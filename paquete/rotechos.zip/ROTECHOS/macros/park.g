; ═══════════════════════════════════════════════════════════════
; park.g  —  Aparcar máquina en zona de seguridad trasera
; Ruta: 0:/macros/park.g
; Llamada con: M98 P"0:/macros/park.g"
;
; Zona de seguridad trasera: X0 Y Max
;   — El carro Y retrocede al fondo del recorrido, alejando la fresa
;     del operario y de la pieza. Z queda elevado a su tope superior
;     (move.axes[2].max, que en RotechOS es Z=0 por convención de homing)
;     para garantizar clearance sobre cualquier material fijado en la mesa.
;     Todos los movimientos son en coordenadas de máquina (G53) para
;     que el aparcado sea independiente del origen de pieza activo.
; ═══════════════════════════════════════════════════════════════

; 5-oct: limpiar el aviso de aborto que dejara un final de carrera anterior (como goto0.g):
; si no, el abort_check de abajo cortaba la macro antes del M84.
if exists(global.abortRequested)
    set global.abortRequested = false
T0                           ; activar tool — M5 se ignora sin ella
M5                           ; apagar spindle antes de mover
; (sin M9: RRF 3.5.4 no lo implementa, solo daba un aviso — 26-sep)

; Guard: G53 requiere homing — abortar si los ejes no están referenciados
if !move.axes[0].homed || !move.axes[1].homed || !move.axes[2].homed
    M291 P"ERROR: Homing requerido antes de aparcar." R"park.g" S1 T0
    abort "park.g abortado — ejes sin referenciar"

; Paso 1 — Elevar Z al tope superior (MCS) para clearance seguro sobre la mesa.
; Antes era Z240 hardcoded → ILEGAL: el área Z es [-100, 0], Z=240 quedaba fuera
; de los soft limits máximos y la SD rechazaba el movimiento (o, sin soft
; limits, el motor empujaba contra el tope físico). Ahora dinámico: SSOT M208.
G53 G1 Z{move.axes[2].max - global.safe_clearance} F{global.z_raise_speed} ; techo M203 Z

; Paso 2 — Mover a zona de seguridad trasera: X0 Y Max (MCS)
;           Se usa el límite máximo de Y para ir al fondo del recorrido
M400                         ; 2-oct: vaciar la cola antes de cambiar la aceleracion (CLAUDE.md §4)
M201 X{exists(global.travel_accel) ? global.travel_accel : 2000} Y{exists(global.travel_accel) ? global.travel_accel : 2000}  ; aceleración de viaje en vacío (más ágil que SEDA/RAYO)
G53 G1 X0 Y{move.axes[1].max - global.homing_backoff_xy} F{global.travel_feed} ; tempo de viaje unificado
M98 P"0:/sys/restore_kinematics.g"  ; restaurar accel del modo activo antes de soltar motores

; Si chocó un final de carrera en el viaje, abortar ANTES de soltar los motores
; (no liberar X/Y con la máquina en una posición de colisión).
M98 P"0:/sys/abort_check.g"
M84 X Y                      ; desactivar motores X e Y (Z se mantiene elevado)