; ═══════════════════════════════════════════════════════════════
; probe_xy_auto.g — Palpado AUTOMÁTICO de esquina XY
; Ruta: 0:/macros/probe_xy_auto.g
;
; ⚠⚠ UNTESTED EN MÁQUINA — AIR-TEST OBLIGATORIO ⚠⚠
;   Prueba primero SIN pieza ni palpador, mirando que los sentidos y recorridos
;   son los correctos para tu utillaje. Este macro MUEVE la fresa/palpador hacia
;   la pieza; un parámetro mal puesto puede provocar una colisión.
;
; A diferencia de probe3d.g (guiado: reposicionas el palpador en cada borde),
; aquí la máquina sondea X e Y SOLA desde una única posición de partida.
;
; PREPARACIÓN (el operario, una sola vez):
;   1. Home hecho.
;   2. Coloca el palpador EN EL AIRE, en diagonal a la esquina de la pieza, a la
;      altura del borde (por debajo de la cara superior), de modo que sondear en
;      sentido +probe_dir_x alcance una cara y +probe_dir_y la otra.
;   3. Lánzalo desde CONFIGURACIÓN y confirma.
;
; Parámetros (config.g): probe_corner_dist, probe_corner_backoff,
;   probe_tip_radius, probe_dir_x, probe_dir_y, probe_speed_fast/slow.
; ═══════════════════════════════════════════════════════════════

; ─── GATE: el palpado automático debe activarse explícitamente en CONFIGURACIÓN ───
if !exists(global.autoProbeEnabled) || !global.autoProbeEnabled
    M291 P"El palpado automático está DESACTIVADO.<br>Actívalo en CONFIGURACIÓN → Palpador 3D antes de usarlo." R"AUTO-PALPADO" S1 T0
    abort "probe_xy_auto abortado — autoProbeEnabled=false"

; ─── GUARDA: sonda no activa ───
if sensors.probes[0].value[0] > 0
    M291 P"ERROR: Sonda activada ANTES de empezar.<br>¿Cortocircuito o palpador tocando algo?" R"AUTO-PALPADO - SEGURIDAD" S1 T0
    abort "probe_xy_auto abortado — sonda activa antes del palpado"

; ─── GUARDA: homing ───
if !move.axes[0].homed || !move.axes[1].homed || !move.axes[2].homed
    M291 P"Los ejes no están referenciados.<br>Haz Home antes del palpado automático." R"AUTO-PALPADO - ERROR" S1 T0
    abort "probe_xy_auto abortado — ejes sin referenciar"

; ─── Confirmación de posicionamiento ───
; 26-sep: husillo parado antes de palpar, como probe3d.g (con el palpador en la
; pinza y el husillo encendido desde la interfaz, se rompe el palpador).
T0                           ; activar tool — M5 se ignora sin ella
M5
G4 P200

M291 P"Coloca el palpador en el aire, en diagonal a la esquina, a la altura del borde.<br>La máquina sondeará X e Y automáticamente.<br>Pulsa OK para empezar." R"AUTO-PALPADO XY" S3

; Aceleración X/Y de palpado DEFINIDA (igual que el núcleo Z con probe_accel_z): sin
; esto, en SEDA (accel 60) el sobre-recorrido tras el disparo a probe_speed_fast era
; ~5mm empujando el palpador contra la pieza. Se restaura al salir (también en errores).
; 5-oct: destinos de G38 recortados al recorrido (G38 no aplica M208, como en probe_axis.g),
; y M400 antes de cambiar la aceleración (CLAUDE.md §4).
M400
M201 X{global.probe_accel_xy} Y{global.probe_accel_xy}

; Recordar la posición de partida (MCS) para regresar entre ejes
; 26-sep: el cero va al WCS ACTIVO (move.workplaceNumber, base 0), no siempre a G54.
var wcs_p = exists(move.workplaceNumber) ? move.workplaceNumber + 1 : 1
M400                         ; 3-oct: posición real, no la de la cola
var sx = move.axes[0].machinePosition
var sy = move.axes[1].machinePosition
var dx = global.probe_dir_x
var dy = global.probe_dir_y

; 3-oct (fuente de RRF 3.5.4): los G38.2 iban en G91 con destino relativo, pero G38.x ignora
; G91 (GCodes6.cpp:597-607): palpaba hacia X=±25 del WCS, no 25 mm desde aquí. Y su F tampoco
; cuenta (va la de M558). Ahora: destino en máquina con G53 y velocidad con probe_speed.g.
M400
; ═══════════════ EJE X ═══════════════
; Pasada rápida de búsqueda
G90
M98 P"0:/sys/probe_speed.g" F{global.probe_speed_fast}
G53 G38.2 X{max(move.axes[0].min, min(move.axes[0].max, var.sx + var.dx * global.probe_corner_dist))}
if result != 0
    G91
    G1 X{-var.dx * global.probe_corner_backoff} F{global.probe_backoff_speed}
    G90
    M98 P"0:/sys/restore_kinematics.g"
    M291 P"El palpador no tocó la cara X dentro del recorrido.<br>Revisa la posición de partida y probe_corner_dist / probe_dir_x." R"AUTO-PALPADO - ERROR X" S1 T0
    abort "probe_xy_auto abortado — sin contacto X"
; Retroceso y pasada lenta de precisión
G91
G1 X{-var.dx * global.probe_corner_backoff} F{global.probe_backoff_speed}
G90
M400
M98 P"0:/sys/probe_speed.g" F{global.probe_speed_slow}
G53 G38.2 X{max(move.axes[0].min, min(move.axes[0].max, move.axes[0].machinePosition + var.dx * (global.probe_corner_backoff + 2)))}
if result != 0
    M98 P"0:/sys/restore_kinematics.g"
    M291 P"La pasada lenta X no hizo contacto." R"AUTO-PALPADO - ERROR X" S1 T0
    abort "probe_xy_auto abortado — sin contacto X (lento)"
; Fijar X0 en la cara, compensando el radio de la punta del palpador
G10 L20 P{var.wcs_p} X{-var.dx * global.probe_tip_radius}
; Apartar X y regresar a la X de partida (Y intacta) — viaje PROTEGIDO: este
; barrido a altura de borde es el único movimiento ciego del ciclo; si el palpador
; toca la cara Y (pieza mayor de lo esperado / mal posicionamiento), para y aborta.
G91
G1 X{-var.dx * global.probe_corner_backoff} F{global.probe_backoff_speed}
G90
M98 P"0:/sys/protected_travel.g" X{var.sx} F{global.travel_feed / 2}

; ═══════════════ EJE Y ═══════════════
G90
M400
M98 P"0:/sys/probe_speed.g" F{global.probe_speed_fast}
G53 G38.2 Y{max(move.axes[1].min, min(move.axes[1].max, var.sy + var.dy * global.probe_corner_dist))}
if result != 0
    G91
    G1 Y{-var.dy * global.probe_corner_backoff} F{global.probe_backoff_speed}
    G90
    M98 P"0:/sys/restore_kinematics.g"
    M291 P"El palpador no tocó la cara Y dentro del recorrido.<br>Revisa la posición de partida y probe_corner_dist / probe_dir_y." R"AUTO-PALPADO - ERROR Y" S1 T0
    abort "probe_xy_auto abortado — sin contacto Y"
G91
G1 Y{-var.dy * global.probe_corner_backoff} F{global.probe_backoff_speed}
G90
M400
M98 P"0:/sys/probe_speed.g" F{global.probe_speed_slow}
G53 G38.2 Y{max(move.axes[1].min, min(move.axes[1].max, move.axes[1].machinePosition + var.dy * (global.probe_corner_backoff + 2)))}
if result != 0
    M98 P"0:/sys/restore_kinematics.g"
    M291 P"La pasada lenta Y no hizo contacto." R"AUTO-PALPADO - ERROR Y" S1 T0
    abort "probe_xy_auto abortado — sin contacto Y (lento)"
; Fijar Y0 en la cara, compensando el radio de la punta
G10 L20 P{var.wcs_p} Y{-var.dy * global.probe_tip_radius}

; Apartar Y y subir a zona segura
G91
G1 Y{-var.dy * global.probe_corner_backoff} F{global.probe_backoff_speed}
G1 Z{global.safe_clearance} F{global.probe_backoff_speed}
G90

; Restaurar la cinemática del modo activo (la aceleración de palpado ya no hace falta)
M98 P"0:/sys/restore_kinematics.g"

M291 P"Origen XY fijado automáticamente en la esquina de la pieza." R"AUTO-PALPADO XY - COMPLETADO" S1 T5
