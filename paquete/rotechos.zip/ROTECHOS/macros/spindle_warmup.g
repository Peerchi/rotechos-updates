; spindle_warmup.g
; =========================================================================
; Rampa progresiva para calentar rodamientos del Spindle
; =========================================================================
; Este macro evita el desgaste prematuro de los rodamientos cerámicos
; al arrancar el VFD directamente a 24,000 RPM estando en frío.
; =========================================================================

; --- Parámetros ajustables ---
var rpm_inicial = 8000      ; RPM seguras de arranque (no bajar de 8000 en motores de aire)
var rpm_final = spindles[0].max       ; RPM máximas del spindle (Object Model)
var incremento_rpm = 2000   ; Salto de RPM en cada escalón
var tiempo_espera = global.warmup_step_time       ; Segundos de estabilización en cada escalón (SSOT)
; -----------------------------

M291 P{"Arrancando rampa térmica del Spindle (" ^ var.rpm_inicial ^ " a " ^ var.rpm_final ^ " RPM)..."} R"Warmup" T5

; 1. Arranque en frío (RPM mínima)
M3 S{var.rpm_inicial}
G4 S{var.tiempo_espera}

var rpm_actual = var.rpm_inicial

; 2. Bucle de rampa escalonada
while var.rpm_actual < var.rpm_final
    set var.rpm_actual = var.rpm_actual + var.incremento_rpm
    if var.rpm_actual > var.rpm_final
        set var.rpm_actual = var.rpm_final ; Evitar pasarse del máximo
    
    M3 S{var.rpm_actual}
    G4 S{var.tiempo_espera}

; 3. Mantener arriba para purgar grasa térmica
M291 P{"Manteniendo " ^ var.rpm_final ^ " RPM por " ^ global.warmup_hold_time ^ "s para purgar grasa..."} R"Warmup" T5
G4 S{global.warmup_hold_time}

; 4. Apagado y deceleración
M291 P"Frenando el Spindle..." R"Warmup" T3
M5
G4 P{global.spindle_cooldown_ms * 3} ; Esperar a que el eje frene por completo antes de permitir otras acciones

M291 P"Calentamiento completado con éxito. Máquina lista." R"Warmup" T3
