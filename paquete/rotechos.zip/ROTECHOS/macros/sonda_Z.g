; ═══════════════════════════════════════════════════════════════
; sonda_Z.g  —  Establecer Z=0 en la superficie del material
; Ruta: 0:/macros/sonda_Z.g
; Llamada con: M98 P"0:/macros/sonda_Z.g"
;
; Cómo funciona:
;   1. Sube Z al tope, va RÁPIDO al sensor fijo (X=move.axes[0].max, Y=tool_sensor_y).
;   2. Palpa Z dos veces (igual que el SAC) usando la sonda fija única (botón Tool/E.7).
;   3. Aplica Z=0 EN LA SUPERFICIE DEL MATERIAL, no en el mártir.
;
; Diferencia con el SAC (sys/M6.g):
;   - SAC:      Z=0 = mártir   → G10 L20 P1 Z{z_sensor_to_table}
;   - SondaZ:   Z=0 = material → G10 L20 P1 Z{z_sensor_to_table - touchplate_thickness}
;
; PRERREQUISITO: el operario DEBE configurar global.touchplate_thickness con
; el GROSOR real del material que está sobre el mártir (Configuración →
; Tool-Change → "Grosor de la pastilla"). Si pones un grosor incorrecto,
; el Z=0 quedará desplazado.
; ═══════════════════════════════════════════════════════════════

G90                          ; modo absoluto

; --- SEGURIDAD: apagar husillo y refrigerante antes de palpar ---
; Palpar con el husillo GIRANDO es peligroso (la fresa puede dañar el sensor o
; engancharse). Se fuerza el apagado nada más entrar, antes de cualquier guard.
T0                           ; activar tool — M5 se ignora sin ella
M5                           ; apagar husillo
; (sin M9: RRF 3.5.4 no lo implementa, solo daba un aviso — 26-sep)
G4 P200                      ; breve pausa para asegurar que el husillo se detiene

; --- GUARD 1: sonda activa al empezar ---
if sensors.probes[0].value[0] > 0
    M291 P"ERROR: Sonda activada ANTES de empezar.<br>¿Hay algo metálico cerca del sensor fijo?" R"SONDA Z - SEGURIDAD" S1 T0
    abort "Sonda Z abortada — sonda activa antes del palpado"

; --- GUARD 2: homing obligatorio (usamos G53) ---
if !move.axes[0].homed || !move.axes[1].homed || !move.axes[2].homed
    M291 P"Los ejes no están referenciados. Realizando Homing automático antes de palpar..." R"SONDA Z - HOMING" S1 T3
    G28

; LED Sonda Z: blanco azulado (R100 U150 B255) sólido. ANTES era lila
; (R170 U40 B255) — similar a magenta del SAC, confundía al operario. Blanco
; azulado comunica "calibración técnica" (no cambio herramienta) y es
; visualmente distinto de cualquier otro estado.
M150 R100 U150 B255 F0 S25      ; Blanco azulado sólido (Sonda Z)
M150 F1

; --- 1. PALPAR EL SENSOR FIJO (lógica compartida con el SAC) ---
; El sub-macro va al sensor (X=move.axes[0].max, Y=global.tool_sensor_y), hace palpado
; rápido + 2 pasadas lentas, guarda el disparo en global.probe_trigger_z, sube Z y
; restaura cinemática. En error aborta él mismo (detiene esta macro).
; 27-sep (revisión de la integración, R6): si probe_z_sensor.g faltara, M98 solo avisa y
; sigue, y se leería el true del palpado anterior.
set global.probeOk = false
M98 P"0:/sys/probe_z_sensor.g"
; 26-sep: si se canceló el aviso de repetibilidad, el palpado no terminó y probe_trigger_z es
; una lectura vieja: aplicarla dejaría el cero de pieza en otro sitio.
if !global.probeOk
    abort "Sonda Z cancelada: el palpado no terminó"

; --- 2. APLICAR Z=0 EN LA SUPERFICIE DEL MATERIAL ---
; G10 L2 aritmético con el disparo guardado por el probe (la fresa ya está arriba).
; Cota WCS que queremos en el punto de disparo =
;          z_sensor_to_table (disparo SOBRE el mártir/mesa, típico 5 — POSITIVO)
;        - touchplate_thickness (grosor del material sobre el mártir, 0 = sin pastilla)
; Equivale a G10 L20 P1 Z{z_sensor_to_table - touchplate_thickness} en el disparo:
;   offset = probe_trigger_z - (z_sensor_to_table - touchplate_thickness).
; 16-sep (B7): el cero se escribía SIEMPRE en G54 (P1). Con un programa en G55, el
; SAC corregía G54 y el trabajo seguía con la longitud de la fresa anterior: la fresa
; más larga se clava esa diferencia. Se escribe en el sistema de coordenadas ACTIVO.
var wcs_p = exists(move.workplaceNumber) ? move.workplaceNumber + 1 : 1
G10 L2 P{var.wcs_p} Z{global.probe_trigger_z - (global.z_sensor_to_table - global.touchplate_thickness)}

; --- 3. SUBIR Z AL TOPE Y AVISAR ---
G53 G0 Z{move.axes[2].max - global.safe_clearance}
M150 R0 U170 B0 F0 S25       ; Verde (listo)
M150 F1
M291 P{"Cero Z establecido en la SUPERFICIE del material (grosor configurado: " ^ global.touchplate_thickness ^ "mm)."} R"SONDA Z LISTA" S1 T3
