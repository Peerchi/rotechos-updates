; ═══════════════════════════════════════════════════════════════
; clear_zero.g  —  Limpiar todos los offsets de trabajo
; Ruta: 0:/macros/clear_zero.g
; Llamada con: M98 P"0:/macros/clear_zero.g"
; ═══════════════════════════════════════════════════════════════

; Resetear offsets a cero absoluto (WCS = MCS).
; L2 establece el offset directamente; L20 fijaría la posición ACTUAL como cero
; (efecto contrario al deseado).
; 16-sep (B7): limpia el sistema de coordenadas ACTIVO. Antes ponía P1 fijo y el aviso
; decía «todos los offsets»: con el trabajo en G55, el operario creía haber limpiado
; un cero que seguía puesto.
var wcs_p = exists(move.workplaceNumber) ? move.workplaceNumber + 1 : 1
G10 L2 P{var.wcs_p} X0 Y0 Z0

M291 P"El cero de trabajo del sistema de coordenadas ACTIVO se ha borrado.<br><br>Necesitarás volver a establecer Zero X, Zero Y y Zero Z antes de mecanizar." R"CERO LIMPIADO" S1 T5
