; ═══════════════════════════════════════════════════════════════
; mesh_probe.g — Malla de palpado de altura del material (N×M puntos).
; Ruta: 0:/macros/mesh_probe.g
; Llamada: M98 P"0:/macros/mesh_probe.g" (con los global.mesh* de globals.g ya puestos por la UI).
;
; QUÉ HACE
;   1. Verifica HOME, sonda no activa y husillo apagado (estos tres
;      requisitos son BLOQUEANTES — la sonda contra un eje sin referenciar
;      rompe la sonda).
;   2. Recorre la cuadrícula XY fila a fila, X siempre ascendente (3-oct: era
;      una serpentina que guardaba las filas impares al revés). En cada punto:
;        a. Va al XY en RAYO (moviendose entre puntos no es crítico).
;        b. Baja a la altura segura en SEDA.
;        c. Palpa con G38.2 a probe_speed_fast (una sola pasada por
;           punto: la malla mide ALABEO, no precisión absoluta; el
;           núcleo compartido `probe_z_sensor.g` es para cero pieza).
;        d. Guarda la lectura en `global.meshPoints (CSV, fila*nx + columna)`.
;        e. Publica `global.meshCurrent = fila*nx + columna` para que la UI haga
;           polling y dibuje el progreso.
;   3. Si un punto falla (sin contacto / sensor activo), marca
;      `global.meshFailedIndex = fila*nx + columna`, `global.meshOk = false`
;      y ABORTA limpiamente (sube Z, restaura cinemática, LED rojo).
;
; PRERREQUISITOS (los pone la UI antes de llamar):
;   - global.meshXmin, meshXmax, meshYmin, meshYmax (mm, MCS) — área a palpar
;   - global.meshNx, meshNy                       — nº de puntos
;   - global.meshFast                             — velocidad rápida (mm/min)
;   - global.meshSlow                             — velocidad lenta (mm/min)
;   - global.meshSafeZ                           — altura segura de viaje (mm, positivo)
;   - global.meshMargin                           — margen al borde M208 (mm)
;   - ejes homeados, sonda libre, husillo parado
;
; CONTRATO DE SALIDA (lo que lee la UI):
;   - global.meshOk          true/false  — malla válida o no
;   - global.meshCurrent     int         — punto actual (0..nx*ny-1)
;   - global.meshFailedIndex int|undef  — punto que falló (-1 si ok)
;   - global.meshPoints      string CSV  — z de cada punto, fila a fila
;                                          (punto (fila, columna) = fila*nx + columna)
; ═══════════════════════════════════════════════════════════════

; ─── 1. GUARDIA: HOME obligatorio ───
if !move.axes[0].homed || !move.axes[1].homed || !move.axes[2].homed
  set global.meshOk = false
  set global.meshFailedIndex = -1
  M291 P"Malla: los ejes no están referenciados. Ejecuta G28 antes de palpar." R"MALLA - HOMING" S1 T0
  abort "mesh_probe abortado — ejes sin referenciar"

; ─── 2. GUARDIA: sonda no activa al empezar ───
if sensors.probes[0].value[0] > 0
  set global.meshOk = false
  set global.meshFailedIndex = -1
  M291 P"ERROR: Sonda activada ANTES de empezar la malla.<br>¿Cortocircuito o fresa tocando la pieza?" R"MALLA - SEGURIDAD" S1 T0
  abort "mesh_probe abortado — sonda activa antes del palpado"

; ─── 3. GUARDIA: husillo apagado ───
T0                                  ; necesario para que M5 se ejecute
M5
; (sin M9: RRF 3.5.4 no lo implementa, solo daba un aviso — 26-sep)
G4 P200

; ─── 4. INICIALIZACIÓN ───
; defaults tolerantes si la UI no declaró alguna global
var xmin = exists(global.meshXmin) ? global.meshXmin : 10
var xmax = exists(global.meshXmax) ? global.meshXmax : (move.axes[0].max - 10)
var ymin = exists(global.meshYmin) ? global.meshYmin : 10
var ymax = exists(global.meshYmax) ? global.meshYmax : (move.axes[1].max - 10)
var nx   = exists(global.meshNx)   ? global.meshNx   : 5
var ny   = exists(global.meshNy)   ? global.meshNy   : 5
var fast = exists(global.meshFast) ? global.meshFast : 600
var slow = exists(global.meshSlow) ? global.meshSlow : 200
var wcs_i = exists(move.workplaceNumber) ? move.workplaceNumber : 0   ; 16-sep (B7): índice del WCS activo (0 = G54)
var safe_z = exists(global.meshSafeZ) ? global.meshSafeZ : 5
var total = var.nx * var.ny
var i = 0
var j = 0
var idx = 0
var x = 0
var y = 0

; limitar nx/ny a rangos razonables (defensivo: la UI ya valida, pero por
; si alguien edita las globals a mano en un macro custom). 50×50=2500 puntos
; ≈ 25 minutos a 600 mm/min + 200 mm/min — tope del tope.
if var.nx < 2 || var.ny < 2 || var.nx > 50 || var.ny > 50
  set global.meshOk = false
  set global.meshFailedIndex = -1
  M291 P{"Malla: dimensiones inválidas (" ^ var.nx ^ "×" ^ var.ny ^ "). Usa entre 2×2 y 50×50."} R"MALLA - PARÁMETROS" S1 T0
  abort "mesh_probe abortado — dimensiones inválidas"

; resetea el array (RRF no tiene array literal vacío; lo creamos como
; string CSV y la UI lo reinterpreta como array de números al parsear)
set global.meshPoints = ""
set global.meshCurrent = 0
set global.meshFailedIndex = -1
set global.meshOk = false

; ─── 5. LED: palpado en curso (azul brillante, mismo que el núcleo) ───
M150 E0 R0 U80 B255 S25 F1

; pasar a RAYO para los movimientos entre puntos (agilidad)
M400
M201 X{global.pro_accel_x} Y{global.pro_accel_y}
M566 X{global.pro_jerk_x} Y{global.pro_jerk_y} P1

G90
G53 G0 Z{move.axes[2].max - global.safe_clearance}      ; subir Z al tope (seguro)

; ─── 6. BUCLE POR FILAS ───
; Para cada fila i (Y = ymin + i*(ymax-ymin)/(ny-1)), X siempre ascendente.
; 3-oct: era una serpentina (filas impares de derecha a izquierda) y guardaba las lecturas en
; el orden de visita: en las filas impares el CSV salía al revés y el mapa las pintaba
; reflejadas (la interfaz lee el punto (fila, columna) en fila*nx + columna). Además decidía
; la fila con `var.i % 2`, y RRF 3.5.4 no tiene operador `%` (ExpressionParser.cpp:197): la
; macro moría en esa línea. Una vuelta en X por fila cuesta poco frente al palpado.
while var.i < var.ny
  set var.j = 0
  while var.j < var.nx
    set var.x = var.xmin + (var.xmax - var.xmin) * var.j / (var.nx - 1)
    set var.y = var.ymin + (var.ymax - var.ymin) * var.i / (var.ny - 1)
    set var.idx = var.i * var.nx + var.j
    set global.meshCurrent = var.idx
    ; 16-sep (C19): el operario ha cancelado. Salida limpia: Z arriba, cinematica
    ; repuesta y malla marcada como no valida, para que la interfaz lo confirme.
    if global.meshAbort
      set global.meshOk = false
      set global.meshAbort = false
      G90
      G53 G0 Z{move.axes[2].max - global.safe_clearance} F{exists(global.travel_feed) ? global.travel_feed : 4000}
      M400
      M98 P"0:/sys/restore_kinematics.g"
      M150 E0 R255 U80 B0 S25 F0
      M291 P"Palpado de malla cancelado por el operario. La malla NO es valida." R"MALLA - CANCELADA" S1 T5
      abort "mesh_probe cancelado por el operario"
    ; mover en XY (RAYO)
    G53 G1 X{var.x} Y{var.y} F{exists(global.travel_feed) ? global.travel_feed : 4000}
    ; bajar a altura segura en SEDA (palpado requiere SEDA)
    M400
    M201 X{global.silk_accel_x} Y{global.silk_accel_y} Z{global.silk_accel_z}
    M566 X{global.silk_jerk_x} Y{global.silk_jerk_y} Z{global.silk_jerk_z} P1
    G53 G0 Z{move.axes[2].max - global.safe_clearance} F{exists(global.travel_feed) ? global.travel_feed : 4000}  ; 2-oct: safe_z (+5) en G53 quedaba por encima del final de carrera
    ; palpar (G38.2 a velocidad rápida — UNA pasada; malla mide alabeo)
    ; 3-oct: era `G91` + `G38.2 Z{min} F{fast}`. G38.x de RRF 3.5.4 ignora G91 y su propio F
    ; (sys/probe_speed.g): el destino era Z{min} del WCS y la velocidad la de M558.
    M98 P"0:/sys/probe_speed.g" F{var.fast}
    G53 G38.2 Z{move.axes[2].min}
    if result != 0
      ; FALLO: marca y aborta limpio
      set global.meshFailedIndex = var.idx
      set global.meshOk = false
      M98 P"0:/sys/probe_cleanup_error.g" Z{move.axes[2].workplaceOffsets[var.wcs_i]}
      M291 P{"ERROR: sensor sin contacto en el punto " ^ (var.idx + 1) ^ " de " ^ var.total ^ ".<br>Comprueba el sensor y la pieza. La malla NO es válida."} R"MALLA - FALLO" S1 T0
      abort "mesh_probe abortado — sensor sin contacto"
    ; guarda la lectura en CSV acumulado (orden fila a fila: fila*nx + columna)
    if global.meshPoints == ""
      set global.meshPoints = "" ^ move.axes[2].machinePosition
    else
      set global.meshPoints = global.meshPoints ^ "," ^ move.axes[2].machinePosition
    ; subir Z al tope antes del siguiente punto
    G90
    G53 G0 Z{move.axes[2].max - global.safe_clearance} F{exists(global.travel_feed) ? global.travel_feed : 4000}
    ; volver a RAYO para el siguiente movimiento XY
    M400
    M201 X{global.pro_accel_x} Y{global.pro_accel_y}
    M566 X{global.pro_jerk_x} Y{global.pro_jerk_y} P1
    G90
    set var.j = var.j + 1
  set var.i = var.i + 1

; ─── 7. CIERRE LIMPIO ───
M400
M98 P"0:/sys/restore_kinematics.g"   ; 2-oct: la malla dejaba el modo de palpado (SEDA) activo
; LED verde: malla completa
M150 E0 R0 U170 B0 S25 F1
M150 F1
set global.meshOk = true
set global.meshFailedIndex = -1

; ─── 8. AVISO AL OPERARIO ───
M291 P{"Malla completa: " ^ var.nx ^ "×" ^ var.ny ^ " = " ^ var.total ^ " puntos palpados.<br>Revisa la vista del mapa. Activa la compensación solo si la distribución es coherente."} R"MALLA - COMPLETADA" S1 T5
