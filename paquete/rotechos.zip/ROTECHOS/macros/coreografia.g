; ═══════════════════════════════════════════════════════════════
; coreografia.g — Presentación de movimiento (demo)
; Ruta: 0:/macros/coreografia.g  ·  Llamada: M98 P"0:/macros/coreografia.g"
;
; Danza corta SIN corte para demos/vídeo: diagonal fluida al centro, dos
; círculos encadenados (uno por sentido), pequeña reverencia en Z y pose
; final frente al operario. Todo en cotas MÁQUINA y al tempo de viaje
; unificado (global.travel_feed) — el junction deviation (M566 P1) funde
; los segmentos sin paradas.
;
; REQUISITOS:
;   - Homing hecho (aborta si no).
;   - MESA DESPEJADA: la reverencia baja a ~15mm bajo el tope en el centro.
;   - AIR-TEST la primera vez, mirando y con la mano en el paro.
; BONUS: si el círculo no sale REDONDO, tienes un problema de M92/M350 —
;   esta macro sirve también como verificación visual de calibración.
; ═══════════════════════════════════════════════════════════════

if !move.axes[0].homed || !move.axes[1].homed || !move.axes[2].homed
    M291 P"Haz Homing (G28) antes de la coreografía." R"COREOGRAFIA" S1 T0
    abort "coreografia abortada — ejes sin referenciar"

T0
M5                                   ; nunca con el husillo girando

; Empezar con el flag de aborto limpio (por si quedó de una colisión anterior).
if exists(global.abortRequested)
    set global.abortRequested = false

M150 R170 U40 B255 P255 F2 S25       ; púrpura pulsante (en movimiento)

; 1. Asegurar Z arriba (y COMPLETAR la subida con M400 ANTES de cualquier viaje
;    XY: sin esto el lookahead puede fundir la subida de Z con el viaje y la
;    fresa cruza la mesa aún bajando).
G90
G53 G0 Z{move.axes[2].max - global.safe_clearance}
M400
M201 X{exists(global.travel_accel) ? global.travel_accel : 2000} Y{exists(global.travel_accel) ? global.travel_accel : 2000}  ; aceleración de viaje en vacío (danza ágil, círculos fluidos)

; 2. Dos círculos completos encadenados, CENTRADOS en la mesa y con radio
;    DERIVADO del espacio real (nunca asume el tamaño de la máquina). El radio
;    es el menor margen libre alrededor del centro menos un colchón de 15mm,
;    tope 40mm. Si no caben (mesa pequeña / área mal configurada) se OMITEN
;    con aviso en vez de chocar. El círculo se traza desde su punto izquierdo
;    (cx-R) girando con el centro en cx → queda perfectamente centrado, su
;    extensión es exactamente cx±R, cy±R, imposible salirse de los límites.
var cx = (move.axes[0].max + move.axes[0].min) / 2
var cy = (move.axes[1].max + move.axes[1].min) / 2
var marginX = min(var.cx - move.axes[0].min, move.axes[0].max - var.cx)
var marginY = min(var.cy - move.axes[1].min, move.axes[1].max - var.cy)
var danceR = min(40, min(var.marginX, var.marginY) - 15)
if var.danceR >= 10
    G53 G1 X{var.cx - var.danceR} Y{var.cy} F{global.travel_feed}   ; punto izquierdo del círculo
    M98 P"0:/sys/abort_check.g"
    G91
    G2 X0 Y0 I{var.danceR} J0 F{global.travel_feed}    ; círculo horario, centro = cx
    M98 P"0:/sys/abort_check.g"
    G3 X0 Y0 I{var.danceR} J0 F{global.travel_feed}    ; antihorario, mismo centro
    M98 P"0:/sys/abort_check.g"
    G90
else
    G53 G1 X{var.cx} Y{var.cy} F{global.travel_feed}   ; solo ir al centro
    echo "coreografia: area pequena para los circulos — omitidos"

; Si un final de carrera disparó durante el viaje/círculos, abortar aquí en vez
; de seguir bajando en la reverencia (M410 ya cortó el movimiento; esto corta la macro).
M98 P"0:/sys/abort_check.g"

; 3. Reverencia: pequeño gesto en Z (requiere mesa despejada — ver cabecera)
; Verificar si Z tiene espacio suficiente respecto a la mesa antes de bajar
if move.axes[2].machinePosition > (move.axes[2].min + 5)
    G91
    G1 Z-5 F800
    M98 P"0:/sys/abort_check.g"
    G1 Z5 F800
    M98 P"0:/sys/abort_check.g"
    G90
else
    echo "coreografia: Z demasiado bajo para la reverencia — gesto omitido"

M98 P"0:/sys/abort_check.g"

; 4. Pose final: frente al operario (misma Y que el cambio de herramienta)
G53 G1 X{move.axes[0].max / 2} Y{exists(global.tool_change_y) ? global.tool_change_y : 30} F{global.travel_feed}
M98 P"0:/sys/restore_kinematics.g"  ; restaurar accel del modo activo
M400

M150 R0 U170 B0 P255 F0 S25          ; verde sólido (saludo terminado)
echo "Coreografía completada"
