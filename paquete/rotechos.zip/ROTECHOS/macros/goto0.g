; ═══════════════════════════════════════════════════════════════
; goto0.g  —  Ir al origen de trabajo (WCS X0 Y0)
; Ruta: 0:/macros/goto0.g
; Llamada con: M98 P"0:/macros/goto0.g"
; ═══════════════════════════════════════════════════════════════

G90                          ; modo absoluto

; Guard: necesita homing para mover con seguridad
if !move.axes[0].homed || !move.axes[1].homed || !move.axes[2].homed
    M291 P"Los ejes deben tener referencia (Homing) antes de ir al origen." R"GOTO0 - ERROR" S1 T0
    abort "goto0.g abortado — ejes sin referenciar"

; Elevar Z al tope superior por coordenada de MÁQUINA (G53) — siempre válido,
; independientemente de si hay un cero Z de pieza puesto.
; Antes era `G0 Z{global.safe_clearance}` en WCS: si el operario aún no había
; fijado el Z cero, Z=10 caía POR ENCIMA del tope (máquina Z max = 0) y RRF
; rechazaba el movimiento → "Ir a 0" no hacía nada. Mismo bug que tenía park.g.
G53 G0 Z{move.axes[2].max - global.safe_clearance} F{global.z_raise_speed}

; Mover XY al origen de trabajo (donde pusiste Zero X / Zero Y)
G90
M400                         ; 2-oct: vaciar la cola antes de cambiar la aceleracion (CLAUDE.md §4)
M201 X{exists(global.travel_accel) ? global.travel_accel : 2000} Y{exists(global.travel_accel) ? global.travel_accel : 2000}  ; aceleración de viaje en vacío
; Flag de aborto limpio antes del viaje (por si quedó de una colisión anterior).
if exists(global.abortRequested)
    set global.abortRequested = false
G1 X0 Y0 F{global.travel_feed} ; ir a WCS X0 Y0 (tempo de viaje unificado)
; Si chocó un final de carrera en el viaje, el M410 del escudo lo cortó; abortar
; la macro para no continuar (es el único movimiento, pero por consistencia).
M98 P"0:/sys/abort_check.g"
M98 P"0:/sys/restore_kinematics.g"  ; restaurar accel del modo activo

; NO bajar Z automáticamente — el operador decide manualmente
; (bajar Z ciego puede impactar bridas, material o sonda)
