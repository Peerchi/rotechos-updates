; ventiladores_prueba.g — enciende los ventiladores de la electronica (AUX1, F1) 15 s y los
; devuelve al control por temperatura (11-oct-2026). Separa una averia de cableado de una de
; configuracion: si con esto no giran, el fallo esta en la placa o en el cable, no en el umbral.
; No mueve nada. Con un trabajo en marcha no se ejecuta.
if state.status == "processing" || state.status == "paused" || state.status == "pausing" || state.status == "resuming"
    abort "Prueba de ventiladores: hay un trabajo en marcha. Prueba con la maquina parada."
if !exists(fans[1]) || fans[1] == null
    abort "Prueba de ventiladores: el ventilador F1 (AUX1) no esta configurado en config.g."
var umbral = 45
if fans[1].thermostatic.lowTemperature != null
    set var.umbral = fans[1].thermostatic.lowTemperature
echo "MCU " ^ (exists(boards[0].mcuTemp) ? boards[0].mcuTemp.current : "?") ^ " C | umbral " ^ var.umbral ^ " C | ventiladores " ^ fans[1].actualValue
echo "Encendiendo los ventiladores al 100 % durante 15 s. Mira el LED de AUX1 y el de VMOS en la placa."
M106 P1 H-1 S1
G4 S15
M106 P1 H10 T{var.umbral}
if exists(sensors.analog[11]) && sensors.analog[11] != null
    M106 P1 H10:11
echo "Ventiladores devueltos al control por temperatura (umbral " ^ var.umbral ^ " C), ahora a " ^ fans[1].actualValue
