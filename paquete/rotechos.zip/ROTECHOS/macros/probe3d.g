; ═══════════════════════════════════════════════════════════════
; probe3d.g  —  Palpador 3D (Buscar esquina de pieza)
; Ruta: 0:/macros/probe3d.g
; Llamada con: M98 P"0:/macros/probe3d.g"
; Requisito: Sonda/palpador configurado en config.g (M558)
; ═══════════════════════════════════════════════════════════════

; ─── APAGAR EL HUSILLO ANTES DE NADA ───
; B-H2.5 (auditoria 15-sep, MEDIA / ALTA con palpador caro): esta macro tenia
; guardas de sonda y de homing pero NINGUN M5, al reves que `sonda_Z.g`,
; `mesh_probe.g` y `M6.g`. Con el husillo encendido por MDI antes de montar el
; palpador 3D, se palpaba GIRANDO: el palpador se destroza y la punta sale
; despedida. Mismo patron y mismo orden que `sonda_Z.g:26-30` — apagar primero,
; guardas despues, porque una guarda que aborta con el husillo girando lo deja
; girando.
; 17-oct (A3): el escudo T2 corta tambien esta macro (abort_check.g entre fases). La peticion
; vieja, de un disparo anterior, se limpia LO PRIMERO: limpiarla tras el M5 y el G4 P200 de
; abajo borraba un disparo de esos 200 ms. Tras el G4 se comprueba, y ningun final del escudo
; puede estar pisado (guards/check_shield_clear.g).
if {exists(global.abortRequested)}
    set global.abortRequested = false
T0                           ; activar tool — M5 se ignora sin ella
M5                           ; apagar husillo
; (sin M9: RRF 3.5.4 no lo implementa, solo daba un aviso — 26-sep)
G4 P200                      ; breve pausa para asegurar que el husillo se detiene
M98 P"0:/sys/guards/check_shield_clear.g"
M98 P"0:/sys/abort_check.g"

; ─── GUARDIA DE SEGURIDAD ───
if sensors.probes[0].value[0] > 0
    M291 P"ERROR: Sonda activada ANTES de empezar.<br>¿Cortocircuito o fresa tocando la pieza?" R"PALPADOR 3D - SEGURIDAD" S1 T0
    abort "Palpador 3D abortado — sonda activa antes del palpado"

; GUARDIA DE HOMING: sin referencia, el G38.2 se mueve a ciegas desde una cota
; desconocida → riesgo de colisión. (Igual que sonda_Z.g, M6.g, bordeador.g…)
if !move.axes[0].homed || !move.axes[1].homed || !move.axes[2].homed
    M291 P"Los ejes no están referenciados.<br>Haz Home antes de usar el Palpador 3D." R"PALPADOR 3D - ERROR" S1 T0
    abort "Palpador 3D abortado — ejes sin referenciar"

; ─── PASO 1: Palpar Z (superficie superior) ───
M291 P"Coloca el palpador sobre la superficie de la pieza.<br>Pulsa OK para palpar Z." R"PALPADOR 3D - Paso 1/3" S3

; 26-sep: el cero va al WCS ACTIVO (move.workplaceNumber, base 0), no siempre a G54.
var wcs_p = {exists(move.workplaceNumber) ? move.workplaceNumber + 1 : 1}
G90

M98 P"0:/sys/probe_axis.g" A"Z" D-50
M98 P"0:/sys/abort_check.g"          ; 17-oct (A3): antes del G10 y del retroceso
G10 L20 P{var.wcs_p} Z0
M400
G91
G1 Z{min(global.safe_clearance / 2, move.axes[2].max - move.axes[2].machinePosition)} F{global.probe_backoff_speed}   ; 18-oct: tope Z MAX
G90
M400
M98 P"0:/sys/abort_check.g"

; ─── PASO 2: Palpar X (borde lateral) ───
M291 P"Mueve el palpador al lateral X de la pieza.<br>Debe quedar en el aire, junto al borde.<br>Pulsa OK para palpar X." R"PALPADOR 3D - Paso 2/3" S3

M98 P"0:/sys/protected_travel.g" Z{move.axes[2].machinePosition - move.axes[2].userPosition - global.probe_edge_depth} F{global.probe_backoff_speed}
M98 P"0:/sys/probe_axis.g" A"X" D-50
M98 P"0:/sys/abort_check.g"          ; 17-oct (A3): antes del G10 y del retroceso
G10 L20 P{var.wcs_p} X{global.probe_tip_radius}
G91
G1 X{global.homing_backoff_xy} F{global.probe_backoff_speed}
G90
M400
M98 P"0:/sys/abort_check.g"
G53 G1 Z{min(move.axes[2].max, move.axes[2].machinePosition - move.axes[2].userPosition + 5)} F{global.probe_backoff_speed}   ; Z5 del WCS, sin pasar de Z MAX
M400
M98 P"0:/sys/abort_check.g"

; ─── PASO 3: Palpar Y (borde frontal) ───
M291 P"Mueve el palpador al lateral Y de la pieza.<br>Debe quedar en el aire, junto al borde.<br>Pulsa OK para palpar Y." R"PALPADOR 3D - Paso 3/3" S3

M98 P"0:/sys/protected_travel.g" Z{move.axes[2].machinePosition - move.axes[2].userPosition - global.probe_edge_depth} F{global.probe_backoff_speed}
M98 P"0:/sys/probe_axis.g" A"Y" D-50
M98 P"0:/sys/abort_check.g"          ; 17-oct (A3): antes del G10 y del retroceso
G10 L20 P{var.wcs_p} Y{global.probe_tip_radius}
G91
G1 Y{global.homing_backoff_xy} F{global.probe_backoff_speed}
G90
M400
M98 P"0:/sys/abort_check.g"
G91
G1 Z{min(global.safe_clearance, move.axes[2].max - move.axes[2].machinePosition)} F{global.probe_backoff_speed}   ; 18-oct: tope Z MAX
G90
M400
M98 P"0:/sys/abort_check.g"

M291 P"Origen XYZ establecido en la esquina de la pieza." R"PALPADOR 3D - COMPLETADO" S1 T5
