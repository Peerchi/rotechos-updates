; diagnostico.g — foto del estado de la máquina para la sesión de banco (6-oct-2026)
; No mueve nada. Escribe en la consola lo que hace falta para diagnosticar un fallo:
; versión, modo, temperaturas, ventiladores, referencias, sensores, red y calibración.
; Copia la salida de la consola y pégala en el chat junto con el paso que fallaba.
; Todo lo opcional va con exists(): si una clave no está en esta build, sale "?".
echo "--- RotechOS diagnostico ---"
echo "Firmware " ^ boards[0].firmwareVersion ^ " | SD " ^ (exists(global.fwVersion) ? global.fwVersion : "?") ^ " | modo " ^ state.machineMode ^ " | estado " ^ state.status
echo "MCU " ^ (exists(boards[0].mcuTemp) ? boards[0].mcuTemp.current : "?") ^ " C | Vin " ^ (exists(boards[0].vIn) ? boards[0].vIn.current : "?") ^ " V"
echo "Ventiladores AUX1 " ^ (exists(fans[1]) ? fans[1].actualValue : "sin configurar") ^ " | aviso drivers " ^ (exists(sensors.analog[11]) ? sensors.analog[11].lastReading : "?")
echo "Referenciado X/Y/Z " ^ move.axes[0].homed ^ "/" ^ move.axes[1].homed ^ "/" ^ move.axes[2].homed
echo "Maquina X/Y/Z " ^ move.axes[0].machinePosition ^ " / " ^ move.axes[1].machinePosition ^ " / " ^ move.axes[2].machinePosition ^ " | WCS G" ^ (53 + move.workplaceNumber + 1)
echo "Limites X " ^ move.axes[0].max ^ " Y " ^ move.axes[1].max ^ " Z " ^ move.axes[2].min ^ ":" ^ move.axes[2].max
if exists(sensors.gpIn[4]) && exists(sensors.gpIn[1]) && exists(sensors.gpIn[3])
    echo "Sensores X MAX " ^ sensors.gpIn[4].value ^ " | Y MAX " ^ sensors.gpIn[1].value ^ " | Z MAX " ^ sensors.gpIn[3].value
else
    echo "Sensores de homing: sin entradas gpIn 1/3/4 (escudo no cargado)"
echo "Sonda Z " ^ (exists(sensors.probes[0]) ? sensors.probes[0].value[0] : "?")
echo "Husillo " ^ (exists(spindles[0]) ? spindles[0].state ^ " " ^ spindles[0].current ^ " rpm" : "?") ^ " | manual " ^ (exists(global.spindleManual) ? global.spindleManual : "?")
echo "Red " ^ network.interfaces[0].state ^ " " ^ network.interfaces[0].actualIP
echo "LED stopMovement " ^ (exists(ledStrips[0].stopMovement) ? ledStrips[0].stopMovement : "?") ^ " | shieldMask " ^ (exists(global.shieldMask) ? global.shieldMask : "?")
echo "Sensor herramienta Y " ^ (exists(global.tool_sensor_y) ? global.tool_sensor_y : "?") ^ " | sensor-mesa " ^ (exists(global.z_sensor_to_table) ? global.z_sensor_to_table : "?")
; Ampliacion banco nov-2026: solo echo y variables locales, sin G/M ni globals.
echo "shieldMask " ^ (exists(global.shieldMask) ? global.shieldMask : -1) ^ (( !exists(global.shieldMask) || global.shieldMask == -1) ? " SIN GUARDAR" : "")
echo "shieldNoMask " ^ (exists(global.shieldNoMask) ? global.shieldNoMask : "?")
echo "kinematicMode " ^ (exists(global.kinematicMode) ? global.kinematicMode : "?") ^ " | workplaceNumber " ^ move.workplaceNumber
var i = 0
while var.i < #sensors.endstops
    if sensors.endstops[var.i] != null
        echo "endstop " ^ var.i ^ " triggered " ^ sensors.endstops[var.i].triggered
    set var.i = var.i + 1
set var.i = 0
while var.i < 6
    echo "gpIn " ^ var.i ^ " value " ^ (exists(sensors.gpIn[var.i].value) ? sensors.gpIn[var.i].value : "sin configurar")
    set var.i = var.i + 1
set var.i = 0
while var.i < #move.axes
    echo "eje " ^ var.i ^ " homed " ^ move.axes[var.i].homed ^ " microstepping " ^ move.axes[var.i].microstepping.value ^ " interpolated " ^ move.axes[var.i].microstepping.interpolated
    set var.i = var.i + 1
echo "--- fin ---"
