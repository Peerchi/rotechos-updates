; ROTECH OS — Bordeador Inteligente v2.0
; Sin fricción, sin preguntas. Usa el Object Model de RRF.

; 2-oct: leia job.file.name / job.file.min / job.file.max, que NO existen en RRF 3.5.4
; (PrintMonitor.cpp:89-99: job.file solo tiene fileName, size, height...). La macro moria
; en la primera linea con un error de firmware. RRF no calcula el contorno XY del archivo:
; lo calcula la interfaz (boton BORDEADOR, rotechos-bordeador.js). Esta macro recibe el
; contorno por parametros: M98 P"0:/macros/bordeador.g" X<xmin> Y<ymin> I<xmax> J<ymax>
if !exists(param.X) || !exists(param.Y) || !exists(param.I) || !exists(param.J)
    M291 P"Para encuadrar usa el boton BORDEADOR de la interfaz: calcula el contorno del archivo cargado." R"BORDEADOR" S1 T0
    abort "Bordeador: faltan los limites X Y I J (usa el boton BORDEADOR de la interfaz)"

if !move.axes[0].homed || !move.axes[1].homed || !move.axes[2].homed
    M291 P"Los ejes deben tener referencia (Homing) antes de encuadrar." R"BORDEADOR - ERROR" S1 T0
    abort "Bordeador abortado — ejes sin referenciar"

; Seguridad Z: subir a cota MAQUINA segura (cerca del tope), independiente del WCS y del
; grosor del material. Asi despeja clamps altos de verdad (antes subia solo a Z=10 WCS,
; que con Z0 en superficie de material grueso podia NO librar el utillaje).
G90
G53 G0 Z{move.axes[2].max - (exists(global.safe_clearance) ? global.safe_clearance : 10)} F{exists(global.z_raise_speed) ? global.z_raise_speed : 1000}

; Empezar con el flag de aborto limpio (por si quedó de una colisión anterior).
if exists(global.abortRequested)
    set global.abortRequested = false

if param.I <= param.X || param.J <= param.Y
    M291 P"Contorno no valido: el maximo debe ser mayor que el minimo." R"BORDEADOR - ERROR" S1 T0
    abort "Bordeador abortado — contorno no valido"

; Contorno recibido (coordenadas de trabajo, WCS activo)
var xMin = param.X
var xMax = param.I
var yMin = param.Y
var yMax = param.J

; Seguridad: Margen de cortesía (2mm extra por lado)
set var.xMin = var.xMin - 2
set var.xMax = var.xMax + 2
set var.yMin = var.yMin - 2
set var.yMax = var.yMax + 2

M291 P"Encuadrando área de trabajo..." S0 T3

; Velocidad adaptada al modo cinemático activo
var feedXY = exists(global.travel_feed) ? global.travel_feed * 0.45 : 1800
if exists(global.kinematicMode) && global.kinematicMode == 1
    set var.feedXY = exists(global.travel_feed) ? global.travel_feed : 4000

M400                         ; 2-oct: vaciar la cola antes de cambiar la aceleracion (CLAUDE.md §4)
M201 X{exists(global.travel_accel) ? global.travel_accel : 2000} Y{exists(global.travel_accel) ? global.travel_accel : 2000}  ; aceleración de viaje en vacío
G1 X{var.xMin} Y{var.yMin} F{exists(global.travel_feed) ? global.travel_feed : 4000} ; Punto inicio (tempo de viaje unificado)

; Si un final de carrera disparó en el viaje al punto de inicio, abortar antes
; de trazar el rectángulo (M410 cortó el viaje; esto corta la macro).
M98 P"0:/sys/abort_check.g"

; Trazar el rectángulo
G1 X{var.xMax} F{var.feedXY}
M98 P"0:/sys/abort_check.g"
G1 Y{var.yMax} F{var.feedXY}
M98 P"0:/sys/abort_check.g"
G1 X{var.xMin} F{var.feedXY}
M98 P"0:/sys/abort_check.g"
G1 Y{var.yMin} F{var.feedXY}
M98 P"0:/sys/abort_check.g"

; Volver al origen de la pieza (X0 Y0)
G1 X0 Y0 F{exists(global.travel_feed) ? global.travel_feed : 4000}   ; regreso al origen al mismo tempo
M98 P"0:/sys/restore_kinematics.g"  ; restaurar accel del modo activo
M291 P"Encuadre completado. Listo para cortar." S1 T3
