; ═══════════════════════════════════════════════════════════════
; vssc.g — Toggle de VSSC (Variable Spindle Speed Control / anti-chatter)
; Ruta: 0:/macros/vssc.g
;
; Activa/desactiva la oscilación sinusoidal de RPM que corre en daemon.g.
; Parámetros en config.g: vssc_period_ms (periodo) y vssc_variance (amplitud).
; Al DESACTIVAR con el husillo girando, restaura la RPM base para no dejarlo
; congelado en un valor intermedio de la onda.
; ═══════════════════════════════════════════════════════════════

if !exists(global.vssc_on)
    M291 P"Los globals de VSSC no existen (¿config.g desactualizado en la SD?)." R"VSSC" S1 T0
    abort "vssc: config.g sin globals VSSC"

if global.vssc_on
    set global.vssc_on = false
    if spindles[0].state == "forward" && global.vssc_base_rpm > 0
        M568 P0 F{global.vssc_base_rpm}
    M291 P"VSSC DESACTIVADO — RPM fija de nuevo." R"VSSC" S1 T3
else
    ; Sembrar base y reloj ANTES de activar (el daemon ya puede leer en el próximo tick)
    set global.vssc_base_rpm = spindles[0].active
    set global.vssc_t0 = mod(state.upTime, 1000000) * 1000 + state.msUpTime
    set global.vssc_on = true
    M291 P{"VSSC ACTIVADO: RPM oscilando ±" ^ (global.vssc_variance / 2) ^ " (periodo " ^ global.vssc_period_ms ^ "ms). Anti-chatter. Re-ejecuta esta macro para apagarlo."} R"VSSC" S1 T5
