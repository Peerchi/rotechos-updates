; pause.g - Pausa segura e INSTANTÁNEA del trabajo
; IMPORTANTE: NO usar M0 (parada completa), usar M25 (pausa reversible)
; El estado cambia automáticamente en daemon.g cuando state.status = "paused"

; 0. Feedback visual INMEDIATO (elimina el lag de 500ms hasta que daemon.g lo detecta)
M150 R255 U128 B0 P255 F0 S25         ; Naranja sólido brillante (PAUSA)

; Guardar posición XY y perfil cinemático antes de pausar
set global.pause_x = move.axes[0].machinePosition
set global.pause_y = move.axes[1].machinePosition
set global.pause_kinematicMode = global.kinematicMode
; Se lee ANTES del M5 de mas abajo: despues valdria siempre 0 y el husillo no
; volveria a arrancar nunca al reanudar.
if exists(spindles[0].active)
    set global.pause_spindle_active = spindles[0].active
    ; active CONSERVA el ultimo S tras un M5 (M6.g): con el husillo ya parado al
    ; pausar, resume.g lo arrancaba solo. 0 solo si se sabe PARADO (B-H4.3).
    if exists(spindles[0].state)
        if spindles[0].state == "stopped"
            set global.pause_spindle_active = 0

; Persistir posición en disco para restaurar tras power-off (macro centralizada)
M98 P"0:/sys/save_position.g"

; Elevar Z PRIMERO, con el husillo aún girando (mismo orden que stop/cancel): sacar
; la fresa del material cortando evita marcas/atascos de un husillo frenándose dentro.
M98 P"0:/sys/z_safe_raise.g"
T0                            ; asegurar tool activa — M5 se ignora sin ella
M5                            ; apagar spindle

; Forzar SEDA tras pausar: silencio y suavidad durante la inspección (compatible con la
; transición automática del hook de UI, pero aplicada en firmware por si hay desfase temporal).
; set_silk.g canónico vive en sys/. ramp_to_silk.g si existe, si no set_silk.g directo.
if fileexists("0:/sys/ramp_to_silk.g")
    M98 P"0:/sys/ramp_to_silk.g"
else
    M98 P"0:/sys/set_silk.g"

; LEDs se actualizarán automáticamente a naranja (paused) en daemon.g
