; =================================================================
; set_pro.g — Perfil RAYO (RotechOS)
; Rendimiento máximo basado en configuración del usuario
; =================================================================


M400 ; sync movement queue
; JERK DINÁMICO: Recupera los valores de las variables globales
; Mantiene P1 para que el acabado superficial sea perfecto
M566 X{global.pro_jerk_x} Y{global.pro_jerk_y} Z{global.pro_jerk_z} P1
if #move.axes > 3
    M566 A{global.pro_jerk_a} P1

; ACELERACIÓN DINÁMICA: Potencia total para seguir el G-Code
M201 X{global.pro_accel_x} Y{global.pro_accel_y} Z{global.pro_accel_z}
if #move.axes > 3
    M201 A{global.pro_accel_a}

; NOTA: M569 NO se toca aquí. Ver explicación en set_silk.g.
; En BTT Scylla V1.0 con TMC2160, M569 P{n} (incluso solo D) re-inicializa el
; chip y RESETEA la dirección. Para mantener inversiones del user, el chopper
; mode se fija UNA SOLA VEZ en config.g (default D3 StealthChop).

; ESTADO: Seteamos modo 1 (Rayo)
set global.kinematicMode = 1

; INDICADOR LED: Cian sólido intenso = producción/precaución
M150 R0 U255 B255 P255 F0 S25