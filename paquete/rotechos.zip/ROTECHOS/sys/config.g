M98 P"0:/sys/globals.g"              ; Inicializar variables globales de RotechOS (Cerebro)
; =========================================================================================================
; config.g  -  ROTECHOS (V3.2 - MODO CLIENTE WiFi)
; Optimizado para BTT Scylla / RepRapFirmware 3.5.x
; Sistema de Jerarquía Cinemática: Modo SEDA (Manual) vs Modo RAYO (Trabajo)
; =========================================================================================================

; --- CONFIGURACIÓN DE IDENTIDAD Y RED ---
; NOTA: M453 (modo CNC) NO se envía desde esta máquina. El comentario antiguo
;       decia "se envía desde start.g al iniciar trabajo" — es FALSO: 0
;       apariciones de M453 en start.g ni en el resto de macros. La máquina
;       opera en el modo por defecto de RRF, que es FFF (GCodes.cpp:66; el comentario decía
;       «spindle» y era falso: ver C2 del acta 2026-09-26). Si lo metieras aquí
;       causa "module is changing mode" en el arranque del firmware BTT Scylla.
;       (t_028bceef)
M550 P"RotechCNC"                    ; Nombre de la máquina
G90                                  ; Coordenadas absolutas
M555 P2                              ; Compatibilidad Marlin/software externo
M586 P0 S1                           ; Servidor HTTP (Interfaz Web)
M586 P1 S0                           ; Desactivar FTP explícitamente (ahorro memoria y ancho de banda)
M586 P2 S0                           ; Desactivar Telnet explícitamente (ahorro memoria y ancho de banda)

; --- PUERTO SERIE AUXILIAR: reservado para la pantalla RotechOS Touch (BTT TFT70 V3.0) ---
; La pantalla está en desarrollo y NO forma parte de v2026.09 (sin validar en hardware).
; Los pines del puerto auxiliar ya están mapeados en sys/board.txt
; (serial.aux.rxTxPins={D.9,D.8}); esta línea es la que lo habilita.
; S es un CAMPO DE BITS, verificado en el código fuente de RRF 3.5
; (StringParser.h: checksumRequired = arg & 1, crcRequired = arg & 4;
;  GCodes2.cpp caso 575: rawMode = val & 2):
;     bit 0 (1) = exige checksum   bit 1 (2) = modo raw   bit 2 (4) = exige CRC
; S2 = modo raw SIN checksum. Es el correcto: la TFT manda G-code sin checksum
; (command_checksum:0 en su config.ini) y el modo raw hace que RRF termine cada
; respuesta con "ok", que es lo que el firmware de la pantalla espera.
; NO usar S1: exige un checksum que la pantalla nunca envía. El "M575 P1 S1
; B115200" que aparece en documentos viejos del repo es incorrecto y nunca se
; validó (ver "ROTECHOS TOUCH/README.md").
; B115200 concuerda con serial_port:P1:6 del config.ini de la pantalla.
M575 P1 S2 B115200                   ; Puerto auxiliar P1 → pantalla RotechOS Touch

; --- DRIVERS Y ASIGNACIÓN DE EJES ---
; S1 = Dirección positiva (ajustar según montaje mecánico en config-machine.g).
; Driver 0: cable STEP de fábrica puede venir sano o quemado según unidad. La
; per-máquina se registra en config-machine.g como `; rotech-banned-drivers=P0:...`;
; por defecto (instalación nueva, sin calibrar) está VACÍA y P0 se considera sano.
; Si esta unidad tiene P0 quemado, config-machine.g lo veta y reasigna X→3.
; Conector físico del motor X, en algunas unidades, va al driver 3 de la placa.
M569 P0 S1                         ; Driver 0: dirección por defecto — sane o vetada per-máquina en config-machine.g
M569 P1 S1 D3 V200               ; Driver 1: Eje Y — StealthChop en reposo, SpreadCycle automático >200 mm/min
M569 P2 S1 D3 V150               ; Driver 2: Eje Z — StealthChop en reposo, SpreadCycle automático >150 mm/min
M569 P3 S1 D3 V200               ; Driver 3: Eje X — StealthChop en reposo, SpreadCycle automático >200 mm/min
; NOTA: D3+V (modo híbrido) = silencioso en parado/jog lento (StealthChop) y par pleno
; al cortar (SpreadCycle automático por encima del umbral V). Configurado UNA SOLA VEZ
; aquí — en BTT Scylla V1.0, llamar M569 en runtime resetea el TMC2160 e invierte dirección.
; El sentido del eje puede invertirse desde CONFIGURACIÓN → Motores (escribe en
; config-machine.g y exige reinicio de la placa).

; --- CALIBRACIÓN DE RESISTENCIAS DE SENSADO DE DRIVERS (OBLIGATORIO BTT SCYLLA) ---
; BTT Scylla V1.0 sólo tiene 4 drivers TMC2160 (P0–P3). NO declarar P4 (no existe
; en hardware y provoca "Driver 4 not present" que puede abortar config.g)
; VERIFICADO (usuario, jun-2026): Rsense = 0.05Ω — R0.05 es CORRECTO.
;   El TMC2160 con esta Rsense soporta ~3.1A RMS continuos: de ahí el tope de
;   3100 mA que la UI impone en CONFIGURACIÓN → Motores (HW_LIMITS).
; Drivers ASIGNADOS por M584 abajo: Y→1, Z→2, X→3. Driver 0 sin uso (no se declara).
M569.9 P0.1 R0.05 S10
M569.9 P0.2 R0.05 S10
M569.9 P0.3 R0.05 S10

M584 X3 Y1 Z2                        ; Mapeo: X→driver3, Y→driver1, Z→driver2 (A eliminado)

; --- PASOS Y CORRIENTE — FALLBACKS DE FÁBRICA, NO DE UNA MÁQUINA REAL ---
; Estos valores NO son los de ninguna máquina concreta: son un consenso
; conservador que sólo se aplica si config-machine.g no existe (instalación
; nueva, sin calibrar). El criterio es: si alguien los usa sin calibrar, que
; la máquina se mueva poco y despacio, NUNCA que se estampe.
; config-machine.g los SOBREESCRIBE con la calibración real en el siguiente
; bloque if fileexists(…) — ver más abajo.
;
; ¿Por qué pasos/mm pequeños? Un paso/mm menor del real hace que el motor
; recorra MENOS distancia de la pedida (jog perezoso, no agresivo). Es la
; dirección segura: el operario lo nota como "va lento" y calibra, no como
; "se estampó". 80 pasos/mm = 1.8°·200·16·1/2mm ≈ correa T2.5 + polea 20T;
; cubre fresadoras pequeñas con holgura. Por debajo de la mayoría de
; máquinas reales (160–400 pasos/mm), nunca por encima.
; ¿Por qué corriente baja? 800 mA RMS está bien POR ENCIMA del suelo de
; integridad_check (200 mA, un driver sin fuerza no moverá nada) y muy POR
; DEBAJO del techo TMC2160 (3100 mA operativo, 4700 mA pico). Un NEMA 23
; a 800 mA no quema drivers ni motores, incluso si el operario olvida
; bajarla. Si la máquina real admite más, config-machine.g lo sube.
M350 X16 Y16 Z16 I1                   ; x16 interpolado a 256 (suavidad + silencio) — igual en casi toda Scylla V1.0
M92 X80 Y80 Z400                     ; Pasos por mm — FALLBACK conservador (instalación sin calibrar)
M906 X800 Y800 Z800 I40              ; Corrientes RMS — FALLBACK conservador (instalación sin calibrar)

; --- LÍMITES INICIALES (MODO SEDA POR DEFECTO) ---
; Estos valores se sobrescribirán al entrar en Modo RAYO o mediante la UI
; (o, si config-machine.g existe, al cargar el perfil per-máquina más abajo).
; FALLBACK DE FÁBRICA: aceleración/velocidad/jerk BAJOS para que un jog
; sin calibrar no sea agresivo. config-machine.g los sube a los valores
; reales de la máquina (ver set_silk.g / set_pro.g para el modo operativo).
M201 X10 Y10 Z5                      ; Aceleraciones (mm/s^2) — FALLBACK conservador
M203 X600 Y600 Z300                  ; Velocidades máx (mm/min) — FALLBACK conservador
M566 X3 Y3 Z1 P1                     ; Jerk (mm/min) — FALLBACK conservador (P1 = Junction Deviation)
; Input Shaping: cancela el "ringing" (microvibración al acelerar/parar) → el movimiento
; parece FLOTAR. Es el mayor salto hacia la sensación Bambu, y es config puro.
; OJO — F40 es una ESTIMACIÓN inicial: lo correcto es medir tu resonancia (acelerómetro, M956)
;   y subir/bajar F. Si tu build RRF-STM32 no soporta M593, se ignora (sin daño).
; CONFIGURACIÓN desde la interfaz: pestaña INPUT SHAPING (rotechos-config-modal.js:3787,
; MACHINE_TABS incluye 'inputshaping'). Se persiste a config-machine.g.
M593 P"zvd" F40                      ; shaper ZVD a 40 Hz (F40 = estimación inicial hasta medir resonancia con M956)

; --- GESTIÓN DE ENERGÍA Y SEGURIDAD ---
; Z retiene peso del spindle por gravedad (tornillo NO autoblocante).
; M84 S86400 = desactivar timeout (1 día) — Z NUNCA debe liberarse automáticamente.
; X/Y se liberan inmediatamente con M18 y tras jog vía SM.busy timeout del JS.
M84 S86400                           ; Desactivar timeout (1 día) — Z siempre energizado
M18 X Y                              ; Soltar X/Y inmediatamente al arrancar (ahorro energía)

; --- LÍMITES DEL ÁREA DE TRABAJO — FALLBACK CONSERVADOR ---
; Estos límites son GENÉRICOS, no los de una máquina concreta. El
; rationale: si config-machine.g no existe (instalación nueva, sin
; calibrar), los soft-limits DEBEN ser más pequeños que el área real de
; cualquier fresadora razonable. Un cuadro de 200×200×25 mm centrado
; cabe en TODA Scylla V1.0 del mundo. Así, si la soft-limit se
; dispara, el motor todavía tiene bastidor por delante y no se estampa.
; config-machine.g SOBREESCRIBE estos valores con el área real (Xmax,
; Ymax, Zmax) en el siguiente if fileexists(…).
; REGLA: M208 aquí es la CERRADURA, no el LÍMITE. El operario mete la
; llave (calibra) y el cuadro crece hasta sus dimensiones reales.
M208 X-100 Y-100 Z-25 S1             ; Mínimos — FALLBACK conservador (caja 200×200×25 mm centrada)
M208 X100 Y100 Z0 S0                ; Máximos — FALLBACK conservador (caja 200×200×25 mm centrada)
; M564 (enforcement de homing + soft limits) se aplica MÁS ABAJO, tras declarar
; los globals, para poder derivar S de global.softLimitsOn (fuente única de verdad).

; --- ENDSTOPS (SENSORES DE FINAL DE CARRERA) ---
; Y, Z, X: sin endstops permanentes — gestionados como GPIO/M581. Se activan temporalmente en homing.
M574 X0 S1                           ; Asegurar X sin endstop permanente
M574 Y0 S1                           ; Asegurar Y sin endstop permanente
M574 Z0 S1                           ; Asegurar Z sin endstop permanente

; --- CONFIGURACIÓN DE ENTRADAS GPIO Y TRIGGERS DE EMERGENCIA M581 (ESCUDO) ---
; 28-sep (R2): el escudo se carga DESPUÉS de config-machine.g (más abajo), porque los lados que
; tienen sensor (global.shieldMask) son de cada máquina y viven allí.

; --- SONDA DE ALTURA (PROBE / TOUCH PLATE) ---
; Sonda Z = PULSADOR DE CONTACTO mecánico (NO inductivo). Pin E.7 (PE7) en conector Tool.
; Cableado: COMÚN del interruptor a GND (NO a E.7); jumper de placa en NPN con pull-up.
;   ^ = pull-up habilitado en RRF (redundante con el de placa, pero inocuo).
;   ! = INVERTIR lógica: en reposo E.7=HIGH (libre, pull-up); al pulsar cierra a GND -> LOW = DISPARADO.
;   La sonda inductiva vieja (D.15 / A-MIN) hacía lo contrario (disparaba en HIGH); de ahí la inversión con !.
; H5 (dive height 5 mm), F120 (velocidad de sondeo en mm/min), T6000 (timeout 6 s).
; AVISO OPERATIVO: aunque F120 coincide con la inductiva anterior, mantener esta VELOCIDAD
; CONSERVADORA porque ahora es un CONTACTO físico: un descenso más agresivo podría dañar
; la punta o falsear el contacto (rebote/salto). Si en banco se mide que un valor mayor es
; seguro (sin rebote y sin desgaste de la punta), subirlo en config-machine.g y validar.
; Las macros usan global.probe_speed_* (probe_speed_fast, probe_speed_slow,
; probe_accel_z, probe_timeout_ms y touchplate_thickness); se ajustan desde
; CONFIGURACIÓN → SONDA Z (rotechos-config-modal.js:710-806 + 1687-1860).
; La UI los persiste en config-machine.g tras calibrar el palpado en banco.
; Sensor SAC (z_sensor_to_table) en daemon.g reutiliza ESTE MISMO pulsador en E.7.
M558 P5 C"^!E.7" H5 F120 T6000
G31 P500 X0 Y0 Z0                    ; Offset de la sonda — fallback en origen; el valor real se calibra en banco y persiste desde CONFIGURACIÓN → SONDA Z (probe tab vía cfgFieldsRunCustom 'PROBE')

; --- VENTILADORES DE LA ELECTRÓNICA (AUX1) — 6-oct-2026, PENDIENTE BANCO ---
; Dos ventiladores en AUX1 (PA5 → A.5, HARDWARE_SCYLLA_V1_OFICIAL.md §5). AUX1 da la tensión de
; V-MOS (24/48 V, 3 A): los ventiladores tienen que ser de esa tensión. Termostáticos: se encienden
; cuando el MCU llega a T °C o un TMC2160 avisa de sobretemperatura (sensor "drivers": 0 normal,
; 100 aviso, 150 apagado). El MCU avisa a 55 °C (daemon_tick.g): T va por debajo. El umbral lo
; ajusta CONFIGURACIÓN → VENTILADORES (`M106 P1 T` en config-machine.g, que se carga después).
; Fuente RRF STM32 v3.5.4: Pins_STM32.h:72 (HAS_CPU_TEMP_SENSOR), TemperatureSensor.cpp:294-317.
; Un M308 que falle da error y config.g sigue: por eso el H del driver va aparte y con exists().
M308 S10 Y"mcu-temp" A"MCU"
M308 S11 Y"drivers" A"Drivers"
M950 F1 C"A.5"                       ; F1, no F0: el T0 (husillo) usa el F0 y un M106/M107 del CAM no los toca
M106 P1 C"Electronica" H10 T45       ; Fallback 45 °C
if exists(sensors.analog[11])
    M106 P1 H10:11

; --- PERFIL DE MÁQUINA (calibración per-máquina — NO se actualiza por OTA) ---
; config-machine.g SOBRESCRIBE los valores genéricos de arriba (M92/M906/M208/
; M558/G31 y los globals per-máquina) con la calibración real de ESTA fresadora.
; Así una OTA puede reescribir config.g entero sin perder la calibración. Si el
; archivo no existe (máquina nueva sin calibrar), config.g sigue con sus
; fallbacks conservadores de arriba (pasos bajos, corrientes bajas, área pequeña
; centrada) hasta que el operario calibre. t_9b49c0a4 añade M558 a esta lista.
; OJO: aquí NO va M569 (re-ejecutarlo resetea el TMC2160) — eso queda solo arriba.
if fileexists("0:/sys/config-machine.g")
    M98 P"0:/sys/config-machine.g"

; 3-oct: tope de velocidad de palpado = la F de M558 que queda tras config-machine.g. G38.x
; ignora su propio F y usa la de M558; probe_speed.g la cambia antes de cada palpado sin pasar
; nunca de este tope (ver probe_speed.g).
if exists(sensors.probes[0]) && exists(global.probeSpeedCap)
    set global.probeSpeedCap = sensors.probes[0].speeds[0]

; Escudo de hardware (M581) con los lados de ESTA máquina (global.shieldMask).
M98 P"0:/sys/recover_triggers.g"     ; Cargar escudo de hardware centralizado

; --- CONTROL DEL SPINDLE (MOTOR PRINCIPAL) ---
M950 R0 C"B.1+C.5+B.0" Q500 L6000:24000   ; VFD/Relé — Q500Hz, rango 6000-24000 RPM
M563 P0 S"Spindle" R0               ; Herramienta 0 con husillo (sin heater)
T0                                   ; Seleccionar Herramienta 0 por defecto
M5                                   ; Asegurar motor apagado al inicio

; --- SISTEMA DE ILUMINACIÓN LED (ROTECH FEEDBACK) ---
M950 E0 C"D.6" T1                    ; Pin D.6 para Neopixels (WS2812B)
M150 E0 R0 U0 B60 S25 F1              ; Azul tenue pulsante = arrancando (rojo era confuso: rojo=alarma)

; --- INICIALIZACIÓN DE VARIABLES GLOBALES (CEREBRO ROTECHOS) ---
; --- ENFORCEMENT M564 (deriva H y S de globals) ---
M564 H{global.requireHoming ? 1 : 0} S{global.softLimitsOn ? 1 : 0}   ; homing y soft limits derivados de globals (mismo patrón que homeall.g:84)

; Detección 24/48 V por BANDA (V13, 15-sep): solo una lectura dentro de la banda de
; 24 V fija 24 V. Antes, cualquier lectura < 36 V lo hacía, y una fuente de 48 V que
; arrancaba caída rebajaba a la mitad el chequeo de integridad y M911 (~17,5 V).
; Ahora esa lectura deja 48 V: integrity_check salta y start.g no deja arrancar.
; 3-oct: exists() delante. vIn y mcuTemp solo existen si la build tiene el monitor
; (Platform.cpp:263-282, HAS_VOLTAGE_MONITOR / HAS_CPU_TEMP_SENSOR); si la de la Scylla no lo
; tuviera, leerlos sin más es un error de expresión, y ese error aborta config.g entero aquí
; mismo, antes del WiFi (GCodes.cpp:686-691). exists() da false en vez de error
; (ObjectModel.cpp:1275-1278). PENDIENTE BANCO: echo boards[0].vIn.current.
if exists(boards[0].vIn) && boards[0].vIn.current >= 18 && boards[0].vIn.current <= 30
    set global.psu_voltage = 24

; --- RESTAURAR PARÁMETROS RAYO GUARDADOS (si existen) ---
if fileexists("0:/sys/pro_params_saved.g")
    M98 P"0:/sys/pro_params_saved.g"

; --- RED Y CONECTIVIDAD ---
; M564 se declara en la sección de globals (deriva S de global.softLimitsOn) — no duplicar aquí
; Credenciales WiFi (M587 cliente + M589 AP). El guard permite BORRAR el archivo
; de la SD tras el primer arranque (recomendado en wifi-passwords.g.example:
; M587/M589 ya persisten en el módulo WiFi) sin romper el arranque de config.g.
if fileexists("0:/sys/wifi-passwords.g")
    M98 P"wifi-passwords.g"
M552 S1                              ; Activar Wi-Fi en modo cliente (conexión asíncrona y limpia sin delays)

; --- ESTADO DE PILLS DRO (override UI) ---
; Formato POR LADO: <eje>:<minOn>|<maxOn>:<typeMin>|<typeMax>:<trigger_value>
; - minOn|maxOn     → 1/0 por lado (checkbox Min y Max del modal → Finales)
; - typeMin|typeMax → nc/no por lado (tipo físico del sensor; afecta a M574)
; - trigger_value   → (opcional) 0 ó 1: qué valor lee el MCU cuando el sensor está activo.
;                     Si no se especifica, se deriva del tipo (NC→1, NO→0).
;                     Útil para entradas opto-aisladas que invierten la señal.
; (Compat: el parser también entiende el formato antiguo "X:on:nc:1" como sensor en MAX.)
;
; X: NPN NC inductivo en C.6 (conector X-MAX). En reposo lee 0 (LOW), al detectar metal lee 1 (HIGH).
; Y/Z: sin sensor → mantener off para evitar falsos rojos por pull-up flotante.
; rotech-pills=X:0|1:nc|nc:1,Y:0|1:nc|nc:1,Z:0|1:nc|nc:1,A:0|0:nc|nc:1
; rotech-triggers=X:5:4:Y:0:1:Z:2:3
; rotech-sac=true                    ; Cambio asistido (SAC) ON/OFF — SSOT UI (la edita rotechos.js)
; rotech-led=128                     ; Brillo LED RGB 1-255 — SSOT UI (la edita rotechos.js)
; rotech-coordmode=WCS               ; Modo DRO WCS/MCS — SSOT UI (la edita rotechos.js)
; rotech-mist=0                     ; Neblina disponible 0/1 — SSOT UI (CONFIGURACIÓN → Husillo)
; rotech-cool=0                     ; Refrigerante disponible 0/1 — SSOT UI (CONFIGURACIÓN → Husillo)

; --- CACHE: EXISTENCIA DEL HOOK USER-DAEMON.G (LEÍDO UNA VEZ AL ARRANQUE) ---
; Antes: daemon.g hacia fileexists("0:/sys/user-daemon.g") cada tick (cada 0.5-1s),
; una lectura SD continua que compite con el job. Ahora se cachea en este global
; al boot; daemon.g solo lee el global (1 comparacion en RAM, 0 SD).
; Trade-off documentado: si el operario crea/borra user-daemon.g en runtime, el
; cambio no se aplica hasta el proximo reinicio. Aceptable: el archivo es un hook
; estatico por diseno (ver comentario en daemon.g).
if fileexists("0:/sys/user-daemon.g")
    set global.userDaemonPresent = true
else
    set global.userDaemonPresent = false

; --- CARGA FINAL Y ACTIVACIÓN DE MODO SEDA ---
; M501 DESACTIVADO: config-override.g está vacío y M501 es un vector de bugs
; (puede sobrescribir M208/M564/M906 guardados por M500 accidental, anulando
; los valores configurados arriba). Re-activar solo si se usa config-override.g
; intencionadamente con valores específicos.
; M501                               ; Cargar parámetros guardados (M500)
M98 P"set_silk.g"                    ; Forzar arranque en MODO SEDA

; --- RESTAURAR EL CERO DE PIEZA DE LA ÚLTIMA SESIÓN ---
; 26-sep (C5): solo el cero de pieza (G10 L2). Ya NO se restaura la posición de máquina con
; G92, que daba los ejes por referenciados en una posición que podía ser falsa: tras encender
; hay que hacer HOME. El saved_position.g viejo (con su G92) ya no se ejecuta.
if fileexists("0:/sys/saved_offsets.g")
    M98 P"0:/sys/saved_offsets.g"
    echo "Cero de pieza restaurado desde la última sesión (haz HOME antes de mover)"

; --- VALIDACIÓN DE COHERENCIA (BOOT INTEGRITY CHECK) ---
; Verifica límites, corrientes, RPM, globals y estado de drivers.
; Si encuentra incoherencias, muestra M291 bloqueante y deja global.integrityOk = false.
; start.g aborta el mecanizado mientras integrityOk = false.
if fileexists("0:/sys/integrity_check.g")
    M98 P"0:/sys/integrity_check.g"

; Protección ante caída de tensión (48V nominal → disparo si baja de 35V)
; Fuente Mean Well LRS-350-48 (48V). Umbrales: S35 dispara el guardado de emergencia,
; R40 permite reanudar al recuperar tensión estable.
; M911: protección de caída de tensión — solo comandos inline críticos.
; NO usar M98 (cargar macro de SD consume ms preciados de los condensadores).
; El LED y restauración SEDA se aplican al volver la energía vía start/cancel.
; ORDEN: Apagar spindle PRIMERO (consume pocos ms), luego elevar Z con la energía restante.
; Mover Z con spindle girando agota los condensadores antes de poder parar el husillo.
; NOTA: El escritura inline a saved_position.g dentro de M911 P"..." requiere
; escapado de comillas conflictivo (""file"") y consumiría ms críticos de
; condensadores. La estrategia actual es: daemon.g guarda cada 15s durante
; processing/resuming (suficiente granularidad ante caída de tensión).
; ¡IMPORTANTE! Los comandos de P"..." se SEPARAN POR ESPACIOS, NO por ';'. Un ';'
; se interpreta como comentario al ejecutar la secuencia → comentaría TODO lo que
; viene detrás (sintaxis oficial RRF: P"M913 X0 Y0 G91 M83 G1 Z3 E-5 F1000").
M911 S{global.psu_voltage * global.power_alert_min} R{global.psu_voltage * global.power_alert_err} P"T0 M5 M913 X0 Y0 G91 G1 Z5 F2000 G90"   ; umbrales de PLR configurables derivados de psu_voltage

; M453 (modo CNC) — NO se envía NUNCA desde esta máquina.
; Razón: el comentario histórico decía "se envía desde el JS al iniciar
; trabajo", pero es FALSO: 0 apariciones en ROTECHOS/www/js, 0 en macros,
; 0 en start.g — solo aparece en comentarios de config.g. La máquina
; funciona con el modo por defecto de RRF (FFF, no «spindle»: GCodes.cpp:66) y nunca entra
; en modo CNC explícito. Además, incluir M453 en config.g provoca
; "module is changing mode" en la BTT Scylla (verificado jul-2026).
; Si en el futuro se quisiera modo CNC persistente, el camino es por
; separado (ver t_028bceef): un M453 explícito al final de config.g con
; manejo del error, o un reset de placa. NO en arranque silencioso.

echo "═══════════════════════════════════"
echo "  RotechOS V3.2 — SISTEMA LISTO"
echo "  MCU: " , (exists(boards[0].mcuTemp) ? boards[0].mcuTemp.current : "?") , "°C  |  Vin: " , (exists(boards[0].vIn) ? boards[0].vIn.current : "?") , "V"
echo "═══════════════════════════════════"
