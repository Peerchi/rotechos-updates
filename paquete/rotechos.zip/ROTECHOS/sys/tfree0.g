; tfree0.g - Liberar herramienta T0
; En CNC con una sola herramienta, no se requiere accion