; sys/spindle_ramp_wait.g
; Espera proporcional para que el husillo alcance las RPM de consigna

if exists(global.spindle_ramp_time)
    G4 P{max(300, ceil(global.spindle_ramp_time * (spindles[0].active / spindles[0].max) * 1.05))}
else
    G4 P1500                      ; fallback si no existe el global
