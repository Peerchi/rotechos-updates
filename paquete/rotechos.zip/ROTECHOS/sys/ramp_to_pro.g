; =================================================================
; ramp_to_pro.g — Transición suave de SEDA a RAYO (RotechOS)
; =================================================================
; Aumenta gradualmente la aceleración y el jerk para evitar el "golpe"
; mecánico/acústico al pasar de la cinemática suave a la de producción.

; Verificamos que no estemos ya en modo RAYO (1) para evitar rampa innecesaria
if global.kinematicMode == 1
    M99

M400 ; sync planner queue before ramp
; Configuramos la rampa
var steps = 15                  ; Número de pasos de interpolación
var delay_ms = 40               ; Tiempo entre pasos en ms (total = 600ms)

; Cálculos de los incrementos por paso (Delta / Pasos)
var step_accel_x = (global.pro_accel_x - global.silk_accel_x) / var.steps
var step_accel_y = (global.pro_accel_y - global.silk_accel_y) / var.steps
var step_accel_z = (global.pro_accel_z - global.silk_accel_z) / var.steps
var step_accel_a = 0.0

var step_jerk_x = (global.pro_jerk_x - global.silk_jerk_x) / var.steps
var step_jerk_y = (global.pro_jerk_y - global.silk_jerk_y) / var.steps
var step_jerk_z = (global.pro_jerk_z - global.silk_jerk_z) / var.steps
var step_jerk_a = 0.0

if #move.axes > 3
    set var.step_accel_a = (global.pro_accel_a - global.silk_accel_a) / var.steps
    set var.step_jerk_a = (global.pro_jerk_a - global.silk_jerk_a) / var.steps

; Bucle de transición gradual
while iterations < var.steps
    ; Aplicamos los valores incrementales
    if #move.axes > 3
        M201 X{global.silk_accel_x + (var.step_accel_x * (iterations + 1))} Y{global.silk_accel_y + (var.step_accel_y * (iterations + 1))}
        M201 Z{global.silk_accel_z + (var.step_accel_z * (iterations + 1))} A{global.silk_accel_a + (var.step_accel_a * (iterations + 1))}
        M566 X{global.silk_jerk_x + (var.step_jerk_x * (iterations + 1))} Y{global.silk_jerk_y + (var.step_jerk_y * (iterations + 1))} P1
        M566 Z{global.silk_jerk_z + (var.step_jerk_z * (iterations + 1))} A{global.silk_jerk_a + (var.step_jerk_a * (iterations + 1))} P1
    else
        M201 X{global.silk_accel_x + (var.step_accel_x * (iterations + 1))} Y{global.silk_accel_y + (var.step_accel_y * (iterations + 1))} Z{global.silk_accel_z + (var.step_accel_z * (iterations + 1))}
        M566 X{global.silk_jerk_x + (var.step_jerk_x * (iterations + 1))} Y{global.silk_jerk_y + (var.step_jerk_y * (iterations + 1))} Z{global.silk_jerk_z + (var.step_jerk_z * (iterations + 1))} P1
    
    ; Pequeña pausa para suavizar la rampa
    G4 P{var.delay_ms}

; Al finalizar, llamamos a set_pro.g SOLO si no estábamos ya en RAYO. El check
; inicial (líneas 8-9) hace M99 si ya estamos, pero set_pro.g reaplica M201 de
; golpe — con kinematicMode==1, los valores ya son los correctos, así que esta
; llamada es trabajo innecesario (~1ms de latencia).
if global.kinematicMode != 1
    M98 P"0:/sys/set_pro.g"
