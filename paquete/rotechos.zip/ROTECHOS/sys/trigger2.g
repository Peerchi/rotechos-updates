; trigger2.g — Escudo de Hardware: Parada de emergencia por final de carrera
; Ejecutado automáticamente por el firmware cuando un M581 T2 se dispara
; NO depende del WiFi ni del JavaScript. La parada de movimiento no es inmediata.
;
; REVISIÓN 4-nov-2026 — DISEÑO Y BANCO PENDIENTES, sin cambio de comportamiento:
; RRF 3.5.4 enumera M410 como pendiente. M25 requiere trabajo y puede esperar si el
; canal de archivo ejecuta una macro no reiniciable; T0 espera movimiento/bloqueo.
; La bandera cooperativa no corta el G1 en curso. M5 y la elevación pueden demorarse.
; No asumir que segmentar o usar M112 conserva posición, husillo o recuperación.
; Decidir entre paro controlado y parada de emergencia con pérdida de referencia,
; incluyendo accionamiento del husillo y retirada de Z; validar en la placa y versión
; reales antes de cambiar esta secuencia. Comprobar cableado y efecto de la seta
; en cada máquina; no suponer que actúa mediante un circuito independiente.
; Banco instrumentado: registrar flanco, velocidad, movimiento y salida del husillo;
; medir latencia y distancia hasta parada, sin herramienta ni pieza y con resguardo.
; Cubrir jog largo, macro M98, G28, trabajo SD y macro no reiniciable dentro del
; trabajo; probar cada sentido/eje, velocidades y carga representativas, y repetición.
; Antes del ensayo acordar límites máximos de distancia/tiempo y condición segura de Z;
; fallar si se superan, si continúa otra fase o si la salida del husillo no es segura.
; Registrar firmware/binario, configuración, resultados y método de recuperación.


; 1. (5-oct) El LED rojo va DESPUÉS de parar: si la tira no va por DMA, M150 espera a que la
; máquina se pare (LedStripManager.cpp:142-148) y el trabajo seguía cortando. Mismo arreglo que
; trigger3.g (A6). PENDIENTE BANCO.

; 2. Parada inmediata del trabajo.
; 26-sep: RRF 3.5.4 NO implementa M410 (src/BugList.txt: «Implement M410 quick stop»); da
; «Command is not supported» como AVISO, la macro sigue y la cola de movimiento TAMBIÉN: el
; trabajo seguía cortando, con el husillo apagado por el M5 de abajo, hasta el M25 del
; daemon. Un M25 desde este canal hace la pausa asíncrona (GCodes2.cpp, case 25 →
; DoAsynchronousPause), la misma de un trigger T1: descarta la cola y ejecuta pause.g.
; Fuera de un trabajo (jog, macro) no hay nada que pausar: ahí solo para la seta o el PARO.
; PENDIENTE BANCO (H5.1).
; 17-oct (A3/N-H1): la bandera de aborto va lo PRIMERO. Es una asignación y no espera a nada;
; todo lo que viene detrás sí puede esperar. El T0 pide el bloqueo de movimiento y espera a que
; la máquina pare (GCodes2.cpp, HandleTcode → LockCurrentMovementSystemAndWaitForStandstill), y
; durante un G28 ese bloqueo lo tiene el HOME hasta que acaba (G28 lo toma y UnlockAll conserva
; los recursos del nivel anterior). Con la bandera detrás del T0, el HOME no se enteraba del
; disparo hasta haber terminado. Ahora la ve en su siguiente sys/abort_check.g, aborta, suelta
; el bloqueo, y este fichero sigue (M5, subir Z, SEDA).
; Para las MACROS (M98) y el HOME: M25 no los pausa (solo pausa trabajos de SD).
if {exists(global.abortRequested)}
    set global.abortRequested = true
if state.status == "processing"
    M25
; El T0 se queda donde estaba, a propósito: al esperar a que la máquina pare, el M5 de detrás
; llega con el movimiento ya parado y no se encola (GCodeQueue::ShouldQueueMCode, case 5), y la
; fresa no se para mientras el trabajo aún avanza. M5 sin herramienta apagaría igual todos los
; husillos (GCodes2.cpp, case 5); lo que hace falta del T0 es esa espera.
T0                                   ; Esperar a que la máquina pare (y asegurar tool activa)
M5                                   ; Deshabilitar husillo
if {exists(global.emergencyStopJob)}
    set global.emergencyStopJob = true
M150 R255 U0 B0 P255 F0 S25          ; LEDs rojo (F0 = enviar ya; F es «vienen más datos», no parpadeo: con F10 no se veía)

; 3. Elevar Z para separar herramienta de la pieza (SÓLO SI HAY ESPACIO)
; El tope superior es Z0. Si estamos a menos de homing_backoff_xy, no subimos para evitar choque mecánico.
; (homing_backoff_xy se REUTILIZA como distancia de salto Z a propósito; exists() por si config.g
; abortó antes de cargar globals — la parada M410/M5 de arriba ya ocurrió en ese caso.)
if {move.axes[2].homed && exists(global.homing_backoff_xy) && exists(global.z_raise_speed) && move.axes[2].machinePosition < (0 - global.homing_backoff_xy)}
    G91                                  ; Coordenadas relativas
    G1 Z{global.homing_backoff_xy} F{global.z_raise_speed} ; Subir Z a velocidad segura
    G90                                  ; Volver a coordenadas absolutas
else
    echo "Aviso: Z demasiado alto para elevación de seguridad. Movimiento omitido."

; 4. Restaurar modo SEDA leyendo los valores de los globals (no fijos).
; ANTES usaba M201 X80 Y80 Z30 y M566 X30 Y30 Z10 fijos, pero el operario podía
; haber tuneado silk_accel_x/y/z y silk_jerk_x/y/z — los fijos anulaban su
; calibración. Ahora se leen los globals para mantener consistencia con el
; resto del sistema. Mantener P1 (Junction Deviation) como en el resto del código.
; Cambio auditoría 2026-07-04: ANTES se aplicaba M201/M566 DIRECTOS (salto audible
; del TMC2160 si la máquina estaba en RAYO). Ahora se delega en ramp_to_silk.g
; (15 pasos × 40 ms = 600 ms), igual que stop.g/cancel.g/pause.g, para evitar
; el "zumbido/clac". set_silk.g hace M150+kinematicMode, efectos inocuos
; (trigger2.g reaplica lo suyo justo después en líneas 48 y 45). La excepción
; "no llamar macros anidados" se relajó para que trigger2.g use la misma
; abstracción que el resto del firmware; alternativa inline (replicar el
; bucle de 15 iteraciones) sería más larga y propensa a drift. Fallback inline
; solo si ramp_to_silk.g no existe (rotura de SD improbable).
if {exists(global.silk_accel_x)}
    M400
    if {fileexists("0:/sys/ramp_to_silk.g")}
        M98 P"0:/sys/ramp_to_silk.g"
    elif {fileexists("0:/sys/set_silk.g")}
        M98 P"0:/sys/set_silk.g"
    else
        ; Fallback inline (sin rampa) si los macros no existen
        M201 X{global.silk_accel_x} Y{global.silk_accel_y} Z{global.silk_accel_z}
        M566 X{global.silk_jerk_x} Y{global.silk_jerk_y} Z{global.silk_jerk_z} P1
else
    ; Fallback si los globals no existen (arranque con config.g fallido)
    M201 X80 Y80 Z30
    M566 X30 Y30 Z10 P1
set global.kinematicMode = 0         ; Actualizar variable global (0 = SEDA)

; 5. Restaurar LEDs a color SEDA (confirma visualmente que la alarma está resuelta)
M150 R0 U0 B255 P80 F0 S25           ; Azul = modo SEDA activo (F0: ver arriba)

; 6. Identificar qué sensor disparó el trigger y enviar mensaje
; 28-sep (R2): solo cuentan los lados con sensor (global.shieldMask, ver globals.g). Un lado sin
; sensor lee 1 siempre por el pull-up y se llevaba el nombre del disparo (p. ej. «X MIN» cuando
; había saltado Y MIN, que se mira después).
var shM = 63
if {exists(global.shieldMask) && global.shieldMask >= 0 && global.shieldMask <= 63 && floor(global.shieldMask) == global.shieldMask}
    set var.shM = global.shieldMask
elif {exists(global.shieldMask) && global.shieldMask == -1}
    ; 11-nov: -1 = sin guardar. Mismos lados que el fallback de antes (los tres MAX = 26):
    ; con 63, un lado sin sensor lee 1 por el pull-up y bloquearia todo. start.g ya niega el trabajo.
    set var.shM = 26
var shNo = 0
if {exists(global.shieldNoMask)}
    set var.shNo = global.shieldNoMask
var sensor_name = "Desconocido"
var msg = "Revisa la máquina antes de continuar."

if {mod(floor(var.shM / 16), 2) == 1 && sensors.gpIn[4] != null && sensors.gpIn[4].value == (mod(floor(var.shNo / 16), 2) == 1 ? 0 : 1)}
    set var.sensor_name = "X MAX"
elif {mod(floor(var.shM / 32), 2) == 1 && sensors.gpIn[5] != null && sensors.gpIn[5].value == (mod(floor(var.shNo / 32), 2) == 1 ? 0 : 1)}
    set var.sensor_name = "X MIN"
elif {mod(floor(var.shM / 2), 2) == 1 && sensors.gpIn[1] != null && sensors.gpIn[1].value == (mod(floor(var.shNo / 2), 2) == 1 ? 0 : 1)}
    set var.sensor_name = "Y MAX"
elif {mod(floor(var.shM / 1), 2) == 1 && sensors.gpIn[0] != null && sensors.gpIn[0].value == (mod(floor(var.shNo / 1), 2) == 1 ? 0 : 1)}
    set var.sensor_name = "Y MIN"
elif {mod(floor(var.shM / 8), 2) == 1 && sensors.gpIn[3] != null && sensors.gpIn[3].value == (mod(floor(var.shNo / 8), 2) == 1 ? 0 : 1)}
    set var.sensor_name = "Z MAX"
elif {mod(floor(var.shM / 4), 2) == 1 && sensors.gpIn[2] != null && sensors.gpIn[2].value == (mod(floor(var.shNo / 4), 2) == 1 ? 0 : 1)}
    set var.sensor_name = "Z MIN"

if var.sensor_name != "Desconocido"
    set var.msg = "Sensor " ^ var.sensor_name ^ " activado. Revisa la máquina."

M291 P{var.msg} R"¡PARADA DE SEGURIDAD!" S1 T15   ; 26-sep: P(…) era sintaxis inválida y el aviso no salía
