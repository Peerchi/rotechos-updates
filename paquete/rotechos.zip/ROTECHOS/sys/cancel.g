; cancel.g - Cancelación limpia tras M0
; M0 ya ha sido enviado por el cliente, aquí completamos la secuencia de parada

G90                          ; Asegurar modo absoluto (protección contra G91 residual)
set global.homingInProgress = false  ; Limpiar flag huérfano si homing fue abortado
if exists(global.uiBeat)
    set global.uiBeat = 0    ; Reiniciar watchdog offline
; Limpiar la marca del watchdog para que una pausa-watcher previa no se arrastre
; a un trabajo posterior (la UI verá un valor viejo y pintaría el toast equivocado).
if exists(global.lastWatchdogPause)
    set global.lastWatchdogPause = 0
; Orden canónico M400→M913 (sincronizar cola antes de cambiar TMC2160). Evita el "clac" al cancelar durante un homing — ver homeall.g:89-90, homex.g:45-46, homey.g:42-43, homez.g:44-45.
M400                         ; vaciar cola antes de M913 (orden canónico: ver homex.g:43-46)
; Failsafe: restaurar corriente al 100% si se canceló durante un homing. Cinemática de RESTORE (no
; de bump — ver homex.g:17-18): tras un cancel mid-homing, devolver la corriente al 100% por
; defecto del TMC2160 sin sobrescribir una posible configuración del operario en M913 que aún no
; se haya ejercido.
M913 X100 Y100 Z100
G4 P200                      ; esperar 200ms para que M0 se procese completamente
; (26-sep: aquí había un M410. RRF 3.5.4 no lo implementa —src/BugList.txt— y solo dejaba
;  un aviso «Command is not supported»; la cola ya la descarta la cancelación (M0).)

; PRIMERO: Elevar Z para sacar la fresa del material (evita rotura con spindle parando)
M98 P"0:/sys/z_safe_raise.g"

; DESPUÉS: Apagar spindle (ya fuera del material — seguro)
T0                           ; Asegurar tool activa — M5 se ignora sin ella
M5                           ; Apagar spindle
G4 P{global.spindle_cooldown_ms}                     ; Esperar 1.5s a que el husillo pierda inercia

; Restaurar perfil SEDA con transición suave RAYO→SEDA (ramp_to_silk.g interpola en 15 pasos, ~600ms)
; set_silk.g canónico vive en sys/. ramp_to_silk.g si existe, si no set_silk.g directo.
if fileexists("0:/sys/ramp_to_silk.g")
    M98 P"0:/sys/ramp_to_silk.g"
else
    M98 P"0:/sys/set_silk.g"
M98 P"0:/sys/recover_triggers.g"  ; Asegurar triggers activos tras cancelación
; LEDs se actualizarán automáticamente en daemon.g. Máquina espera comando del usuario.

; Guardar posición para restaurar al próximo arranque (macro centralizada)
M98 P"0:/sys/save_position.g"

M117 CANCELADO               ; mostrar mensaje en LCD
; LED IDLE reposo: azul claro (consistente con stop.g — ver comentario allí)
M150 R0 U40 B180 S25 F0
M150 F1

echo "═══════════════════════════════════"
echo "  TRABAJO CANCELADO"
echo "  MCU: " , (exists(boards[0].mcuTemp) ? boards[0].mcuTemp.current : "?") , "°C  |  Vin: " , (exists(boards[0].vIn) ? boards[0].vIn.current : "?") , "V"
echo "═══════════════════════════════════"
