; tpre0.g - Pre-seleccion herramienta T0
; En CNC con una sola herramienta, no se requiere accion