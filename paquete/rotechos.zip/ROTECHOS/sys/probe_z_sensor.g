; ═══════════════════════════════════════════════════════════════
; probe_z_sensor.g — Núcleo de palpado contra el sensor fijo (compartido)
; Ruta: 0:/sys/probe_z_sensor.g   ·   Llamada con: M98 P"0:/sys/probe_z_sensor.g"
;
; Lógica ÚNICA de palpado que comparten el SAC (sys/M6.g) y la Sonda Z
; (macros/sonda_Z.g). Hace:
;   1. Sube Z al tope (seguro).
;   2. Va al sensor fijo: X=move.axes[0].max, Y=global.tool_sensor_y (XY en RAYO,
;      restaura SEDA antes de palpar).
;   3. Palpado rápido (probe_speed_fast) + pasadas lentas (probe_speed_slow) con
;      MEDIA y PARADA TEMPRANA: mínimo 2, máximo probe_max_passes; acepta cuando
;      el rango <= probe_tolerance. Aceleración Z definida (probe_accel_z) para
;      que el sobre-recorrido del botón de contacto sea seguro.
;   4. Restaura la cinemática del modo activo.
; Sube Z a seguro y restaura cinemática al terminar (TAMBIÉN antes del diálogo de
; repetibilidad, para que un Cancel no deje la fresa abajo). Guarda el disparo en
; global.probe_trigger_z; el llamador aplica su propio offset con G10 L2 aritmético
; (mártir vs material, posición-independiente) y su mensaje/LED de éxito.
;
; PRERREQUISITOS (los garantiza el llamador): ejes referenciados, sonda no activa,
; husillo parado. En error: restaura el WCS previo, sube Z, repone cinemática,
; LED rojo + M291 y ABORTA (el abort detiene también al llamador).
; ═══════════════════════════════════════════════════════════════

; 26-sep: ficha de «el palpado terminó». Se pone a true en la última línea; si algo sale antes
; (un abort, o Cancelar en el aviso de repetibilidad, que solo sale de ESTA macro), el
; llamador la ve en false y aborta en vez de aplicar el probe_trigger_z de la fresa anterior.
set global.probeOk = false
var wcs_i = exists(move.workplaceNumber) ? move.workplaceNumber : 0   ; 16-sep (B7): índice del WCS activo (0 = G54)
var z_offset_saved  = move.axes[2].workplaceOffsets[var.wcs_i]   ; para restaurar si falla
; Acumuladores de las pasadas lentas (media + rango incremental, sin guardar lista)
var z_sum  = 0.0          ; suma de las lecturas (media = z_sum / z_n)
var z_min  = 99999.0      ; lectura mínima vista
var z_max  = -99999.0     ; lectura máxima vista
var z_n    = 0            ; nº de pasadas lentas completadas
var z_last = 0.0          ; última lectura
var passes_max = exists(global.probe_max_passes) ? global.probe_max_passes : 5
; Suelo de seguridad: con <2 pasadas no hay repetibilidad que medir (el bucle
; aceptaría una única lectura sin contraste). Editar config.g a 1 no debe poder
; degradar el palpado en silencio.
if var.passes_max < 2
    set var.passes_max = 2

G90
G53 G0 Z{move.axes[2].max - global.safe_clearance}                            ; asegurar Z arriba (seguro: solo sube)

; Bajar el escudo M581 de X-MAX de forma granular: vamos a viajar a X-max.
; Sin esto, el carro lo activaria y trigger2 dispararia la alarma a mitad de palpado.
; 26-sep (A2): era `R-1`, que en RRF 3.5.4 desactiva el trigger 2 ENTERO (la R es la condición
; de todo el trigger, TriggerItem.cpp:115): el palpado iba sin escudo en ningún eje. S-1 quita
; solo el pin 4 (X-MAX). Lo vuelve a poner recover_triggers.g al terminar.
M581 P4 T2 S-1


; 2-oct: sin calibrar, tool_sensor_y vale 0 (globals.g) y la fresa iria a un punto cualquiera
; y bajaria hasta el fondo buscando el sensor. Se exige calibrarlo antes del primer SAC.
if global.tool_sensor_y == 0
    M98 P"0:/sys/recover_triggers.g"
    abort "SAC sin calibrar: indica la posicion Y del sensor de herramienta en CONFIGURACION antes de usarlo"

; Ir al sensor fijo — XY en RAYO para agilidad
M400
M201 X{global.pro_accel_x} Y{global.pro_accel_y}
M566 X{global.pro_jerk_x} Y{global.pro_jerk_y} P1
G53 G1 X{move.axes[0].max} Y{global.tool_sensor_y} F{exists(global.travel_feed) ? global.travel_feed : 4000}
; Restaurar SEDA en XY antes de palpar (todo lento y seguro)
M400
M201 X{global.silk_accel_x} Y{global.silk_accel_y}
M566 X{global.silk_jerk_x} Y{global.silk_jerk_y} P1

; Aceleración Z de palpado DEFINIDA (no la del modo activo). El sobre-recorrido tras
; el disparo = v²/(2·accel); con 200 y la búsqueda a 400 mm/min ≈ 0.1mm (botón a salvo).
M400
M201 Z{global.probe_accel_z}

; --- Palpado rápido (búsqueda) ---
; LED azul brillante al INICIAR el palpado (cambio visual claro para el operario
; de que la máquina está palpando, no colgada).
M150 E0 R0 U80 B255 S25 F1
; 3-oct: G38.x de RRF 3.5.4 no usa su F (va a la de M558) ni el modo G91, y sin G53 su destino
; es del WCS: Z{min} sin G53 era min + offset Z del cero de pieza, por debajo del recorrido.
; G53 = destino en máquina; probe_speed.g = la velocidad que pedía la F (ver probe_speed.g).
M98 P"0:/sys/probe_speed.g" F{global.probe_speed_fast}
G53 G38.2 Z{move.axes[2].min}
if result != 0
    M98 P"0:/sys/probe_cleanup_error.g" Z{var.z_offset_saved}
    M291 P"ERROR: El sensor no hizo contacto (búsqueda rápida).<br>Comprueba el sensor y la posición de la fresa." R"PALPADO - ERROR" S1 T0
    abort "Palpado abortado — sensor sin contacto (rápido)"

; --- Pasadas lentas de precisión: MEDIA con PARADA TEMPRANA ---
; Retroceso 3mm tras la rápida (sale del rango de disparo) y bucle de pasadas
; lentas: mínimo 2; si su RANGO (max-min) <= probe_tolerance se acepta la MEDIA
; y se corta el bucle (caso bueno = mismo tiempo que antes). Si no se asienta,
; sigue palpando hasta passes_max ANTES de molestar al operario — una lectura
; suelta ruidosa ya no dispara el diálogo, y la media de K pasadas da un Z0 más
; fino que la última lectura. Rango en mm (no varianza): comparable 1:1 con
; probe_tolerance.
G91
G1 Z{global.probe_backoff_dist1} F{global.probe_backoff_speed}
G90
while iterations < var.passes_max
    if iterations > 0
        ; retroceso corto entre pasadas (la 1ª ya viene del backoff largo de arriba)
        G91
        G1 Z{global.probe_backoff_dist2} F{global.probe_backoff_speed}
        G90
    ; Apagado durante el descenso de cada pasada: el operario solo ve un destello
    ; cuando la fresa TOCA el sensor, no durante el descenso. Eso sincroniza el
    ; ritmo visual con el ritmo mecánico real (1 destello por toque).
    M150 E0 R0 U0 B0 S25 F1
    M98 P"0:/sys/probe_speed.g" F{global.probe_speed_slow}
    G53 G38.2 Z{move.axes[2].min}
    if result != 0
        M98 P"0:/sys/probe_cleanup_error.g" Z{var.z_offset_saved}
        M291 P{"ERROR: El sensor no hizo contacto en la pasada de precisión #" ^ (iterations + 1) ^ ".<br>Repite la operación."} R"PALPADO - ERROR" S1 T0
        abort "Palpado abortado — sin contacto (precisión)"
    set var.z_last = move.axes[2].machinePosition
    set var.z_sum = var.z_sum + var.z_last
    set var.z_n = var.z_n + 1
    if var.z_last < var.z_min
        set var.z_min = var.z_last
    if var.z_last > var.z_max
        set var.z_max = var.z_last
    ; DESTELLO al tocar: azul brillante justo cuando se registra la lectura,
    ; 150ms de duración para que se vea aunque el bucle sea rápido. Mismo color
    ; y brillo que la fase rápida (U80 B255) para continuidad visual.
    M150 E0 R0 U80 B255 S25 F1
    G4 P150
    M150 E0 R0 U0 B0 S25 F1
    ; Parada temprana: con >=2 pasadas dentro de tolerancia, la media ya es fiable
    if var.z_n >= 2 && (var.z_max - var.z_min) <= global.probe_tolerance
        break
set global.probe_trigger_z = var.z_sum / var.z_n        ; MEDIA de las pasadas → al llamador (G10 L2 aritmético)
; LED apagado al terminar el palpado — el M150 siguiente (en M6.g) toma el control.
M150 E0 R0 U0 B0 S25 F1

; --- Poner la máquina en SEGURO ANTES del diálogo de repetibilidad ---
; Subimos Z y restauramos la cinemática del modo activo AHORA. Así, pase lo que pase
; en el M291 S3 de abajo (Aceptar o CANCELAR — que aborta TODA la pila de macros), la
; fresa ya está arriba y la cinemática restaurada: el Cancel ya NO deja la herramienta
; clavada abajo en el sensor. El llamador aplica el offset con G10 L2 usando
; global.probe_trigger_z, sin necesitar que la fresa siga en el punto de disparo.
G53 G0 Z{move.axes[2].max - global.safe_clearance}
; Liberar el endstop X-MAX y REARMAR el escudo ANTES del dialogo de repetibilidad
; (un Cancel aborta la pila; si el flag quedara arriba el escudo seguiria bajado).
; Retroceder 25mm en X suelta el inductivo X-MAX; luego ya es seguro rearmar.
; IMPORTANTE: este movimiento es entre dos puntos de MÁQUINA (no cerca del sensor),
; por lo que se hace en RAYO. Si se quedara en SEDA (M201 X80, M566 X80) y el carro
; viaja a F4000, la combinación de jerk bajo + velocidad alta genera vibración audible
; en los TMC2160 (zumbido/clac característico). La cinemática del modo activo se
; restaura DESPUÉS, con la máquina parada.
M400
M201 X{global.pro_accel_x} Y{global.pro_accel_y}
M566 X{global.pro_jerk_x} Y{global.pro_jerk_y} P1
G53 G1 X{move.axes[0].max - global.probe_x_backoff} F{exists(global.travel_feed) ? global.travel_feed : 4000}
M400
M98 P"0:/sys/recover_triggers.g"
; Restaurar la cinemática del modo activo. 15-sep (B13): antes se llamaba a ramp_to_pro.g
; o ramp_to_silk.g según el modo, pero las dos salen con M99 cuando el modo ya coincide:
; X/Y se quedaban con la dinámica de RAYO fijada arriba y Z con la de palpado, con la UI
; diciendo SEDA. restore_kinematics.g aplica la del modo sin tocar modo ni LED, y tras
; su M400 la máquina está parada: no hay salto en mitad de un movimiento.
M98 P"0:/sys/restore_kinematics.g"

; --- Verificación de repetibilidad (rango de TODAS las pasadas lentas) ---
; Solo se llega aquí fuera de tolerancia si NI CON passes_max pasadas se asentó:
; sensor sucio/inestable, vibración o sujeción floja. Bloqueante para que el
; operario decida. (La máquina ya está segura arriba: Cancelar no deja la fresa abajo.)
if (var.z_max - var.z_min) > global.probe_tolerance
    var repMsg = "Repetibilidad: " ^ (var.z_max - var.z_min) ^ "mm en " ^ var.z_n ^ " pasadas"
    set var.repMsg = var.repMsg ^ " (max " ^ global.probe_tolerance ^ "mm). Sensor sucio/sujecion floja."
    set var.repMsg = var.repMsg ^ "<br>Aceptar = usar media. Cancelar = abortar."
    M291 P{var.repMsg} R"PALPADO - REPETIBILIDAD" S3
    ; (Cancelar sale de esta macro aquí mismo: la ficha de abajo no se pone.)

set global.probeOk = true             ; ÚLTIMA línea: el palpado llegó al final
