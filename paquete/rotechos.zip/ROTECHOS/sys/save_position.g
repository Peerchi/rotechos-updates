; sys/save_position.g
; Guarda el CERO DE PIEZA (G10 L2 del WCS activo) para restaurarlo al próximo arranque.
; 26-sep (auditoría contra el fuente de RRF 3.5.4, C5): antes guardaba también la posición de
; máquina con G92, y G92 marca los ejes como REFERENCIADOS (GCodes3.cpp:143). Cada arranque
; daba X/Y/Z por referenciados en la posición vieja, aunque se hubiera movido el pórtico a mano
; con la máquina apagada (o caído Z, que no es autoblocante): start.g dejaba arrancar sin HOME.
; Ahora se guarda solo el cero de pieza, que no toca el referenciado, en un fichero NUEVO
; (saved_offsets.g): el saved_position.g viejo que quede en la SD ya no se ejecuta nunca.

; 16-sep (B7): el cero se escribía SIEMPRE en G54 (P1). Con un programa en G55, el
; SAC corregía G54 y el trabajo seguía con la longitud de la fresa anterior: la fresa
; más larga se clava esa diferencia. Se escribe en el sistema de coordenadas ACTIVO.
var wcs_i = exists(move.workplaceNumber) ? move.workplaceNumber : 0
if #move.axes >= 3
    echo >"0:/sys/saved_offsets.g" "G10 L2 P" ^ (var.wcs_i + 1) ^ " X" ^ move.axes[0].workplaceOffsets[var.wcs_i] ^ " Y" ^ move.axes[1].workplaceOffsets[var.wcs_i] ^ " Z" ^ move.axes[2].workplaceOffsets[var.wcs_i]
