; sys/save_position.g
; Guarda el CERO DE PIEZA (G10 L2 del WCS activo) para restaurarlo al próximo arranque.
; 26-sep (auditoría contra el fuente de RRF 3.5.4, C5): antes guardaba también la posición de
; máquina con G92, y G92 marca los ejes como REFERENCIADOS (GCodes3.cpp:143). Cada arranque
; daba X/Y/Z por referenciados en la posición vieja, aunque se hubiera movido el pórtico a mano
; con la máquina apagada (o caído Z, que no es autoblocante): start.g dejaba arrancar sin HOME.
; Ahora se guarda solo el cero de pieza, que no toca el referenciado, en un fichero NUEVO
; (saved_offsets.g): el saved_position.g viejo que quede en la SD ya no se ejecuta nunca.

; 16-sep (B7): el cero se escribía SIEMPRE en G54 (P1). Con un programa en G55, el
; SAC corregía G54 y el trabajo seguía con la longitud de la fresa anterior: la fresa
; más larga se clava esa diferencia. Se escribe en el sistema de coordenadas ACTIVO.
var wcs_i = {exists(move.workplaceNumber) ? move.workplaceNumber : 0}
if #move.axes >= 3
    var off_x = move.axes[0].workplaceOffsets[var.wcs_i]
    var off_y = move.axes[1].workplaceOffsets[var.wcs_i]
    var off_z = move.axes[2].workplaceOffsets[var.wcs_i]
    echo >"0:/sys/saved_offsets.g" {"G10 L2 P" ^ (var.wcs_i + 1) ^ " X" ^ var.off_x ^ " Y" ^ var.off_y ^ " Z" ^ var.off_z}

    ; Registro INFORMATIVO de la última posición de MÁQUINA (no de pieza).
    ; NO se lee ni se ejecuta al arrancar y NO controla ningún movimiento: es
    ; solo un .txt para diagnóstico. No restaura nada, no autoriza reanudar y
    ; no marca ningún eje como referenciado. X/Y/Z solo si los TRES están homed.
    var wcs_txt = {"G" ^ (var.wcs_i + 54)}
    var homed_xyz = {move.axes[0].homed && move.axes[1].homed && move.axes[2].homed}
    echo >"0:/sys/last_position_info.txt" "; last_position_info INFORMATIVO: no se lee al arrancar ni controla movimientos"
    echo >>"0:/sys/last_position_info.txt" {"status=" ^ state.status ^ " wcs=" ^ var.wcs_txt}
    if var.homed_xyz
        var pos_x = {move.axes[0].machinePosition}
        var pos_y = {move.axes[1].machinePosition}
        var pos_z = {move.axes[2].machinePosition}
        echo >>"0:/sys/last_position_info.txt" {"homed=YES X=" ^ var.pos_x ^ " Y=" ^ var.pos_y ^ " Z=" ^ var.pos_z}
    else
        echo >>"0:/sys/last_position_info.txt" "homed=NO-HOMED: sin coordenadas (no todos los ejes estan referenciados)"
