; homea.g — "homing" del eje A rotativo (sin endstop físico)
; Ejecutado por RRF ante G28 A (y desde homeall.g si el eje A existe).
; Un rotativo continuo no tiene referencia absoluta: se adopta la posición
; actual como A=0 con G92 — patrón estándar de 4º eje sin endstop. G92 marca
; el eje como referenciado, lo que desbloquea sus movimientos bajo M564 H1
; (global.requireHoming). Sin este archivo, un eje A activado quedaba
; inamovible con requireHoming=true (fix A-4 del audit del 4º eje, 2026-07-12).
; PENDIENTE DE BANCO (validar con el rotativo montado antes de subir a SD)
if #move.axes < 4
    M99                          ; eje A no configurado — nada que hacer
G92 A0                           ; posición actual = A0 → eje referenciado
