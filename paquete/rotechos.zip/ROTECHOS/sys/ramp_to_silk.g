; =================================================================
; ramp_to_silk.g — Cambio de RAYO a SEDA (RotechOS)
; =================================================================
; 14-nov-2026: ya NO es una rampa. Antes subía/bajaba M201 y M566 en 15 pasos con
; G4 P40 entre paso y paso (600 ms). Pero empezaba con M400: la cola está vacía y
; NADA se mueve mientras dura, así que la «rampa» no suavizaba ningún movimiento
; (M201/M566 solo son límites del planificador para los movimientos que vengan
; DESPUÉS; no tocan los drivers). Lo único que hacía era retrasar 600 ms la pausa,
; el paro y el cambio de herramienta, y dejar valores a medias si algo abortaba a
; mitad. Ahora el cambio es de una vez, con el mismo orden canónico
; (M400 → M201 → M566 P1) que hace set_silk.g.
; El fichero se conserva con su nombre porque lo llaman start.g, pause.g, resume.g,
; stop.g, cancel.g, M6.g y la interfaz.

; Si ya estamos en SEDA no hay nada que hacer
if global.kinematicMode == 0
    M99

M400 ; cola vacía antes de cambiar la dinámica
if global.kinematicMode != 0
    M98 P"0:/sys/set_silk.g"
