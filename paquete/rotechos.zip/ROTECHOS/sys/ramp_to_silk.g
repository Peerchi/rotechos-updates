; =================================================================
; ramp_to_silk.g — Transición suave de RAYO a SEDA (RotechOS)
; =================================================================
; Disminuye gradualmente la aceleración y el jerk para evitar el "golpe"
; mecánico/acústico al finalizar un trabajo (stop.g, cancel.g, trigger2.g).
; Espejo de ramp_to_pro.g pero en sentido inverso.
;
; Verificamos que no estemos ya en modo SEDA (0) para evitar rampa innecesaria
if global.kinematicMode == 0
    M99

M400 ; sync planner queue before ramp
; Configuramos la rampa
var steps = 15
var delay_ms = 40              ; Total = 600ms

; Cálculos de los incrementos por paso (Delta / Pasos)
; Dirección: de RAYO (actual) hacia SEDA (objetivo)
var step_accel_x = (global.silk_accel_x - global.pro_accel_x) / var.steps
var step_accel_y = (global.silk_accel_y - global.pro_accel_y) / var.steps
var step_accel_z = (global.silk_accel_z - global.pro_accel_z) / var.steps
var step_accel_a = 0.0

var step_jerk_x = (global.silk_jerk_x - global.pro_jerk_x) / var.steps
var step_jerk_y = (global.silk_jerk_y - global.pro_jerk_y) / var.steps
var step_jerk_z = (global.silk_jerk_z - global.pro_jerk_z) / var.steps
var step_jerk_a = 0.0

if #move.axes > 3
    set var.step_accel_a = (global.silk_accel_a - global.pro_accel_a) / var.steps
    set var.step_jerk_a = (global.silk_jerk_a - global.pro_jerk_a) / var.steps

; Bucle de transición gradual (descendente)
while iterations < var.steps
    ; Aplicamos los valores incrementales desde el valor actual hacia SEDA
    if #move.axes > 3
        M201 X{global.pro_accel_x + (var.step_accel_x * (iterations + 1))} Y{global.pro_accel_y + (var.step_accel_y * (iterations + 1))}
        M201 Z{global.pro_accel_z + (var.step_accel_z * (iterations + 1))} A{global.pro_accel_a + (var.step_accel_a * (iterations + 1))}
        M566 X{global.pro_jerk_x + (var.step_jerk_x * (iterations + 1))} Y{global.pro_jerk_y + (var.step_jerk_y * (iterations + 1))} P1
        M566 Z{global.pro_jerk_z + (var.step_jerk_z * (iterations + 1))} A{global.pro_jerk_a + (var.step_jerk_a * (iterations + 1))} P1
    else
        M201 X{global.pro_accel_x + (var.step_accel_x * (iterations + 1))} Y{global.pro_accel_y + (var.step_accel_y * (iterations + 1))} Z{global.pro_accel_z + (var.step_accel_z * (iterations + 1))}
        M566 X{global.pro_jerk_x + (var.step_jerk_x * (iterations + 1))} Y{global.pro_jerk_y + (var.step_jerk_y * (iterations + 1))} Z{global.pro_jerk_z + (var.step_jerk_z * (iterations + 1))} P1

    ; Pequeña pausa para suavizar la rampa
    G4 P{var.delay_ms}

; Al finalizar, llamamos a set_silk.g SOLO si no estábamos ya en SEDA. El check
; inicial (líneas 9-10) hace M99 si ya estamos, pero set_silk.g reaplica M201
; de golpe — con kinematicMode==0, los valores ya son correctos.
if global.kinematicMode != 0
    M98 P"0:/sys/set_silk.g"
