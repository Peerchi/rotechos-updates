; homey.g — homing eje Y independiente
set global.homingInProgress = true
; 17-oct (A3/N-H1): el escudo T2 corta tambien el HOME. Una peticion vieja (de un disparo
; durante el jog) no cuenta: se limpia aqui; las nuevas las consume abort_check.g entre fases.
if {exists(global.abortRequested)}
    set global.abortRequested = false

; Guardia: verificar que el husillo está parado y la sonda Z inactiva
M98 P"0:/sys/guards/check_homing_safe.g"
if {exists(global.motorDirectionCheckMask) && global.motorDirectionCheckMask != 0}
    set global.homingInProgress = false
    abort "HOME bloqueado: verifica el sentido del motor hacia su final de carrera antes de referenciar."

; 15-sep (B10): subir Z antes de mover Y, como homeall.g. Con la fresa baja, un G28 Y
; por consola la arrastraba por la pieza o las bridas. Sin Z referenciado no se sabe
; dónde está la fresa: se aborta.
M400
if !move.axes[2].homed
    set global.homingInProgress = false
    abort "Homing Y abortado: referencia Z primero (G28 Z o G28)"
if {move.axes[2].machinePosition < (move.axes[2].max - global.safe_clearance)}
    M400
    G90
    G53 G1 Z{move.axes[2].max - global.safe_clearance} F{global.z_raise_speed}

; Cinemática suave de homing — evita golpe en arranque (ver homeall.g)
M400
M98 P"0:/sys/abort_check.g"      ; 17-oct (A3): el escudo saltó al subir Z → no mover Y
M201 Y{global.homing_accel_y}
M566 Y{global.homing_jerk_y} P1

; --- REDUCCIÓN DE CORRIENTE (Efecto muelle magnético) ---
; SOLO el eje que se homea. NO bajar Z: su tornillo NO es autoblocante (config.g)
; y al 60% el spindle podría caer por gravedad durante el homing de Y.
; M913 literal = INTENCIONAL: la UI no expone M913 operativo (no es M906 RMS).
M400
M913 Y60                       ; INTENCIONAL — no editable desde UI (cinemática de bump)

; Desactivar triggers M581 ANTES del unbinding (evita disparos falsos transitorios)
; 28-sep (revisión RRF, «R-1 en homing»): era `M581 Pn T2 R-1`. En RRF 3.5.4 la R es la
; condición del trigger ENTERO (TriggerItem.cpp:117-121) y S vale 1 si falta: apagaba los seis
; sensores y además AÑADÍA el pin. S-1 quita solo ese pin (TriggerItem.cpp:140-144).
M581 P1 T2 S-1               ; quitar SOLO el pin de Y Max del trigger 2
M581 P0 T2 S-1               ; quitar SOLO el pin de Y Min del trigger 2
; Seleccionar el lado configurado y liberar su pin GPIO antes de usarlo como endstop.
if {!exists(global.homeSideY) || global.homeSideY == 1}
    M950 J1 C"nil"               ; liberar pin D.14 de GPIO (Y MAX)
    M574 Y2 S1 P"^D.14"          ; activar endstop Y MAX
else
    M950 J0 C"nil"               ; liberar pin A.8 de GPIO (Y MIN)
    M574 Y1 S1 P"^A.8"            ; activar endstop Y MIN

G91
if {!exists(global.homeSideY) || global.homeSideY == 1}
    G1 H1 Y{move.axes[1].max + 40} F{global.travel_feed / 4}   ; buscar Y MAX
else
    G1 H1 Y{-(move.axes[1].max - move.axes[1].min + 40)} F{global.travel_feed / 4}   ; buscar Y MIN
M400
M98 P"0:/sys/abort_check.g"      ; 17-oct (A3): el escudo saltó en esta fase → abortar (no es «sensor no detectado»)
if !move.axes[1].homed                ; el primer H1 no llegó al sensor (A1, 28-sep)
    M98 P"0:/sys/home_fail.g"
    if {!exists(global.homeSideY) || global.homeSideY == 1}
        abort "Homing Y fallido: no se detecto Y MAX en el recorrido. Revisa el sensor y su cable."
    else
        abort "Homing Y fallido: no se detecto Y MIN en el recorrido. Revisa el sensor y su cable."
if {!exists(global.homeSideY) || global.homeSideY == 1}
    G1 Y{-global.homing_backoff_xy} F{global.probe_backoff_speed}                  ; retroceder desde Y MAX
else
    G1 Y{global.homing_backoff_xy} F{global.probe_backoff_speed}                   ; retroceder desde Y MIN
M400
M98 P"0:/sys/abort_check.g"      ; 17-oct (A3): el escudo saltó en el retroceso → no buscar de nuevo
; 11-nov: exigir una detección nueva sin soltar el motor (también Z).
; M350 con los valores actuales desmarca homed: RRF 3.5.4, GCodes2.cpp:2920-2942.
M350 Y{move.axes[1].microstepping.value} I{move.axes[1].microstepping.interpolated ? 1 : 0}
if sensors.endstops[1].triggered
    M98 P"0:/sys/home_fail.g"
    abort "Homing Y fallido: el sensor no se libera tras el retroceso. Revisa el sensor y su cable."
if {!exists(global.homeSideY) || global.homeSideY == 1}
    G1 H1 Y{global.homing_backoff_xy * 2} F{global.probe_speed_slow}               ; búsqueda lenta hacia Y MAX
else
    G1 H1 Y{-global.homing_backoff_xy * 2} F{global.probe_speed_slow}              ; búsqueda lenta hacia Y MIN
G90
; 28-sep (A1): sin G92. El G1 H1 que llega al sensor ya fija la posición y marca el eje; un
; G92 aquí lo daba por referenciado aunque el sensor no se hubiera detectado nunca.
M400
M98 P"0:/sys/abort_check.g"      ; 17-oct (A3): el escudo saltó en esta fase → abortar (no es «sensor no detectado»)
if !move.axes[1].homed
    M98 P"0:/sys/home_fail.g"
    if {!exists(global.homeSideY) || global.homeSideY == 1}
        abort "Homing Y fallido: no se detecto el final de carrera Y MAX. Revisa el sensor y su cable antes de volver a referenciar."
    else
        abort "Homing Y fallido: no se detecto el final de carrera Y MIN. Revisa el sensor y su cable antes de volver a referenciar."
G91
if {!exists(global.homeSideY) || global.homeSideY == 1}
    G1 Y{-global.homing_clearance_xy} F{global.probe_backoff_speed}
else
    G1 Y{global.homing_clearance_xy} F{global.probe_backoff_speed}
G90

; Restaurar escudo de hardware centralizado
M400
M98 P"0:/sys/abort_check.g"      ; 17-oct (A3): el escudo saltó durante el apartado → abortar ANTES de rearmar
M574 Y0 S1                   ; deshabilitar endstop Y
M98 P"0:/sys/recover_triggers.g"
M98 P"0:/sys/abort_check.g"      ; 17-oct (A3): un disparo durante el rearme no se da por bueno

; --- RESTAURAR CORRIENTE AL 100% ---
; INTENCIONAL: cinemática de homing, no editable desde UI.
M400
M913 X100 Y100 Z100             ; INTENCIONAL — restauración tras bump de homing

; Restaurar cinemática del modo activo (SEDA=0 / RAYO=1)
M98 P"0:/sys/restore_kinematics.g"

set global.homingInProgress = false

; --- RETROALIMENTACIÓN DE ÉXITO (coherente con homeall.g) ---
M98 P"0:/sys/home_feedback_success.g"
