; homey.g — homing eje Y independiente
set global.homingInProgress = true

; Guardia: verificar que el husillo está parado y la sonda Z inactiva
M98 P"0:/sys/guards/check_homing_safe.g"

; 15-sep (B10): subir Z antes de mover Y, como homeall.g. Con la fresa baja, un G28 Y
; por consola la arrastraba por la pieza o las bridas. Sin Z referenciado no se sabe
; dónde está la fresa: se aborta.
M400
if !move.axes[2].homed
    set global.homingInProgress = false
    abort "Homing Y abortado: referencia Z primero (G28 Z o G28)"
if move.axes[2].machinePosition < (move.axes[2].max - global.safe_clearance)
    M400
    G90
    G53 G1 Z{move.axes[2].max - global.safe_clearance} F{global.z_raise_speed}

; Cinemática suave de homing — evita golpe en arranque (ver homeall.g)
M400
M201 Y{global.homing_accel_y}
M566 Y{global.homing_jerk_y} P1

; --- REDUCCIÓN DE CORRIENTE (Efecto muelle magnético) ---
; SOLO el eje que se homea. NO bajar Z: su tornillo NO es autoblocante (config.g)
; y al 60% el spindle podría caer por gravedad durante el homing de Y.
; M913 literal = INTENCIONAL: la UI no expone M913 operativo (no es M906 RMS).
M400
M913 Y60                       ; INTENCIONAL — no editable desde UI (cinemática de bump)

; Desactivar triggers M581 ANTES del unbinding (evita disparos falsos transitorios)
; 28-sep (revisión RRF, «R-1 en homing»): era `M581 Pn T2 R-1`. En RRF 3.5.4 la R es la
; condición del trigger ENTERO (TriggerItem.cpp:117-121) y S vale 1 si falta: apagaba los seis
; sensores y además AÑADÍA el pin. S-1 quita solo ese pin (TriggerItem.cpp:140-144).
M581 P1 T2 S-1               ; quitar SOLO el pin de Y Max del trigger 2
M581 P0 T2 S-1               ; quitar SOLO el pin de Y Min del trigger 2
; Liberar pin D.14 del GPIO J1 antes de usarlo como endstop
M950 J1 C"nil"               ; liberar pin D.14 de GPIO
M574 Y2 S1 P"^D.14"          ; activar endstop Y Max (Y2 = lado MAX, pin D.14 = sensor J1)

G91
G1 H1 Y{move.axes[1].max + 40} F{global.travel_feed / 6}   ; buscar endstop Y Max — recorrido dinámico (área M208 + 40mm)
M400
if !move.axes[1].homed                ; el primer H1 no llegó al sensor (A1, 28-sep)
    M98 P"0:/sys/home_fail.g"
    abort "Homing Y fallido: no se detecto Y MAX en el recorrido. Revisa el sensor y su cable."
G1 Y{-global.homing_backoff_xy} F{global.probe_backoff_speed}                  ; retroceder un poco (hacia -Y)
G1 H1 Y{global.homing_backoff_xy * 2} F{global.probe_speed_slow}               ; búsqueda lenta de precisión
G90
; 28-sep (A1): sin G92. El G1 H1 que llega al sensor ya fija la posición y marca el eje; un
; G92 aquí lo daba por referenciado aunque el sensor no se hubiera detectado nunca.
M400
if !move.axes[1].homed
    M98 P"0:/sys/home_fail.g"
    abort "Homing Y fallido: no se detecto el final de carrera Y MAX. Revisa el sensor y su cable antes de volver a referenciar."
G91
G1 Y{-global.homing_clearance_xy} F{global.probe_backoff_speed}
G90

; Restaurar escudo de hardware centralizado
M574 Y0 S1                   ; deshabilitar endstop Y
M98 P"0:/sys/recover_triggers.g"

; --- RESTAURAR CORRIENTE AL 100% ---
; INTENCIONAL: cinemática de homing, no editable desde UI.
M400
M913 X100 Y100 Z100             ; INTENCIONAL — restauración tras bump de homing

; Restaurar cinemática del modo activo (SEDA=0 / RAYO=1)
M98 P"0:/sys/restore_kinematics.g"

set global.homingInProgress = false

; --- RETROALIMENTACIÓN DE ÉXITO (coherente con homeall.g) ---
M98 P"0:/sys/home_feedback_success.g"
