; sys/probe_cleanup_error.g
; Restablecer coordenadas, velocidad y escudo al fallar el palpado en sensor fijo (SAC)
; Parámetro Z: Offset Z original a restaurar

; 16-sep (B7): el cero se escribía SIEMPRE en G54 (P1). Con un programa en G55, el
; SAC corregía G54 y el trabajo seguía con la longitud de la fresa anterior: la fresa
; más larga se clava esa diferencia. Se escribe en el sistema de coordenadas ACTIVO.
; 2-oct: mesh_probe.g llama aqui con G91 activo (palpaba en relativo). Sin esto los G53 de
; abajo serian RELATIVOS: la fresa bajaba en vez de subir y el carro corria hacia X-max.
G90

var wcs_p = exists(move.workplaceNumber) ? move.workplaceNumber + 1 : 1
if exists(param.Z)
    G10 L2 P{var.wcs_p} Z{param.Z}

G53 G0 Z{move.axes[2].max - global.safe_clearance}
; Liberar el endstop X-MAX y limpiar el escudo (evita alarma espuria)
G53 G1 X{move.axes[0].max - global.probe_x_backoff} F{global.travel_feed}
M400
M98 P"0:/sys/recover_triggers.g"
M98 P"0:/sys/restore_kinematics.g"
M150 R255 U0 B0 F0 S25
M150 F1
