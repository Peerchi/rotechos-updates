; net_ap.g — pasa la máquina a su red propia «RotechOS» (http://192.168.1.1), sin USB.
; La llama CONFIGURACIÓN → Red al activar «Trabajar siempre con la red propia», y el
; botón «Seguir con esta red» del aviso naranja. Que ARRANQUE siempre así lo guarda
; la UI en config-machine.g (set global.netApOnly = true); aquí solo se cambia ya.
; El cambio lo hace daemon_tick.g (etapas 0-2), que espera de verdad a que el módulo
; esté parado antes de pedir el AP. Si ya está en la red propia, no se toca nada.
set global.netApOnly = true
if network.interfaces[0].actualIP != "192.168.1.1" && !global.apModeActive
    set global.netTries = 0
    set global.netStage = 0
    set global.netStageT = state.upTime
    set global.netApCheckDone = false
