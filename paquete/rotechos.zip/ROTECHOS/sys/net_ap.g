; net_ap.g — pasa la máquina a su red propia «RotechOS» (http://192.168.1.1), sin USB.
; La llama CONFIGURACIÓN → Red al activar «Trabajar siempre con la red propia», y el
; botón «Seguir con esta red» del aviso naranja. Que ARRANQUE siempre así lo guarda
; la UI en config-machine.g (set global.netApOnly = true); aquí solo se cambia ya.
; El cambio lo hace daemon_tick.g (etapas 0-2), que espera de verdad a que el módulo
; esté parado antes de pedir el AP. 18-oct (E1): daemon_tick.g es el único dueño
; del M589 y aplica global.apKey o el fallback; así M589 queda justo antes de M552 S2.
; Si ya está en la red propia, no se toca nada.
set global.netApOnly = true
var eth = exists(global.netEthernet) && global.netEthernet
; 31-oct: elegir esta red deja de usar Ethernet también en los próximos arranques.
if exists(global.netEthernet)
    set global.netEthernet = false
if fileexists("0:/sys/net-ethernet.g")
    M30 "0:/sys/net-ethernet.g"
; Saliendo de Ethernet, M552 S0 no corta un intento en curso: apagar y usar la etapa 4.
if var.eth
    set global.apModeActive = false
    set global.netTries = 0
    M552 S-1
    set global.netStage = 4
    set global.netStageT = state.upTime
    set global.netApCheckDone = false
elif network.interfaces[0].actualIP != "192.168.1.1" && !global.apModeActive
    set global.netTries = 0
    set global.netStage = 0
    set global.netStageT = state.upTime
    set global.netApCheckDone = false
