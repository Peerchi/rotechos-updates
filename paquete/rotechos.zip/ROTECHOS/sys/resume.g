; resume.g - Reanudacion del trabajo en PAUSED
; El spindle mantiene su velocidad anterior automáticamente en RRF
; Si está parado, M3 sin S usa la última velocidad

; GUARDIA: G53 requiere homing — si se perdió referencia durante la pausa, abortar
; 28-sep (C1): con M24, RRF NO ejecuta este fichero si falta la referencia (GCodes2.cpp:1152-1157)
; y reanuda igual; esta guarda solo cubre una llamada directa (M98). Lo que impide reanudar sin
; referencia es la interfaz, que no manda el M24 (C1-a en tests/e2e-auditoria-rrf354.spec.js).
if !move.axes[0].homed || !move.axes[1].homed || !move.axes[2].homed
    abort "Reanudación abortada: Pérdida de referencia (Homing requerido)"

; 15-sep (B2): una caída de tensión que no llega a apagar la placa ejecuta la acción de
; M911 (M913 X0 Y0): X/Y quedan sin par y pierden pasos. Nada devolvía la corriente.
; Se devuelve y se exige homing (M18 quita la referencia): los pasos perdidos no vuelven.
if exists(move.axes[0].percentCurrent) && (move.axes[0].percentCurrent < 100 || move.axes[1].percentCurrent < 100)
    M400
    M913 X100 Y100 Z100             ; INTENCIONAL — devolver el par tras la acción de M911
    M18 X Y
    ; 28-sep (C1 de la auditoría contra RRF 3.5.4): un `abort` aquí NO impide la reanudación. M24
    ; ya ha puesto el canal en `resuming1` antes de llamar a este fichero (GCodes2.cpp:1152-1157)
    ; y, al acabar la macro, RRF baja la fresa a la cota de pausa y sigue el programa SIN husillo
    ; (GCodes4.cpp:519-600). La interfaz ya no manda el M24 en este caso, pero puede llegar desde
    ; DWC, la consola o la pantalla física. El único corte que RRF respeta es el paro: M112.
    ; Con X/Y soltados (M18) hay que reiniciar y referenciar igualmente.
    echo "resume.g: X/Y sin corriente completa tras una caida de tension. PARO para impedir que RRF reanude sin husillo. Reinicia y haz Homing."
    M112
; Orden canónico M400→M913 (sincronizar cola antes de tocar el TMC2160) — ver cancel.g:12-13.
M400
M913 X100 Y100 Z100             ; INTENCIONAL — porcentaje de M913, no la corriente de M906 (esa la edita la UI)

; Restaurar posición XY si hubo jog durante la pausa — sin exists()
G90
; SEGURIDAD: elevar Z al tope MCS (Z=0, max) ANTES del reposicionamiento XY.
; El operario pudo hacer jog de Z durante la pausa (inspeccionar corte, cambiar
; brida), así que la cota Z actual es desconocida; mover XY sin despejar Z
; arrastraría la fresa por la pieza/bridas. (Espejo del z-safe de stop/cancel.g.)
; GUARDA: mismo patrón que z_safe_raise.g — solo subir Z si hay espacio; si ya
; está por encima de la línea de clearance, NO mover (moverlo bajaría la fresa).
if move.axes[2].machinePosition < (move.axes[2].max - global.safe_clearance)
    G53 G1 Z{move.axes[2].max - global.safe_clearance} F{global.z_raise_speed}
else
    echo "resume.g: Z ya por encima de la línea de seguridad — reposicionamiento XY sin subir Z"
G53 G1 X{global.pause_x} Y{global.pause_y} F{global.travel_feed}

; Restaurar perfil cinemático si cambió durante la pausa (ej: operario hizo jog en SILK)
; Además: forzar RAYO si el hook de UI no aplicó el cambio (timing 500ms vs M24 inmediato)
if !exists(global.pause_kinematicMode) || global.pause_kinematicMode == 1   ; 3-oct: exists() primero (cortocircuito izquierda a derecha)
    if fileexists("0:/sys/ramp_to_pro.g")
        M98 P"0:/sys/ramp_to_pro.g"
    else
        M98 P"0:/sys/set_pro.g"
else
    M98 P"0:/sys/set_silk.g"

; B-H4.3 (auditoria 15-sep): el M3 era INCONDICIONAL. Si el operario pausaba en
; un tramo con el husillo ya parado —entre dos operaciones, tras un cambio de
; herramienta— al reanudar arrancaba solo, con las manos posiblemente dentro.
; Ahora solo se enciende si estaba encendido al pausar. La global vale 1 por
; defecto (globals.g), asi que ante cualquier duda se reanuda como siempre.
if !exists(global.pause_spindle_active) || global.pause_spindle_active > 0
    T0                            ; activar tool — M3 se ignora sin ella
    M3                            ; encender spindle (retoma última velocidad configurada — R2 no soportado en RRF)
    ; Espera de rampa PROPORCIONAL al salto de RPM
    M98 P"0:/sys/spindle_ramp_wait.g"
else
    echo "resume.g: el husillo estaba parado al pausar — no se enciende"
; Las LEDs y estado se actualizarán automáticamente en daemon.g cuando state.status = "processing"

