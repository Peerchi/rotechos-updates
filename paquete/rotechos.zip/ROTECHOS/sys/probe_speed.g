; probe_speed.g — fija la velocidad del SIGUIENTE G38.x
; Uso: M98 P"0:/sys/probe_speed.g" F<mm/min>
;
; 3-oct-2026 (fuente de RRF 3.5.4): G38.x NO usa su propio F. El movimiento de palpado sale
; con la velocidad 0 de M558 (GCodes4.cpp:1563, `ms.feedRate = zp->GetProbingSpeed(0)`), así
; que los F{global.probe_speed_fast} / F{global.probe_speed_slow} de las macros no hacían nada:
; todo el palpado iba a la F de M558. `M558 K0 F...` sin P ni C solo cambia la velocidad de la
; sonda que ya existe (EndstopsManager.cpp:622-662, ZProbe.cpp:459-466).
;
; TOPE: nunca más rápido que la F de M558 que dejó config (global.probeSpeedCap). Esa F es la
; velocidad que se dio por segura para un pulsador de CONTACTO (config.g, bloque de M558); para
; subirla, se sube en CONFIGURACIÓN -> SONDA Z, no aquí.
if !exists(param.F)
    abort "probe_speed.g: falta F (mm/min)"
if !exists(global.probeSpeedCap)
    global probeSpeedCap = sensors.probes[0].speeds[0]
M558 K0 F{min(param.F, global.probeSpeedCap)}
