; daemon_tick.g — Una vuelta del vigilante de RotechOS (la llama daemon.g en bucle)
; Ruta: 0:/sys/daemon_tick.g
; 28-sep (M1): era el cuerpo de daemon.g. RRF espera 10 s entre dos ejecuciones de daemon.g
; (GCodes.cpp:559-563) y los contadores de abajo suponen ~0,5-1 s por vuelta: la pausa por
; tensión baja tardaba ~42 s. daemon.g hace ahora el bucle y la espera.
; IMPORTANTE: NO usar globals aquí — pueden no existir si config.g
;             falló durante el arranque. Usar solo Object Model (state.*,
;             move.*, boards[*]) que siempre están disponibles.
; ─────────────────────────────────────────────────────────────────

; Guardia: no ejecutar si los ejes no están disponibles aún
if #move.axes < 3
    M99

; ── Alerta térmica MCU ───────────────────────────────────────────────────────
; Nivel numérico auto-creado aquí (0=normal, 1=aviso>55, 2=crítica>65), NO booleano:
; con un flag compartido, la CRÍTICA quedaba silenciada si ya había saltado el AVISO
; (el flag ya era true). Con nivel, cada escalada 0→1→2 muestra su M291.
; Declarado en globals.g (centralización del "cerebro"); aquí solo se setea/lee.
; 28-sep (A6 + M1): el M150 solo al CAMBIAR de nivel. Con la tira por bit-bang cada M150 espera
; a que la máquina pare (LedStripManager.cpp:142-148): repetido en cada vuelta del bucle, frenaría
; el corte dos veces por segundo mientras dure el aviso.
; 3-oct: exists() delante (ver config.g): sin el sensor en la build, cada vuelta del daemon
; moría aquí y no llegaba nunca al vigilante de interfaz ni al de tensión.
if exists(boards[0].mcuTemp) && boards[0].mcuTemp.current > 65
    if global.thermalAlertLevel < 2
        M150 E0 R255 U50 B0 S25 F0   ; Rojo/Naranja intenso — CRÍTICO (>65°C)
        set global.thermalAlertLevel = 2
        M291 P"ALERTA CRÍTICA: Temperatura MCU > 65°C. Refrigeración insuficiente." R"Hardware" S1 T0
elif exists(boards[0].mcuTemp) && boards[0].mcuTemp.current > 55
    if global.thermalAlertLevel < 1
        M150 E0 R100 U30 B0 S25 F0   ; Naranja tenue — AVISO (>55°C)
        set global.thermalAlertLevel = 1
        M291 P"Aviso: Temperatura MCU > 55°C" R"Hardware" S1 T10
else
    ; Histéresis: apagar la alerta solo por debajo de 53°C (no a 55) para evitar
    ; el flip-flop si la temperatura oscila en el umbral — cada cruce recargaría
    ; los LEDs con un M98 desde la SD.
    if exists(boards[0].mcuTemp) && boards[0].mcuTemp.current < 53 && global.thermalAlertLevel > 0
        set global.thermalAlertLevel = 0
        M291 P"Temperatura MCU normalizada." R"Hardware" S1 T5
        ; Restaurar LEDs forzando una actualización a través del modo cinemático.
        ; ANTES sobrescribía el LED en TODOS los estados, compitiendo con el LED
        ; de pausa (naranja) o de procesamiento (cian) durante 500ms. Ahora solo
        ; restaura si la máquina está en IDLE — paused/processing ya tienen su
        ; LED correcto gobernado por pause.g/start.g.
        if exists(global.kinematicMode)
            if state.status == "idle"
                if global.kinematicMode == 1
                    M98 P"0:/sys/set_pro.g"
                else
                    M98 P"0:/sys/set_silk.g"

; ── Vigilante de tensión en marcha (V13, 15-sep) ──
; Antes solo reaccionaba M911 (~35 V en 48 V): entre el aviso (~44 V) y M911 nadie
; miraba vIn. Mismo patrón que la alerta térmica (niveles e histéresis) y que el
; vigilante de interfaz (M291 + M25 de un disparo; pause.g sube Z y luego M5).
; M911 sigue siendo la última línea. PENDIENTE BANCO: vinLowCycles y pausas falsas.
; globals.g declara en orden vinLow* < power_alert_* < psu_voltage: si existen el
; primero y el último, existen todos (config.g pudo fallar a mitad).
if exists(global.vinLowCount) && exists(global.psu_voltage) && exists(boards[0].vIn)
    var vin = boards[0].vIn.current
    var vErr = global.psu_voltage * global.power_alert_err
    var vWarn = global.psu_voltage * global.power_alert_warn
    ; Pausa: bajo el umbral de error durante vinLowCycles ciclos seguidos (filtra la
    ; caída transitoria del arranque del husillo).
    if state.status == "processing" && var.vin < var.vErr
        set global.vinLowCount = global.vinLowCount + 1
        if global.vinLowCount >= global.vinLowCycles
            M150 E0 R255 U40 B0 S25 F0
            M291 P{"Tension baja en marcha: " ^ var.vin ^ " V (umbral " ^ var.vErr ^ " V). Trabajo PAUSADO."} R"ALIMENTACION" S1 T0
            M25
            set global.lastBrownoutPause = state.upTime
            set global.vinLowCount = 0
    else
        set global.vinLowCount = 0
    ; Aviso sin pausa bajo el umbral de aviso, con histéresis de 1 V.
    if var.vin < var.vWarn && !global.vinWarnShown
        set global.vinWarnShown = true
        M291 P{"Aviso: tension " ^ var.vin ^ " V por debajo de " ^ var.vWarn ^ " V."} R"ALIMENTACION" S1 T10
    elif var.vin > var.vWarn + 1 && global.vinWarnShown
        set global.vinWarnShown = false

; ── Parada del job tras un trigger de emergencia ──
; 26-sep: trigger2.g ya manda su propio M25 en cuanto salta (pausa asíncrona, igual que
; un trigger T1; el «riesgo de bloqueo del RTOS» que se citaba aquí no aparece en el
; fuente de RRF 3.5.4). Esto queda como red por si aquel M25 no llegara a entrar: si el
; trabajo sigue corriendo, se pausa aquí (~500 ms).
if exists(global.emergencyStopJob) && global.emergencyStopJob
    set global.emergencyStopJob = false
    if state.status == "processing" || state.status == "resuming"
        M25

; ── Flag de homing huérfano ──
; Un G28 ABORTADO deja homingInProgress=true y, con el gate nuevo de trigger2.g,
; eso significa ESCUDO DESACTIVADO en silencio (y M581 posiblemente desarmados).
; Un homing real nunca está en "idle": si el flag sigue activo con la máquina
; idle, es huérfano → limpiar y re-armar el escudo (recover_triggers es idempotente).
if exists(global.homingInProgress) && global.homingInProgress && state.status == "idle"
    set global.homingInProgress = false
    M98 P"0:/sys/recover_triggers.g"
    ; 2-oct: un homing abortado tambien deja X/Y al 60 % de par (M913 del bump) y nada
    ; lo devolvia: el siguiente trabajo iba con el motor debil y perdia pasos.
    M400
    M913 X100 Y100 Z100
    echo "daemon: flag de homing huerfano limpiado — escudo re-armado y par al 100 %"

; ── Flag de escudo suprimido huérfano ──
; Si un palpado/SAC abortó por error dejó shieldSuppressed=true con la máquina
; idle: el escudo quedaría bajado para siempre. Limpiar y re-armar (mismo patrón
; que el homing huérfano). Si el carro quedó en X-max, el rearmado disparará la
; alarma X-MAX — correcto: el sensor SÍ está activo y la máquina está parada.
if exists(global.shieldSuppressed) && global.shieldSuppressed && state.status == "idle"
    set global.shieldSuppressed = false
    M98 P"0:/sys/recover_triggers.g"
    echo "daemon: flag de escudo suprimido huerfano limpiado — escudo re-armado"

; ── Persistencia de posición ──
; Guarda la posición actual en save_position.g (sin "d") para restaurar al
; arrancar. El escritor está en save_position.g; el lector en config.g.
; Usa global.posSaveCounter (declarado en config.g) como contador — `iterations`
; solo existe dentro de bucles while, NO en macros como daemon.g.
; Optimizado para evitar desgaste de SD y picos de latencia (chatter) durante corte:
;   - Solo guarda en estados estáticos (idle / paused) cada 15 ciclos (~15s).
;   - Solo escribe si la posición física real ha cambiado respecto al último guardado.
;   - En estado activo (processing / resuming) no escribe nada en la SD (el PLR
;     nativo Duet usa resurrect.g y la UI guarda su propio estado en localStorage).
if exists(global.posSaveCounter)
    if state.status == "idle" || state.status == "paused"
        set global.posSaveCounter = global.posSaveCounter + 1
        if global.posSaveCounter >= 15
            set global.posSaveCounter = 0
            if !exists(global.last_saved_x) || move.axes[0].machinePosition != global.last_saved_x || move.axes[1].machinePosition != global.last_saved_y || move.axes[2].machinePosition != global.last_saved_z
                set global.last_saved_x = move.axes[0].machinePosition
                set global.last_saved_y = move.axes[1].machinePosition
                set global.last_saved_z = move.axes[2].machinePosition
                M98 P"0:/sys/save_position.g"

; ── Watchdog de conectividad de la UI ──
; Durante un trabajo (processing) la UI manda un "latido" (set global.uiBeat =
; state.upTime) cada ~10 s. Si deja de llegar > global.uiWatchdogSec segundos, se
; asume que el operario perdió el control (móvil suspendido, WiFi caído) y se
; PAUSA el trabajo (M25 → pause.g sube Z y para el husillo). Reversible con M24.
; Desactivable con global.uiWatchdogOn = false. Guardado con exists() por si
; config.g falló y los globals no existen. Tras M25 el estado deja de ser
; "processing" → no se re-dispara en bucle.
if exists(global.uiWatchdogOn) && global.uiWatchdogOn && exists(global.uiBeat) && global.uiBeat > 0 && state.status == "processing"
    if (state.upTime - global.uiBeat) > global.uiWatchdogSec
        ; Ámbar parpadeante lento (F2 P255 = 1Hz) en vez de fijo. Comunica
        ; "atención, no alarma" — el operario distingue del rojo de emergencia
        ; y del ámbar de alerta térmica (que es continuo).
        M150 E0 R255 U40 B0 S25 F0
        M291 P"Se perdió la conexión con la interfaz. Trabajo PAUSADO por seguridad.<br>Reanuda (Resume / M24) cuando recuperes el control." R"WATCHDOG: UI DESCONECTADA" S1 T0
        M25
        ; Marca para que la UI, al re-conectar, distinga esta pausa de una pausa
        ; de operario y muestre un toast específico (rotechos.js — _onWatchdogPause).
        ; Se evalúa una vez por tick: tras el M25, state.status deja de ser
        ; "processing" y el if exterior ya no entra. Sin esto, la UI ve "PAUSADO"
        ; al volver sin contexto.
        set global.lastWatchdogPause = state.upTime



; ── Red: cliente del taller o red propia «RotechOS» (http://192.168.1.1) ──
; Se evalúa por etapas, una por tick, leyendo el estado REAL del módulo y sin G4.
; 5-oct (fuente RRF 3.5.4 del port STM32, WiFiInterface.cpp):
;  - El M587/M589 de wifi-passwords.g llamado desde config.g NO llega al módulo:
;    la red se activa al terminar config.g (RepRap.cpp:731) y SendCommand responde
;    «module is disabled» (WiFiInterface.cpp:2172). Por eso se aplica aquí, con el
;    módulo ya parado («idle»).
;  - M552 S2 se rechaza si el módulo no está en idle (WiFiInterface.cpp:1077), y
;    M552 S0 no corta un intento de conexión en curso (WiFiInterface.cpp:778). El
;    G4 S2 de antes perdía esa carrera y la máquina se quedaba sin cliente ni AP.
; Etapas (global.netStage): 0 esperando al cliente · 1 parando el módulo ·
; 2 AP pedido · 3 reintento de cliente con wifi-passwords.g. Se cierra al
; conectar (netApCheckDone); un microcorte posterior no saca la máquina de la red.
; 6-oct: con global.netApOnly (CONFIGURACIÓN → Red, «Trabajar siempre con la red
; propia») no se espera al cliente: se para el módulo y se levanta la red RotechOS
; en el primer tick. wifi-passwords.g se sigue aplicando (trae la clave del AP),
; pero sin reintentar el cliente. net_join.g y net_ap.g rearman estas etapas.
if exists(global.netStage) && !global.netApCheckDone
    var nst = network.interfaces[0].state
    var apOnly = exists(global.netApOnly) && global.netApOnly
    if global.netStage == 0
        if var.nst == "active" && !var.apOnly
            set global.netApCheckDone = true
        elif var.apOnly || state.upTime > 75 || (state.upTime > 35 && var.nst != "obtainingIP" && var.nst != "connected")
            if var.apOnly
                echo "daemon: red propia elegida, levantando la red RotechOS (http://192.168.1.1)"
            else
                echo "daemon: WiFi cliente sin conexion tras 35 s, preparando la red RotechOS (http://192.168.1.1)"
            M552 S0
            set global.netStage = 1
            set global.netStageT = state.upTime
    elif global.netStage == 1
        if var.nst == "active" && !var.apOnly
            ; conectó justo al pedir la parada: se conserva el cliente
            M552 S1
            set global.netApCheckDone = true
        elif var.nst == "idle"
            if !global.netFileApplied || !fileexists("0:/sys/wifi-passwords.g")
                M589 S"RotechOS" P"rotechos" I192.168.1.1
            if !global.netFileApplied && fileexists("0:/sys/wifi-passwords.g")
                set global.netFileApplied = true
                M98 P"0:/sys/wifi-passwords.g"
                if !var.apOnly
                    M552 S1
                    set global.netStage = 3
            if global.netStage != 3
                M552 S2
                set global.netStage = 2
            set global.netStageT = state.upTime
        elif state.upTime - global.netStageT > 15
            ; módulo apagado o aún arrancando: repetir la parada
            M552 S0
            set global.netStageT = state.upTime
    elif var.nst == "active"
        set global.netApCheckDone = true
        if global.netStage == 2
            set global.apModeActive = true
            M150 E0 R40 U0 B60 S25 F0
            echo "daemon: red RotechOS activa, conectate a ella y abre http://192.168.1.1"
    elif state.upTime - global.netStageT > 40
        set global.netTries = global.netTries + 1
        if global.netTries > 5
            set global.netApCheckDone = true
            M150 E0 R60 U0 B0 S25 F0
            echo "daemon: el modulo WiFi no levanta ni cliente ni la red RotechOS; revisa M122 por USB"
        else
            M552 S0
            set global.netStage = 1
            set global.netStageT = state.upTime

; ── Hook de extensión: user-daemon.g ──
; Si existe 0:/sys/user-daemon.g se ejecuta cada ciclo. Permite añadir tareas
; de fondo propias (experimentos, telemetría extra) SIN editar este archivo:
; las actualizaciones del daemon del sistema no pisan el código del usuario.
; Sin bucles infinitos dentro — este archivo ya itera solo.
; La existencia se cachea en global.userDaemonPresent al boot (config.g) para
; NO hacer un fileexists a la SD en cada tick (ahorro de I/O y latencia).
if exists(global.userDaemonPresent) && global.userDaemonPresent
    M98 P"0:/sys/user-daemon.g"

; La espera entre vueltas vive en daemon.g (28-sep, M1).
