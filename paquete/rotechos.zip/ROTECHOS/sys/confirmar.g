; ═══════════════════════════════════════════════════════════════
; confirmar.g  —  Aviso bloqueante cuyo Cancelar SÍ detiene lo que viene detrás
; Ruta: 0:/sys/confirmar.g
; Llamada: M98 P"0:/sys/confirmar.g" A{"mensaje"} B{"título"} C3     (C = modo: 2 o 3)
;          if !global.confirmado
;              abort "…"
; ═══════════════════════════════════════════════════════════════
; POR QUÉ EXISTE (26-sep, auditoría contra el fuente de RRF 3.5.4):
; en RRF, Cancelar un M291 bloqueante dentro de una macro sale SOLO de esa macro, y la que
; la llamó sigue (GCodes.cpp:465-485). Un `if result == -1` después del M291 no sirve: la
; macro ya ha salido. Por eso el aviso vive aquí dentro: si se cancela, la línea final no
; se ejecuta, `global.confirmado` se queda en false y el llamador lo ve y aborta.
; Y ningún aviso bloqueante es imposible de cancelar: M292 P1 cancela cualquiera
; (GCodes7.cpp:116-146), desde la interfaz, DWC o la pantalla física.
set global.confirmado = false
M291 P{param.A} R{param.B} S{param.C}
set global.confirmado = true
