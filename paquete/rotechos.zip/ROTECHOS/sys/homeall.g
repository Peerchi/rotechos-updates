; Marcar inicio de homing — bloquea trigger2.g durante la secuencia
set global.homingInProgress = true

; Guardia: verificar que el husillo está parado y la sonda Z inactiva
M98 P"0:/sys/guards/check_homing_safe.g"

; CINEMÁTICA SUAVE para el homing — independiente de en qué modo estuviera el
; usuario antes (SEDA/RAYO). Sin esto, el primer movimiento puede arrancar con
; jerk de RAYO (600 mm/s) y dar un golpe sonoro al absorber la holgura del
; acoplador. Estos valores son los más suaves del modo SEDA, ideales para
; acercarse a los topes mecánicos sin tirones.
M400                         ; vaciar cola antes de cambiar parámetros
M201 X{global.homing_accel_x} Y{global.homing_accel_y} Z{global.homing_accel_z}             ; aceleraciones suaves de homing
M566 X{global.homing_jerk_x} Y{global.homing_jerk_y} Z{global.homing_jerk_z} P1             ; jerk muy bajo → arranque sin golpe

; --- REDUCCIÓN DE CORRIENTE (Efecto muelle magnético) ---
; M913 literal = INTENCIONAL: la UI no expone M913 operativo (no es M906 RMS).
M400
M913 X60 Y60                 ; Torque X/Y al 60% para el bump; Z SE QUEDA AL 100%: retiene el peso del husillo (tornillo no autoblocante) y su sensor es inductivo (sin impacto). INTENCIONAL — no editable desde UI

; ORDEN CRÍTICO INDUSTRIAL: Z primero (subir herramienta), luego X, luego Y.
; Mover X/Y antes de Z arrastraría la fresa por la pieza/bridas → daño físico.

; --- Homing Z (tope superior = Z=0) ---
; Desactivar trigger ANTES de liberar pin — evita disparo falso por pin flotante
; 28-sep (revisión RRF, «R-1 en homing»): era `M581 Pn T2 R-1`. En RRF 3.5.4 la R es la
; condición del trigger ENTERO (TriggerItem.cpp:117-121) y S vale 1 si falta: apagaba los seis
; sensores y además AÑADÍA el pin. S-1 quita solo ese pin (TriggerItem.cpp:140-144).
M581 P3 T2 S-1               ; quitar SOLO el pin de Z Max del trigger 2
M581 P2 T2 S-1               ; quitar SOLO el pin de Z Min del trigger 2
M950 J3 C"nil"               ; liberar pin D.12 de GPIO
M574 Z2 S1 P"^D.12"          ; activar endstop Z Max (pin D.12 = sensor J3)
G91                                        ; relativo
; Recorrido dinámico = rango Z + 15mm margen (SSOT M208). Antes Z150 hardcoded.
; Fase Z con aceleración de palpado (200 mm/s²): con la accel de homing (12) el F
; estaba capado a ~350 para no sobrepasar el rango del inductivo al frenar; con 200,
; F1200 frena en ~1mm (v²/2a), dentro del margen de 5mm del sensor. Ahorra ~15s por
; homing. La fase X/Y no mueve Z y restore_kinematics lo repone al final.
M400
M201 Z{global.probe_accel_z}
G1 H1 Z{(0 - move.axes[2].min) + 15} F{global.z_raise_speed} ; buscar tope superior — recorrido dinámico
M400
if !move.axes[2].homed                ; el primer H1 no llegó al sensor (A1, 28-sep)
    M98 P"0:/sys/home_fail.g"
    abort "Homing Z fallido: no se detecto Z MAX en el recorrido. Revisa el sensor y su cable."
G1 Z{-global.homing_backoff_z} F{global.probe_backoff_speed} ; retroceder (libera el inductivo)
G1 H1 Z{global.homing_backoff_z * 4} F{global.probe_speed_slow} ; búsqueda lenta de precisión (mismo F que el palpado lento)
G90                          ; absoluto
; 28-sep (A1): sin G92. El G1 H1 que llega al sensor ya fija la posición y marca el eje; un
; G92 aquí lo daba por referenciado aunque el sensor no se hubiera detectado nunca.
M400
if !move.axes[2].homed
    M98 P"0:/sys/home_fail.g"
    abort "Homing Z fallido: no se detecto el final de carrera Z MAX. Revisa el sensor y su cable antes de volver a referenciar."
M574 Z0 S1                   ; deshabilitar endstop Z
; 28-sep: los pines de Z NO se rearman aquí. Z se queda en el punto de disparo de Z MAX (la
; búsqueda lenta para ahí) hasta el apartado del final: armarlo ahora haría que cualquier
; parpadeo del sensor durante el XY lanzara la parada. Antes pasaba lo mismo en la práctica:
; el `R-1` del XY apagaba el trigger entero. Los arma recover_triggers.g al final, con Z ya
; apartado. Durante el XY no vigila ningún sensor, como antes; el escudo vuelve entero al final.
M950 J3 C"^D.12"             ; re-registrar pin de Z Max como GPIO

; --- Homing SIMULTÁNEO X / Y (diagonal) ---
; Desactivar triggers de emergencia para ambos ejes
M581 P4 T2 S-1               ; quitar SOLO el pin de X Max del trigger 2
M581 P5 T2 S-1               ; quitar SOLO el pin de X Min del trigger 2
M581 P1 T2 S-1               ; quitar SOLO el pin de Y Max del trigger 2
M581 P0 T2 S-1               ; quitar SOLO el pin de Y Min del trigger 2

; Liberar pines y convertirlos en endstops
M950 J4 C"nil"               ; liberar pin C.6 de GPIO
M574 X2 S1 P"^C.6"           ; activar endstop X Max
M950 J1 C"nil"               ; liberar pin D.14 de GPIO
M574 Y2 S1 P"^D.14"          ; activar endstop Y Max

; Secuencia de palpado simultáneo
G91                          ; relativo
G1 H1 X{move.axes[0].max + 40} Y{move.axes[1].max + 40} F1000  ; búsqueda rápida diagonal
M400
if !move.axes[0].homed || !move.axes[1].homed                ; el primer H1 no llegó al sensor (A1, 28-sep)
    M98 P"0:/sys/home_fail.g"
    abort "Homing X/Y fallido: no se detecto X MAX o Y MAX en el recorrido. Revisa el sensor y su cable."
G1 X{-global.homing_backoff_xy} Y{-global.homing_backoff_xy} F{global.probe_backoff_speed} ; retroceder un poco ambos
G1 H1 X{global.homing_backoff_xy * 2} Y{global.homing_backoff_xy * 2} F{global.probe_speed_slow} ; búsqueda lenta de precisión simultánea
G90                          ; absoluto

; Establecer posiciones máximas
; 28-sep (A1): sin G92. El G1 H1 que llega al sensor ya fija la posición y marca el eje; un
; G92 aquí lo daba por referenciado aunque el sensor no se hubiera detectado nunca.
M400
if !move.axes[0].homed || !move.axes[1].homed
    M98 P"0:/sys/home_fail.g"
    abort "Homing X/Y fallido: no se detecto el final de carrera X MAX o Y MAX. Revisa el sensor y su cable antes de volver a referenciar."

; Apartar TODOS los ejes de sus sensores tras el homing → sensores libres ANTES de armar
G91
G1 Z{-global.homing_clearance_z} F{global.probe_backoff_speed}
G1 X{-global.homing_clearance_xy} Y{-global.homing_clearance_xy} F{global.probe_backoff_speed}
G90

; Restaurar hardware y escudo de forma centralizada
M574 X0 S1                   ; deshabilitar endstop X
M574 Y0 S1                   ; deshabilitar endstop Y
M98 P"0:/sys/recover_triggers.g"
; Restaurar M564 según las preferencias del user (NO forzar S1).
; Si el user desactivó soft limits, NUNCA se reactivan tras el homing.
M400
M564 H{global.requireHoming ? 1 : 0} S{global.softLimitsOn ? 1 : 0}   ; respeta preferencias del user

; --- RESTAURAR CORRIENTE AL 100% ---
; INTENCIONAL: cinemática de homing, no editable desde UI.
M400
M913 X100 Y100 Z100             ; INTENCIONAL — restauración tras bump de homing

; Restaurar la cinemática del modo activo (SEDA/RAYO) tras el homing.
M98 P"0:/sys/restore_kinematics.g"

; --- Homing eje A (4º motor, opcional) — solo si está configurado y sin referenciar ---
if #move.axes > 3 && !move.axes[3].homed
  M98 P"0:/sys/homea.g"

; Finalizar homing — restaurar trigger2.g y marcar X como referenciado
set global.homingInProgress = false
set global.xHomed = true

; --- RETROALIMENTACIÓN DE ÉXITO (LEDs y Zumbador) ---
M98 P"0:/sys/home_feedback_success.g"
