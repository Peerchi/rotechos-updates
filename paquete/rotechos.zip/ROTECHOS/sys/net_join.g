; net_join.g — une la máquina a una red WiFi desde la interfaz, sin USB.
; La llama CONFIGURACIÓN → Red con:  M98 P"0:/sys/net_join.g" S"<red>" K"<clave>"
; (K y no P: en M98 la P es el fichero.)
; M587 solo llega al módulo con el módulo parado («idle»), como en daemon_tick.g:
; primero se para (el AP o el cliente actual se cae), se guarda la red y se pide el
; cliente. El resultado lo vigila daemon_tick.g en su etapa 3: si en 40 s no hay
; conexión, vuelve a levantar la red RotechOS (http://192.168.1.1). Nunca hace
; falta el USB para salir de una clave mal escrita.
; PENDIENTE BANCO: lo que tarda de verdad el ESP32 en parar y en asociar.
if !exists(param.S) || !exists(param.K)
    abort "net_join.g: faltan la red (S) y la clave (K)"
set global.netApCheckDone = true          ; el vigilante de red, quieto mientras se cambia
M552 S0
while network.interfaces[0].state != "idle" && iterations < 40
    G4 P250
M587 S{param.S} P{param.K}
set global.netApOnly = false
set global.apModeActive = false
set global.netTries = 0
M552 S1
set global.netStage = 3
set global.netStageT = state.upTime
set global.netApCheckDone = false
