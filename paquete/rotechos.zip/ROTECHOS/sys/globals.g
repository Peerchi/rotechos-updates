; sys/globals.g
; CEREBRO VIRTUAL ROTECHOS — Declaración centralizada de variables globales
; Ruta: 0:/sys/globals.g

; --- Versión ---
; Sincronizada con sys/VERSION (auditoria estado del arte jul-2026, H8):
; VERSION = 2026-06-12, globals.g era 2026-06-21 (9 dias de drift). Canon: globals.g
; (RRF lo lee al boot; VERSION es solo display).
global fwVersion = "2026-10-09"

; --- Identidad de la máquina ---
; Nombre que el usuario le pone a SU fresadora desde CONFIGURACIÓN. La UI lo
; persiste con `set global.machineName = "X"` al final de config-machine.g
; (cfgPersistStringGlobal → cfgSetGlobal, rotechos-config-persist.js).
; Se declara AQUÍ y vacío porque en RRF un `set` sobre un global no declarado
; es un error: abortaría config-machine.g en esa línea. Y como cfgSetGlobal
; inyecta cada global nuevo JUSTO DESPUÉS del último `set global.`, esta línea
; rota se tragaría en silencio todos los globals per-máquina que se persistan
; después (soft-limits, sonda, perfil RAYO). Vacío = "sin nombrar todavía".
global machineName = ""

; --- Watchdog de Conectividad ---
global uiBeat = 0
global uiWatchdogSec = 30
global uiWatchdogOn = true
; lastWatchdogPause: upTime (state.upTime, segundos desde boot) en el que el watchdog
; de UI pausó el trabajo por última vez. El cliente (rotechos.js) lo lee en cada
; poll y, si crece, muestra un toast específico "Pausa por pérdida de UI". Se
; resetea a 0 al arrancar un trabajo nuevo (start.g) o al cancelar (cancel.g)
; para no arrastrar la pausa entre trabajos.
global lastWatchdogPause = 0
; --- Vigilante de tensión en marcha (V13, 15-sep; lo lee daemon.g) ---
; vinLowCycles: ciclos seguidos bajo psu_voltage*power_alert_err antes de pausar.
; daemon.g espera 500 ms por ciclo en processing: 4 son ~2 s. PENDIENTE BANCO: medir
; la caída real al arrancar el husillo y en los rápidos, y ajustar este valor.
; lastBrownoutPause: upTime de la última pausa por tensión (como lastWatchdogPause).
global vinLowCount = 0
global vinLowCycles = 4
global vinWarnShown = false
global lastBrownoutPause = 0
; apModeActive: true si el firmware levantó el AP propio (192.168.1.1). Lo escribe
; daemon.g al detectar que el cliente WiFi no conectó tras 35 s. Lo lee network.g
; para discriminar el render del módulo de red.
global apModeActive = false
; netApCheckDone: one-shot para que la rama de fallback a AP se evalúe SOLO una
; vez por arranque (un microcorte en marcha no debe sacar la máquina de la red).
global netApCheckDone = false
; netStage/netStageT/netTries/netFileApplied: etapas de la red en daemon_tick.g
; (0 esperando cliente, 1 parando el módulo, 2 AP pedido, 3 reintento de cliente).
global netStage = 0
global netStageT = 0
global netTries = 0
global netFileApplied = false
; netApOnly: true = trabajar siempre con la red propia «RotechOS» (sin WiFi en el
; taller). De fábrica, true desde el 8-oct (decisión de Sergi): la máquina arranca
; directamente en su red, sin credenciales de nadie. Unirse a una WiFi desde
; CONFIGURACIÓN → Red guarda false en config-machine.g, que se carga después.
; daemon_tick.g lo lee para levantar el AP sin esperar al cliente.
global netApOnly = true

; --- Parámetros de Homing ---
global homing_accel_x = 30
global homing_accel_y = 30
global homing_accel_z = 12
global homing_jerk_x = 3
global homing_jerk_y = 3
global homing_jerk_z = 1

; --- Holguras y Retornos de Fin de Carrera (Homing) ---
global homing_backoff_z = 2
global homing_backoff_xy = 5
global homing_clearance_z = 10
global homing_clearance_xy = 10

; --- Factores de Alerta de Alimentación ---
global power_alert_warn = 0.916   ; ~44V / 48V
global power_alert_err = 0.83     ; ~40V / 48V
global power_alert_min = 0.73     ; ~35V / 48V

; --- Perfil RAYO (PRO) ---
; Los globals *_a se RE-DECLARAN (2026-07-12, fix A-1 del audit del 4º eje).
; La eliminación de jul-2026 (H9) dejaba dos minas: (a) al activar el eje A
; desde la UI, set_pro/set_silk/ramp_to_* los consumen tras `if #move.axes > 3`
; y reventarían con "unknown variable" en CADA arranque de trabajo; (b) el
; pro_params_saved.g que genera la UI al guardar VELOCIDADES escribe
; `set global.pro_*_a` SIEMPRE, y config.g lo ejecuta en el boot sin guard.
; Declarar un global sin eje mapeado es inocuo para RRF (es una variable
; suelta) — la nota de H9 ("RRF rechaza variables sin driver") era incorrecta.
; Defaults del eje A: CONSERVADORES, rotativo en grados (deg/s² / deg/min),
; coherentes con los defaults de la UI (config-modal). AJUSTAR EN BANCO.
; PENDIENTE DE BANCO (verificar boot limpio con y sin eje A en M584)
global pro_accel_x = 1000
global pro_accel_y = 1000
global pro_accel_z = 150
global pro_accel_a = 500
global pro_jerk_x = 600
global pro_jerk_y = 600
global pro_jerk_z = 60
global pro_jerk_a = 600

; --- Perfil SEDA (SILK) ---
global silk_accel_x = 60
global silk_accel_y = 60
global silk_accel_z = 20
global silk_accel_a = 60
global silk_jerk_x = 80
global silk_jerk_y = 80
global silk_jerk_z = 25
global silk_jerk_a = 60

; --- Estado y Banderas Cinematográficas ---
global kinematicMode = 0
global xHomed = false
global homingInProgress = false
global emergencyStopJob = false
global abortRequested = false
global shieldSuppressed = false
global requireHoming = true
global softLimitsOn = true
; 15-sep (B6): nace en false. Solo integrity_check.g lo pone a true al final de config.g;
; si config.g se corta antes del chequeo, start.g no deja mecanizar sin protecciones.
global integrityOk = false
; firstBootCompleted: solo se escribe desde rotechos-modules.js (wizard paso 11).
; No hay lector activo en firmware ni UI; candidato a eliminación cuando se
; decida el alcance. Mantener para no romper el setter del wizard.
global firstBootCompleted = false
global psu_voltage = 48
; --- Alerta térmica MCU (nivel 0=normal, 1=aviso>55, 2=crítico>65) ---
; Antes declarado en daemon.g:16-17; centralizado aquí para mantener el principio
; "cerebro en globals.g". El if !exists() defensivo en daemon.g se mantiene.
global thermalAlertLevel = 0
global posSaveCounter = 0
; Cache del hook user-daemon.g (seteado en config.g al boot). True = existe
; 0:/sys/user-daemon.g. Usado por daemon.g para NO hacer fileexists por tick.
global userDaemonPresent = false

; --- Palpado (Probing) y SAC ---
global z_sensor_to_table = 5
global touchplate_thickness = 0
global sac_enabled = true
; 4-oct: husillo de dial manual (Makita). Solo lo lee la interfaz: M3/M5 no lo mueven.
global spindleManual = false
global sac_z0_surface = false
global probe_speed_fast = 400
global probe_speed_slow = 100
; 3-oct: tope de velocidad de palpado (mm/min). G38.x ignora su F y usa la de M558; config.g
; copia aquí la F de M558 tras cargar config-machine.g y probe_speed.g no la supera nunca.
global probeSpeedCap = 120
global probe_backoff_dist1 = 3
global probe_backoff_dist2 = 2
global probe_backoff_speed = 800
global probe_accel_z = 200
global probe_accel_xy = 200
global probe_tolerance = 0.15
global probe_trigger_z = 0
global probe_x_backoff = 25
global probe_edge_depth = 2
global probe_max_passes = 5
; probe_timeout_ms (t_014cd150, §4.8): tiempo máximo de palpado en ms. Si la
; sonda no hace contacto en este tiempo, la macro aborta. Rango válido 1000–30000.
; Default 10000 ms (10 s) — suficiente para velocidades lentas sin atascar al operario.
global probe_timeout_ms = 10000

; --- Spindle y Cambios de Herramienta ---
global next_tool_description = ""
global spindle_ramp_time = 1500
global spindle_cooldown_ms = 1500
global tool_change_y = 30
; tool_sensor_y: posición Y del sensor fijo del SAC (tool length setter).
; FALLBACK NEUTRO = 0. La posición REAL es per-máquina y la siembra
; config-machine.g al calibrar (integrity_check exige Y ∈ [Ymin, Ymax];
; con el área conservadora de config.g, Ymin=-100 e Ymax=100, así que 0
; está dentro). Si config-machine.g sobreescribe el área al rango real
; de la fresadora, ese mismo config-machine.g reasigna tool_sensor_y al
; valor correcto cerca del borde Y — los dos van siempre juntos.
global tool_sensor_y = 0

; --- Calentamiento del Spindle (Warmup) ---
global warmup_step_time = 4
global warmup_hold_time = 10

; --- Viajes y Despejes en Vacío ---
global safe_clearance = 10
global z_raise_speed = 1000
global travel_feed = 4000
global travel_accel = 2000

; --- VSSC (Variable Spindle Speed Control) ---
global vssc_on = false
global vssc_period_ms = 4000
global vssc_variance = 200
global vssc_base_rpm = 0
global vssc_t0 = 0

; --- Viajes Protegidos ---
global protected_move_tol = 0.1

; --- Palpado Automático de Esquina ---
global autoProbeEnabled = false
global probe_corner_dist = 25
global probe_corner_backoff = 4
global probe_tip_radius = 0
global probe_dir_x = 1
global probe_dir_y = 1
global pause_x = 0
global pause_y = 0
global pause_kinematicMode = 0
; B-H4.3 (auditoria 15-sep): si el husillo estaba PARADO al pausar, resume.g no
; debe encenderlo. Se arranca a 1 —«encender»— a proposito: ese es el
; comportamiento de siempre, asi que si por cualquier camino pause.g no llegara
; a escribir esta global, se reanuda como hasta hoy. El fallo por defecto tiene
; que ser el conocido: reanudar SIN husillo con el trabajo cortando rompe fresa
; y pieza, y eso es peor que encenderlo de mas.
global pause_spindle_active = 1

; --- Historial de Posición Guardada (SD Wear Prevention) ---
global last_saved_x = -99999
global last_saved_y = -99999
global last_saved_z = -99999

; --- Malla de Palpado (Heightmap del material) --------------------------
; 3-oct: era UN global de tipo objeto, `global mesh = {xmin=0, …}`. RRF 3.5.4 no tiene
; objetos literales: `{xmin=0…}` se lee como la variable `xmin`, que no existe
; (ExpressionParser.cpp:273-275 y ObjectModel.cpp:1280), y un error de ese tipo aborta el
; fichero Y TODOS SUS LLAMADORES (GCodes.cpp:686-691 y GCodeBuffer.cpp:1026-1043). Como
; globals.g es la línea 1 de config.g, la placa arrancaba sin el resto de config.g: sin
; motores mapeados, sin husillo y sin WiFi. Tampoco existe `set global.mesh.ok` (solo
; global.NOMBRE con índices, StringParser.cpp:730-800). Ahora son globals sueltos:
;   meshXmin/meshXmax/meshYmin/meshYmax — área a palpar (mm, MCS)
;   meshNx/meshNy        — nº de puntos (cuadrícula N×M)
;   meshFast/meshSlow    — velocidades de palpado (mm/min)
;   meshSafeZ            — altura segura de viaje (mm, positivo)
;   meshPoints           — CSV de lecturas Z, fila a fila (fila*nx + columna)
;   meshCurrent          — índice del punto en curso (0..nx*ny-1)
;   meshFailedIndex      — punto que falló (-1 si ok)
;   meshOk               — malla válida (true/false)
;   meshMargin           — margen al borde M208 (mm); solo lo lee la UI
;   meshAbort            — lo pone la interfaz al cancelar (ver abajo)
; La unidad `tests/unit/globales-ui-declarados.test.js` exige que cualquier `set global.X`
; que la UI mande al firmware tenga su X declarado aquí.
; 16-sep (C19): `abort` lo pone la interfaz al cancelar y lo consulta mesh_probe.g en cada
; punto. Sin el, cancelar solo apagaba el seguimiento de la interfaz y la sonda seguia bajando.
; 26-sep: fichas de «esto llegó al final». Cancelar un M291 dentro de una macro sale solo de
; ella y el llamador sigue (GCodes.cpp:465-485): confirmar.g y probe_z_sensor.g ponen su ficha
; a true en su ÚLTIMA línea, y quien las llama aborta si sigue en false.
; 28-sep (R2 de la revisión de la integración): lados del escudo M581 que tienen sensor.
; Bit n = entrada Jn (J0 Y MIN=1, J1 Y MAX=2, J2 Z MIN=4, J3 Z MAX=8, J4 X MAX=16, J5 X MIN=32).
; Por defecto los tres MAX (2+8+16 = 26): son los sensores que referencian (M574 X2 Y2 Z2 en
; homex/homey/homez.g) y los que lleva la máquina. 5-oct: antes era 63, y una SD con un
; config-machine.g anterior al 28-sep (sin esta línea) bloqueaba TODOS los trabajos, porque
; un lado sin sensor, con pull-up, lee 1 siempre. La interfaz lo guarda por máquina en
; config-machine.g al guardar CONFIGURACIÓN → Endstops; los MIN se añaden allí.
global shieldMask = 26
; Lados cuyo sensor es NO (normalmente abierto), mismos bits. Con pull-up, un NC lee 1 al
; dispararse (o con el cable cortado) y un NO lee 0. Por defecto todos NC (0).
global shieldNoMask = 0
global confirmado = false
global probeOk = false
global meshXmin = 0
global meshXmax = 0
global meshYmin = 0
global meshYmax = 0
global meshNx = 5
global meshNy = 5
global meshFast = 600
global meshSlow = 200
global meshSafeZ = 5
global meshPoints = ""
global meshCurrent = 0
global meshFailedIndex = -1
global meshOk = false
global meshMargin = 10
global meshAbort = false
