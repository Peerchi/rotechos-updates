; ventiladores_rescate.g — pone los ventiladores de AUX1 cuando config.g no los trae (18-oct-2026)
; Ruta: 0:/sys/ventiladores_rescate.g · lo llama daemon_tick.g UNA vez por arranque.
; Por qué existe: el bloque de ventiladores entró en config.g el 6-oct, pero a una máquina ya
; instalada no le llega ningún config.g nuevo por deploy.sh (copia config.g con
; --ignore-existing) ni por las OTA anteriores a la fusión del 17-oct (no escribían config.g).
; En esas máquinas F1 no existe: los ventiladores no arrancan nunca, ni a 45 °C ni a 60, y el
; `M106 P1 T` de config-machine.g da error al arrancar. Este fichero sí llega por las dos vías.
; Si config.g ya creó F1 no hace nada: el SSOT del bloque sigue siendo config.g (pin, sensores,
; umbral de fábrica). Mantener los dos iguales; tests/unit/firmware-aux1-fan.test.js lo vigila.
; Orden: primero el ventilador, luego los sensores. Un H que apunta a un sensor que no existe
; deja el ventilador al 100 % (LocalFan.cpp, RRF 3.5.4): si un M308 falla, quedan encendidos.
; Limitación: un umbral distinto de 45 guardado desde la interfaz no se recupera aquí (su
; `M106 P1 T` en config-machine.g falló al arrancar); se reaplica al volver a Guardar la pestaña.
if exists(fans[1]) && fans[1] != null
    M99
M950 F1 C"A.5"
M106 P1 C"Electronica" S1 H10 T45
if !exists(sensors.analog[10]) || sensors.analog[10] == null
    M308 S10 Y"mcu-temp" A"MCU"
if !exists(sensors.analog[11]) || sensors.analog[11] == null
    M308 S11 Y"drivers" A"Drivers"
M106 P1 S1 H10:11
echo "Ventiladores AUX1 configurados desde ventiladores_rescate.g: el config.g de esta maquina no los trae."
