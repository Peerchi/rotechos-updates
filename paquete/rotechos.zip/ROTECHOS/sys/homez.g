; homez.g — homing eje Z independiente (tope superior = Z=0)
set global.homingInProgress = true

; Guardia: verificar que el husillo está parado y la sonda Z inactiva
M98 P"0:/sys/guards/check_homing_safe.g"

; Cinemática suave de homing — evita golpe en arranque (ver homeall.g)
M400
M201 Z{global.probe_accel_z}  ; accel de palpado para la fase Z (ver homeall.g) — Z12 capaba el F a ~350
M566 Z{global.homing_jerk_z} P1

; --- REDUCCIÓN DE CORRIENTE (Efecto muelle magnético) ---
; M913 literal = INTENCIONAL: la UI no expone M913 operativo (no es M906 RMS).
M400
M913 X60 Y60                 ; Z al 100%: retiene el peso del husillo; el sensor Z es inductivo (sin impacto). INTENCIONAL — no editable desde UI

; Desactivar triggers M581 ANTES del unbinding (evita disparos falsos transitorios)
; 28-sep (revisión RRF, «R-1 en homing»): era `M581 Pn T2 R-1`. En RRF 3.5.4 la R es la
; condición del trigger ENTERO (TriggerItem.cpp:117-121) y S vale 1 si falta: apagaba los seis
; sensores y además AÑADÍA el pin. S-1 quita solo ese pin (TriggerItem.cpp:140-144).
M581 P2 T2 S-1               ; quitar SOLO el pin de Z Min del trigger 2
M581 P3 T2 S-1               ; quitar SOLO el pin de Z Max del trigger 2
; Liberar pin D.12 del GPIO J3 antes de usarlo como endstop
M950 J3 C"nil"               ; liberar pin D.12 de GPIO
M574 Z2 S1 P"^D.12"          ; activar endstop Z Max (pin D.12 = sensor J3)

G91
; 3-oct (H1.3 del veredicto): aquí había un `G1 Z-10` «por si ya estuviera tocando». Con Z sin
; referenciar (G28 Z lo desmarca antes, GCodes.cpp:3310-3315) y M564 H1, RRF lo rechaza con
; «insufficient axes homed» (GCodes.cpp:2249-2252) y la macro sigue; con «Requerir HOME»
; apagado, bajaba 10 mm a ciegas, con la fresa quizá encima de la pieza. Sobra: si el sensor ya
; está pisado, el G1 H1 de abajo termina al instante y marca el eje (DDA.cpp:1855-1864), y el
; retroceso y la búsqueda lenta dan la precisión. homeall.g ya lo hacía así.
; Recorrido dinámico = rango Z + 15mm margen (SSOT M208). Antes Z150 hardcoded.
G1 H1 Z{(0 - move.axes[2].min) + 15} F{global.z_raise_speed} ; buscar tope superior (H1 = endstop máximo) — recorrido dinámico
M400
if !move.axes[2].homed                ; el primer H1 no llegó al sensor (A1, 28-sep)
    M98 P"0:/sys/home_fail.g"
    abort "Homing Z fallido: no se detecto Z MAX en el recorrido. Revisa el sensor y su cable."
G1 Z{-global.homing_backoff_z} F{global.probe_backoff_speed}                                ; retroceder 2mm (libera el inductivo; sobre-recorrido ~1mm)
G1 H1 Z{global.homing_backoff_z * 4} F{global.probe_speed_slow}                              ; búsqueda lenta de precisión (mismo F que el palpado lento)
G90
; 28-sep (A1): sin G92. El G1 H1 que llega al sensor ya fija la posición y marca el eje; un
; G92 aquí lo daba por referenciado aunque el sensor no se hubiera detectado nunca.
M400
if !move.axes[2].homed
    M98 P"0:/sys/home_fail.g"
    abort "Homing Z fallido: no se detecto el final de carrera Z MAX. Revisa el sensor y su cable antes de volver a referenciar."

; Apartar Z un poco del tope ANTES de armar alarmas
G91
G1 Z{-global.homing_backoff_z - 1} F{global.probe_backoff_speed}
G90

; Restaurar escudo de hardware centralizado
M574 Z0 S1                   ; deshabilitar endstop Z
M98 P"0:/sys/recover_triggers.g"

; --- RESTAURAR CORRIENTE AL 100% ---
; INTENCIONAL: cinemática de homing, no editable desde UI.
M400
M913 X100 Y100 Z100             ; INTENCIONAL — restauración tras bump de homing

; Restaurar cinemática del modo activo (SEDA=0 / RAYO=1)
M98 P"0:/sys/restore_kinematics.g"

set global.homingInProgress = false

; --- RETROALIMENTACIÓN DE ÉXITO (coherente con homeall.g) ---
M98 P"0:/sys/home_feedback_success.g"
