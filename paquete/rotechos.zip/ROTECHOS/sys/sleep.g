; sleep.g - Modo reposo de la maquina
M5                           ; apagar spindle
M84 X Y                      ; soltar X/Y. Z SIEMPRE energizado: el tornillo no es autoblocante
                             ; y sin par el husillo cae (config.g:111-114). 2-oct: era M84 a secas
M150 E0 R0 U0 B8 S25 F0      ; Azul muy tenue — máquina en reposo pero viva
M291 P"Modo reposo activado. Motores desactivados." R"REPOSO" S0 T4