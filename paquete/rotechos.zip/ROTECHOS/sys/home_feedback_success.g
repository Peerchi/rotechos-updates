; sys/home_feedback_success.g
; Retroalimentación de éxito (LED verde, pitido y restauración de color)

M150 R0 U255 B0 P255 F0 S25      ; LED verde sólido
M300 S2000 P150                  ; Pitido de éxito
G4 P600                          ; Mostrar verde por 0.6s
M98 P"0:/sys/restore_kinematics.g" ; Restaurar color del perfil/modo activo
