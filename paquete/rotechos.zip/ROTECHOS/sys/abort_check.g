;  abort_check.g — Punto de control de aborto cooperativo (escudo de seguridad)
;  Ruta: 0:/sys/abort_check.g  ·  Llamada: M98 P"0:/sys/abort_check.g"
;
;  Las macros de MOVIMIENTO lo llaman entre fases. Si un final de carrera disparo
;  el escudo (trigger2.g puso global.abortRequested), corta el flujo de la macro
;  para que NO siga moviendo. trigger2 ya hizo M5 (husillo) + subir Z; aqui solo se
;  aborta la pila. Aborto SUAVE: vuelve a idle, sin halt ni reset.
;
;  POR QUE hace falta: fuera de un trabajo nada vacia la cola desde un trigger (el M410
;  que se creia que lo hacia no existe en RRF 3.5.4, ver trigger2.g) y el interprete de
;  la macro sigue leyendo lineas y encolando mas G1. Este check detiene la macro. (M25 solo pausa JOBS de archivo,
;  no macros M98 — por eso una macro chocaba sin detenerse.)
;
;  17-oct (A3/N-H1): ahora lo llaman tambien el HOME y el palpado, que QUITAN pines del escudo
;  (M581 S-1), registran finales como endstop (M574) y bajan el par (M913). `abort` corta la
;  pila entera (GCodes::AbortPrint -> AbortFile(true)), asi que nada de eso se restauraria
;  despues: se deja todo como home_fail.g ANTES de abortar. No mueve nada (trigger2.g ya subio Z).
;  El escudo se rearma aunque un sensor siga pisado: RRF lee el estado de partida sin disparar
;  (TriggerItem.cpp, Configure), y salir del sensor tampoco dispara (solo el flanco de entrada).
;  Lo que el llamador cambie aparte (cero de pieza, flags propios) lo restaura el propio llamador
;  antes de llamar aqui; ver probe_z_sensor.g.
if exists(global.abortRequested) && global.abortRequested
    set global.abortRequested = false
    ; recover_triggers.g baja homingInProgress: se lee antes
    var era_home = exists(global.homingInProgress) && global.homingInProgress
    G90
    M400
    M574 X0 S1                       ; ningun final queda como endstop de homing
    M574 Y0 S1
    M574 Z0 S1
    M98 P"0:/sys/recover_triggers.g" ; rearma los M581 (y los pines GPIO) del escudo
    M913 X100 Y100 Z100              ; INTENCIONAL — deshacer el 60 % del bump de homing
    if exists(global.homingInProgress)
        set global.homingInProgress = false
    if var.era_home && exists(global.xHomed)   ; G28 desmarca el eje: que la interfaz no lo dé por referenciado
        set global.xHomed = move.axes[0].homed
    M150 R255 U0 B0 P255 F0 S25      ; LED rojo: parada de seguridad
    M98 P"0:/sys/restore_kinematics.g" ; 1-nov: el palpado XY deja su M201; abort no vuelve al llamador
    abort "Operacion cancelada — final de carrera de seguridad disparado"
