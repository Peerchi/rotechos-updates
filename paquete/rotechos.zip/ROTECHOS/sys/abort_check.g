;  abort_check.g — Punto de control de aborto cooperativo (escudo de seguridad)
;  Ruta: 0:/sys/abort_check.g  ·  Llamada: M98 P"0:/sys/abort_check.g"
;
;  Las macros de MOVIMIENTO lo llaman entre fases. Si un final de carrera disparo
;  el escudo (trigger2.g puso global.abortRequested), corta el flujo de la macro
;  para que NO siga moviendo. trigger2 ya hizo M5 (husillo) + subir Z; aqui solo se
;  aborta la pila. Aborto SUAVE: vuelve a idle, sin halt ni reset.
;
;  POR QUE hace falta: fuera de un trabajo nada vacia la cola desde un trigger (el M410
;  que se creia que lo hacia no existe en RRF 3.5.4, ver trigger2.g) y el interprete de
;  la macro sigue leyendo lineas y encolando mas G1. Este check detiene la macro. (M25 solo pausa JOBS de archivo,
;  no macros M98 — por eso una macro chocaba sin detenerse.)
if exists(global.abortRequested) && global.abortRequested
    set global.abortRequested = false
    abort "Operacion cancelada — final de carrera de seguridad disparado"
