; Ethernet DHCP/router o directo al PC con IP fija.
;   M98 P"0:/sys/ethernet.g" D0    router/LAN con DHCP
;   M98 P"0:/sys/ethernet.g" D1    directo al PC: CNC 192.168.50.1/24
;   M98 P"0:/sys/ethernet.g" S0    dejar Ethernet y volver a WiFi/AP
if !exists(global.netEthernet)
  abort "ethernet.g: reinicia la placa para terminar de actualizar"
if state.status == "processing" || state.status == "paused"
  abort "ethernet.g: no se cambia de red con un trabajo en marcha"
if exists(param.D) && param.D != 0 && param.D != 1
  abort "ethernet.g: D debe ser 0 (router) o 1 (directo al PC)"
set global.netApCheckDone = true
set global.netTries = 0
set global.netStageT = state.upTime
set global.netEthFailed = false
if exists(param.S) && param.S == 0
  set global.netEthernet = false
  set global.netEthProfileClear = true
  set global.netEthernetDirect = false
  set global.netStage = 4
  set global.netStageT = state.upTime
  M552 S-1
  if fileexists("0:/sys/net-ethernet.g")
    M30 "0:/sys/net-ethernet.g"
  if fileexists("0:/sys/net-ethernet-direct.g")
    M30 "0:/sys/net-ethernet-direct.g"
else
  set global.netEthernetDirect = exists(param.D) && param.D == 1
  set global.netEthProfileClear = false
  set global.apModeActive = false
  set global.netEthernet = true
  set global.netStage = 6
  M552 S-1
  M552 S0
set global.netApCheckDone = false
