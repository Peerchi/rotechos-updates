; ethernet.g — pasar a Ethernet o dejar de usarlo, desde CONFIGURACIÓN → Red.
;   M98 P"0:/sys/ethernet.g"       prueba Ethernet ahora
;   M98 P"0:/sys/ethernet.g" S0    deja de usarlo y vuelve a la WiFi o a la red RotechOS
; Solo pide el cambio. Lo hace daemon_tick.g, que da 60 s para tener IP y SOLO ENTONCES
; escribe 0:/sys/net-ethernet.g: si falla, no queda nada guardado y vuelve a la red de
; antes. Requiere el firmware WiFiModule_esp32eth.bin en el módulo (GUIA_INSTALACION).
if !exists(global.netEthernet)
  abort "ethernet.g: reinicia la placa para terminar de actualizar"
if state.status == "processing" || state.status == "paused"
  abort "ethernet.g: no se cambia de red con un trabajo en marcha"
set global.netTries = 0
set global.netStageT = state.upTime
set global.netEthFailed = false
if exists(param.S) && param.S == 0
  set global.netEthernet = false
  if fileexists("0:/sys/net-ethernet.g")
    M30 "0:/sys/net-ethernet.g"
  set global.netStage = 4
  M552 S-1
else
  set global.apModeActive = false
  set global.netEthernet = true
  set global.netStage = 0
set global.netApCheckDone = false
