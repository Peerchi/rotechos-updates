; ═══════════════════════════════════════════════════════════════
; protected_travel.g — Viaje vigilado por la sonda (colisión = parada + abort)
; Ruta: 0:/sys/protected_travel.g
; Llamada: M98 P"0:/sys/protected_travel.g" X{..} Y{..} Z{..} F{feed}
;          Coordenadas MÁQUINA (MCS) absolutas; los ejes son opcionales
;          (el omitido mantiene su posición actual). F opcional (def. 1000).
;
; G38.3 viaja hacia el destino VIGILANDO la sonda 0: si dispara por el camino,
; el movimiento PARA sin error de firmware. Después se compara la posición final
; con el destino (tolerancia global.protected_move_tol): si no coinciden, algo
; se tocó antes de llegar → M291 + abort (detiene también a la macro llamadora).
;
; SOLO tiene sentido cuando el elemento sensor VIAJA CON LA HERRAMIENTA
; (palpador 3D / fresa conductiva: probe3d.g, probe_xy_auto.g). NO protege nada
; con el sensor fijo de mesa (SAC/sonda Z): ese solo dispara con la fresa encima.
; ═══════════════════════════════════════════════════════════════

if !exists(param.X) && !exists(param.Y) && !exists(param.Z)
    abort "protected_travel: indica al menos un eje destino (X/Y/Z, coords máquina)"

if sensors.probes[0].value[0] > 0
    M291 P"Viaje protegido cancelado: la sonda YA está disparada antes de moverse.<br>Separa el palpador / revisa el cable." R"VIAJE PROTEGIDO" S1 T0
    abort "protected_travel: sonda disparada antes del viaje"

M400                          ; 3-oct: posición real, no la de la cola
var tx = exists(param.X) ? param.X : move.axes[0].machinePosition
var ty = exists(param.Y) ? param.Y : move.axes[1].machinePosition
var tz = exists(param.Z) ? param.Z : move.axes[2].machinePosition
var tf = exists(param.F) ? param.F : 1000

G90
; 3-oct: G38.x ignora su F y usa la de M558 (ver probe_speed.g); por eso la velocidad va aparte.
M98 P"0:/sys/probe_speed.g" F{var.tf}
G53 G38.3 K0 X{var.tx} Y{var.ty} Z{var.tz}
M400

var tol = exists(global.protected_move_tol) ? global.protected_move_tol : 0.1
if abs(move.axes[0].machinePosition - var.tx) > var.tol || abs(move.axes[1].machinePosition - var.ty) > var.tol || abs(move.axes[2].machinePosition - var.tz) > var.tol
    var travelErr = "COLISIÓN en viaje protegido: el palpador tocó algo ANTES de llegar al destino."
    set var.travelErr = var.travelErr ^ "<br>La máquina ha parado en el punto de contacto."
    set var.travelErr = var.travelErr ^ " Revisa la zona, sube Z y reposiciona."
    M291 P{var.travelErr} R"VIAJE PROTEGIDO - COLISIÓN" S1 T0
    abort "protected_travel: posición final != destino — contacto inesperado"
