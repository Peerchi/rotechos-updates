; ═══════════════════════════════════════════════════════════════
; integrity_check.g — Validación de coherencia al arrancar
; Ruta: 0:/sys/integrity_check.g
; Llamado al final de config.g.
;
; OBJETIVO: detectar configuraciones incoherentes (M208 inválido, corrientes
; fuera de rango, RPM ilegal, globals corruptos) ANTES de que el operario
; intente mecanizar.
;
; Si encuentra problemas:
;   1. set global.integrityOk = false
;   2. Muestra M291 bloqueante (S2) listando los errores
;   3. start.g se niega a iniciar mecanizado mientras integrityOk = false
;
; Si todo OK: echo silencioso + global.integrityOk = true
; ═══════════════════════════════════════════════════════════════

; Acumulador de errores (string concatenado)
; F7 informe v2: partir el M291 final en dos si >256 chars (limite RRF).
; var.errors se conserva para el test sintético (scripts/test_integrity_check.js).
; var.msgA lleva los primeros 3 mensajes, var.msgB el resto; decision por
; contador var.msgCount. Sin len()/slicing (no validados en RRF 3.5.4 segun
; subset de Sergi en el test sintactico). var.errors se reconstruye al final.
; Empeor caso escenario 7 errores: parte 1 = 249 chars (CABE), parte 2 = 297
; chars (puede truncarse en ~41 chars). Es MEJOR que el original (481 chars
; truncados en un solo M291), pero no garantiza 0 truncado con >6 errores.
; Patron: GCK-1 / 7a2cd39 (var + concatenacion).
var errors = ""
var msgCount = 0
var msgA = ""
var msgB = ""

; ── 1. Soft limits coherentes (M208): max > min en cada eje ──
if move.axes[0].max <= move.axes[0].min
    set var.msgCount = var.msgCount + 1
    if var.msgCount <= 3
        set var.msgA = var.msgA ^ "• Eje X: M208 max (" ^ move.axes[0].max ^ ") <= min (" ^ move.axes[0].min ^ ")<br>"
    else
        set var.msgB = var.msgB ^ "• Eje X: M208 max (" ^ move.axes[0].max ^ ") <= min (" ^ move.axes[0].min ^ ")<br>"
    set var.errors = var.errors ^ "• Eje X: M208 max (" ^ move.axes[0].max ^ ") <= min (" ^ move.axes[0].min ^ ")<br>"
if move.axes[1].max <= move.axes[1].min
    set var.msgCount = var.msgCount + 1
    if var.msgCount <= 3
        set var.msgA = var.msgA ^ "• Eje Y: M208 max (" ^ move.axes[1].max ^ ") <= min (" ^ move.axes[1].min ^ ")<br>"
    else
        set var.msgB = var.msgB ^ "• Eje Y: M208 max (" ^ move.axes[1].max ^ ") <= min (" ^ move.axes[1].min ^ ")<br>"
    set var.errors = var.errors ^ "• Eje Y: M208 max (" ^ move.axes[1].max ^ ") <= min (" ^ move.axes[1].min ^ ")<br>"
if move.axes[2].max <= move.axes[2].min
    set var.msgCount = var.msgCount + 1
    if var.msgCount <= 3
        set var.msgA = var.msgA ^ "• Eje Z: M208 max (" ^ move.axes[2].max ^ ") <= min (" ^ move.axes[2].min ^ ")<br>"
    else
        set var.msgB = var.msgB ^ "• Eje Z: M208 max (" ^ move.axes[2].max ^ ") <= min (" ^ move.axes[2].min ^ ")<br>"
    set var.errors = var.errors ^ "• Eje Z: M208 max (" ^ move.axes[2].max ^ ") <= min (" ^ move.axes[2].min ^ ")<br>"

; ── 2. Corrientes M906 dentro del límite RMS del TMC2160 (4700mA) ──
if move.axes[0].current > 4700
    set var.msgCount = var.msgCount + 1
    if var.msgCount <= 3
        set var.msgA = var.msgA ^ "• X: corriente " ^ move.axes[0].current ^ "mA > 4700 mA (límite TMC2160)<br>"
    else
        set var.msgB = var.msgB ^ "• X: corriente " ^ move.axes[0].current ^ "mA > 4700 mA (límite TMC2160)<br>"
    set var.errors = var.errors ^ "• X: corriente " ^ move.axes[0].current ^ "mA > 4700 mA (límite TMC2160)<br>"
if move.axes[1].current > 4700
    set var.msgCount = var.msgCount + 1
    if var.msgCount <= 3
        set var.msgA = var.msgA ^ "• Y: corriente " ^ move.axes[1].current ^ "mA > 4700 mA<br>"
    else
        set var.msgB = var.msgB ^ "• Y: corriente " ^ move.axes[1].current ^ "mA > 4700 mA<br>"
    set var.errors = var.errors ^ "• Y: corriente " ^ move.axes[1].current ^ "mA > 4700 mA<br>"
if move.axes[2].current > 4700
    set var.msgCount = var.msgCount + 1
    if var.msgCount <= 3
        set var.msgA = var.msgA ^ "• Z: corriente " ^ move.axes[2].current ^ "mA > 4700 mA<br>"
    else
        set var.msgB = var.msgB ^ "• Z: corriente " ^ move.axes[2].current ^ "mA > 4700 mA<br>"
    set var.errors = var.errors ^ "• Z: corriente " ^ move.axes[2].current ^ "mA > 4700 mA<br>"

; ── 3. Corrientes mínimas razonables (>200mA) — drivers no responderán bien por debajo ──
if move.axes[0].current < 200
    set var.msgCount = var.msgCount + 1
    if var.msgCount <= 3
        set var.msgA = var.msgA ^ "• X: corriente " ^ move.axes[0].current ^ "mA demasiado baja (mínimo 200)<br>"
    else
        set var.msgB = var.msgB ^ "• X: corriente " ^ move.axes[0].current ^ "mA demasiado baja (mínimo 200)<br>"
    set var.errors = var.errors ^ "• X: corriente " ^ move.axes[0].current ^ "mA demasiado baja (mínimo 200)<br>"
if move.axes[1].current < 200
    set var.msgCount = var.msgCount + 1
    if var.msgCount <= 3
        set var.msgA = var.msgA ^ "• Y: corriente " ^ move.axes[1].current ^ "mA demasiado baja<br>"
    else
        set var.msgB = var.msgB ^ "• Y: corriente " ^ move.axes[1].current ^ "mA demasiado baja<br>"
    set var.errors = var.errors ^ "• Y: corriente " ^ move.axes[1].current ^ "mA demasiado baja<br>"
if move.axes[2].current < 200
    set var.msgCount = var.msgCount + 1
    if var.msgCount <= 3
        set var.msgA = var.msgA ^ "• Z: corriente " ^ move.axes[2].current ^ "mA demasiado baja<br>"
    else
        set var.msgB = var.msgB ^ "• Z: corriente " ^ move.axes[2].current ^ "mA demasiado baja<br>"
    set var.errors = var.errors ^ "• Z: corriente " ^ move.axes[2].current ^ "mA demasiado baja<br>"

; ── 4. Spindle RPM en rango legal (6000-24000) ──
if #spindles > 0
    if spindles[0].max < 6000
        set var.msgCount = var.msgCount + 1
        if var.msgCount <= 3
            set var.msgA = var.msgA ^ "• Spindle max " ^ spindles[0].max ^ " RPM < 6000 (mín. seguridad refrigeración)<br>"
        else
            set var.msgB = var.msgB ^ "• Spindle max " ^ spindles[0].max ^ " RPM < 6000 (mín. seguridad refrigeración)<br>"
        set var.errors = var.errors ^ "• Spindle max " ^ spindles[0].max ^ " RPM < 6000 (mín. seguridad refrigeración)<br>"
    if spindles[0].max > 24000
        set var.msgCount = var.msgCount + 1
        if var.msgCount <= 3
            set var.msgA = var.msgA ^ "• Spindle max " ^ spindles[0].max ^ " RPM > 24000 (fuera de rango fabricante)<br>"
        else
            set var.msgB = var.msgB ^ "• Spindle max " ^ spindles[0].max ^ " RPM > 24000 (fuera de rango fabricante)<br>"
        set var.errors = var.errors ^ "• Spindle max " ^ spindles[0].max ^ " RPM > 24000 (fuera de rango fabricante)<br>"
    if spindles[0].min < 6000
        set var.msgCount = var.msgCount + 1
        if var.msgCount <= 3
            set var.msgA = var.msgA ^ "• Spindle min " ^ spindles[0].min ^ " RPM < 6000 (riesgo quemar motor por bajas RPM)<br>"
        else
            set var.msgB = var.msgB ^ "• Spindle min " ^ spindles[0].min ^ " RPM < 6000 (riesgo quemar motor por bajas RPM)<br>"
        set var.errors = var.errors ^ "• Spindle min " ^ spindles[0].min ^ " RPM < 6000 (riesgo quemar motor por bajas RPM)<br>"

; ── 5. Globals críticos de palpado y herramienta ──
; z_sensor_to_table puede ser negativo (sensor bajo mártir) o positivo (sensor sobre mártir),
; pero NUNCA cero (cero = sin offset = error de configuración).
if global.z_sensor_to_table == 0
    set var.msgCount = var.msgCount + 1
    if var.msgCount <= 3
        set var.msgA = var.msgA ^ "• global.z_sensor_to_table es 0 — debe ser ≠ 0 (positivo si sensor sobre mártir, negativo si bajo él)<br>"
    else
        set var.msgB = var.msgB ^ "• global.z_sensor_to_table es 0 — debe ser ≠ 0 (positivo si sensor sobre mártir, negativo si bajo él)<br>"
    set var.errors = var.errors ^ "• global.z_sensor_to_table es 0 — debe ser ≠ 0 (positivo si sensor sobre mártir, negativo si bajo él)<br>"
if global.safe_clearance <= 0
    set var.msgCount = var.msgCount + 1
    if var.msgCount <= 3
        set var.msgA = var.msgA ^ "• global.safe_clearance debe ser > 0 (es " ^ global.safe_clearance ^ ")<br>"
    else
        set var.msgB = var.msgB ^ "• global.safe_clearance debe ser > 0 (es " ^ global.safe_clearance ^ ")<br>"
    set var.errors = var.errors ^ "• global.safe_clearance debe ser > 0 (es " ^ global.safe_clearance ^ ")<br>"

; ── 6. Posiciones de cambio de herramienta dentro del área de trabajo ──
if global.touchplate_thickness < 0
    set var.msgCount = var.msgCount + 1
    if var.msgCount <= 3
        set var.msgA = var.msgA ^ "• global.touchplate_thickness (" ^ global.touchplate_thickness ^ ") no puede ser negativo (0 = sin pastilla, es válido)<br>"
    else
        set var.msgB = var.msgB ^ "• global.touchplate_thickness (" ^ global.touchplate_thickness ^ ") no puede ser negativo (0 = sin pastilla, es válido)<br>"
    set var.errors = var.errors ^ "• global.touchplate_thickness (" ^ global.touchplate_thickness ^ ") no puede ser negativo (0 = sin pastilla, es válido)<br>"
; NOTA: tool_sensor_x ELIMINADO — M6.g usa move.axes[0].max directamente, no
;       hay global que validar (M208 ya garantiza coherencia consigo mismo).
if global.tool_sensor_y < move.axes[1].min || global.tool_sensor_y > move.axes[1].max
    set var.msgCount = var.msgCount + 1
    if var.msgCount <= 3
        set var.msgA = var.msgA ^ "• global.tool_sensor_y (" ^ global.tool_sensor_y ^ ") fuera del rango Y<br>"
    else
        set var.msgB = var.msgB ^ "• global.tool_sensor_y (" ^ global.tool_sensor_y ^ ") fuera del rango Y<br>"
    set var.errors = var.errors ^ "• global.tool_sensor_y (" ^ global.tool_sensor_y ^ ") fuera del rango Y<br>"
; NOTA: change_x/change_y eliminados — la posición de cambio de herramienta es
; dinámica en M6.g (X = move.axes[0].max / 2, Y = 20). No hay globals que validar.

; ── 7. Parámetros RAYO (PRO mode) razonables ──
if global.pro_accel_x <= 0 || global.pro_accel_y <= 0 || global.pro_accel_z <= 0
    set var.msgCount = var.msgCount + 1
    if var.msgCount <= 3
        set var.msgA = var.msgA ^ "• Aceleraciones PRO deben ser > 0<br>"
    else
        set var.msgB = var.msgB ^ "• Aceleraciones PRO deben ser > 0<br>"
    set var.errors = var.errors ^ "• Aceleraciones PRO deben ser > 0<br>"
if global.pro_jerk_x <= 0 || global.pro_jerk_y <= 0 || global.pro_jerk_z <= 0
    set var.msgCount = var.msgCount + 1
    if var.msgCount <= 3
        set var.msgA = var.msgA ^ "• Jerks PRO deben ser > 0<br>"
    else
        set var.msgB = var.msgB ^ "• Jerks PRO deben ser > 0<br>"
    set var.errors = var.errors ^ "• Jerks PRO deben ser > 0<br>"

; ── 7b. Parámetros SEDA (SILK mode) razonables ──
; Sin este check, user podría dejar silk_accel_x=0 (vía mcfgM201X) y set_silk.g
; aplicaría aceleración cero → motor se queda inmóvil en jog manual.
if global.silk_accel_x <= 0 || global.silk_accel_y <= 0 || global.silk_accel_z <= 0
    set var.msgCount = var.msgCount + 1
    if var.msgCount <= 3
        set var.msgA = var.msgA ^ "• Aceleraciones SILK deben ser > 0<br>"
    else
        set var.msgB = var.msgB ^ "• Aceleraciones SILK deben ser > 0<br>"
    set var.errors = var.errors ^ "• Aceleraciones SILK deben ser > 0<br>"
if global.silk_jerk_x <= 0 || global.silk_jerk_y <= 0 || global.silk_jerk_z <= 0
    set var.msgCount = var.msgCount + 1
    if var.msgCount <= 3
        set var.msgA = var.msgA ^ "• Jerks SILK deben ser > 0<br>"
    else
        set var.msgB = var.msgB ^ "• Jerks SILK deben ser > 0<br>"
    set var.errors = var.errors ^ "• Jerks SILK deben ser > 0<br>"

; ── 8. (retirado el 2-oct-2026) Drivers físicos funcionales ──
; Leía boards[0].drivers[N].state, que NO existe en RRF 3.5.4: el único campo es
; `status`, un mapa de bits numérico (Platform.cpp:374), y las expresiones de RRF no
; tienen operadores de bits para leerlo. La línea daba error de expresión al arrancar,
; integrity_check.g no llegaba a poner integrityOk = true y start.g bloqueaba todos los
; trabajos. El fallo de driver lo sigue avisando RRF por su cuenta (mensajes de
; driver_error / M122); la comprobación queda para el banco.

; ── 9. Tensión de alimentación >= 35V (48V nominal, M911 dispara a 35V) ──
; Umbral derivado de psu_voltage (mismo factor 0.73 que M911; fallback 35 = sistema 48V)
var vinMin = (exists(global.psu_voltage) && exists(global.power_alert_min)) ? global.psu_voltage * global.power_alert_min : 35
if exists(boards[0].vIn) && boards[0].vIn.current < var.vinMin   ; 3-oct: exists(), ver config.g
    ; 3-oct: casi 0 V con la placa encendida = fuente de 48 V apagada o Vin sin medir en esta build
    var vinWhy = (boards[0].vIn.current < 5) ? " (¿fuente de 48V apagada, o la placa no mide Vin? ver guion de banco)" : " (alimentación inestable)"
    set var.msgCount = var.msgCount + 1
    if var.msgCount <= 3
        set var.msgA = var.msgA ^ "• Vin " ^ boards[0].vIn.current ^ "V < " ^ var.vinMin ^ "V" ^ var.vinWhy ^ "<br>"
    else
        set var.msgB = var.msgB ^ "• Vin " ^ boards[0].vIn.current ^ "V < " ^ var.vinMin ^ "V" ^ var.vinWhy ^ "<br>"
    set var.errors = var.errors ^ "• Vin " ^ boards[0].vIn.current ^ "V < " ^ var.vinMin ^ "V" ^ var.vinWhy ^ "<br>"

; ── 10. MCU no en thermal warning ──
if exists(boards[0].mcuTemp) && boards[0].mcuTemp.current > 70   ; 3-oct: exists(), ver config.g
    set var.msgCount = var.msgCount + 1
    if var.msgCount <= 3
        set var.msgA = var.msgA ^ "• MCU " ^ boards[0].mcuTemp.current ^ "°C — temperatura crítica al arranque<br>"
    else
        set var.msgB = var.msgB ^ "• MCU " ^ boards[0].mcuTemp.current ^ "°C — temperatura crítica al arranque<br>"
    set var.errors = var.errors ^ "• MCU " ^ boards[0].mcuTemp.current ^ "°C — temperatura crítica al arranque<br>"

; ── 11. (retirado 9-oct-2026) ──
; Aquí se avisaba de cualquier eje X/Y/Z en el driver P0, porque en la placa
; anterior de Sergi ese driver estaba quemado. Con placa nueva X vuelve a P0
; (config.g, M584 X0 Y1 Z2) y el aviso saltaría en cada arranque. Un driver
; dañado se veta per-máquina en config-machine.g (`; rotech-banned-drivers=`).

; ── 12. Globals críticos presentes (config.g desactualizado / backup viejo) ──
; Si falta alguno, se restauró un config.g antiguo o la copia a la SD fue parcial:
; las macros que los usan fallarían con errores crípticos a mitad de operación.
if !exists(global.safe_clearance) || !exists(global.travel_feed) || !exists(global.probe_speed_fast) || !exists(global.probe_speed_slow)
    set var.msgCount = var.msgCount + 1
    if var.msgCount <= 3
        set var.msgA = var.msgA ^ "• Faltan globals de movimiento/palpado — config.g DESACTUALIZADO (¿backup viejo o copia parcial?)<br>"
    else
        set var.msgB = var.msgB ^ "• Faltan globals de movimiento/palpado — config.g DESACTUALIZADO (¿backup viejo o copia parcial?)<br>"
    set var.errors = var.errors ^ "• Faltan globals de movimiento/palpado — config.g DESACTUALIZADO (¿backup viejo o copia parcial?)<br>"
if !exists(global.probe_tolerance) || !exists(global.z_sensor_to_table) || !exists(global.tool_sensor_y) || !exists(global.spindle_ramp_time)
    set var.msgCount = var.msgCount + 1
    if var.msgCount <= 3
        set var.msgA = var.msgA ^ "• Faltan globals del SAC/sonda — config.g DESACTUALIZADO<br>"
    else
        set var.msgB = var.msgB ^ "• Faltan globals del SAC/sonda — config.g DESACTUALIZADO<br>"
    set var.errors = var.errors ^ "• Faltan globals del SAC/sonda — config.g DESACTUALIZADO<br>"

; ── VEREDICTO ──
if var.msgCount == 0
    set global.integrityOk = true
    echo "Integrity check: [OK]"
else
    set global.integrityOk = false
    ; Reconstruir var.errors desde msgA ^ msgB (orden original preservado: 3 primeros a A, resto a B)
    set var.errors = var.msgA ^ var.msgB
    ; M291 parte 1: los primeros mensajes que cupieron en var.msgA (máx 3)
    M291 P{"<b>CONFIGURACIÓN INCOHERENTE</b><br><br>" ^ var.msgA ^ "<br>El mecanizado está bloqueado hasta corregir estos errores en la configuración."} R"INTEGRITY CHECK — ARRANQUE" S2
    ; M291 parte 2: solo si hay overflow (var.msgB no vacío)
    if var.msgB != ""
        M291 P{var.msgB ^ "<br>FIN — corrige también los anteriores."} R"INTEGRITY CHECK — CONTINUACIÓN" S2
    echo "Integrity check: [FAIL] — revisa M291"
