; ═══════════════════════════════════════════════════════════════
; restore_kinematics.g — Restaura M201/M566 según el modo cinemático activo
; Ruta: 0:/sys/restore_kinematics.g   ·   Llamada con: M98 P"0:/sys/restore_kinematics.g"
;
; Aplica aceleración (M201) y jerk (M566) de TODOS los ejes según
; global.kinematicMode (0 = SEDA / 1 = RAYO), leyendo los globals editables
; por el usuario (silk_* / pro_*).
;
; IMPORTANTE — por qué NO se usa set_pro.g / set_silk.g aquí:
;   Aquellos, además de M201/M566, CAMBIAN global.kinematicMode y el LED. Este
;   macro es solo-cinemática (no toca modo ni LED), pensado para restaurar al
;   final de homing y palpado sin efectos colaterales.
; ═══════════════════════════════════════════════════════════════
M400 ; sync movement queue before changing parameters
if global.kinematicMode == 1
    if #move.axes > 3
        M201 X{global.pro_accel_x} Y{global.pro_accel_y} Z{global.pro_accel_z} A{global.pro_accel_a}
        M566 X{global.pro_jerk_x} Y{global.pro_jerk_y} Z{global.pro_jerk_z} A{global.pro_jerk_a} P1
    else
        M201 X{global.pro_accel_x} Y{global.pro_accel_y} Z{global.pro_accel_z}
        M566 X{global.pro_jerk_x} Y{global.pro_jerk_y} Z{global.pro_jerk_z} P1
else
    if #move.axes > 3
        M201 X{global.silk_accel_x} Y{global.silk_accel_y} Z{global.silk_accel_z} A{global.silk_accel_a}
        M566 X{global.silk_jerk_x} Y{global.silk_jerk_y} Z{global.silk_jerk_z} A{global.silk_jerk_a} P1
    else
        M201 X{global.silk_accel_x} Y{global.silk_accel_y} Z{global.silk_accel_z}
        M566 X{global.silk_jerk_x} Y{global.silk_jerk_y} Z{global.silk_jerk_z} P1
