; recover_triggers.g — Restaura los 6 triggers M581 a su estado operativo normal
; Llamado desde stop.g, cancel.g y start.g (defensa en profundidad: arma el escudo M581).
;
; ORDEN CRÍTICO: primero liberar endstops (M574 *0), luego re-registrar pines como
; GPIO (M950 J*), y finalmente activar los triggers (M581).
; NOTA: J6/J7 (PD_15/PD_13) ELIMINADOS — colisionan con SPI del TMC2160 Z.

; 1. Liberar endstops por si quedaron registrados (homing abortado)
M574 X0 S1
M574 Y0 S1
M574 Z0 S1

; 2. Re-registrar pines como GPIO puro con Pull-Up activo
M950 J0 C"^A.8"       ; Y Min  (PA_8)
M950 J1 C"^D.14"      ; Y Max  (PD_14)
M950 J2 C"^C.7"       ; Z Min  (PC_7)
M950 J3 C"^D.12"      ; Z Max  (PD_12)
M950 J4 C"^C.6"       ; X Max  (PC_6, con pull-up)
M950 J5 C"^D.11"      ; X Min  (PD_11)

; 3. Reactivar triggers M581 SOLO en los lados con sensor (global.shieldMask, ver globals.g).
; 28-sep (R2): antes se armaban los seis. Un lado sin sensor no aporta protección y start.g lo
; leía como «final de carrera activo». S-1 quita ese pin sin tocar el resto del trigger
; (TriggerItem.cpp:140-148); R0 (sin condición) va en cada pin armado.
; J0 Y Min · J1 Y Max · J2 Z Min · J3 Z Max · J4 X Max · J5 X Min
; Tipo por lado (global.shieldNoMask): NC dispara al pasar a 1 (S1), NO al pasar a 0 (S0).
var shRest = 63
if exists(global.shieldMask)
    set var.shRest = global.shieldMask
var shNo = 0
if exists(global.shieldNoMask)
    set var.shNo = global.shieldNoMask
while iterations < 6
    if mod(var.shRest, 2) == 1
        M581 P{iterations} T2 S{mod(var.shNo, 2) == 1 ? 0 : 1} R0
    else
        M581 P{iterations} T2 S-1
    set var.shRest = floor(var.shRest / 2)
    set var.shNo = floor(var.shNo / 2)

; 4. Limpiar de forma segura los flags de estado para garantizar que el escudo se activa
if exists(global.abortRequested)
    set global.abortRequested = false
if exists(global.homingInProgress)
    set global.homingInProgress = false
if exists(global.shieldSuppressed)
    set global.shieldSuppressed = false

; 5. Confirmación visual: parpadeo verde rápido = escudo M581 ARMADO
M150 R0 U255 B0 P255 F0 S25      ; LED verde sólido
G4 P150                          ; mantener 0.15s
M98 P"0:/sys/restore_kinematics.g" ; devolver color al modo activo (SEDA/RAYO)
