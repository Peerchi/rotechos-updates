; ═══════════════════════════════════════════════════════════════
; z_safe_raise.g — Subida Z RELATIVA para despejar la fresa del material.
; Ruta: 0:/sys/z_safe_raise.g   ·   Llamada con: M98 P"0:/sys/z_safe_raise.g"
;
; Fuente ÚNICA de la "subida de seguridad relativa" (DRY). La usan pause.g, stop.g
; y cancel.g. Sube solo si los ejes están referenciados Y hay espacio (no demasiado
; cerca del tope). Sube global.safe_clearance mm a global.z_raise_speed.
;   - Umbral: solo sube si estás a más de safe_clearance del tope (machinePosition <
;     max - safe_clearance), si no, no hay sitio y se omite.
; Es un RETROCESO (alejarse del material) → seguro aunque el husillo siga girando.
; ═══════════════════════════════════════════════════════════════
if move.axes[2].homed && move.axes[2].machinePosition < (move.axes[2].max - global.safe_clearance)
    G91
    G1 Z{global.safe_clearance} F{global.z_raise_speed}
    G90
else
    echo "z_safe_raise.g: subida Z omitida — sin homing o demasiado cerca del tope"
