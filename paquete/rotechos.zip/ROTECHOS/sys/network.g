; network.g — Feedback visual LED al cambiar estado de red
; Ruta: 0:/sys/network.g
; Se ejecuta automaticamente cuando cambia la conexion WiFi (RRF 3.x)
;
; Variables RRF3:
;   network.interfaces[0].state    → "active" | "idle" | "connecting" | "disabled"
;   network.interfaces[0].actualIP → IP asignada ("0.0.0.0" si no hay)

; El modo AP lo firma la IP 192.168.1.1 (no el state del interfaz ni el global
; apModeActive a secas). Motivo: cuando el operario abandona el AP y se reconecta
; a la red del taller, daemon.g ya puso apModeActive=true al levantar el AP
; y nadie lo bajaba → network.g pintaba violeta estando ya en cliente. La IP
; del AP es la firma inequívoca. state=="active" lo es en AMBOS modos.
if network.interfaces[0].actualIP == "192.168.1.1" || (exists(global.apModeActive) && global.apModeActive)
    ; Punto de Acceso activo: violeta = modo configuración/commissioning
    M150 E0 R40 U0 B60 S25 F0
    echo "RotechOS: Punto de Acceso activo — conectate a la red 'RotechOS' y abre http://192.168.1.1"
elif network.interfaces[0].state == "active"
    ; Conexión cliente establecida: verde breve
    M150 E0 R0 U60 B0 S25 F0
    echo "RotechOS: WiFi conectado —" , network.interfaces[0].actualIP
    if exists(global.apModeActive) && global.apModeActive
        set global.apModeActive = false
        echo "RotechOS: bandera apModeActive limpiada — operario reconectado a la red del taller"
elif network.interfaces[0].state == "connecting"
    ; Intentando conectar: ámbar
    M150 E0 R64 U32 B0 S25 F0
    echo "RotechOS: Conectando a WiFi..."
else
    ; Sin red (idle / disabled): rojo tenue
    M150 E0 R20 U0 B0 S25 F0
    echo "RotechOS: WiFi desconectado"
