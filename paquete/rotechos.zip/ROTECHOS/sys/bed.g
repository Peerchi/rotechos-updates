; bed.g - Nivelacion de cama (no aplica en CNC)
; Este archivo existe porque RRF lo espera. No se ejecuta.