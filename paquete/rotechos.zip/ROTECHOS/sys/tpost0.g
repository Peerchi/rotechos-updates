; tpost0.g - Post-seleccion herramienta T0
; En CNC con una sola herramienta, no se requiere accion