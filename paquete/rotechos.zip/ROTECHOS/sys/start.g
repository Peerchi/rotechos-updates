; start.g - Inicializacion antes de comenzar trabajo
; Ejecutado automáticamente cuando se inicia un mecanizado

; GUARDIA: integridad de configuración (integrity_check.g al arrancar la máquina)
; Si la configuración tenía errores en boot, NO permitir mecanizar hasta corregir.
if !exists(global.integrityOk) || !global.integrityOk
    M291 P"La configuración tiene errores detectados al arrancar.<br>Revisa el aviso de INTEGRITY CHECK y corrige antes de mecanizar." R"ERROR: INTEGRIDAD" S1 T0
    abort "Trabajo cancelado: integrity_check falló al arrancar"

; 15-sep (B2): una caída de tensión que no llega a apagar la placa ejecuta la acción de
; M911 (M913 X0 Y0): X/Y quedan sin par y pierden pasos. Nada devolvía la corriente.
; Se devuelve y se exige homing (M18 quita la referencia): los pasos perdidos no vuelven.
if exists(move.axes[0].percentCurrent) && (move.axes[0].percentCurrent < 100 || move.axes[1].percentCurrent < 100)
    M400
    M913 X100 Y100 Z100
    M18 X Y
    M291 P"X/Y se quedaron sin corriente (caída de tensión).<br>Haz Homing antes de mecanizar." R"ERROR: SIN PAR" S1 T0
    abort "Trabajo cancelado: X/Y sin corriente tras caída de tensión (G28 requerido)"

; GUARDIA: verificar homing si "Requerir HOME" está activado
; exists() defensivo: si config.g abortó antes de declararlo, FALLAR SEGURO (= exigir homing)
if !exists(global.requireHoming) || global.requireHoming
    if !move.axes[0].homed || !move.axes[1].homed || !move.axes[2].homed
        M291 P"Los ejes deben tener referencia (Homing) antes de iniciar el mecanizado." R"ERROR: SIN HOMING" S1 T10
        abort "Trabajo cancelado: ejes sin referenciar (G28 requerido)"

; 27-sep (revisión de la integración, R3): el microajuste Z (M290) de un trabajo anterior sigue
; puesto hasta un reinicio o un PARO (GCodes.cpp:261), y el siguiente trabajo saldría desplazado.
; Se deja a 0 al empezar. R0 = valor absoluto.
M290 R0 Z0

; Garantizar el escudo de emergencia (triggers M581) ARMADO antes de mecanizar. Cierra el
; hueco en que un homing ABORTADO (entre que homeall quita y re-arma los triggers) deja la
; maquina sin parada por sensor. recover_triggers.g es idempotente; re-armar no molesta.
M98 P"0:/sys/recover_triggers.g"
; 26-sep (auditoría contra RRF 3.5.4, M4): al rearmar, RRF lee el estado de partida SIN
; disparar (TriggerItem.cpp:171-172): un sensor ya pisado, o con el cable cortado (lógica NC:
; 1 = disparado o abierto, ver health_check.g), no avisaría y el trabajo arrancaría con ese
; lado ciego. Se comprueban los del escudo (J0..J5 = gpIn[0..5]) antes de mecanizar.
; 28-sep (R2): SOLO los lados con sensor (global.shieldMask). Un lado sin sensor, con pull-up,
; lee 1 siempre, y el bucle viejo abortaba TODOS los trabajos de una máquina con finales solo
; en MAX.
var shRest = 63
if exists(global.shieldMask)
    set var.shRest = global.shieldMask
var shNo = 0
if exists(global.shieldNoMask)
    set var.shNo = global.shieldNoMask
while iterations < 6
    if mod(var.shRest, 2) == 1 && sensors.gpIn[iterations] != null && sensors.gpIn[iterations].value == (mod(var.shNo, 2) == 1 ? 0 : 1)
        M291 P{"Final de carrera activo o cable cortado (entrada J" ^ iterations ^ "). Liberalo o revisa el cable. Si ese lado no tiene sensor, desactivalo en CONFIGURACION > Endstops y guarda."} R"ERROR: SENSOR ACTIVO" S1 T0
        abort "Trabajo cancelado: final de carrera activo al empezar"
    set var.shRest = floor(var.shRest / 2)
    set var.shNo = floor(var.shNo / 2)

; LEDs cian eléctrico (trabajando)
M150 R0 U40 B64 S25 F0
M150 F1

; Activar perfil RAYO con transición suave SEDA→RAYO (ramp_to_pro.g interpola en 15 pasos, ~600ms)
; Elimina el "golpe" mecánico/acústico al arrancar. set_pro.g canónico vive en sys/.
if fileexists("0:/sys/ramp_to_pro.g")
    M98 P"0:/sys/ramp_to_pro.g"
elif fileexists("0:/sys/set_pro.g")
    M98 P"0:/sys/set_pro.g"
else
    abort "Falta set_pro.g en SD — no se puede iniciar trabajo sin perfil cinemático"

; Chopper mode (D2 SpreadCycle) se fija UNA SOLA VEZ en config.g — NO se toca en
; runtime (en la Scylla, reemitir M569 reinicia el TMC2160 → glitch). set_pro.g
; NO cambia el chopper mode.

; Modo offline por defecto: el watchdog de UI se desactiva hasta que la UI web envíe el primer latido.
if exists(global.uiBeat)
    set global.uiBeat = 0
; Limpiar la marca del watchdog (HALLAZGO-5 informe 2026-08-17): un trabajo
; previo pudo haber sido pausado por pérdida de UI; sin este reset el toast
; "Pausa por pérdida de UI" reaparecería en este nuevo arranque.
if exists(global.lastWatchdogPause)
    set global.lastWatchdogPause = 0

M114
echo "MECANIZADO INICIADO"
