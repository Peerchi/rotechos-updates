; ═══════════════════════════════════════════════════════════════
; M6.g  —  SAC 100% Industrial (Cero Z: mártir/base o superficie, según global.sac_z0_surface)
; ═══════════════════════════════════════════════════════════════

; Capturar estado ANTES de cualquier guard, para que un abort temprano (sonda activa,
; fallo de homing) no arrastre estado stale al siguiente M6:
;  - tool_name: snapshot del nombre y LIMPIEZA inmediata del global (próximo M6 limpio).
;  - spindle_rpm: RPM del trabajo SOLO si el husillo estaba GIRANDO al entrar (se captura
;    antes del M5). spindles[0].active conserva el último S tras un M5: sin mirar el
;    estado, un M6 manual con husillo parado lo rearrancaría al final sin que el
;    operario lo espere, justo después de tener las manos en la fresa.
var tool_name = ""
if exists(global.next_tool_description)
    set var.tool_name = global.next_tool_description
    set global.next_tool_description = ""
var modo_ini = exists(global.kinematicMode) ? global.kinematicMode : 1   ; 5-oct: para volver a SEDA en un M6 manual
var spindle_rpm = 0
if spindles[0].state == "forward"
    set var.spindle_rpm = spindles[0].active
    ; Con VSSC activo, active es el valor OSCILADO (base ± variance/2): capturar
    ; la BASE real para que el rearranque post-SAC no derive la RPM del trabajo.
    if exists(global.vssc_on) && global.vssc_on && global.vssc_base_rpm > 0
        set var.spindle_rpm = global.vssc_base_rpm
; 26-sep (auditoría contra RRF 3.5.4, C2): el M5 iba DESPUÉS de las guardas de abajo. La
; máquina corre en modo FFF y ahí un `abort` dentro de un trabajo NO para el husillo
; (GCodes.cpp:4407-4417): una guarda que abortaba dejaba la fresa girando con la
; interfaz en reposo. Apagar lo primero; las RPM ya están capturadas arriba.
T0                                   ; Activar tool (M3 la necesita; M5 apaga todos igualmente)
; 27-sep (revisión de la integración, R8): M400 explícito. Hoy el T0 ya espera a vaciar la cola
; (GCodes2.cpp:4878-4883), pero si alguien lo quita, un M5 con movimientos pendientes se
; encola (GCodeQueue.cpp:48-52) y un abort posterior la vacía: el husillo seguiría girando.
M400
M5                                   ; Apagar Spindle
; Origen del CERO Z del programa CAM (global.sac_z0_surface; si no existe → mártir/base):
;   false → Z0 en la BASE/mártir (mesa). Robusto, no depende del grosor.
;   true  → Z0 en la SUPERFICIE del material = mesa + global.touchplate_thickness (grosor).
var z0_surface = false
if exists(global.sac_z0_surface)
    set var.z0_surface = global.sac_z0_surface
var z0_cam = var.z0_surface ? "la SUPERFICIE del material" : "la base del material (mártir)"
; 16-sep (B7): el cero se escribía SIEMPRE en G54 (P1). Con un programa en G55, el
; SAC corregía G54 y el trabajo seguía con la longitud de la fresa anterior: la fresa
; más larga se clava esa diferencia. Se escribe en el sistema de coordenadas ACTIVO.
var wcs_p = exists(move.workplaceNumber) ? move.workplaceNumber + 1 : 1

; 0a. GUARDIA RETROFIT: sin sensor de herramienta fijo (sac_enabled=false), el SAC
; no puede calibrar — abortar con instrucciones en vez de ir a buscar un sensor
; inexistente contra el chasis. Los postprocesadores emiten T{n}/M6 igualmente.
if exists(global.sac_enabled) && !global.sac_enabled
    ; S1 T0 y no S2: un aviso bloqueante se puede Cancelar, y Cancelar solo sale de esta macro
    ; SIN llegar al abort (GCodes.cpp:465-485): el trabajo seguiría. Así el abort va siempre.
    M291 P"SAC desactivado en CONFIGURACION (maquina sin sensor de herramienta).<br>Cambia la fresa a mano y fija el Z0 con la Sonda Z o el touchplate." R"SAC DESACTIVADO" S1 T0
    abort "M6 cancelado — sac_enabled=false"

; 5-oct: sin calibrar (tool_sensor_y = 0) probe_z_sensor.g aborta, pero DESPUÉS de mover al
; punto de cambio y pedir la fresa. Se avisa antes de mover nada.
if exists(global.tool_sensor_y) && global.tool_sensor_y == 0
    M291 P"Sensor de herramienta sin calibrar.<br>Indica su posicion Y en CONFIGURACION antes del primer cambio de herramienta." R"SAC SIN CALIBRAR" S1 T0
    abort "M6 cancelado — tool_sensor_y sin calibrar"

; 0. GUARDIA: sonda activa antes de empezar / ejes sin referenciar (homing automático).
if sensors.probes[0].value[0] > 0
    M291 P"ERROR: Sonda activada ANTES de empezar.<br>¿Cortocircuito o fresa tocando el sensor?" R"SAC - SEGURIDAD" S1 T0
    abort "M6 abortado — sonda activa antes del palpado"

; B-H3.2 (auditoria 15-sep): el G28 de abajo iba ANTES del M5, y `check_homing_safe.g`
; aborta el homing si el husillo gira. El M5 está ahora arriba del todo (26-sep, C2).

if !move.axes[0].homed || !move.axes[1].homed || !move.axes[2].homed
    M291 P"Los ejes no están referenciados. Realizando Homing automático antes del SAC..." R"SAC - HOMING" S1 T3
    G28

M150 R255 U0 B255 F0 S25             ; Magenta sólido (cambio de herramienta / atención)
M150 F1

; 1. SUBIR Y MOVER A POSICIÓN DE CAMBIO
; Husillo apagado (M5 línea 19), Z al tope, X centrado y Y posicionado (cerca del
; operario, alejado del fondo) basado en global.tool_change_y. Da margen para que 
; la fresa no quede encima del propio carro y deja espacio para la mano del operario.
; 2-oct: era G91 G1 Z+safe_clearance sin mirar el techo; cerca del tope pisaba el final
; de carrera de Z. Misma subida lenta, en máquina y acotada por debajo del tope.
G90
G53 G1 Z{min(move.axes[2].machinePosition + global.safe_clearance, move.axes[2].max - global.safe_clearance)} F1500    ; subida inicial de seguridad (F al techo M203 Z)
G53 G0 Z{move.axes[2].max - global.safe_clearance}
; XY del SAC en rápido: aplicar RAYO con rampa suave SEDA→RAYO (~600ms, 15 pasos).
; ANTES se aplicaba M201 X{rayo} Y{rayo} + M566 X{rayo} Y{rayo} P1 directamente,
; lo que generaba un salto audible del TMC2160 (zumbido/clac) si la máquina
; estaba en SEDA. ramp_to_pro.g ya cubre el caso kinematicMode==1 (sale con M99
; sin hacer nada — no afecta si ya estamos en RAYO).
if fileexists("0:/sys/ramp_to_pro.g")
    M98 P"0:/sys/ramp_to_pro.g"
elif fileexists("0:/sys/set_pro.g")
    M98 P"0:/sys/set_pro.g"
M400                                 ; Sincronizar cola tras la rampa ANTES de mover (orden canónico M400→movimiento)
G53 G1 X{move.axes[0].max / 2} Y{exists(global.tool_change_y) ? global.tool_change_y : 30} F{exists(global.travel_feed) ? global.travel_feed : 4000}
M400                                 ; Esperar a que la máquina termine el movimiento y se detenga

; 2. POP-UP PARA EL USUARIO
; Mensaje dinámico: si el postprocesador puso el nombre de la herramienta (que
; capturamos arriba en var.tool_name), se muestra en negrita. Si está vacío
; (M6 manual desde la UI), se muestra el mensaje genérico.
; 26-sep: con un M291 aquí mismo, Cancelar salía de M6.g sin cambiar la herramienta y el
; trabajo seguía con el husillo parado. Ahora Cancelar detiene el trabajo.
; 27-sep (revisión de la integración, R7): el texto medía 316 bytes y M291 guarda como mucho
; 256 (Configuration.h:131): se perdía la última frase y el corte caía en mitad de un <b>.
; Ahora son 220 bytes como mucho con un nombre de herramienta de 20 caracteres (medido).
var cmsg = "Inserta la fresa y apriétala.<br>"
if var.tool_name != ""
    set var.cmsg = "Herramienta: <b>" ^ var.tool_name ^ "</b>.<br>"
set var.cmsg = var.cmsg ^ "Cero Z del CAM: <b>" ^ var.z0_cam ^ "</b>.<br>"
set var.cmsg = var.cmsg ^ "Makita: APÁGALO con su interruptor antes de tocar la fresa (M5 no lo para).<br>"
set var.cmsg = var.cmsg ^ "OK = fresa apretada, calibrar altura."
; 27-sep (R6): la ficha se baja aquí también. Si confirmar.g faltara (SD a medio actualizar),
; M98 solo avisa y sigue (GCodes.cpp:3196-3203) y se leería el true de la vez anterior.
set global.confirmado = false
M98 P"0:/sys/confirmar.g" A{var.cmsg} B{"CAMBIO DE HERRAMIENTA"} C3
if !global.confirmado
    abort "Cambio de herramienta cancelado por el operario"

; 3. IR AL SENSOR FIJO Y PALPAR (lógica compartida con Sonda Z)
; El sub-macro va al sensor (X=move.axes[0].max, Y=global.tool_sensor_y), hace el
; palpado rápido + 2 pasadas lentas, guarda el disparo en global.probe_trigger_z,
; sube Z y restaura cinemática. En error aborta él mismo (detiene el SAC).
set global.probeOk = false             ; R6: no heredar el true de un palpado anterior
M98 P"0:/sys/probe_z_sensor.g"
; Si se canceló su aviso de repetibilidad, probe_z_sensor.g salió sin llegar al final y
; global.probe_trigger_z es el de la herramienta ANTERIOR: aplicarlo clavaría la fresa.
if !global.probeOk
    abort "Cambio de herramienta cancelado: el palpado no terminó"

; 4. APLICAR OFFSET DEFINITIVO — Cero Z según el origen del CAM (var.z0_surface).
; G10 L2 aritmético con el disparo guardado por el probe (posición-independiente: la fresa
; ya está arriba). Base de cálculo: cara de la mesa = probe_trigger_z - z_sensor_to_table.
;   - mártir/base (default): Z0 en la mesa. Robusto, no depende del grosor.
;   - superficie: Z0 = mesa + global.touchplate_thickness (grosor). OJO: si el grosor no es
;     exacto, TODAS las profundidades de corte se desplazan ese error.
if var.z0_surface
    G10 L2 P{var.wcs_p} Z{global.probe_trigger_z - global.z_sensor_to_table + global.touchplate_thickness}
else
    G10 L2 P{var.wcs_p} Z{global.probe_trigger_z - global.z_sensor_to_table}

; 5. RETIRAR, REARRANCAR HUSILLO Y AVISAR
G53 G0 Z{move.axes[2].max - global.safe_clearance}                            ; Subir Z a tope (el probe ya subió; reaseguro)
M150 R0 U255 B255 F0 S25             ; Cian sólido (listo para RAYO) - 25 LEDs
M150 F1
; 26-sep: era un aviso de 3 s (S1 T3) y el husillo VFD arrancaba solo, con el operario recién
; salido de tocar la fresa; y con un Makita apagado para el cambio (M5 no lo para, y el
; firmware no sabe qué husillo hay), el trabajo seguía con la fresa parada. Ahora bloquea.
set global.confirmado = false          ; R6: no heredar el true del aviso anterior
M98 P"0:/sys/confirmar.g" A{"Herramienta calibrada. Aparta las manos: al pulsar OK arranca el husillo y sigue el trabajo.<br><br>Husillo manual (Makita): ENCIÉNDELO antes de pulsar OK."} B{"SISTEMA LISTO"} C2
; Cancelar aquí dejaba el trabajo cortando sin husillo: ahora lo detiene.
if !global.confirmado
    abort "Trabajo detenido: no se confirmó el arranque del husillo tras el cambio de herramienta"
; Rearrancar el husillo al RPM del trabajo (capturado al entrar, antes del M5) y
; esperar a que alcance revoluciones, para que el primer corte tras el SAC NO ocurra
; con el husillo aún acelerando. M6 manual sin husillo (rpm=0): solo pausa breve.
if var.spindle_rpm > 0
    M3 S{var.spindle_rpm}
    M98 P"0:/sys/spindle_ramp_wait.g"
else
    G4 P200                          ; settling breve antes de devolver el control (antes P1000 = 1s de titubeo muerto)
; 5-oct: un M6 manual (fuera de un trabajo, state.status «busy», RepRap.cpp:2407-2412) dejaba la
; máquina en RAYO tras la rampa del punto 1, y el jog siguiente iba con la dinámica de producción.
if state.status != "processing" && var.modo_ini == 0
    M98 P"0:/sys/ramp_to_silk.g"
; NOTA: global.next_tool_description ya quedó limpio al entrar a la macro
; (capturado en var.tool_name). No hace falta limpiarlo aquí.
