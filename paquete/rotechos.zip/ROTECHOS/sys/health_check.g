; ═══════════════════════════════════════════════════════════════
; health_check.g — Diagnóstico rápido del sistema RotechOS
; Ruta: 0:/sys/health_check.g
; Llamada con: M98 P"0:/sys/health_check.g"
; ═══════════════════════════════════════════════════════════════

; 3-oct: exists(), ver config.g. -1 = la build no mide esa magnitud.
var volt   = exists(boards[0].vIn) ? boards[0].vIn.current : -1
var temp   = exists(boards[0].mcuTemp) ? boards[0].mcuTemp.current : -1
var ram    = boards[0].freeRam

; --- Evaluar tensión (sistema de 48V — Mean Well LRS-350-48; mismos umbrales que
;     integrity_check/M911: ERROR <40, AVISO <44. Antes usaba 20/22, de un sistema 24V,
;     y un fallo grave a 30V reportaba "OK") ---
; Umbrales derivados de global.psu_voltage (48V → ERROR <40, AVISO <44; fallback 48V)
var vErr  = (exists(global.psu_voltage) && exists(global.power_alert_err)) ? global.psu_voltage * global.power_alert_err : 40
var vWarn = (exists(global.psu_voltage) && exists(global.power_alert_warn)) ? global.psu_voltage * global.power_alert_warn : 44
var voltStr = "OK"
if var.volt < 0
    set var.voltStr = "SIN MEDIDA"
elif var.volt < var.vErr
    set var.voltStr = "ERROR"
elif var.volt < var.vWarn
    set var.voltStr = "AVISO"

; --- Evaluar temperatura MCU ---
var tempStr = "OK"
if var.temp < 0
    set var.tempStr = "SIN MEDIDA"
elif var.temp > 65
    set var.tempStr = "CRITICA"
elif var.temp > 55
    set var.tempStr = "ALTA"

; --- Evaluar sensores (X, Y, Z son NC, 0=Conectado/Libre, 1=Abierto/Disparado) ---
; X son GPIO J4 (X MAX) y J5 (X MIN), no endstops M574 → se leen de sensors.gpIn[].
; Guardas null (como trigger2.g): si config.g falló, gpIn[n] puede no existir.
; 28-sep (R2): solo los lados con sensor (global.shieldMask); un lado sin sensor lee 1 siempre.
var shM = 63
if exists(global.shieldMask)
    set var.shM = global.shieldMask
var shNo = 0
if exists(global.shieldNoMask)
    set var.shNo = global.shieldNoMask
var sensStr = "OK"
if mod(floor(var.shM / 16), 2) == 1 && sensors.gpIn[4] != null && sensors.gpIn[4].value == (mod(floor(var.shNo / 16), 2) == 1 ? 0 : 1)
    set var.sensStr = "AVISO: X MAX ACTIVADO"
elif mod(floor(var.shM / 32), 2) == 1 && sensors.gpIn[5] != null && sensors.gpIn[5].value == (mod(floor(var.shNo / 32), 2) == 1 ? 0 : 1)
    set var.sensStr = "AVISO: X MIN ACTIVADO"
elif mod(floor(var.shM / 1), 2) == 1 && sensors.gpIn[0] != null && sensors.gpIn[0].value == (mod(floor(var.shNo / 1), 2) == 1 ? 0 : 1)
    set var.sensStr = "AVISO: Y MIN ACTIVADO"
elif mod(floor(var.shM / 2), 2) == 1 && sensors.gpIn[1] != null && sensors.gpIn[1].value == (mod(floor(var.shNo / 2), 2) == 1 ? 0 : 1)
    set var.sensStr = "AVISO: Y MAX ACTIVADO"
elif mod(floor(var.shM / 4), 2) == 1 && sensors.gpIn[2] != null && sensors.gpIn[2].value == (mod(floor(var.shNo / 4), 2) == 1 ? 0 : 1)
    set var.sensStr = "AVISO: Z MIN ACTIVADO"
elif mod(floor(var.shM / 8), 2) == 1 && sensors.gpIn[3] != null && sensors.gpIn[3].value == (mod(floor(var.shNo / 8), 2) == 1 ? 0 : 1)
    set var.sensStr = "AVISO: Z MAX ACTIVADO"

; --- Evaluar drivers mapeados (X=3, Y=1, Z=2) ---
; 2-oct: leia boards[0].drivers[N].state, que no existe en RRF 3.5.4 (solo `status`, un
; mapa de bits que las expresiones no pueden leer; Platform.cpp:374). La macro moria con
; error de expresion. El fallo de driver lo avisa RRF por su cuenta.
var drvStr = "ver M122"

; --- Modo cinemático actual --- (global declarado en config.g)
var modeStr = "SEDA"
if global.kinematicMode == 1
    set var.modeStr = "RAYO"

; --- Mostrar diagnóstico ---
var diag = "V: " ^ var.volt ^ "V " ^ var.voltStr ^ "<br>MCU: " ^ var.temp ^ "C " ^ var.tempStr
set var.diag = var.diag ^ "<br>RAM: " ^ var.ram ^ " bytes<br>Sensores NC: " ^ var.sensStr
set var.diag = var.diag ^ "<br>Drivers XYZ: " ^ var.drvStr ^ "<br>Modo: " ^ var.modeStr
M291 P{var.diag} R"Health Check" S1 T15
