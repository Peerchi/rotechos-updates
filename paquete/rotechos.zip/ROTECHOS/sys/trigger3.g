; trigger3.g — Botón externo de PARO (paro_externo) por software
; Ejecutado automáticamente por el firmware cuando el M581 P{N} T3 se dispara.
; NO depende del WiFi ni del JavaScript: si la interfaz está cerrada, el
; botón sigue parando la máquina.
;
; QUIÉN LO DISPARA
; ────────────────
; Configurado en config-machine.g por rotechos-config-pins-ui.js cuando el
; operario asigna un pin al slug `paro_externo`:
;   M950 J{N} C"^pin"   ; pull-up (NC, fail-safe) o "^!pin" para NO
;   M581 P{N} T3 S1 R0  ; flanco ascendente, una sola vez
; El disparo se entrega con la lógica de pines invertida ya aplicada (RRO), así
; que este macro NO toca M950 para reinterpretar el pin.
;
; LO QUE HACE
; ────────────
; (sin M410: RRF 3.5.4 no lo implementa; quien para el movimiento es el M112 del final)
; T0 / M5 — apagar el husillo (orden canónico, ver CLAUDE.md §5)
; M150 R255 U0 B0 — alarma visual: LED rojo sólido
; M117 — mensaje en la pantalla del panel (M408 S0 lo consume el polling)
; M112 — paro duro y total del firmware, equivalente a la seta de verdad
;
; M112 es la única instrucción que pone al firmware en estado STOP y cierra
; la conexión HTTP. Lo que sigue (M112 mismo, no más líneas tras él) es un
; compromiso documentado:
;   - M112 cierra TODO, incluido este macro. Las líneas posteriores NO se
;     ejecutan. Por eso mantenemos M150/M117 ANTES de M112: para que el
;     operario vea la pista visual aunque el botón de paro del cockpit no
;     esté a mano.

; 1. Alarma visual y abort del movimiento en curso (orden canónico)
; 26-sep (auditoría contra el fuente de RRF 3.5.4, A6): M112 va PRIMERO y es lo único.
; Antes le precedían M5 y M150, y los dos pueden ESPERAR al movimiento en curso: M5 se
; encola tras los movimientos (GCodeQueue.cpp:48-52) y M150, si la tira LED no va por DMA,
; espera a que la máquina se pare (LedStripManager.cpp:142-148). El PARO llegaba tarde.
; Tras M112 no se ejecuta nada más, y el reinicio borra las globales: por eso no hay más líneas.
M112
