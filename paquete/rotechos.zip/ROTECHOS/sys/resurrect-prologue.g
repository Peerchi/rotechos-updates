; resurrect-prologue.g — GUARDA: el rescate PLR fue RETIRADO de RotechOS (decisión 2026-07-04)
; Este archivo se ejecuta ANTES de reanudar el G-Code si alguien lanza M916 a mano.
; M911 sigue activo (protección física: spindle off + Z arriba en caída de tensión) y
; RRF puede seguir autogenerando resurrect.g al detectar el corte. Sin el protocolo de
; recuperación (homing + reposicionado XY + husillo + bajada controlada de Z), reanudar
; a ciegas arriesga arrastrar o clavar la fresa. Por eso este prólogo ABORTA siempre.
; Si en el futuro se reintroduce el rescate, recuperar el protocolo completo del
; historial de git (versión previa a jul-2026 de este archivo).

M291 P"El rescate PLR fue retirado de RotechOS. La reanudacion via M916 esta bloqueada por seguridad. Vuelva a lanzar el trabajo desde el principio." R"PLR desactivado" S1 T0
abort "PLR retirado: M916 bloqueado por seguridad (sin protocolo de recuperacion)"
