; sys/probe_axis.g
; Palpado de precisión en un eje
; Parámetros:
;   A: Eje (string: "X", "Y" o "Z")
;   D: Recorrido de búsqueda (numérico, ej: -50), relativo a la posición actual
;
; 3-oct-2026 (fuente de RRF 3.5.4), reescrito. Tenía tres fallos que el simulador no veía:
;  - `G38.2 {param.A}{param.D}`: la letra de un parámetro no puede salir de una expresión. El
;    lector salta lo que va entre llaves (StringParser.cpp:1086-1094 y 1269-1276), así que el
;    G38.2 llegaba sin eje y RRF lo rechaza con «No axis specified» (GCodes6.cpp:614-622): el
;    Palpador 3D abortaba siempre en el primer paso. Lo mismo con los `G1 {param.A}...`.
;  - G38.x ignora G91: su destino es absoluto (GCodes6.cpp:597-607). `G91` + `G38.2 Z-50`
;    palpaba hacia Z=-50 del WCS, no 50 mm más abajo.
;  - G38.x ignora su F y usa la de M558 (ver probe_speed.g).
; Ahora el destino se calcula en coordenadas de máquina (G53) desde la posición actual, una
; rama por eje.

if !exists(param.A) || !exists(param.D)
    abort "sys/probe_axis.g: Falta parámetro A (eje) o D (distancia)"
if param.A != "X" && param.A != "Y" && param.A != "Z"
    abort "sys/probe_axis.g: A debe ser X, Y o Z"

var ax = (param.A == "X") ? 0 : ((param.A == "Y") ? 1 : 2)
var dir = (param.D < 0) ? -1 : 1
var esc = (0 - var.dir) * 5                     ; retirada de 5 mm en caso de fallo

; 1. Palpado rápido (M400: la posición de partida tiene que ser la real, no la de la cola)
M400
; 5-oct: G38.x no aplica los límites M208 (GCodes6.cpp:543-649); el destino se recorta
; al recorrido real para que un D largo cerca del borde no lleve el eje al tope físico.
var t = max(move.axes[var.ax].min, min(move.axes[var.ax].max, move.axes[var.ax].machinePosition + param.D))
G90
M98 P"0:/sys/probe_speed.g" F{global.probe_speed_fast}
if var.ax == 0
    G53 G38.2 X{var.t}
elif var.ax == 1
    G53 G38.2 Y{var.t}
else
    G53 G38.2 Z{var.t}
if result != 0
    G91
    if var.ax == 0
        G1 X{var.esc} Z5 F{global.probe_backoff_speed}
    elif var.ax == 1
        G1 Y{var.esc} Z5 F{global.probe_backoff_speed}
    else
        G1 Z5 F{global.probe_backoff_speed}
    G90
    M291 P{"ERROR: La sonda " ^ param.A ^ " no hizo contacto en la búsqueda rápida."} R"PALPADOR 3D - ERROR" S1 T0
    abort "Palpador 3D abortado — error de contacto en búsqueda rápida"

; 2. Retroceso
var backoff_dist = global.probe_backoff_dist1 * (0 - var.dir)
G91
if var.ax == 0
    G1 X{var.backoff_dist} F{global.probe_backoff_speed}
elif var.ax == 1
    G1 Y{var.backoff_dist} F{global.probe_backoff_speed}
else
    G1 Z{var.backoff_dist} F{global.probe_backoff_speed}
G90
M400

; 3. Palpado lento de precisión
set var.t = move.axes[var.ax].machinePosition + (global.probe_backoff_dist1 + 2) * var.dir
M98 P"0:/sys/probe_speed.g" F{global.probe_speed_slow}
if var.ax == 0
    G53 G38.2 X{var.t}
elif var.ax == 1
    G53 G38.2 Y{var.t}
else
    G53 G38.2 Z{var.t}
if result != 0
    G91
    if var.ax == 0
        G1 X{var.esc} Z5 F{global.probe_backoff_speed}
    elif var.ax == 1
        G1 Y{var.esc} Z5 F{global.probe_backoff_speed}
    else
        G1 Z5 F{global.probe_backoff_speed}
    G90
    M291 P{"ERROR: La sonda " ^ param.A ^ " no hizo contacto en la pasada de precisión."} R"PALPADOR 3D - ERROR" S1 T0
    abort "Palpador 3D abortado — error de contacto en pasada lenta"
