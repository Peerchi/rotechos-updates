; =================================================================
; set_silk.g — Perfil SEDA (RotechOS)
; Suavidad absoluta para posicionamiento manual
; =================================================================
; Los valores M201/M566 NO estan hardcoded — vienen de globals silk_*
; editados por el user via mcfgM201/mcfgM566 (tab drivers). Antes este
; archivo anulaba los settings del user al ejecutarse tras config.g.

M400 ; sync movement queue
; JERK: P1 activa Junction Deviation (suavizado de esquinas)
M566 X{global.silk_jerk_x} Y{global.silk_jerk_y} Z{global.silk_jerk_z} P1
if #move.axes > 3
    M566 A{global.silk_jerk_a} P1

; ACELERACIÓN: Progresiva para evitar inercias en el cabezal
M201 X{global.silk_accel_x} Y{global.silk_accel_y} Z{global.silk_accel_z}
if #move.axes > 3
    M201 A{global.silk_accel_a}

; NOTA: M569 (dirección + chopper mode) NO se toca aquí.
; En BTT Scylla V1.0 con TMC2160, cualquier M569 P{n} (incluso solo D) re-inicializa
; el chip TMC y RESETEA la dirección S a su default, anulando inversiones del user.
; El chopper mode (D3=StealthChop, D2=SpreadCycle) se establece UNA SOLA VEZ en
; config.g y permanece para toda la sesión. Si necesitas SpreadCycle para
; mecanizar materiales duros, edita config.g manualmente.

; ESTADO: Seteamos modo 0 (Seda) para la lógica de la UI/LEDs
set global.kinematicMode = 0

; INDICADOR LED: Azul pulsante lento = seguro/manual
M150 R0 U0 B255 P80 F2 S25
