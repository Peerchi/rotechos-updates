; homex.g — Homing real del eje X (sensor inductivo NPN en X-MAX, pin C.6)
set global.homingInProgress = true
; 17-oct (A3/N-H1): el escudo T2 corta tambien el HOME. Una peticion vieja (de un disparo
; durante el jog) no cuenta: se limpia aqui; las nuevas las consume abort_check.g entre fases.
if {exists(global.abortRequested)}
    set global.abortRequested = false

; Guardia: verificar que el husillo está parado y la sonda Z inactiva
M98 P"0:/sys/guards/check_homing_safe.g"
if {exists(global.motorDirectionCheckMask) && global.motorDirectionCheckMask != 0}
    set global.homingInProgress = false
    abort "HOME bloqueado: verifica el sentido del motor hacia su final de carrera antes de referenciar."

; 15-sep (B10): subir Z antes de mover X, como homeall.g. Con la fresa baja, un G28 X
; por consola la arrastraba por la pieza o las bridas. Sin Z referenciado no se sabe
; dónde está la fresa: se aborta.
M400
if !move.axes[2].homed
    set global.homingInProgress = false
    abort "Homing X abortado: referencia Z primero (G28 Z o G28)"
if {move.axes[2].machinePosition < (move.axes[2].max - global.safe_clearance)}
    M400
    G90
    G53 G1 Z{move.axes[2].max - global.safe_clearance} F{global.z_raise_speed}

; Cinemática suave de homing — evita golpe en arranque (ver homeall.g)
M400
M98 P"0:/sys/abort_check.g"      ; 17-oct (A3): el escudo saltó al subir Z → no mover X
M201 X{global.homing_accel_x}
M566 X{global.homing_jerk_x} P1

; --- REDUCCIÓN DE CORRIENTE (Efecto muelle magnético) ---
; SOLO el eje que se homea. NO bajar Z: su tornillo NO es autoblocante (config.g)
; y al 60% el spindle podría caer por gravedad durante el homing de X.
; M913 literal = INTENCIONAL: la UI no expone M913 operativo (no es M906 RMS).
; El valor al 60% es cinemática de bump contra el tope; no anula un "save" del user.
M400
M913 X60                       ; INTENCIONAL — no editable desde UI (cinemática de bump)

; Desactivar triggers M581 ANTES del unbinding (evita disparos falsos transitorios)
; 28-sep (revisión RRF, «R-1 en homing»): era `M581 Pn T2 R-1`. En RRF 3.5.4 la R es la
; condición del trigger ENTERO (TriggerItem.cpp:117-121) y S vale 1 si falta: apagaba los seis
; sensores y además AÑADÍA el pin. S-1 quita solo ese pin (TriggerItem.cpp:140-144).
M581 P4 T2 S-1               ; quitar SOLO el pin de X Max del trigger 2
M581 P5 T2 S-1               ; quitar SOLO el pin de X Min del trigger 2
; Seleccionar el lado configurado y liberar su pin GPIO antes de usarlo como endstop.
if {!exists(global.homeSideX) || global.homeSideX == 1}
    M950 J4 C"nil"               ; liberar pin C.6 de GPIO (X MAX)
    M574 X2 S1 P"^C.6"           ; activar endstop X MAX
else
    M950 J5 C"nil"               ; liberar pin D.11 de GPIO (X MIN)
    M574 X1 S1 P"^D.11"          ; activar endstop X MIN

G91                          ; coordenadas relativas
if {!exists(global.homeSideX) || global.homeSideX == 1}
    G1 H1 X{move.axes[0].max + 40} F{global.travel_feed / 4}   ; buscar X MAX
else
    G1 H1 X{-(move.axes[0].max - move.axes[0].min + 40)} F{global.travel_feed / 4}   ; buscar X MIN
M400
M98 P"0:/sys/abort_check.g"      ; 17-oct (A3): el escudo saltó en esta fase → abortar (no es «sensor no detectado»)
if !move.axes[0].homed                ; el primer H1 no llegó al sensor (A1, 28-sep)
    M98 P"0:/sys/home_fail.g"
    if {!exists(global.homeSideX) || global.homeSideX == 1}
        abort "Homing X fallido: no se detecto X MAX en el recorrido. Revisa el sensor y su cable."
    else
        abort "Homing X fallido: no se detecto X MIN en el recorrido. Revisa el sensor y su cable."
if {!exists(global.homeSideX) || global.homeSideX == 1}
    G1 X{-global.homing_backoff_xy} F{global.probe_backoff_speed}                  ; retroceder desde X MAX
else
    G1 X{global.homing_backoff_xy} F{global.probe_backoff_speed}                   ; retroceder desde X MIN
M400
M98 P"0:/sys/abort_check.g"      ; 17-oct (A3): el escudo saltó en el retroceso → no buscar de nuevo
; 11-nov: exigir una detección nueva sin soltar el motor (también Z).
; M350 con los valores actuales desmarca homed: RRF 3.5.4, GCodes2.cpp:2920-2942.
M350 X{move.axes[0].microstepping.value} I{move.axes[0].microstepping.interpolated ? 1 : 0}
if sensors.endstops[0].triggered
    M98 P"0:/sys/home_fail.g"
    abort "Homing X fallido: el sensor no se libera tras el retroceso. Revisa el sensor y su cable."
if {!exists(global.homeSideX) || global.homeSideX == 1}
    G1 H1 X{global.homing_backoff_xy * 2} F{global.probe_speed_slow}               ; búsqueda lenta hacia X MAX
else
    G1 H1 X{-global.homing_backoff_xy * 2} F{global.probe_speed_slow}              ; búsqueda lenta hacia X MIN
G90                          ; coordenadas absolutas
; 28-sep (A1): sin G92. El G1 H1 que llega al sensor ya fija la posición y marca el eje; un
; G92 aquí lo daba por referenciado aunque el sensor no se hubiera detectado nunca.
M400
M98 P"0:/sys/abort_check.g"      ; 17-oct (A3): el escudo saltó en esta fase → abortar (no es «sensor no detectado»)
if !move.axes[0].homed
    M98 P"0:/sys/home_fail.g"
    if {!exists(global.homeSideX) || global.homeSideX == 1}
        abort "Homing X fallido: no se detecto el final de carrera X MAX. Revisa el sensor y su cable antes de volver a referenciar."
    else
        abort "Homing X fallido: no se detecto el final de carrera X MIN. Revisa el sensor y su cable antes de volver a referenciar."

; Apartar X de su sensor → el sensor queda libre ANTES de armar alarmas
G91
if {!exists(global.homeSideX) || global.homeSideX == 1}
    G1 X{-global.homing_clearance_xy} F{global.probe_backoff_speed}
else
    G1 X{global.homing_clearance_xy} F{global.probe_backoff_speed}
G90

; Restaurar escudo de hardware centralizado
M400
M98 P"0:/sys/abort_check.g"      ; 17-oct (A3): el escudo saltó durante el apartado → abortar ANTES de rearmar
M574 X0 S1                   ; deshabilitar endstop X
M98 P"0:/sys/recover_triggers.g"
M98 P"0:/sys/abort_check.g"      ; 17-oct (A3): un disparo durante el rearme no se da por bueno

; --- RESTAURAR CORRIENTE AL 100% ---
; INTENCIONAL: cinemática de homing, no editable desde UI (ver cabecera § REDUCCIÓN).
M400
M913 X100 Y100 Z100             ; INTENCIONAL — restauración tras bump de homing

; Restaurar cinemática del modo activo (SEDA=0 / RAYO=1)
M98 P"0:/sys/restore_kinematics.g"

; Seguridad: Bandera de que X ya está referenciado
set global.xHomed = true
set global.homingInProgress = false

; --- RETROALIMENTACIÓN DE ÉXITO (coherente con homeall.g) ---
M98 P"0:/sys/home_feedback_success.g"
