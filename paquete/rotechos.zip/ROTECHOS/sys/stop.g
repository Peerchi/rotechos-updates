; stop.g - Parada segura al finalizar trabajo correctamente
G90                           ; Asegurar modo absoluto (protección contra G91 residual)
set global.homingInProgress = false  ; Limpiar flag huérfano si homing fue abortado
if exists(global.uiBeat)
    set global.uiBeat = 0     ; Reiniciar watchdog offline
; (26-sep: aquí había un M410. RRF 3.5.4 no lo implementa —src/BugList.txt— y solo dejaba
;  un aviso «Command is not supported»; la cola ya la descarta el fin o la cancelación del trabajo.)

; PRIMERO: Elevar Z para sacar la fresa del material (evita rotura con spindle parando)
M98 P"0:/sys/z_safe_raise.g"

; DESPUÉS: Apagar spindle (ya fuera del material — seguro)
T0                            ; Asegurar tool activa — M5 se ignora sin ella
M5                            ; Apagar spindle
G4 P{global.spindle_cooldown_ms}                      ; Esperar 1.5s a que el husillo pierda inercia

; Restaurar perfil SEDA con transición suave RAYO→SEDA (ramp_to_silk.g interpola en 15 pasos, ~600ms)
; set_silk.g canónico vive en sys/. ramp_to_silk.g si existe, si no set_silk.g directo.
if fileexists("0:/sys/ramp_to_silk.g")
    M98 P"0:/sys/ramp_to_silk.g"
else
    M98 P"0:/sys/set_silk.g"

; Guardar posición para restaurar al próximo arranque (macro centralizada)
M98 P"0:/sys/save_position.g"

; LED IDLE reposo: azul claro (R0 U40 B180) claramente visible bajo luz de
; taller. ANTES era R4 U9 B32 (casi apagado — el operario dudaba si estaba
; dormida). Ahora la máquina tiene presencia industrial sin parpadear.
M150 R0 U40 B180 S25 F0
M150 F1
M98 P"0:/sys/recover_triggers.g"  ; Asegurar triggers activos tras parada
; M98 P"0:/macros/park.g"       ; aparcar maquina (DESACTIVADO: peligroso sin homing real)

echo "═══════════════════════════════════"
echo "  TRABAJO FINALIZADO CORRECTAMENTE"
echo "  MCU: " , (exists(boards[0].mcuTemp) ? boards[0].mcuTemp.current : "?") , "°C  |  Vin: " , (exists(boards[0].vIn) ? boards[0].vIn.current : "?") , "V"
echo "═══════════════════════════════════"
