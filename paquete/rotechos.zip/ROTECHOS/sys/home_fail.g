; home_fail.g  —  Deja la máquina como tras un homing, cuando un eje NO llegó a su sensor
; Llamada: M98 P"0:/sys/home_fail.g"  y, justo después, `abort "…"` en la macro de homing.
;
; 28-sep (A1 de la auditoría contra RRF 3.5.4): las macros de homing terminaban con `G92`, y
; `G92` marca el eje como referenciado (GCodes3.cpp:143) aunque el sensor no se hubiera
; detectado nunca: con el cable del inductivo cortado, el carro llegaba al tope mecánico y el
; eje quedaba «referenciado» en una cota falsa. Ahora no hay `G92`: el `G1 H1` que llega al
; sensor fija la posición y marca el eje (DDA.cpp:1855-1908), y G28 lo desmarca antes de
; empezar (GCodes.cpp:3310-3323). Si tras el homing el eje sigue sin referencia, se viene aquí.
;
; Qué deja: ningún endstop permanente, el escudo M581 armado con los lados de esta máquina,
; la corriente al 100 % y la cinemática del modo activo. No mueve nada.
M400
M574 X0 S1
M574 Y0 S1
M574 Z0 S1
M98 P"0:/sys/recover_triggers.g"
M913 X100 Y100 Z100             ; INTENCIONAL — deshacer el 60 % del bump de homing
if exists(global.homingInProgress)
    set global.homingInProgress = false
M150 R255 U0 B0 P255 F0 S25     ; LED rojo: homing fallido
