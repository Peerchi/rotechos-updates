; daemon.g — Vigilante de RotechOS (RRF lo arranca solo; ver daemon_tick.g)
; Ruta: 0:/sys/daemon.g
; 28-sep (auditoría contra RRF 3.5.4, M1): RRF 3.5.4 espera 10 s entre el final de una
; ejecución de daemon.g y la siguiente (GCodes.cpp:559-563: DoDwellTime(daemonRunning ? 10000
; : 1000)). La lógica contaba con una vuelta cada 0,5-1 s: la pausa por tensión baja
; (vinLowCycles = 4) tardaba ~42 s en vez de ~2 s, el vigilante de interfaz hasta 10 s de más
; y la posición se guardaba cada ~2,5 min. Ahora este fichero no termina: repite la vuelta
; con la espera de siempre (0,5 s mecanizando, 1 s en el resto).
; Si una vuelta aborta por un error, RRF vuelve a lanzar daemon.g a los 10 s, como antes.
; NO usar globals aquí sin exists(): pueden no existir si config.g falló.
while true
    M98 P"0:/sys/daemon_tick.g"
    if state.status == "processing" || state.status == "resuming"
        G4 P500
    else
        G4 P1000
