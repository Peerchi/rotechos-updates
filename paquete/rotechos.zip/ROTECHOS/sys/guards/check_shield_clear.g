; sys/guards/check_shield_clear.g
; Guardia: ningun final de carrera del escudo puede estar pisado al empezar una macro de movimiento.
; Llamada: M98 P"0:/sys/guards/check_shield_clear.g"   (desde M6.g, las macros de palpado, bordeador, coreografia, goto0 y park)
;
; 17-oct (A3, revision de Codex): al rearmar el escudo, RRF 3.5.4 toma el nivel de partida sin
; disparar (TriggerItem.cpp, Configure llama a Check() y descarta el resultado). Tras un aborto
; con un sensor aun pisado, ese lado queda ciego hasta que se suelte y se vuelva a pisar, y la
; macro siguiente limpiaba la peticion vieja y palpaba igual. Misma comprobacion que start.g.
; NO se usa en el HOME: referenciar con el carro sobre un sensor es normal y es como se sale.
var shRest = 63
if exists(global.shieldMask) && global.shieldMask >= 0 && global.shieldMask <= 63 && floor(global.shieldMask) == global.shieldMask
    set var.shRest = global.shieldMask
elif exists(global.shieldMask) && global.shieldMask == -1
    ; 11-nov: -1 = sin guardar. Mismos lados que el fallback de antes (los tres MAX = 26):
    ; con 63, un lado sin sensor lee 1 por el pull-up y bloquearia todo. start.g ya niega el trabajo.
    set var.shRest = 26
var shNo = 0
if exists(global.shieldNoMask)
    set var.shNo = global.shieldNoMask
while iterations < 6
    if mod(var.shRest, 2) == 1 && sensors.gpIn[iterations] != null && sensors.gpIn[iterations].value == (mod(var.shNo, 2) == 1 ? 0 : 1)
        M291 P{"Final de carrera activo o cable cortado (entrada J" ^ iterations ^ "). Separa el carro con el jog o revisa el cable antes de seguir."} R"ERROR: SENSOR ACTIVO" S1 T0
        abort "Macro cancelada: final de carrera activo al empezar"
    set var.shRest = floor(var.shRest / 2)
    set var.shNo = floor(var.shNo / 2)
