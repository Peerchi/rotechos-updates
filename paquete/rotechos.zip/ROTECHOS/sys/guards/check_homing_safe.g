; sys/guards/check_homing_safe.g
; Guardia: verificar que el husillo está parado y la sonda Z inactiva antes de homing

; 14-nov-2026: si config.g se cortó al arrancar, faltan el escudo de finales, el husillo y el
; perfil SEDA: no se referencia. exists() por si el globals.g de la SD es anterior.
if {exists(global.configComplete) && !global.configComplete}
    set global.homingInProgress = false
    abort "HOME bloqueado: la configuración no terminó de cargar al arrancar. Mira el error de arranque en la interfaz, corrígelo y reinicia la placa."

; Guardia: abortar si el husillo está girando
if spindles[0].state != "stopped"
    set global.homingInProgress = false
    M291 P"El husillo está girando. Apágalo antes de hacer Homing." R"HOMING ABORTADO" S1 T0
    abort "Homing abortado — Husillo girando"

; Guardia: abortar si la sonda Z está activa (contacto prematuro / corto)
if sensors.probes[0].value[0] > 0
    set global.homingInProgress = false
    M291 P"ERROR: Sonda Z activa antes de empezar.<br>¿Fresa tocando el palpador?" R"HOMING ABORTADO" S1 T0
    abort "Homing abortado — Sonda Z activa"
