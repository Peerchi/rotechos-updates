/* ---
 * rotechos-ota-zip.js — Detección de archivos comprimidos para el gestor OTA.
 *
 * FIX-NV-3a (2026-08-06): la OTA es SOLO notificación (rotechos-ota.js) y NO
 * parsea ZIPs. Arrastrar el `.zip` literal a la dropZone subía el archivo
 * íntegro a 0:/sys/ (interfaz deception). Este módulo decide, por nombre, si
 * un archivo debe ser rechazado antes de encolarse.
 *
 * Por qué módulo separado:
 *   - Testable en Node sin DOM, sin rotechos.js entero. tests/unit/ota-zip-block.test.js
 *     importa este módulo directamente.
 *   - Carga ANTES de rotechos.js (defer, posición en index.html) para que la
 *     IIFE del gestor OTA pueda usar `isOtaArchive(name)` desde su closure.
 *
 * Formatos bloqueados: .zip, .tar.gz, .tgz, .rar, .7z.
 * Lista cerrada — si alguien añade .bz2 / .xz / .iso / .dmg, lo hace aquí
 * Y actualiza el test unitario correspondiente.
 * --- */
'use strict';

/**
 * Devuelve true si `name` es un archivo comprimido que la OTA no sabe
 * procesar. Insensible a mayúsculas. Tolerante a paths completos
 * (`basename/releaser.zip` → matchea por la última `/`).
 *
 * @param {string} name
 * @returns {boolean}
 */
function isOtaArchive(name) {
  if (typeof name !== 'string' || !name) return false;
  const base = name.includes('/') ? name.slice(name.lastIndexOf('/') + 1) : name;
  return /\.(zip|tar\.gz|tgz|rar|7z)$/i.test(base);
}

// Exposición global (símbolo consumido por rotechos.js IIFE) + CommonJS para Node test.
if (typeof globalThis !== 'undefined') globalThis.isOtaArchive = isOtaArchive;
if (typeof module !== 'undefined' && module.exports) module.exports = { isOtaArchive };
