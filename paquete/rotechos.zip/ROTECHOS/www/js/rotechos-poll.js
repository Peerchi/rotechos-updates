/* ---
 * rotechos-poll.js — Defer module: el cuerpo REAL del poll de telemetría.
 *
 * Sprint 4 fase 2 del programa de reducción del monolito. Saca de rotechos.js
 * el cuerpo del poll (antes `poll()`, aquí `_pollRun`) y el fetch inicial de
 * límites por eje. La infraestructura de timers (startPoll, la reprogramación,
 * el intervalo dinámico y el listener de visibilitychange) SIGUE en el shell:
 * este fichero es el ciclo, no el reloj.
 *
 * Contrato: tests/unit/poll-core.test.js (17 tests) — es la especificación de
 * este fichero; no deshagas nada sin leerlo.
 *
 *  - Todo el estado del ciclo vive en AppState: AppState.poll.{active,cycle,
 *    latencyMs,fails}, AppState.cache.* (caches de ciclo + softLimits,
 *    machinePos, softLimitsEnabled, endstopCfg) y AppState.limits.*.
 *    Los nombres sueltos legacy del shell quedaron como PUENTES de
 *    compatibilidad (accessors en window, ver rotechos.js) para no tocar el
 *    enforcement del jog ni su red de tests. Este fichero NO usa los puentes.
 *
 *  - ⚠️ PENDIENTE BANCO (jul-2026): el clamp del jog lee ahora estos valores a
 *    través de AppState.cache. La suite (unit + e2e) pasa contra el mock, pero
 *    el enforcement con la máquina real (ejes sin homing, M564 S0) hay que
 *    validarlo en banco antes de darlo por bueno.
 *
 * Dependencias globales (inyectables en tests): AppState, SM, STATES,
 * _fetchModel, _unwrap, RRF, setConn, log, toast, t, LOG, startPoll,
 * _clearPollTimer, _schedulePoll, _currentPollInterval, window, Date,
 * setTimeout.
 * --- */

const _CONN_MAX_STRIKES = 3; // Fallos tolerados antes de declarar OFFLINE

// El indicador de conexion tiene tres estados de fabrica —ok, error, busy— y
// faltaba el de en medio: "algo no responde, pero todavia no lo doy por
// perdido". Sin el, el unico camino era saltar de verde a rojo, y como el salto
// tarda tres fallos, el verde se sostenia demasiado tiempo.
function _pillReintentando() {
  // los unitarios corren en node, sin DOM: sin esta guarda el poll revienta ahi
  if (typeof document === 'undefined' || typeof SM === 'undefined') return;
  const pill = document.getElementById('connPill');
  if (!pill || !SM.connected) return;      // si ya esta en rojo, no lo suavices
  pill.className = 'conn-pill warn';
  pill.title = (typeof t === 'function')
    ? t('msg.connReintentando', 'Reintentando conexión…')
    : 'Reintentando conexión…';
}
function _pillConectado() {
  if (typeof document === 'undefined' || typeof SM === 'undefined') return;
  const pill = document.getElementById('connPill');
  if (!pill || !SM.connected) return;
  pill.className = 'conn-pill ok';
  pill.title = (typeof t === 'function') ? t('msg.conectado', 'Conectado') : 'Conectado';
}

// Durante el arranque, visor, DRO y JOG conservan su geometría pero quedan
// invisibles hasta tener un modelo consistente. La salida de emergencia evita
// dejar el cockpit vacío si la placa está desconectada o tarda en responder.
let _cockpitBootGateTimer = null;
function _revealCockpitAfterBoot() {
  if (typeof document === 'undefined') return;
  document.body?.classList.remove(`cockpit-booting`);
  if (_cockpitBootGateTimer) {
    clearTimeout(_cockpitBootGateTimer);
    _cockpitBootGateTimer = null;
  }
}
if (typeof document !== 'undefined') {
  _cockpitBootGateTimer = setTimeout(_revealCockpitAfterBoot, 1500);
  // El historial y las horas de husillo del mantenimiento viven en el modulo
  // perezoso rotechos-modules.js: solo registraban si en esa sesion se abria
  // HISTORIAL o el asistente (25-sep). Se carga despues del arranque.
  setTimeout(() => { if (typeof __lazyLoad === `function`) __lazyLoad(`/js/rotechos-modules.js`).catch(() => {}); }, 8000);
}

// ---
// A — SEÑAL DE ESPERA PARA SONDEO LENTO (t_d9f3c73d)
// Propuesta aprobada en docs/dev/propuestas/2026-08-13_senial-espera-sondeo-propuesta.md
// y docs/dev/propuestas/2026-08-13_robustez-percibida-paquete-decision.md.
//
// Cuando la primera petición del ciclo `_fetchModel("state.status")` cuelga más
// de 350 ms sin respuesta, el operario ve un badge ámbar transitorio
// "ESPERANDO RESPUESTA" (`.status-awaiting`). Si llega antes, la señal ni se
// pinta. Anti-flicker: si la señal llegó a aparecer, se mantiene al menos
// 600 ms antes de permitir que se retire (gestionado por el repintado normal
// del siguiente `updateStateUI`).
//
// Notas de implementación:
// - El ciclo se mide SOLO sobre `state.status` (la petición más rápida). El
//   resto del ciclo (move/spindles/sensors...) puede tardar segundos en
//   condiciones nominales y NO debe disparar la señal.
// - Si entre el disparo y los 350 ms el sistema pasa a `status-disconnected`,
//   ese estado gana (el siguiente `updateStateUI` repinta con
//   `status-disconnected`, sobreescribiendo la clase).
// - El setTimeout se cancela SIEMPRE al volver del await (llegue o no
//   respuesta), para no dejar timers huérfanos entre ciclos.
// - El módulo-local `_awaitTimer` se reinicia al inicio de cada `_pollRun`.
// ---
const _AWAITING_UMBRAL_MS = 350;     // ms antes de pintar awaiting
const _AWAITING_MIN_VISIBLE_MS = 600; // ms mínimo visible si llegó a aparecer
let _awaitTimer = null;                // setTimeout del ciclo actual
let _awaitShownAt = 0;                 // Date.now() en que se pintó awaiting
function _paintAwaiting() {
  // Pinta el estado ámbar transitorio. Defensivo: solo si seguimos
  // conectados (status-disconnected ya tiene su propio manejo).
  const badge = $('machineStatus');
  if (!badge || !SM || !SM.connected) return;
  badge.classList.add('status-awaiting');
  setText('stateTxt', t('state.awaiting', 'ESPERANDO RESPUESTA'));
  // Pendant (mpgStateTxt) refleja el mismo texto. El color del pendant sale
  // por [data-state="AWAITING"] en CSS.
  const pill = $('mpgStatePill');
  if (pill) pill.dataset.state = 'AWAITING';
  setText('mpgStateTxt', t('state.awaiting', 'ESPERANDO RESPUESTA'));
  _awaitShownAt = Date.now();
}

/** Fetch de soft limits con d99 — ejecutado una vez al conectar.
 *  min/max son config y podrían omitirse en respuestas delta normales. */
async function _fetchAxisLimits() {
  try {
    const r = await _fetchModel(`move.axes`, 3000, `d99`);
    const axes = _unwrap(r);
    if (!Array.isArray(axes)) return;
    const sl = AppState.cache.softLimits;
    [`X`,`Y`,`Z`,`A`].forEach((n, i) => {
      const ax = axes[i];
      if (!ax) return;
      if (ax.min !== undefined && ax.min !== null) sl[n].min = ax.min;
      if (ax.max !== undefined && ax.max !== null) sl[n].max = ax.max;
    });
    log(`Soft limits cargados: X[${sl.X.min},${sl.X.max}] Y[${sl.Y.min},${sl.Y.max}] Z[${sl.Z.min},${sl.Z.max}]`, `sys`);
  } catch {}
}

async function _pollRun() {
  if (AppState.poll.active) return;
  AppState.poll.active = !0;
  AppState.poll.cycle++;
  // Generación al arrancar: si la interfaz cambia de estado durante el ciclo, lo
  // leído se descarta al final (acta: docs/dev/hallazgos/2026-09-11_AT-04-diagnostico.md).
  const _myGen = AppState.poll.gen;
  // En el primer ciclo, cargar soft limits con d99 para asegurar valores completos
  if (AppState.poll.cycle === 1) await _fetchAxisLimits();
  const _pollT0 = Date.now();
  try {
    // A (t_d9f3c73d): colgar el timer de 350 ms SOLO sobre la primera
    // petición del ciclo. Si llega respuesta antes, se cancela y nunca se
    // pinta. Defensivo: si quedara un timer huérfano de un ciclo previo,
    // lo cancelamos al arrancar este (ya está implícito al reasignar).
    if (_awaitTimer) { clearTimeout(_awaitTimer); _awaitTimer = null; }
    _awaitTimer = setTimeout(_paintAwaiting, _AWAITING_UMBRAL_MS);
    const rState = await _fetchModel("state.status");
    // A (t_d9f3c73d): respuesta de state.status recibida. Cancela el timer
    // y, si llegó a pintar awaiting, mantiene la señal visible al menos
    // 600 ms antes del repintado real (anti-flicker). El siguiente
    // updateStateUI al final del ciclo sobreescribirá la clase completa
    // con el estado real.
    if (_awaitTimer) { clearTimeout(_awaitTimer); _awaitTimer = null; }
    if (_awaitShownAt) {
      const left = _AWAITING_MIN_VISIBLE_MS - (Date.now() - _awaitShownAt);
      if (left > 0) await new Promise((r) => setTimeout(r, left));
      // A (t_d9f3c73d): retirar el awaiting INMEDIATAMENTE. updateStateUI
      // del final del ciclo SOLO se ejecuta si hay SM.transition (mapeo
      // cambia); si el estado real coincide con el actual (caso típico
      // IDLE→IDLE), no hay transición y la clase awaiting + el texto
      // "ESPERANDO RESPUESTA" quedarían pegados. Repintamos badge y
      // pendant aquí. window.updateStateUI() cubre el badge de cabecera;
      // el pendant (#mpgStatePill/#mpgStateTxt) lo cubre _renderPendantState
      // que vive dentro de updateMPG (no exportado como función suelta).
      if (typeof window.updateStateUI === `function`) window.updateStateUI();
      // Pendant: reset explícito. updateMPG es el path canónico, pero su
      // firma exige 6 args; para el repintado del estado basta con
      // restaurar el dataset.state y el texto del pill a lo que diga SM.
      const _pill = $('mpgStatePill');
      const _mpgTxt = $('mpgStateTxt');
      if (_pill && _pill.dataset.state === `AWAITING`) {
        // SM.current llega como letra (`I`/`R`/`D`...) vía _STATE_TO_LETTER
        // inverso, pero el pendant usa el `STATE` en mayúsculas del monolito
        // (STATES.IDLE etc). Mapeo local de defensa.
        const _cur = SM.current || `IDLE`;
        _pill.dataset.state = _cur;
        if (_mpgTxt) {
          const _txt = _cur === `IDLE` ? `INACTIVO`
            : _cur === `READY` ? `LISTO`
            : _cur === `RUNNING` ? `EN MARCHA`
            : _cur === `PAUSED` ? `PAUSADO`
            : _cur === `ERROR` ? `ERROR`
            : _cur;
          _mpgTxt.textContent = _txt;
        }
      }
      _awaitShownAt = 0;
    }
    let stateStr = _unwrap(rState);
    const isBoardActive = stateStr === 'processing' || stateStr === 'paused';
    const _pollIsActive = SM.current === STATES.RUNNING || SM.current === STATES.PAUSED || isBoardActive;
    const needB = (AppState.poll.cycle % 2 === 0) || isBoardActive;
    const needC = _pollIsActive ? AppState.poll.cycle % 10 === 0 : AppState.poll.cycle % 15 === 0;
    const needD = !_pollIsActive && AppState.poll.cycle % 30 === 0;
    // ── Serialización: await secuencial — ESP32 despacha mejor 1 socket a la vez ──
    // Optimizado: sensors (endstops+gpIn) en un solo fetch, spindles/global menos frecuentes en IDLE
    // state.messageBox = M291 activo del firmware. Si no se pide aquí, los M291
    // S2/S3 nunca se muestran en la UI y la macro queda colgada esperando OK
    // (caso típico: SAC parado en la posición de cambio sin mostrar el modal).
    const rMsgBox = await _fetchModel("state.messageBox");
    const rMove  = await _fetchModel("move");
    // 27-sep (arreglos de interfaz, A3): el LED ya no relanza el poll en cada fotograma, y en
    // reposo el husillo se leía una vuelta de cada cuatro (~12 s). Con el husillo encendido o
    // con un apagado de aspiración pendiente se lee en cada vuelta: si no, un rearranque dentro
    // del retardo no se veía a tiempo y la aspiración se apagaba con el husillo girando.
    const _spCache = AppState.cache.spindles && AppState.cache.spindles[0];
    const _spOn = !!(_spCache && _spCache.state && _spCache.state !== `stopped`);
    const _aspirPend = typeof window !== `undefined` && window.ASPIR_FOLLOW?.getState?.().pending === true;
    const rSpindles = (needB && _pollIsActive) || (AppState.poll.cycle % 4 === 0) || _spOn || _aspirPend ? await _fetchModel("spindles", null, "v") : null;  // 2-oct: max/min del husillo son campos verbose (Spindle.cpp)
    const rSensors = needB ? await _fetchModel("sensors", null, "d99") : null;
    // En el primer ciclo también pedimos job aunque esté IDLE: evita pintar el
    // estado vacío del visor antes de saber si el firmware conserva un G-code.
    const _needInitialJobStatus = !SM._jobStatusKnown;
    const rJ     = needB && (_pollIsActive || _needInitialJobStatus) ? await _fetchModel("job") : null;
    const rG     = (needB && _pollIsActive) || (AppState.poll.cycle % 6 === 1) ? await _fetchModel("global") : null;  // ciclo 1 incluido: antes, 18 s sin saber si el husillo es manual
    const rB     = needC ? await _fetchModel("boards") : null;
    const rN     = needD ? await _fetchModel("network") : null;
    // Extraer endstops, gpIn y probes del fetch unificado de sensors
    let rE = null, rGpIn = null, rProbes = null;
    if (rSensors != null) {
      const _sens = _unwrap(rSensors);
      if (_sens) {
        rE = _sens.endstops != null ? { result: _sens.endstops } : null;
        rGpIn = _sens.gpIn != null ? { result: _sens.gpIn } : null;
        // probes lo consume la pill esProbe y data.probes[0] en general
        rProbes = _sens.probes != null ? { result: _sens.probes } : null;
      }
    }
    AppState.poll.latencyMs = Date.now() - _pollT0;
    // Con fetches serializados, un ciclo needB puede tardar ~3-5s normalmente.
    // Solo alertar si supera 10s (indica problemas reales de red).
    if (AppState.poll.latencyMs > 10000 && SM.connected) {
      log(`Poll lento: ${AppState.poll.latencyMs}ms — conexión inestable`, `warn`);
      if (SM.current === STATES.RUNNING || SM.current === STATES.PAUSED) {
        toast(
          `${t(`msg.slowConnection`, `Conexión lenta con el CNC — acerca el router o reinícialo`)} (${(AppState.poll.latencyMs / 1000).toFixed(1)}s) — ${t(`msg.telemetryDelayed`, `la información de posición se retrasa; acerca el router al CNC o reinicia el router si persiste`)}`,
          `warn`,
        );
      }
    }
    // Construir data desde rr_model (reemplaza rr_status?type=2)
    const _STATE_TO_LETTER = {
      idle: `I`, busy: `B`, processing: `C`, paused: `D`,
      resuming: `R`, halted: `H`, off: `O`, simulating: `M`,
      changingTool: `T`, flashing: `F`,
      // A-5 (jul-2026): 'pausing'/'cancelling' son estados reales de RRF 3.5.4
      // (RepRap::GetStatusString) que antes caían al default 'I'=IDLE — con
      // el husillo aún decelerando, el operario vería "INACTIVO" mientras la
      // máquina sigue en movimiento. Reusan 'D' (mismo letra que 'paused')
      // porque RRF_TO_SM.D → STATES.PAUSED, transición válida desde RUNNING.
      pausing: `D`, cancelling: `D`,
    };
    stateStr = _unwrap(rState);
    const statusLetter = (typeof stateStr === `string`) ? (_STATE_TO_LETTER[stateStr] ?? `I`) : null;
    const data = statusLetter ? { status: statusLetter, _rrfRaw: stateStr } : null;
    if (data)
      try {
        const moveObj = _unwrap(rMove);
        if (moveObj) {
          data.move = moveObj;
          if (moveObj.currentMove) data.currentMove = moveObj.currentMove;
          data.params = {
            // RRF reporta move.speedFactor como FRACCIÓN (1.0 = 100%). Normalizar a
            // porcentaje aquí, en el origen, para que todo el resto (display y barra)
            // muestre 100% en vez de 1%.
            // Heurística de semántica: un factor legítimo como FRACCIÓN nunca pasa de
            // 5 (=500%); si llega mayor, la build ya lo entrega en PORCENTAJE y
            // multiplicarlo de nuevo mostraba 1000%/10000% tras recargar.
            speedFactor: (() => {
              const v = moveObj.speedFactor ?? 1;
              if (v <= 10 && (v % 1 !== 0 || [1, 2, 3, 4, 5, 10].includes(v))) return v * 100;
              return v;
            })(),
            feedFactor: (() => {
              const v = moveObj.feedFactor ?? 1;
              if (v <= 10 && (v % 1 !== 0 || [1, 2, 3, 4, 5, 10].includes(v))) return v * 100;
              return v;
            })(),
          };
          if (moveObj.axes) {
            const axes = moveObj.axes;
            if (Array.isArray(axes) && axes.length >= 3) {
              data.coords = {};
              data.coords.machine = [
                  axes[0]?.machinePosition ?? 0,
                  axes[1]?.machinePosition ?? 0,
                  axes[2]?.machinePosition ?? 0,
                  axes[3]?.machinePosition ?? 0,
                ];
                // Actualizar caché de posición y soft limits para enforcement JS
                const _mp = AppState.cache.machinePos, _sl = AppState.cache.softLimits;
                [`X`,`Y`,`Z`,`A`].forEach((n,i) => {
                  const ax = axes[i];
                  if (!ax) return;
                  _mp[n] = ax.machinePosition ?? _mp[n];
                  if (ax.min !== undefined && ax.min !== null) _sl[n].min = ax.min;
                  if (ax.max !== undefined && ax.max !== null) _sl[n].max = ax.max;
                });
                // 27-sep (análisis de la interfaz): era SIEMPRE workplaceOffsets[0] (G54). Con un
                // programa en G55 el DRO de pieza y la comprobación de límites del visor usaban el
                // cero de G54. El WCS activo es move.workplaceNumber, base 0 (Move.cpp:139); los
                // offsets van por WCS, también base 0 (Platform.cpp:214-219).
                const _wi = Number.isInteger(moveObj.workplaceNumber) && moveObj.workplaceNumber >= 0 ? moveObj.workplaceNumber : 0;
                AppState.cache.workplaceNumber = _wi;
                const o0 = axes[0]?.workplaceOffsets?.[_wi] ?? 0,
                  o1 = axes[1]?.workplaceOffsets?.[_wi] ?? 0,
                  o2 = axes[2]?.workplaceOffsets?.[_wi] ?? 0,
                  o3 = axes[3]?.workplaceOffsets?.[_wi] ?? 0;
                // Microajuste Z (M290) acumulado. RRF lo conserva hasta un reinicio o un PARO
                // (GCodes.cpp:261): se enseña mientras no sea 0 (ver updateUI).
                data.babystepZ = Number(axes[2]?.babystep) || 0;
                // Cachear offsets del WCS activo por eje — el visor 3D los lee para
                // convertir coords de fichero a coords de máquina antes de
                // comparar con los soft limits. Sin esto, el chequeo previo
                // da VERDE para ficheros que rebasan el recorrido (t_717c48cc).
                // Inicialización defensiva: AppState.cache.wcsOffsets se
                // declara en rotechos.js:37, pero el mock de
                // tests/unit/poll-core.test.js:loadPollCore arman su propio
                // AppState sin ese campo; ||= lo crea en sitio sin pisar el
                // objeto real si ya estaba.
                const _w = (AppState.cache.wcsOffsets ||= { X:0, Y:0, Z:0, A:0 });
                _w.X = o0; _w.Y = o1; _w.Z = o2; _w.A = o3;
                data.coords.xyz = [
                  (axes[0]?.machinePosition ?? 0) - o0,
                  (axes[1]?.machinePosition ?? 0) - o1,
                  (axes[2]?.machinePosition ?? 0) - o2,
                  (axes[3]?.machinePosition ?? 0) - o3,
                ];
              }
            }
          }
        // Spindles: poblar data.spindles para RPM (con caché para ciclos sin needB)
        const spArr = _unwrap(rSpindles);
        if (Array.isArray(spArr)) {
          data.spindles = spArr;
          AppState.cache.spindles = spArr;
        } else if (AppState.cache.spindles != null) {
          data.spindles = AppState.cache.spindles;
        }

        // t_e234f3be: la aspiración observa el estado del husillo y enciende
        // la salida correspondiente al detectar forward/reverse. Si re-arranca
        // dentro del retardo, cancela el apagado pendiente. La salida del
        // módulo ASPIR_FOLLOW.tick es 'on' / 'scheduleOff' / 'cancel' /
        // 'noop' / 'skip' — todo en AppState.cache._aspirFollow; diagnóstico.
        if (typeof window !== 'undefined' && window.ASPIR_FOLLOW &&
            typeof window.ASPIR_FOLLOW.tick === 'function' &&
            Array.isArray(data.spindles) && data.spindles.length > 0) {
          try { window.ASPIR_FOLLOW.tick(data.spindles[0]); }
          catch (e) { if (typeof LOG !== 'undefined') LOG.warn('aspirFollow tick:', e); }
        }

        (rB != null
          ? ((data.boards = _unwrap(rB)), (AppState.cache.boards = data.boards))
          : AppState.cache.boards != null && (data.boards = AppState.cache.boards),
          rN != null
            ? ((data.network = _unwrap(rN)), (AppState.cache.network = data.network))
            : AppState.cache.network != null && (data.network = AppState.cache.network));

        if (rJ != null) {
          const jb = _unwrap(rJ);
          if (jb) {
            data.jobModel = jb;
            SM._jobStatusKnown = true;
          }
        }
        if (rG != null) {
          const globalObj = _unwrap(rG);
          if (globalObj) {
            data.xHomed = globalObj.xHomed;
            data.kinematicMode = globalObj.kinematicMode;
            data.homingInProgress = globalObj.homingInProgress;
            // 6-oct: red propia elegida (CONFIGURACIÓN → Red); lo lee APDetector.
            if (typeof globalObj.netApOnly === `boolean`) data.netApOnly = globalObj.netApOnly;
            // Sincronizar el guard de jog JS con la preferencia REAL del firmware.
            // Antes solo se refrescaba al abrir el modal de config, así que tras
            // recargar la página el jog usaba el default `true` y bloqueaba el
            // movimiento negativo aunque el user hubiera desactivado los soft
            // limits. global.softLimitsOn = fuente de verdad.
            if (globalObj.softLimitsOn !== undefined && globalObj.softLimitsOn !== null)
              AppState.cache.softLimitsEnabled = !!globalObj.softLimitsOn;
            // Mismo motivo, para homingInProgress: hasta ahora solo viajaba en
            // `data` y se perdía al acabar el ciclo, así que el guard de
            // btnRecover no tenía forma de saber si había un homing en marcha.
            // Se cachea el último valor bueno; si el firmware no lo reporta en
            // este ciclo, se conserva el anterior en vez de asumir "no hay homing".
            if (globalObj.homingInProgress !== undefined && globalObj.homingInProgress !== null)
              AppState.cache.homingInProgress = !!globalObj.homingInProgress;
            // HALLAZGO-5 (informe 2026-08-17): marca que el daemon.g deja al
            // pausar el trabajo por pérdida de UI (global.lastWatchdogPause =
            // state.upTime). Sin este hilo, la UI ve "PAUSADO" al volver sin
            // contexto de por qué. Solo nos importa el último valor bueno;
            // rotechos.js lo cruza con el último visto para disparar el toast
            // una sola vez.
            if (globalObj.spindleManual != null) document.body.classList.toggle(`spindle-manual`, !!globalObj.spindleManual);
            if (globalObj.lastWatchdogPause !== undefined && globalObj.lastWatchdogPause !== null)
              AppState.cache.lastWatchdogPause = globalObj.lastWatchdogPause;
          }
        }
        if (rE != null) {
          const es = _unwrap(rE);
          Array.isArray(es) && ((data.endstops = es), (AppState.cache.endstops = es));
        } else AppState.cache.endstops != null && (data.endstops = AppState.cache.endstops);

        // Propagar el messageBox del firmware (M291 activo) — el handler 'sac'
        // lo consume para mostrar el modal. Es lo que pinta el cuadro "Instala
        // la herramienta" del SAC y el OK que desbloquea la macro.
        if (rMsgBox != null) {
          const _mb = _unwrap(rMsgBox);
          // RRF devuelve `null` cuando no hay messageBox activo. Solo lo pasamos
          // si existe — así el hook 'sac' detecta "ya no hay mensaje" → cierra
          // el modal local cuando el firmware lo retira (M292 / timeout).
          if (_mb && typeof _mb === `object` && _mb.message) data.messageBox = _mb;
        }

        if (rGpIn != null) {
          const gp = _unwrap(rGpIn);
          if (Array.isArray(gp)) {
            data.gpIn = gp;
            AppState.cache.gpIn = gp;
            // Solo activar bloqueo si ese extremo concreto tiene sensor habilitado
            // (evita falsos positivos por pull-ups flotantes en pines sin sensor)
            const _ecfg = AppState.cache.endstopCfg;
            AppState.limits.triggers = {
              YMin: _ecfg.Y.minOn && gp[0]?.value === _ecfg.Y.trigLevel,
              YMax: _ecfg.Y.maxOn && gp[1]?.value === _ecfg.Y.trigLevel,
              ZMin: _ecfg.Z.minOn && gp[2]?.value === _ecfg.Z.trigLevel,
              ZMax: _ecfg.Z.maxOn && gp[3]?.value === _ecfg.Z.trigLevel,
              XMax: _ecfg.X.maxOn && gp[4]?.value === _ecfg.X.trigLevel,
              XMin: _ecfg.X.minOn && gp[5]?.value === _ecfg.X.trigLevel,
            };
          }
        } else if (AppState.cache.gpIn != null) {
          data.gpIn = AppState.cache.gpIn; // Usar caché en ciclos sin needB
        }
        // Propagar el estado de la sonda Z (M558) — lo consume la pill esProbe
        // y el panel de diagnóstico. Cache en ciclos sin needB para no parpadear.
        if (rProbes != null) {
          const probes = _unwrap(rProbes);
          if (Array.isArray(probes)) { data.probes = probes; AppState.cache.probes = probes; }
        } else if (AppState.cache.probes != null) {
          data.probes = AppState.cache.probes;
        }

        const isActive =
          SM.current === STATES.RUNNING || SM.current === STATES.PAUSED;
        if (
          isActive &&
          data.endstops &&
          !AppState.limits.alarmActive &&
          Date.now() >= (AppState.limits.bootGrace || 0)
        ) {
          const _hitAxes = [];
          const _ecfg = AppState.cache.endstopCfg;
          [`X`, `Y`, `Z`].forEach((ax, i) => {
            if (_ecfg[ax].off) return;
            const hit = data.endstops[i]?.triggered === !0;
            if (hit && !AppState.limits.prevHit[ax]) _hitAxes.push(ax);
          });
          if (_hitAxes.length) {
            RRF.urgentGcode("M25\nT0\nM5").catch(() => {});
            log(`Endstop ${_hitAxes.join("+")} — M25+T0+M5 urgente`, "err");
          }
        }
      } catch (e) {
        LOG.warn(`Telemetry poll error:`, e);
      }
    if (!data) {
      AppState.poll.fails++;
      // A (t_d9f3c73d): si el ciclo falla del todo, el timer de awaiting ya
      // disparó (350 ms) pero la respuesta nunca llegó. Limpiamos el timer y
      // dejamos que el flujo de strikes / setConn pinte el estado correcto.
      // Si se llega a strike 3, setConn(false) ejecutará updateStateUI con
      // SM.connected=false → badge "DESCONECTADO" gana sobre awaiting.
      if (_awaitTimer) { clearTimeout(_awaitTimer); _awaitTimer = null; }
      _awaitShownAt = 0;
      // Sistema de strikes: tolerar hasta 3 fallos antes de declarar desconexión.
      // Un fallo aislado puede ser ruido WiFi, GC del navegador, o pico EMI del VFD.
      if (AppState.poll.fails === 1 && SM.connected) {
        // Strike 1: sin toast, pero el INDICADOR deja de mentir.
        // Antes esto era del todo silencioso y el resultado medido fue que la
        // interfaz sostenia "conectado, INACTIVO, indicador verde" durante 17
        // segundos con el firmware caido. Tolerar el fallo esta bien; afirmar
        // que todo va bien mientras se tolera, no. El ambar no alarma —no dice
        // "desconectado"— pero deja de prometer lo que ya no se sabe.
        LOG.warn(`Poll strike 1/${_CONN_MAX_STRIKES} — reintentando…`);
        _pillReintentando();
      } else if (AppState.poll.fails === 2 && SM.connected) {
        // Strike 2: warning en consola + toast sutil "info" (no warn/err) — el
        // operario se entera de que algo va mal sin que sea una alarma. H-6
        // (2026-08-17) documentaba que strikes 1-2 eran silenciosos y el
        // operario solo se enteraba en el 3º (desconexión). El strike 2 es
        // el último momento en que todavía puede pasar por microcorte — un
        // toast info le da feedback sin escalar a error.
        log(`Conexión inestable (strike ${AppState.poll.fails}/${_CONN_MAX_STRIKES})…`, `warn`);
        toast(t(`msg.connInstable`, `Conexión inestable — reintentando…`), `info`);
      } else if (AppState.poll.fails >= _CONN_MAX_STRIKES && SM.connected) {
        // Strike 3+: desconexión confirmada
        setConn(false, `Sin conexión`);
        // AUD-VIS (auditoria visual 20-sep): este aviso lo afirmaba SIEMPRE, sin
        // mirar si habia trabajo. Con la maquina parada, perder la red hacia que
        // la interfaz asegurase que estaba cortando — una afirmacion falsa sobre
        // si la maquina se mueve. Ahora mira el ultimo estado conocido.
        const _habiaTrabajo = (typeof SM !== `undefined` && typeof STATES !== `undefined`
          && (SM.current === STATES.RUNNING || SM.current === STATES.PAUSED));
        log(_habiaTrabajo
          ? `Conexión perdida con el firmware. El trabajo sigue ejecutándose de forma autónoma en el CNC. Intentando reconexión…`
          : `Conexión perdida con el firmware (sin trabajo en curso al perderla). Intentando reconexión…`, `warn`);
        toast(_habiaTrabajo
          ? t(`msg.connLost`, `Conexión perdida con la UI — el CNC sigue ejecutando el trabajo de forma autónoma; no apagues la máquina. Espera unos segundos: la UI se reconectará sola. Si no vuelve, recarga la página (F5).`)
          : t(`msg.connLostIdle`, `Conexión perdida con la máquina. Al perderse no había ningún trabajo en curso. Espera unos segundos: la interfaz se reconectará sola. Si no vuelve, recarga la página (F5).`),
        `warn`);
      }
      _clearPollTimer();
      SM.pollTimer = setTimeout(startPoll, _currentPollInterval());
      return;
    }
    if (AppState.poll.fails > 0) {
      // HUECO-4: también el microcorte (1-2 fallos sin llegar a DESCONECTADO)
      // avisa "Reconectado"; antes la pill volvía a verde sin decir nada.
      if (AppState.poll.fails >= 2) log(`✓ Conexión recuperada tras ${AppState.poll.fails} strikes`, `sys`);
      AppState.poll.fails = 0;
      // el indicador vuelve a verde en cuanto responde: si sigue en ambar
      // despues de recuperarse, la proxima vez nadie se lo cree
      _pillConectado();
      // Solo si seguimos conectados: la recuperación desde DESCONECTADO ya
      // emite msg.connRestored más abajo, y dos avisos seguidos serían ruido.
      // La clave va como 3er argumento para que el toast barra los
      // "Conexión perdida" encolados (rotechos-ui-feedback.js).
      if (SM.connected && AppState.poll.fails < _CONN_MAX_STRIKES) {
        toast(t(`msg.connRestoredMicro`, `Reconectado`), `ok`, `msg.connRestoredMicro`);
      }
      _schedulePoll(_currentPollInterval());
    }
    // H-5 (2026-08-17): tras reconectar, si SM quedó en ERROR por un halt
    // previo (escudo trigger2.g, soft limit, etc.) y el firmware ya no
    // reporta halted en el siguiente poll, transicionamos a IDLE para que
    // el operario no vea "ERROR" persistente. Si el firmware sigue halted,
    // _uiResolveStateMachine (rotechos.js:1422) lo regresará a ERROR en el
    // siguiente ciclo — la transición a IDLE aquí es momentánea y refleja
    // "la UI está conectada, el estado del SM se va a reevaluar".
    const _wasHalted = SM.current === STATES.ERROR;
    // ESTOP-3 (2026-08-30): esta auto-recuperacion NO puede deshacer un PARO DE
    // EMERGENCIA que el operario acaba de pulsar. Medido: con la maquina en
    // RUNNING, `SM.transition(ERROR)` del btnEStop re-arma el poll en su propia
    // cola (rotechos.js:715-721, la rama `prev === RUNNING`), y `_clearPollTimer()`
    // mata el TEMPORIZADOR pero no el ciclo YA EN VUELO. Ese ciclo llegaba aqui,
    // veia `_wasHalted` y devolvia el badge a INACTIVO: la pantalla decia
    // "listo" con la fresa recien parada de emergencia. Lo cazaba
    // `tests/e2e-paro-emergencia.spec.js:214` (ESTOP-3), rojo determinista.
    // `SM._rebootPending` ya distingue exactamente ese caso — lo pone el propio
    // btnEStop (rotechos.js:2785) y lo limpia la reconexion tras M999
    // (rotechos.js:1053) — asi que H-5 solo tiene que respetarlo. El ERROR
    // sigue saliendo solo por la via normal: cuando el firmware deje de
    // reportar halted, `_uiResolveStateMachine` reevalua el estado.
    // La interfaz cambió de estado durante el ciclo: lo leído es viejo y se descarta;
    // el siguiente ciclo (que _schedulePoll reprograma igual) trae la verdad.
    if (AppState.poll.gen !== _myGen) return;
    // Paro pulsado sin red: el M112 no llego. Con la red de vuelta se reenvia
    // (un M112 solo para, nunca mueve), salvo que la placa ya este parada o haya
    // pasado demasiado tiempo. La pildora deja de decir «sin conexion».
    if (SM._estopM112 === `fallo` && SM.current === STATES.ERROR) {
      if (stateStr === `halted` || Date.now() - SM._estopFalloTs > 300e3) SM._estopM112 = null;
      else {
        SM._estopM112 = `enviando`;
        RRF.urgentGcode(`M112`).then(() => {
          SM._estopM112 = `ok`;
          toast(t(`msg.estopReenviado`, `Red recuperada: el paro de emergencia NO había llegado y se ha enviado ahora.`), `err`);
          log(`M112 reenviado al recuperar la red`, `err`);
        }).catch(() => { SM._estopM112 = `fallo`; }).finally(() => window.updateStateUI?.());
      }
      SM.connected || setConn(!0, `Conectado`);
    }
    (SM._rebootPending ||
      SM.connected ||
      (setConn(!0, `Conectado`), toast(t(`msg.connRestored`, `Conexión restaurada`), `ok`, `msg.connRestored`)),
      _wasHalted && !SM._rebootPending && SM.can(STATES.IDLE) && SM.transition(STATES.IDLE, `reconexión tras halt`),
      window.updateUI(data));
    // El primer modelo válido ya ha actualizado visor, coordenadas y JOG.
    // Solo ahora se revela el cockpit, para que el navegador nunca pinte los
    // valores de plantilla entre el HTML inicial y la telemetría real.
    _revealCockpitAfterBoot();
  } catch (_pe) {
    if (_pe?.name !== `AbortError` && _pe?.name !== `TimeoutError`)
      LOG.warn(`Poll error:`, _pe);
  } finally {
    // A (t_d9f3c73d): si salimos por una excepción no controlada (no por
    // respuesta), el timer de awaiting puede seguir vivo. Cancelarlo
    // SIEMPRE en finally garantiza que no quede disparando tras el ciclo.
    if (_awaitTimer) { clearTimeout(_awaitTimer); _awaitTimer = null; }
    AppState.poll.active = !1;
  }
}

// Fachada + centinela: binding léxico top-level (typeof literal lo ve; el
// checker del shell lo comprueba en SHELL_SENTINEL_CHECKS).
// La const NO se lee aquí a propósito: es el binding léxico que verifica
// SHELL_SENTINEL_CHECKS. El consumo real es window.POLL.
// eslint-disable-next-line no-unused-vars -- binding centinela, ver comentario de arriba
const POLL = window.POLL = { run: _pollRun, fetchAxisLimits: _fetchAxisLimits };
