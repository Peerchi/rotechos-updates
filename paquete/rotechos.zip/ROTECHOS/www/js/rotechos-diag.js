// ---
// rotechos-diag.js — PAQUETE DE DIAGNOSTICO EXPORTABLE
// ---
//
// POR QUE EXISTE
//   RotechOS se entrega a varios usuarios que lo usan a fondo, cada uno en su
//   maquina, sin nadie delante. Hasta hoy, cuando a uno le fallaba algo esa
//   informacion no llegaba a ninguna parte: `rotechos-error-trap.js` reenviaba
//   a `LOG.error`, que escribe en la consola de la UI y se pierde al recargar;
//   y el ZIP de backup solo lleva `0:/sys` y `0:/macros`, que sirve para
//   restaurar una configuracion, no para diagnosticar una incidencia.
//   El resultado practico era un correo que dice "no me va".
//
//   Diseño previo: `carril-A-diseno-paquete-diagnostico.md` (kimi2, 2026-08-30).
//   Se sigue, con dos correcciones que se explican mas abajo.
//
// SE CARGA PEREZOSAMENTE
//   Via `__lazyLoad` (rotechos.js), el mismo patron que ya usan 6 modulos. El
//   arranque en frio va 138 KB por encima de su objetivo y no admite un modulo
//   mas en la cadena de 37 scripts `defer`. El service worker precachea los
//   perezosos igual que los eager, asi que tras la primera visita esta en disco
//   antes de que nadie lo pida.
//
// CORRECCION 1 AL DISEÑO — el anillo de log NO vive aqui
//   El diseño lo ponia en este modulo. No puede: si el modulo es perezoso, el
//   anillo empieza a grabar cuando el operario pulsa el boton, y para entonces
//   los fallos que habia que capturar ya han pasado. El anillo vive en
//   `rotechos-error-trap.js`, que ya es eager y cuyo trabajo es exactamente
//   ese; aqui solo se LEE (`window.__rotechosLogRing.snapshot()`).
//
// CORRECCION 2 AL DISEÑO — `buildSimpleZip` no estaba exportada
//   El diseño daba por hecho que ya existia `window.__buildSimpleZip`. No
//   existia: `buildSimpleZip` vivia dentro del IIFE de `rotechos-backup.js`
//   (lineas 25-643) y ese fichero no exponia NADA. Verificado con
//   `grep -rn "__buildSimpleZip" ROTECHOS/www/` -> 0 resultados. Se ha añadido
//   ese unico export ahi en vez de duplicar 90 lineas de formato ZIP binario.
//
// LO QUE NUNCA PUEDE PASAR
//   Que el paquete lleve credenciales. `wifi-passwords.g` guarda el SSID y la
//   contraseña del WiFi EN CLARO en la tarjeta. Hay dos barreras, y son
//   independientes a proposito: una lista de exclusion por nombre de fichero, y
//   un redactado del CONTENIDO de todo lo que entra. La segunda existe porque
//   la primera no basta: un secreto puede aparecer dentro de otro fichero
//   —una `global` que lo escupa en un `echo`, un M587 copiado a mano en
//   `config.g`— y ahi el nombre del fichero no te salva.
// ---

(function () {
  'use strict';
  if (typeof window === 'undefined') return;

  // ── Barrera 1: ficheros que NO se leen jamas ──────────────────────────────
  // `wifi-passwords.g`   credenciales WiFi en claro.
  // `*.bak`              una copia vieja de `config-machine.g` puede llevar un
  //                      PIN que el operario ya rotó; no aporta al diagnostico.
  const DIAG_DENYLIST = /(^|\/)(wifi-passwords(\.|$)|.*\.bak$)/i;

  // ── Barrera 2: redactado del contenido ────────────────────────────────────
  // Se aplica a TODO texto que entra al paquete, venga de donde venga.
  function redact(texto) {
    if (typeof texto !== 'string') return texto;
    return texto
      // M587/M589: alta de red WiFi. El SSID se conserva (es util para
      // diagnosticar y no es un secreto); la contraseña, no.
      .replace(/\b(M587|M589)(\s+S("[^"]*"|\S+))?\s+P("[^"]*"|\S+)/gi,
        (m, cmd, sBloque) => `${cmd}${sBloque || ''} P"[REDACTADO: credencial WiFi]"`)
      // net_join.g (CONFIGURACIÓN → Red, 6-oct) recibe la clave WiFi en K"...".
      .replace(/\bK"([^"]*)"/g, 'K"[REDACTADO: credencial WiFi]"')
      // M551: PIN HTTP de la propia UI.
      .replace(/\bM551\s+P("[^"]*"|\S+)/gi, 'M551 P"[REDACTADO: PIN]"')
      // Cualquier P"..." con pinta de secreto (>=6 caracteres). Deliberadamente
      // agresivo: perder un parametro legitimo en el informe es barato,
      // filtrar una credencial no.
      .replace(/\bP"([^"]{6,})"/g, 'P"[REDACTADO]"')
      // Cabeceras de autenticacion, por si un logueo las hubiera capturado.
      .replace(/^(authorization|cookie|proxy-authorization|x-api-key)\s*:\s*.+$/gim,
        '$1: [REDACTADO]');
  }

  const _ip = () => (typeof window.TARGET_IP === 'string' ? window.TARGET_IP : '');

  async function _pedir(url, timeoutMs = 8000) {
    try {
      const r = await fetch(url, { signal: AbortSignal.timeout(timeoutMs) });
      return r.ok ? await r.text() : null;
    } catch (_) {
      return null;
    }
  }

  const _descargar = (ruta) =>
    _pedir(`${_ip()}/rr_download?name=${encodeURIComponent(ruta)}&time=${Date.now()}`);

  const _gcode = (cmd) =>
    _pedir(`${_ip()}/rr_gcode?gcode=${encodeURIComponent(cmd)}`, 4000);

  // Allowlist explicita: se nombra lo que entra, nunca "todo menos". Si mañana
  // alguien añade un fichero con secretos a `0:/sys`, no entra solo.
  const CONFIG_ALLOWLIST = [
    '0:/sys/config.g',
    '0:/sys/config-machine.g',
    '0:/sys/globals.g',
    '0:/sys/board.txt',
    '0:/sys/VERSION',
    '0:/sys/health_check.g',
    '0:/sys/integrity_check.g',
    '0:/sys/recover_triggers.g',
  ];

  function _identidad() {
    const g = (k) => {
      try { return window[k] ?? null; } catch (_) { return null; }
    };
    return {
      schema: 1,
      exportadoEn: new Date().toISOString(),
      version: g('ROTECHOS_VERSION'),
      build: g('ROTECHOS_BUILD'),
      // El unico identificador que no puede quedarse atras: se deriva del
      // service worker activo, no se teclea (ver rotechos-version.js).
      swCache: g('ROTECHOS_SW_CACHE'),
      gitSha: g('ROTECHOS_GIT_SHA'),
      navegador: (typeof navigator !== 'undefined' && navigator.userAgent) || null,
      viewport: (typeof window.innerWidth === 'number')
        ? `${window.innerWidth}x${window.innerHeight}` : null,
      idioma: (typeof navigator !== 'undefined' && navigator.language) || null,
      redactado: [
        'wifi-passwords.g: excluido a proposito (credenciales WiFi en claro)',
        '*.bak: excluido a proposito (puede contener un PIN antiguo)',
        'contenido: M587/M589/M551 y P"..." redactados en todo el paquete',
      ],
    };
  }

  function _estado() {
    const leer = (ruta, porDefecto = null) => {
      try {
        return ruta.split('.').reduce((o, k) => (o == null ? o : o[k]), window) ?? porDefecto;
      } catch (_) { return porDefecto; }
    };
    return {
      smActual: leer('SM.current'),
      conectado: leer('SM.connected'),
      ficheroCargado: leer('SM.loadedFile'),
      cicloSondeo: leer('AppState.poll.cycle'),
      esLider: leer('AppState.tab.isLeader'),
      modoEscuela: leer('AppState.ui.schoolMode'),
      pestanaOculta: (typeof document !== 'undefined') ? document.hidden : null,
    };
  }

  function _consola() {
    try {
      const el = document.getElementById('consoleOut');
      if (!el) return '(no hay #consoleOut en el DOM)';
      return el.innerText.split('\n').slice(-200).join('\n');
    } catch (_) {
      return '(no se pudo leer #consoleOut)';
    }
  }

  function _anillo() {
    try {
      const r = window.__rotechosLogRing;
      if (!r || typeof r.snapshot !== 'function') {
        return '(anillo de incidencias no disponible: rotechos-error-trap.js no cargo)';
      }
      const filas = r.snapshot();
      if (!filas.length) return '(sin incidencias registradas en esta sesion)';
      return filas.map((f) => {
        let ctx = '';
        try { ctx = f.ctx ? ' ' + JSON.stringify(f.ctx) : ''; } catch (_) { ctx = ' [ctx no serializable]'; }
        return `${f.ts} [${f.nivel}] ${f.msg}${ctx}`;
      }).join('\n');
    } catch (_) {
      return '(error leyendo el anillo de incidencias)';
    }
  }

  /**
   * Construye el paquete. Devuelve { nombre, bytes, entradas } o lanza.
   * Cada pieza va en su propio try: que falle una fuente (la placa no
   * responde, un fichero no existe) NO puede dejar al operario sin paquete —
   * justo en una incidencia es cuando mas cosas estan rotas.
   */
  async function construirPaquete() {
    const partes = [];
    const anadir = (path, contenido) => {
      if (DIAG_DENYLIST.test(path)) return;
      partes.push({ path, content: redact(String(contenido == null ? '' : contenido)) });
    };

    // diag/ — lo que sabe el navegador, sin tocar la placa.
    anadir('diag/estado.json', JSON.stringify(_estado(), null, 2));
    anadir('diag/consola.txt', _consola());
    anadir('diag/incidencias.txt', _anillo());

    // config/ y macros/ — lo que hay en la tarjeta.
    const fallos = [];
    for (const ruta of CONFIG_ALLOWLIST) {
      if (DIAG_DENYLIST.test(ruta)) continue;
      const txt = await _descargar(ruta);
      if (txt == null) { fallos.push(ruta); continue; }
      anadir(`config/${ruta.replace(/^0:\//, '')}`, txt);
    }

    try {
      const lista = await _pedir(
        `${_ip()}/rr_filelist?dir=${encodeURIComponent('0:/macros')}&time=${Date.now()}`, 6000);
      const files = (JSON.parse(lista || '{}').files || [])
        .filter((f) => f && f.type === 'f' && typeof f.name === 'string');
      for (const f of files) {
        if (DIAG_DENYLIST.test(f.name)) continue;
        const txt = await _descargar(`0:/macros/${f.name}`);
        if (txt == null) { fallos.push(`0:/macros/${f.name}`); continue; }
        anadir(`macros/${f.name}`, txt);
      }
    } catch (_) {
      fallos.push('0:/macros (listado)');
    }

    // Diagnostico del firmware. M122 y M119 son de solo lectura: no mueven nada.
    for (const [cmd, nombre] of [['M122', 'm122.txt'], ['M119', 'm119.txt']]) {
      const out = await _gcode(cmd);
      if (out == null) { fallos.push(cmd); continue; }
      anadir(`diag/${nombre}`, out);
    }

    const manifiesto = _identidad();
    manifiesto.entradas = partes.map((p) => p.path).sort();
    manifiesto.noRecuperado = fallos;
    // El manifiesto va el ULTIMO para poder listar lo que de verdad entro.
    partes.unshift({ path: 'manifest.json', content: JSON.stringify(manifiesto, null, 2) });

    // `rotechos-backup.js` es a su vez PEREZOSO (es uno de los 7 modulos que
    // carga `__lazyLoad`), asi que `__buildSimpleZip` no existe hasta que
    // alguien ha abierto el backup. Medido el 2026-08-31 en navegador: sin
    // esta espera, el boton petaba con '__buildSimpleZip no disponible' para
    // cualquier operario que no hubiera entrado antes en la pestaña de backup
    // — es decir, para casi todos. Los tests unitarios no lo veian porque
    // prueban las piezas puras, no el orden de carga.
    // `__lazyLoad` se declara con `const` a nivel superior en rotechos.js, y un
    // `const` top-level es un binding LEXICO global: se ve por su nombre desde
    // otro script clasico, pero NO cuelga de `window`. Se prueban las dos vias
    // para no depender de por donde este expuesto hoy.
    if (typeof window.__buildSimpleZip !== 'function') {
      let cargar = null;
      try { if (typeof __lazyLoad === 'function') cargar = __lazyLoad; } catch (_) { /* no existe */ }
      if (!cargar && typeof window.__lazyLoad === 'function') cargar = window.__lazyLoad;
      if (cargar) {
        try { await cargar('/js/rotechos-backup.js'); } catch (_) { /* se reporta abajo */ }
      }
    }
    const zip = window.__buildSimpleZip;
    if (typeof zip !== 'function') {
      throw new Error('__buildSimpleZip no disponible (rotechos-backup.js no cargo)');
    }
    // Fecha LOCAL, no UTC. `toISOString()` daba el dia anterior a partir de las
    // 22:00 en horario peninsular: un paquete generado a las 00:30 del dia 31 se
    // llamaba '...-2026-08-30.zip'. El nombre lo lee una persona que va a
    // decir "te mando el de anoche", asi que tiene que cuadrar con su reloj.
    const d = new Date();
    const fecha = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    return { nombre: `rotechos-diag-${fecha}.zip`, bytes: zip(partes), entradas: partes.length };
  }

  async function exportarDiagnostico() {
    const t = (typeof window.t === 'function') ? window.t : ((k, d) => d);
    const toast = (typeof window.toast === 'function') ? window.toast : (() => {});
    try {
      toast(t('msg.diagBuilding', 'Generando paquete de diagnostico…'), 'info');
      const { nombre, bytes, entradas } = await construirPaquete();
      const url = URL.createObjectURL(new Blob([bytes], { type: 'application/zip' }));
      const a = document.createElement('a');
      a.href = url; a.download = nombre;
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 4000);
      toast(t('msg.diagReady', `Diagnostico listo: ${nombre} (${entradas} entradas)`), 'ok');
      if (typeof window.log === 'function') {
        window.log(`Paquete de diagnostico generado: ${nombre} (${entradas} entradas)`, 'sys');
      }
      return nombre;
    } catch (e) {
      toast(t('msg.diagErr', 'No se pudo generar el diagnostico'), 'err');
      if (typeof window.log === 'function') {
        window.log(`Error generando el diagnostico: ${e && e.message}`, 'err');
      }
      throw e;
    }
  }

  window.ROTECHOS_DIAG = { exportar: exportarDiagnostico, construir: construirPaquete, redact: redact, DIAG_DENYLIST: DIAG_DENYLIST };
  window.exportarDiagnostico = exportarDiagnostico;
})();
