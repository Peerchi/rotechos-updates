/* ---
 * rotechos-lint-gcode.js — Validador puro de archivos .g previo a la SD
 *
 * Extraído del monolito (rotechos.js:4214-4240) en la tarjeta kanban
 * t_6621e986 (lote/2026-09-05, monolito-bloque-2).
 *
 * Captura los typos que RRF aborta EN SILENCIO al arrancar/ejecutar:
 *   - Línea >256 car (límite duro de RRF: el firmware las rechaza)
 *   - Sangría con TAB (RRF exige espacios)
 *   - Bloques de control (if/elif/else/while/foreach) sin cuerpo indentado
 *
 * Errores duros (256/TAB) bloquean el guardado desde el editor y disparan
 * un confirmDialog al cargar archivos desde la SD. Los warnings de bloque
 * solo avisan: el firmware los acepta, pero son patrón de error humano.
 *
 * Solo aplica a archivos .g (el resto pasa el lint sin chequeos, ver
 * el short-circuit de la primera línea de `_lintGcode`).
 *
 * Función pura: sin estado, sin DOM, sin acceso a RRF/SM/AppState, sin
 * globales. Recibe (content, filename), devuelve { errors, warnings }.
 *
 * CALLOUTS:
 *   - monolito  rotechos.js:4251 (listener btnEditorSave, al guardar)
 *   - módulo    rotechos-file-ops.js:158 (gate G3, al cargar .g en la SD)
 *
 * Tests: tests/unit/lint-gcode.test.js (15 directos + 5 smoke tests).
 * --- */
(function () {
  'use strict';

  /**
   * Valida un archivo .g antes de subirlo a la SD del Duet.
   * @param {string} content - Contenido del archivo (CRLF o LF).
   * @param {string} filename - Nombre del archivo; si no termina en `.g`, retorna sin chequear.
   * @returns {{errors: string[], warnings: string[]}} Errores duros (bloquean guardado) y avisos.
   */
  function _lintGcode(content, filename) {
    if (!/\.g$/i.test(filename || ``)) return { errors: [], warnings: [] };
    const errors = [], warnings = [];
    const lines = content.split(/\r?\n/);
    const leadWs = (s) => (s.match(/^[ \t]*/) || [``])[0];
    for (let i = 0; i < lines.length; i++) {
      const ln = lines[i], n = i + 1;
      if (ln.length > 256) errors.push(`Línea ${n}: ${ln.length} caracteres (máx 256 en RRF)`);
      if (leadWs(ln).includes(`\t`)) errors.push(`Línea ${n}: sangría con TAB (RRF exige espacios)`);
    }
    const ctrl = /^(\s*)(if|elif|else|while|foreach)\b/;
    for (let i = 0; i < lines.length; i++) {
      const m = lines[i].match(ctrl);
      if (!m) continue;
      const myIndent = m[1].length;
      let j = i + 1;
      while (j < lines.length && lines[j].trim() === ``) j++;
      if (j >= lines.length || leadWs(lines[j]).length <= myIndent)
        warnings.push(`Línea ${i + 1}: bloque "${m[2]}" sin cuerpo indentado`);
    }
    return { errors, warnings };
  }

  // Publicación en globalThis. Mismo patrón que rotechos-dom-helpers.js y
  // rotechos-storage.js: el monolito y rotechos-file-ops.js leen `_lintGcode`
  // desde el script global realm sin necesidad de puente local.
  if (typeof globalThis._lintGcode === 'undefined') {
    globalThis._lintGcode = _lintGcode;
  }
})();
