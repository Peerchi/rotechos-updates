/* ---
 * rotechos-aspiracion-follow.js — Aspiración que sigue al husillo.
 *
 * t_e234f3be, sep-2026. La aspiración se enciende sola cuando el husillo
 * arranca y se apaga tras un retardo configurable cuando se detiene — para
 * que el conducto termine de tragarse la viruta que ya estaba en vuelo.
 *
 * ARQUITECTURA
 *
 *   1) Estado del husillo: lo da el poll existente (data.spindles[0].state),
 *      mismo campo que usa `setSpindleState` en rotechos-spindle.js. Si el
 *      estado es `forward` o `reverse`, husillo activo. Cualquier otro valor
 *      (`stopped`, `unconfigured`) → husillo parado. La función pura
 *      `tickIsSpindleActive(sp)` lo decide — testeable en aislamiento.
 *
 *   2) Resolución del pin: la salida a activar se busca en config-machine.g
 *      parseando `; rotech-pins=…` con la MISMA función que usa el módulo
 *      `rotechos-config-pins-ui.js`. El número M950 P{n} se computa con el
 *      MISMO orden que `generateM950Lines`: las entradas primero (M950 J{n}),
 *      luego las salidas (M950 P{n}), desde window.ROTECHOS_PINES_UI.M950_BASE_P (P6; antes
 *      100, que RRF rechaza). Si `aspiracion` no
 *      tiene pin, se busca `aspiracion_potencia` como fallback. Si ninguno
 *      está asignado, el módulo deja la aspiración DESACTIVADA y la UI debe
 *      decirlo (el interruptor queda deshabilitado con motivo).
 *
 *   3) Máquina de estados: `tick(prevState, newState, opts)` recibe el
 *      estado del husillo del ciclo anterior y del actual, y emite la acción
 *      correspondiente — encender (`on`), apagar (`scheduleOff`) o cancelar
 *      (`cancel`). Es PURA salvo por `setTimeout`/`clearTimeout`, que se
 *      inyectan como dependencias para los tests. Sin `tick`, el módulo
 *      conserva el último estado conocido y dispara las acciones cuando el
 *      poll lo invoca. Tests unitarios ejercitan este contrato.
 *
 *   4) Caso de re-arranque dentro de la ventana: si el husillo vuelve a
 *      arrancar antes de que termine el retardo, el timer pendiente se
 *      CANCELA (la aspiración sigue encendida). Comprobado por test.
 *
 *   5) Persistencia: NO en config.g (hardware). El interruptor y el retardo
 *      se persisten en config-machine.g como comentarios:
 *        ; rotech-aspir-follow=true|false
 *        ; rotech-aspir-delay=N
 *      siguiendo el patrón de `; rotech-sac=true|false` que ya vive en
 *      `rotechos-config-modal.js`. cfgPersistComment sanitiza el valor
 *      (sin `;`, sin `\n`, sin `\r`).
 *
 * DEPENDENCIAS GLOBALES
 *   - AppState.cache._aspirFollow    estado vivo del follow (active, delay,
 *                                     pendingTimer, prevState, pin, reason)
 *   - AppState.cache.spindles        última lectura del poll
 *   - RRF.gcode(cmd)                 envío del M42 P{n} S0/S1
 *   - parseRotechPins(raw)           parser compartido (rotechos-config-pins-ui.js)
 *   - setTimeout / clearTimeout      re-arranque con cancelación
 *
 * LIMITACIÓN CONOCIDA
 * El módulo lee config-machine.g al ARRANCAR (cfgMachineRead) y cachea el
 * pin en `AppState.cache._aspirFollow.pin`. Si el operario cambia la
 * asignación en CONTROLADORA, NO se re-lee automáticamente: la UI debe
 * invalidarlo. Una llamada explícita a `invalidatePin()` (que expone
 * window.ASPIR_FOLLOW) basta — la próxima vez que el poll pida el pin se
 * re-lee. PENDIENTE BANCO: validar conmutación entre funciones en caliente.
 * --- */
(function () {
  'use strict';

  const DEFAULT_DELAY_S = 15;
  const MIN_DELAY_S = 0;
  const MAX_DELAY_S = 600;

  // ─── helpers inyectables ───────────────────────────────────────────────
  function _readConfigMachine() {
    if (typeof window.cfgMachineRead === 'function') return window.cfgMachineRead();
    return Promise.resolve('');
  }

  // Parser de `; rotech-pins=…`. Copia mínima del mismo regex que vive
  // en rotechos-config-pins-ui.js:117 — ese módulo NO expone la función a
  // window (su IIFE solo publica window.ROTECHOS_PINES_UI), y este módulo
  // no puede tocarlo (t_09bea999: otras tarjetas en ese fichero). Si
  // window.parseRotechPins apareciera en el futuro, tiene prioridad sobre
  // esta copia local.
  function _localParseRotechPins(raw) {
    const out = {};
    if (typeof raw !== 'string' || !raw) return out;
    const m = raw.match(/;\s*rotech-pins=([^\n]+)/);
    if (!m) return out;
    for (const part of m[1].split(',')) {
      const seg = part.trim(); if (!seg) continue;
      const f = seg.split(':').map((s) => s.trim());
      const slug = f[0]; if (!slug) continue;
      if (f.length >= 4) out[slug] = { type: f[1] || 'output_digital', pin: f[2] || '', btn: f[3] === '1' ? 1 : 0 };
      else if (f.length === 2) out[slug] = { type: 'output_digital', pin: f[1] || '', btn: 0 };
    }
    return out;
  }

  // Mismo orden que generateM950Lines en rotechos-config-pins-ui.js:
  // entradas (M950 J{n}) primero, luego salidas (M950 P{n}), desde M950_BASE_P.
  function _resolvePinIndex(parsed, slug) {
    if (!parsed || typeof parsed !== 'object') return null;
    const owners = [];
    for (const s of Object.keys(parsed)) {
      const r = parsed[s];
      if (r && r.pin) owners.push({ slug: s, ...r });
    }
    const outputs = owners.filter((o) => o.type !== 'input_digital');
    // El pin del slug pedido debe estar en OUTPUTS (aspiración es digital
    // output). Si por error figurara como input, no se enciende — el módulo
    // mismo rechaza la asignación en sanityCheckAssignment, pero por
    // defensa duplicamos el filtro aquí.
    const idx = outputs.findIndex((o) => o.slug === slug);
    if (idx < 0) return null;
    const base = (typeof window !== 'undefined' && window.ROTECHOS_PINES_UI && Number.isInteger(window.ROTECHOS_PINES_UI.M950_BASE_P))
      ? window.ROTECHOS_PINES_UI.M950_BASE_P : 6;   // mismo valor que rotechos-config-pins-ui.js
    return base + idx;
  }

  function _resolveAspiracionPin(parsed) {
    // aspiracion (relé D.5) tiene prioridad; aspiracion_potencia (V-MOS)
    // es el fallback moderno (t_fa32b4d7, sep-2026).
    const a = _resolvePinIndex(parsed, 'aspiracion');
    if (a != null) return { pin: a, slug: 'aspiracion' };
    const b = _resolvePinIndex(parsed, 'aspiracion_potencia');
    if (b != null) return { pin: b, slug: 'aspiracion_potencia' };
    return null;
  }

  // ─── estado ────────────────────────────────────────────────────────────
  function _ensureState() {
    if (typeof AppState === 'undefined') return null;
    AppState.cache ||= {};
    if (!AppState.cache._aspirFollow) {
      AppState.cache._aspirFollow = {
        enabled: false,
        delay: DEFAULT_DELAY_S,
        pin: null,
        slug: null,
        prevState: null,   // último spindles[0].state visto por el poll
        active: false,     // aspiración ENCENDIDA ahora mismo
        pendingOffTimer: null,
        reason: null,      // motivo por el que no está activa (sin pin…)
      };
    }
    return AppState.cache._aspirFollow;
  }

  // ─── API pública ───────────────────────────────────────────────────────
  const ASPIR_FOLLOW = {
    DEFAULT_DELAY_S,

    /**
     * Lee config-machine.g, parsea `; rotech-pins=…` y guarda el pin
     * resultante. Devuelve la promesa (se ejecuta al boot; no se re-ejecuta
     * en cada tick). Si la función `aspiracion` no está asignada, deja
     * `pin=null` y `reason='sin-pin'`.
     */
    async loadPin() {
      const st = _ensureState();
      if (!st) return null;
      const raw = await _readConfigMachine();
      const parse = (typeof window.parseRotechPins === 'function')
        ? window.parseRotechPins
        : _localParseRotechPins;
      const parsed = parse(raw || '');
      const found = _resolveAspiracionPin(parsed);
      if (found) {
        ASPIR_FOLLOW._setPin(found.pin, found.slug);
      } else {
        st.pin = null;
        st.slug = null;
        st.reason = 'sin-pin';
      }
      return st.pin;
    },

    /**
     * Llamar cuando el operario reasigna los pines en CONTROLADORA para
     * que el siguiente ciclo del poll use el pin actualizado.
     */
    invalidatePin() {
      const st = _ensureState();
      if (st) { st.pin = null; st.slug = null; st.reason = 'invalidated'; }
    },

    /**
     * Asigna el pin directamente. Pensado para que el módulo de
     * CONTROLADORA lo llame tras un `; rotech-pins=…` reescrito, y para
     * que los tests inyecten el pin sin tocar la red.
     */
    _setPin(pin, slug) {
      const st = _ensureState();
      if (!st) return;
      if (pin == null) { st.pin = null; st.slug = null; st.reason = 'invalidated'; return; }
      st.pin = +pin;
      st.slug = String(slug || '');
      st.reason = null;
    },

    /**
     * Refresca el pin desde config-machine.g. Pensado para llamarse cuando
     * rotechos-config-pins-ui.js carga perezosamente al abrir CONTROLADORA
     * (el módulo expone window.ROTECHOS_PINES_UI; hasta entonces el follow
     * usa el parser local — _localParseRotechPins — para sacar el pin de
     * `; rotech-pins=` aunque el módulo de pines no esté en memoria).
     *
     * (t_09bea999) Antes hacía un return temprano con reason='parser-missing'
     * si window.parseRotechPins no estaba, y los e2e que abren HUSILLO sin
     * haber pasado antes por CONTROLADORA veían el interruptor muerto
     * para siempre. Ahora loadPin usa siempre _localParseRotechPins como
     * fallback — el módulo de pines es opcional, no obligatorio.
     */
    async refreshPinFromConfig() {
      const st = _ensureState();
      if (!st) return null;
      return await ASPIR_FOLLOW.loadPin();
    },

    /**
     * Establece enabled/delay SIN persistir. Usado por los tests para
     * inyectar el estado sin tocar config-machine.g; en producción la
     * UI llama a loadConfig al abrir Configuración y a persistConfig al
     * guardar.
     */
    _setEnabledDelay(enabled, delay) {
      const st = _ensureState();
      if (!st) return;
      if (typeof enabled === 'boolean') st.enabled = enabled;
      if (Number.isFinite(+delay)) {
        st.delay = Math.max(MIN_DELAY_S, Math.min(MAX_DELAY_S, Math.round(+delay)));
      }
    },

    /**
     * Persiste enabled/delay en config-machine.g como comentarios
     * `; rotech-aspir-follow=true|false` y `; rotech-aspir-delay=N`.
     * NO toca `; rotech-pins=…` — eso es del módulo de CONTROLADORA.
     * Devuelve la promesa de la cola (cfgPersistComment es serializada).
     */
    persistConfig({ enabled, delay }) {
      const st = _ensureState();
      if (st) {
        if (typeof enabled === 'boolean') st.enabled = enabled;
        if (Number.isFinite(+delay)) {
          const d = Math.max(MIN_DELAY_S, Math.min(MAX_DELAY_S, Math.round(+delay)));
          st.delay = d;
        }
      }
      const writes = [];
      if (typeof enabled === 'boolean' && typeof window.cfgPersistComment === 'function') {
        writes.push(window.cfgPersistComment('rotech-aspir-follow', enabled ? 'true' : 'false'));
      }
      if (Number.isFinite(+delay) && typeof window.cfgPersistComment === 'function') {
        writes.push(window.cfgPersistComment('rotech-aspir-delay', String(st ? st.delay : +delay)));
      }
      return Promise.all(writes);
    },

    /**
     * Carga enabled/delay desde un texto ya leído de config-machine.g (no
     * toca la red). Función PURA + el side-effect sobre AppState.cache.
     * Si el comentario no existe, devuelve el estado a sus defaults
     * (enabled=false, delay=DEFAULT_DELAY_S) — el operario que abre
     * Configuración con config-machine.g vacío ve el interruptor apagado
     * por defecto, no el último valor vivo que el módulo conservase.
     */
    loadConfig(rawText) {
      const st = _ensureState();
      if (!st) return;
      // Reset a defaults ANTES de aplicar lo que encontremos en el raw.
      // Sin esto, abrir Configuración con un raw SIN los comentarios no
      // refresca la UI y el operario ve el último valor de la sesión.
      st.enabled = false;
      st.delay = DEFAULT_DELAY_S;
      const txt = String(rawText || '');
      const ef = txt.match(/;\s*rotech-aspir-follow=(true|false)/);
      if (ef) st.enabled = ef[1] === 'true';
      const ed = txt.match(/;\s*rotech-aspir-delay=(\d+)/);
      if (ed) {
        const d = parseInt(ed[1], 10);
        if (Number.isFinite(d)) st.delay = Math.max(MIN_DELAY_S, Math.min(MAX_DELAY_S, d));
      }
    },

    /**
     * Lee el último estado conocido del husillo de la caché del poll y
     * aplica la transición. Devuelve la acción tomada para diagnóstico.
     *
     *  - 'on'         se acaba de encender la aspiración (M42 P{n} S1)
     *  - 'scheduleOff'se acaba de programar el apagado (timer pendiente)
     *  - 'off-now'    se acaba de apagar YA (timer disparó)
     *  - 'cancel'     se canceló un apagado pendiente (re-arranque)
     *  - 'noop'       no había nada que hacer (estado == anterior)
     *  - 'skip'       el módulo no está activo (sin pin o disabled)
     */
    tick(currentSp) {
      const st = _ensureState();
      if (!st) return 'noop';
      if (!st.enabled) return 'skip';
      if (st.pin == null) {
        // Sin pin no accionamos nada. Cargar pin si aún no se hizo.
        if (st.reason === null) ASPIR_FOLLOW.loadPin();
        return 'skip';
      }
      const isActive = tickIsSpindleActive(currentSp);
      const wasActive = tickIsSpindleActive(st.prevState);
      const cmd = (s) => `M42 P${st.pin} S${s}`;
      // Re-arranque dentro de la ventana: cancela el apagado pendiente.
      if (isActive && st.pendingOffTimer != null) {
        clearTimeout(st.pendingOffTimer);
        st.pendingOffTimer = null;
        st.prevState = currentSp;
        return 'cancel';
      }
      if (isActive && !wasActive) {
        // 0 → 1: encender YA
        st.prevState = currentSp;
        st.active = true;
        if (typeof RRF !== 'undefined' && RRF && typeof RRF.gcode === 'function') {
          RRF.gcode(cmd('1')).catch(() => {});
        }
        return 'on';
      }
      if (!isActive && wasActive) {
        // 1 → 0: programar apagado tras el retardo
        st.prevState = currentSp;
        const delayMs = Math.max(0, st.delay) * 1000;
        if (st.pendingOffTimer != null) clearTimeout(st.pendingOffTimer);
        st.pendingOffTimer = setTimeout(() => {
          st.pendingOffTimer = null;
          st.active = false;
          if (typeof RRF !== 'undefined' && RRF && typeof RRF.gcode === 'function') {
            RRF.gcode(cmd('0')).catch(() => {});
          }
        }, delayMs);
        return 'scheduleOff';
      }
      // isActive == wasActive: no hay transición; o ya estaba apagado, o
      // ya estaba encendido sin cambio. Mantener prevState por si la
      // siguiente transición quiere compararlo.
      st.prevState = currentSp;
      return 'noop';
    },

    getState() {
      const st = _ensureState();
      if (!st) return null;
      // Devolver una COPIA — no la referencia. Si el test muta `st.pin`
      // pensando que cambia AppState.cache, no lo hace. Se devuelve copia
      // para que el consumidor NO pueda mutar el estado del módulo.
      return {
        enabled: st.enabled,
        delay: st.delay,
        pin: st.pin,
        slug: st.slug,
        active: st.active,
        pending: st.pendingOffTimer != null,
        reason: st.reason,
      };
    },

    /**
     * Apaga YA la aspiración (sin esperar al retardo). Usado cuando el
     * operario apaga el interruptor — no queremos que la aspiración siga
     * corriendo 15 s con el husillo ya en OFF.
     */
    cancel() {
      const st = _ensureState();
      if (!st) return;
      if (st.pendingOffTimer != null) {
        clearTimeout(st.pendingOffTimer);
        st.pendingOffTimer = null;
      }
      if (st.active && st.pin != null) {
        if (typeof RRF !== 'undefined' && RRF && typeof RRF.gcode === 'function') {
          RRF.gcode(`M42 P${st.pin} S0`).catch(() => {});
        }
      }
      st.active = false;
    },
  };

  // ─── función pura testeable ────────────────────────────────────────────
  /**
   * Decide si el estado del husillo indica que está ACTIVO (forward/reverse)
   * o o o PARADO (cualquier otro, incluido null/undefined).
   * Coherente con el guard de setSpindleState en rotechos-spindle.js:141.
   */
  function tickIsSpindleActive(sp) {
    if (!sp || typeof sp !== 'object') return false;
    const s = sp.state;
    if (typeof s !== 'string') return false;
    return s !== 'stopped' && s !== 'unconfigured' && s !== '';
  }

  // Fachada + centinela
  window.ASPIR_FOLLOW = ASPIR_FOLLOW;
  window.tickIsSpindleActive = tickIsSpindleActive;
})();