/* ---
   ROTECHOS — Persistencia de configuración (config.g / config-machine.g)
   Extraído de rotechos.js (jul-2026) SIN cambios de lógica.
   Lectura/escritura en la SD con verificación read-back, y persistencia
   de globals per-máquina (`set global.X`) con cola serializada.
   Dependencias en runtime (todas globales, resueltas tras la carga defer):
   TARGET_IP, _fetchRRF, toast (rotechos.js) y t (rotechos-i18n.js).
   Este archivo carga ANTES que rotechos.js (ver index.html).
   ═══════════════════════════════════════════════════════════════ */
// API pública consumida por rotechos.js (cross-file); ESLint no ve esos usos:
/* exported cfgRead, cfgWrite, cfgGet, cfgPersistComment, cfgPersistGlobalLine, cfgPersistPin, cfgGetPin, cfgRemovePin, parseBannedDrivers, cfgPersistBannedDrivers, isDriverBanned, isMachineCalibrated, cfgGetToolsTable, cfgSetToolsTable */
const CFGPATH       = `0:/sys/config.g`;
const CFG_MACHINE   = `0:/sys/config-machine.g`;
let _cfgRaw          = ``,
    _cfgMachineRaw   = ``;
// ¿La última lectura de config-machine.g fue VÁLIDA? Un `_cfgMachineRaw` vacío
// tiene dos causas que NO se pueden confundir: máquina virgen (el archivo aún
// no existe → guardar y crearlo es correcto) o fallo de lectura (red caída,
// HTTP 500 → guardar subiría un archivo de una línea ENCIMA de la calibración
// del cliente y la borraría). Este flag distingue las dos. Ver H-2-01.
let _cfgMachineLoadOk = false;

// Defense-in-depth multi-pestaña (audit adversarial jul-2026 F2/F8 + Claude).
// Si la pestaña actual es líder y va a tocar config.g / config-machine.g, pide
// a la OTRA pestaña que suelte el liderato via BroadcastChannel y espera un
// `yield-ack` breve. Cierra el TOCTOU entre pestañas (dos `cfgPersistComment`
// casi simultáneos pueden entrelazar read-modify-write). Degrada a no-op si no
// hay BC o si esta pestaña ya está en read-only. Timeout 1500ms.
function _requestYieldAndAck() {
  return new Promise((resolve) => {
    try {
      if (typeof BroadcastChannel === `undefined`) return resolve(false);
      const bc = (typeof AppState !== `undefined` && AppState?.tab?.bc) || null;
      if (!bc) return resolve(false);
      if (!AppState.tab.isLeader) return resolve(false);
      const onAck = (e) => {
        if (e.data && e.data.type === `yield-ack` && e.data.id === AppState.tab.id) {
          try { bc.removeEventListener(`message`, onAck); } catch (_) {}
          resolve(true);
        }
      };
      bc.addEventListener(`message`, onAck);
      try { bc.postMessage({ type: `request-yield`, id: AppState.tab.id }); }
      catch (_) { try { bc.removeEventListener(`message`, onAck); } catch (_) {} return resolve(false); }
      setTimeout(() => {
        try { bc.removeEventListener(`message`, onAck); } catch (_) {}
        resolve(false);
      }, 1500);
    } catch (_) { resolve(false); }
  });
}

async function _cfgReadPath(path, cacheName) {
  try {
    const r = await RRF.download(path);
    if (!r.ok) {
      // 404 en config-machine.g = máquina virgen (todavía sin calibrar). Es un
      // caso legítimo: lectura VÁLIDA con contenido vacío.
      if (path === CFG_MACHINE && r.status === 404) {
        ((_cfgMachineRaw = ``), (_cfgMachineLoadOk = true));
        LOG.warn(`cfgMachineRead: config-machine.g no existe (maquina virgen)`);
        return ``;
      }
      throw Error(`HTTP ` + r.status);
    }
    let text = await r.text();
    // Defense-in-depth (audit adversarial jul-2026 F4 + Claude):
    //   - BOM UTF-8 (\xEF\xBB\xBF) al inicio del archivo: si config.g lo trae
    //     (típico al editar con Notepad en Windows y guardar como UTF-8), el
    //     primer comando (p.ej. `M92`) no casa con el ancla `^` y se ignora.
    //   - CRLF Windows (\r\n): algunos matchers regex consumen el `\r` como
    //     parte del valor, contaminando cfgGet con strings tipo '80\r'.
    //     Estandarizamos a LF antes de pasar el texto a los parsers.
    text = text.replace(/^\uFEFF/, '').replace(/\r\n/g, '\n');
    if (cacheName === 'raw') _cfgRaw = text;
    else if (cacheName === 'machine') ((_cfgMachineRaw = text), (_cfgMachineLoadOk = true));
    return text;
  } catch (e) {
    // Fallo de lectura REAL (red caída, HTTP 500, timeout). NO es "no existe":
    // marcamos la lectura como inválida para que Guardar ABORTE en vez de
    // subir un config-machine.g vacío sobre la calibración del cliente.
    if (path === CFG_MACHINE) {
      _cfgMachineLoadOk = false;
      LOG.warn(`cfgMachineRead: fallo de lectura (${e.message}) — no se puede guardar hasta releer`);
      return ``;
    }
    return (toast(t(`msg.noSePudoLeer`, `No se pudo leer ` + path.split('/').pop()), `err`), null);
  }
}
// eslint-disable-next-line no-unused-vars -- usado por cfgRead fuera de este módulo (rotechos.js:198,235 (typeof) + rotechos-config-modal.js:164,207,1580 + rotechos.js:3393)
// ── Serializacion de lecturas (t_0e8e4716, 2026-09-06) ────────────────────
// Dos llamadas concurrentes a la MISMA lectura emitian DOS `rr_download`
// identicos casi simultaneos y uno se quedaba sin respuesta: el `await` de
// quien llamo colgaba para siempre. Sintoma medido: el operario pulsa
// "Guardar asignacion de pines", savePines entra, llega al
// `await cfgMachineRead()` y no vuelve; config-machine.g queda intacto y la UI
// no dice nada. (docs/dev/hallazgos/2026-09-05_flake-guardado-pines.md)
//
// Pasaba porque el click en Guardar burbujea hasta el panel #mcfgTabPines y
// dispara _onPinesTabOpen, que hace su propia lectura en paralelo. Eso se
// arregla aparte, pero la defensa correcta va AQUI: dos lecturas del mismo
// fichero deben compartir UN fetch, no competir.
//
// No es solo cosa de tests: contra la Scylla real, dos GET simultaneos del
// mismo fichero por WiFi es exactamente lo que no se debe hacer.
//
// La promesa en vuelo se guarda por ruta y se limpia al resolver, asi que la
// siguiente lectura vuelve a ir a la SD (esto NO es una cache de contenido:
// el contenido lo siguen cacheando _cfgRaw/_cfgMachineRaw como antes).
const _lecturasEnVuelo = new Map();
function _cfgReadCoalesced(path, cacheName) {
  const enVuelo = _lecturasEnVuelo.get(path);
  if (enVuelo) return enVuelo;
  const p = _cfgReadPath(path, cacheName).finally(() => _lecturasEnVuelo.delete(path));
  _lecturasEnVuelo.set(path, p);
  return p;
}
// eslint-disable-next-line no-unused-vars -- global, lo usan otros modulos
async function cfgRead()              { return _cfgReadCoalesced(CFGPATH, 'raw'); }
async function cfgMachineRead()       { return _cfgReadCoalesced(CFG_MACHINE, 'machine'); }
// FIX H-4-02 (carril 4): defensa en profundidad — si el operario cambió de pestaña
// y volvió sin relectura, _cfgMachineLoadOk puede seguir en false del intento
// anterior. cfgMachineWrite reescribiría encima de la SD con el contenido en RAM
// sin haber releído la calibración real. Todos los call-sites ya consultan el
// flag antes de invocar, pero la propia función debe también blindarse.
// eslint-disable-next-line no-unused-vars -- usado por rotechos-config-modal.js (los cfgPersist* de este fichero usan _cfgMachineWriteDirecto: ver el aviso de reentrada)
async function cfgMachineWrite(content) {
  if (typeof _cfgMachineLoadOk !== 'undefined' && !_cfgMachineLoadOk) {
    LOG.error(`cfgMachineWrite abortado: _cfgMachineLoadOk=false (sin lectura válida reciente)`);
    toast(t(`msg.configgNoCargado`, `config-machine.g no cargado — recarga Configuración antes de guardar`), `err`);
    return !1;
  }
  // A§10 (auditoria 15-sep): config-machine.g tiene DOS clases de escritor. Los
  // `onchange` instantaneos van serializados en `_cfgWriteQueue` y releen dentro
  // de la cola; el Guardar generico llamaba aqui con un `content` construido
  // sobre un `raw` leido ANTES. Reproducido ejecutando el codigo
  // (tests/unit/cfg-carrera-escrituras.test.js): el Guardar pisaba
  // `set global.safe_clearance` y, como en caliente SI se aplicaba, el operario
  // no veia nada — el fallo salia al REINICIAR la maquina.
  //
  // Aqui va la segunda mitad: antes de escribir, releer la SD y compararla con
  // la base de la que salio este `content` (`_cfgMachineRaw` al entrar). Si no
  // coinciden, alguien escribio por detras y este `content` esta ciego: se
  // ABORTA con aviso. Perder un guardado avisando es malo; perderlo en silencio,
  // sobre la calibracion del cliente, es peor.
  //
  // NO se encola: la primera version si, y lo pago un e2e — con las dos
  // escrituras del mismo gesto (blur y click de Guardar) la segunda esperaba a
  // la primera y el boton no salia de «Guardando…». Medido en el navegador: dos
  // ENCOLA, un EJECUTA. La serializacion ya la da el `cfgEsperarEscrituras()`
  // del llamante.
  const _base = _cfgMachineRaw;
  if (_base != null) {
    const actual = await cfgMachineRead();
    const _n = (x) => String(x ?? ``).replace(/\r\n/g, `\n`).replace(/\s+$/, ``);
    if (_n(actual) !== _n(_base)) {
      LOG.warn(`cfgMachineWrite: config-machine.g cambio desde que se leyo — guardado ABORTADO para no pisarlo`);
      toast(t(`msg.configCambioDetras`,
        `Otro cambio se guardó en la máquina mientras editabas, así que este guardado se ha CANCELADO para no borrarlo. No se ha perdido nada: cierra CONFIGURACIÓN, vuelve a abrirla y repite el cambio.`), `err`);
      return !1;
    }
  }
  return _cfgMachineWriteDirecto(content);
}

// Escritura de config-machine.g SIN comprobar la base ni releer. Para quien ya
// esta dentro de `_cfgWriteQueue` (los `cfgPersist*`), que releen ellos mismos.
function _cfgMachineWriteDirecto(content) {
  return _cfgWritePath(content, CFG_MACHINE, 'machine');
}

// A§10, primera mitad: el Guardar generico espera aqui a que la cola de
// escrituras instantaneas se vacie ANTES de construir su `content`, para que
// parta del estado real de la SD y no de uno anterior al `onchange` del blur.
// eslint-disable-next-line no-unused-vars -- usado por rotechos-config-modal.js
function cfgEsperarEscrituras() { return _cfgWriteQueue; }
async function _cfgWritePath(content, path, cacheName) {
  const fname = path.split('/').pop();
  const encoded = encodeURIComponent(path);
  // Defense-in-depth multi-pestaña (audit adversarial jul-2026 F2/F8 +
  // Claude): antes de tocar config.g/config-machine.g, pedimos yield-control
  // por BroadcastChannel si OTRA pestaña es líder. Esto cierra el TOCTOU
  // entre pestañas (dos `cfgPersistComment` casi simultáneos pueden entrelazar
  // read-modify-write). Degrada a no-op si no hay BC o si la pestaña actual
  // ya es read-only. Timeout 1500 ms para no bloquear la UI.
  await _requestYieldAndAck();
  // Normaliza para comparar el read-back sin falsos negativos por fin de línea
  // (\r\n) o espacios/saltos finales que el servidor de la SD pudiera ajustar.
  const _norm = (s) =>
    String(s).replace(/\r\n/g, `\n`).replace(/[ \t]+$/gm, ``).replace(/\s+$/, ``);
  const _upload = async () => {
    const blob = new Blob([content], { type: `text/plain` }),
      r = await _fetchRRF(
        `${TARGET_IP}/rr_upload?name=${encoded}&time=${Date.now()}`,
        { method: `POST`, body: blob }, 15000,
      );
    if (!r.ok) throw Error(`HTTP ` + r.status);
  };
  const _readback = async () => {
    const r = await RRF.download(path, { timeoutMs: 8000 });
    if (!r.ok) throw Error(`read-back HTTP ` + r.status);
    return await r.text();
  };
  try {
    // HUECO-2 (t_e558a603): guardar es la operacion lenta MEDIDA del acta
    // 2026-09-06_C-robustez-percibida.md — sube y ADEMAS relee para verificar,
    // asi que son dos viajes a la SD por WiFi. Si tarda, el operario no tenia
    // ninguna senal y parecia colgado. El aviso se CANCELA en cuanto termina:
    // no anade espera, solo deja de callar. Guard por typeof: los unitarios
    // cargan este modulo sin el resto de la UI.
    const _lento = (typeof window !== `undefined` && window.rotechosOpFeedback)
      ? window.rotechosOpFeedback.opSlow(t(`msg.opGuardarConfig`, `guardar la configuración`) + ` (${fname})`)
      : null;
    try {
      await _upload();
      // VERIFICACIÓN DE PERSISTENCIA: releer de la SD y confirmar que
      // quedó EXACTAMENTE lo que subimos. Cierra el agujero de "guardé y vi OK
      // pero el archivo no cambió" (upload 200 pero sin persistir / SD lenta).
      let back = await _readback();
      if (_norm(back) !== _norm(content)) {
        LOG.warn(`cfgWrite(${fname}): read-back no coincide — reintentando subida…`);
        await _upload();
        back = await _readback();
        if (_norm(back) !== _norm(content)) {
          LOG.error(`cfgWrite(${fname}): read-back FALLÓ tras reintento — la SD no refleja el cambio`);
          toast(t(`msg.elGuardadoNoSe`, `Guardado NO confirmado en la SD — se reintentó la subida y la lectura de vuelta no coincide. Tu cambio NO está en la SD. Repite el guardado; si falla otra vez, revisa la conexión WiFi con la máquina y que la SD no esté llena ni protegida contra escritura.`), `err`);
          return !1;
        }
      }
      if (cacheName === 'raw') _cfgRaw = content;
      else if (cacheName === 'machine') _cfgMachineRaw = content;
      return !0;
    } finally {
      if (_lento) _lento();
    }
  } catch (e) {
    LOG.error(`cfgWrite(${fname}) error:`, e);
    // HUECO-3 (t_e558a603): el toast decia «Error al guardar <fichero> — HTTP 500».
    // Nombra el fichero pero no la OPERACION ni que hacer, y el `e.message` crudo
    // (`HTTP 500`, `read-back HTTP 500`) no le dice nada al operario. Ahora la
    // frase nombra la operacion y traduce el codigo a algo accionable; el mensaje
    // tecnico se conserva detras para no perder diagnostico.
    const _tecnico = String((e && e.message) || e);
    const _http = /HTTP\s+(\d{3})/.exec(_tecnico);
    const _of = (typeof window !== `undefined` && window.rotechosOpFeedback) || null;
    if (_of) {
      _of.opFail(
        t(`msg.opGuardarConfig`, `guardar la configuración`) + ` (${fname})`,
        _http
          ? { reason: `http`, status: Number(_http[1]) }
          : { reason: `network`, error: _tecnico },
      );
    } else {
      toast(t(`msg.saveConfigErr`, `Error al guardar ` + fname + ` — `) + _tecnico, `err`);
    }
    return !1;
  }
}
// eslint-disable-next-line no-unused-vars -- usado por cfgWrite fuera de este módulo (rotechos.js:199,236 (typeof) + rotechos-config-modal.js:2126,2317 + rotechos.js:3393)
async function cfgWrite(content)              { return _cfgWritePath(content, CFGPATH, 'raw'); }
function cfgReplaceLine(content, pattern, newLine) {
  const safePattern = pattern.replace(/[.*+?^${}()|[\\]\\\\]/g, '\\\\$&');
  const re = RegExp(`^(${safePattern}[^\\n]*)`, `m`);
  return re.test(content)
    ? content.replace(re, newLine)
    : content + `\n` + newLine;
}

/**
 * Persiste un global per-máquina en formato `set global.X = value` (runtime, sin
 * redeclaración). Para usar en config-machine.g: los globals YA están declarados en
 * globals.g y config-machine.g corre DESPUÉS; `set global.X =` los actualiza sin
 * riesgo de doble declaración que abortaría RRF.
 *
 * Si el patrón `set global.X =` ya existe, lo reemplaza. Si no, inyecta la línea
 * tras el último `set global.` o al final del archivo.
 */
function cfgSetGlobal(content, gName, value) {
  const setLine = `set global.${gName} = ${value}`;
  const pattern = `set global.${gName} =`;
  const safePattern = pattern.replace(/[.*+?^${}()|[\\]\\\\]/g, '\\\\$&');
  const re = RegExp(`^(${safePattern}[^\\n]*)`, `m`);
  // 15-sep: en config.g, un `set global` detrás de la carga de config-machine.g pisa la
  // calibración en cada arranque (z_sensor_to_table del SAC). Va, o se mueve, DELANTE.
  const carga = /^if fileexists\("0:\/sys\/config-machine\.g"\)/m;
  const iCarga = content.search(carga);
  if (iCarga > -1) {
    const m = re.exec(content);
    if (m && m.index < iCarga) return content.replace(re, setLine);
    const fin = m ? content.indexOf(`\n`, m.index) : -1;
    const sin = m ? content.slice(0, m.index) + (fin < 0 ? `` : content.slice(fin + 1)) : content;
    const at = sin.search(carga);
    return sin.slice(0, at) + setLine + `\n` + sin.slice(at);
  }
  if (re.test(content)) return content.replace(re, setLine);
  // No existe aún → inyectar tras el último set global o al final
  const lastSet = content.lastIndexOf(`set global.`);
  if (lastSet > -1) {
    const endOfLine = content.indexOf(`\n`, lastSet);
    return content.slice(0, endOfLine + 1) + setLine + `\n` + content.slice(endOfLine + 1);
  }
  return content + `\n` + setLine + `\n`;
}
// eslint-disable-next-line no-unused-vars -- usado por cfgGet fuera de este módulo (rotechos-config-modal.js:485,697,700,744,1136,1286-7,1305,1351-2,1391)
function cfgGet(line, param) {
  const m = line?.match(RegExp(param + `(-?[\\d.]+)`));
  return m ? m[1] : ``;
}

// ---
// t_f8b27b80 (2026-09-05): primitivas para los 3 huecos nuevos del modal
// CONFIGURACIÓN. M84, M586 y M593 son líneas de config.g (no globals) que
// la UI exponía como solo-lectura. El handler del modal usa estas dos
// funciones para leer/escribir; el resto del flujo (cfgMachineWrite,
// read-back, BroadcastChannel) lo trae el código existente.
// ---

/**
 * Lee el valor de un parámetro de la PRIMERA línea que empiece por `mcode `
 * (o `mcode` sin espacio — M84 aparece como `M84 S86400` o `M84` solo, según
 * tenga o no parámetros). Devuelve `''` si no encuentra el mcode o el
 * parámetro. Pura: no toca red, no lee ficheros.
 *
 * Ejemplos:
 *   cfgGetMcodeParam('M84 S86400',           'M84', 'S') → '86400'
 *   cfgGetMcodeParam('M586 P1 S1',           'M586', 'S') → '1'  (toma P1)
 *   cfgGetMcodeParam('M586 P1 S0\nM586 P2 S1','M586','S') → '0' (toma primera línea)
 */
// eslint-disable-next-line no-unused-vars -- lo usa rotechos-config-modal.js
function cfgGetMcodeParam(content, mcode, param) {
  const re = RegExp(`^${mcode}\\b[^\\n]*`, `m`);
  const m = (content || ``).match(re);
  if (!m) return ``;
  const line = m[0];
  // Para P y F, regex tolerante con valores entrecomillados (M593 P"zvd" F40).
  if (param === `P`) {
    const quoted = line.match(/P"([^"]+)"/);
    if (quoted) return quoted[1];
    return cfgGet(line, `P`);
  }
  return cfgGet(line, param);
}

/**
 * Sustituye TODAS las líneas que empiezan por `anchor` (p.ej. `M84`,
 * `M586 P1`, `M593`) por `newLine`. Si no encuentra ninguna, añade
 * `newLine` al final. Es una variante de cfgReplaceLine que ignora el
 * sufijo del anchor: cfgReplaceLine solo acepta un patrón sin regex
 * especiales y matchea al inicio de la línea; aquí lo usamos para
 * anchors con espacios (M586 P1) que cfgReplaceLine también soporta
 * pero queremos semántica "reemplaza todas las líneas que coincidan".
 *
 * Ejemplos:
 *   cfgReplaceMcode('M84 S30\nM18 X Y', 'M84', 'M84 S86400 ; Desactivar timeout')
 *     → 'M84 S86400 ; Desactivar timeout\nM18 X Y'
 *   cfgReplaceMcode('M586 P0 S1\nM586 P1 S0', 'M586 P1', 'M586 P1 S1 ; ...')
 *     → 'M586 P0 S1\nM586 P1 S1 ; ...'
 */
// eslint-disable-next-line no-unused-vars -- usado por rotechos-config-modal.js (t_f8b27b80)
function cfgReplaceMcode(content, anchor, newLine) {
  const safe = anchor.replace(/[.*+?^${}()|[\]\\]/g, `\\$&`);
  const re = RegExp(`^${safe}[^\\n]*\\n?`, `gm`);
  if (re.test(content)) return content.replace(re, newLine + `\n`);
  return content + `\n` + newLine + `\n`;
}

/**
 * t_f8b27b80 (2026-09-05) — predicado puro para el aviso "Z cae por gravedad"
 * de CONFIGURACIÓN → TIMEOUT MOTORES. Z retiene el peso del husillo porque el
 * tornillo NO es autoblocante: si se desenergiza con la fresa cerca de la mesa,
 * cae hasta tocar la pieza o la propia mesa. La UI avisa al guardar cuando el
 * operario baja el M84 S por debajo de 1 minuto (sigue siendo legal: mantenimiento
 * sin husillo es legítimo; el aviso es para que el operario lo haga a propósito).
 *
 *   m84NeedsZDropWarn(86400) === false   (defecto de fábrica: 1 día)
 *   m84NeedsZDropWarn(0)     === true    (S0: semantica NO verificada — se avisa)
 *   m84NeedsZDropWarn(30)    === true    (Z puede caer antes de 1 min sin movimiento)
 *   m84NeedsZDropWarn(59)    === true
 *   m84NeedsZDropWarn(60)    === false   (1 min = umbral a partir del cual ya avisa)
 *   m84NeedsZDropWarn(NaN)   === false   (no es un valor válido → caller aborta arriba)
 *
 * Pura: sin DOM, sin red, sin i18n. Vive aquí al lado de cfgGetMcodeParam/
 * cfgReplaceMcode (mismas razones: t_f8b27b80, módulo canónico de persistencia).
 */
// eslint-disable-next-line no-unused-vars -- usado por rotechos-config-modal.js (t_f8b27b80)
function m84NeedsZDropWarn(secs) {
  // Tipo estricto: la UI pasa `parseInt(..., 10)` (número). Si llega un string
  // es bug del caller → fail-safe (no avisa). Esto evita que un cambio futuro
  // en la UI que pase string-por-error empiece a falsear el aviso.
  if (typeof secs !== `number` || !Number.isFinite(secs) || secs < 0) return false;
  // Por debajo de 1 min el operario esta pidiendo soltar Z antes de tiempo: la
  // fresa puede caer si el siguiente movimiento no llega en ese intervalo.
  //
  // EL CERO TAMBIEN AVISA (corregido 2026-09-05). La version original lo daba
  // por "riesgo cero" razonando que S0 = "soltar ahora, X/Y tambien". Ese
  // razonamiento se contradice: si suelta ahora, la Z queda desenergizada, que
  // es justo el escenario del que avisa esta funcion. Y la lectura contraria
  // —S0 = no expirar nunca— tampoco esta verificada contra RRF 3.5.4.
  //
  // Con las dos lecturas sin comprobar y una de ellas peligrosa, se avisa. Un
  // aviso de mas en el valor que alguien teclea para "desactivar esto" cuesta
  // un clic; no avisar cuesta una fresa contra la mesa. PENDIENTE BANCO:
  // comprobar que hace de verdad M84 S0 en la Scylla y ajustar esto con la
  // medicion delante.
  return secs >= 0 && secs < 60;
}

/**
 * t_f8b27b80 (2026-09-05) — predicado puro para el aviso "abre la máquina a
 * la red sin autenticación" de CONFIGURACIÓN → PROTOCOLOS DE RED. FTP (M586 P1)
 * y Telnet (M586 P2) NO exigen credenciales; dejarlos apagados es el defecto
 * correcto. Encender UNO de los dos abre la máquina a la red local a cualquiera
 * que sepa la IP; HTTP (P0) NO se expone aquí (romper la sesión web no compensa).
 *
 *   networkOpensAccess(false, false) === false   (defecto de fábrica)
 *   networkOpensAccess(true,  false) === true
 *   networkOpensAccess(false, true ) === true
 *   networkOpensAccess(true,  true ) === true
 *
 * Pura: mismo rationale que m84NeedsZDropWarn.
 */
// eslint-disable-next-line no-unused-vars -- usado por rotechos-config-modal.js (t_f8b27b80)
function networkOpensAccess(ftpOn, telnetOn) {
  return !!ftpOn || !!telnetOn;
}

/**
 * Persiste un ajuste de UI como comentario `; {key}={value}` en config.g (SSOT
 * en la SD). Sustituye al uso de localStorage para que la configuración sea
 * permanente y visible desde cualquier navegador.
 *
 * ROBUSTEZ (fix #2): cada escritura
 *   1. se SERIALIZA en una cola (_cfgWriteQueue) para que dos toggles rápidos
 *      (p.ej. SAC y luego modo coord) no hagan read-modify-write entrelazados y
 *      uno revierta al otro;
 *   2. relee config.g FRESCO de la SD justo antes de modificar (no usa el cache
 *      _cfgRaw, que podría estar obsoleto si otra pestaña/navegador lo cambió).
 * cfgWrite ya muestra toast de error, así que el usuario tiene feedback si falla.
 * Devuelve la promesa de la operación (los callers pueden await si lo necesitan).
 *
 * SANITIZACIÓN (audit jul-2026 F4/R6): `value` puede contener texto (p.ej.
 * `cfgPersistComment('rotech-mist-note', 'línea\nmaliciosa')`). Sin sanitizar,
 * el `\n` se inyectaría en config.g como nueva línea con texto arbitrario y
 * el `;` se confundiría con un comentario RRF. Esto podría romper el parser
 * de M-code o inyectar comandos en el arranque. Filtro `;` y `\n`/`\r` antes
 * de escribir — si el filtro recorta, el valor almacenado queda "vacío en
 * parte", pero es preferible a corrupciones silenciosas.
 */
let _cfgWriteQueue = Promise.resolve();
// Encola una escritura que no es un cfgPersist* (el M208 al vuelo de LIMITES).
// Fuera de la cola, dos campos seguidos leian la misma base y el segundo pisaba
// al primero en silencio, y Guardar no lo esperaba (e2e-calibracion-escrituras-en-serie).
// eslint-disable-next-line no-unused-vars -- usado por rotechos-config-modal.js
function cfgEnCola(fn) {
  _cfgWriteQueue = _cfgWriteQueue.then(fn).catch((e) => (LOG.warn(`cfgEnCola:`, e), false));
  return _cfgWriteQueue;
}
function _sanitizeCommentValue(v) {
  return String(v).replace(/[;\n\r]/g, '');
}
// eslint-disable-next-line no-unused-vars -- usado por cfgPersistComment fuera de este módulo (rotechos.js:4136,4142 + rotechos-led.js:61)
function cfgPersistComment(key, value) {
  const safeVal = _sanitizeCommentValue(value);
  _cfgWriteQueue = _cfgWriteQueue
    .then(async () => {
      const raw = await cfgMachineRead();
      if (raw == null) return false;
      // MISMO fail-closed que cfgPersistGlobalLine, y por el mismo motivo: una
      // lectura fallida devuelve cadena VACÍA, no null, y `"" == null` es false.
      // Aquí es peor todavía: cfgReplaceLine AÑADE la línea al final cuando no
      // encuentra el patrón, así que sobre un raw vacío escribe un
      // config-machine.g de UNA línea encima de la calibración del cliente.
      // El fix de 005d751 arregló cfgPersistGlobalLine y NO miró esta función,
      // que está 18 líneas más arriba en este mismo fichero: se arregló la
      // instancia, no la clase. Call-sites afectados: rotech-sac
      // (rotechos-config-modal.js:1467), rotech-led (rotechos-led.js:62) y
      // rotech-coordmode (rotechos.js:3825).
      if (typeof _cfgMachineLoadOk !== 'undefined' && !_cfgMachineLoadOk) {
        toast(
          t(`msg.configMaquinaNoLeida`, `No se pudo leer config-machine.g — guardado ABORTADO para no machacar tu calibración (pasos/mm, corrientes, área, sonda). NO se ha guardado NADA. Qué hacer: (1) revisa la conexión WiFi con la máquina, (2) abre CONFIGURACIÓN → abrir y verifica que la pestaña MOTORES/VELOCIDADES/SOFT-LIMITS/BACKLASH muestra tus valores reales, (3) reintenta el cambio que querías guardar. Si tu calibración ya no aparece en pantalla, NO toques nada y contacta con soporte.`),
          `err`,
        );
        LOG.warn(`cfgPersistComment(${key}): lectura invalida — ABORTADO para no borrar la calibracion`);
        return false;
      }
      return await _cfgMachineWriteDirecto(cfgReplaceLine(raw, `; ${key}=`, `; ${key}=${safeVal}`));
    })
    .catch((e) => (LOG.warn(`cfgPersistComment(${key}):`, e), false));
  return _cfgWriteQueue;
}

/**
 * Persiste un global per-máquina en config-machine.g usando cfgSetGlobal
 * (formato `set global.X = value`, sin riesgo de doble declaración).
 * Elimina el bug del escape de `cfgReplaceLine` con `global ${name}\s*=`.
 */
// eslint-disable-next-line no-unused-vars -- usado por cfgPersistGlobalLine fuera de este módulo (rotechos.js:3982 + rotechos-config-modal.js:724,1220,1245,1400,1848,1850 + rotechos-modules.js:238)
function cfgPersistGlobalLine(name, newLine) {
  _cfgWriteQueue = _cfgWriteQueue
    .then(async () => {
      // Extraer el valor del newLine (numérico O booleano), ignorando el comentario.
      // Sin |true|false los globals booleanos (softLimitsOn, requireHoming) caían al
      // fallback `val = newLine` → cfgSetGlobal escribía la línea entera como valor.
      const valMatch = newLine.match(/=\s*(-?[\d.]+|true|false)/i);
      const val = valMatch ? valMatch[1] : newLine;
      const raw = await cfgMachineRead();
      if (raw == null) return false;
      // Fail-closed: `raw == null` NO basta. Cuando la lectura falla de verdad
      // (HTTP 500, red caída, timeout) _cfgReadPath devuelve cadena VACÍA, no
      // null — y `"" == null` es false en JS. Sin este guard, cfgSetGlobal
      // construía el archivo desde vacío y cfgMachineWrite subía un
      // config-machine.g de UNA línea ENCIMA de la calibración del cliente
      // (pasos/mm, corrientes, área, sonda). El flag ya existía y las dos rutas
      // de rotechos-config-modal.js (220, 1916) sí lo consultaban; esta no.
      // `typeof` por el mismo motivo que en config-modal.js:220: los tests
      // unitarios extraen esta función a un sandbox donde el símbolo no vive.
      if (typeof _cfgMachineLoadOk !== 'undefined' && !_cfgMachineLoadOk) {
        toast(
          t(`msg.configMaquinaNoLeida`, `No se pudo leer config-machine.g — guardado ABORTADO para no machacar tu calibración (pasos/mm, corrientes, área, sonda). NO se ha guardado NADA. Qué hacer: (1) revisa la conexión WiFi con la máquina, (2) abre CONFIGURACIÓN → abrir y verifica que la pestaña MOTORES/VELOCIDADES/SOFT-LIMITS/BACKLASH muestra tus valores reales, (3) reintenta el cambio que querías guardar. Si tu calibración ya no aparece en pantalla, NO toques nada y contacta con soporte.`),
          `err`,
        );
        LOG.warn(`cfgPersistGlobalLine(${name}): lectura invalida — ABORTADO para no borrar la calibracion`);
        return false;
      }
      return await _cfgMachineWriteDirecto(cfgSetGlobal(raw, name, val));
    })
    .catch((e) => (LOG.warn(`cfgPersistGlobalLine(${name}):`, e), false));
  return _cfgWriteQueue;
}

/**
 * Sanitiza el valor de un global de tipo STRING antes de escribirlo en
 * config-machine.g. Quita comillas (romperían el `set global.X = "..."`),
 * saltos de línea y `;` (inyectarían líneas/comentarios en el arranque de RRF,
 * misma clase de bug que cubre _sanitizeCommentValue) y recorta a 24 caracteres
 * (el maxlength del input del wizard, rotechos-modules.js:54).
 */
function _sanitizeStringGlobal(v) {
  return String(v ?? ``).replace(/["\n\r;]/g, ``).trim().slice(0, 24);
}

/**
 * Persiste un global per-máquina de tipo STRING en config-machine.g.
 *
 * Existe como función aparte de cfgPersistGlobalLine PORQUE esa extrae el valor
 * con la regex `=\s*(-?[\d.]+|true|false)` (línea 260), que NO casa un string:
 * caería al fallback `val = newLine` y cfgSetGlobal escribiría la línea ENTERA
 * como valor (`set global.machineName = set global.machineName = "X"`). Aquí el
 * valor se pasa ya sanitizado y entrecomillado, sin pasar por esa extracción.
 *
 * Mantiene el MISMO fail-closed que cfgPersistGlobalLine: si la lectura de
 * config-machine.g falló de verdad (_cfgMachineLoadOk === false), aborta en vez
 * de escribir un archivo de una línea encima de la calibración del cliente.
 */
// eslint-disable-next-line no-unused-vars -- usado por cfgPersistStringGlobal fuera de este módulo (rotechos-modules.js:172 via window)
function cfgPersistStringGlobal(name, value) {
  const safe = _sanitizeStringGlobal(value);
  _cfgWriteQueue = _cfgWriteQueue
    .then(async () => {
      const raw = await cfgMachineRead();
      if (raw == null) return false;
      if (typeof _cfgMachineLoadOk !== 'undefined' && !_cfgMachineLoadOk) {
        toast(
          t(`msg.configMaquinaNoLeida`, `No se pudo leer config-machine.g — guardado ABORTADO para no machacar tu calibración (pasos/mm, corrientes, área, sonda). NO se ha guardado NADA. Qué hacer: (1) revisa la conexión WiFi con la máquina, (2) abre CONFIGURACIÓN → abrir y verifica que la pestaña MOTORES/VELOCIDADES/SOFT-LIMITS/BACKLASH muestra tus valores reales, (3) reintenta el cambio que querías guardar. Si tu calibración ya no aparece en pantalla, NO toques nada y contacta con soporte.`),
          `err`,
        );
        LOG.warn(`cfgPersistStringGlobal(${name}): lectura invalida — ABORTADO para no borrar la calibracion`);
        return false;
      }
      // Comillas explícitas: el valor puede llevar espacios ("Taller CNC") y sin
      // ellas el `set global.X = Taller CNC` no es parseable al releerlo.
      return await _cfgMachineWriteDirecto(cfgSetGlobal(raw, name, `"${safe}"`));
    })
    .catch((e) => (LOG.warn(`cfgPersistStringGlobal(${name}):`, e), false));
  return _cfgWriteQueue;
}

/**
 * Lee un global per-máquina de tipo STRING desde el contenido de
 * config-machine.g (función PURA: no toca la red, recibe el texto ya leído).
 * Devuelve `''` si el global no está presente — el caller decide el fallback.
 */
// eslint-disable-next-line no-unused-vars -- usado por cfgGetStringGlobal fuera de este módulo (rotechos-config-modal.js + rotechos-backup.js via window)
function cfgGetStringGlobal(content, gName) {
  const m = String(content ?? ``).match(
    RegExp(`^set global\\.${gName}\\s*=\\s*"([^"]*)"`, `m`),
  );
  return m ? m[1] : ``;
}

/**
 * Sanitiza el valor de un PIN HTTP (M551 P"…") antes de escribirlo en
 * config-machine.g. Más estricto que _sanitizeCommentValue / _sanitizeStringGlobal:
 *
 *   - `"` rompería el `P"…"` del M-code (casing literal: P usa comillas).
 *   - `;` se interpretaría como comentario RRF (anularía el resto de la línea).
 *   - `\n` y `\r` inyectarían líneas/comandos en el arranque de RRF.
 *   - ESPACIOS y `\t` permitirían anclar regex o bypass de maxlength por copy-paste.
 *
 * Permitido: letras, dígitos y los símbolos `-_.@#!?,:`. Recortado a 24 chars
 * (alineado con el `maxlength=24` del input del wizard/configuración).
 * Null/undefined → `''`. Vacío (`''`) tras sanitizar indica "PIN rechazado".
 */
function _sanitizePin(v) {
  return String(v ?? ``)
    .replace(/["\n\r;\s\t]/g, ``)
    .replace(/[^A-Za-z0-9\-_.@#!?,:]/g, ``)
    .slice(0, 24);
}

/**
 * Lee el PIN HTTP de un contenido ya leído de config-machine.g (función PURA:
 * no toca la red). Devuelve `''` si no hay línea M551 o si el valor está vacío.
 *
 * Acepta sintaxis M551 P"…"  (con o sin espacios alrededor). El operador M551
 * estándar de RRF acepta también `M551 Pfoo` (sin comillas), pero la
 * persistencia siempre lo escribe con comillas; la regex cubre ambas formas.
 */
// eslint-disable-next-line no-unused-vars -- usado por cfgGetPin fuera de este módulo (rotechos.js + rotechos-config-modal.js via window)
function cfgGetPin(content) {
  const m = String(content ?? ``).match(/^M551\s+P"([^"]*)"/m);
  return m ? m[1] : ``;
}

/**
 * Borra TODAS las líneas M551 (incluyendo su \n final) del contenido. Si no
 * existe ninguna, devuelve `content` sin tocar. Función PURA.
 *
 * Usada por la ruta de "quitar PIN" desde la UI. El helper impuro que
 * orquesta releer + borrar + escribir (`cfgRemovePin(...)`) se delega al
 * caller (rotechos-config-modal.js) para mantener simetría con
 * `cfgPersistPin` — este módulo expone la primitiva pura.
 *
 * Por qué GLOBAL (borrar TODAS las líneas M551), no solo la primera:
 *   - Asimetría con `cfgPersistPin`: este ya aborta si el archivo tiene MÁS de
 *     una línea M551 (rotechos-config-persist.js, cfgPersistPin, filtro de
 *     duplicados). El path de "definir PIN" era defensivo; el de "quitar PIN"
 *     no lo era.
 *   - Si config-machine.g tiene dos líneas M551 (edición manual de la SD o
 *     estado ya corrupto), el usuario quita el PIN, la UI confirmaba éxito,
 *     y la máquina arrancaba TODAVÍA BLOQUEADA con el segundo PIN — el
 *     usuario quedaba fuera de su propia fresadora sin saberlo.
 *   - Preferimos borrar de más (expresión global `g`) a fallar cerrado:
 *     dejar un PIN activo cuando el usuario ha pedido quitarlo es peor que
 *     borrar de más, porque el fallo es silencioso y deja la máquina
 *     inaccesible para una sesión que se creía abierta. Si la SD trae
 *     duplicados, lo correcto es dejar 0 líneas y que la siguiente sesión
 *     arranque sin PIN.
 *
 * Consecuencia: la ruta de UI (rotechos-config-modal.js, `_removePin`) debe
 * verificar post-escritura que `cfgMachineRead()` ya no contiene ninguna
 * línea `^M551\b` antes de mostrar el toast de éxito `msg.pinRemoved`.
 */
// eslint-disable-next-line no-unused-vars -- usado por cfgRemovePin fuera de este módulo (rotechos-config-modal.js via window)
function cfgRemovePin(content) {
  const s = String(content ?? ``);
  // Captura TODAS las líneas que empiezan por M551 con su \n final, ancla
  // de inicio de línea (multilinea). El flag `g` es la diferencia clave
  // respecto a la versión anterior: una regex sin `g` reemplaza solo la
  // PRIMERA coincidencia y deja las demás, dejándolas activas en la SD.
  const re = /^M551\b[^\n]*\n?/gm;
  return re.test(s) ? s.replace(re, ``) : s;
}

/**
 * Persiste el PIN HTTP en config-machine.g como `M551 P"…"` (runtime +
 * persistencia). Patrón gemelo de `cfgPersistComment`/`cfgPersistGlobalLine`:
 *
 *   1. Cola serializada (`_cfgWriteQueue`) — evita TOCTOU entre toggles rápidos.
 *   2. Releer `config-machine.g` FRESCO de la SD (no usar el cache `_cfgMachineRaw`).
 *   3. Fail-closed: si la lectura fue inválida (`_cfgMachineLoadOk === false`),
 *      ABORTAR (no se quiere subir un archivo de una línea encima de la
 *      calibración del cliente — mismo bug que cerró `cfgPersistGlobalLine`).
 *   4. Filtro de duplicados: si el archivo tiene MÁS de una línea `^M551\b`,
 *      abortar con `msg.pinDuplicado`. La persistencia siempre lo deja en una
 *      sola línea, así que >1 indica edición manual corrupta — preferimos
 *      avisar a seguir escribiendo y crear duplicados en runtime.
 *   5. Sanitizar el PIN con `_sanitizePin` (estricto: nada de `"`, `\n`, `;`,
 *      espacios, etc.).
 *   6. Reemplazar (o añadir al final) con `cfgReplaceLine(raw, "M551", …)`.
 *   7. `cfgMachineWrite` con read-back (defensa contra upload silencioso).
 *   8. Devuelve la promesa de la operación (los callers pueden await).
 *
 * NO toca `config.g` (es un M-code, no un global), respeta la OTA: el helper
 * de OTA (`rotechos-ota-zip.js`/`rotechos-ota.js`) fusiona `config.g` pero
 * conserva `config-machine.g` (la calibración + globals per-máquina viven
 * ahí — `sys/config.g:78`).
 */
// eslint-disable-next-line no-unused-vars -- usado por cfgPersistPin fuera de este módulo (rotechos.js + rotechos-config-modal.js via window)
function cfgPersistPin(pin) {
  // S-N3 (informe 2026-08-18 v3): el bloqueo por 5 intentos/30s del escudo
  // SÍ se respeta en `tryConnect` (rotechos-auth.js:409). Pero esta ruta
  // NO pasa por `tryConnect`: el operario puede ir a CONFIGURACIÓN → PIN,
  // escribir un PIN nuevo y pulsar "Definir / cambiar PIN" infinitas veces
  // durante el bloqueo, saltándose la defensa contra typos. Cerramos esa
  // grieta aquí, antes de tocar nada. Reutilizamos la misma clave i18n
  // `msg.pinLockoutWarn` que `_notifyLockout` para que el aviso sea
  // coherente (mismo texto, mismo idioma). Defensivo: si rotechos-auth aún
  // no cargó, o no expone `isLockedOut`, NO bloqueamos (fail-open en este
  // helper de UI; el escudo principal sigue protegiendo lo crítico).
  if (typeof window !== `undefined` && window.rotechosAuth &&
      typeof window.rotechosAuth.isLockedOut === `function` &&
      window.rotechosAuth.isLockedOut()) {
    const remainingMs = (() => {
      try {
        const ts = Number(window.localStorage.getItem(`rotechos.authLockoutUntil`) || 0);
        return ts > Date.now() ? ts - Date.now() : 0;
      } catch (_) { return 0; }
    })();
    const secs = Math.max(1, Math.ceil(remainingMs / 1000));
    toast(t(`msg.pinLockoutWarn`, `Demasiados intentos, espera {secs}s antes de reintentar.`).replace(`{secs}`, String(secs)), `warn`);
    LOG.warn(`cfgPersistPin: abortado por lockout activo (~${secs}s restantes)`);
    return Promise.resolve(false);
  }
  const safe = _sanitizePin(pin);
  if (!safe) {
    toast(t(`msg.pinEmpty`, `El PIN está vacío o solo contiene caracteres no permitidos`), `err`);
    LOG.warn(`cfgPersistPin: PIN vacío tras sanitizar — ABORTADO`);
    return Promise.resolve(false);
  }
  const newLine = `M551 P"${safe}"`;
  _cfgWriteQueue = _cfgWriteQueue
    .then(async () => {
      const raw = await cfgMachineRead();
      if (raw == null) return false;
      // Fail-closed igual que el resto de la familia (cfgPersistGlobalLine,
      // cfgPersistStringGlobal, cfgPersistComment). El flag distingue
      // "máquina virgen" (read 404, válido) de "lectura fallida de verdad"
      // (HTTP 500, red caída) — en el segundo abortamos para NO pisar la
      // calibración del cliente con un archivo de una línea.
      if (typeof _cfgMachineLoadOk !== `undefined` && !_cfgMachineLoadOk) {
        toast(
          t(`msg.configMaquinaNoLeida`, `No se pudo leer config-machine.g — guardado ABORTADO para no machacar tu calibración (pasos/mm, corrientes, área, sonda). NO se ha guardado NADA. Qué hacer: (1) revisa la conexión WiFi con la máquina, (2) abre CONFIGURACIÓN → abrir y verifica que la pestaña MOTORES/VELOCIDADES/SOFT-LIMITS/BACKLASH muestra tus valores reales, (3) reintenta el cambio que querías guardar. Si tu calibración ya no aparece en pantalla, NO toques nada y contacta con soporte.`),
          `err`,
        );
        LOG.warn(`cfgPersistPin: lectura inválida — ABORTADO para no borrar la calibración`);
        return false;
      }
      // Filtro de duplicados: si la SD trae más de una línea `M551 …`,
      // la persistencia quedaría mal y la OTA posterior borraría la última.
      // Preferimos avisar al operario (o al soporte) antes que enmascarar el
      // problema creando OTRA línea.
      const lines = raw.split('\n').filter((l) => /^M551\b/.test(l));
      if (lines.length > 1) {
        toast(
          t(`msg.pinDuplicado`, `Hay varias líneas M551 en config-machine.g. Edita la SD y deja solo una antes de continuar.`),
          `err`,
        );
        LOG.warn(`cfgPersistPin: ${lines.length} líneas ^M551 detectadas — ABORTADO`);
        return false;
      }
      // Aplicar en caliente en RRF (defensa en profundidad: si la persistencia
      // falla, el PIN queda al menos activo para esta sesión). Falla silenciosa:
      // no es un error duro; la persistencia (read-back) ya cubre el resultado.
      try { await RRF.gcode(newLine); } catch (_) {}
      const ok = await _cfgMachineWriteDirecto(cfgReplaceLine(raw, `M551`, newLine));
      // Cachear el PIN en localStorage para que el siguiente rr_connect
      // (rotechos-auth.tryConnect) lo encuentre sin tener que re-leer
      // config-machine.g. Si rotechos-auth aún no está cargado (orden de
      // carga futura), la función es defensiva y no lanza.
      if (ok && typeof window !== `undefined` && window.rotechosAuth &&
          typeof window.rotechosAuth.setStoredPin === `function`) {
        try { window.rotechosAuth.setStoredPin(safe); } catch (_) {}
      }
      return ok;
    })
    .catch((e) => (LOG.warn(`cfgPersistPin:`, e), false));
  return _cfgWriteQueue;
}

/**
 * Lista per-máquina de drivers vetados (Pn donde n=0..3 en BTT Scylla V1.0).
 *
 * ORIGEN DEL DISEÑO (2026-08-12, Sergi):
 *   Las boards BTT Scylla V1.0 traen 4 drivers TMC2160 (P0–P3) y todos funcionan
 *   en una placa sana. Bloquear P0 "porque la Scylla tiene un defecto" es una
 *   afirmación FALSA sobre hardware ajeno — no puede viajar en un producto que
 *   se distribuye. El motivo por el que esta unidad concreta tiene P0 quemado
 *   es de Sergi, no del fabricante.
 *
 * POR QUÉ PER-MÁQUINA Y NO GLOBAL:
 *   La OTA reescribe `config.g` entero pero respeta `config-machine.g` (la
 *   calibración propia de cada fresadora; ver CLAUDE.md §2). Un cliente con
 *   una placa distinta del MISMO modelo no debe heredar el veto. Sembrar la
 *   lista vacía por defecto es lo correcto: una instalación nueva NO veta
 *   ningún driver.
 *
 * FORMATO EN SD:
 *   `; rotech-banned-drivers=P0:driver-quemado-en-esta-unidad,P1:otra-razon`
 *   - Una entrada por driver vetado: identificador "P<n>" (n = 0..3, TMC2160)
 *     seguido opcionalmente de ":" y un motivo libre (texto sin ";" ni "\n",
 *     saneado por _sanitizeCommentValue al persistir).
 *   - Ausencia de la línea = lista VACÍA (ningún driver vetado).
 *   - La línea puede llevar espacios alrededor de los "," para legibilidad.
 *
 * POR QUÉ SE LEE COMO SET Y NO COMO STRING:
 *   El consumidor (M569.customSave, M584.customSave) solo necesita saber "este
 *   driver P está vetado SÍ/NO" — `Set<number>` lo modela con semántica clara
 *   y lookup O(1). Si el motivo hace falta para el toast, `parseBannedDrivers`
 *   lo expone en un objeto paralelo: `{ drivers: Set, reasons: Map<number,str> }`.
 *
 * Tests: tests/unit/cfg-banned-drivers.test.js
 */
// eslint-disable-next-line no-unused-vars -- usado por isDriverBanned y parseBannedDrivers fuera de este módulo (rotechos-config-modal.js)
function parseBannedDrivers(content) {
  const drivers = new Set();
  const reasons = new Map();
  if (typeof content !== `string` || !content) return { drivers, reasons };
  // Regex anclada a línea para no capturar un ; rotech-banned-drivers=... dentro
  // de un comentario inline. Coincide con el formato producido por cfgPersistBannedDrivers.
  const re = /^\s*;\s*rotech-banned-drivers\s*=\s*(.+?)\s*$/m;
  const m = content.match(re);
  if (!m) return { drivers, reasons };
  for (const entryRaw of m[1].split(`,`)) {
    const entry = entryRaw.trim();
    if (!entry) continue;
    // Acepta "P0", "P3" mayúscula (formato canónico) y "p0" minúscula (tolerante).
    // Cualquier otro identificador se ignora silenciosamente — si en el futuro el
    // SD lleva otra nomenclatura, parsear es punto de extensión.
    const driverMatch = entry.match(/^P([0-3])\s*(?::\s*(.+))?$/i);
    if (!driverMatch) continue;
    const n = Number(driverMatch[1]);
    drivers.add(n);
    if (driverMatch[2]) reasons.set(n, driverMatch[2].trim());
  }
  return { drivers, reasons };
}

// eslint-disable-next-line no-unused-vars -- usado por isDriverBanned fuera de este módulo (rotechos-config-modal.js)
function isDriverBanned(content, n) {
  return parseBannedDrivers(content).drivers.has(Number(n));
}

/**
 * Persiste la lista de drivers vetados en config-machine.g.
 *
 * Recibe un array de objetos `{ n, reason? }` o un Map<number, string|undefined>;
 * reescribe la línea completa `; rotech-banned-drivers=...` (idempotente con
 * cfgReplaceLine; si no existe, la añade al final). Comparte el patrón
 * gemelo de cfgPersistComment/cfgPersistGlobalLine: serialización por cola,
 * fail-closed ante lectura inválida, saneado defensivo del motivo.
 *
 * Devuelve una promesa — el caller puede await si necesita confirmación.
 */
// eslint-disable-next-line no-unused-vars -- exportado para uso futuro (panel UI en CONFIGURACIÓN)
function cfgPersistBannedDrivers(entries) {
  const norm = (entries instanceof Map)
    ? Array.from(entries, ([n, reason]) => ({ n, reason }))
    : (Array.isArray(entries) ? entries : []);
  const safe = norm
    .filter((e) => e && Number.isInteger(e.n) && e.n >= 0 && e.n <= 3)
    .map((e) => {
      const base = `P${e.n}`;
      const reason = e.reason ? _sanitizeCommentValue(e.reason).trim() : ``;
      return reason ? `${base}:${reason}` : base;
    })
    .join(`,`);
  return cfgPersistComment(`rotech-banned-drivers`, safe);
}

/**
 * t_8ebcb0bc — ¿Está esta máquina calibrada? Recibe el contenido en RAM de
 * `config-machine.g`. Devuelve `true` si M92/M906/M208 son NO triviales
 * (NO coinciden con los fallbacks de `config.g`), `false` si la máquina
 * usa los defaults genéricos. Función PURA: el test unitario la extrae
 * con `vm.runInContext` y la cubre sin red ni SD.
 */
// eslint-disable-next-line no-unused-vars -- usado por rotechos-config-modal.js
function isMachineCalibrated(machineRaw) {
  if (typeof machineRaw !== 'string') return false;
  const txt = machineRaw;
  if (!txt.trim()) return false;
  // Fallbacks que config.g acaba de declarar: si la calibración real coincide
  // con TODOS estos sigue siendo trivial; si AL MENOS un eje difiere, calibrada.
  const M92_FACTORY = { X: 80, Y: 80, Z: 400 };
  const M906_FACTORY = { X: 800, Y: 800, Z: 800 };
  const M208_XMAX_FACTORY = 100;
  const M208_YMAX_FACTORY = 100;
  const M208_ZMIN_FACTORY = -25;
  const m92 = txt.match(/^\s*M92\s+([^\n]*)/m);
  if (m92) {
    const p = m92[1];
    const x = p.match(/X([\d.]+)/)?.[1];
    const y = p.match(/Y([\d.]+)/)?.[1];
    const z = p.match(/Z([\d.]+)/)?.[1];
    if ((x !== undefined && parseFloat(x) !== M92_FACTORY.X) ||
        (y !== undefined && parseFloat(y) !== M92_FACTORY.Y) ||
        (z !== undefined && parseFloat(z) !== M92_FACTORY.Z)) return true;
  }
  const m906 = txt.match(/^\s*M906\s+([^\n]*)/m);
  if (m906) {
    const p = m906[1];
    const x = p.match(/X([\d.]+)/)?.[1];
    const y = p.match(/Y([\d.]+)/)?.[1];
    const z = p.match(/Z([\d.]+)/)?.[1];
    if ((x !== undefined && parseFloat(x) !== M906_FACTORY.X) ||
        (y !== undefined && parseFloat(y) !== M906_FACTORY.Y) ||
        (z !== undefined && parseFloat(z) !== M906_FACTORY.Z)) return true;
  }
  const m208Max = txt.match(/^\s*M208\s+([^\n]*)\s+S0\s*$/m);
  if (m208Max) {
    const p = m208Max[1];
    const x = parseFloat(p.match(/X(-?[\d.]+)/)?.[1] ?? '');
    const y = parseFloat(p.match(/Y(-?[\d.]+)/)?.[1] ?? '');
    if (x !== M208_XMAX_FACTORY || y !== M208_YMAX_FACTORY) return true;
  }
  const m208Min = txt.match(/^\s*M208\s+([^\n]*)\s+S1\s*$/m);
  if (m208Min) {
    const p = m208Min[1];
    const z = parseFloat(p.match(/Z(-?[\d.]+)/)?.[1] ?? '');
    if (z !== M208_ZMIN_FACTORY) return true;
  }
  return false;  // Sin M92/M906/M208 detectables → todavía no calibrada.
}

/**
 * Sane (T) — normaliza el nombre de una herramienta antes de escribirlo
 * en `M563 P<n> S"<name>"`. Mismas reglas que `_sanitizeStringGlobal` pero
 * un pelín más estrictas: las comillas rompen el parseo del M-code
 * (casing literal: S usa comillas), `;` se interpretaría como comentario,
 * `\n`/`\r` inyectarían líneas/comandos en el arranque de RRF.
 *
 * Reglas:
 *  - Vacío / solo whitespace → '' (el caller debe rechazar el nombre).
 *  - Quita `"` (rompería `S"..."`), `;` (comentario), `\n`/`\r` (líneas).
 *  - NO escapa `\"` (RRF 3.5.4 no acepta `\"` dentro de S"<...>"; decidimos
 *    rechazar en seco y mostrar toast, no escribir caracteres rotos).
 *  - Trim + recorta a 24 caracteres (alineado con el resto del proyecto).
 *
 * Pura: recibe un string y devuelve string.
 */
function _sanitizeToolsName(name) {
  const s = String(name ?? ``);
  // Cualquier carácter peligroso → vacío (rechazo duro). Más legible
  // para el operario que un truncado silencioso que dejase el nombre
  // medio vacío.
  if (/[";\n\r]/.test(s)) return ``;
  const trimmed = s.trim();
  if (!trimmed) return ``;
  return trimmed.slice(0, 24);
}

/**
 * Lee la tabla M563 del contenido (ya en RAM) de `config-machine.g` y
 * devuelve un array de herramientas. Función PURA: no toca la red.
 *
 * REGLAS DE NEGOCIO (t_33991c62):
 *  - Si NO hay línea `M563 P0` en el archivo, la tool 0 ("Spindle", R0)
 *    se INYECTA automáticamente al inicio del array. La razón es que
 *    toda la base de código asume que existe (T0+M5 al parar el husillo,
 *    T0 al cargar G-code, etc.). Un config-machine.g virgen sin tool 0
 *    dejaría la máquina sin herramienta activa — bug de seguridad.
 *  - Duplicados del mismo `P<n>` → solo se conserva la PRIMERA ocurrencia
 *    (el resto se ignora silenciosamente; una OTA posterior conservaría
 *    solo la primera de cualquier modo).
 *  - Campos opcionales ausentes (Z, D, F) → `null` en el objeto.
 *  - Comentario trailing tras los flags → tolerado y descartado.
 *
 * Devuelve array de objetos `{p, name, R, Z, D, F, mat}` donde `mat`
 * siempre es `null` en esta primera iteración (la UI puede mostrar
 * material, pero M563 estándar RRF no lo soporta — ver t_33991c62 brief).
 *
 * Tests: tests/unit/cfg-tools-table.test.js
 */
// eslint-disable-next-line no-unused-vars -- usado por rotechos-config-modal.js via window
function cfgGetToolsTable(content) {
  const txt = String(content ?? ``);
  const re = /^M563\s+P(\d+)\s+S"([^"]*)"\s+R([01])(?:\s+Z(-?[\d.]+))?(?:\s+D([\d.]+))?(?:\s+F(\d+))?(?:\s+;.*)?\s*$/gm;
  const tools = [];
  const seen = new Set();
  let m;
  while ((m = re.exec(txt)) !== null) {
    const p = Number(m[1]);
    if (seen.has(p)) continue;   // dedup — solo la primera
    seen.add(p);
    tools.push({
      p,
      name: m[2],
      R: Number(m[3]),
      Z: m[4] ?? null,
      D: m[5] ?? null,
      F: m[6] ?? null,
      mat: null,
    });
  }
  // Defensa dura: tool 0 SIEMPRE presente. Si el archivo la perdió, la
  // reinsertamos al inicio con sus valores canónicos.
  if (!seen.has(0)) {
    tools.unshift({ p: 0, name: 'Spindle', R: 0, Z: '0', D: null, F: null, mat: null });
  }
  return tools;
}

/**
 * Genera el bloque M563 al final de `config-machine.g` con la tabla dada.
 * Borra TODAS las líneas `M563` previas (independientemente del fichero)
 * y las sustituye por la lista que recibe. Inyecta tool 0 ("Spindle", R0)
 * si el array no la trae — es INMORTAL.
 *
 * Formato por entrada:
 *   M563 P<n> S"<name>" R<r> [Z<offset>] [D<diam>] [F<flutes>]
 * Los campos null/`""` se omiten (no escribimos "Z" sin valor).
 *
 * El bloque se inserta al final del contenido, separado por una cabecera
 * legible para el operario (`; --- HERRAMIENTAS (M563) ---`). Líneas de
 * comentario `; rotech-*` y los M-codes existentes NO se tocan: solo
 * se reemplazan las líneas que empiecen por `M563\b`.
 *
 * Función PURA: no toca la red ni la SD. El caller debe persistir el
 * resultado vía `cfgMachineWrite`.
 *
 * Tests: tests/unit/cfg-tools-table.test.js
 */
// eslint-disable-next-line no-unused-vars -- usado por rotechos-config-modal.js via window
function cfgSetToolsTable(content, tools) {
  const txt = String(content ?? ``);
  const arr = Array.isArray(tools) ? tools.slice() : [];
  // Defensa dura: tool 0 SIEMPRE presente. Si nadie la trae, la inyectamos.
  if (!arr.some((t) => t && Number(t.p) === 0)) {
    arr.unshift({ p: 0, name: 'Spindle', R: 0, Z: 0, D: null, F: null, mat: null });
  }
  // Borrar TODAS las líneas M563 previas (con su \n final). El flag `g`
  // es importante — `cfgReplaceLine` solo reemplaza la primera.
  const cleaned = txt.replace(/^M563\b[^\n]*\n?/gm, ``);
  // Generar el bloque.
  const lines = [`; --- HERRAMIENTAS (M563) — generado por RotechOS UI (t_33991c62) ---`];
  for (const t of arr) {
    if (!t || !Number.isInteger(Number(t.p))) continue;
    const p = Number(t.p);
    const name = _sanitizeToolsName(t.name ?? '') || (p === 0 ? 'Spindle' : `Tool ${p}`);
    let line = `M563 P${p} S"${name}" R${t.R ? 1 : 0}`;
    if (t.Z !== null && t.Z !== `` && t.Z !== undefined) line += ` Z${t.Z}`;
    if (t.D !== null && t.D !== `` && t.D !== undefined) line += ` D${t.D}`;
    if (t.F !== null && t.F !== `` && t.F !== undefined) line += ` F${t.F}`;
    if (p === 0) line += `   ; tool 0 con husillo — protegida`;
    lines.push(line);
  }
  const block = lines.join(`\n`) + `\n`;
  // Insertar al final. Si el archivo NO termina en \n, añadimos uno para
  // que el bloque empiece en línea limpia.
  return cleaned.replace(/(\n)?$/, ``) + (cleaned.endsWith(`\n`) || cleaned === `` ? `` : `\n`) + block;
}
