/* ---
 * rotechos-wcs.js — Defer module: ceros de pieza (WCS G54) en los botones X/Y/Z/ALL.
 *
 * Sprint WCSG del programa de reducción del monolito. Saca de rotechos.js el
 * bloque que:
 *   - define la tabla WCSG con los comandos G10 L20 P0 X0/Y0/Z0 y la versión ALL,
 *   - define WCSM con los mensajes i18n y fallback para los 4 botones,
 *   - engancha un click handler por cada `.wcs-btn` (4 botones en el DRO) que:
 *       1) bloquea si la máquina está RUNNING/PAUSED (avisa con toast y aborta),
 *       2) para `ALL` exige confirmDialog — un toque accidental redefine el
 *          origen de los TRES ejes y arruina la pieza,
 *       3) envía el G-code, refresca el DRO en cliente (escritura optimista
 *          de wX/wY/wZ/zReadout, ajustando SM._prevXYZ y SM.zPos),
 *       4) re-pinta la posición de herramienta en el visor (VIZ.setToolPos)
 *          y dispara un poll inmediato para confirmar el offset del firmware.
 *
 * Dependencias globales (inyectables en tests; viven en el shell):
 *   - $, $$              — alias de querySelector / querySelectorAll (rotechos.js)
 *   - SM, STATES         — máquina de estados (rotechos.js: máquina de estados)
 *   - RRF                — cliente RRF con .gcode() async (rotechos.js)
 *   - setText            — helper DOM (rotechos-dom.js)
 *   - t, toast, log      — i18n / notificación / consola (rotechos-i18n.js, etc.)
 *   - confirmDialog      — modal sí/no (rotechos.js)
 *   - VIZ                — módulo del visor 3D, sólo si existe (typeof guard)
 *   - _pollRun           — función del ciclo de poll (rotechos-poll.js); sólo
 *                          si existe, el typeof guard la llama para refrescar.
 *
 * Contrato: este módulo se carga con defer, DESPUÉS de rotechos.js y DESPUÉS
 * de rotechos-poll.js. Los handlers se enlazan cuando el script corre, así
 * que si los botones no están aún en el DOM, `$$('.wcs-btn')` da 0 y el
 * handler no se engancha (mismo comportamiento que el bloque original).
 * --- */
'use strict';

const WCSG = {
  X:   `G10 L20 P0 X0`,
  Y:   `G10 L20 P0 Y0`,
  Z:   `G10 L20 P0 Z0`,
  ALL: `G10 L20 P0 X0 Y0 Z0`,
};

const WCSM = {
  X:   { key: `msg.zeroX`,   fallback: `Cero X establecido` },
  Y:   { key: `msg.zeroY`,   fallback: `Cero Y establecido` },
  Z:   { key: `msg.zeroZ`,   fallback: `Cero Z establecido` },
  ALL: { key: `msg.zeroAll`, fallback: `Cero XYZ establecido` },
};

$$(`.wcs-btn`).forEach((b) => {
  b.addEventListener(`click`, async () => {
    if (SM.current === STATES.RUNNING || SM.current === STATES.PAUSED) {
      toast(t(`msg.noWcsDuring`, `No se puede cambiar el WCS durante un trabajo`), `warn`);
      return;
    }
    const axis = b.dataset.axis;
    // UX-3: confirmar el Zero de los TRES ejes a la vez — un toque accidental
    // (sobre todo en móvil, junto a los botones de jog) redefine el origen de
    // pieza y el trabajo empezaría en el sitio equivocado, arruinando la pieza.
    // K-COB-01 cubrió macros y otros destructive; H-1 (v1) cubrió XYZ 0 aquí.
    // Pendiente: cada botón individual X/Y/Z también redefine origen — Z puede
    // echar a perder la pieza con 0.5 mm de error. Mismo patrón que ALL.
    if (axis === `ALL`) {
      if (
        !(await confirmDialog(
          t(`dlg.wcsZeroAll.title`, `Fijar origen XYZ`),
          t(`dlg.wcsZeroAll.msg`, `¿Fijar la posición actual como origen de pieza (0,0,0) en los TRES ejes?<br><b>Esto es destructivo</b>: el siguiente corte empezará en la posición actual, NO en la esquina del material. Si dudas, cancela y revisa primero con SONDA Z para Z y palpador fijo para X/Y. ¿Continuar?`),
        ))
      ) return;
    } else if (axis === `X` || axis === `Y` || axis === `Z`) {
      const WCS_AXIS_MSG = {
        X: { title: `dlg.wcsZeroX.title`, msg: `dlg.wcsZeroX.msg`,
             dTitle: `Fijar origen X`, dMsg: `¿Fijar la posición actual como origen de pieza en <b>X</b>?<br>El siguiente corte en X empezará aquí, NO en el borde del material. Si dudas, cancela y usa el palpador fijo para X. ¿Continuar?` },
        Y: { title: `dlg.wcsZeroY.title`, msg: `dlg.wcsZeroY.msg`,
             dTitle: `Fijar origen Y`, dMsg: `¿Fijar la posición actual como origen de pieza en <b>Y</b>?<br>El siguiente corte en Y empezará aquí, NO en el borde del material. Si dudas, cancela y usa el palpador fijo para Y. ¿Continuar?` },
        Z: { title: `dlg.wcsZeroZ.title`, msg: `dlg.wcsZeroZ.msg`,
             dTitle: `Fijar origen Z`, dMsg: `¿Fijar la posición actual como origen de pieza en <b>Z</b>?<br><b>Esto es destructivo en Z</b>: medio milímetro de error y la fresa pasa por encima o por debajo de la pieza. Si dudas, cancela y lanza SONDA Z. ¿Continuar?` },
      };
      const m = WCS_AXIS_MSG[axis];
      if (
        !(await confirmDialog(
          t(m.title, m.dTitle),
          t(m.msg, m.dMsg),
        ))
      ) return;
    }
    const r = await RRF.gcode(WCSG[axis]);
    if (r) {
      log(WCSG[axis] + " — " + t(WCSM[axis].key, WCSM[axis].fallback), `cmd`);
      toast(t(WCSM[axis].key, WCSM[axis].fallback), `ok`);
      let px = SM._prevXYZ ?? [0, 0, 0];
      if (axis === `X` || axis === `ALL`) {
        setText(`wX`, `  0.000`);
        px = [0, px[1], px[2]];
      }
      if (axis === `Y` || axis === `ALL`) {
        setText(`wY`, `  0.000`);
        px = [px[0], 0, px[2]];
      }
      if (axis === `Z` || axis === `ALL`) {
        setText(`wZ`, `  0.000`);
        setText(`zReadout`, `0.000`);
        SM.zPos = 0;
        px = [px[0], px[1], 0];
      }
      SM._prevXYZ = px;
      if (typeof VIZ !== `undefined` && VIZ && typeof VIZ.setToolPos === `function`) {
        VIZ.setToolPos(px[0], px[1]);
      }
      // Nueva generación: un ciclo en vuelo con el WCS anterior se descarta.
      if (typeof AppState !== `undefined` && AppState.poll && typeof AppState.poll.bumpGen === `function`) {
        AppState.poll.bumpGen();
      }
      if (typeof _pollRun === `function`) _pollRun();
    } else {
      toast(t(`msg.wcsErrSet`, `Error al establecer offset`), `err`);
    }
  });
});

// Fachada + centinela. Expone los mapas para que el shell (rotechos.js) y
// otros módulos (p.ej. rotechos-pendant.js) puedan consultar la tabla G10
// y los mensajes i18n sin duplicar el literal. Mantenerla SIEMPRE al final.
// La const NO se lee aquí a propósito: es el binding léxico de la fachada. El
// consumo real es window.WCS desde el shell y desde el pendant.
// eslint-disable-next-line no-unused-vars -- binding centinela, ver comentario de arriba
const WCS = window.WCS = { G: WCSG, M: WCSM };