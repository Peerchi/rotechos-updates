// rotechos-ota-install.js — instalar una versión de RotechOS desde la interfaz.
//
// Dos entradas, las dos con un toque humano y una confirmación:
//   - «Instalar ahora» en el aviso de versión nueva: descarga el paquete que
//     publica scripts/publicar_actualizacion.sh en Peerchi/rotechos-updates
//     (raw.githubusercontent.com, que sí permite leerlo desde el navegador; el
//     adjunto de la release no) y comprueba su SHA-256 contra el manifest.
//   - «Instalar desde un ZIP»: el mismo ZIP de la release, elegido en el
//     dispositivo. Vale sin internet, p. ej. conectado a la red RotechOS.
//
// Qué hace con el ZIP: comprueba el CRC de cada fichero, y sube a la SD lo que
// hay en ROTECHOS/sys, macros, licenses y www, en ese orden y con index.html al
// final. No toca nunca los ficheros de ESTA máquina: config.g (mapeo de
// motores), config-machine.g (calibración), config-override.g, user-daemon.g ni
// wifi-passwords.g. Tampoco firmware/: el módulo WiFi ya está grabado.
// Al terminar ofrece reiniciar la placa (M999); el vigilante de M999 recarga
// la página cuando vuelve.
//
// Carga perezosa desde rotechos-ota.js. Depende de rotechos.js (TARGET_IP,
// RRF, SM, STATES, STORE, CFG, toast, log, LOG, confirmDialog) y de t().

(function () {
  "use strict";

  const PAQUETE_URL_OK =
    /^https:\/\/raw\.githubusercontent\.com\/Peerchi\/rotechos-updates\//;
  const DESCARGA_TIMEOUT_MS = 120000;
  const SUBIDA_TIMEOUT_MS = 60000;

  // Ficheros propios de cada máquina: la instalación no los sustituye nunca.
  const DE_LA_MAQUINA =
    /^(config|config-machine|config-override|user-daemon|wifi-passwords)\.g$/i;
  const CARPETAS = { sys: 0, macros: 1, licenses: 2, www: 3 };

  let _ocupado = false;

  // ── ZIP ────────────────────────────────────────────────────────────────
  // Lee el directorio central (no adivina por firmas sueltas, que pueden
  // aparecer dentro de un fichero comprimido).
  function leerZip(u8) {
    const dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength);
    let eocd = -1;
    for (let i = u8.length - 22; i >= 0 && i >= u8.length - 22 - 65535; i--) {
      if (dv.getUint32(i, true) === 0x06054b50) { eocd = i; break; }
    }
    if (eocd < 0) throw Error(t("msg.otaInstNoZip", "el fichero no es un ZIP"));
    const total = dv.getUint16(eocd + 10, true);
    let p = dv.getUint32(eocd + 16, true);
    const dec = new TextDecoder();
    const out = [];
    for (let n = 0; n < total; n++) {
      if (p + 46 > u8.length || dv.getUint32(p, true) !== 0x02014b50)
        throw Error(t("msg.otaInstZipRoto", "el ZIP está dañado"));
      const flags = dv.getUint16(p + 8, true);
      const metodo = dv.getUint16(p + 10, true);
      const crc = dv.getUint32(p + 16, true);
      const comp = dv.getUint32(p + 20, true);
      const tam = dv.getUint32(p + 24, true);
      const nlen = dv.getUint16(p + 28, true);
      const xlen = dv.getUint16(p + 30, true);
      const clen = dv.getUint16(p + 32, true);
      const off = dv.getUint32(p + 42, true);
      const nombre = dec.decode(u8.subarray(p + 46, p + 46 + nlen));
      p += 46 + nlen + xlen + clen;
      if (nombre.endsWith("/")) continue;
      if (flags & 1) throw Error(t("msg.otaInstZipCifrado", "el ZIP está cifrado"));
      if (off + 30 > u8.length || dv.getUint32(off, true) !== 0x04034b50)
        throw Error(t("msg.otaInstZipRoto", "el ZIP está dañado"));
      const ini = off + 30 + dv.getUint16(off + 26, true) + dv.getUint16(off + 28, true);
      if (ini + comp > u8.length) throw Error(t("msg.otaInstZipRoto", "el ZIP está dañado"));
      out.push({ nombre, metodo, crc, tam, datos: u8.subarray(ini, ini + comp) });
    }
    return out;
  }

  async function descomprimir(e) {
    let datos;
    if (e.metodo === 0) datos = e.datos;
    else if (e.metodo === 8) {
      if (typeof DecompressionStream !== "function")
        throw Error(t("msg.otaInstSinInflate",
          "este navegador no sabe descomprimir el ZIP; actualízalo o usa la subida de ficheros sueltos"));
      const flujo = new Blob([e.datos]).stream().pipeThrough(new DecompressionStream("deflate-raw"));
      datos = new Uint8Array(await new Response(flujo).arrayBuffer());
    } else {
      throw Error(`${e.nombre}: compresión ${e.metodo} no soportada`);
    }
    if (datos.length !== e.tam || crc32(datos) !== e.crc)
      throw Error(t("msg.otaInstCrc", "{f} llega dañado dentro del ZIP").replace("{f}", e.nombre));
    return datos;
  }

  let _tablaCrc = null;
  function crc32(u8) {
    if (!_tablaCrc) {
      _tablaCrc = new Uint32Array(256);
      for (let n = 0; n < 256; n++) {
        let c = n;
        for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
        _tablaCrc[n] = c >>> 0;
      }
    }
    let c = 0xffffffff;
    for (let i = 0; i < u8.length; i++) c = _tablaCrc[(c ^ u8[i]) & 0xff] ^ (c >>> 8);
    return (c ^ 0xffffffff) >>> 0;
  }

  // SHA-256 en JS: crypto.subtle no existe en http://192.168.1.1 (no es un
  // contexto seguro), y es la única forma de comprobar el paquete descargado.
  const K = new Uint32Array([
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
  ]);
  function sha256(u8) {
    const largo = u8.length;
    const bloques = Math.ceil((largo + 9) / 64);
    const m = new Uint8Array(bloques * 64);
    m.set(u8);
    m[largo] = 0x80;
    const dvm = new DataView(m.buffer);
    dvm.setUint32(m.length - 8, Math.floor(largo / 0x20000000));
    dvm.setUint32(m.length - 4, (largo * 8) >>> 0);
    const h = new Uint32Array([
      0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19,
    ]);
    const w = new Uint32Array(64);
    const rot = (x, n) => (x >>> n) | (x << (32 - n));
    for (let b = 0; b < bloques; b++) {
      for (let i = 0; i < 16; i++) w[i] = dvm.getUint32(b * 64 + i * 4);
      for (let i = 16; i < 64; i++) {
        const s0 = rot(w[i - 15], 7) ^ rot(w[i - 15], 18) ^ (w[i - 15] >>> 3);
        const s1 = rot(w[i - 2], 17) ^ rot(w[i - 2], 19) ^ (w[i - 2] >>> 10);
        w[i] = (w[i - 16] + s0 + w[i - 7] + s1) >>> 0;
      }
      let [a, bb, c, d, e, f, g, hh] = h;
      for (let i = 0; i < 64; i++) {
        const t1 = (hh + (rot(e, 6) ^ rot(e, 11) ^ rot(e, 25)) + ((e & f) ^ (~e & g)) + K[i] + w[i]) >>> 0;
        const t2 = ((rot(a, 2) ^ rot(a, 13) ^ rot(a, 22)) + ((a & bb) ^ (a & c) ^ (bb & c))) >>> 0;
        hh = g; g = f; f = e; e = (d + t1) >>> 0;
        d = c; c = bb; bb = a; a = (t1 + t2) >>> 0;
      }
      h[0] += a; h[1] += bb; h[2] += c; h[3] += d; h[4] += e; h[5] += f; h[6] += g; h[7] += hh;
    }
    return Array.from(h, (x) => x.toString(16).padStart(8, "0")).join("");
  }

  // ── Plan: qué fichero del ZIP va a qué ruta de la SD ────────────────────
  function planificar(entradas) {
    const subir = [];
    const conservados = [];
    let version = null;
    let hayIndex = false;
    for (const e of entradas) {
      const m = /^ROTECHOS\/(sys|macros|licenses|www)\/(.+)$/.exec(e.nombre);
      if (!m) continue;
      const [, carpeta, resto] = m;
      if (resto.split("/").some((s) => s === "" || s === "." || s === "..")) continue;
      if (carpeta === "sys" && DE_LA_MAQUINA.test(resto)) {
        conservados.push(`0:/sys/${resto}`);
        continue;
      }
      if (carpeta === "www" && resto === "index.html") hayIndex = true;
      if (carpeta === "sys" && resto === "VERSION") version = e;
      const ultimo = carpeta === "www" && /^index\.html(\.gz)?$/.test(resto);
      subir.push({ e, ruta: `0:/${carpeta}/${resto}`, orden: ultimo ? 9 : CARPETAS[carpeta] });
    }
    if (!hayIndex || !version)
      throw Error(t("msg.otaInstNoRotechos",
        "este ZIP no es una versión de RotechOS (le falta ROTECHOS/www/index.html o ROTECHOS/sys/VERSION)"));
    subir.sort((x, y) => x.orden - y.orden);
    return { subir, conservados, entradaVersion: version };
  }

  function versionDe(texto) {
    const m = /(\d{4}-\d{2}-\d{2})/.exec(texto || "");
    return m ? m[1] : null;
  }

  // ── Progreso a pantalla completa: mientras se escribe la SD no se toca nada
  function capa() {
    let el = document.getElementById("otaInstallOverlay");
    if (!el) {
      el = document.createElement("div");
      el.id = "otaInstallOverlay";
      el.setAttribute("role", "alertdialog");
      el.setAttribute("aria-live", "polite");
      el.style.cssText =
        "position:fixed;inset:0;z-index:100000;display:flex;align-items:center;justify-content:center;" +
        "background:rgba(0,0,0,.72);padding:16px";
      el.innerHTML =
        '<div style="background:var(--bg-panel,#1b1f24);color:var(--text-1,#fff);border:1px solid var(--border,#333);' +
        'border-radius:var(--r-md,8px);padding:18px 20px;width:min(440px,100%);font-size:14px;line-height:1.5">' +
        '<div data-ota-titulo style="font-weight:800;margin-bottom:6px"></div>' +
        '<div data-ota-texto style="color:var(--text-2,#ccc);font-size:13px;margin-bottom:10px"></div>' +
        '<div style="background:var(--bg-raised,#222);border:1px solid var(--border,#333);border-radius:3px;height:8px;overflow:hidden">' +
        '<div data-ota-barra style="background:var(--teal,#0cc);height:100%;width:0%;transition:width .2s"></div></div>' +
        '<div data-ota-pie style="color:var(--text-3,#999);font-size:12px;margin-top:8px"></div>' +
        '<button type="button" data-ota-cerrar class="ui-action-md ui-action-mute" style="display:none;margin-top:12px"></button></div>';
      document.body.appendChild(el);
    }
    const q = (s) => el.querySelector(`[data-ota-${s}]`);
    return {
      el,
      poner(titulo, texto, pct, pie) {
        q("titulo").textContent = titulo;
        q("texto").textContent = texto;
        q("barra").style.width = `${Math.max(0, Math.min(100, pct))}%`;
        q("pie").textContent = pie || "";
      },
      error(texto) {
        q("titulo").textContent = t("msg.otaInstFallo", "La instalación no se ha completado");
        q("texto").textContent = texto;
        q("barra").style.background = "var(--red,#e33)";
        const b = q("cerrar");
        b.textContent = t("btn.close", "Cerrar");
        b.style.display = "";
        b.onclick = () => el.remove();
      },
      quitar() { el.remove(); },
    };
  }

  async function subirFichero(ruta, datos) {
    const url = `${TARGET_IP}/rr_upload?name=${encodeURIComponent(ruta)}&time=${Date.now()}`;
    let ultimo = null;
    for (let intento = 0; intento < 2; intento++) {
      try {
        const r = await fetch(url, {
          method: "POST",
          body: datos,
          signal: AbortSignal.timeout(SUBIDA_TIMEOUT_MS),
        });
        if (!r.ok) throw Error(`HTTP ${r.status}`);
        const j = await r.json().catch(() => ({}));
        if (j && j.err) throw Error(`err ${j.err}`);
        return;
      } catch (e) {
        ultimo = e;
      }
    }
    throw ultimo;
  }

  function trabajoEnMarcha() {
    try {
      return SM.current === STATES.RUNNING || SM.current === STATES.PAUSED;
    } catch { return false; }
  }

  // ── Instalar un ZIP ya en memoria ─────────────────────────────────────
  async function instalarBytes(u8, origen) {
    const entradas = leerZip(u8);
    const plan = planificar(entradas);
    const nueva = versionDe(new TextDecoder().decode(await descomprimir(plan.entradaVersion)));
    if (!nueva) throw Error(t("msg.otaInstNoRotechos", "este ZIP no es una versión de RotechOS"));
    const actual = window.OTA && window.OTA.readLocalVersion ? await window.OTA.readLocalVersion() : "0";

    const aviso = actual !== "0" && nueva < actual
      ? `<p style="color:var(--yellow)"><b>${escHtml(t("dlg.otaInst.older", "Es MÁS ANTIGUA que la instalada ({v}).").replace("{v}", actual))}</b></p>`
      : actual !== "0" && nueva === actual
      ? `<p>${escHtml(t("dlg.otaInst.same", "Es la misma versión que ya tienes; se volverá a escribir."))}</p>`
      : "";
    const ok = await confirmDialog({
      title: t("dlg.otaInst.title", "Instalar RotechOS {v}").replace("{v}", nueva),
      body:
        `<p>${escHtml(t("dlg.otaInst.body", "Se escribirán {n} ficheros en la SD de la máquina ({o}). Tarda unos minutos: no apagues la máquina ni cierres esta página hasta que termine.").replace("{n}", String(plan.subir.length)).replace("{o}", origen))}</p>` +
        aviso +
        `<p>${escHtml(t("dlg.otaInst.keep", "Se conservan tu calibración (config-machine.g), el mapeo de motores (config.g) y tu WiFi."))}</p>` +
        `<p>${escHtml(t("dlg.otaInst.after", "Al terminar se reinicia la placa. Después, antes de hacer HOME, mueve cada eje un poco con el JOG y la mano en la seta."))}</p>`,
      confirmText: t("dlg.otaInst.yes", "Instalar"),
      cancelText: t("dlg.otaInst.no", "Cancelar"),
    });
    if (!ok) return false;
    if (trabajoEnMarcha()) {
      toast(t("msg.uploadActive", "No se puede subir archivos con un trabajo activo"), "err");
      return false;
    }
    if (window.rotechosAuth && typeof window.rotechosAuth.tryConnect === "function") {
      const a = await window.rotechosAuth.tryConnect(TARGET_IP, "");
      if (!a || !a.ok) throw Error(t("msg.otaInstAuth", "la máquina no ha aceptado la conexión (PIN)"));
    }

    const ui = capa();
    const titulo = t("msg.otaInstTitulo", "Instalando RotechOS {v}").replace("{v}", nueva);
    const quieto = t("msg.otaInstQuieto", "No apagues la máquina ni cierres esta página.");
    if (typeof _pausePollMs === "function") _pausePollMs(plan.subir.length * 4000 + 30000);
    let hechos = 0;
    try {
      for (const p of plan.subir) {
        ui.poner(titulo, quieto, (hechos / plan.subir.length) * 100, `[${hechos + 1}/${plan.subir.length}] ${p.ruta}`);
        const datos = await descomprimir(p.e);
        try {
          await subirFichero(p.ruta, datos);
        } catch (e) {
          throw Error(t("msg.otaInstSubida",
            "no se pudo escribir {f} ({e}). La SD ha quedado a medias: repite la instalación.")
            .replace("{f}", p.ruta).replace("{e}", e && e.message ? e.message : String(e)));
        }
        hechos++;
      }
    } catch (e) {
      ui.error(e.message || String(e));
      log(`OTA: instalación de ${nueva} interrumpida tras ${hechos}/${plan.subir.length}: ${e.message}`, "err");
      if (typeof startPoll === "function") startPoll();
      return false;
    }
    ui.poner(titulo, t("msg.otaInstHecho", "Ficheros escritos. Reiniciando la placa…"), 100, "");
    log(`OTA: RotechOS ${nueva} instalado (${hechos} ficheros, ${origen}); conservados: ${plan.conservados.join(", ") || "ninguno en el ZIP"}`, "ok");
    try {
      const l = STORE.get("ota.log", []);
      l.unshift({
        date: new Date().toLocaleString("es-ES", { day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit" }),
        files: `RotechOS ${nueva} (${hechos} archivos)`,
        ver: nueva,
        size: (u8.length / 1024).toFixed(1) + " KB",
        impact: "reboot-duet",
      });
      if (typeof CFG !== "undefined" && l.length > CFG.otaLogMax) l.length = CFG.otaLogMax;
      STORE.set("ota.log", l);
    } catch { /* el historial es cosmético */ }
    ui.quitar();
    // M999: rotechos.js enseña el aviso de reinicio y su vigilante recarga
    // la página cuando la placa vuelve (con los ficheros nuevos).
    await RRF.gcode("M999");
    return true;
  }

  async function conGuarda(fn) {
    if (_ocupado) {
      toast(t("msg.otaInProgress", "Comprobación en curso…"), "warn");
      return false;
    }
    _ocupado = true;
    try {
      return await fn();
    } catch (e) {
      toast(t("msg.otaInstFallo", "La instalación no se ha completado") + ": " + (e.message || e), "err");
      LOG.warn("OTA: instalación fallida", e);
      return false;
    } finally {
      _ocupado = false;
    }
  }

  // Desde el aviso: descarga el paquete publicado y comprueba su huella.
  function desdeManifest(manifest) {
    return conGuarda(async () => {
      const url = manifest && manifest.paquete_url;
      const sha = String((manifest && manifest.paquete_sha256) || "").toLowerCase();
      if (!PAQUETE_URL_OK.test(url || "") || !/^[0-9a-f]{64}$/.test(sha))
        throw Error(t("msg.otaInstSinPaquete", "esta versión no trae paquete instalable; descárgala de GitHub"));
      const ui = capa();
      ui.poner(t("msg.otaInstBajando", "Descargando RotechOS {v}").replace("{v}", manifest.rotechos_version), "", 5, "");
      let u8;
      try {
        const r = await fetch(url, { cache: "no-store", signal: AbortSignal.timeout(DESCARGA_TIMEOUT_MS) });
        if (!r.ok) throw Error(`HTTP ${r.status}`);
        u8 = new Uint8Array(await r.arrayBuffer());
      } catch (e) {
        ui.quitar();
        throw Error(t("msg.otaInstSinRed",
          "no se pudo descargar ({e}). Si este dispositivo no tiene internet, descarga el ZIP desde otro y usa «Instalar desde un ZIP» en CONFIGURACIÓN → ACTUALIZAR (OTA)")
          .replace("{e}", e.message || e));
      }
      ui.quitar();
      if (sha256(u8) !== sha)
        throw Error(t("msg.otaInstSha", "la descarga no coincide con la publicada; inténtalo de nuevo en unos minutos"));
      return instalarBytes(u8, t("msg.otaInstOrigenGithub", "descargada de GitHub"));
    });
  }

  // Desde un ZIP elegido en el dispositivo.
  function desdeFichero(file) {
    return conGuarda(async () => {
      if (!file) return false;
      const u8 = new Uint8Array(await file.arrayBuffer());
      return instalarBytes(u8, file.name);
    });
  }

  window.OTAInstall = { desdeManifest, desdeFichero, _leerZip: leerZip, _planificar: planificar, _sha256: sha256, _crc32: crc32, _descomprimir: descomprimir };
})();
