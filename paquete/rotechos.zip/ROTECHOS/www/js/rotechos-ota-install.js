// rotechos-ota-install.js — instalar una versión de RotechOS desde la interfaz.
//
// Dos entradas, las dos con un toque humano y una confirmación:
//   - «Instalar ahora» en el aviso de versión nueva: descarga el paquete que
//     publica scripts/publicar_actualizacion.sh en Peerchi/rotechos-updates
//     (raw.githubusercontent.com, que sí permite leerlo desde el navegador; el
//     adjunto de la release no) y comprueba su SHA-256 contra el manifest.
//   - «Instalar desde un ZIP»: el mismo ZIP de la release, elegido en el
//     dispositivo. Vale sin internet, p. ej. conectado a la red RotechOS.
//
// Qué hace con el ZIP: comprueba el CRC de cada fichero, y sube a la SD lo que
// hay en ROTECHOS/sys, macros, licenses y www, con index.html al final de la
// interfaz y VERSION después de verificar el resto. No toca nunca los ficheros de ESTA máquina: config-machine.g
// (calibración, PIN, drivers vetados), config-override.g, board.txt,
// user-daemon.g ni wifi-passwords.g. Tampoco firmware/: el módulo WiFi ya está grabado.
// 18-oct (O3): tampoco sustituye el estado generado en runtime (resurrect.g,
// saved_offsets.g, pro_params_saved.g, jobhistory.json, *.csv y la copia OTA).
// config.g se FUSIONA (17-oct): el del paquete trae la lógica de fábrica nueva,
// y las líneas que son de la máquina (lista cerrada en claveDe) se copian tal
// cual del config.g que ya tenía. El anterior queda en 0:/sys/config.g.antes-ota.
// Si no se puede leer o no parece un config.g de RotechOS, se conserva entero.
// Al terminar ofrece reiniciar la placa (M999); el vigilante de M999 recarga
// la página cuando vuelve.
//
// Carga perezosa desde rotechos-ota.js. Depende de rotechos.js (TARGET_IP,
// RRF, SM, STATES, STORE, CFG, toast, log, LOG, confirmDialog) y de t().

(function () {
  "use strict";

  const PAQUETE_URL_OK =
    /^https:\/\/raw\.githubusercontent\.com\/Peerchi\/rotechos-updates\//;
  const DESCARGA_TIMEOUT_MS = 120000;
  const SUBIDA_TIMEOUT_MS = 60000;
  // Topes deliberadamente muy por encima de una release normal (~4 MiB sin
  // comprimir), pero finitos: la UI procesa el ZIP en la memoria del móvil.
  const MAX_ZIP_COMPRIMIDO = 16 * 1024 * 1024;
  const MAX_ENTRADAS_ZIP = 2000;
  const MAX_ZIP_EXPANDIDO = 64 * 1024 * 1024;
  // M39 informa de espacio libre en la SD. El margen cubre temporales del
  // filesystem y evita empezar una OTA cuando solo cabría el ZIP lógico.
  const ESPACIO_OTA_MARGEN_MIN = 1024 * 1024;
  const ESPACIO_OTA_MARGEN_PCT = 0.25;
  const OTA_MANIFEST = "0:/sys/rotechos-ota-manifest.json";
  const OTA_TRANSACTION = "0:/sys/rotechos-ota-transaction.json";
  const OTA_TRANSACTION_RESERVA = 2048;

  // Ficheros propios de cada máquina: la instalación no los sustituye nunca.
  // 18-oct (E1): además de la configuración y credenciales, RRF y la UI
  // escriben estos ficheros de estado durante la vida de la máquina. La OTA
  // no debe sustituirlos aunque alguien construya un ZIP que los contenga.
  const DE_LA_MAQUINA =
    /^(?:config-machine|config-override|user-daemon|wifi-passwords|ap-key|saved_offsets|saved_position|pro_params_saved|resurrect|wifi-module-flashed|net-ethernet|net-ethernet-direct)\.g$|^config\.g\.antes-ota$|^(?:rotechos-ota-(?:manifest|transaction)\.json|jobhistory\.json|.+\.csv|board\.txt)$/i;
  const COPIA_CONFIG = "0:/sys/config.g.antes-ota";
  const CARPETAS = { sys: 0, macros: 1, licenses: 2, www: 3 };

  let _ocupado = false;

  // ── ZIP ────────────────────────────────────────────────────────────────
  // Lee el directorio central (no adivina por firmas sueltas, que pueden
  // aparecer dentro de un fichero comprimido).
  function leerZip(u8) {
    if (u8.length > MAX_ZIP_COMPRIMIDO)
      throw Error(t("msg.otaInstZipGrande", "el ZIP es demasiado grande"));
    const dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength);
    let eocd = -1;
    for (let i = u8.length - 22; i >= 0 && i >= u8.length - 22 - 65535; i--) {
      if (dv.getUint32(i, true) === 0x06054b50) { eocd = i; break; }
    }
    if (eocd < 0) throw Error(t("msg.otaInstNoZip", "el fichero no es un ZIP"));
    const total = dv.getUint16(eocd + 10, true);
    if (total > MAX_ENTRADAS_ZIP)
      throw Error(t("msg.otaInstZipEntradas", "el ZIP contiene demasiados ficheros"));
    let p = dv.getUint32(eocd + 16, true);
    const dec = new TextDecoder();
    const out = [];
    let expandido = 0;
    for (let n = 0; n < total; n++) {
      if (p + 46 > u8.length || dv.getUint32(p, true) !== 0x02014b50)
        throw Error(t("msg.otaInstZipRoto", "el ZIP está dañado"));
      const flags = dv.getUint16(p + 8, true);
      const metodo = dv.getUint16(p + 10, true);
      const crc = dv.getUint32(p + 16, true);
      const comp = dv.getUint32(p + 20, true);
      const tam = dv.getUint32(p + 24, true);
      const nlen = dv.getUint16(p + 28, true);
      const xlen = dv.getUint16(p + 30, true);
      const clen = dv.getUint16(p + 32, true);
      const off = dv.getUint32(p + 42, true);
      expandido += tam;
      if (expandido > MAX_ZIP_EXPANDIDO)
        throw Error(t("msg.otaInstZipGrande", "el ZIP es demasiado grande"));
      const nombre = dec.decode(u8.subarray(p + 46, p + 46 + nlen));
      p += 46 + nlen + xlen + clen;
      if (nombre.endsWith("/")) continue;
      if (flags & 1) throw Error(t("msg.otaInstZipCifrado", "el ZIP está cifrado"));
      if (off + 30 > u8.length || dv.getUint32(off, true) !== 0x04034b50)
        throw Error(t("msg.otaInstZipRoto", "el ZIP está dañado"));
      const ini = off + 30 + dv.getUint16(off + 26, true) + dv.getUint16(off + 28, true);
      if (ini + comp > u8.length) throw Error(t("msg.otaInstZipRoto", "el ZIP está dañado"));
      out.push({ nombre, metodo, crc, tam, datos: u8.subarray(ini, ini + comp) });
    }
    return out;
  }

  async function descomprimir(e) {
    let datos;
    if (e.metodo === 0) datos = e.datos;
    else if (e.metodo === 8) {
      if (typeof DecompressionStream !== "function")
        throw Error(t("msg.otaInstSinInflate",
          "este navegador no sabe descomprimir el ZIP; actualízalo o usa la subida de ficheros sueltos"));
      const flujo = new Blob([e.datos]).stream().pipeThrough(new DecompressionStream("deflate-raw"));
      datos = new Uint8Array(await new Response(flujo).arrayBuffer());
    } else {
      throw Error(`${e.nombre}: compresión ${e.metodo} no soportada`);
    }
    if (datos.length !== e.tam || crc32(datos) !== e.crc)
      throw Error(t("msg.otaInstCrc", "{f} llega dañado dentro del ZIP").replace("{f}", e.nombre));
    return datos;
  }

  let _tablaCrc = null;
  function crc32(u8) {
    if (!_tablaCrc) {
      _tablaCrc = new Uint32Array(256);
      for (let n = 0; n < 256; n++) {
        let c = n;
        for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
        _tablaCrc[n] = c >>> 0;
      }
    }
    let c = 0xffffffff;
    for (let i = 0; i < u8.length; i++) c = _tablaCrc[(c ^ u8[i]) & 0xff] ^ (c >>> 8);
    return (c ^ 0xffffffff) >>> 0;
  }

  // SHA-256 en JS: crypto.subtle no existe en http://192.168.1.1 (no es un
  // contexto seguro), y es la única forma de comprobar el paquete descargado.
  const K = new Uint32Array([
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
  ]);
  function sha256(u8) {
    const largo = u8.length;
    const bloques = Math.ceil((largo + 9) / 64);
    const m = new Uint8Array(bloques * 64);
    m.set(u8);
    m[largo] = 0x80;
    const dvm = new DataView(m.buffer);
    dvm.setUint32(m.length - 8, Math.floor(largo / 0x20000000));
    dvm.setUint32(m.length - 4, (largo * 8) >>> 0);
    const h = new Uint32Array([
      0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19,
    ]);
    const w = new Uint32Array(64);
    const rot = (x, n) => (x >>> n) | (x << (32 - n));
    for (let b = 0; b < bloques; b++) {
      for (let i = 0; i < 16; i++) w[i] = dvm.getUint32(b * 64 + i * 4);
      for (let i = 16; i < 64; i++) {
        const s0 = rot(w[i - 15], 7) ^ rot(w[i - 15], 18) ^ (w[i - 15] >>> 3);
        const s1 = rot(w[i - 2], 17) ^ rot(w[i - 2], 19) ^ (w[i - 2] >>> 10);
        w[i] = (w[i - 16] + s0 + w[i - 7] + s1) >>> 0;
      }
      let [a, bb, c, d, e, f, g, hh] = h;
      for (let i = 0; i < 64; i++) {
        const t1 = (hh + (rot(e, 6) ^ rot(e, 11) ^ rot(e, 25)) + ((e & f) ^ (~e & g)) + K[i] + w[i]) >>> 0;
        const t2 = ((rot(a, 2) ^ rot(a, 13) ^ rot(a, 22)) + ((a & bb) ^ (a & c) ^ (bb & c))) >>> 0;
        hh = g; g = f; f = e; e = (d + t1) >>> 0;
        d = c; c = bb; bb = a; a = (t1 + t2) >>> 0;
      }
      h[0] += a; h[1] += bb; h[2] += c; h[3] += d; h[4] += e; h[5] += f; h[6] += g; h[7] += hh;
    }
    return Array.from(h, (x) => x.toString(16).padStart(8, "0")).join("");
  }

  // ── Plan: qué fichero del ZIP va a qué ruta de la SD ────────────────────
  function planificar(entradas) {
    const subir = [];
    const conservados = [];
    const destinos = new Set();
    let version = null;
    let configNuevo = null;
    let hayIndex = false;
    for (const e of entradas) {
      const m = /^ROTECHOS\/(sys|macros|licenses|www)\/(.+)$/.exec(e.nombre);
      if (!m) continue;
      const [, carpeta, resto] = m;
      if (resto.split("/").some((s) => s === "" || s === "." || s === "..")) continue;
      const ruta = `0:/${carpeta}/${resto}`;
      if (destinos.has(ruta)) throw Error(t("msg.otaInstDuplicado", `el ZIP contiene dos entradas para ${ruta}`));
      destinos.add(ruta);
      if (carpeta === "sys" && DE_LA_MAQUINA.test(resto)) {
        conservados.push(`0:/sys/${resto}`);
        continue;
      }
      if (carpeta === "sys" && resto === "config.g") {
        configNuevo = e;
        continue;
      }
      if (carpeta === "www" && resto === "index.html") hayIndex = true;
      if (carpeta === "sys" && resto === "VERSION") version = e;
      const ultimo = carpeta === "www" && /^index\.html(\.gz)?$/.test(resto);
      subir.push({ e, ruta, orden: ultimo ? 9 : CARPETAS[carpeta] });
    }
    if (!hayIndex || !version)
      throw Error(t("msg.otaInstNoRotechos",
        "este ZIP no es una versión de RotechOS (le falta ROTECHOS/www/index.html o ROTECHOS/sys/VERSION)"));
    subir.sort((x, y) => x.orden - y.orden);
    return { subir, conservados, entradaVersion: version, configNuevo };
  }

  // ── config.g: lógica de fábrica nueva + valores de ESTA máquina ────────
  // Criterio (17-oct): de config.g es de la máquina, y por tanto se conserva,
  // exactamente lo que la interfaz escribe en él o lo que fija un valor de la
  // máquina: nombre (M550), dirección y modo de cada driver (M569 P0-P3), mapeo
  // de ejes (M584), finales de carrera por eje (M574), husillo (M950 R0) y LED
  // (M150),
  // sonda (M558, G31), HOME obligatorio y límites (M564, M208), los valores de
  // reserva de motores y velocidades (M350, M92, M906, M201, M203, M566, M425),
  // los `set global.X` sueltos y los comentarios `; rotech-*=`. Todo lo demás
  // —orden, condicionales, macros que se llaman, líneas nuevas— viene de fábrica.
  // Solo cuentan las líneas sin sangría: una sangrada está dentro de un if y es
  // lógica. Mismo ancla que cfgReplaceLine (inicio de línea), que es como la
  // interfaz las encuentra para editarlas.
  const CLAVE_SOLO_ORDEN = /^(?:M550|M584|M558|G31|M564|M350|M92|M906|M201|M203|M566|M425|M150)$/;

  // Estas órdenes forman parte de la lógica de fábrica y no son ajustes que
  // la UI conserve en config.g. Se permiten como excepciones al guardia de
  // claves desconocidas: M593 dejó de formar parte de la plantilla y M106 es
  // el fallback de ventiladores (la UI lo guarda en config-machine.g).
  const COMANDOS_FABRICA_NO_MAQUINA = new Set(["M593", "M106", "M911"]);

  function comandoDe(linea) {
    if (/^\s/.test(linea)) return null;
    let codigo = "";
    for (let i = 0, comillas = false; i < linea.length; i++) {
      const ch = linea[i];
      if (ch === '"') comillas = !comillas;
      else if (ch === ";" && !comillas) break;
      codigo += ch;
    }
    const m = /^([GM]\d+(?:\.\d+)?)(?:\s|$)/i.exec(codigo.trim());
    return m ? m[1].toUpperCase() : null;
  }

  function claveDe(linea) {
    if (/^\s/.test(linea)) return null;
    const com = /^;\s*(rotech-[a-z0-9-]+)=/i.exec(linea);
    if (com) return `;${com[1].toLowerCase()}`;
    const g = /^set\s+global\.([A-Za-z_][A-Za-z0-9_]*)\s*=/.exec(linea);
    if (g) return `set global.${g[1]}`;
    // El comentario empieza en el primer `;` fuera de comillas (M950 C"a;b" R0).
    let codigo = "";
    for (let i = 0, comillas = false; i < linea.length; i++) {
      const ch = linea[i];
      if (ch === '"') comillas = !comillas;
      else if (ch === ";" && !comillas) break;
      codigo += ch;
    }
    codigo = codigo.trim();
    const m = /^([GM]\d+(?:\.\d+)?)(?:\s+(.*))?$/i.exec(codigo);
    if (!m) return null;
    const cmd = m[1].toUpperCase();
    const args = (m[2] || "").split(/\s+/).filter(Boolean);
    if (CLAVE_SOLO_ORDEN.test(cmd)) return cmd;
    // La Scylla tiene los drivers P0 a P3; un M569 P4 viejo no se arrastra.
    if (cmd === "M569") {
      const p = args.find((a) => /^P[0-3]$/i.test(a));
      return p ? `M569 ${p.toUpperCase()}` : null;
    }
    if (cmd === "M574") {
      const eje = args.find((a) => /^[XYZABC]/i.test(a));
      return eje ? `M574 ${eje[0].toUpperCase()}` : null;
    }
    if (cmd === "M950") return args.some((a) => /^R0$/i.test(a)) ? "M950 R0" : null;
    if (cmd === "M208") return args.some((a) => /^S1$/i.test(a)) ? "M208 S1" : "M208 S0";
    return null;
  }

  // Claves que fijan UN valor: si la máquina las tenía repetidas, RRF se quedaba
  // con la última, y solo esa se arrastra (dos M569 P1 resetean el TMC dos veces).
  // Las de ejes (M574 X1 y X2, M906 X… y M906 Z…, M208 S0/S1) se arrastran todas.
  const CLAVE_VARIAS = /^(?:M574 |M208 |M350$|M92$|M906$|M201$|M203$|M566$|M425$)/;

  // Devuelve { texto, conservadas, anadidas }, { bloqueada, desconocidas } o
  // null si `viejo` no parece un config.g de RotechOS (entonces no se toca:
  // mejor sin mejoras que sin motores).
  function fusionarConfig(nuevo, viejo) {
    const norm = (x) => String(x || "").replace(/^\uFEFF/, "").replace(/\r\n/g, "\n");
    const lv = norm(viejo).split("\n");
    const ln = norm(nuevo).split("\n");
    const claves = (ls) => new Set(ls.map(claveDe).filter(Boolean));
    const kv = claves(lv);
    if (!kv.has("M584") || !kv.has("M569 P0") || !claves(ln).has("M584")) return null;

    // Una clave nueva que la OTA no entiende no puede clasificarse como
    // lógica de fábrica ni como ajuste de máquina. Si la línea antigua no
    // existe literalmente en la plantilla nueva, fusionar la descartaría sin
  // avisar. En ese caso se conserva config.g entero (el caller deja
    // configNuevo fuera del plan) y la actualización sigue siendo segura.
    // Una línea sangrada solo es equivalente bajo los mismos bloques padres.
    // Contar ocurrencias evita dar por conservada una instrucción duplicada.
    function lineasCondicionales(ls) {
      const padres = [];
      const cuentas = new Map();
      for (const linea of ls) {
        if (!linea.trim() || /^\s*;/.test(linea)) continue;
        const sangria = /^\s*/.exec(linea)[0].length;
        while (padres.length && padres[padres.length - 1].sangria >= sangria) padres.pop();
        const firma = JSON.stringify([...padres.map((p) => p.linea), linea]);
        if (sangria) cuentas.set(firma, (cuentas.get(firma) || 0) + 1);
        padres.push({ sangria, linea });
      }
      return cuentas;
    }
    const condNuevas = lineasCondicionales(ln);
    const condViejas = lineasCondicionales(lv);
    const lineasNuevas = new Set(ln);
    const desconocidas = [];
    for (const [firma, cantidad] of condViejas) {
      // Bloque de fábrica retirado en la versión posterior al 10-oct-2026.
      // Solo se reconoce esa instrucción exacta bajo esa condición exacta.
      const retiradaConocida = firma === JSON.stringify([
        "if exists(sensors.analog[11])", "    M106 P1 H10:11"
      ]) ? 1 : 0;
      if ((condNuevas.get(firma) || 0) + retiradaConocida < cantidad) {
        desconocidas.push(JSON.parse(firma).slice(-1)[0]);
      }
    }
    for (const l of lv) {
      if (!l.trim() || /^\s/.test(l) || claveDe(l)) continue;
      const cmd = comandoDe(l);
      // Mantener la compatibilidad existente: un M569 P4 antiguo se elimina
      // al tomar la plantilla nueva, porque la Scylla solo tiene P0-P3.
      if (/^M569\s+P[4-9]\b/i.test(l)) continue;
      // Una línea no reconocida puede ser lógica RRF propia (var, global,
      // echo, if, etc.). No se puede descartar silenciosamente al fusionar:
      // si la plantilla nueva no la contiene literalmente, se conserva el
      // config.g entero y se pide revisión manual.
      if (!cmd) {
        // Los comentarios no tienen efecto en el arranque; no deben bloquear
        // una fusión solo porque la plantilla nueva ya no documente la misma
        // explicación local.
        if (/^\s*;/.test(l)) continue;
        if (!lineasNuevas.has(l) && !desconocidas.includes(l)) desconocidas.push(l);
        continue;
      }
      if (COMANDOS_FABRICA_NO_MAQUINA.has(cmd)) continue;
      if (!lineasNuevas.has(l) && !desconocidas.includes(l)) desconocidas.push(l);
    }
    if (desconocidas.length) {
      // No se puede decidir si es una opción nueva de la UI o una orden de
      // fábrica retirada. En ambos casos es más seguro no reemplazar config.g:
      // así la orden no se pierde y tampoco se ejecuta una plantilla parcial.
      return { bloqueada: true, desconocidas };
    }

    const deLaMaquina = new Map();
    for (const l of lv) {
      const k = claveDe(l);
      if (!k) continue;
      if (!deLaMaquina.has(k) || !CLAVE_VARIAS.test(k)) deLaMaquina.set(k, []);
      deLaMaquina.get(k).push(l);
    }
    const puestas = new Set();
    const out = [];
    for (const l of ln) {
      const k = claveDe(l);
      if (!k || !deLaMaquina.has(k)) { out.push(l); continue; }
      if (!puestas.has(k)) out.push(...deLaMaquina.get(k));
      puestas.add(k);
    }
    // Lo que la fábrica ya no trae: la interfaz lo añadió (cfgReplaceLine
    // añade al final si no encuentra la línea). Va donde iría: los
    // `set global` delante de la carga de config-machine.g (cfgSetGlobal), el
    // resto al final.
    const anadidas = [...deLaMaquina.keys()].filter((k) => !puestas.has(k));
    const globales = anadidas.filter((k) => k.startsWith("set global."));
    const resto = anadidas.filter((k) => !k.startsWith("set global."));
    if (globales.length) {
      const i = out.findIndex((l) => /^if fileexists\("0:\/sys\/config-machine\.g"\)/.test(l));
      const lineas = globales.flatMap((k) => deLaMaquina.get(k));
      if (i >= 0) out.splice(i, 0, ...lineas);
      else resto.unshift(...globales);
    }
    if (resto.length) {
      while (out.length && out[out.length - 1] === "") out.pop();
      out.push(...resto.flatMap((k) => deLaMaquina.get(k)), "");
    }
    return { texto: out.join("\n"), conservadas: [...puestas], anadidas, desconocidas: [] };
  }

  async function leerConfigActual(ruta = "0:/sys/config.g") {
    try {
      if (typeof RRF === "undefined" || typeof RRF.download !== "function") return null;
      const r = await RRF.download(ruta, { timeoutMs: 15000 });
      if (!r || !r.ok) return null;
      const texto = await r.text();
      return texto && texto.trim() ? texto : null;
    } catch { return null; }
  }

  function versionDe(texto) {
    const m = /(\d{4}-\d{2}-\d{2})/.exec(texto || "");
    return m ? m[1] : null;
  }

  // ── Progreso a pantalla completa: mientras se escribe la SD no se toca nada
  function capa() {
    let el = document.getElementById("otaInstallOverlay");
    if (!el) {
      el = document.createElement("div");
      el.id = "otaInstallOverlay";
      el.setAttribute("role", "alertdialog");
      el.setAttribute("aria-live", "polite");
      el.style.cssText =
        "position:fixed;inset:0;z-index:100000;display:flex;align-items:center;justify-content:center;" +
        "background:rgba(0,0,0,.72);padding:16px";
      el.innerHTML =
        '<div style="background:var(--bg-panel,#1b1f24);color:var(--text-1,#fff);border:1px solid var(--border,#333);' +
        'border-radius:var(--r-md,8px);padding:18px 20px;width:min(440px,100%);font-size:14px;line-height:1.5">' +
        '<div data-ota-titulo style="font-weight:800;margin-bottom:6px"></div>' +
        '<div data-ota-texto style="color:var(--text-2,#ccc);font-size:13px;margin-bottom:10px"></div>' +
        '<div style="background:var(--bg-raised,#222);border:1px solid var(--border,#333);border-radius:3px;height:8px;overflow:hidden">' +
        '<div data-ota-barra style="background:var(--teal,#0cc);height:100%;width:0%;transition:width .2s"></div></div>' +
        '<div data-ota-pie style="color:var(--text-3,#999);font-size:12px;margin-top:8px"></div>' +
        '<button type="button" data-ota-cerrar class="ui-action-md ui-action-mute" style="display:none;margin-top:12px"></button></div>';
      document.body.appendChild(el);
    }
    const q = (s) => el.querySelector(`[data-ota-${s}]`);
    return {
      el,
      poner(titulo, texto, pct, pie) {
        q("titulo").textContent = titulo;
        q("texto").textContent = texto;
        q("barra").style.width = `${Math.max(0, Math.min(100, pct))}%`;
        q("pie").textContent = pie || "";
      },
      error(texto) {
        q("titulo").textContent = t("msg.otaInstFallo", "La instalación no se ha completado");
        q("texto").textContent = texto;
        q("barra").style.background = "var(--red,#e33)";
        const b = q("cerrar");
        b.textContent = t("btn.close", "Cerrar");
        b.style.display = "";
        b.onclick = () => el.remove();
      },
      quitar() { el.remove(); },
    };
  }

  async function subirFichero(ruta, datos) {
    const url = `${TARGET_IP}/rr_upload?name=${encodeURIComponent(ruta)}&time=${Date.now()}`;
    let ultimo = null;
    for (let intento = 0; intento < 3; intento++) {
      await exigirMaquinaInactiva();
      try {
        const r = await fetch(url, {
          method: "POST",
          body: datos,
          signal: AbortSignal.timeout(SUBIDA_TIMEOUT_MS),
        });
        if (!r.ok) throw Error(`HTTP ${r.status}`);
        const j = await r.json().catch(() => ({}));
        if (j && j.err) throw Error(`err ${j.err}`);
        return;
      } catch (e) {
        ultimo = e;
      }
    }
    throw ultimo;
  }

  function bytesPlan(plan) {
    return plan.subir.reduce((total, p) => total +
      Number(p.datos?.byteLength ?? p.e?.tam ?? 0), 0);
  }

  function fmtBytes(bytes) {
    const n = Number(bytes);
    if (!Number.isFinite(n) || n < 0) return "—";
    if (n < 1024 * 1024) return `${Math.round(n / 1024)} KB`;
    return `${(n / 1048576).toFixed(1)} MB`;
  }

  function extraerSDInfo(respuesta) {
    const candidatos = [
      respuesta?.SDinfo,
      respuesta?.sdInfo,
      respuesta?.result?.SDinfo,
      respuesta?.result?.sdInfo,
      respuesta?.result,
      respuesta,
    ];
    return candidatos.find((x) => x && typeof x === "object" &&
      ((Number.isFinite(Number(x.present)) && Number(x.present) >= 0) ||
       (Number.isFinite(Number(x.free)) && Number(x.free) >= 0))) || null;
  }

  // M39 es una lectura: no escribe la SD ni cambia el estado de la máquina.
  // Algunas builds antiguas no lo exponen por rr_gcode; en ese caso se
  // devuelve null y la OTA sigue siendo compatible, pero lo deja registrado.
  async function consultarSD() {
    try {
      if (typeof RRF === "undefined" || typeof RRF.gcode !== "function") return null;
      const info = extraerSDInfo(await RRF.gcode("M39 P0 S2"));
      if (!info) LOG?.warn?.("OTA: M39 no devolvió SDinfo; continúo sin preflight de espacio");
      return info;
    } catch (e) {
      LOG?.warn?.("OTA: no se pudo consultar M39", e?.message || e);
      return null;
    }
  }

  async function comprobarEspacio(plan) {
    const info = await consultarSD();
    if (!info) return { conocido: false, necesario: bytesPlan(plan) };
    if (Number(info.present) === 0)
      throw Error(t("msg.otaInstSdAusente", "la controladora no detecta una SD utilizable"));
    const libreReportado = Number(info.free);
    if (!Number.isFinite(libreReportado) || libreReportado < 0) {
      LOG?.warn?.("OTA: M39 informó la SD pero no devolvió free; continúo sin preflight de espacio");
      return { conocido: false, necesario: bytesPlan(plan) };
    }
    const payload = bytesPlan(plan) + OTA_TRANSACTION_RESERVA;
    const margen = Math.max(ESPACIO_OTA_MARGEN_MIN, Math.ceil(payload * ESPACIO_OTA_MARGEN_PCT));
    const necesario = payload + margen;
    const libre = libreReportado;
    if (libre < necesario) {
      throw Error(t("msg.otaInstSinEspacio",
        "no hay espacio suficiente en la SD: quedan {l} y la actualización necesita aproximadamente {n} contando margen")
        .replace("{l}", fmtBytes(libre)).replace("{n}", fmtBytes(necesario)));
    }
    return { conocido: true, libre, necesario, capacidad: Number(info.capacity) || null };
  }

  function rutaGestionadaSegura(ruta, conMacros = false) {
    const raiz = conMacros ? "(?:www|licenses|macros)" : "(?:www|licenses)";
    const m = new RegExp(`^0:/(${raiz})/(.+)$`).exec(String(ruta || ""));
    if (!m) return false;
    return m[2].split("/").every((segmento) => segmento && segmento !== "." && segmento !== ".." &&
      /^[A-Za-z0-9][A-Za-z0-9_.-]*$/.test(segmento));
  }

  async function leerManifiesto() {
    const texto = await leerConfigActual(OTA_MANIFEST);
    if (!texto || texto.length > 128 * 1024) return null;
    try {
      const dato = JSON.parse(texto);
      if (dato?.format !== 1 || !Array.isArray(dato.paths)) return null;
      // Solo se aceptan rutas web/licencias que la OTA haya declarado. Nunca
      // se usa el manifiesto para borrar macros, G-code o configuración.
      const paths = dato.paths.filter((p) => typeof p === "string" && rutaGestionadaSegura(p));
      const macroHashes = {};
      if (dato.macroHashes && typeof dato.macroHashes === "object") {
        for (const [ruta, hash] of Object.entries(dato.macroHashes)) {
          if (rutaGestionadaSegura(ruta, true) && /^\w{64}$/.test(String(hash))) macroHashes[ruta] = String(hash);
        }
      }
      return { version: String(dato.version || ""), paths: new Set(paths), macroHashes };
    } catch { return null; }
  }

  function rutasGestionadas(plan) {
    return [...new Set(plan.subir.map((p) => p.ruta).filter((ruta) =>
      rutaGestionadaSegura(ruta)))];
  }

  async function limpiarResiduos(previo, plan) {
    if (!previo || typeof RRF === "undefined" || typeof RRF.deleteFile !== "function") return 0;
    const actuales = new Set(rutasGestionadas(plan));
    const obsoletos = [...previo.paths].filter((ruta) => !actuales.has(ruta));
    let borrados = 0;
    for (const ruta of obsoletos) {
      await exigirMaquinaInactiva();
      try {
        if (await RRF.deleteFile(ruta)) borrados++;
        else LOG?.warn?.(`OTA: no se pudo limpiar residuo ${ruta}`);
      } catch (e) {
        LOG?.warn?.(`OTA: limpieza omitida ${ruta}`, e?.message || e);
      }
    }
    return borrados;
  }

  async function guardarManifiesto(version, plan) {
    try {
      if (typeof TextEncoder !== "function") return false;
      const macroHashes = {};
      for (const p of plan.subir.filter((item) => item.ruta.startsWith("0:/macros/"))) {
        const datos = p.datos || await descomprimir(p.e);
        macroHashes[p.ruta] = sha256(datos);
      }
      const datos = new TextEncoder().encode(JSON.stringify({
        format: 1,
        version,
        paths: rutasGestionadas(plan),
        macroHashes,
      }));
      await subirFichero(OTA_MANIFEST, datos);
      return true;
    } catch (e) {
      if (e?.otaEstado) throw e;
      // El manifiesto solo sirve para limpiar residuos en la siguiente OTA;
      // no debe convertir una instalación ya escrita en un falso fallo total.
      LOG?.warn?.("OTA: no se pudo guardar el manifiesto", e?.message || e);
      return false;
    }
  }

  // Compatibilidad con tarjetas antiguas: se interpreta 404 como ausencia.
  // RRF también puede devolverlo al fallar la apertura de un fichero existente;
  // ni el listado garantiza ausencia ante todos los errores de lectura de SD.
  async function comprobarTransaccionAnterior() {
    try {
      const r = await RRF.download(OTA_TRANSACTION, { timeoutMs: 15000 });
      if (r && r.status === 404) return;
      if (!r || !r.ok) throw Error("lectura fallida");
      const dato = JSON.parse(await r.text());
      if (dato?.format === 1 && dato.status === "complete" && /^\d{4}-\d{2}-\d{2}$/.test(String(dato.version || ""))) return;
    } catch { /* Un marcador ilegible tampoco acredita una copia. */ }
    throw Error(t("msg.otaRecoveryReview", "No se puede acreditar el estado de recuperación de la OTA anterior. No reinicies ni repitas la actualización. Pide que revisen sys/config.g, sys/config.g.antes-ota y el control de transacción OTA antes de continuar."));
  }

  async function guardarTransaccion(version, status, plan) {
    try {
      const datos = new TextEncoder().encode(JSON.stringify({
        format: 1,
        status,
        version,
        paths: plan ? plan.subir.map((p) => p.ruta).filter((ruta) => rutaGestionadaSegura(ruta, true)) : [],
        at: new Date().toISOString(),
      }));
      await subirFichero(OTA_TRANSACTION, datos);
      const r = await RRF.download(OTA_TRANSACTION, { timeoutMs: 15000 });
      if (!r || !r.ok || await r.text() !== new TextDecoder().decode(datos)) throw Error("verificación fallida");
      return true;
    } catch (e) {
      LOG?.warn?.(`OTA: no se pudo guardar transacción ${status}`, e?.message || e);
      return false;
    }
  }

  // Por compatibilidad se trata 404 como ausencia, aunque RRF puede emitirlo
  // cuando falla la apertura de un macro existente.
  async function leerMacroActual(ruta) {
    let r = null;
    try { r = await RRF.download(ruta, { timeoutMs: 15000 }); } catch { r = null; }
    if (r && r.status === 404) return null;
    if (!r || !r.ok) {
      throw Error(t("msg.otaInstMacroIlegible",
        `no se pudo leer ${ruta} ni confirmar si existe; pide que revisen el archivo y la conexión antes de actualizar`, { ruta }));
    }
    return await r.text();
  }

  async function comprobarConflictosMacros(previo, plan) {
    const hashes = previo?.macroHashes || {};
    const conservar = new Set();
    for (const p of plan.subir.filter((item) => item.ruta.startsWith("0:/macros/"))) {
      const actual = await leerMacroActual(p.ruta);
      if (actual === null) continue;
      const esperado = p.datos || await descomprimir(p.e);
      const hashActual = sha256(new TextEncoder().encode(actual));
      if (hashes[p.ruta] !== hashActual) {
        // Una coincidencia exacta con el paquete permite adoptar una macro
        // sin huella. Una huella conocida discrepante sigue siendo conflicto,
        // incluso si el contenido coincide con el paquete nuevo.
        if (!hashes[p.ruta] && hashActual === sha256(esperado)) {
          p.datos = esperado;
          continue;
        }
        // Sin huella y con contenido distinto, podría ser del operario.
        // Se conserva sin registrarlo como contenido de fábrica.
        if (!hashes[p.ruta]) {
          conservar.add(p.ruta);
          LOG?.warn?.(`OTA: se conserva macro existente sin huella previa ${p.ruta}`);
          continue;
        }
        throw Error(t("msg.otaInstMacroConflicto",
          `no se sobrescribe el macro personalizado ${p.ruta}; haz una copia y resuelve el conflicto antes de actualizar`));
      }
      p.datos = esperado;
    }
    if (conservar.size) {
      plan.subir = plan.subir.filter((p) => !conservar.has(p.ruta));
      plan.conservados.push(...conservar);
    }
  }

  async function verificarFicherosCriticos(plan) {
    const criticos = plan.subir.filter((p) => /(?:0:\/sys\/VERSION|0:\/www\/(?:index\.html|sw\.js))$/.test(p.ruta));
    for (const p of criticos) {
      const r = await RRF.download(p.ruta, { timeoutMs: 15000 });
      if (!r || !r.ok) throw Error(t("msg.otaVerificacionNoDisponible", "no se pudo verificar un archivo crítico después de escribirlo; se cancela la actualización"));
      const leido = await r.text();
      const esperado = new TextDecoder().decode(p.datos || await descomprimir(p.e));
      if (leido !== esperado) throw Error(`verificación fallida tras escribir ${p.ruta}`);
    }
  }

  // Por compatibilidad 404 se trata como ausencia, con la misma limitación de RRF.
  async function leerVersionAnterior(ruta) {
    const r = await RRF.download(ruta, { timeoutMs: 15000 });
    if (r && r.status === 404) return null;
    if (!r || !r.ok) throw Error(t("msg.otaVersionUnreadable", "no se pudo leer sys/VERSION antes de actualizar"));
    return await r.text();
  }

  async function reponerVersion(ruta, anterior) {
    try {
      if (anterior === null) return false;
      await subirFichero(ruta, new TextEncoder().encode(anterior));
      return await leerVersionAnterior(ruta) === anterior;
    } catch { return false; }
  }

  // config.g se relee después de escribirlo: si no llega entero se reintenta y,
  // si sigue mal, se vuelve a poner el de antes. Una placa no arranca sin él.
  async function comprobarConfig(ruta, datos, anterior) {
    const esperado = new TextDecoder().decode(datos);
    const textoAnterior = new TextDecoder().decode(anterior);
    for (let intento = 0; intento < 2; intento++) {
      try {
        await subirFichero(ruta, datos);
        if ((await leerConfigActual(ruta)) === esperado) return;
      } catch (e) {
        if (e?.otaEstado) throw e;
        // La placa puede haber truncado el fichero aun si la subida falló.
      }
    }
    // 18-oct (O2): la copia de seguridad se verifica después de reponerla;
    // un fallo aquí exige recuperación manual y no se puede reiniciar la placa.
    try {
      await subirFichero(ruta, anterior);
      if ((await leerConfigActual(ruta)) !== textoAnterior) {
        throw Error(`lectura distinta tras reponer`);
      }
    } catch {
      throw Error(t("msg.otaInstConfigNoRepuesto", "config.g no se ha podido reponer: NO reinicies. Pide que revisen config.g y su copia antes de restaurar nada."));
    }
    throw Error(t("msg.otaInstConfig", "config.g no se ha escrito bien; se ha repuesto el anterior"));
  }

  function trabajoEnMarcha() {
    try {
      return SM.current === STATES.RUNNING || SM.current === STATES.PAUSED
        || SM.current === STATES.HOMING || SM.current === STATES.SIMULATING
        || SM.current === STATES.TRANSITIONING
        || (typeof AppState !== "undefined" && (AppState.macro?.running || AppState.bord?.active));
    } catch { return true; }
  }

  // Una lectura puntual reduce la ventana de riesgo, pero no bloquea a otros clientes.
  async function exigirMaquinaInactiva() {
    let respuesta = null;
    if (!trabajoEnMarcha()) {
      try { respuesta = await _fetchModel("state.status", 3000); } catch { /* estado desconocido */ }
    }
    if (!respuesta || respuesta.result !== "idle" || trabajoEnMarcha()) {
      const error = Error(t("msg.otaEstadoNoConfirmado", "no se ha podido confirmar que la máquina esté inactiva; se cancela la actualización"));
      error.otaEstado = true;
      throw error;
    }
  }

  // ── Instalar un ZIP ya en memoria ─────────────────────────────────────
  async function instalarBytes(u8, origen) {
    const entradas = leerZip(u8);
    const plan = planificar(entradas);
    const nueva = versionDe(new TextDecoder().decode(await descomprimir(plan.entradaVersion)));
    if (!nueva) throw Error(t("msg.otaInstNoRotechos", "este ZIP no es una versión de RotechOS"));
    await comprobarTransaccionAnterior();
    const actual = window.OTA && window.OTA.readLocalVersion ? await window.OTA.readLocalVersion() : "0";

    // config.g: se fusiona con el de la máquina o, si no se puede, se conserva.
    let fusion = null;
    let configFusionBloqueada = [];
    let configViejo = null;
    if (plan.configNuevo) {
      const nuevoTxt = new TextDecoder().decode(await descomprimir(plan.configNuevo));
      configViejo = await leerConfigActual();
      if (configViejo) {
        const resultado = fusionarConfig(nuevoTxt, configViejo);
        if (resultado && resultado.bloqueada) configFusionBloqueada = resultado.desconocidas;
        else fusion = resultado;
      }
      if (fusion) {
        // La copia, lo primero; config.g, detrás del resto de sys/ (las macros
        // que llama ya están en la SD si la subida se corta después).
        const enc = new TextEncoder();
        const trasSys = plan.subir.filter((p) => p.ruta.startsWith("0:/sys/")).length;
        plan.subir.splice(trasSys, 0,
          { ruta: "0:/sys/config.g", datos: enc.encode(fusion.texto), anterior: enc.encode(configViejo) });
        plan.subir.unshift({ ruta: COPIA_CONFIG, datos: enc.encode(configViejo) });
      } else {
        plan.conservados.push("0:/sys/config.g");
      }
    }

    const aviso = actual !== "0" && nueva < actual
      ? `<p style="color:var(--yellow)"><b>${escHtml(t("dlg.otaInst.older", "Es MÁS ANTIGUA que la instalada ({v}).").replace("{v}", actual))}</b></p>`
      : actual !== "0" && nueva === actual
      ? `<p>${escHtml(t("dlg.otaInst.same", "Es la misma versión que ya tienes; se volverá a escribir."))}</p>`
      : "";
    const ok = await confirmDialog({
      title: t("dlg.otaInst.title", "Instalar RotechOS {v}").replace("{v}", nueva),
      body:
        `<p>${escHtml(t("dlg.otaInst.body", "Se escribirán {n} ficheros en la SD de la máquina ({o}). Tarda unos minutos: no apagues la máquina ni cierres esta página hasta que termine.").replace("{n}", String(plan.subir.length)).replace("{o}", origen))}</p>` +
        aviso +
        `<p>${escHtml(t("dlg.otaInst.keep", "Se conservan tu calibración y tu PIN (config-machine.g), tu red (board.txt y WiFi) y los ajustes de máquina de config.g: drivers y su sentido, mapeo de ejes, finales de carrera, sonda, husillo y nombre."))}</p>` +
        `<p>${escHtml(t("msg.otaConcurrentWarning", "Solo un cliente debe actualizar o modificar archivos durante la instalación. La interfaz no puede bloquear a otros clientes."))}</p>` +
        `<p>${escHtml(t("msg.ota404Warning", "La controladora puede indicar que falta un archivo si falla su lectura. Comprueba la SD y haz una copia de seguridad antes de actualizar."))}</p>` +
        `<p>${escHtml(fusion
          ? t("dlg.otaInst.configFusion", "El resto de config.g se actualiza a la versión nueva; el anterior queda guardado como config.g.antes-ota.")
          : configFusionBloqueada.length
          ? t("dlg.otaInst.configUnknown", "config.g no se actualiza porque contiene {n} ajuste(s) M/G que esta versión no reconoce; se conserva entero para no perderlos.").replace("{n}", String(configFusionBloqueada.length))
          : t("dlg.otaInst.configIntacto", "config.g no se toca: no se ha podido leer el de esta máquina, así que las mejoras de config.g de esta versión no se aplican."))}</p>` +
        `<p>${escHtml(t("dlg.otaInst.after", "Al terminar se reinicia la placa. Después, antes de hacer HOME, mueve cada eje un poco con el JOG y la mano en la seta."))}</p>`,
      confirmText: t("dlg.otaInst.yes", "Instalar"),
      cancelText: t("dlg.otaInst.no", "Cancelar"),
    });
    if (!ok) return false;
    if (trabajoEnMarcha()) {
      toast(t("msg.uploadActive", "No se puede subir archivos con un trabajo activo"), "err");
      return false;
    }
    if (window.rotechosAuth && typeof window.rotechosAuth.tryConnect === "function") {
      const a = await window.rotechosAuth.tryConnect(TARGET_IP, "");
      if (!a || !a.ok) throw Error(t("msg.otaInstAuth", "la máquina no ha aceptado la conexión (PIN)"));
    }

    // Se comprueba después de la confirmación y de la autenticación, pero
    // antes de cualquier rr_upload. M39 es opcional en RRF antiguas.
    const espacio = await comprobarEspacio(plan);
    const manifiestoPrevio = await leerManifiesto();
    await comprobarConflictosMacros(manifiestoPrevio, plan);
    if (trabajoEnMarcha()) throw Error(t("msg.otaInstMovimiento", "la máquina ha cambiado de estado; se cancela la OTA antes de continuar"));
    await comprobarTransaccionAnterior();
    if (!await guardarTransaccion(nueva, "pending", plan)) {
      throw Error(t("msg.otaInstTransaccion", "No se pudo preparar o verificar el control de recuperación. No reinicies ni repitas la actualización; pide que revisen el estado de recuperación."));
    }

    const ui = capa();
    const titulo = t("msg.otaInstTitulo", "Instalando RotechOS {v}").replace("{v}", nueva);
    const quieto = t("msg.otaInstQuieto", "No apagues la máquina ni cierres esta página.");
    if (typeof _pausePollMs === "function") _pausePollMs(plan.subir.length * 4000 + 30000);
    let hechos = 0;
    try {
      for (const p of plan.subir) {
        // VERSION se publica al final, tras escribir y verificar el resto.
        if (p.ruta === "0:/sys/VERSION") continue;
        if (trabajoEnMarcha()) throw Error(t("msg.otaInstMovimiento", "la máquina ha cambiado de estado; se cancela la OTA antes de continuar"));
        ui.poner(titulo, quieto, (hechos / plan.subir.length) * 100, `[${hechos + 1}/${plan.subir.length}] ${p.ruta}`);
        const datos = p.datos || await descomprimir(p.e);
        try {
          if (p.anterior) await comprobarConfig(p.ruta, datos, p.anterior);
          else await subirFichero(p.ruta, datos);
          if (p.ruta === COPIA_CONFIG && await leerConfigActual(COPIA_CONFIG) !== new TextDecoder().decode(datos)) {
            throw Error(t("msg.otaBackupVerify", "No se pudo verificar la copia de config.g. Esta instalación no ha actualizado config.g. No reinicies ni repitas la actualización; pide que revisen el estado de recuperación."));
          }
        } catch (e) {
          // No se marca "complete": la transacción "pending" escrita antes de
          // empezar impide otra OTA hasta revisar el estado de recuperación.
          throw Error(t("msg.otaInstSubida",
            "no se pudo escribir {f} ({e}). La SD puede haber quedado a medias. No reinicies ni repitas la actualización; pide que revisen el estado de recuperación.")
            .replace("{f}", p.ruta).replace("{e}", e && e.message ? e.message : String(e)));
        }
        hechos++;
      }
    } catch (e) {
      ui.error((e.message || String(e)) + t("msg.otaInterruptedReview", " No reinicies ni repitas la OTA; pide que revisen el estado de recuperación."));
      log(`OTA: instalación de ${nueva} interrumpida tras ${hechos}/${plan.subir.length}: ${e.message}`, "err");
      if (typeof startPoll === "function") startPoll();
      return false;
    }
    try {
      await verificarFicherosCriticos({ subir: plan.subir.filter((p) => p.ruta !== "0:/sys/VERSION") });
      if (trabajoEnMarcha()) throw Error(t("msg.otaInstMovimiento", "la máquina ha cambiado de estado; se cancela la OTA antes de continuar"));
    } catch (e) {
      ui.error((e.message || String(e)) + t("msg.otaInterruptedReview", " No reinicies ni repitas la OTA; pide que revisen el estado de recuperación."));
      log(`OTA: verificación final fallida tras ${hechos} ficheros: ${e.message}`, "err");
      if (typeof startPoll === "function") startPoll();
      return false;
    }
    let residuos, manifiestoGuardado;
    try {
      await exigirMaquinaInactiva();
      residuos = await limpiarResiduos(manifiestoPrevio, plan);
      await exigirMaquinaInactiva();
      manifiestoGuardado = await guardarManifiesto(nueva, plan);
    } catch (e) {
      ui.error((e.message || String(e)) + t("msg.otaInterruptedReview", " No reinicies ni repitas la OTA; pide que revisen el estado de recuperación."));
      if (typeof startPoll === "function") startPoll();
      return false;
    }
    const version = plan.subir.find((p) => p.ruta === "0:/sys/VERSION");
    let versionAnterior;
    let versionIntentada = false;
    let cierreIntentado = false;
    try {
      if (trabajoEnMarcha()) throw Error(t("msg.otaInstMovimiento", "la máquina ha cambiado de estado; se cancela la OTA antes de continuar"));
      versionAnterior = await leerVersionAnterior(version.ruta);
      const datosVersion = version.datos || await descomprimir(version.e);
      if (trabajoEnMarcha()) throw Error(t("msg.otaInstMovimiento", "la máquina ha cambiado de estado; se cancela la OTA antes de continuar"));
      versionIntentada = true;
      await subirFichero(version.ruta, datosVersion);
      if (await leerVersionAnterior(version.ruta) !== new TextDecoder().decode(datosVersion)) {
        throw Error(t("msg.otaVersionVerify", "verificación fallida tras escribir sys/VERSION"));
      }
      hechos++;
      if (trabajoEnMarcha()) throw Error(t("msg.otaInstMovimiento", "la máquina ha cambiado de estado; se cancela la OTA antes de continuar"));
      cierreIntentado = true;
      if (!await guardarTransaccion(nueva, "complete", plan)) {
        throw Error(t("msg.otaInstTransaccionIncompleta", "No se pudo confirmar el cierre del control de recuperación. No reinicies ni repitas la OTA; pide que revisen el estado de recuperación."));
      }
    } catch (e) {
      let mensaje = e.message || String(e);
      if (versionIntentada && !cierreIntentado && !e?.otaEstado) {
        const repuesta = await reponerVersion(version.ruta, versionAnterior);
        mensaje += repuesta
          ? t("msg.otaVersionRestored", " Se ha restituido sys/VERSION anterior.")
          : t("msg.otaVersionRestoreFailed", " No se ha podido restituir sys/VERSION.");
      } else if (versionIntentada && e?.otaEstado) {
        mensaje += t("msg.otaVersionEstadoIncierto", " No se ha intentado modificar VERSION tras el cambio de estado; revisa su contenido antes de continuar.");
      }
      mensaje += t("msg.otaInterruptedReview", " No reinicies ni repitas la OTA; pide que revisen el estado de recuperación.");
      ui.error(mensaje);
      log(`OTA: publicación de VERSION interrumpida: ${mensaje}`, "err");
      if (typeof startPoll === "function") startPoll();
      return false;
    }
    ui.poner(titulo, t("msg.otaInstHecho", "Ficheros escritos. Reiniciando la placa…"), 100, "");
    log(`OTA: RotechOS ${nueva} instalado (${hechos} ficheros, ${origen}); conservados: ${plan.conservados.join(", ") || "ninguno en el ZIP"}` +
      (fusion ? `; config.g fusionado (de la máquina: ${fusion.conservadas.concat(fusion.anadidas).join(", ")})` : "") +
      (configFusionBloqueada.length ? `; config.g conservado por ajustes desconocidos: ${configFusionBloqueada.join(" | ")}` : "") +
      `; espacio SD: ${espacio.conocido ? `${fmtBytes(espacio.libre)} libres` : "no confirmado"}` +
      `; residuos web/licencias eliminados: ${residuos}; manifiesto: ${manifiestoGuardado ? "ok" : "no guardado"}`, "ok");
    try {
      const l = STORE.get("ota.log", []);
      l.unshift({
        date: new Date().toLocaleString("es-ES", { day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit" }),
        files: `RotechOS ${nueva} (${hechos} archivos)`,
        ver: nueva,
        size: (u8.length / 1024).toFixed(1) + " KB",
        impact: "reboot-duet",
      });
      if (typeof CFG !== "undefined" && l.length > CFG.otaLogMax) l.length = CFG.otaLogMax;
      STORE.set("ota.log", l);
    } catch { /* el historial es cosmético */ }
    // M999: rotechos.js enseña el aviso de reinicio y su vigilante recarga
    // la página cuando la placa vuelve (con los ficheros nuevos).
    try { await exigirMaquinaInactiva(); } catch (e) {
      ui.error(t("msg.otaReinicioBloqueado", "Los archivos y la versión se han guardado, pero NO se ha enviado el reinicio porque no se confirma que la máquina esté inactiva. Comprueba su estado y la conexión antes de continuar."));
      log("OTA: reinicio no enviado porque no se confirmó el estado inactivo", "warn");
      if (typeof startPoll === "function") startPoll();
      return false;
    }
    let reinicio;
    try { reinicio = await RRF.gcode("M999"); } catch (e) { reinicio = null; }
    if (!reinicio || (reinicio.err !== undefined && reinicio.err !== 0)) {
      ui.error(t("msg.otaInstReinicio", "Los archivos se han escrito, pero no se pudo confirmar el reinicio de la placa. No apagues ni repitas hasta comprobar la conexión."));
      log("OTA: archivos escritos, reinicio M999 no confirmado", "warn");
      if (typeof startPoll === "function") startPoll();
      return false;
    }
    ui.quitar();
    return true;
  }

  async function conGuarda(fn) {
    if (_ocupado) {
      toast(t("msg.otaInProgress", "Comprobación en curso…"), "warn");
      return false;
    }
    _ocupado = true;
    try {
      return await fn();
    } catch (e) {
      toast(t("msg.otaInstFallo", "La instalación no se ha completado") + ": " + (e.message || e), "err");
      LOG.warn("OTA: instalación fallida", e);
      return false;
    } finally {
      _ocupado = false;
    }
  }

  // Desde el aviso: descarga el paquete publicado y comprueba su huella.
  function desdeManifest(manifest) {
    return conGuarda(async () => {
      const url = manifest && manifest.paquete_url;
      const sha = String((manifest && manifest.paquete_sha256) || "").toLowerCase();
      if (!PAQUETE_URL_OK.test(url || "") || !/^[0-9a-f]{64}$/.test(sha))
        throw Error(t("msg.otaInstSinPaquete", "esta versión no trae paquete instalable; descárgala de GitHub"));
      const ui = capa();
      ui.poner(t("msg.otaInstBajando", "Descargando RotechOS {v}").replace("{v}", manifest.rotechos_version), "", 5, "");
      let u8;
      try {
        const r = await fetch(url, { cache: "no-store", signal: AbortSignal.timeout(DESCARGA_TIMEOUT_MS) });
        if (!r.ok) throw Error(`HTTP ${r.status}`);
        const largo = Number(r.headers.get("content-length"));
        if (Number.isFinite(largo) && largo > MAX_ZIP_COMPRIMIDO)
          throw Error(t("msg.otaInstZipGrande", "el ZIP es demasiado grande"));
        u8 = new Uint8Array(await r.arrayBuffer());
      } catch (e) {
        ui.quitar();
        throw Error(t("msg.otaInstSinRed",
          "no se pudo descargar ({e}). Si este dispositivo no tiene internet, descarga el ZIP desde otro y usa «Instalar desde un ZIP» en CONFIGURACIÓN → ACTUALIZAR (OTA)")
          .replace("{e}", e.message || e));
      }
      ui.quitar();
      if (sha256(u8) !== sha)
        throw Error(t("msg.otaInstSha", "la descarga no coincide con la publicada; inténtalo de nuevo en unos minutos"));
      return instalarBytes(u8, t("msg.otaInstOrigenGithub", "descargada de GitHub"));
    });
  }

  // Desde un ZIP elegido en el dispositivo.
  function desdeFichero(file) {
    return conGuarda(async () => {
      if (!file) return false;
      if (Number(file.size) > MAX_ZIP_COMPRIMIDO)
        throw Error(t("msg.otaInstZipGrande", "el ZIP es demasiado grande"));
      const u8 = new Uint8Array(await file.arrayBuffer());
      return instalarBytes(u8, file.name);
    });
  }

  window.OTAInstall = { desdeManifest, desdeFichero, _leerZip: leerZip, _planificar: planificar, _fusionarConfig: fusionarConfig, _claveDe: claveDe, _comprobarEspacio: comprobarEspacio, _rutasGestionadas: rutasGestionadas, _sha256: sha256, _crc32: crc32, _descomprimir: descomprimir,
    _limites: { zipComprimido: MAX_ZIP_COMPRIMIDO, entradas: MAX_ENTRADAS_ZIP, expandido: MAX_ZIP_EXPANDIDO } };
})();
