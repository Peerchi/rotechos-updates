/* ---
 * rotechos-ui-states.js — Sistema de estados de la UI (UI-7, t_18afd7a2).
 *
 * QUÉ HACE: helpers para gestionar los 4 estados visuales definidos en
 * rotechos.css (.ui-state-empty / .ui-state-loading / .ui-state-error +
 * .ui-spinner) + el helper .ui-state-disabled-hint (NO es una clase CSS;
 * es esto, que añade title= automático en runtime cuando un botón pasa
 * a disabled, explicando POR QUÉ no se puede pulsar).
 *
 * REGLAS DEL BRIEFING:
 * - Spinner < 300 ms = no mostrar. > 1 s = siempre algo visible.
 *   El helper `setLoadingState(el, on, msg)` mide tiempo y solo activa
 *   `.ui-spinner-show` si el loading dura > 300 ms.
 * - Loading NO puede sustituir a empty sin reset explícito.
 *   El helper quita `.ui-state-loading` y `.ui-state-empty` al mismo
 *   tiempo. Quien llama debe llamar primero `setEmptyState(el)` o el
 *   `setLoadingState(el, false)` no resetea el empty previo.
 * - Error dice QUÉ hacer (no solo QUÉ pasó).
 *   `setErrorState(el, msg, actionMsg)` pone el mensaje principal y la
 *   acción sugerida como segundo <span class="ui-state-error-action">.
 *
 * ADEMÁS:
 * - `wireDisabledHints()` registra un MutationObserver que mira los
 *   botones del documento. Cuando un botón pasa a `disabled`, le pone
 *   `title=` automático si el atributo `data-disabled-hint` está
 *   presente. Si no, usa `aria-label` o un fallback razonable. Asi
 *   cubrimos los 18 botones del inventario §4.2 sin tocar el HTML uno
 *   a uno, y el operario ve POR QUÉ el botón está gris.
 *
 * PUBLIC API (window.*):
 *   - setEmptyState(el)                  aplica .ui-state-empty
 *   - setLoadingState(el, on, msg)       togglear .ui-state-loading + spinner con timeout 300 ms
 *   - setErrorState(el, msg, actionMsg)  aplica .ui-state-error con acción sugerida
 *   - clearState(el)                     quita todas las .ui-state-* y .ui-spinner-show
 *   - wireDisabledHints()                inicializa el observer (llamar una vez en DOMContentLoaded)
 *
 * NOTA OPERATIVA: este módulo NO depende de SM/STATES/etc. Es DOM puro,
 * asi que se puede cargar en cualquier punto del orden de scripts.
 * --- */
'use strict';

(function () {
  // Mapeo de tiempos de carga por zona. Sirve para que el caller no
  // tenga que recordar el número. Por defecto 300 ms (regla del briefing).
  const SPINNER_DELAY_MS = 300;

  // ---
  // Helpers internos
  // ---

  // Quita todas las clases de estado y el spinner. Se usa antes de aplicar
  // cualquier estado nuevo para garantizar el "reset explícito" del briefing.
  function _clearClasses(el) {
    if (!el || !el.classList) return;
    el.classList.remove('ui-state-empty', 'ui-state-loading', 'ui-state-error', 'ui-spinner-show');
    // Si tenía un spinner hijo, lo desactivamos también
    const sp = el.querySelector(':scope > .ui-spinner');
    if (sp) sp.classList.remove('ui-spinner-show');
    // Y el contenedor de acción de error
    const act = el.querySelector(':scope > .ui-state-error-action');
    if (act) act.remove();
  }

  // ---
  // API pública: setEmptyState
  // ---
  function setEmptyState(el) {
    if (!el) return;
    _clearClasses(el);
    el.classList.add('ui-state-empty');
  }

  // ---
  // API pública: setLoadingState
  // on=true activa el estado; on=false lo apaga y resetea.
  // Si msg está presente y el contenedor estaba vacío, lo rellena.
  // El spinner aparece SOLO si el loading dura más de 300 ms.
  // ---
  const _loadingTimers = new WeakMap();

  function setLoadingState(el, on, msg) {
    if (!el) return;
    if (on) {
      _clearClasses(el);
      el.classList.add('ui-state-loading');
      // Asegurar que hay un .ui-spinner hijo (lo crea si falta)
      let sp = el.querySelector(':scope > .ui-spinner');
      if (!sp) {
        sp = document.createElement('span');
        sp.className = 'ui-spinner';
        sp.setAttribute('aria-hidden', 'true');
        el.insertBefore(sp, el.firstChild);
      }
      // Mensaje: si ya tenía texto, lo conservamos (modo append). Si no,
      // añadimos el msg al lado del spinner.
      if (msg && !el.dataset._uiLoadingMsg) {
        el.dataset._uiLoadingMsg = msg;
        // Buscar/crear un span de texto hermano del spinner
        let txt = el.querySelector(':scope > .ui-state-loading-text');
        if (!txt) {
          txt = document.createElement('span');
          txt.className = 'ui-state-loading-text';
          el.appendChild(txt);
        }
        txt.textContent = msg;
      }
      // Programar la aparición del spinner tras 300 ms
      if (_loadingTimers.has(el)) clearTimeout(_loadingTimers.get(el));
      const t = setTimeout(() => {
        // Solo activar si sigue en loading (puede haberse apagado antes)
        if (el.classList.contains('ui-state-loading')) {
          sp.classList.add('ui-spinner-show');
        }
      }, SPINNER_DELAY_MS);
      _loadingTimers.set(el, t);
    } else {
      // Apagar loading + reset
      if (_loadingTimers.has(el)) {
        clearTimeout(_loadingTimers.get(el));
        _loadingTimers.delete(el);
      }
      _clearClasses(el);
      delete el.dataset._uiLoadingMsg;
      const txt = el.querySelector(':scope > .ui-state-loading-text');
      if (txt) txt.remove();
    }
  }

  // ---
  // API pública: setErrorState
  // msg = qué pasó. actionMsg = qué hacer (opcional, pero recomendado
  // por regla del briefing: el error dice QUÉ HACER).
  // ---
  function setErrorState(el, msg, actionMsg) {
    if (!el) return;
    _clearClasses(el);
    el.classList.add('ui-state-error');
    // Texto principal (sobrescribe el contenido pero conserva ::before ⚠)
    el.textContent = msg || '';
    // Acción sugerida (span hijo, formato italico)
    if (actionMsg) {
      const act = document.createElement('span');
      act.className = 'ui-state-error-action';
      act.textContent = actionMsg;
      el.appendChild(act);
    }
  }

  // ---
  // API pública: clearState
  // Quita cualquier estado aplicado. Útil antes de repintar.
  // ---
  function clearState(el) {
    if (!el) return;
    if (_loadingTimers.has(el)) {
      clearTimeout(_loadingTimers.get(el));
      _loadingTimers.delete(el);
    }
    _clearClasses(el);
    delete el.dataset._uiLoadingMsg;
    const txt = el.querySelector(':scope > .ui-state-loading-text');
    if (txt) txt.remove();
  }

  // ---
  // Helper: wireDisabledHints
  // Observa el DOM y cuando un botón pasa a `disabled`, le pone title=
  // automático si tiene `data-disabled-hint` (o `aria-label`).
  // Cubre los 18 botones del inventario §4.2 sin tocar el HTML uno a uno.
  // ---
  const _hintObserved = new WeakSet();

  function _setDisabledHint(btn) {
    if (!btn || _hintObserved.has(btn)) return;
    if (!btn.disabled) return;
    // Prioridad: data-disabled-hint > aria-label > "Acción no disponible ahora"
    let hint = btn.getAttribute('data-disabled-hint');
    if (!hint) hint = btn.getAttribute('aria-label');
    if (!hint) hint = 'Acción no disponible ahora — consulta el panel de estado.';
    // Solo poner si no tenía ya un title distinto (no pisar hints manuales)
    if (!btn.hasAttribute('title')) {
      btn.setAttribute('title', hint);
    }
    _hintObserved.add(btn);
  }

  function wireDisabledHints(root) {
    const target = root || document.body;
    if (!target) return;
    // Inicial: todos los disabled actuales del subtree
    target.querySelectorAll('button[disabled], input[disabled], select[disabled]').forEach(_setDisabledHint);
    // Observer para los nuevos que se deshabiliten en runtime
    if (typeof MutationObserver !== 'undefined') {
      const obs = new MutationObserver((mutations) => {
        for (const m of mutations) {
          if (m.type === 'attributes' && m.attributeName === 'disabled') {
            _setDisabledHint(m.target);
          } else if (m.type === 'childList') {
            m.addedNodes.forEach((n) => {
              if (n.nodeType !== 1) return;
              if (n.matches && (n.matches('button[disabled], input[disabled], select[disabled]'))) {
                _setDisabledHint(n);
              }
              // Y los hijos del nuevo nodo
              if (n.querySelectorAll) {
                n.querySelectorAll('button[disabled], input[disabled], select[disabled]').forEach(_setDisabledHint);
              }
            });
          }
        }
      });
      obs.observe(target, {
        attributes: true,
        attributeFilter: ['disabled'],
        childList: true,
        subtree: true,
      });
    }
  }

  // ---
  // Export
  // ---
  window.setEmptyState = setEmptyState;
  window.setLoadingState = setLoadingState;
  window.setErrorState = setErrorState;
  window.clearState = clearState;
  window.wireDisabledHints = wireDisabledHints;
})();
