/* ---
 * rotechos-ui-states.js — title automatico en los botones deshabilitados
 * (UI-7, t_18afd7a2).
 *
 * `wireDisabledHints()` registra un MutationObserver que mira los botones
 * del documento. Cuando un boton pasa a `disabled`, le pone `title=`
 * automatico si el atributo `data-disabled-hint` esta presente. Si no, usa
 * `aria-label` o un fallback razonable. Asi cubre los 18 botones del
 * inventario §4.2 sin tocar el HTML uno a uno, y el operario ve POR QUE el
 * boton esta gris.
 *
 * PUBLIC API (window.*):
 *   - wireDisabledHints()   inicializa el observer (una vez, en DOMContentLoaded)
 *
 * Es DOM puro (no depende de SM/STATES), asi que se puede cargar en
 * cualquier punto del orden de scripts.
 * --- */
'use strict';

(function () {
  // setEmptyState / setLoadingState / setErrorState / clearState vivian aqui
  // y no los llamaba nadie (ni la interfaz ni los tests): retirados el
  // 8-oct-2026. Las clases .ui-state-* de rotechos.css siguen en uso desde el HTML.

  // ---
  // Helper: wireDisabledHints
  // Observa el DOM y cuando un botón pasa a `disabled`, le pone title=
  // automático si tiene `data-disabled-hint` (o `aria-label`).
  // Cubre los 18 botones del inventario §4.2 sin tocar el HTML uno a uno.
  // ---
  const _hintObserved = new WeakSet();

  function _setDisabledHint(btn) {
    if (!btn || _hintObserved.has(btn)) return;
    if (!btn.disabled) return;
    // Prioridad: data-disabled-hint > aria-label > "Acción no disponible ahora"
    let hint = btn.getAttribute('data-disabled-hint');
    if (!hint) hint = btn.getAttribute('aria-label');
    if (!hint) hint = 'Acción no disponible ahora — consulta el panel de estado.';
    // Solo poner si no tenía ya un title distinto (no pisar hints manuales)
    if (!btn.hasAttribute('title')) {
      btn.setAttribute('title', hint);
    }
    _hintObserved.add(btn);
  }

  function wireDisabledHints(root) {
    const target = root || document.body;
    if (!target) return;
    // Inicial: todos los disabled actuales del subtree
    target.querySelectorAll('button[disabled], input[disabled], select[disabled]').forEach(_setDisabledHint);
    // Observer para los nuevos que se deshabiliten en runtime
    if (typeof MutationObserver !== 'undefined') {
      const obs = new MutationObserver((mutations) => {
        for (const m of mutations) {
          if (m.type === 'attributes' && m.attributeName === 'disabled') {
            _setDisabledHint(m.target);
          } else if (m.type === 'childList') {
            m.addedNodes.forEach((n) => {
              if (n.nodeType !== 1) return;
              if (n.matches && (n.matches('button[disabled], input[disabled], select[disabled]'))) {
                _setDisabledHint(n);
              }
              // Y los hijos del nuevo nodo
              if (n.querySelectorAll) {
                n.querySelectorAll('button[disabled], input[disabled], select[disabled]').forEach(_setDisabledHint);
              }
            });
          }
        }
      });
      obs.observe(target, {
        attributes: true,
        attributeFilter: ['disabled'],
        childList: true,
        subtree: true,
      });
    }
  }

  // ---
  // Export
  // ---
  window.wireDisabledHints = wireDisabledHints;
})();
