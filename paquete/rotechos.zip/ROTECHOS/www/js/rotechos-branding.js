/*
 * rotechos-branding.js — identidad visual opcional por empresa.
 *
 * La identidad vive en el navegador (no en config.g ni en el firmware): así
 * no puede alterar parámetros de máquina y sobrevive a una actualización OTA
 * de la interfaz. Exportar/importar permite replicarla en otras pantallas.
 *
 * Seguridad: todo dato (formulario, almacenamiento o rotechos-identidad.json)
 * pasa por normalise() antes de usarse. Los textos solo se escriben con
 * textContent, el color solo si es #rrggbb y el logo solo si es un data URL
 * PNG/JPEG/WebP de 512 KB como mucho cuyos primeros bytes coinciden con su
 * tipo (un SVG renombrado a .png se rechaza). Nada se inyecta como HTML/CSS.
 * «RotechOS» no se puede quitar: con nombre de empresa, sigue en el subtítulo,
 * en la cabecera del pendant, en la marca de agua y en el título.
 */
(function () {
  'use strict';

  const STORE_KEY = 'ui.branding';
  const FALLBACK_KEY = 'rotechos-ui-branding';
  const MAX_LOGO_BYTES = 512 * 1024;
  const MAX_LOGO_B64 = Math.ceil(MAX_LOGO_BYTES / 3) * 4;
  const ALLOWED_TYPES = new Set(['image/png', 'image/jpeg', 'image/webp']);
  const DEFAULTS = Object.freeze({
    companyName: '',
    tagline: '',
    logoDataUrl: '',
    accent: '#0d9448',
    watermark: false,
  });

  const $ = id => document.getElementById(id);

  function cleanText(value, max) {
    // Fuera control y formato (Cc/Cf): incluye los de dirección (U+202E...) y
    // los de ancho cero, que podrían dar la vuelta o esconder «RotechOS».
    return String(value == null ? '' : value)
      .replace(/[\p{Cc}\p{Cf}\u2028\u2029]/gu, ' ')
      .replace(/\s+/g, ' ').trim().slice(0, max);
  }

  function validAccent(value) {
    return /^#[0-9a-f]{6}$/i.test(value) ? value.toLowerCase() : DEFAULTS.accent;
  }

  // Firma de los primeros bytes de cada formato admitido.
  function magicMatches(type, bytes) {
    const b = i => bytes.charCodeAt(i);
    if (type === 'png') return bytes.length >= 8 && b(0) === 0x89 && bytes.slice(1, 4) === 'PNG';
    if (type === 'jpeg') return bytes.length >= 3 && b(0) === 0xff && b(1) === 0xd8 && b(2) === 0xff;
    if (type === 'webp') return bytes.length >= 12 && bytes.slice(0, 4) === 'RIFF' && bytes.slice(8, 12) === 'WEBP';
    return false;
  }

  function validLogo(value) {
    if (typeof value !== 'string') return '';
    const m = /^data:image\/(png|jpeg|webp);base64,([A-Za-z0-9+/]+={0,2})$/.exec(value);
    if (!m || m[2].length > MAX_LOGO_B64) return '';
    try {
      const bytes = atob(m[2]);
      return bytes.length <= MAX_LOGO_BYTES && magicMatches(m[1], bytes.slice(0, 12)) ? value : '';
    } catch (_) {
      return '';
    }
  }

  // Comprobación completa: que el navegador lo decodifique como imagen de
  // verdad (la firma sola deja pasar una cabecera PNG sin imagen detrás).
  function decodesAsImage(dataUrl) {
    if (!dataUrl) return Promise.resolve(false);
    const img = new Image();
    img.src = dataUrl;
    return img.decode().then(() => img.naturalWidth > 0 && img.naturalHeight > 0, () => false);
  }

  function normalise(raw) {
    const value = raw && typeof raw === 'object' && !Array.isArray(raw) ? raw : {};
    return {
      companyName: cleanText(value.companyName, 32),
      tagline: cleanText(value.tagline, 48),
      logoDataUrl: validLogo(value.logoDataUrl),
      accent: validAccent(String(value.accent || DEFAULTS.accent)),
      watermark: value.watermark === true,
    };
  }

  // Subtítulo con nombre de empresa: RotechOS va delante para que la elipsis
  // de la cabecera nunca lo recorte.
  function taglineFor(data) {
    return `RotechOS · ${data.tagline || 'CNC CONTROLLER'}`;
  }

  function read() {
    try {
      const stored = window.STORE?.get(STORE_KEY, null);
      if (stored) return normalise(stored);
    } catch (_) { /* fallback below */ }
    try {
      const raw = localStorage.getItem(FALLBACK_KEY);
      return raw ? normalise(JSON.parse(raw)) : { ...DEFAULTS };
    } catch (_) {
      return { ...DEFAULTS };
    }
  }

  function write(value) {
    const data = normalise(value);
    try {
      if (window.STORE?.set(STORE_KEY, data)) return true;
    } catch (_) { /* fallback below */ }
    try {
      localStorage.setItem(FALLBACK_KEY, JSON.stringify(data));
      return true;
    } catch (_) {
      return false;
    }
  }

  // toggleAttribute y no .hidden: el logo base es un <svg>, y en SVGElement
  // la propiedad .hidden no existe (no lo ocultaría).
  function setVisible(element, visible) {
    if (!element) return;
    element.toggleAttribute('hidden', !visible);
    element.setAttribute('aria-hidden', String(!visible));
  }

  function setLogo(img, data) {
    if (!img) return;
    if (data.logoDataUrl) {
      img.src = data.logoDataUrl;
      img.alt = data.companyName ? `Logo de ${data.companyName}` : 'Logo de empresa';
    } else {
      img.removeAttribute('src');
    }
    setVisible(img, Boolean(data.logoDataUrl));
  }

  // Con la identidad por defecto los textos de marca son los del HTML y los
  // traduce rotechos-i18n.js; solo se escriben cuando hay nombre de empresa.
  let wasCustom = false;
  const BRAND_TEXT_IDS = ['brandCompanyName', 'brandTagline', 'pendantBrandName'];

  // Con nombre de empresa estos nodos dejan de ser de rotechos-i18n.js (si no,
  // cualquier I18N.add() tardío volvería a escribir «RotechOS» encima).
  function setI18nOwnership(custom) {
    BRAND_TEXT_IDS.forEach(id => {
      const el = $(id);
      if (!el) return;
      if (custom && el.hasAttribute('data-i18n')) {
        el.dataset.i18nBrand = el.getAttribute('data-i18n');
        el.removeAttribute('data-i18n');
      } else if (!custom && el.dataset.i18nBrand) {
        el.setAttribute('data-i18n', el.dataset.i18nBrand);
        delete el.dataset.i18nBrand;
      }
    });
  }
  function apply(raw) {
    const data = normalise(raw);
    const custom = Boolean(data.companyName);
    document.documentElement.style.setProperty('--brand-accent', data.accent);
    document.documentElement.dataset.companyBrand = custom ? 'custom' : 'default';

    setI18nOwnership(custom);
    if (custom) {
      if ($('brandCompanyName')) $('brandCompanyName').textContent = data.companyName;
      if ($('brandTagline')) $('brandTagline').textContent = taglineFor(data);
      if ($('pendantBrandName')) $('pendantBrandName').textContent = `RotechOS Pendant · ${data.companyName}`;
      document.title = `${data.companyName} · RotechOS`;
    } else if (wasCustom) {
      if ($('brandCompanyName')) $('brandCompanyName').textContent = 'RotechOS';
      if ($('brandTagline')) $('brandTagline').textContent = 'CNC CONTROLLER';
      if ($('pendantBrandName')) $('pendantBrandName').textContent = 'RotechOS Pendant';
      document.title = 'RotechOS · Panel CNC v2026.11';
      try { window.I18N?.applyI18n?.(); } catch (_) { /* textos ya en español */ }
    }
    wasCustom = custom;

    setLogo($('brandLogoImg'), data);
    setVisible($('brandLogoRotech'), !data.logoDataUrl);
    setLogo($('pendantBrandLogo'), data);
    setVisible($('pendantBrandLogoRotech'), !data.logoDataUrl);

    const watermark = $('brandingWatermark');
    if (watermark) {
      watermark.classList.toggle('show', Boolean(data.watermark && (custom || data.logoDataUrl)));
      if ($('brandingWatermarkName')) {
        $('brandingWatermarkName').textContent = custom ? `RotechOS · ${data.companyName}` : 'RotechOS';
      }
      setLogo($('brandingWatermarkLogo'), data);
    }
    return data;
  }

  function setStatus(message, error) {
    const status = $('brandingStatus');
    if (!status) return;
    status.textContent = message;
    status.dataset.error = error ? 'true' : 'false';
  }

  function updatePreview() {
    const name = cleanText($('brandingCompanyName')?.value, 32);
    const tagline = cleanText($('brandingTagline')?.value, 48);
    if ($('brandingPreviewName')) $('brandingPreviewName').textContent = name || 'RotechOS';
    if ($('brandingPreviewTagline')) {
      $('brandingPreviewTagline').textContent = name ? taglineFor({ tagline }) : 'CNC CONTROLLER';
    }
  }

  function setDraftLogo(logoDataUrl) {
    const modal = $('brandingModal');
    if (modal) modal._draftLogo = logoDataUrl;
    const preview = $('brandingLogoPreview');
    if (preview) {
      if (logoDataUrl) preview.src = logoDataUrl;
      else preview.removeAttribute('src');
      setVisible(preview, Boolean(logoDataUrl));
    }
  }

  // Rellena el formulario (borrador): no guarda ni aplica nada.
  function fillForm(data) {
    $('brandingCompanyName').value = data.companyName;
    $('brandingTagline').value = data.tagline;
    $('brandingAccent').value = data.accent;
    $('brandingWatermarkToggle').checked = data.watermark;
    setDraftLogo(data.logoDataUrl);
    updatePreview();
  }

  function showModal() {
    const modal = $('brandingModal');
    if (!modal) return;
    fillForm(read());
    setStatus('');
    modal.classList.add('show');
    modal.setAttribute('aria-hidden', 'false');
    $('brandingCompanyName')?.focus();
  }

  function hideModal() {
    const modal = $('brandingModal');
    if (!modal) return;
    modal.classList.remove('show');
    modal.setAttribute('aria-hidden', 'true');
    setStatus('');
  }

  function currentDraft() {
    const modal = $('brandingModal');
    return {
      companyName: $('brandingCompanyName')?.value || '',
      tagline: $('brandingTagline')?.value || '',
      accent: $('brandingAccent')?.value || DEFAULTS.accent,
      watermark: Boolean($('brandingWatermarkToggle')?.checked),
      logoDataUrl: modal?._draftLogo ?? read().logoDataUrl,
    };
  }

  function save() {
    const data = normalise(currentDraft());
    if (!write(data)) {
      setStatus('No se pudo guardar la identidad en este navegador.', true);
      return;
    }
    apply(data);
    hideModal();
    window.showToast?.('Identidad visual guardada', 'ok');
  }

  async function reset() {
    const ask = window.confirmDialog
      ? window.confirmDialog('Restaurar RotechOS', 'Se quitan el nombre, el logo y el color de tu empresa de esta pantalla.')
      : Promise.resolve(window.confirm('¿Restaurar la identidad visual de RotechOS?'));
    if (!(await ask)) return;
    if (!write(DEFAULTS)) {
      setStatus('No se pudo restaurar la identidad.', true);
      return;
    }
    apply(DEFAULTS);
    fillForm(DEFAULTS);
    setStatus('Identidad RotechOS restaurada.', false);
  }

  function handleLogo(file) {
    if (!file) return;
    if (!ALLOWED_TYPES.has(file.type)) {
      setStatus('Usa un PNG, JPG o WebP. SVG no está permitido por seguridad.', true);
      return;
    }
    if (file.size > MAX_LOGO_BYTES) {
      setStatus('El logo debe ocupar 512 KB o menos.', true);
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      const logoDataUrl = validLogo(reader.result);
      decodesAsImage(logoDataUrl).then(ok => {
        if (!ok) {
          setStatus('El archivo no es un PNG, JPG o WebP válido.', true);
          return;
        }
        setDraftLogo(logoDataUrl);
        setStatus('Logo cargado. Pulsa Guardar para aplicarlo.', false);
      });
    };
    reader.onerror = () => setStatus('No se pudo leer el archivo.', true);
    reader.readAsDataURL(file);
  }

  function exportIdentity() {
    const blob = new Blob([JSON.stringify(read(), null, 2)], { type: 'application/json' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'rotechos-identidad.json';
    link.click();
    setTimeout(() => URL.revokeObjectURL(link.href), 1000);
    setStatus('Identidad exportada. Puedes importarla en otra pantalla.', false);
  }

  // Un logo de 512 KB en base64 más los textos cabe de sobra en 1 MB.
  const MAX_IMPORT_BYTES = 1024 * 1024;
  function importIdentity(file) {
    if (!file) return;
    if (file.size > MAX_IMPORT_BYTES) {
      setStatus('El archivo es demasiado grande para ser una identidad.', true);
      return;
    }
    const reader = new FileReader();
    reader.onload = async () => {
      try {
        const raw = JSON.parse(reader.result);
        if (!raw || typeof raw !== 'object' || Array.isArray(raw)) throw new Error('formato');
        const data = normalise(raw);
        if (data.logoDataUrl && !(await decodesAsImage(data.logoDataUrl))) data.logoDataUrl = '';
        fillForm(data);
        const logoPerdido = typeof raw.logoDataUrl === 'string' && raw.logoDataUrl && !data.logoDataUrl;
        setStatus(logoPerdido
          ? 'Identidad importada sin el logo (no es un PNG, JPG o WebP válido). Pulsa Guardar para aplicarla.'
          : 'Identidad importada. Pulsa Guardar para aplicarla.', logoPerdido);
      } catch (_) {
        setStatus('El archivo no contiene una identidad válida.', true);
      }
    };
    reader.onerror = () => setStatus('No se pudo leer el archivo.', true);
    reader.readAsText(file);
  }

  function init() {
    apply(read());
    // Un logo guardado que el navegador no sabe pintar no deja un hueco: se
    // vuelve al logo de RotechOS.
    ['brandLogoImg', 'pendantBrandLogo', 'brandingWatermarkLogo'].forEach(id => {
      $(id)?.addEventListener('error', () => {
        setVisible($(id), false);
        setVisible($(id === 'pendantBrandLogo' ? 'pendantBrandLogoRotech' : 'brandLogoRotech'), true);
      });
    });
    const modal = $('brandingModal');
    if (!modal) return;
    $('btnBranding')?.addEventListener('click', showModal);
    $('btnBrandingClose')?.addEventListener('click', hideModal);
    $('btnBrandingCancel')?.addEventListener('click', hideModal);
    $('btnBrandingSave')?.addEventListener('click', save);
    $('btnBrandingReset')?.addEventListener('click', reset);
    $('btnBrandingExport')?.addEventListener('click', exportIdentity);
    $('brandingLogoInput')?.addEventListener('change', e => { handleLogo(e.target.files?.[0]); e.target.value = ''; });
    $('brandingImportInput')?.addEventListener('change', e => { importIdentity(e.target.files?.[0]); e.target.value = ''; });
    $('brandingCompanyName')?.addEventListener('input', updatePreview);
    $('brandingTagline')?.addEventListener('input', updatePreview);
    $('btnBrandingLogoRemove')?.addEventListener('click', () => {
      setDraftLogo('');
      setStatus('Logo quitado del borrador. Pulsa Guardar para aplicarlo.', false);
    });
    modal.addEventListener('click', e => { if (e.target === modal) hideModal(); });
    document.addEventListener('keydown', e => {
      if (e.key === 'Escape' && modal.classList.contains('show')) hideModal();
    });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init, { once: true });
  else init();

  window.ROTECHOS_BRANDING = {
    read, apply, normalise, validLogo,
    reset: () => { write(DEFAULTS); apply(DEFAULTS); },
  };
})();
