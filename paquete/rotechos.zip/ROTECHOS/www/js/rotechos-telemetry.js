// rotechos-telemetry.js — fachada EAGER con la telemetría del cockpit.
// Cuatro funciones que pinta el poll en cada ciclo. Publica `window.TELEMETRY`.
// El estado compartido (_ovFeedTs, _ovSpindleTs, _spindleRunning y familia)
// se queda en rotechos.js: lo lee y escribe rotechos-jog.js (defer posterior),
// y declararlo aquí crearía una ventana TDZ en el arranque del núcleo.
window.TELEMETRY = {
  /** Pinta el pill MCU en el visor de telemetría (#telemMcu / #mcuPill). */
  update(data) {
    if (!data) return;
    let rawBoards = data.boards;
    rawBoards && rawBoards.result !== void 0 && (rawBoards = rawBoards.result);
    const boards = Array.isArray(rawBoards)
        ? rawBoards
        : rawBoards
          ? [rawBoards]
          : [],
      board =
        boards.find(
          (b) =>
            b &&
            (b.canAddress === 0 || b.canAddress === null || !(`canAddress` in b)),
        ) ||
        boards[0] ||
        null,
      mcuEl = $(`telemMcu`),
      mcuPill = $(`mcuPill`);
    if (mcuEl && mcuPill) {
      let temp = null;
      if (typeof data._mcuTempDirect === `number`) temp = data._mcuTempDirect;
      else if (board?.mcuTemp?.current != null) temp = board.mcuTemp.current;
      else if (data.mcu?.temperature != null) temp = data.mcu.temperature;
      else if (typeof data.mcuTemp === `number`) temp = data.mcuTemp;
      else if (data.sensors?.analogs?.[0]?.lastReading != null)
        temp = data.sensors.analogs[0].lastReading;
      // 3-oct: aquí había `else if (!SM.connected) temp = 38.5`: sin conexión pintaba 38.5° en
      // verde, una lectura inventada. Sin dato, «—».
      if (temp != null) {
        const tNum = parseFloat(temp);
        ((mcuEl.textContent = `${tNum.toFixed(1)}°`),
          (mcuPill.className = `telem-pill${tNum > 60 ? ` err` : tNum > 45 ? ` warn` : ` ok`}`));
      } else ((mcuEl.textContent = `—`), (mcuPill.className = `telem-pill`));
    }
  },

  /** Actualiza el DRO (X/Y/Z/A WCS y MCS), la posición en VIZ y el RPM del spindle. */
  _uiUpdateDRO(data) {
    const isConnected = typeof SM !== 'undefined' && SM.connected;
    const _rawXyz = data.coords?.xyz ?? [0, 0, 0],
      _rawMcs = data.coords?.machine ?? _rawXyz,
      xyz = _rawXyz;
    // El DRO (cockpit + pendant + pendant2) lo pinta la capa de suavizado a 60fps; aquí
    // solo fijamos el OBJETIVO con las coords reales de este poll. Coste de placa: 0.
    DRO.setTarget(_rawXyz, _rawMcs, isConnected);
    SM.zPos = xyz[2] ?? 0;
    const _homingAxes = data.move?.axes;
    const _hasHomingStatus = Array.isArray(_homingAxes) && _homingAxes.length > 0
      && _homingAxes.every((a) => typeof a.homed === `boolean`);
    const _ah = _hasHomingStatus && _homingAxes.every((a) => a.homed);
    AppState.limits.allHomed = _ah;
    if (_ah) AppState.sys.postEmergencyReset = false; // Homing completo — desbloquear
    // Cachea `move.axes[i].min/max` para que los readouts derivados del
    // recorrido máximo reflejen el estado real de soft limits en RRF.
    if (Array.isArray(_homingAxes)) {
      if (!AppState.axes) AppState.axes = [];
      _homingAxes.forEach((a, i) => {
        if (!a) return;
        AppState.axes[i] = AppState.axes[i] || {};
        if (typeof a.min === `number`) AppState.axes[i].min = a.min;
        if (typeof a.max === `number`) AppState.axes[i].max = a.max;
      });
    }
    // El aviso aparece solo con una confirmación real de ejes sin HOME.
    $(`homedWarning`)?.classList.toggle("hidden", !_hasHomingStatus || _ah);
    // Refresca el banner HOME de SONDA/SAC y el readout derivado tras un G28.
    if (typeof window.renderSondaBannerHome === `function`) window.renderSondaBannerHome();
    if (typeof window.renderSondaRecorridoMax === `function`) window.renderSondaRecorridoMax();
    const vizFilePos = data?.jobModel?.filePosition ?? data?.filePosition;
    let vizStale = !1;
    if (SM.current === STATES.RUNNING && typeof vizFilePos === `number` && SM.lastVizFilePos != null) {
      if (SM.lastVizFilePos - vizFilePos > 50) vizStale = !0;
    }
    if (!vizStale && SM.current === STATES.RUNNING && (Date.now() - (_ovFeedTs || 0) < 1000 || Date.now() - (_ovSpindleTs || 0) < 1000))
      vizStale = !0;
    typeof VIZ !== "undefined" && !vizStale && VIZ.setToolPos(xyz[0] ?? 0, xyz[1] ?? 0);
    if (typeof vizFilePos === `number` && (SM.current === STATES.RUNNING || SM.current === STATES.PAUSED))
      SM.lastVizFilePos = vizFilePos;
    else
      SM.current !== STATES.RUNNING && SM.current !== STATES.PAUSED && (SM.lastVizFilePos = null);
    SM._prevXYZ = [xyz[0] ?? 0, xyz[1] ?? 0, xyz[2] ?? 0, xyz[3] ?? 0];
    // RPM display: si el husillo está parado, forzar 0 (`active` retiene el
    // último RPM solicitado tras M5 en algunas versiones de RRF).
    const _sp = data.spindles?.[0];
    // El rango REAL de ESTE husillo, no uno genérico. RRF publica min/max
    // en spindles[] desde el M950 R0 ... L{min}:{max} de config.g.
    if (Number.isFinite(_sp?.max) && _sp.max > 0) CFG.maxRPM = _sp.max;
    if (Number.isFinite(_sp?.min) && _sp.min >= 0) CFG.spindleMin = _sp.min;
    syncSpindleRangeUI();
    syncMachineLimitsUI();
    const _stopped = !_sp || _sp.state === `stopped` || _sp.state === `unconfigured`;
    const rpm = _stopped ? 0 : (_sp.current ?? _sp.active ?? data.params?.spindleSpeeds?.[0] ?? 0);
    // RPM SIN separador, igual que el pendant: `toLocaleString('es-ES')` no
    // agrupa a cuatro digitos, y estas dos lecturas —que se pintan una encima
    // de otra— salian mezcladas. Medido con el husillo a 9000 y el maximo en
    // 24000: «9000» junto a «24.000 RPM · max.». Acotado a las RPM.
    const man = !!globalThis.document?.body?.classList.contains(`spindle-manual`);
    setText(`sRPM`, !isConnected ? `---` : man ? t(`spindle.manual`, `MANUAL`) : String(Math.round(rpm)));
    $(`sBar`).style.transform = `scaleX(${!isConnected || man ? 0 : Math.min(rpm / CFG.maxRPM, 1)})`;
    // La etiqueta no lleva data-i18n en el HTML: su valor es dato de máquina,
    // no texto traducible. Solo la abreviatura pasa por t().
    setText(`sMax`, man ? t(`spindle.manualDial`, `RPM en el dial`) : !isConnected
      ? `— RPM · ${t(`work.maxAbbr`, `máx.`)}`
      : `${String(Math.round(CFG.maxRPM))} RPM · ${t(`work.maxAbbr`, `máx.`)}`);
  },

  /** Sincroniza el slider de feed override con el estado real del firmware.
   *  Si la red parpadea mientras el operario toca el slider,
   *  `_ovFeedRetries` se resetea a 0 en cada movimiento y los reintentos
   *  silenciosos pueden no llegar nunca a sincronizar. Medimos tiempo de
   *  divergencia y avisamos al operario con toast `err` cuando el firmware
   *  lleva >CFG.ovFeedWarnMs sin aceptar el override. */
  _uiSyncFeedOverride(data) {
    const fo = data.params?.speedFactor ?? data.params?.feedFactor ?? 100;
    setText(`mOver`, `${Math.round(fo)}%`); // con %: igual que el valor desconectado (index.html) y que VELOCIDADES
    setText(`mFeed`, `${Math.round((data.currentMove?.requestedSpeed ?? 0) * 60)} mm/min`);
    const foVal = Math.round(fo),
      fs = $(`feedSlider`),
      fv = $(`feedVal`);
    if (Date.now() - _ovFeedTs > CFG.ovFeedSyncMs) {
      const _divergent = _ovFeedTarget !== null && Math.abs(foVal - _ovFeedTarget) > 2;
      if (_divergent && _ovFeedRetries < 5) {
        _ovFeedRetries++;
        if (!_ovFeedUnmatchedTs) _ovFeedUnmatchedTs = Date.now();
        RRF.urgentGcode(`M220 S${_ovFeedTarget}`).catch(_swallowErr(`override.M220`));
        _ovFeedTs = Date.now();
        // Aviso único: si llevamos más de CFG.ovFeedWarnMs sin que el firmware
        // matchee Y aún no avisamos, toast err persistente.
        if (
          !_ovFeedWarned &&
          Date.now() - _ovFeedUnmatchedTs > CFG.ovFeedWarnMs
        ) {
          _ovFeedWarned = !0;
          toast(
            t(
              `msg.feedOverrideLost`,
              `Override de avance no aplicado al firmware (pediste ${_ovFeedTarget}%, firmware sigue en ${foVal}%). Verifica la conexión.`,
            ),
            `err`,
          );
          LOG.warn(`feed override divergente: objetivo ${_ovFeedTarget}% / firmware ${foVal}% / retries ${_ovFeedRetries}`);
        }
      } else {
        _ovFeedTarget = null;
        _ovFeedUnmatchedTs = 0;   // sincronizado → reset para próximo ciclo
        _ovFeedWarned = !1;       // sin esto, un futuro ciclo divergente NO
                                  // avisaba: el flag quedaba pegado en true
                                  // desde el primer toast.
        // updateOvBar vive en rotechos-jog.js. Guard por si la carga falla
        // (SD a medias, caché rota): sin guard, ReferenceError rompe este
        // tick del poll y la barra de override queda stale.
        fs && Math.abs(+fs.value - foVal) > 2 &&
          ((fs.value = foVal),
           typeof updateOvBar === `function` && updateOvBar(`feedBarFill`, `feedBarTrack`, foVal));
        fv && (fv.textContent = `${foVal}%`);
      }
    }
  },

  /** Actualiza el RPM nominal del spindle para el cálculo del override.
   *  Respeta el estado real del spindle: si está parado, no actualiza el
   *  nominal (`active` retiene el último RPM tras M5 en algunas versiones). */
  _uiSyncSpindleOverride(data) {
    const _sp = data.spindles?.[0];
    const _stopped = !_sp || _sp.state === `stopped` || _sp.state === `unconfigured`;
    const activeRpm = _stopped ? 0 : (_sp.active ?? 0);
    _spindleRunning = !_stopped;   // estado real del husillo (para el guard del override)
    // Guard por si el defer SPINDLE falla al cargar: si lo hace, este
    // handler muere sin abortar el ciclo del poll.
    if (Date.now() - _ovSpindleTs > CFG.ovSpindleSyncMs && activeRpm > 0 &&
        typeof SPINDLE !== `undefined` && SPINDLE._setNominal)
      SPINDLE._setNominal(Math.round(activeRpm / (SPINDLE.getOvPct() / 100)));
  },
};