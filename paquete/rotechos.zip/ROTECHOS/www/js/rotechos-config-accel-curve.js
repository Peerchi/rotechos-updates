// ---
// rotechos-config-accel-curve.js — Canvas curva aceleración (pestaña VELOCIDADES)
// ---
// Módulo lazy (cargado por rotechos-config-modal.js al primer click en la
// pestaña VELOCIDADES, vía window.__loadAccelCurve()). Antes vivía inline
// en rotechos-config-modal.js (~5 KB parseados en el arranque); ahora se
// carga solo cuando el operario entra en esa pestaña.
//
// Dependencias globales (cargadas antes por orden de defer):
//   - rotechos-dom.js          → $()
//   - rotechos-i18n.js         → t()
//   - rotechos-config-modal.js → accelCurveProfile() (función pura, vive
//                                allí entre marcadores ACCEL_CURVE_PROFILE_BEGIN/END
//                                por tests/unit/accel-curve.test.js).
// ---
'use strict';

(function () {
  const DIST = 100; // mm simulados
  let axis = `X`;
  let drawTimer = null;
  const DEFAULTS = { M203: 3000, M201: 300, M566: 300, RA: 600, RJ: 480 };

  function _num(id, dflt) {
    const el = $(id);
    const v = el ? parseFloat(el.value || el.placeholder) : NaN;
    return Number.isFinite(v) && v > 0 ? v : dflt;
  }
  function _readAxis(ax) {
    const vmax = _num(`mcfgM203${ax}`, DEFAULTS.M203);
    return {
      seda: { v0: _num(`mcfgM566${ax}`, DEFAULTS.M566), vmax, a: _num(`mcfgM201${ax}`, DEFAULTS.M201) },
      rayo: { v0: _num(`mcfgRayoJerk${ax}`, DEFAULTS.RJ), vmax, a: _num(`mcfgRayoAcc${ax}`, DEFAULTS.RA) },
    };
  }
  function draw() {
    const cv = $(`accelCurveCanvas`);
    if (!cv) return;
    const ctx = cv.getContext(`2d`);
    const W = cv.width, H = cv.height, padL = 90, padR = 30, padT = 30, padB = 60;
    const css = getComputedStyle(document.documentElement);
    const cText = css.getPropertyValue(`--text-3`).trim() || `#888`;
    const cGrid = css.getPropertyValue(`--border`).trim() || `#333`;
    ctx.clearRect(0, 0, W, H);
    const cfg = _readAxis(axis);
    // accelCurveProfile vive en rotechos-config-modal.js (top-level function → window.accelCurveProfile)
    const pSeda = window.accelCurveProfile(cfg.seda.v0, cfg.seda.vmax, cfg.seda.a, DIST);
    const pRayo = window.accelCurveProfile(cfg.rayo.v0, cfg.rayo.vmax, cfg.rayo.a, DIST);
    const tMax = Math.max(pSeda.total, pRayo.total) * 1.06;
    const vTop = Math.max(pSeda.vpeak, pRayo.vpeak) * 60 * 1.12;
    const X = (t) => padL + (t / tMax) * (W - padL - padR);
    const Y = (vMmMin) => H - padB - (vMmMin / vTop) * (H - padT - padB);
    ctx.font = `22px ${css.getPropertyValue(`--mono`).trim() || `monospace`}`;
    ctx.strokeStyle = cGrid; ctx.fillStyle = cText; ctx.lineWidth = 1;
    for (let i = 0; i <= 4; i++) {
      const v = (vTop / 4) * i, y = Y(v);
      ctx.beginPath(); ctx.moveTo(padL, y); ctx.lineTo(W - padR, y); ctx.stroke();
      ctx.fillText(String(Math.round(v)), 8, y + 7);
    }
    for (let i = 0; i <= 5; i++) {
      const tt = (tMax / 5) * i, x = X(tt);
      ctx.beginPath(); ctx.moveTo(x, padT); ctx.lineTo(x, H - padB); ctx.stroke();
      ctx.fillText(`${tt.toFixed(2)}s`, x - 26, H - padB + 30);
    }
    ctx.fillText(`mm/min`, 8, 20);
    const plot = (p, v0mmMin, color) => {
      ctx.strokeStyle = color; ctx.lineWidth = 4; ctx.beginPath();
      ctx.moveTo(X(0), Y(0));
      ctx.lineTo(X(0), Y(v0mmMin));
      ctx.lineTo(X(p.t1), Y(p.vpeak * 60));
      ctx.lineTo(X(p.t1 + p.t2), Y(p.vpeak * 60));
      ctx.lineTo(X(p.total), Y(v0mmMin));
      ctx.lineTo(X(p.total), Y(0));
      ctx.stroke();
    };
    const purple = css.getPropertyValue(`--purple`).trim() || `#a78bfa`;
    const teal = css.getPropertyValue(`--teal`).trim() || `#00c8c8`;
    plot(pSeda, cfg.seda.v0, purple);
    plot(pRayo, cfg.rayo.v0, teal);
    ctx.fillStyle = purple; ctx.fillRect(W - 300, 14, 26, 8);
    ctx.fillStyle = cText; ctx.fillText(`SEDA`, W - 266, 24);
    ctx.fillStyle = teal; ctx.fillRect(W - 170, 14, 26, 8);
    ctx.fillStyle = cText; ctx.fillText(`RAYO`, W - 136, 24);
    const meta = $(`accelCurveMeta`);
    if (meta) {
      const fmt = (p) => p.triangular
        ? `${t(`cfg.curve.peak`, `pico`)} ${Math.round(p.vpeak * 60)} mm/min (${t(`cfg.curve.noreach`, `no alcanza el máximo en`)} ${DIST} mm) · ${p.total.toFixed(2)}s`
        : `${Math.round(p.vpeak * 60)} mm/min ${t(`cfg.curve.in`, `en`)} ${p.t1.toFixed(2)}s · ${t(`cfg.curve.total`, `total`)} ${p.total.toFixed(2)}s`;
      meta.textContent = `${t(`cfg.curve.axis`, `Eje`)} ${axis} — SEDA: ${fmt(pSeda)} · RAYO: ${fmt(pRayo)}`;
    }
  }
  function _bind() {
    document.querySelectorAll(`#curveAxisSel .curve-axis-btn`).forEach((b) => {
      b.addEventListener(`click`, () => {
        axis = b.dataset.axis || `X`;
        document.querySelectorAll(`#curveAxisSel .curve-axis-btn`).forEach((o) => {
          const on = o === b;
          o.style.background = on ? `var(--green-fill)` : `var(--bg-raised)`;
          o.style.borderColor = on ? `var(--green-fill)` : `var(--border-md)`;
          o.style.color = on ? `#fff` : `var(--text-2)`;
        });
        draw();
      });
    });
    $(`mcfgTabSpeeds`)?.addEventListener(`input`, () => draw());
    document.querySelector(`.mcfg-tab[data-tab=speeds]`)?.addEventListener(`click`, () => {
      if (drawTimer) clearTimeout(drawTimer);
      drawTimer = setTimeout(() => { drawTimer = null; draw(); }, 50);
    });
    // La curva vive dentro de un <details> plegado por defecto. Con el details
    // cerrado el canvas mide 0x0, asi que cualquier draw() de mientras pinta en
    // el vacio y al abrirlo se veria en blanco. Se redibuja al abrir.
    $(`accelCurveDetails`)?.addEventListener(`toggle`, function () {
      if (this.open) draw();
    });
  }
  _bind(); draw();
  window.ACCEL_CURVE = { draw, profile: window.accelCurveProfile };
})();
