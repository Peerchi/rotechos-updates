/* ---
 * rotechos-logger.js — Logger tipado con niveles, sin dependencias
 *
 * Extraído del monolito rotechos.js (jul-2026, auditoría del monolito).
 * Reemplaza el uso directo de `console.log/warn/error` que estaba
 * disperso en el código (44 ocurrencias en 8 ficheros en main).
 *
 * QUÉ HACE
 *   - Define window.LOG con 4 niveles (debug/info/warn/error) más
 *     setLevel/getLevel para configuración runtime.
 *   - Filtra mensajes por nivel: silent > error > warn > info > debug.
 *   - Formato uniforme: `HH:MM:SS [LEVEL] msg {ctx}`.
 *   - CERO dependencias externas. Vanilla JS puro.
 *
 * POR QUÉ ES AUTO-BOOTSTRAP
 *   - El IIFE se ejecuta al cargar el <script>, sin requerir setup
 *     externo. window.LOG está disponible inmediatamente después.
 *   - Si el módulo se carga en un sandbox (test unit sin window real,
 *     e.g. rotechos-storage.js cargado aislado), funciona igual
 *     porque hace `typeof window !== 'undefined'` y crea su propio
 *     fallback `globalThis.LOG` para entornos sin window.
 *
 * API PÚBLICA (window.LOG)
 *   window.LOG.debug(msg, ctx?)   → si level >= debug, console.debug(...)
 *   window.LOG.info(msg, ctx?)    → si level >= info,  console.info(...)
 *   window.LOG.warn(msg, ctx?)    → si level >= warn,  console.warn(...)
 *   window.LOG.error(msg, ctx?)   → si level >= error, console.error(...)
 *   window.LOG.setLevel(level)    → cambia el nivel (silent/error/warn/info/debug)
 *   window.LOG.getLevel()         → string con el nivel actual
 *
 * USO DESDE OTROS MÓDULOS
 *   - LOG.error("fallo al parsear config:", err)
 *   - LOG.warn("multi-tab detectado", { id: tabId })
 *   - LOG.info("RotechOS Iniciado", "sys")
 *
 * ORDEN DE CARGA en index.html
 *   - Debe cargarse ANTES de cualquier módulo que use LOG.* (es decir,
 *     antes de rotechos-storage, rotechos-led, rotechos-config-persist,
 *     rotechos-ota, rotechos-viz, rotechos.js).
 *
 * SAFEGUARDS
 *   - 5 niveles, no se puede asignar a un nivel inválido.
 *   - try/catch defensivo en _emit (por si console no existe en
 *     entornos raros como workers viejos).
 *   - setLevel con nivel desconocido cae a 'info' (no rompe la app).
 *   - En sandbox sin window: crea globalThis.LOG = {...} para que
 *     los módulos que llaman LOG.* sin definir LOG no rompan.
 * --- */

(function () {
  // ── Detección de entorno: ¿window o globalThis? ──
  // El módulo es auto-bootstrap: se autoinstala al cargarse, sin requerir
  // setup externo. En producción lo carga <script defer> en index.html.
  // En sandbox de tests, vm.runInContext expone `globalThis` como contexto
  // compartido (no window). Inyectamos LOG en TODOS los globales disponibles
  // para que sea visible tanto desde window.LOG como desde LOG directo.
  const _g = (typeof window !== 'undefined') ? window
           : (typeof globalThis !== 'undefined') ? globalThis
           : {};
  const _hasConsole = typeof console !== 'undefined';

  // Definimos las constantes de niveles con su peso (mayor = más severo).
  const LEVELS = { silent: 0, error: 1, warn: 2, info: 3, debug: 4 };
  const NAMES  = ['silent', 'error', 'warn', 'info', 'debug'];
  let _level = LEVELS.info; // default

  function _now() {
    const d = new Date();
    const pad = (n) => String(n).padStart(2, '0');
    return pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds());
  }

  function _fmt(level, msg, ctx) {
    const ts = _now();
    const tag = level.toUpperCase().padEnd(5, ' ');
    const head = ts + ' [' + tag + '] ' + (msg == null ? '' : msg);
    if (ctx == null) return head;
    let tail;
    try {
      tail = typeof ctx === 'string' ? ctx : JSON.stringify(ctx);
    } catch (_) {
      tail = String(ctx);
    }
    return head + ' ' + tail;
  }

  function _emit(level, consoleMethod, msg, ctx) {
    if (LEVELS[level] > _level) return;
    if (!_hasConsole) return;
    try {
      consoleMethod(_fmt(level, msg, ctx));
    } catch (_) {
      // si console no existe (entornos raros), swallow silenciosamente.
    }
  }

  const LOG = {
    debug: (msg, ctx) => _emit('debug', console.debug, msg, ctx),
    info:  (msg, ctx) => _emit('info',  console.info,  msg, ctx),
    warn:  (msg, ctx) => _emit('warn',  console.warn,  msg, ctx),
    error: (msg, ctx) => _emit('error', console.error, msg, ctx),
    setLevel(level) {
      if (!(level in LEVELS)) {
        try {
          console.error(`LOG.setLevel: nivel "${level}" desconocido. Usando 'info'.`);
        } catch (_) {}
        level = 'info';
      }
      _level = LEVELS[level];
    },
    getLevel() {
      return NAMES[_level];
    },
  };

  // Exponer en window (producción) o globalThis (sandbox de tests).
  // En sandbox vm, los dos nombres apuntan al mismo objeto contexto, pero
  // también inyectamos como global dentro del IIFE para que `LOG` directo
  // funcione cuando el módulo target busca el identificador en su scope chain.
  _g.LOG = LOG;
  if (typeof window !== 'undefined') window.LOG = LOG;
  if (typeof globalThis !== 'undefined') globalThis.LOG = LOG;
})();