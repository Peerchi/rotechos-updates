// ---
// rotechos-notif.js — NOTIFICACIONES del navegador (Notification API)
// ---
// Extraído de rotechos.js (jul-2026, extracción #2 del roadmap). El botón
// NOTIF de la topbar (topbarNotifBtn) había desaparecido de index.html en un
// rediseño y la feature quedó inalcanzable; jul-2026: el toggle vive en
// CONFIGURACIÓN → HISTORIAL (panel cfg.tab.jobhistory, inyectado por
// rotechos-config-modal.js — ver MACHINE_TABS). El id `mcfgNotifEnabled`
// en index.html:2575 es un **wrapper dormante** (patrón H3-bis, commit
// 3bad606) al que este módulo hace `chk.checked = on/off` como sink seguro:
// si el panel HISTORIAL aún no inyectó su checkbox real, el guard `chk &&`
// evita throw y el estado real se sincroniza al re-render del panel. El
// opt-in persiste vía STORE ('notif.enabled') — solo se restaura si el
// permiso del navegador sigue granted. Gate doble: opt-in del operario (con
// flujo de permisos) Y Notification.permission === granted. El wrapper de
// SM.transition es el trigger de negocio: notifica fin de trabajo
// (RUNNING→IDLE con archivo) y error (RUNNING→ERROR) para trabajos largos
// sin operario delante. Su try/catch garantiza que un fallo de notifs
// JAMÁS bloquee una transición de la máquina de estados.
//
// NOTA jul-2026 (Bloque D, cierre M6+): auditado contra index.html y
// rotechos-config-modal.js. Decisión: NO migrar el wrapper a <input
// type=checkbox> propio en línea 2575 — el panel HISTORIAL ya renderiza el
// checkbox real, duplicarlo rompe el patrón canónico (cf. fmCount,
// pendant2RunSpVal, etc.). Si en el futuro se quiere eliminar el wrapper,
// localizar primero todos los puntos de render del panel HISTORIAL y
// unificar binding.
//
// Dependencias en runtime (todas globales, resueltas por orden de defer;
// este archivo carga DESPUÉS de rotechos.js — ver index.html; en concreto
// SM debe existir YA al ejecutarse este script, por el bind del wrapper):
//   - rotechos-dom.js     → $()
//   - rotechos-i18n.js    → t()
//   - rotechos-logger.js  → LOG
//   - rotechos-storage.js → STORE (guarded: sin él no hay persistencia)
//   - rotechos.js         → SM, STATES, toast, hms
//
// Los callers de sendNotif que siguen en rotechos.js (halt, soft limit,
// endstop) usan guard `typeof sendNotif === 'function'` — funcionan con
// cualquier orden de carga.
//
// ⚠️ tests/unit/notif.test.js extrae sendNotif y el wrapper por regex
//    anclada a indent 0 (cierres `\n}` / `\n};`): si reindentas o renombras
//    _origTransition, actualiza el anclaje del test.
// ---
/* exported sendNotif */
// Opt-in persistido: solo se restaura a true si el permiso sigue granted
// (si el usuario lo revocó en el navegador, el toggle vuelve a apagado).
let notifEnabled =
  typeof STORE !== `undefined` &&
  STORE.get(`notif.enabled`, !1) &&
  `Notification` in window &&
  Notification.permission === `granted`;
function sendNotif(title, body, icon = `✓`, titleKey = null) {
  if (!(!notifEnabled || Notification.permission !== `granted`))
    try {
      // Si el caller pasa una clave i18n explícita (4º arg), la usamos para el
      // TÍTULO. Si no, derivamos la clave del título como antes (compat hacia
      // atrás). El body queda delegado al caller: t() no interpola
      // ${var}, y los call-sites de "ALERTA: Halt: thermal" / "Final de
      // carrera X activado" tienen cuerpo dinámico → no se puede prefijar
      // con una clave genérica. (HALLAZGO-25, ARREGLO 2026-08-18.)
      const _key = titleKey || `notif.` + title.toLowerCase().replace(/\s+/g, '_');
      const _tTitle = (typeof t === 'function' && t(_key, title)) || title;
      new Notification(_tTitle ? `${icon} ${_tTitle}` : `${icon} ${title}`, {
        body,
        icon: `/favicon.ico`,
        tag: `rotechos-job`,
      });
    } catch {}
}
function setNotifEnabled(on) {
  notifEnabled = on;
  typeof STORE !== `undefined` && STORE.set(`notif.enabled`, on);
  const chk = $(`mcfgNotifEnabled`);
  chk && (chk.checked = on);
}
const notifChkEl = $(`mcfgNotifEnabled`);
notifChkEl && (notifChkEl.checked = notifEnabled);
notifChkEl &&
  notifChkEl.addEventListener(`change`, async () => {
    if (!(`Notification` in window)) {
      notifChkEl.checked = !1;
      toast(t(`msg.notificacionesNoDisponiblesEn`, `Notificaciones no disponibles en este navegador`), `warn`);
      return;
    }
    if (!notifChkEl.checked) {
      setNotifEnabled(!1);
      toast(t(`msg.notificacionesDesactivadas`, `Notificaciones desactivadas`), `info`);
      return;
    }
    if (Notification.permission === `denied`) {
      notifChkEl.checked = !1;
      toast(
        t(`msg.notificationsBlocked`, `Notificaciones bloqueadas por el navegador — para activarlas pulsa el candado/camión del icono a la izquierda de la URL, busca "Notificaciones" o "Permisos" y pon RotechOS en "Permitir". Luego vuelve a marcar el check y recarga la página (F5). Hasta que no las actives, la app no te avisará al terminar un trabajo.`),
        `err`,
      );
      return;
    }
    if (
      Notification.permission !== `granted` &&
      (await Notification.requestPermission()) !== `granted`
    ) {
      notifChkEl.checked = !1;
      toast(t(`msg.permisoDenegado`, `Permiso denegado`), `err`);
      return;
    }
    setNotifEnabled(!0);
    toast(t(`msg.notificacionesActivadas`, `Notificaciones activadas`), `ok`);
  });
const _origTransition = SM.transition.bind(SM);
SM.transition = function (newState, reason) {
  const prevState = SM.current;
  const ok = _origTransition(newState, reason);
  try {
    if (
      ok &&
      prevState === STATES.RUNNING &&
      newState === STATES.IDLE &&
      SM.loadedFile
    ) {
      const dur = SM.jobStartTime ? Date.now() - SM.jobStartTime : 0;
      sendNotif(`Trabajo completado`, `${SM.loadedFile} — ${hms(dur)}`, `✓`, `notif.jobComplete`);
    }
    if (ok && newState === STATES.ERROR) {
      SM.loadedFile &&
        prevState === STATES.RUNNING &&
        sendNotif(
          `Error en trabajo`,
          `${SM.loadedFile} — ${reason || `error desconocido`}`,
          `✕`,
          `notif.jobError`,
        );
    }
  } catch (e) {
    LOG.warn(`Transition wrapper error:`, e);
  }
  return ok;
};
