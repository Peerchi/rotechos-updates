/* ---
 * rotechos-auth.js — Capa fina de autenticación HTTP por PIN (M551).
 *
 *   - Almacena el PIN en localStorage (`rotechos.pin`) para no tener que
 *     re-leer config-machine.g en cada rr_connect.
 *   - Construye la URL de `rr_connect?password=...` con el PIN cacheado.
 *   - Clasifica la respuesta de RRF en 'ok' / 'rejected' / 'network_error'.
 *   - Cuando RRF rechaza (HTTP 401, "Password required"), muestra un overlay
 *     modal de entrada de PIN y reintenta rr_connect con el valor tecleado.
 *
 * Honestidad (no marketing):
 *   El PIN protege del ACCESO CASUAL, NO del tráfico capturado. RRF sirve
 *   HTTP plano. Si necesitas seguridad real, segmenta la WiFi del taller
 *   y/o usa HTTPS (futuro). El paro físico de la máquina (escudo M581 o
 *   seta cableada) sigue siendo independiente del navegador y del PIN.
 *
 * No rompe la UX sin PIN: si no hay PIN configurado, el módulo actúa como
 * un no-op y `rr_connect` se llama sin `password=`, igual que antes de
 * este cambio.
 *
 * Vereda de implementación: rotechos-config-persist.js:cfgPersistPin (helper
 * de persistencia) + rotechos-config-modal.js:tab PIN (UI de configuración).
 * Tests unitarios: tests/unit/rotechos-auth.test.js (cubre los 3 escenarios
 * del briefing: sin PIN, PIN correcto, PIN rechazado).
 * --- */
'use strict';

// ---
// I18N DEFENSIVO (HALLAZGO-7 / HALLAZGO-8 del informe 2026-08-18-busca-v2)
// rotechos-i18n.js publica `window.t(key, fallback)`. En runtime de navegador
// el módulo carga antes que rotechos-ui-feedback.js (orden defer FIFO;
// rotechos-i18n.js está en pos. 5, rotechos-auth.js en pos. 12) — `window.t`
// ya existe cuando se renderiza el overlay. Pero en los tests unitarios
// (sandbox vm con `window: {}`, tests/unit/rotechos-auth.test.js:99) no
// existe. Si lo invocamos sin guarda, rompe los 7 tests DOM que crean el
// overlay. Patrón: snapshot de la función al cargar el módulo y, si no
// está, usar un fallback estable (clave → fallback, fallback → fallback).
// ---
const _t = (typeof window !== `undefined` && typeof window.t === `function`)
  ? window.t
  : (_key, fallback) => (fallback != null ? fallback : _key);

// ---
// TOAST DEFENSIVO (HALLAZGO-8)
// rotechos-ui-feedback.js carga en pos. 21 del defer — DESPUÉS de
// rotechos-auth.js (pos. 12). El módulo solo define funciones; NO se ejecuta
// hasta que el operario falla 5 veces y entra en lockout (DOMContentLoaded
// ya pasó; todos los defer terminaron). Aún así, blindamos: si window.toast
// no existe por algún orden de carga atípico, degradamos a console.warn.
// ---
function _toastWarn(msg) {
  if (typeof window !== `undefined` && typeof window.toast === `function`) {
    window.toast(msg, `warn`);
  } else {
    try { console.warn(`[rotechos-auth]`, msg); } catch (_) { /* defensivo */ }
  }
}

// eslint-disable-next-line no-unused-vars -- consumido por rotechos.js (RRF.connect + watcher M999) via window
const PIN_STORAGE_KEY = `rotechos.pin`;

// ---
// PIN DE FÁBRICA — 123456789 (decisión Sergi 2026-08-18, t_042f109c).
//
// Por qué un valor por defecto: la UI NO puede prometer seguridad si el
// operario no sabe que el PIN existe. Un PIN "vacío = sin protección" deja
// la máquina abierta al primer despiste. Un PIN fijo de fábrica, conocido,
// es mejor que NADA solo si el operario lo ve y decide cambiarlo o quitarlo
// en el primer arranque (el wizard del paso 12 se lo recuerda y el panel
// Configuración → PIN HTTP lo muestra en el estado).
//
// ¿Por qué NO en config.g? Porque config.g lo reescribe la OTA. El PIN
// debe persistir en config-machine.g (la calibración de cada máquina, lo
// que la OTA respeta). Ver `sys/config-machine.g` — la línea canónica
// `M551 P"123456789"` vive ahí como baseline.
//
// ¿Por qué EXPORTADO y no inline? El wizard (rotechos-modules.js paso 12)
// y el panel de Configuración lo consultan para detectar "PIN sin
// cambiar" y avisar al operario. Tests e2e lo usan para verificar el
// camino "el operario ve el aviso" y "el operario lo cambia".
// ---
const DEFAULT_FACTORY_PIN = `123456789`; // 9 dígitos, dentro del charset permitido (A-Za-z0-9 y -_.@#!?,:, máx 24)

// eslint-disable-next-line no-unused-vars -- consumido por rotechos-modules.js (wizard s12) + rotechos-config-modal.js via window
function isFactoryPin(pin) {
  return String(pin ?? ``) === DEFAULT_FACTORY_PIN;
}

/* ---
 * PRIMITIVAS PURAS — sin DOM, sin red, sin localStorage. Testeables.
 * Exportadas en window.rotechosAuth para que tests unitarios las invoquen
 * sin cargar el resto del módulo.
 * --- */

// Construye la URL que se envía a RRF en `/rr_connect`. Si pin es vacío
// (o null), emite `password=` para preservar el comportamiento previo:
// la API de RRF acepta ambos (`password=` vacío = sin PIN). El parámetro
// `time` evita caches HTTP intermedios.
function buildRRConnectUrl(baseIp, pin) {
  const safePin = pin == null ? `` : String(pin);
  return `${baseIp}/rr_connect?password=${encodeURIComponent(safePin)}&time=${Date.now()}`;
}

// Clasifica una respuesta de fetch() en tres categorías operativas:
//   'ok'            → la máquina aceptó el handshake (200 + JSON válido).
//   'rejected'      → RRF devolvió 401 (HTTP) o "Password required" en el
//                     body. El operario debe autenticarse para continuar.
//   'network_error' → cualquier otro fallo (timeout, 5xx, parse roto).
//                     NO es un rechazo de auth; es un fallo técnico que la
//                     UI ya sabe manejar (toast, reconnect, etc.).
//
// Devolver 'rejected' SÓLO cuando el código o el body lo indique evita
// falsos positivos en paneles 5xx que harían saltar el overlay sin razón.
//
// Acepta `null` (fetch falló antes de resolver) → 'network_error'.
// `body` es el JSON ya parseado (puede ser null si la respuesta no era OK
// o si el parse falló).
function classifyRRConnectResponse(response, body) {
  if (response == null) return `network_error`;
  // RRF 3.x devuelve HTTP 401 con body {"err":N,"errMessage":"..."} cuando
  // hace falta password. Documentado en RRF HTTP docs.
  if (response.status === 401) return `rejected`;
  if (!response.ok) return `network_error`;
  // 5-oct: RRF 3.5.4 responde a un PIN incorrecto con HTTP 200 y {"err":1}, y sin
  // sesiones libres con {"err":2} (HttpResponder.cpp:467-483). Antes eso era «ok».
  if (body && typeof body === `object` && body.err) return body.err === 1 ? `rejected` : `network_error`;
  // Defensa: si el JSON viene con `errMessage` que contiene "password", es
  // un rechazo aunque el status code no sea 401 (algunos proxys devuelven
  // 200 con body de error). Verificado contra el objeto modelo real de RRF.
  if (body && typeof body === `object` && typeof body.errMessage === `string`) {
    const m = body.errMessage.toLowerCase();
    if (m.includes(`password`)) return `rejected`;
  }
  return `ok`;
}

// ---
// CHARSET M551 (t_4f22bdc3, 2026-09-01)
//
// RepRapFirmware M551 acepta SOLO letras/dígitos y los símbolos
// `-_.@#!?,:` — máximo 24 caracteres, SIN espacios. Está documentado en
// `config-machine.g` (línea canónica `M551 P"…"`) y replicado en
// `rotechos-config-persist.js:_sanitizePin` (que SILENCIOSAMENTE borra
// cualquier carácter fuera del set). El problema: si el operario teclea
// `taller 2024` (con espacio), la persistencia graba `taller2024` sin
// avisar — y al ir a entrar, la máquina pide `taller2024` en vez de lo que
// el operario tecleó. Queda FUERA de su propia máquina hasta editar la SD.
//
// `validateM551Pin` es la primitiva pura que decide si un PIN es grabable.
// Se llama desde la UI EN EL MOMENTO DE ESCRIBIR (no solo al pulsar
// "Guardar") para que el operario vea el error antes de perder tiempo en
// el camino. Devuelve un objeto estable para que la UI pinte el aviso
// concreto (qué carácter sobra, cuántos quedan) sin tener que re-implementar
// la lógica.
//
//   ok       → true si el PIN es grabable (vacío también: "no PIN" es válido)
//   motivo   → string i18n-codificado para `t('msg.pinCharset.<motivo>', fallback)`
//              o '' si ok=true
//   caracter → el carácter concreto que sobra (string de 1 char) o '' si
//              no aplica (length, vacío)
//   restantes→ cuántos caracteres más caben (número, 0..24)
//
// Coherencia con `_sanitizePin` (rotechos-config-persist.js): el set
// permitido es el mismo. Si `_sanitizePin` se ensancha algún día, este
// validador debe moverse con él. Por eso el set vive aquí exportado como
// `M551_PIN_CHARSET_REGEX` para que tests y la UI lo compartan.
// ---

// Set permitido M551 — letras/dígitos + `-_.@#!?,:`. Definido una sola
// vez y exportado por window.rotechosAuth para que tests y la UI lo
// compartan (evita que la regex de validación y la de sanitización se
// desincronicen). La longitud máxima 24 viene del input `maxlength=24`
// del HTML (index.html:1067) y de M551 RRF (rotechos-auth.js:82).
const M551_PIN_CHARSET_REGEX = /^[A-Za-z0-9\-_.@#!?,:]*$/;
const M551_PIN_MAX_LEN = 24;

// Recorre `pin` y devuelve el primer carácter que NO esté en el charset
// permitido. Si todos están bien, devuelve ''. Pensado para que el
// mensaje de error diga "el carácter X no está permitido", no un genérico.
function _firstBadChar(pin) {
  const s = String(pin ?? ``);
  for (let i = 0; i < s.length; i++) {
    if (!M551_PIN_CHARSET_REGEX.test(s[i])) return s[i];
  }
  return ``;
}

// eslint-disable-next-line no-unused-vars -- expuesto en window.rotechosAuth (consumido por rotechos-config-modal.js)
function validateM551Pin(pin) {
  // `null`/`undefined` se tratan como vacío (el operario aún no tecleó).
  const s = String(pin ?? ``);
  // Caso vacío: NO es un error — "vacío = sin cambios / sin PIN" es un
  // estado válido (el panel Configuración lo usa como "no tocar"). El
  // validador devuelve ok=true con motivo vacío y restantes=24.
  if (s.length === 0) {
    return { ok: true, motivo: ``, caracter: ``, restantes: M551_PIN_MAX_LEN };
  }
  // Longitud > 24: M551 lo rechazaría en el siguiente arranque. Avisamos
  // ANTES de que el operario pulse "Guardar" y descubra que su PIN se ha
  // truncado a 24 silenciosamente. `motivo=demasiado-largo` para que la
  // UI pinte "máximo 24 caracteres" y el contador marque 0.
  if (s.length > M551_PIN_MAX_LEN) {
    return {
      ok: false,
      motivo: `demasiado-largo`,
      caracter: ``,
      restantes: 0,
    };
  }
  // Carácter fuera del charset: avisamos CUÁL es (el operario puede que
  // haya tecleado un espacio, una `ñ`, una coma rusa…). El orden importa:
  // los espacios son el caso más común (passphrase típica), por eso los
  // nombramos con un motivo específico (`msg.pinCharset.espacio` en i18n)
  // y caemos al genérico `caracter-invalido` para el resto.
  const bad = _firstBadChar(s);
  if (bad !== ``) {
    const motivo = (bad === ` ` || bad === `\t`) ? `espacio` : `caracter-invalido`;
    return {
      ok: false,
      motivo,
      caracter: bad,
      restantes: M551_PIN_MAX_LEN - s.length,
    };
  }
  return {
    ok: true,
    motivo: ``,
    caracter: ``,
    restantes: M551_PIN_MAX_LEN - s.length,
  };
}

/* ---
 * PRIMITIVAS IMPURAS — localStorage + UI. NO se exportan al global para
 * no contaminar; viven en el IIFE y se accede por window.rotechosAuth.
 * --- */

// Lee el PIN cacheado. Devuelve '' si no hay nada cacheado o si el caché
// está corrupto. NO lanza.
function _getStoredPin() {
  try {
    const v = localStorage.getItem(PIN_STORAGE_KEY);
    return v == null ? `` : String(v);
  } catch (_) {
    return ``;
  }
}

// Persiste el PIN en localStorage. Llamado por cfgPersistPin tras un
// guardado exitoso en SD. NO lanza.
function _setStoredPin(pin) {
  try {
    if (pin) localStorage.setItem(PIN_STORAGE_KEY, String(pin));
    else localStorage.removeItem(PIN_STORAGE_KEY);
  } catch (_) { /* defensivo: localStorage puede estar deshabilitado */ }
}

// Borra el PIN cacheado. Llamado por cfgRemovePin tras quitar el PIN de
// la SD y por el overlay de auth tras un logout explícito.
function _clearStoredPin() {
  try { localStorage.removeItem(PIN_STORAGE_KEY); } catch (_) {}
}

/* ---
 * OVERLAY DE AUTH — solo se monta cuando hace falta (no por defecto).
 *
 * Por qué lazy: en una máquina SIN PIN, este overlay nunca debe aparecer.
 * Renderizarlo siempre sería DOM muerto + posibilidade de foco robado.
 *
 * Cuando RRF devuelve 'rejected', `tryConnect` llama a `_showAuthOverlay`.
 * El overlay pide PIN, llama a `_setStoredPin(pin)` y vuelve a llamar a
 * `tryConnect` con el nuevo valor. Si el operario cancela, devuelve false
 * y la UI sigue sin autenticar (otros comandos pueden seguir fallando —
 * coherente con la decisión de "sin auth no hay control").
 * --- */

let _overlayEl = null;
let _activePromptResolve = null;
// HALLAZGO H-N5 (informe 2026-08-18-busca-superficie-seguridad-api-rrf-y-pin-v3):
// si dos `tryConnect` corren casi-a-la-vez (M999 watcher 1s + JOG del
// operario; OTA encolada + MDI rápido), la segunda invocación de
// `_showAuthOverlay` pisaba `_activePromptResolve` con su propio resolver
// y la PRIMERA promesa quedaba pendiente para siempre. El escudo aborta
// silencioso y el operario no entiende por qué un botón "no responde".
// Fix: si ya hay un overlay abierto con un resolver activo, encolamos las
// llamadas nuevas en `_pendingOverlayWaiters`; cuando el operario teclea OK
// (o Cancelar), `close(val)` resuelve TODOS los waiters con el mismo valor.
// El overlay sigue siendo UNO (mismo DOM, mismo input), el operario teclea
// una sola vez y todas las promesas concurrentes salen juntas.
let _pendingOverlayWaiters = [];

function _ensureOverlay() {
  if (_overlayEl && document.body.contains(_overlayEl)) return _overlayEl;
  const el = document.createElement(`div`);
  el.id = `authOverlay`;
  el.setAttribute(`role`, `dialog`);
  el.setAttribute(`aria-modal`, `true`);
  el.setAttribute(`aria-labelledby`, `authOverlayTitle`);
  el.style.cssText = [
    `position:fixed`, `inset:0`, `background:var(--overlay-bg)`,
    `display:none`, `align-items:center`, `justify-content:center`,
    `z-index:99999`, `font-family:var(--font)`,
  ].join(`;`);
  el.innerHTML = `
    <div style="background:var(--bg);border:1px solid var(--border-hi);border-radius:var(--r-xl);padding:22px 22px 18px;max-width:380px;width:calc(100vw - 32px);box-shadow:var(--shadow-lg)">
      <div id="authOverlayTitle" style="color:var(--text-1);font-weight:700;font-size:16px;margin-bottom:8px">${_t(`msg.pinOverlayTitle`, `PIN HTTP requerido`)}</div>
      <div style="color:var(--text-2);font-size:12px;line-height:1.5;margin-bottom:12px">${_t(`msg.pinOverlayBody`, `La máquina exige contraseña HTTP. Introdúcela para continuar. El PIN viaja sin cifrar por HTTP — protege del acceso casual, no de quien capture tráfico.`)}</div>
      <input id="authOverlayInput" type="password" autocomplete="current-password" maxlength="24" class="in-txt" style="width:100%;font-family:var(--mono)">
      <div id="authOverlayError" style="color:var(--red);font-size:11px;margin-top:8px;min-height:14px"></div>
      <div style="display:flex;gap:8px;margin-top:14px;flex-wrap:wrap">
        <button id="authOverlayBtnOk" type="button" class="btn-save" style="flex:1">${_t(`msg.pinOverlayBtnOk`, `Entrar`)}</button>
        <button id="authOverlayBtnCancel" type="button" class="btn-cancel" style="flex:0 0 auto">${_t(`msg.pinOverlayBtnCancel`, `Cancelar`)}</button>
      </div>
    </div>
  `;
  document.body.appendChild(el);

  // Listeners: Enter dispara OK, Escape dispara cancelar.
  const input = el.querySelector(`#authOverlayInput`);
  const btnOk = el.querySelector(`#authOverlayBtnOk`);
  const btnCancel = el.querySelector(`#authOverlayBtnCancel`);
  const close = (val) => {
    el.style.display = `none`;
    const r = _activePromptResolve;
    _activePromptResolve = null;
    // H-N5: drena la cola de waiters concurrentes con el mismo `val` para
    // que N `tryConnect` paralelos que compartían overlay salgan juntos.
    const waiters = _pendingOverlayWaiters;
    _pendingOverlayWaiters = [];
    if (r) r(val);
    for (const w of waiters) { try { w(val); } catch (_) { /* defensivo */ } }
  };
  btnOk.addEventListener(`click`, () => {
    const v = (input.value || ``).trim();
    if (!v) {
      el.querySelector(`#authOverlayError`).textContent = _t(`msg.pinOverlayEmptyError`, `PIN vacío.`);
      input.focus();
      return;
    }
    _setStoredPin(v);
    close(v);
  });
  btnCancel.addEventListener(`click`, () => close(``));
  input.addEventListener(`keydown`, (ev) => {
    if (ev.key === `Enter`) { ev.preventDefault(); btnOk.click(); }
    else if (ev.key === `Escape`) { ev.preventDefault(); btnCancel.click(); }
  });

  _overlayEl = el;
  return el;
}

function _showAuthOverlay(errorMsg) {
  // H-N5: si ya hay un overlay abierto con un resolver activo, NO
  // sobreescribimos `_activePromptResolve` — encolamos esta llamada para
  // que `close()` la drene junto con la principal cuando el operario
  // teclee OK/Cancelar. Mismo DOM, misma interacción, todas las promesas
  // salen juntas.
  if (_activePromptResolve) {
    return new Promise((resolve) => {
      _pendingOverlayWaiters.push(resolve);
    });
  }
  return new Promise((resolve) => {
    const el = _ensureOverlay();
    const input = el.querySelector(`#authOverlayInput`);
    const err = el.querySelector(`#authOverlayError`);
    input.value = ``;
    err.textContent = errorMsg || ``;
    el.style.display = `flex`;
    _activePromptResolve = resolve;
    // Foco en input tras pintar (defensa contra robo de foco).
    setTimeout(() => { try { input.focus(); } catch (_) {} }, 30);
  });
}

// Rate-limit básico en el overlay: máximo 5 intentos, tras los cuales se
// bloquea 30s. NO es seguridad real (la red puede saltarse el rate
// client-side) — es defensa contra typos en la UI.
//
// Estado persistente (H-5 del informe 2026-08-17): el contador y el
// timestamp de bloqueo viven en localStorage para sobrevivir cierres de
// pestaña. Si el operario teclea mal 5 veces, cierra la pestaña y vuelve,
// sigue bloqueado. Coherente con que el PIN cacheado YA vive en
// localStorage (rotechos.pin). Las claves usan prefijo `rotechos.auth` y
// se limpian al alcanzar éxito.
const FAIL_COUNT_KEY = `rotechos.authFail`;
const LOCKOUT_UNTIL_KEY = `rotechos.authLockoutUntil`;
const MAX_FAILS = 5;
const LOCKOUT_MS = 30_000;

// El contador de fallos CADUCA (2026-08-31). Antes solo se ponia a cero con un
// `tryConnect` que saliera bien, asi que un contador a 5 de una sesion vieja
// —incluso de otra maquina, porque localStorage no distingue— dejaba la UI a un
// solo fallo de rearmar el bloqueo de 30 s, para siempre. Y durante el bloqueo
// no se hace ninguna peticion, asi que tampoco podia haber un exito que lo
// limpiara: el operario se quedaba encerrado leyendo "PIN requerido" sin que
// nadie le pidiera el PIN.
//
// Con la caducidad, cinco intentos fallidos siguen bloqueando 30 s —que es
// para lo que existe el contador, frenar la fuerza bruta— pero cinco fallos
// repartidos a lo largo de un dia ya no cuentan como una racha.
//
// La ventana es de 10 minutos: cinco veces el bloqueo de 30 s, holgado para
// una racha real de tecleo y corto para que nadie arrastre el contador de una
// sesion a otra. Se guarda junto al contador; si falta la marca (contadores
// escritos por una version anterior), se trata como caducado, que es el lado
// seguro: como mucho se le regalan al operario cinco intentos.
const FAIL_WINDOW_MS = 600_000;
const FAIL_STAMP_KEY = `rotechos.authFailAt`;
function _readStoredFailCount() {
  try {
    const v = localStorage.getItem(FAIL_COUNT_KEY);
    if (v == null) return 0;
    const marca = parseInt(String(localStorage.getItem(FAIL_STAMP_KEY) || ``), 10);
    if (!Number.isFinite(marca)) {
      // CONTADOR SIN MARCA: se ADOPTA, no se tira (corregido 2026-08-31).
      // La primera version lo trataba como caducado y lo borraba, razonando
      // que "como mucho se le regalan cinco intentos al operario". El
      // razonamiento estaba invertido: este contador existe para frenar la
      // fuerza bruta, asi que ante una edad desconocida lo conservador es
      // CONSERVARLO, no descartarlo. Regalar cinco intentos a quien esta
      // probando PINs es justo lo que no se quiere.
      // Ademas rompia a quien lo escribe sin marca: las versiones anteriores
      // de este mismo fichero, y `tests/e2e-auth-pin-lockout.spec.js`, que
      // siembra `authFail=4` para provocar el bloqueo al siguiente fallo.
      // Medido: los 5 tests de ese spec pasaban antes y fallaban despues, con
      // `authFail:"2"` en vez de 5 — la siembra se borraba al leerla.
      // Se le pone la marca AHORA: la racha queda acotada a la ventana en vez
      // de ser eterna, que era el objetivo, sin perder la cuenta.
      try { localStorage.setItem(FAIL_STAMP_KEY, String(Date.now())); } catch (_) { /* swallow */ }
    } else if (Date.now() - marca > FAIL_WINDOW_MS) {
      try {
        localStorage.removeItem(FAIL_COUNT_KEY);
        localStorage.removeItem(FAIL_STAMP_KEY);
      } catch (_) { /* almacenamiento no disponible: el 0 de abajo ya protege */ }
      return 0;
    }
    const n = parseInt(String(v), 10);
    return Number.isFinite(n) && n >= 0 ? n : 0;
  } catch (_) { return 0; }
}

function _writeStoredFailCount(n) {
  try {
    if (n > 0) localStorage.setItem(FAIL_COUNT_KEY, String(n));
    else localStorage.removeItem(FAIL_COUNT_KEY);
  } catch (_) { /* defensivo: localStorage puede estar deshabilitado */ }
}

function _readStoredLockoutUntil() {
  try {
    const v = localStorage.getItem(LOCKOUT_UNTIL_KEY);
    if (v == null) return 0;
    const n = parseInt(String(v), 10);
    return Number.isFinite(n) && n >= 0 ? n : 0;
  } catch (_) { return 0; }
}

function _writeStoredLockoutUntil(ts) {
  try {
    if (ts > 0) localStorage.setItem(LOCKOUT_UNTIL_KEY, String(ts));
    else localStorage.removeItem(LOCKOUT_UNTIL_KEY);
  } catch (_) {}
}

function _noteAuthFailure() {
  const n = _readStoredFailCount() + 1;
  _writeStoredFailCount(n);
  // Sella CUANDO fue el ultimo fallo, para que `_readStoredFailCount` pueda
  // caducar la racha. Sin esta marca el contador seria eterno.
  try { localStorage.setItem(FAIL_STAMP_KEY, String(Date.now())); } catch (_) { /* swallow */ }
  if (n >= MAX_FAILS) {
    _writeStoredLockoutUntil(Date.now() + LOCKOUT_MS);
  }
}

function _isLockedOut() {
  const ts = _readStoredLockoutUntil();
  return ts > Date.now();
}

// HALLAZGO-8 (informe 2026-08-18-busca-mensajes-v2): lockout 30s sin aviso.
// Cuando el operario falla 5 veces, queda bloqueado 30s sin saberlo. Esta
// función auxiliar avisa UNA vez por cada intento de `tryConnect` que
// entre con el lockout YA activo (no reavisa en llamadas intermedias).
// Calcula los segundos exactos que faltan (`Math.ceil` para que "0.5s" se
// vea como "1s" — no como "espera 0s"). Coherente con HALLAZGO-6: t() NO
// expande plantillas, así que el .replace('{secs}', secs) lo hacemos aquí,
// que es donde sí sabemos el número.
function _notifyLockout() {
  if (!_isLockedOut()) return;
  const remainingMs = _readStoredLockoutUntil() - Date.now();
  const secs = Math.max(1, Math.ceil(remainingMs / 1000));
  _toastWarn(_t(`msg.pinLockoutWarn`, `Demasiados intentos, espera {secs}s antes de reintentar.`).replace(`{secs}`, String(secs)));
}

function _resetAuthFailures() {
  _writeStoredFailCount(0);
  _writeStoredLockoutUntil(0);
  try { localStorage.removeItem(FAIL_STAMP_KEY); } catch (_) { /* swallow */ }
}

/* ---
 * API PÚBLICA — window.rotechosAuth
 *
 * tryConnect(baseIp, pin?, fetcher?) es la pieza que rotechos.js llama
 *   en `RRF.connect` y en el watcher M999. Si `pin` viene vacío, usa
 *   el cache de localStorage. `fetcher` es opcional y permite inyectar
 *   un mock en tests; por defecto usa `fetch`.
 *
 * Devuelve una Promise<boolean>:
 *   true  → autenticado (o sin PIN configurado, modo legacy)
 *   false → rechazo de auth o error no recuperable
 *
 * En el caso 'rejected', `tryConnect` muestra el overlay y reintenta con
 * el PIN tecleado. Si el operario cancela, devuelve false. La UI sigue
 * funcionando para lecturas; los comandos que RRF rechace saldrán con
 * el mismo toast de error de siempre.
 * --- */

async function _oneConnectAttempt(_fetch, baseIp, pin) {
  const url = buildRRConnectUrl(baseIp, pin);
  let resp = null;
  let body = null;
  try {
    // D-04 (medido 19-sep): el PIN va en la query string. En el HISTORIAL del
    // navegador NO queda —un `fetch` no es una navegacion, verificado contra un
    // perfil real con control positivo—, pero SI se escribia en el cache de
    // disco si el firmware no mandaba `Cache-Control`. `no-store` lo cierra
    // pase lo que pase en la placa, que no tenemos delante para comprobarlo.
    resp = await _fetch(url, { cache: `no-store`, signal: (typeof AbortSignal !== `undefined` ? AbortSignal.timeout(8000) : undefined) });
    if (resp && resp.ok) {
      try { body = await resp.json(); } catch (_) { /* tolerante */ }
    }
  } catch (_) {
    return { cls: `network_error`, resp, body };
  }
  return { cls: classifyRRConnectResponse(resp, body), resp, body };
}

// tryConnect es la pieza que rotechos.js llama en `RRF.connect` y en el
// watcher M999. Si `pin` viene vacío, usa el cache de localStorage.
// `fetcher` es opcional y permite inyectar un mock en tests; por defecto
// usa `fetch`. Devuelve {ok, body} donde body es el JSON parseado de la
// respuesta exitosa (o null si no se llegó a autenticar).
//
// Caso `ok`: body = JSON del rr_connect exitoso (parseado).
// Caso `rejected`: muestra overlay, reintenta hasta 2 veces. Si el operario
//   cancela, devuelve {ok:false, body:null}.
// Caso `network_error`: devuelve {ok:false, body:null} sin overlay (NO es
//   problema de auth, es problema de red — la UI ya lo maneja).
async function tryConnect(baseIp, pin, fetcher, sinOverlay) {
  const _fetch = fetcher || ((url, opts) => fetch(url, opts));
  const usePin = (pin != null && pin !== ``) ? pin : _getStoredPin();
  // HALLAZGO-8: si entramos con el lockout YA activo, avisamos al operario
  // antes de devolver. Esto cubre el caso btnRecon → RRF.connect → tryConnect
  // y el caso del reintento interno cuando ya consumió 5 fallos. La función
  // _notifyLockout es idempotente (no avisa si no está lockout-out).
  if (_isLockedOut()) {
    // BLOQUEO SIN SALIDA (arreglado 2026-08-31). Este early-return corta ANTES
    // del overlay del PIN, asi que durante el bloqueo el operario ve "PIN
    // requerido" y NUNCA se le pide el PIN. Peor: el contador y el `until`
    // viven en localStorage y sobreviven a recargas, a reiniciar el mock y a
    // cambiar de maquina — un bloqueo de hace semanas contra la maquina real
    // seguia encerrando al operario contra el mock en local.
    // Reproducido: con el arbol limpio `tryConnect` da ok:true; sembrando
    // `rotechos.authFail=5` y un `authLockoutUntil` futuro, da ok:false y SIN
    // motivo, asi que quien llama no podia distinguir "espera 30 s" de
    // "teclea el PIN" y enseñaba el texto generico.
    // Ahora se devuelve el motivo y los segundos que faltan para que el
    // llamante diga la verdad. `_notifyLockout` sigue avisando igual.
    _notifyLockout();
    const _restanMs = _readStoredLockoutUntil() - Date.now();
    return {
      ok: false,
      body: null,
      motivo: `bloqueo-temporal`,
      segundos: Math.max(1, Math.ceil(_restanMs / 1000)),
    };
  }
  let result = await _oneConnectAttempt(_fetch, baseIp, usePin);

  if (result.cls === `ok`) { _resetAuthFailures(); return { ok: true, body: result.body }; }
  if (result.cls === `rejected`) {
    // HALLAZGO-8: si el primer intento ya entra con lockout (carrera entre
    // _noteAuthFailure + este punto), avisar y abortar sin overlay.
    if (_isLockedOut()) {
      _notifyLockout();
      // HUECO-5: motivo SIEMPRE asignado; cancelar el overlay no es un fallo de red.
      return { ok: false, body: null, motivo: `shield-aborted` };
    }
    // H-N6 (corregido 2026-08-27): con un trabajo EN CURSO no se abre el
    // overlay — taparia la UI a pantalla completa y el operario perderia de
    // vista el boton rojo del cockpit. Se devuelve el rechazo y que decida el
    // caller. OJO: esto suprime el OVERLAY, no el comando; el intento con el
    // PIN cacheado ya se ha hecho arriba y si valia, hemos salido por `ok`.
    if (sinOverlay) { return { ok: false, body: null, motivo: `overlay-suprimido` }; }
    // Mostrar overlay UNA vez; el operario teclea el PIN.
    const entered = await _showAuthOverlay(``);
    if (!entered) return { ok: false, body: null, motivo: `shield-aborted` };
    result = await _oneConnectAttempt(_fetch, baseIp, _getStoredPin());
    if (result.cls === `ok`) { _resetAuthFailures(); return { ok: true, body: result.body }; }
    if (result.cls === `rejected`) {
      _noteAuthFailure();
      if (_isLockedOut()) {
        // HALLAZGO-8: el operario acaba de meter el 5º PIN malo. Avisar
        // explícitamente que entra en lockout 30s con countdown real.
        _notifyLockout();
        return { ok: false, body: null, motivo: `shield-aborted` };
      }
      const again = await _showAuthOverlay(_t(`msg.pinOverlayRejected`, `PIN rechazado. Inténtalo de nuevo.`));
      if (again) {
        result = await _oneConnectAttempt(_fetch, baseIp, _getStoredPin());
        if (result.cls === `ok`) { _resetAuthFailures(); return { ok: true, body: result.body }; }
      }
    }
    return { ok: false, body: null, motivo: `shield-aborted` };
  }
  // HUECO-5: fallo de red. Con este motivo el call-site no culpa al escudo
  // (acta: docs/dev/hallazgos/2026-09-06_C-robustez-percibida.md §2.2).
  return { ok: false, body: null, motivo: `network-error` };
}

// ---
// VISIBILIDAD DEL PIN (ojito muestra/oculta) — HUECO-4 del carril 2.
// El PIN via por HTTP plano y se cachea en localStorage; mostrar el valor
// 5 segundos mientras se teclea no debilita nada. Defensivo: si el input
// no existe, no hace nada. Idempotente: si ya se le puso un botón, no lo
// duplica. El botón se marca con data-eye-of="<inputId>" para detectar
// re-montajes (el wizard recrea los inputs en cada paso).
// ---
function bindPinVisibilityToggle(inputId) {
  const input = document.getElementById(inputId);
  if (!input) return;
  // Si ya tiene el ojo puesto, no duplicamos.
  const parent = input.parentNode;
  if (parent && parent.dataset && parent.dataset.eyeOf === inputId) return;
  // Si el input ya está wrappeado con un div relativo, reusar.
  let wrap = null;
  if (parent && parent.tagName === `DIV` && parent.style && parent.style.position === `relative`) {
    wrap = parent;
  } else {
    wrap = document.createElement(`div`);
    wrap.style.cssText = `position:relative;flex:1;min-width:0`;
    parent.insertBefore(wrap, input);
    wrap.appendChild(input);
  }
  wrap.dataset.eyeOf = inputId;
  const btn = document.createElement(`button`);
  btn.type = `button`;
  btn.setAttribute(`aria-label`, `Mostrar u ocultar el PIN (5 s)`);
  btn.setAttribute(`title`, `Mostrar u ocultar el PIN (5 s)`);
  btn.dataset.i18nTitle = `aria.cfg.pin.showHide`;
  btn.dataset.i18nAriaLabel = `aria.cfg.pin.showHide`;
  // t_a50a4380 (UI-4): migrado a la clase .pin-eye-btn (rotechos.css). Antes
  // declaraba padding+font+line-height inline (~17px), un valor suelto
  // fuera de la escala. Ahora cuelga de --btn-h-xs (24) y el cssText se
  // reduce al layout (position/right/top/transform).
  btn.className = `pin-eye-btn`;
  btn.style.cssText = `position:absolute;right:6px;top:50%;transform:translateY(-50%)`;
  // 27-sep (análisis de interfaz, B4): icono SVG en vez de emoji (CLAUDE.md §8: sin emojis).
  const _ojo = (x) => `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7S1 12 1 12z"/>${x}</svg>`;
  const _EYE = _ojo(`<circle cx="12" cy="12" r="3"/>`);
  const _EYE_OFF = _ojo(`<path d="M3 3l18 18"/>`);
  btn.innerHTML = _EYE;
  let timer = null;
  let revealing = false;
  btn.addEventListener(`click`, () => {
    // Reveal 5 segundos: 5s no debilita nada (el PIN ya viaja en la URL sin
    // cifrar y se cachea en localStorage). Cogemos la decisión de DWC.
    if (timer) { clearTimeout(timer); timer = null; }
    if (revealing) {
      input.type = `password`;
      btn.innerHTML = _EYE;
      revealing = false;
      return;
    }
    input.type = `text`;
    btn.innerHTML = _EYE_OFF;
    revealing = true;
    timer = setTimeout(() => {
      input.type = `password`;
      btn.innerHTML = _EYE;
      revealing = false;
      timer = null;
    }, 5000);
  });
  // Si el operario cambia de pestaña mientras el PIN está revelado, contamos
  // los 5 s igual; el timer se dispara al volver si el documento estaba
  // en background. No es un agujero de seguridad (los 5 s son la cota).
  wrap.appendChild(btn);
}

// ---
// BIND PIN INPUT VALIDATOR (t_4f22bdc3, 2026-09-01)
//
// Liga el evento `input` (no `change`, queremos feedback en cada tecla) al
// input del PIN del panel Configuración (`#mcfgPinInput`) y muestra
// EN VIVO:
//   - el contador de caracteres restantes (24..0) en una esquina del input,
//   - el mensaje de error específico (qué carácter sobra, o "demasiado largo").
//
// Inserción DOM 100% runtime: el briefing prohibe tocar index.html, así
// que creamos los elementos auxiliares desde JS. Patrón "lazy decorator":
// la primera vez que se llama, crea el contador y el <div> de error; en
// llamadas sucesivas, los reusa. Idempotente: si rotechos-auth.js se
// carga dos veces (no debería, pero defensivo) no duplica nodos.
//
// La función también pinta el estado inicial (input vacío = "24 restantes,
// sin error"), para que el operario vea el contador ANTES de teclear.
//
// No bloquea: la decisión de GUARDAR (en `_setPin`, rotechos-config-modal.js)
// sigue siendo del botón. Aquí solo INFORMAMOS al operario.
//
// Devuelve el input (para que el caller pueda encadenar o testear).
// ---

// Construye (si no existe) el nodo contador + el nodo error y los inserta
// inmediatamente después del input. Devuelve { counterEl, errorEl } para
// que `bindPinInputValidator` los reutilice. Defensivo: si el input ya
// tiene un hermano decorado (segundo bind, montaje del wizard), reusa
// los nodos via `data-pin-validator-of`.
function _ensurePinValidatorNodes(input) {
  // Si ya hay nodos decorados bajo el MISMO padre, los reusamos.
  const parent = input.parentNode;
  if (!parent) return null;
  const sib = parent.querySelector(`[data-pin-validator-of="${input.id}"]`);
  if (sib) {
    return {
      rowEl: sib,
      counterEl: sib.querySelector(`[data-pin-validator-role="counter"]`),
      errorEl: sib.querySelector(`[data-pin-validator-role="error"]`),
    };
  }
  // Contador (esquina del input): `position:relative` en el padre lo
  // ancla abajo a la derecha; si el input ya está dentro de un wrapper
  // relativo (rotechos-auth.js:bindPinVisibilityToggle lo crea), reusamos
  // ese mismo padre para no anidar wrappers.
  // El CSS via `data-i18n-*`/`maxlength` ya posiciona el input; nosotros
  // añadimos un pequeño bloque flex al final con dos hijos: counter + error.
  const row = document.createElement(`div`);
  row.setAttribute(`data-pin-validator-of`, input.id);
  row.style.cssText = [
    `display:flex`,
    `justify-content:space-between`,
    `align-items:center`,
    `gap:8px`,
    `margin-top:4px`,
    `font-size:11px`,
    `line-height:1.3`,
    `color:var(--text-3)`,
  ].join(`;`);
  const errorEl = document.createElement(`span`);
  errorEl.setAttribute(`data-pin-validator-role`, `error`);
  errorEl.style.cssText = [
    `flex:1`,
    `color:var(--red)`,
    `font-family:var(--font-mono,monospace)`,
  ].join(`;`);
  const counterEl = document.createElement(`span`);
  counterEl.setAttribute(`data-pin-validator-role`, `counter`);
  counterEl.setAttribute(`aria-live`, `polite`);
  counterEl.style.cssText = [
    `flex:0 0 auto`,
    `font-family:var(--font-mono,monospace)`,
    `color:var(--text-3)`,
  ].join(`;`);
  row.appendChild(errorEl);
  row.appendChild(counterEl);
  // Inserción: el input vive dentro de un `<div style="display:flex;gap:8px">`
  // (index.html:1067) que también contiene el input de confirmación. Salir
  // de ese wrapper e insertar DESPUÉS de él para que el row ocupe su
  // propia línea debajo de los dos inputs.
  const grand = parent.parentNode;
  if (grand && grand.nodeType === 1) {
    grand.insertBefore(row, parent.nextSibling);
  } else {
    parent.appendChild(row);
  }
  return { rowEl: row, counterEl, errorEl };
}

// Construye el mensaje de error a partir del resultado de `validateM551Pin`.
// Tres ramas: vacío (no error, sin mensaje), demasiado-largo (genérico),
// charset (específico por carácter). Usa `t(..., fallback)` con la clave
// `msg.pinCharset.<motivo>` para que la i18n (ES/EN) decida el texto.
function _pinErrorMessage(result) {
  if (result.ok) return ``;
  switch (result.motivo) {
    case `demasiado-largo`:
      return _t(
        `msg.pinCharset.demasiado-largo`,
        `Máximo 24 caracteres (actual: {n}).`.replace(`{n}`, String(24 + 1))
      ).replace(`{n}`, String(24 + 1));
    case `espacio`:
      // Espacio explícito por nombre — el operario sabe qué pasa cuando
      // intenta una passphrase típica.
      return _t(
        `msg.pinCharset.espacio`,
        `El PIN no admite espacios. Quita el espacio y vuelve a teclear.`
      );
    case `caracter-invalido`: {
      // Mostramos el carácter concreto entre comillas angulares para que
      // sea inequívoco cuando es invisible (espacio, tab) o unicode raro.
      const ch = result.caracter;
      let display;
      if (ch === ` `) display = `<espacio>`;
      else if (ch === `\t`) display = `<tab>`;
      else display = `<${ch}>`;
      return _t(
        `msg.pinCharset.caracter-invalido`,
        `Carácter no permitido: ${display}. Solo se admiten letras, dígitos y los símbolos - _ . @ # ! ? , :.`
      ).replace(`{ch}`, display);
    }
    default:
      return _t(
        `msg.pinCharset.desconocido`,
        `PIN no válido. Revisa el charset y la longitud.`
      );
  }
}

// Pinta el resultado de validateM551Pin en el par counterEl/errorEl.
// `count` es lo que se muestra en el contador; `msg` es lo que va al
// errorEl. Si msg es '' (sin error), errorEl se oculta para no comer
// espacio visual cuando el operario aún no ha tecleado.
function _paintPinValidation(counterEl, errorEl, result) {
  if (!counterEl || !errorEl) return;
  // Contador: "X restantes" o "X restantes · N/24" cuando hay error de
  // longitud para que el operario vea que se ha pasado. La unidad "car."
  // cabe en ES y EN (catalán sería "caràct." — no aplica aquí).
  let txt = _t(`msg.pinCharset.restantes`, `${result.restantes} restantes`).replace(
    `{n}`, String(result.restantes)
  );
  if (result.motivo === `demasiado-largo`) {
    // Cuando el operario ya ha pasado el límite, el contador muestra el
    // exceso en negativo para que se vea claro ("-1 de 24"). Pero como
    // el HTML tiene maxlength=24, en navegadores modernos el input NUNCA
    // llega a 25+ por teclado — solo por paste. Aún así defendemos.
    txt = _t(`msg.pinCharset.excedido`, `Excedido por {n}`).replace(`{n}`, `1`);
  }
  counterEl.textContent = txt;
  const msg = _pinErrorMessage(result);
  if (msg) {
    errorEl.textContent = msg;
    errorEl.style.display = ``;
  } else {
    errorEl.textContent = ``;
    errorEl.style.display = `none`;
  }
}

// eslint-disable-next-line no-unused-vars -- expuesto en window.rotechosAuth (consumido por rotechos-config-modal.js y rotechos-modules.js)
function bindPinInputValidator(inputId) {
  const input = document.getElementById(inputId);
  if (!input) return null;
  // Si ya está bindeado, no duplicamos listeners (mismo patrón que
  // bindPinVisibilityToggle).
  if (input.dataset && input.dataset.pinValidatorOf === `1`) return input;
  const nodes = _ensurePinValidatorNodes(input);
  if (!nodes) return input;
  const { counterEl, errorEl } = nodes;
  // Estado inicial: contador a 24/24, sin error (operario aún no ha
  // tecleado). Hacemos la primera pintura SIN disparar el evento `input`
  // para no llamar a validateM551Pin antes de tener DOM estable.
  _paintPinValidation(counterEl, errorEl, validateM551Pin(``));
  input.addEventListener(`input`, () => {
    // Pegar (paste) puede meter 100+ chars aunque maxlength=24: aunque
    // los navegadores modernos TRUNCAN al pegar, defendemos pasando
    // por la validación igualmente (la primitiva ya maneja >24).
    _paintPinValidation(counterEl, errorEl, validateM551Pin(input.value));
  });
  input.dataset.pinValidatorOf = `1`;
  return input;
}

// API pública mínima: primitivas puras + helper impuro. Las impuras
// (overlay, localStorage) se prueban en e2e y por contrato del código.
window.rotechosAuth = Object.freeze({
  buildRRConnectUrl,
  classifyRRConnectResponse,
  // t_4f22bdc3 (2026-09-01): charset + longitud M551. Pura: 0 DOM,
  // 0 red, 0 localStorage. La UI la llama en cada `input` para feedback
  // en vivo y la ruta de "Guardar PIN" para confirmar antes de persistir.
  validateM551Pin,
  tryConnect,
  getStoredPin: _getStoredPin,
  setStoredPin: _setStoredPin,
  clearStoredPin: _clearStoredPin,
  bindPinVisibilityToggle,
  // t_4f22bdc3 (2026-09-01): bind del validador en vivo al input. Llamar
  // UNA vez por input (idempotente). Crea el contador y el error como
  // nodos hermanos sin tocar el HTML estático.
  bindPinInputValidator,
  // Set permitido exportado para tests y para que cualquier otro módulo
  // (rotechos-config-persist.js, rotechos-modules.js) reuse la misma
  // fuente de verdad en lugar de duplicar la regex.
  M551_PIN_CHARSET_REGEX,
  M551_PIN_MAX_LEN,
  // S-N3 (informe 2026-08-18 v3): el bloqueo por 5 intentos/30s ya lo
  // respeta el escudo (`tryConnect` consulta _isLockedOut). Pero el camino
  // `cfgPersistPin` (rotechos-config-persist.js:458) podía tentar PINs
  // nuevos saltándose el bloqueo. Exportamos la consulta para que ese
  // módulo decida abortar con toast en lugar de seguir. Sincronizada con
  // el cartel de i18n `msg.pinLockoutWarn` (rotechos-i18n-dynjs.js:434)
  // ya existente y usado por `_notifyLockout`.
  isLockedOut: _isLockedOut,
  // t_042f109c (2026-08-18): PIN de fábrica 123456789, cambiable y
  // honesto sobre lo que protege. El wizard (paso 12) y el panel
  // Configuración → PIN HTTP consultan DEFAULT_FACTORY_PIN e isFactoryPin
  // para mostrar el aviso "este PIN es de fábrica, te recomendamos
  // cambiarlo" sin tener que duplicar el literal en cada sitio.
  DEFAULT_FACTORY_PIN,
  isFactoryPin,
});

// ---
// AUTOINIT del ojo en los inputs del panel PIN (HUECO-4). El HTML
// (`#mcfgPinInput` y `#mcfgPinInputConfirm`) vive en index.html:1027 con
// `display:none` en el panel. Como este script se carga con `defer`, el
// DOM ya está parseado cuando llegamos aquí, así que el bind es directo.
// Los inputs del wizard se montan en runtime cuando se pinta el paso 12
// (rotechos-modules.js:269) y se bindean desde allí.
//
// t_4f22bdc3 (2026-09-01): añadimos `bindPinInputValidator` para que el
// panel Configuración muestre el contador de caracteres restantes y los
// errores específicos de charset en vivo, sin esperar a pulsar "Guardar".
// El validador también se bindea en el input de confirmación (mismo
// contador y misma lógica) para que el operario vea los dos campos en
// el mismo estado. El wizard hace su propio bind manual porque el input
// se crea runtime.
// ---
try {
  bindPinVisibilityToggle(`mcfgPinInput`);
  bindPinVisibilityToggle(`mcfgPinInputConfirm`);
  bindPinInputValidator(`mcfgPinInput`);
  bindPinInputValidator(`mcfgPinInputConfirm`);
} catch (_) { /* defensivo: nunca debe romper la carga del módulo */ }
