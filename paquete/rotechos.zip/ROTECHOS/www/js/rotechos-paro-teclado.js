// ---
// rotechos-paro-teclado.js — PARO SIEMPRE VISIBLE CON EL TECLADO ABIERTO
//
// TARJETA t_1f6006ac · FASE 1 del plan de fragmentación del monolito
// (docs/dev/hallazgos/2026-09-09_monolito-diagnostico-y-plan-de-fragmentacion.md §3).
// Extraído del monolito rotechos.js (L6719-6752, bloque 19) tal cual: 34 líneas,
// IIFE autocontenido, cero dependencias externas. Se carga como `defer` ANTES
// de rotechos.js para que el listener `vv.resize` esté vivo desde el primer
// paint — la decisión 2026-09-04 (cuando el bug original fue arreglado) ya
// establecía que el primer teclado en iOS no debe esperar a boot.
//
// EL PROBLEMA, que no es el que parece: el PARO es `position:sticky; top:0`
// dentro de .col-right, asi que "un teclado que sube desde abajo" no deberia
// taparlo nunca. Lo que pasa en iOS es otra cosa — al abrirse el teclado el
// VISUAL viewport encoge y se desplaza hacia abajo sobre el de LAYOUT, y un
// sticky se pega al de layout. Resultado: el PARO se queda pegado arriba de una
// zona que ya no se ve. Sigue ahi, en su sitio, y el operario no lo tiene.
//
// EL ARREGLO: compensar ese desplazamiento con un translateY del mismo tamano.
// Se hace con una variable CSS que vale 0px mientras no hay teclado, de modo
// que el caso normal —y por tanto todos los tests existentes— no cambia ni un
// pixel: `transform: translateY(0px)` no altera el flujo.
//
// Se usa transform y no `position:fixed` a proposito: fixed dentro de una
// columna obliga a reponer ancho y bordes a mano, y ahi es donde se rompen las
// puertas de scroll y visibilidad.
//
// No expone nada en `window.*` — el centinela de la sesión (rotura = bug del
// PARO móvil, no API rota) es que la variable CSS `--vv-shift` se actualice.
// rotechos.css:343 la consume con fallback a 0px, asi que un fallo de carga
// de este módulo no rompe el layout: degrada al caso sin compensar.
// ---
(function paroSobreTeclado() {
  const vv = window.visualViewport;
  if (!vv) return;                       // sin la API no se toca nada
  let ultimo = -1;
  const aplicar = () => {
    // offsetTop es cuanto ha bajado el viewport visible sobre el de layout.
    // Sin teclado es 0 y la variable se queda en 0px.
    const off = Math.max(0, Math.round(vv.offsetTop));
    if (off === ultimo) return;          // no repintar si no ha cambiado
    ultimo = off;
    document.documentElement.style.setProperty(`--vv-shift`, `${off}px`);
  };
  vv.addEventListener(`resize`, aplicar);
  vv.addEventListener(`scroll`, aplicar);
  aplicar();
})();