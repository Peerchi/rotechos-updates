/* ---
 * rotechos-firstcut.js — Defer module: checklist 'Mi primer corte' (cockpit).
 *
 * Extraído del monolito rotechos.js en MON-FIRSTCUT (jul-2026). Saca las 45
 * líneas del bloque FIRSTCUT: solo LEE estado (no escribe), monta la tarjeta
 * en el DOM (#firstcutCard) y arranca un setInterval de 1000 ms que evalúa
 * si los pasos del checklist están hechos.
 *
 * Notas de la extracción (no las deshagas sin leer el contrato):
 *
 *  - Este módulo es PURO CONSUMIDOR. Lee AppState.limits.allHomed,
 *    SM.loadedFile, DRO.tMcs/tWcs y SM.current (de los módulos rotechos,
 *    rotechos-dom, rotechos-poll). NO escribe sobre ninguno.
 *
 *  - El interval (this._iv) es propiedad del módulo. Se limpia al
 *    dismiss() o cuando el checklist detecta que el trabajo está RUNNING
 *    y se autodispara. Como este módulo es el único initFirstcut del
 *    sistema (lo era antes y lo sigue siendo), NO hay riesgo de interval
 *    duplicado tras la extracción.
 *
 *  - Carga con defer, DESPUÉS de rotechos.js, igual que el resto de los
 *    módulos extraídos del monolito. Por eso el IIFE de autoinicialización
 *    se dispara al cargar el script.
 * --- */
'use strict';

const FIRSTCUT = {
  materialOk: false,
  visible: false,
  init() {
    const dismissed = STORE.get(`wizard.firstCut`);
    const card = $(`firstcutCard`);
    if (!card || dismissed === `done`) return;
    this.visible = true;
    // La tarjeta nace con la clase `telem-vi-span-cb45` en index.html:2387, y
    // esa clase es `display:none` (rotechos.css:2960). Se la puso el sprint de
    // migracion de estilos inline. Un `style.display = ''` NO la vence: vaciar
    // el inline deja mandar a la clase, asi que la tarjeta del primer corte no
    // se mostraba NUNCA. Hay que retirar la clase, que es justo lo que init()
    // pretende hacer. Lo encontro obrera3 (t_2d753e23) al perseguir por que
    // fallaba su spec: el test tenia razon y el producto estaba roto.
    // 2026-08-21: la migracion de estilos renombro la clase en index.html:2361
    // a `telem-value` (rotechos.css:2987, tambien display:none) y NADIE actualizo
    // esta linea, asi que el remove dejo de acertar y la tarjeta volvio a no
    // mostrarse NUNCA. Se retiran las DOS: la vieja por si algun index sin
    // regenerar aun la trae, y la que oculta de verdad hoy.
    card.classList.remove(`telem-vi-span-cb45`);
    card.classList.remove(`telem-value`);
    // La tarjeta nacio como position:fixed en la esquina inferior derecha, y ahi
    // caia ENCIMA del panel VELOCIDADES (OVERRIDE): medido a 1280x800, la
    // tarjeta ocupaba (1014,571)-(1266,786) y #feedPlus esta en (1242,575). Los
    // clicks llegaban igual —hay pointer-events:none en su chrome— pero el
    // operario no veia los botones que pulsaba.
    // Reservar hueco con padding no servia: .col-right tiene overflow-y auto y
    // su contenido ya no cabe (scrollHeight 821 sobre 736 de alto), asi que el
    // padding solo alarga el scroll y no aparta nada.
    // La movemos DENTRO de la columna derecha: alli es un bloque mas del flujo
    // (ver .col-right > #firstcutCard en rotechos.css), empuja en vez de tapar
    // y se desplaza con la columna. Si esa columna no existe —maquetas viejas o
    // el pendant— se queda donde estaba y sigue funcionando como antes.
    // typeof: el sandbox de los tests unitarios carga este modulo sin un DOM
    // completo, y usar `document` a pelo lo tumbaba con "document is not
    // defined". La reubicacion es una mejora de maquetacion, no el contrato del
    // modulo: si no hay DOM, se salta y todo lo demas sigue igual.
    // 2026-08-29: el destino pasa a ser el ESTADO VACIO DEL VISOR, no el rail.
    // El motivo original de sacarla de position:fixed —que tapaba el panel de
    // VELOCIDADES— ya no aplica: ese panel se fue al centro con la propuesta C.
    // Y el sitio natural de esta guia es donde el operario esta mirando cuando
    // aun no ha cargado nada: el centro dice "Sin archivo cargado" y el paso 3
    // de la guia es justamente "Cargar el G-code".
    // Se conserva que aparezca SOLA (no detras de un enlace): quien estrena la
    // maquina no sabe que tiene que buscarla.
    // Si el estado vacio no existe —maquetas viejas, pendant, o un viewport
    // donde no cabe— cae al rail como antes, que sigue funcionando.
    const _doc = (typeof document !== `undefined`) ? document : null;
    // Se cuelga de #vizPlaceholder, no de #vizEmpty: este ultimo tiene su propia
    // anchura maxima (420 px medidos) y meterla dentro estrujaba el mensaje.
    const _centro = _doc ? _doc.getElementById(`vizPlaceholder`) : null;
    const _col = _doc ? _doc.querySelector(`.col-right`) : null;
    // El criterio NO puede ser el ancho. La tarjeta mide 279 px y el visor solo
    // 247 a 1280x720: con `innerWidth >= 1025` se colgaba del centro igual y
    // salia RECORTADA 58 px por .vizWrap — el paso 1 de la guia, medio tapado,
    // en la pantalla que estrena la maquina. A ese mismo ancho la columna
    // derecha tiene 302 px libres, o sea que cabe entera sin apretar nada.
    // Se decide por ALTO DISPONIBLE, y medido: si el visor no da para la
    // tarjeta, va al rail. Los 16 px son el respiro para que no quede pegada.
    const _viz = _doc ? _doc.getElementById(`vizCard`) : null;
    const _cabe = !!(_centro && _viz && _viz.clientHeight >= card.offsetHeight + 16);
    const _destino = (_centro && window.innerWidth >= 1025 && _cabe) ? _centro : _col;
    if (_destino && card.parentElement !== _destino) _destino.appendChild(card);
    // Clase en vez de :has() en el CSS. Un selector :has() se reevalua en cada
    // mutacion del DOM y este cockpit muta cada segundo (sondeo, DRO, estado);
    // al medirlo, la suite e2e paso de 1 fallo por carga a 10. La clase la
    // pone quien sabe la respuesta —este modulo— y no cuesta nada.
    // Se pone Y SE QUITA: si en un resize deja de caber y la tarjeta se va al
    // rail, el margen de 300 px que abre esta clase se quedaria reservado para
    // nadie, dejando el estado vacio descentrado sin motivo.
    _centro?.classList.toggle(`con-guia`, _destino === _centro);
    card.style.display = ``;
    // La tarjeta es position:fixed (rotechos.css:1988) y se solapa con el
    // acciones inferiores del cockpit (p.ej. en tests/e2e-primer-arranque-
    // trabajo.spec.js:286). Sin este truco, el subtree intercepta clicks de
    // los botones del cockpit que están por debajo (ARR-3b). El chrome de
    // la tarjeta (head, steps, foot) NO necesita bloquear el cockpit — solo
    // los botones interactivos (fc-act, fcClose). El fix es scoped aqui, en
    // init(), para no tocar rotechos.css desde un modulo extraido.
    card.style.pointerEvents = `none`;
    card.querySelectorAll(`.fc-act, #fcClose`).forEach((el) => { el.style.pointerEvents = `auto`; });
    $(`fcClose`)?.addEventListener(`click`, () => this.dismiss());
    card.querySelector(`[data-fc=home] .fc-act`)?.addEventListener(`click`, () => $(`btnQaHomeAll`)?.click());
    card.querySelector(`[data-fc=material] .fc-act`)?.addEventListener(`click`, () => { this.materialOk = !this.materialOk; this.update(); });
    card.querySelector(`[data-fc=file] .fc-act`)?.addEventListener(`click`, () => $(`vizCard`)?.scrollIntoView({ behavior: `smooth`, block: `center` }));
    card.querySelector(`[data-fc=origin] .fc-act`)?.addEventListener(`click`, () => $(`btnQaSondaZ`)?.click());
    card.querySelector(`[data-fc=start] .fc-act`)?.addEventListener(`click`, () => $(`btnPlayPause`)?.click());
    this._iv = setInterval(() => this.update(), 1000);
    this.update();
  },
  dismiss() {
    if (this._iv) { clearInterval(this._iv); this._iv = null; }
    STORE.set(`wizard.firstCut`, `done`);
    const card = $(`firstcutCard`);
    if (card) card.style.display = `none`;
    this.visible = false;
  },
  update() {
    if (!this.visible) return;
    const st = {
      home: !!(AppState.limits && AppState.limits.allHomed),
      material: this.materialOk,
      file: !!SM.loadedFile,
      origin: [0, 1, 2].some((i) => Math.abs((DRO.tMcs[i] ?? 0) - (DRO.tWcs[i] ?? 0)) >= 0.001),
      start: SM.current === STATES.RUNNING,
    };
    for (const k in st) {
      const row = $q(`#firstcutCard [data-fc=${k}]`);
      row && row.classList.toggle(`fc-done`, !!st[k]);
    }
    if (st.start) {
      toast(t(`fc.congrats`, `Primer corte en marcha. El checklist no volverá a aparecer.`), `ok`);
      this.dismiss();
    }
  },
};
(function initFirstcut() { FIRSTCUT.init(); })();

// eslint-disable-next-line no-unused-vars
const FIRST_CUT = window.FIRST_CUT = FIRSTCUT;
