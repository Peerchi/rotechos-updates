/* ---
 * RotechOS — VIZ 2D / 3D Visualizador de trayectoria G-code
 * Extraído de rotechos.js. Debe cargarse DESPUÉS de rotechos.js —
 * usa $, SM, STATES, RRF, CFG, toast, confirmDialog, log,
 * _clearPollTimer, startPoll, clearJob.
 * --- */
// Invocado desde rotechos.js (cross-file); ESLint no ve ese uso:
/* exported vizLoadGCode */

// ---
// VIZ — Visualizador 2D de trayectoria G-code
// ---
const VIZ = {
  // La caché solo vive durante esta sesión del navegador. Es una ayuda visual,
  // nunca sustituye al fichero confirmado por RRF.
  CACHE_KEY: `rotechos.viz.local-cache.v1`,
  CACHE_MAX_CHARS: 1000000,
  canvas: $(`vizCanvas`),
  ctx: null,
  _paths: [],
  get paths() {
    return this._paths;
  },
  set paths(val) {
    this._paths = val;
    if (!val || !val.length) {
      this.coords = null;
      this.pathMeta = null;
    }
  },
  coords: null,
  pathMeta: null,
  activeWorker: null,
  activeBlobUrl: null,
  bounds: null,
  scale: 1,
  offsetX: 0,
  offsetY: 0,
  toolX: null,
  toolY: null,
  toolZ: null,
  isPanning: !1,
  panStart: null,
  panOffset: null,
  _interactiveMoveBusy: !1,
  _interactiveMoveTarget: null,
  _interactiveMoveTimer: null,
  raf: 0,
  resizeRaf: 0,
  _seq: 0,
  _dirty: !0,
  _userViewAdjusted: !1,
  _autoFitKey: null,
  initialized: !1,
  get dirty() {
    return this._dirty;
  },
  set dirty(value) {
    this._dirty = !!value;
    if (this._dirty) {
      this._schedule();
    }
  },
  _isVisible() {
    if (document.hidden || !this.canvas) return !1;
    if (typeof this.canvas.getClientRects === `function`) {
      if (!this.canvas.getClientRects().length) return !1;
      if (typeof getComputedStyle === `function`) {
        const style = getComputedStyle(this.canvas);
        if (style.display === `none` || style.visibility === `hidden`) return !1;
      }
    }
    return typeof this.canvas.offsetParent === `undefined` || this.canvas.offsetParent !== null;
  },
  _schedule() {
    if (this.raf || !this._isVisible() || (!this.dirty && !this._lerpActive)) return;
    this.raf = requestAnimationFrame(() => {
      this.raf = 0;
      this.loop();
    });
  },
  init() {
    if (this.initialized) return;
    this.initialized = !0;
    ((this.ctx = this.canvas.getContext(`2d`)),
      this.resize(),
      window.addEventListener(`resize`, () => {
        if (this.resizeRaf) return;
        this.resizeRaf = requestAnimationFrame(() => {
          this.resizeRaf = 0;
          this.resize();
        });
      }),
      // Si la pestaña/panel estaba oculto cuando se cargó el G-code, el `loop()`
      // no pintó (chequea document.hidden). Forzar redibujado al volver visible
      // resuelve "el visor no muestra la pieza tras cargar un archivo".
      // FIX-3: además, al ocultarse cancela el espejo del pendant (mpgVizMirror)
      // y al volver re-arranca AMBOS bucles con la guarda `if (!this.raf) ...`
      // para que no quede un bucle duplicado.
      document.addEventListener(`visibilitychange`, () => {
        if (document.hidden) {
          if (this.raf) { cancelAnimationFrame(this.raf); this.raf = 0; }
          if (this.resizeRaf) { cancelAnimationFrame(this.resizeRaf); this.resizeRaf = 0; }
          if (mpgVizMirror.raf) { cancelAnimationFrame(mpgVizMirror.raf); mpgVizMirror.raf = 0; }
          return;
        }
        (this.resize(), (this.dirty = !0), this._schedule());
        mpgVizMirror._seq = -1;
        scheduleMpgVizMirror();
      }),
      this.bindEvents(),
      this._schedule());
    const pendantWrap = $(`mpgVizWrap`);
    if (pendantWrap && typeof MutationObserver === `function`) {
      this._mpgObserver = new MutationObserver(() => scheduleMpgVizMirror());
      this._mpgObserver.observe(pendantWrap, { attributes: !0, attributeFilter: [`class`, `style`] });
    }
  },
  resize() {
    const wrap = $(`vizWrap`),
      dpr = window.devicePixelRatio || 1,
      w = wrap.clientWidth || this.canvas.offsetWidth || 400,
      h = wrap.clientHeight || this.canvas.offsetHeight || 360;
    w === 0 ||
      h === 0 ||
      ((this.canvas.width = w * dpr),
      (this.canvas.height = h * dpr),
      (this.canvas.style.width = w + `px`),
      (this.canvas.style.height = h + `px`),
      this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0),
      (this.dirty = !0));
  },
  bindEvents() {
    const c = this.canvas;
    (c.addEventListener(
      `wheel`,
      (e) => {
        e.preventDefault();
        this._userViewAdjusted = !0;
        const f = e.deltaY < 0 ? 1.15 : 1 / 1.15,
          rect = c.getBoundingClientRect(),
          mx = e.clientX - rect.left,
          my = e.clientY - rect.top;
        ((this.offsetX = mx - (mx - this.offsetX) * f),
          (this.offsetY = my - (my - this.offsetY) * f),
          (this.scale *= f),
          (this.dirty = !0));
      },
      { passive: !1 },
    ),
      c.addEventListener(`pointerdown`, (e) => {
        ((this.isPanning = !0),
          (this.panStart = { x: e.clientX, y: e.clientY }),
          (this.panOffset = { x: this.offsetX, y: this.offsetY }),
          $(`vizWrap`).classList.add(`panning`),
          c.setPointerCapture(e.pointerId));
      }),
      c.addEventListener(`pointermove`, (e) => {
        this.isPanning &&
          ((this.offsetX = this.panOffset.x + (e.clientX - this.panStart.x)),
          (this.offsetY = this.panOffset.y + (e.clientY - this.panStart.y)),
          (this._userViewAdjusted = !0),
          (this.dirty = !0));
      }),
      c.addEventListener(`pointerup`, () => {
        ((this.isPanning = !1),
          (this._isRotating = !1),
          $(`vizWrap`).classList.remove(`panning`));
      }),
      c.addEventListener(`contextmenu`, (e) => e.preventDefault()),
      c.addEventListener(`pointerdown`, (e) => {
        if (e.button === 2 && this.viewMode === `3d`) {
          ((this._isRotating = !0),
            (this._rotStart = { x: e.clientX, y: e.clientY }),
            (this._rotStartAngles = { x: this.rotAngleX, y: this.rotAngleY }),
            c.setPointerCapture(e.pointerId),
            e.preventDefault());
        }
      }),
      c.addEventListener(`pointermove`, (e) => {
        if (this._isRotating) {
          this._userViewAdjusted = !0;
          const dx = (e.clientX - this._rotStart.x) * 0.01,
            dy = (e.clientY - this._rotStart.y) * 0.01;
          ((this.rotAngleX = this._rotStartAngles.x + dy),
            (this.rotAngleY = this._rotStartAngles.y + dx),
            (this.rotAngleX = Math.max(-1.5, Math.min(1.5, this.rotAngleX))),
            (this.dirty = !0));
        }
      }),
      c.addEventListener(`dblclick`, (e) => this.moveToCanvasPoint(e)));
  },
  moveToCanvasPoint(e) {
    if (this.viewMode !== `top` || !this.coords?.length) {
      toast(t(`msg.vizMoveUnavailable`, `Visor: carga un G-code y usa la vista superior para mover.`), `warn`);
      return;
    }
    const rect = this.canvas.getBoundingClientRect();
    this.moveToWcs((e.clientX - rect.left - this.offsetX) / this.scale, -(e.clientY - rect.top - this.offsetY) / this.scale);
  },
  async moveToWcs(x, y) {
    if (this._interactiveMoveBusy) {
      toast(t(`msg.vizMoveBusy`, `Visor: espera a que termine el movimiento anterior.`), `warn`);
      return;
    }
    if (machineMoveBlocked(true)) return;
    if (!AppState.limits.allHomed) {
      toast(t(`msg.vizMoveNeedsHome`, `Visor: ejecuta HOME antes de mover a una posición.`), `warn`);
      return;
    }
    if (SM.busy || (SM.current !== STATES.IDLE && SM.current !== STATES.READY)) {
      toast(t(`msg.jogBlocked`, `Jog bloqueado: hay una macro o un comando en marcha — espera a que termine (el piloto RUNNING de la barra superior se apagará)`), `warn`);
      return;
    }
    const limits = window._softLimits || {}, offsets = window._wcsOffsets || {};
    const mx = x + (offsets.X ?? 0), my = y + (offsets.Y ?? 0);
    const inAxis = (axis, value) => Number.isFinite(value) && Number.isFinite(limits[axis]?.min)
      && Number.isFinite(limits[axis]?.max) && value >= limits[axis].min && value <= limits[axis].max;
    if (!inAxis(`X`, mx) || !inAxis(`Y`, my)) {
      toast(t(`msg.vizMoveOutsideArea`, `Visor: el punto está fuera del área configurada.`), `warn`);
      return;
    }
    const tx = x.toFixed(3), ty = y.toFixed(3);
    this._interactiveMoveBusy = !0;
    this._interactiveMoveTarget = { x, y };
    clearTimeout(this._interactiveMoveTimer);
    this._interactiveMoveTimer = setTimeout(() => this.clearInteractiveMove(), 60000);
    const cmd = `G90\nG53 G1 Z{max(move.axes[2].machinePosition, move.axes[2].max - global.safe_clearance)} F{global.z_raise_speed}\nM400\nG1 X${tx} Y${ty} F{global.travel_feed}`;
    const ok = await RRF.gcode(cmd);
    if (!ok) {
      this.clearInteractiveMove();
      toast(t(`msg.vizMoveErr`, `Visor: no se pudo iniciar el movimiento.`), `err`);
      return;
    }
    log(`Visor: Z segura → X${tx} Y${ty}`, `cmd`);
    toast(t(`msg.vizMoveSent`, `Visor: Z sube a altura segura y va a X${tx} Y${ty}.`, { x: tx, y: ty }), `info`);
  },
  clearInteractiveMove() {
    clearTimeout(this._interactiveMoveTimer);
    this._interactiveMoveTimer = null;
    this._interactiveMoveTarget = null;
    this._interactiveMoveBusy = !1;
  },
  loop() {
    if (!this._isVisible()) { this.raf = 0; return; }
    if (this.dirty) {
      this.draw();
      this.dirty = !1;
    }
    this._schedule();
  },
  draw() {
    const c = this.canvas,
      ctx = this.ctx,
      W = c.width / (window.devicePixelRatio || 1),
      H = c.height / (window.devicePixelRatio || 1),
      isDark = document.documentElement.dataset.theme !== `light`;

    this._seq = (this._seq | 0) + 1;
    scheduleMpgVizMirror();
    ctx.clearRect(0, 0, W, H);

    // 17-oct: el visor dibuja en coordenadas de PIEZA (las del fichero). La mesa
    // se pinta en ese mismo marco, desplazada por el WCS activo, así que la pieza
    // y la fresa quedan en su sitio real dentro de la máquina. Sin G-code se
    // sigue viendo la mesa y la fresa; sin límites leídos no se inventa área.
    const _sl = window._softLimits || {},
      _wcs = window._wcsOffsets || {},
      env = this.machineEnvelopeWork(_sl, _wcs);
    const hasPaths = !!(this.paths && this.paths.length);
    if (!hasPaths && !env && this.toolX === null) return;
    const fitKey = this._fitInputKey(env);
    if (!this._userViewAdjusted && fitKey !== this._autoFitKey) this.fitView();

    this.drawGrid(ctx, W, H, isDark);

    (ctx.save(),
      ctx.translate(this.offsetX, this.offsetY),
      ctx.scale(this.scale, this.scale));
    const _pj = this._projector();
    if (env) this.drawEnvelope(ctx, env, _pj, _wcs, isDark);

    if (hasPaths) {
      const viewHash = this.viewMode + '_' + (this.viewMode === `3d` ? this.rotAngleX + '_' + this.rotAngleY : ``);
      // t_e1f3f979: el overlay rojo depende de los soft limits y los WCS, que
      // pueden cambiar en runtime (operario edita M208 desde Configuración).
      // Sin este sufijo, el cacheo del path rojo queda obsoleto al cambiar
      // M208 y el operario sigue viendo el aviso antiguo. Usamos JSON estable:
      // es barato (3 ejes × 2 números + 3 offsets) y solo se ejecuta cuando
      // el resto del cacheo YA iba a rehacerse.
      const _sl0 = _sl;
      const _wcs0 = _wcs;
      const limitsHash = JSON.stringify({
        lX: [_sl0.X?.min ?? null, _sl0.X?.max ?? null],
        lY: [_sl0.Y?.min ?? null, _sl0.Y?.max ?? null],
        lZ: [_sl0.Z?.min ?? null, _sl0.Z?.max ?? null],
        wX: _wcs0.X ?? null, wY: _wcs0.Y ?? null, wZ: _wcs0.Z ?? null,
      });
      const totalSegments = this.pathMeta ? (this.pathMeta.length / 3) : 0;
      const isLarge = totalSegments > 5000;
      const isRotating = this._isRotating && isLarge;
      const drawHash = viewHash + '_' + limitsHash + (isRotating ? '_rot' : '');
      if (!this._cachedPaths || this._cachedViewHash !== drawHash) {
        const pRapid = new Path2D();
        const pCut = new Path2D();
        // Decimación: agresiva al rotar (~2000 segs objetivo) y SUAVE en reposo
        // solo para archivos enormes (>80k segs), para que el stroke no dé tirones
        // en pan/zoom. Los trabajos normales (<80k) se dibujan a full detalle (step 1).
        const STATIC_DECIMATE_OVER = 80000;
        const step = isRotating
          ? Math.ceil(totalSegments / 2000)
          : (totalSegments > STATIC_DECIMATE_OVER ? Math.ceil(totalSegments / STATIC_DECIMATE_OVER) : 1);
        const stepIndex = step * 3;
        const meta = this.pathMeta;
        const coords = this.coords;
        if (meta && coords) {
          for (let idx = 0; idx < meta.length; idx += stepIndex) {
            const type = meta[idx];
            const start = meta[idx+1];
            const len = meta[idx+2];
            if (len < 2) continue;
            const path = type === 0 ? pRapid : pCut;
            const cIdx = start * 3;
            const p0 = _pj({ x: coords[cIdx], y: coords[cIdx+1], z: coords[cIdx+2] });
            path.moveTo(p0.x, p0.y);
            for (let i = 1; i < len; i++) {
              const pi = _pj({ x: coords[cIdx + i*3], y: coords[cIdx + i*3 + 1], z: coords[cIdx + i*3 + 2] });
              path.lineTo(pi.x, pi.y);
            }
          }
        }
        // t_e1f3f979 (regla H): overlay ROJO sobre los segmentos que caen fuera
        // del recorrido. Se calcula junto al cacheo principal (mismo viewHash)
        // para no rehacer el bucle. NO toca el motor — solo añade un Path2D.
        // Si los soft limits no están disponibles (máquina sin M208 leído,
        // tests, mock-server) NO pinta nada: el briefing prohíbe inventar un
        // área por defecto.
        const pOut = new Path2D();
        const _sl = window._softLimits || {};
        const _wcs = window._wcsOffsets || { X: 0, Y: 0, Z: 0 };
        const _hasLimits = _sl && (_sl.X || _sl.Y || _sl.Z) &&
          ((_sl.X && (_sl.X.min != null || _sl.X.max != null)) ||
           (_sl.Y && (_sl.Y.min != null || _sl.Y.max != null)) ||
           (_sl.Z && (_sl.Z.min != null || _sl.Z.max != null)));
        if (meta && coords && _hasLimits) {
          const oX = _wcs.X ?? 0, oY = _wcs.Y ?? 0, oZ = _wcs.Z ?? 0;
          const lXmin = _sl.X?.min, lXmax = _sl.X?.max;
          const lYmin = _sl.Y?.min, lYmax = _sl.Y?.max;
          const lZmin = _sl.Z?.min, lZmax = _sl.Z?.max;
          // 17-oct: antes se marcaban solo los VÉRTICES fuera de área, así que un
          // tramo que cruzaba el límite seguía en azul hasta su punto final. Ahora
          // cada tramo se recorta contra la caja de la máquina (pasada a
          // coordenadas de pieza) y se pinta en rojo solo la parte que se sale.
          // La pura trabaja en coordenadas de máquina. La proyección posterior
          // resta el WCS para volver a las coordenadas del fichero.
          const box = {
            X: { min: lXmin, max: lXmax },
            Y: { min: lYmin, max: lYmax },
            Z: { min: lZmin, max: lZmax },
          };
          const a = { x: 0, y: 0, z: 0 }, b = { x: 0, y: 0, z: 0 };
          for (let idx = 0; idx < meta.length; idx += stepIndex) {
            const start = meta[idx + 1];
            const len = meta[idx + 2];
            if (len < 2) continue;
            const cIdx0 = start * 3;
            for (let i = 1; i < len; i++) {
              const j0 = cIdx0 + (i - 1) * 3, j1 = cIdx0 + i * 3;
              a.x = coords[j0]; a.y = coords[j0 + 1]; a.z = coords[j0 + 2];
              b.x = coords[j1]; b.y = coords[j1 + 1]; b.z = coords[j1 + 2];
              const parts = this.segmentOutsideParts(
                { x: a.x + oX, y: a.y + oY, z: a.z + oZ },
                { x: b.x + oX, y: b.y + oY, z: b.z + oZ },
                box,
              );
              for (let k = 0; k < parts.length; k++) {
                const t0 = parts[k][0], t1 = parts[k][1];
                const p0 = _pj({ x: a.x + (b.x - a.x) * t0, y: a.y + (b.y - a.y) * t0, z: a.z + (b.z - a.z) * t0 });
                const p1 = _pj({ x: a.x + (b.x - a.x) * t1, y: a.y + (b.y - a.y) * t1, z: a.z + (b.z - a.z) * t1 });
                pOut.moveTo(p0.x, p0.y);
                pOut.lineTo(p1.x, p1.y);
              }
            }
          }
        }
        this._cachedPaths = { rapid: pRapid, cut: pCut, out: pOut };
        this._cachedViewHash = drawHash;
      }

      if (this._cachedPaths.rapid) {
        ctx.strokeStyle = isDark ? `rgba(251,191,36,.6)` : `#b45309`;
        ctx.lineWidth = 0.6 / this.scale;
        ctx.setLineDash([5 / this.scale, 3 / this.scale]);
        ctx.stroke(this._cachedPaths.rapid);
      }
      if (this._cachedPaths.cut) {
        ctx.strokeStyle = isDark ? `#06b6d4` : `#10b981`;
        ctx.lineWidth = 1.2 / this.scale;
        ctx.setLineDash([]);
        ctx.stroke(this._cachedPaths.cut);
      }
      // t_e1f3f979: overlay ROJO para los segmentos fuera de área. Se pinta
      // ENCIMA de rapid y cut con un trazo más grueso para que el operario lo
      // vea de un vistazo. No es interactivo (no cursor/hover); el aviso en
      // texto sigue siendo el detalle ("X supera X-MAX en 12,4 mm").
      if (this._cachedPaths.out) {
        ctx.strokeStyle = isDark ? `rgba(239,68,68,.95)` : `rgba(220,38,38,.95)`;
        ctx.lineWidth = 2 / this.scale;
        ctx.setLineDash([]);
        ctx.stroke(this._cachedPaths.out);
      }
    }
    if (this.toolX !== null) {
      ctx.save();
      const r = 4 / this.scale,
        _tz = Number.isFinite(this.toolZ) ? this.toolZ : 0,
        _tp = _pj({ x: this.toolX, y: this.toolY, z: _tz });
      (ctx.setLineDash([]),
        ctx.beginPath(),
        ctx.arc(_tp.x, _tp.y, r, 0, Math.PI * 2),
        (ctx.fillStyle = `#f08020`),
        ctx.fill(),
        (ctx.strokeStyle = `#fff`),
        (ctx.lineWidth = 1 / this.scale),
        ctx.stroke(),
        (ctx.strokeStyle = `rgba(240,128,32,.5)`),
        (ctx.lineWidth = 0.5 / this.scale));
      const ch = 10 / this.scale;
      (ctx.beginPath(),
        ctx.moveTo(_tp.x - ch, _tp.y),
        ctx.lineTo(_tp.x + ch, _tp.y),
        ctx.moveTo(_tp.x, _tp.y - ch),
        ctx.lineTo(_tp.x, _tp.y + ch),
        ctx.stroke());
      // Altura de la fresa en coordenadas de pieza, al lado del punto.
      if (Number.isFinite(this.toolZ)) {
        ctx.font = `bold ${11 / this.scale}px monospace`;
        ctx.fillStyle = isDark ? `rgba(253,186,116,.95)` : `#9a3412`;
        ctx.fillText(`${t(`msg.vizToolZ`, `Z`)} ${this.toolZ.toFixed(3)}`, _tp.x + 12 / this.scale, _tp.y - 6 / this.scale);
      }
      ctx.restore();
    }
    (ctx.restore(), this.drawAxisLabels(ctx, W, H, isDark));
  },
  // Proyección de la vista activa: punto 3D de pieza -> punto 2D del lienzo
  // (antes de aplicar pan/zoom). La usan la trayectoria, la mesa, la fresa y
  // el encuadre, para que las cuatro vistas coloquen todo igual.
  _projector() {
    const vm = this.viewMode;
    if (vm === `front`) return function (p) { return { x: p.x, y: -(Number.isFinite(p.z) ? p.z : 0) }; };
    if (vm === `iso`) return function (p) {
      return { x: p.x + p.y * 0.5, y: -p.y * 0.866 - (Number.isFinite(p.z) ? p.z : 0) };
    };
    if (vm === `3d`) {
      const cx = Math.cos(this.rotAngleX),
        sx = Math.sin(this.rotAngleX),
        cy = Math.cos(this.rotAngleY),
        sy = Math.sin(this.rotAngleY);
      return function (p) {
        const z = Number.isFinite(p.z) ? p.z : 0,
          y1 = -p.y * cx - z * sx,
          z1 = -p.y * sx + z * cx,
          x2 = p.x * cy + z1 * sy;
        return { x: x2, y: y1 };
      };
    }
    return function (p) { return { x: p.x, y: -p.y }; };
  },
  // Área de la máquina expresada en coordenadas de PIEZA del WCS activo.
  // limits: {X:{min,max},Y,Z} en coordenadas de máquina (move.axes[n].min/max).
  // offsets: offset del WCS activo por eje (máquina = pieza + offset).
  // Sin X e Y finitos devuelve null: no se inventa el área de otra máquina.
  // Z es opcional (minZ/maxZ null si no se conoce).
  machineEnvelopeWork(limits, offsets) {
    const L = limits || {}, o = offsets || {};
    const value = (axis, side) => {
      const n = Number(L[axis]?.[side]);
      return L[axis]?.[side] != null && Number.isFinite(n) ? n : null;
    };
    const off = (axis) => {
      const n = Number(o[axis]);
      return Number.isFinite(n) ? n : 0;
    };
    const xmin = value(`X`, `min`), xmax = value(`X`, `max`),
      ymin = value(`Y`, `min`), ymax = value(`Y`, `max`),
      zmin = value(`Z`, `min`), zmax = value(`Z`, `max`);
    const ok = (min, max) => min != null && max != null && max > min;
    if (!ok(xmin, xmax) || !ok(ymin, ymax)) return null;
    const ox = off(`X`), oy = off(`Y`), oz = off(`Z`);
    return {
      minX: xmin - ox, maxX: xmax - ox,
      minY: ymin - oy, maxY: ymax - oy,
      minZ: ok(zmin, zmax) ? zmin - oz : null, maxZ: ok(zmin, zmax) ? zmax - oz : null,
    };
  },
  // Partes de un tramo p0->p1 que quedan FUERA de la caja, como intervalos
  // [t0, t1] del parámetro (0 = p0, 1 = p1). box: {X:{min,max},Y,Z}; un límite
  // null o un eje ausente no restringe. Recorte paramétrico (Liang-Barsky).
  segmentOutsideParts(p0, p1, box) {
    const EPS = 1e-9;
    let tIn = 0, tOut = 1;
    const axes = [[`X`, `x`], [`Y`, `y`], [`Z`, `z`]];
    for (let n = 0; n < 3; n++) {
      const axis = axes[n][0], b = box && (box[axis] || {
        min: box[`min${axis}`],
        max: box[`max${axis}`],
      });
      if (!b) continue;
      const k = axes[n][1], a0 = Number(p0?.[k]), a1 = Number(p1?.[k]);
      if (!Number.isFinite(a0) || !Number.isFinite(a1)) return [];
      const d = a1 - a0;
      const min = b.min != null ? Number(b.min) : null;
      const max = b.max != null ? Number(b.max) : null;
      if (min != null && !Number.isFinite(min) || max != null && !Number.isFinite(max)) continue;
      if (min != null && max != null && max < min) return [];
      if (d === 0) {
        if ((min != null && a0 < min) || (max != null && a0 > max)) return [[0, 1]];
        continue;
      }
      if (min != null) {
        if (d > 0) tIn = Math.max(tIn, (min - a0) / d);
        else tOut = Math.min(tOut, (min - a0) / d);
      }
      if (max != null) {
        if (d > 0) tOut = Math.min(tOut, (max - a0) / d);
        else tIn = Math.max(tIn, (max - a0) / d);
      }
      if (tIn > tOut + EPS) return [[0, 1]];
    }
    const out = [];
    if (tIn > EPS) out.push([0, Math.min(1, tIn)]);
    if (tOut < 1 - EPS) out.push([Math.max(0, tOut), 1]);
    return out;
  },
  // Dibuja la mesa (caja de la máquina) y el cero de máquina, ya dentro del
  // ctx trasladado/escalado. env viene de machineEnvelopeWork().
  drawEnvelope(ctx, env, pj, offsets, isDark) {
    const z0 = env.minZ, z1 = env.maxZ;
    const P = (x, y, z) => pj({ x, y, z });
    const isFront = this.viewMode === `front`, hasZ = Number.isFinite(z0) && Number.isFinite(z1);
    if (isFront && !hasZ) return;
    if (!isFront && this.viewMode !== `top` && !hasZ) return;
    const tableZ = hasZ ? z0 : 0;
    const face = isFront
      ? [P(env.minX, env.minY, z0), P(env.maxX, env.minY, z0), P(env.maxX, env.minY, z1), P(env.minX, env.minY, z1)]
      : [P(env.minX, env.minY, tableZ), P(env.maxX, env.minY, tableZ), P(env.maxX, env.maxY, tableZ), P(env.minX, env.maxY, tableZ)];
    ctx.save();
    ctx.setLineDash([]);
    ctx.beginPath();
    face.forEach((p, i) => (i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y)));
    ctx.closePath();
    ctx.fillStyle = isDark ? `rgba(148,163,184,.07)` : `rgba(15,23,42,.05)`;
    ctx.fill();
    // Aristas de la caja (en vista superior las verticales se reducen a puntos).
    const xs = [env.minX, env.maxX], ys = [env.minY, env.maxY], zs = hasZ ? [z0, z1] : [tableZ];
    ctx.beginPath();
    zs.forEach((z) => {
      const q = [P(xs[0], ys[0], z), P(xs[1], ys[0], z), P(xs[1], ys[1], z), P(xs[0], ys[1], z)];
      q.forEach((p, i) => (i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y)));
      ctx.closePath();
    });
    if (zs.length === 2) {
      xs.forEach((x) => ys.forEach((y) => {
        const a = P(x, y, z0), b = P(x, y, z1);
        ctx.moveTo(a.x, a.y);
        ctx.lineTo(b.x, b.y);
      }));
    }
    ctx.strokeStyle = isDark ? `rgba(148,163,184,.75)` : `rgba(51,65,85,.7)`;
    ctx.lineWidth = 1.5 / this.scale;
    ctx.stroke();
    // Cero de máquina: cuadrado pequeño con etiqueta.
    const ox = Number(offsets?.X), oy = Number(offsets?.Y), oz = Number(offsets?.Z);
    const m = P(Number.isFinite(ox) ? -ox : 0, Number.isFinite(oy) ? -oy : 0, Number.isFinite(oz) ? -oz : 0), s = 4 / this.scale;
    ctx.fillStyle = isDark ? `rgba(217,70,239,.95)` : `rgba(126,34,206,.95)`;
    ctx.fillRect(m.x - s, m.y - s, s * 2, s * 2);
    ctx.strokeStyle = isDark ? `rgba(250,232,255,.95)` : `rgba(255,255,255,.95)`;
    ctx.lineWidth = 1 / this.scale;
    ctx.strokeRect(m.x - s, m.y - s, s * 2, s * 2);
    ctx.font = `bold ${10 / this.scale}px monospace`;
    ctx.fillStyle = isDark ? `rgba(250,232,255,.95)` : `rgba(88,28,135,.95)`;
    ctx.fillText(t(`msg.vizMachineZero`, `Cero máquina`), m.x + 7 / this.scale, m.y + 14 / this.scale);
    ctx.restore();
  },
  drawGrid(ctx, W, H, isDark) {
    const gc = isDark ? `#1e293b` : `#c7d2e0`,
      step = 50 * this.scale;
    if (step < 8) return; // Evitar bucles lentos o rejillas densas al alejar mucho el zoom
    ((ctx.strokeStyle = gc), (ctx.lineWidth = 1), ctx.beginPath());
    for (let x = this.offsetX % step; x < W; x += step)
      (ctx.moveTo(x, 0), ctx.lineTo(x, H));
    for (let y = this.offsetY % step; y < H; y += step)
      (ctx.moveTo(0, y), ctx.lineTo(W, y));
    (ctx.stroke(),
      isDark
        ? ((ctx.shadowColor = `rgba(6,182,212,0.8)`),
          (ctx.shadowBlur = 12),
          (ctx.strokeStyle = `rgba(6,182,212,.4)`))
        : ((ctx.shadowBlur = 0), (ctx.strokeStyle = `rgba(8,115,145,.82)`)),
      (ctx.lineWidth = 1.5),
      ctx.setLineDash([]),
      ctx.beginPath(),
      ctx.moveTo(this.offsetX, 0),
      ctx.lineTo(this.offsetX, H),
      ctx.moveTo(0, this.offsetY),
      ctx.lineTo(W, this.offsetY),
      ctx.stroke(),
      isDark && (ctx.shadowBlur = 0));
  },
  // Se rellena desde move.axes[n].min/max cuando llega el object model.
  // null evita presentar como universal el recorrido de una maquina concreta.
  workLimits: { x: null, y: null },
  // t_e1f3f979 (regla H, Fase 2.2 · 2026-09-01): bounding box vs soft limits.
  // Pura, sin tocar el DOM. La usan (a) este módulo para colorear los segmentos
  // fuera de área en el canvas, (b) tests/unit/viz-bounds-warnings.test.js, y
  // (c) potencialmente el visor 3D (viz3dWarnings en rotechos.js:5729) en el
  // futuro. Si bounds es null (código vacío / error de parseo) o TODOS los
  // limits son null (máquina sin M208 leído), devuelve {status:'unknown'} y
  // el caller NO debe pintar aviso NI un falso "todo correcto".
  //
  // Convención de limits: {X:{min,max}, Y:{min,max}, Z:{min,max}} con min/max
  // numéricos o null. Ejes con lim==null se IGNORAN — un eje desconocido no
  // genera violación (no inventamos el recorrido de otra máquina) pero tampoco
  // afirma que ese eje esté bien.
  //
  // wcsOffsets (opcional): si llega, se aplica coord_maquina = coord_fichero +
  // offset[axis] y se compara con el limit. t_717c48cc (jul-2026) demostró que
  // un cero de pieza en X=300 hace que un fichero X0..X300 termine en
  // X300..X600 — sin WCS, el chequeo da VERDE y la máquina choca. Por eso
  // está aquí SIEMPRE que se conozca el offset.
  //
  // overflow: positivo = distancia que se sale del recorrido (mm). Es el dato
  // que el operario necesita leer ("X supera X-MAX en 12,4 mm").
  computeBoundsWarnings(bounds, limits, opts) {
    if (!bounds || !isFinite(bounds.minX)) {
      return { status: 'unknown', reason: 'no_bounds' };
    }
    // t_e1f3f979 (P0 del briefing): si TODOS los limits son null
    // (máquina sin M208 leído, mock-server, primera conexión) NO afirmamos
    // "todo correcto" — un falso verde aquí es peor que no decir nada.
    // Devolvemos 'unknown' para que el caller explique que no se pudo
    // comprobar, en vez de pintar el canvas como si nada pasara.
    const _allNull = !limits ||
      ((limits.X == null || (limits.X.min == null && limits.X.max == null)) &&
       (limits.Y == null || (limits.Y.min == null && limits.Y.max == null)) &&
       (limits.Z == null || (limits.Z.min == null && limits.Z.max == null)));
    if (_allNull) return { status: 'unknown', reason: 'no_limits' };

    const axes = ['X', 'Y', 'Z'];
    const offX = opts?.wcsOffsets?.X ?? 0;
    const offY = opts?.wcsOffsets?.Y ?? 0;
    const offZ = opts?.wcsOffsets?.Z ?? 0;
    const axisOff = { X: offX, Y: offY, Z: offZ };
    const axisMinKey = { X: 'minX', Y: 'minY', Z: 'minZ' };
    const axisMaxKey = { X: 'maxX', Y: 'maxY', Z: 'maxZ' };
    const violations = [];
    for (const ax of axes) {
      const lim = limits && limits[ax];
      const fMin = bounds[axisMinKey[ax]];
      const fMax = bounds[axisMaxKey[ax]];
      if (!isFinite(fMin) || !isFinite(fMax)) continue;
      // lim == null/undefined → desconocido → NO inventamos, NO añadimos
      // violación, pero seguimos con el resto de ejes.
      if (lim == null) continue;
      const lMin = lim.min;
      const lMax = lim.max;
      const off = axisOff[ax];
      const mMin = fMin + off;
      const mMax = fMax + off;
      if (lMax != null && mMax > lMax) {
        violations.push({
          axis: ax, side: 'max',
          fileValue: fMax, machineValue: mMax,
          wcsOffset: off, limit: lMax,
          overflow: mMax - lMax,
        });
      }
      if (lMin != null && mMin < lMin) {
        violations.push({
          axis: ax, side: 'min',
          fileValue: fMin, machineValue: mMin,
          wcsOffset: off, limit: lMin,
          overflow: lMin - mMin,
        });
      }
    }
    if (violations.length === 0) return { status: 'ok' };
    return { status: 'over', violations };
  },
  // t_e1f3f979 (regla H, Fase 2.2 · 2026-09-01): formatea el resultado de
  // computeBoundsWarnings en un mensaje corto apto para un toast. Pura, no
  // toca el DOM; la usa el handler del worker postMessage para avisar al
  // operario de que la trayectoria cae fuera del recorrido ANTES de ejecutar.
  //
  // Contrato:
  //   - { status:'ok' }      → null. NO se muestra nada (el canvas ya basta).
  //   - { status:'unknown' } → string explicando que no se pudo comprobar
  //                            ("Límites no disponibles, no se pudo comprobar").
  //                            Un falso "todo OK" aquí sería peor que callar.
  //   - { status:'over', violations:[...] }
  //                          → string listando cada violación en una sola línea
  //                            ("X supera X-MAX en 12,4 mm; Z cae por debajo
  //                            de Z-MIN en 0,8 mm"). El toast dura 3200 ms
  //                            (TCONF.warn), suficiente para 2-3 violaciones.
  //
  // El segundo parámetro `t(key, fallback)` es la función i18n ya inyectada —
  // se pasa desde fuera (no la importamos aquí) para que el test pueda usar
  // un stub sin montar un DOM. Las claves son:
  //   msg.pathBoundsOver       → "Trayectoria fuera de área: {details}"
  //   msg.pathBoundsOverSide   → "{axis} supera {side} en {overflow} mm"
  //                              (side = "X-MAX" / "Y-MIN" / etc.)
  //   msg.pathBoundsUnknown    → "Límites no leídos, no se pudo comprobar"
  //   msg.pathBoundsDisclaimer → "Macros / WCS / cambios de herramienta pueden
  //                              mover la trayectoria real, el aviso mira solo
  //                              el fichero."
  formatBoundsWarning(result, t) {
    if (!result || result.status === 'ok') return null;
    if (result.status === 'unknown') {
      return t(`msg.pathBoundsUnknown`,
        `Límites de recorrido no disponibles: no se pudo comprobar si la trayectoria cabe.`);
    }
    // status === 'over'. La i18n del proyecto (rotechos-i18n.js:77) no
    // interpola — t(key, fallback) devuelve el string tal cual — así que
    // sustituimos {axis}/{side}/{overflow} aquí. El diccionario EN puede
    // ignorar los placeholders si quiere; basta con que su forma tenga
    // sentido al caer el fallback.
    const fmt = (s, vars) =>
      s.replace(/\{(\w+)\}/g, (_, k) => (vars[k] != null ? String(vars[k]) : `{${k}}`));
    const sideLabel = (ax, side) => `${ax}-${side === 'max' ? 'MAX' : 'MIN'}`;
    const details = result.violations.map((v) => fmt(
      t(`msg.pathBoundsOverSide`, `{axis} supera {side} en {overflow} mm`),
      { axis: v.axis, side: sideLabel(v.axis, v.side), overflow: v.overflow.toFixed(1) }
    )).join('; ');
    const head = t(`msg.pathBoundsOver`, `Trayectoria fuera de área:`);
    const disclaimer = t(`msg.pathBoundsDisclaimer`,
      `Macros / WCS / cambios de herramienta pueden mover la trayectoria real; el aviso mira solo el fichero.`);
    return `${head} ${details} — ${disclaimer}`;
  },
  drawAxisLabels(ctx, W, H, isDark) {
    ((ctx.font = `bold 11px monospace`),
      (ctx.fillStyle = isDark
        ? `rgba(255,255,255,.30)`
        : `rgba(60,40,20,.35)`));
    const vm = this.viewMode;
    (ctx.fillText(`X+`, W - 26, this.offsetY - 6),
      ctx.fillText(
        vm === `front`
          ? `Z+`
          : vm === `iso`
            ? `Y+/Z+`
            : vm === `3d`
              ? `3D`
              : `Y+`,
        this.offsetX + 6,
        15,
      ));
  },
  // Encuadre. mode `table`: mesa entera más la pieza (lo normal: se ve dónde
  // cae la pieza en la máquina). mode `part`: solo la pieza. Sin argumento usa
  // el último modo elegido. Sin límites leídos encuadra solo la pieza.
  _fitInputKey(env) {
    return JSON.stringify({
      view: this.viewMode,
      rotX: this.viewMode === `3d` ? this.rotAngleX : null,
      rotY: this.viewMode === `3d` ? this.rotAngleY : null,
      bounds: this.bounds,
      envelope: env,
      mode: this.fitMode,
    });
  },
  fitView(mode) {
    if (mode === `table` || mode === `part`) this.fitMode = mode;
    const env = this.machineEnvelopeWork(window._softLimits || {}, window._wcsOffsets || {}),
      b = this.bounds,
      useEnv = env && (this.fitMode !== `part` || !b);
    if (!b && !useEnv) return;
    const c = this.canvas,
      W = c.width / (window.devicePixelRatio || 1),
      H = c.height / (window.devicePixelRatio || 1),
      pj = this._projector(),
      corners = [];
    const addBox = (x0, x1, y0, y1, z0, z1) => {
      [x0, x1].forEach((x) => [y0, y1].forEach((y) => [z0, z1].forEach((z) => corners.push(pj({ x, y, z })))));
    };
    if (b) addBox(b.minX, b.maxX, b.minY, b.maxY, b.minZ ?? 0, b.maxZ ?? 0);
    if (useEnv) addBox(env.minX, env.maxX, env.minY, env.maxY, env.minZ ?? 0, env.maxZ ?? 0);
    let bx0 = 1 / 0, bx1 = -1 / 0, by0 = 1 / 0, by1 = -1 / 0;
    corners.forEach(function (p) {
      if (p.x < bx0) bx0 = p.x;
      if (p.x > bx1) bx1 = p.x;
      if (p.y < by0) by0 = p.y;
      if (p.y > by1) by1 = p.y;
    });
    const bw = bx1 - bx0 || 1,
      bh = by1 - by0 || 1;
    ((this.scale = Math.max(0.1, Math.min((W - 80) / bw, (H - 80) / bh))),
      (this.offsetX = 40 - bx0 * this.scale + (W - 80 - bw * this.scale) / 2),
      (this.offsetY = 40 - by0 * this.scale + (H - 80 - bh * this.scale) / 2),
      (this._userViewAdjusted = !1),
      (this._autoFitKey = this._fitInputKey(env)),
      (this.dirty = !0));
  },
  fitMode: `table`,
  rotAngleX: 0.5,
  rotAngleY: 0.3,
  viewMode: `top`,
  setToolPos(x, y, z) {
    const target = this._interactiveMoveTarget;
    if (target && Math.hypot(x - target.x, y - target.y) < 0.5) this.clearInteractiveMove();
    // Omitir z conserva la compatibilidad con los callers antiguos.
    const zArg = arguments.length > 2 ? arguments[2] : undefined;
    const nextZ = zArg === undefined ? this.toolZ : (Number.isFinite(Number(zArg)) ? Number(zArg) : null);
    if (this.toolX === x && this.toolY === y && this.toolZ === nextZ) return;
    if (this.toolX === null || this.toolY === null) {
      this.toolX = x;
      this.toolY = y;
      this.toolZ = nextZ;
      this._targetX = x;
      this._targetY = y;
      this._targetZ = nextZ;
      this.dirty = !0;
      return;
    }
    this._targetX = x;
    this._targetY = y;
    this._targetZ = nextZ;
    const dx = x - this.toolX,
      dy = y - this.toolY,
      dz = Number.isFinite(nextZ) && Number.isFinite(this.toolZ) ? nextZ - this.toolZ : 0;
    if (dx * dx + dy * dy + dz * dz > 1e4) {
      this.toolX = x;
      this.toolY = y;
      this.toolZ = nextZ;
      this._lerpActive = !1;
      this.dirty = !0;
      return;
    }
    if (!this._lerpActive) {
      this._lerpActive = !0;
      const self = this;
      let tPrev = performance.now();
      (function lerpStep(now) {
        // FIX-3: si la pestaña está oculta, parar el suavizado (la transición
        // hacia el objetivo se reanudará al volver visible con un nuevo
        // setToolPos). Evita un rAF "muerto" corriendo a 60fps sin pintar.
        if (document.hidden) { self._lerpActive = !1; return; }
        now = now || performance.now();
        // Suavizado exponencial independiente de framerate: k = 1 - e^(-dt/τ).
        // τ≈39ms reproduce el tacto del antiguo 0.35/frame a 60Hz, pero ya no se
        // acelera al doble en pantallas de 120Hz.
        const dt = Math.min(now - tPrev, 100);
        tPrev = now;
        const k = 1 - Math.exp(-dt / 39),
          dx = self._targetX - self.toolX,
          dy = self._targetY - self.toolY,
          targetZ = Number.isFinite(self._targetZ) ? self._targetZ : self.toolZ,
          dz = Number.isFinite(targetZ) && Number.isFinite(self.toolZ) ? targetZ - self.toolZ : 0;
        if (Math.abs(dx) < 0.05 && Math.abs(dy) < 0.05 && Math.abs(dz) < 0.05) {
          self.toolX = self._targetX;
          self.toolY = self._targetY;
          self.toolZ = targetZ;
          self._lerpActive = !1;
          self.dirty = !0;
          return;
        }
        self.toolX += dx * k;
        self.toolY += dy * k;
        if (Number.isFinite(self.toolZ) && Number.isFinite(targetZ)) self.toolZ += dz * k;
        self.dirty = !0;
        requestAnimationFrame(lerpStep);
      })();
    }
  },
};
function vizCacheFilename(filename) {
  // El selector usa nombres relativos y RRF responde 0:/gcodes/<nombre>.
  // Conservamos los subdirectorios para no confundir dos archivos homónimos.
  return String(filename || ``).replace(/^0:\/gcodes\//i, ``).replace(/^\/?gcodes\//i, ``);
}
function vizCacheSave(text, filename) {
  if (typeof sessionStorage === `undefined` || typeof text !== `string` || text.length > VIZ.CACHE_MAX_CHARS) return;
  try { sessionStorage.setItem(VIZ.CACHE_KEY, JSON.stringify({ filename, text })); } catch (_) {}
}
function vizCacheClear() {
  try { sessionStorage.removeItem(VIZ.CACHE_KEY); } catch (_) {}
}
function vizRestoreCachedIfMatching(filename) {
  if (VIZ.coords || typeof sessionStorage === `undefined` || !filename) return false;
  try {
    const cached = JSON.parse(sessionStorage.getItem(VIZ.CACHE_KEY) || `null`);
    if (!cached || typeof cached.text !== `string` || cached.text.length > VIZ.CACHE_MAX_CHARS
      || vizCacheFilename(cached.filename) !== vizCacheFilename(filename)) return false;
    vizLoadGCode(cached.text, cached.filename, true);
    return true;
  } catch (_) { return false; }
}
(VIZ.init(),
  $(`vizZoomIn`).addEventListener(`click`, () => {
    const c = VIZ.canvas,
      W = c.width / (window.devicePixelRatio || 1),
      H = c.height / (window.devicePixelRatio || 1);
    ((VIZ.offsetX = W / 2 - (W / 2 - VIZ.offsetX) * 1.25),
      (VIZ.offsetY = H / 2 - (H / 2 - VIZ.offsetY) * 1.25),
      (VIZ.scale *= 1.25),
      (VIZ._userViewAdjusted = !0),
      (VIZ.dirty = !0));
  }),
  $(`vizZoomOut`).addEventListener(`click`, () => {
    const c = VIZ.canvas,
      W = c.width / (window.devicePixelRatio || 1),
      H = c.height / (window.devicePixelRatio || 1);
    ((VIZ.offsetX = W / 2 - (W / 2 - VIZ.offsetX) / 1.25),
      (VIZ.offsetY = H / 2 - (H / 2 - VIZ.offsetY) / 1.25),
      (VIZ.scale /= 1.25),
      (VIZ._userViewAdjusted = !0),
      (VIZ.dirty = !0));
  }),
  // 17-oct: con pieza cargada y área conocida, el botón alterna el encuadre
  // entre la mesa entera y solo la pieza; si no, encuadra lo que haya.
  $(`vizReset`).addEventListener(`click`, () => {
    const env = VIZ.machineEnvelopeWork(window._softLimits, window._wcsOffsets);
    if (env && VIZ.bounds) {
      const next = VIZ.fitMode === `table` ? `part` : `table`;
      VIZ.fitView(next);
      toast(next === `table`
        ? t(`msg.vizFitTable`, `Visor: mesa entera`)
        : t(`msg.vizFitPart`, `Visor: solo la pieza`), `info`);
    } else VIZ.fitView();
  }),
  $(`vizClearFile`).addEventListener(`click`, async () => {
    if (SM._cancelInProgress) return; // doble clic: como el ESC
    if (SM.current === STATES.RUNNING) {
      if (
        !(await confirmDashboard(
          t(`dlg.removeRunningJob.title`, `Quitar trabajo en ejecución`),
          t(`dlg.removeRunningJob.msg`, `<p style="color:var(--red)"><b>ATENCIÓN — el corte se cancela.</b></p><p>Vas a <b>cancelar el corte en curso</b>: se para, se apaga el husillo y Z sube. El archivo se <b>descarga del visor</b>, pero <b>sigue en la SD</b> y puedes volver a cargarlo.</p><p>Si solo quieres parar un momento, pulsa <b>Cancelar</b> aquí y usa <b>PAUSA</b>.</p><p>¿Cancelar el trabajo?</p>`),
        ))
      )
        return;
      _clearPollTimer();
      SM._cancelInProgress = !0;
      SM.busy = !0;
      // FIX: M25 PRIMERO (pausar), luego M0 (cancelar), T0+M5 (spindle off)
      // try/finally garantiza SM.busy = false incluso si falla la red
      try {
        let stopResult = null;
        try { stopResult = await RRF.urgentGcode(`M25\nM0\nT0\nM5`); } catch {}
        if (!stopResult) {
          toast(t(`msg.stopNotConfirmed`, `No se pudo confirmar la parada: usa PARO o la seta`), `err`);
          return;
        }
        await sleep(1500);
        await RRF.gcode(`G91\nG1 Z${CFG.safeZClear ?? 50} F1000\nG90`).catch(() => {});
        // Restaurar modo SEDA (SILK) tras cancelar — evitar quedar en PRO
        try {
          const r = await RRF.gcode(`M98 P"${MACROS.setSilk}"`);
          if (!r) throw new Error(`Fallback`);
        } catch {
          RRF.gcode(FALLBACK_SEDA).catch(() => {});
        }
        RRF.gcode(`M98 P"0:/sys/recover_triggers.g"`).catch(() => {});
        clearJob();
        SM.transition(STATES.IDLE, `archivo quitado desde ejecución`);
        toast(t(`msg.jobCancelledAndRemoved`, `Trabajo cancelado y archivo quitado`), `warn`);
        log(`M25+M0+T0+M5+Z↑+SEDA+triggers — archivo quitado en ejecución`, `warn`);
      } finally {
        SM.busy = !1;
        SM._cancelInProgress = !1;
        startPoll();
      }
      return;
    }
    if (SM.current === STATES.PAUSED) {
      if (
        !(await confirmDashboard(
          t(`dlg.removePausedJob.title`, `Quitar trabajo pausado`),
          t(`dlg.removePausedJob.msg`, `<p style="color:var(--red)"><b>ATENCIÓN — el corte se cancela.</b></p><p>El corte está en <b>PAUSA</b>. Vas a <b>cancelarlo</b>: no se podrá reanudar. El archivo se <b>descarga del visor</b>, pero <b>sigue en la SD</b> y puedes volver a cargarlo.</p><p>Si quieres seguir desde donde se quedó, pulsa <b>Cancelar</b> aquí y luego <b>RESUME</b>.</p><p>¿Cancelar el trabajo?</p>`),
        ))
      )
        return;
      _clearPollTimer();
      SM._cancelInProgress = !0;
      SM.busy = !0;
      // FIX: try/finally garantiza SM.busy = false incluso si falla la red
      try {
        let stopResult = null;
        try { stopResult = await RRF.urgentGcode(`M0\nT0\nM5`); } catch {}
        if (!stopResult) {
          toast(t(`msg.stopNotConfirmed`, `No se pudo confirmar la parada: usa PARO o la seta`), `err`);
          return;
        }
        await RRF.gcode(`G91\nG1 Z${CFG.safeZClear ?? 50} F1000\nG90`).catch(() => {});
        // Restaurar modo SEDA (SILK) tras cancelar
        try {
          const r = await RRF.gcode(`M98 P"${MACROS.setSilk}"`);
          if (!r) throw new Error(`Fallback`);
        } catch {
          RRF.gcode(FALLBACK_SEDA).catch(() => {});
        }
        RRF.gcode(`M98 P"0:/sys/recover_triggers.g"`).catch(() => {});
        clearJob();
        SM.transition(STATES.IDLE, `archivo quitado desde pausa`);
        toast(t(`msg.jobCancelledAndRemoved`, `Trabajo cancelado y archivo quitado`), `warn`);
        log(`M0+T0+M5+Z↑+SEDA+triggers — archivo quitado desde pausa`, `warn`);
      } finally {
        SM.busy = !1;
        SM._cancelInProgress = !1;
        startPoll();
      }
      return;
    }
    await RRF.gcode(`M23 ""`).catch(() => {});
    clearJob();
    SM.transition(STATES.IDLE, `archivo descargado`);
    toast(t(`msg.fileUnloaded`, `Archivo descargado`), `info`);
    log(`Archivo descargado — estado IDLE`, `sys`);
  }));
const VIZ_WORKER_CODE = `
self.onmessage = function(e) {
  let text = e.data.text;
  
  // Calcular offsets de línea en segundo plano para no congelar la UI principal
  // C-rot-02: para archivos grandes evitamos construir el Int32Array entero
  // (que era el grueso del coste para >20MB). El main thread ya descarta
  // SM.gcodeLineMap en ese caso.
  let offsets = null;
  let offsetsArray = null;
  if (text.length <= 20000000) {
    offsets = [0];
    let idx = 0;
    while ((idx = text.indexOf(String.fromCharCode(10), idx)) !== -1) {
      idx++;
      offsets.push(idx);
    }
    offsetsArray = new Int32Array(offsets);
  }

  let cx = 0, cy = 0, cz = 0, cf = 1000;
  let currentType = null;
  let coordsList = [];
  let pathMetaList = [];
  let currentPtsStart = 0;
  let currentPtsLength = 0;
  
  function flush() {
    if (currentPtsLength > 1) {
      pathMetaList.push(currentType === 'rapid' ? 0 : 1, currentPtsStart, currentPtsLength);
    }
  }

  function startPath(type) {
    if (type !== currentType) {
      flush();
      if (currentPtsLength > 0) {
        let len = coordsList.length;
        let lx = coordsList[len - 3];
        let ly = coordsList[len - 2];
        let lz = coordsList[len - 1];
        coordsList.push(lx, ly, lz);
        currentPtsStart = (coordsList.length / 3) - 1;
        currentPtsLength = 1;
      } else {
        currentPtsStart = coordsList.length / 3;
        currentPtsLength = 0;
      }
      currentType = type;
    }
  }

  function addPoint(x, y, z) {
    if (currentPtsLength === 0) {
      currentPtsStart = coordsList.length / 3;
    }
    coordsList.push(x, y, z);
    currentPtsLength++;
  }

  let minX = 1/0, maxX = -1/0, minY = 1/0, maxY = -1/0, minZ = 1/0, maxZ = -1/0;
  let totalLines = 0, cutLines = 0, estimatedTimeMs = 0;

  let cursor = 0;
  let len = text.length;

  while(cursor < len) {
    let nextIdx = text.indexOf(String.fromCharCode(10), cursor);
    if (nextIdx === -1) nextIdx = len;
    
    let raw = text.substring(cursor, nextIdx);
    cursor = nextIdx + 1;
    totalLines++;

    let semi = raw.indexOf(';');
    if (semi !== -1) raw = raw.substring(0, semi);
    
    let line = raw.trim().toUpperCase();
    if (!line) continue;

    // Fast extraction regex for G, X, Y, Z, I, J, R, F
    // G0* permite G0/G1/G2/G3 y también G00/G01/G02/G03 (comunes en CAM de doble dígito)
    let m = line.match(/\\bG0*([0123])\\b|X([+-]?[0-9.]+)|Y([+-]?[0-9.]+)|Z([+-]?[0-9.]+)|I([+-]?[0-9.]+)|J([+-]?[0-9.]+)|R([+-]?[0-9.]+)|F([+-]?[0-9.]+)/g);
    if (!m) continue;

    let nx = cx, ny = cy, nz = cz, iVal = 0, jVal = 0, rVal = null, moveType = null;
    let isG = false;

    for (let i = 0; i < m.length; i++) {
      let token = m[i];
      let c = token[0], v = parseFloat(token.substring(1));
      if (c === 'G') { moveType = v; isG = true; }
      else if (c === 'X') nx = v;
      else if (c === 'Y') ny = v;
      else if (c === 'Z') nz = v;
      else if (c === 'F') cf = v;
      else if (c === 'I') iVal = v;
      else if (c === 'J') jVal = v;
      else if (c === 'R') rVal = v;
    }

    if (!isG && moveType === null) moveType = currentType === 'rapid' ? 0 : (currentType === 'cut' ? 1 : null);
    if (moveType === null) { cx = nx; cy = ny; cz = nz; continue; }

    let typeStr = moveType === 0 ? 'rapid' : 'cut';

    // Interpolation for G2/G3
    if (moveType === 2 || moveType === 3) {
      let dx = nx - cx, dy = ny - cy;
      let cx_arc, cy_arc, r;
      if (rVal !== null) {
        let d2 = dx*dx + dy*dy;
        let d = Math.sqrt(d2);
        if (d > 0) {
          let h = Math.sqrt(Math.max(0, rVal*rVal - d2/4));
          let sign = (moveType === 3) ? 1 : -1;
          if (rVal < 0) sign = -sign;
          cx_arc = cx + dx/2 - sign * h * dy / d;
          cy_arc = cy + dy/2 + sign * h * dx / d;
          r = Math.abs(rVal);
        } else { cx_arc = cx; cy_arc = cy; r = 0; }
      } else {
        cx_arc = cx + iVal; cy_arc = cy + jVal;
        r = Math.sqrt(iVal*iVal + jVal*jVal);
      }

      if (r > 0) {
        let startAngle = Math.atan2(cy - cy_arc, cx - cx_arc);
        let endAngle = Math.atan2(ny - cy_arc, nx - cx_arc);
        
        if (moveType === 2 && endAngle >= startAngle) endAngle -= Math.PI * 2;
        if (moveType === 3 && endAngle <= startAngle) endAngle += Math.PI * 2;
        
        let angleDiff = Math.abs(endAngle - startAngle);
        let segments = Math.max(1, Math.ceil(r * angleDiff / 1.0)); // ~1mm resolution
        
        startPath(typeStr);
        if (currentPtsLength === 0) {
          addPoint(cx, cy, cz);
        }

        for (let i = 1; i <= segments; i++) {
          let a = startAngle + (endAngle - startAngle) * (i / segments);
          let px = cx_arc + r * Math.cos(a);
          let py = cy_arc + r * Math.sin(a);
          let pz = cz + (nz - cz) * (i / segments);
          
          addPoint(px, py, pz);
          minX = Math.min(minX, px); maxX = Math.max(maxX, px);
          minY = Math.min(minY, py); maxY = Math.max(maxY, py);
          minZ = Math.min(minZ, pz); maxZ = Math.max(maxZ, pz);
          cutLines++;
          estimatedTimeMs += (Math.sqrt(Math.pow(px-cx,2) + Math.pow(py-cy,2) + Math.pow(pz-cz,2)) / cf) * 60000;
          cx = px; cy = py; cz = pz;
        }
      } else { moveType = 1; }
    }
    
    if (moveType === 0 || moveType === 1) {
      let dx = nx - cx, dy = ny - cy, dz = nz - cz;
      let dist = Math.sqrt(dx*dx + dy*dy + dz*dz);
      if (dist > 0) {
        let feed = moveType === 0 ? Math.max(cf, 5000) : cf;
        estimatedTimeMs += (dist / feed) * 60000;
      }
      
      startPath(typeStr);
      if (currentPtsLength === 0) {
        addPoint(cx, cy, cz);
      }
      if (typeStr === 'cut') cutLines++;
      
      addPoint(nx, ny, nz);
      minX = Math.min(minX, nx); maxX = Math.max(maxX, nx);
      minY = Math.min(minY, ny); maxY = Math.max(maxY, ny);
      minZ = Math.min(minZ, nz); maxZ = Math.max(maxZ, nz);
      cx = nx; cy = ny; cz = nz;
    }
  }

  flush();
  
  let coordsArray = new Float32Array(coordsList);
  let pathMetaArray = new Int32Array(pathMetaList);
  let hasBounds = coordsList.length > 0;
  
  self.postMessage({
    coords: coordsArray,
    pathMeta: pathMetaArray,
    bounds: hasBounds ? { minX, maxX, minY, maxY, minZ, maxZ } : null,
    lineCount: totalLines,
    cutLines: cutLines,
    estimatedTimeMs: estimatedTimeMs,
    offsets: offsetsArray
  }, [coordsArray.buffer, pathMetaArray.buffer, ...(offsetsArray ? [offsetsArray.buffer] : [])]);
};
`;

// eslint-disable-next-line no-unused-vars -- usado por vizLoadGCode fuera de este módulo (rotechos.js:202,238 (typeof) + 2313 + tests/take_screenshots.js:122,138,158,174)
function vizLoadGCode(text, filename, fromLocalCache = false) {
  $(`vizPlaceholder`).style.display = `none`;
  // FIX B-01 (2026-07-05): escapar `filename` antes de innerHTML — el nombre lo elige
  // el operario o viene del firmware; defense-in-depth contra XSS local.
  $(`vizFileName`).innerHTML = escHtml(filename) + ' <span style="color:var(--text-3);font-size:10px;margin-left:6px">(Procesando...)</span>';
  
  if (VIZ.activeWorker) {
    VIZ.activeWorker.terminate();
    VIZ.activeWorker = null;
  }
  if (VIZ.activeBlobUrl) {
    URL.revokeObjectURL(VIZ.activeBlobUrl);
    VIZ.activeBlobUrl = null;
  }
  
  const blob = new Blob([VIZ_WORKER_CODE], {type: 'application/javascript'});
  const blobUrl = URL.createObjectURL(blob);
  VIZ.activeBlobUrl = blobUrl;
  const worker = new Worker(blobUrl);
  VIZ.activeWorker = worker;
  
  worker.onmessage = function(e) {
    const result = e.data;
    VIZ.coords = result.coords;
    VIZ.pathMeta = result.pathMeta;
    VIZ.paths = [{ pts: [1] }]; // Dummy compatibility array
    VIZ.bounds = result.bounds;
    VIZ._cachedPaths = null;
    VIZ._cachedViewHash = null;
    VIZ.dirty = true;
    // Forzar resize + repintado explícito: si la pestaña estaba oculta cuando
    // arrancó el worker, el primer frame del loop() se saltea. Sin este push,
    // el visor queda en blanco hasta que el usuario interactúe (zoom/pan) o
    // se dispare visibilitychange.
    VIZ.resize();
    VIZ.dirty = true;
    VIZ.fitView();
    // Llamar draw() directamente si el RAF está pausado por document.hidden
    if (typeof document !== `undefined` && !document.hidden && VIZ.ctx) {
      try { VIZ.draw(); } catch (e) { LOG.error(`VIZ draw post-parse:`, e); }
    }
    
    $(`vizFileName`).textContent = fromLocalCache
      ? `${filename} · ${t(`msg.localCache`, `caché local`)}`
      : filename;
    $(`vizClearFile`).style.display = `flex`;
    $(`vizPlaceholder`).style.display = `none`;

    // t_e1f3f979 (regla H): aviso de TEXTO al cargar el G-code si la trayectoria
    // cae fuera del recorrido. Se hace ANTES del toast de "cargada" para que
    // el operario lo vea con prioridad (TCONF.warn=3200 ms, aria-live=assertive,
    // role=alert). El brief prohíbe BLOQUEAR la carga: si hay bounds y los
    // soft limits están disponibles y la pieza cabe, no aparece nada.
    try {
      const _bounds = result.bounds;
      const _sl = window._softLimits || {};
      const _wcs = window._wcsOffsets || { X: 0, Y: 0, Z: 0 };
      const _wrn = VIZ.computeBoundsWarnings(
        _bounds,
        { X: _sl.X ? { min: _sl.X.min ?? null, max: _sl.X.max ?? null } : null,
          Y: _sl.Y ? { min: _sl.Y.min ?? null, max: _sl.Y.max ?? null } : null,
          Z: _sl.Z ? { min: _sl.Z.min ?? null, max: _sl.Z.max ?? null } : null },
        { wcsOffsets: _wcs }
      );
      const _msg = VIZ.formatBoundsWarning(_wrn, t);
      if (_msg) toast(_msg, _wrn.status === 'over' ? `warn` : `info`);
    } catch (_e) {
      LOG.error(`viz bounds warning:`, _e);
    }
    
    SM.gcodeLineMap = result.offsets
      ? { text: text, offsets: result.offsets }
      : (log(`Archivo muy grande (${(text.length / 1e6).toFixed(1)}MB): sin mapa de líneas, draw() usará saltos fijos`, `warn`), null);
    if (!fromLocalCache) vizCacheSave(text, filename);

    // Lint de seguridad: G-code que enciende el husillo (M3) SIN un dwell de spin-up
    // (G4) → el 1er corte podría empezar con el husillo acelerando. El post propio ya
    // inyecta G4 S3; esto solo avisa de archivos de OTROS CAM. Conservador (mínimo falso
    // positivo): avisa solo si hay M3/M03 y NO hay NINGÚN G4/G04 en todo el archivo.
    SM.gcodeSpindleNoDwell = !1;
    try {
      if (text.length < 8000000) {
        const _clean = text.replace(/\([^)]*\)/g, ` `).replace(/;.*$/gm, ` `);
        SM.gcodeSpindleNoDwell = /\bM0?3\b/.test(_clean) && !/\bG0?4\b/.test(_clean);
      }
    } catch (e) {}
      
    SM.lastLoggedLine = null;
    SM.lastLoggedFilePos = null;
    SM.lastLineLogAt = 0;
    SM.estimatedTotalMs = result.estimatedTimeMs > 0 ? result.estimatedTimeMs : result.cutLines * 500;
    SM.estimatedTotalLines = result.cutLines;
    
    toast(`${t(`msg.pathLoaded`, `Trayectoria cargada:`)} ${filename}`, `ok`);
    if (VIZ.activeWorker === worker) {
      VIZ.activeWorker = null;
    }
    if (VIZ.activeBlobUrl === blobUrl) {
      URL.revokeObjectURL(blobUrl);
      VIZ.activeBlobUrl = null;
    }
    worker.terminate();
  };
  worker.onerror = function(err) {
    $(`vizFileName`).textContent = filename;
    log(`Visor: error procesando el G-code: ${err && err.message ? err.message : err}`, `err`);
    toast(`${t(`msg.pathProcessErr`, `No se pudo procesar la trayectoria de`)} ${filename}`, `err`);
    if (VIZ.activeWorker === worker) {
      VIZ.activeWorker = null;
    }
    if (VIZ.activeBlobUrl === blobUrl) {
      URL.revokeObjectURL(blobUrl);
      VIZ.activeBlobUrl = null;
    }
    worker.terminate();
  };

  worker.postMessage({text: text});
}

// ── Espejo de la trayectoria al pendant móvil ───────────────────────────────
// El visor (VIZ) dibuja en #vizCanvas (cockpit). Cuando la pantalla TRABAJO del
// pendant está a la vista (móvil), copiamos ese bitmap a #mpgVizCanvas para
// mostrar la trayectoria sin refactorizar el visor. No-op si el pendant no está
// visible (offsetParent null en escritorio o en otras pantallas del pendant).
function mpgVizMirrorVisible() {
  const wrap = $(`mpgVizWrap`);
  if (document.hidden || !wrap || wrap.offsetParent === null) return !1;
  if (typeof getComputedStyle === `function`) {
    const style = getComputedStyle(wrap);
    if (style.display === `none` || style.visibility === `hidden`) return !1;
  }
  return !0;
}

function scheduleMpgVizMirror() {
  if (!mpgVizMirrorVisible() || mpgVizMirror.raf) return;
  mpgVizMirror.raf = requestAnimationFrame(() => {
    mpgVizMirror.raf = 0;
    mpgVizMirror();
  });
}

function mpgVizMirror() {
  const wrap = $('mpgVizWrap');
  if (mpgVizMirrorVisible()) {
    const src = VIZ.canvas,
      dst = $('mpgVizCanvas');
    if (src && dst) {
      const dpr = window.devicePixelRatio || 1,
        cw = wrap.clientWidth,
        ch = wrap.clientHeight;
      if (cw > 0 && ch > 0) {
        const tw = Math.round(cw * dpr),
          th = Math.round(ch * dpr);
        const dimsChanged = dst.width !== tw || dst.height !== th;
        // dirty-check: copiar el bitmap SOLO si VIZ repintó o cambiaron las
        // dimensiones. Antes se copiaba a 60fps siempre → batería/calor en móvil.
        if (dimsChanged || mpgVizMirror._seq !== (VIZ._seq | 0)) {
          mpgVizMirror._seq = VIZ._seq | 0;
          if (dimsChanged) {
            ((dst.width = tw), (dst.height = th));
          }
          const ctx = dst.getContext(`2d`);
          (ctx.setTransform(1, 0, 0, 1, 0, 0), ctx.clearRect(0, 0, tw, th));
          if (src.width > 0 && src.height > 0) {
            const s = Math.min(tw / src.width, th / src.height),
              dw = src.width * s,
              dh = src.height * s;
            ctx.drawImage(src, (tw - dw) / 2, (th - dh) / 2, dw, dh);
          }
          const empty = $('mpgVizEmpty');
          if (empty)
            empty.style.display = VIZ.paths && VIZ.paths.length ? `none` : `flex`;
        }
      }
    }
  } else {
    // Pendant oculto: forzar recopiado la próxima vez que reaparezca.
    mpgVizMirror._seq = -1;
  }
}
mpgVizMirror();

// FIX P3 — Auditoría UI 2026-07-18: exponer VIZ a window.* para robustez
// ante reorden futuro de los <script defer> en index.html. Antes, si alguien
// movía rotechos-viz.js ANTES de rotechos.js, el visualizador 3D quedaba
// inerte silenciosamente (typeof VIZ era undefined en el monolito). Ahora
// se puede detectar vía window.VIZ y fallar con un mensaje claro.
window.VIZ = VIZ;
