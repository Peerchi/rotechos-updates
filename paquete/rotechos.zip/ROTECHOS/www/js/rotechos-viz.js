/* ---
 * RotechOS — VIZ 2D / 3D Visualizador de trayectoria G-code
 * Extraído de rotechos.js. Debe cargarse DESPUÉS de rotechos.js —
 * usa $, SM, STATES, RRF, CFG, toast, confirmDialog, log,
 * _clearPollTimer, startPoll, clearJob.
 * --- */
// Invocado desde rotechos.js (cross-file); ESLint no ve ese uso:
/* exported vizLoadGCode */

// ---
// VIZ — Visualizador 2D de trayectoria G-code
// ---
const VIZ = {
  canvas: $(`vizCanvas`),
  ctx: null,
  _paths: [],
  get paths() {
    return this._paths;
  },
  set paths(val) {
    this._paths = val;
    if (!val || !val.length) {
      this.coords = null;
      this.pathMeta = null;
    }
  },
  coords: null,
  pathMeta: null,
  activeWorker: null,
  activeBlobUrl: null,
  bounds: null,
  scale: 1,
  offsetX: 0,
  offsetY: 0,
  toolX: null,
  toolY: null,
  isPanning: !1,
  panStart: null,
  panOffset: null,
  raf: null,
  dirty: !0,
  init() {
    ((this.ctx = this.canvas.getContext(`2d`)),
      this.resize(),
      window.addEventListener(`resize`, () => {
        (this.resize(), (this.dirty = !0));
      }),
      // Si la pestaña/panel estaba oculto cuando se cargó el G-code, el `loop()`
      // no pintó (chequea document.hidden). Forzar redibujado al volver visible
      // resuelve "el visor no muestra la pieza tras cargar un archivo".
      // FIX-3: además, al ocultarse cancela el espejo del pendant (mpgVizMirror)
      // y al volver re-arranca AMBOS bucles con la guarda `if (!this.raf) ...`
      // para que no quede un bucle duplicado.
      document.addEventListener(`visibilitychange`, () => {
        if (document.hidden) {
          if (mpgVizMirror.raf) { cancelAnimationFrame(mpgVizMirror.raf); mpgVizMirror.raf = 0; }
          return;
        }
        (this.resize(), (this.dirty = !0));
        if (!this.raf) this.loop();
        if (!mpgVizMirror.raf) mpgVizMirror.raf = requestAnimationFrame(mpgVizMirror);
      }),
      this.bindEvents(),
      this.loop());
  },
  resize() {
    const wrap = $(`vizWrap`),
      dpr = window.devicePixelRatio || 1,
      w = wrap.clientWidth || this.canvas.offsetWidth || 400,
      h = wrap.clientHeight || this.canvas.offsetHeight || 360;
    w === 0 ||
      h === 0 ||
      ((this.canvas.width = w * dpr),
      (this.canvas.height = h * dpr),
      (this.canvas.style.width = w + `px`),
      (this.canvas.style.height = h + `px`),
      this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0),
      (this.dirty = !0));
  },
  bindEvents() {
    const c = this.canvas;
    (c.addEventListener(
      `wheel`,
      (e) => {
        e.preventDefault();
        const f = e.deltaY < 0 ? 1.15 : 1 / 1.15,
          rect = c.getBoundingClientRect(),
          mx = e.clientX - rect.left,
          my = e.clientY - rect.top;
        ((this.offsetX = mx - (mx - this.offsetX) * f),
          (this.offsetY = my - (my - this.offsetY) * f),
          (this.scale *= f),
          (this.dirty = !0));
      },
      { passive: !1 },
    ),
      c.addEventListener(`pointerdown`, (e) => {
        ((this.isPanning = !0),
          (this.panStart = { x: e.clientX, y: e.clientY }),
          (this.panOffset = { x: this.offsetX, y: this.offsetY }),
          $(`vizWrap`).classList.add(`panning`),
          c.setPointerCapture(e.pointerId));
      }),
      c.addEventListener(`pointermove`, (e) => {
        this.isPanning &&
          ((this.offsetX = this.panOffset.x + (e.clientX - this.panStart.x)),
          (this.offsetY = this.panOffset.y + (e.clientY - this.panStart.y)),
          (this.dirty = !0));
      }),
      c.addEventListener(`pointerup`, () => {
        ((this.isPanning = !1),
          (this._isRotating = !1),
          $(`vizWrap`).classList.remove(`panning`));
      }),
      c.addEventListener(`contextmenu`, (e) => e.preventDefault()),
      c.addEventListener(`pointerdown`, (e) => {
        if (e.button === 2 && this.viewMode === `3d`) {
          ((this._isRotating = !0),
            (this._rotStart = { x: e.clientX, y: e.clientY }),
            (this._rotStartAngles = { x: this.rotAngleX, y: this.rotAngleY }),
            c.setPointerCapture(e.pointerId),
            e.preventDefault());
        }
      }),
      c.addEventListener(`pointermove`, (e) => {
        if (this._isRotating) {
          const dx = (e.clientX - this._rotStart.x) * 0.01,
            dy = (e.clientY - this._rotStart.y) * 0.01;
          ((this.rotAngleX = this._rotStartAngles.x + dy),
            (this.rotAngleY = this._rotStartAngles.y + dx),
            (this.rotAngleX = Math.max(-1.5, Math.min(1.5, this.rotAngleX))),
            (this.dirty = !0));
        }
      }));
  },
  loop() {
    // _seq se incrementa SOLO cuando hay un repintado real → el espejo móvil
    // (mpgVizMirror) lo usa para evitar copiar el bitmap a 60fps sin cambios.
    // FIX-3: si la pestaña está oculta, NO reagendar — el listener de
    // visibilitychange en este mismo fichero reanuda el bucle con una sola
    // llamada a loop(). Aquí NO se reactiva para garantizar un único loop.
    if (document.hidden) { this.raf = 0; return; }
    (this.dirty &&= (this.draw(), (this._seq = (this._seq | 0) + 1), !1),
      (this.raf = requestAnimationFrame(() => this.loop())));
  },
  draw() {
    const c = this.canvas,
      ctx = this.ctx,
      W = c.width / (window.devicePixelRatio || 1),
      H = c.height / (window.devicePixelRatio || 1),
      isDark = document.documentElement.dataset.theme !== `light`;
    
    ctx.clearRect(0, 0, W, H);
    
    if (!this.paths || !this.paths.length) {
      // Sin texto "Sin archivo" en el centro del lienzo (petición del usuario):
      // el chip del panel G-CODE ya indica el estado; el visor queda limpio.
      return;
    }
    
    this.drawGrid(ctx, W, H, isDark);
    
    if (this.paths.length) {
      (ctx.save(),
        ctx.translate(this.offsetX, this.offsetY),
        ctx.scale(this.scale, this.scale));
      const _vm = this.viewMode,
        _pj =
          _vm === `front`
            ? function (p) {
                return { x: p.x, y: -(p.z || 0) };
              }
            : _vm === `iso`
              ? function (p) {
                  return { x: p.x + p.y * 0.5, y: -p.y * 0.866 - (p.z || 0) };
                }
              : _vm === `3d`
                ? function () {
                    const cx = Math.cos(this.rotAngleX),
                      sx = Math.sin(this.rotAngleX),
                      cy = Math.cos(this.rotAngleY),
                      sy = Math.sin(this.rotAngleY);
                    return function (p) {
                      const z = p.z || 0,
                        y1 = -p.y * cx - z * sx,
                        z1 = -p.y * sx + z * cx,
                        x2 = p.x * cy + z1 * sy;
                      return { x: x2, y: y1 };
                    };
                  }.call(this)
                : function (p) {
                    return { x: p.x, y: -p.y };
                  };
      const viewHash = this.viewMode + '_' + (this.viewMode === `3d` ? this.rotAngleX + '_' + this.rotAngleY : ``);
      // t_e1f3f979: el overlay rojo depende de los soft limits y los WCS, que
      // pueden cambiar en runtime (operario edita M208 desde Configuración).
      // Sin este sufijo, el cacheo del path rojo queda obsoleto al cambiar
      // M208 y el operario sigue viendo el aviso antiguo. Usamos JSON estable:
      // es barato (3 ejes × 2 números + 3 offsets) y solo se ejecuta cuando
      // el resto del cacheo YA iba a rehacerse.
      const _sl0 = window._softLimits || {};
      const _wcs0 = window._wcsOffsets || {};
      const limitsHash = JSON.stringify({
        lX: [_sl0.X?.min ?? null, _sl0.X?.max ?? null],
        lY: [_sl0.Y?.min ?? null, _sl0.Y?.max ?? null],
        lZ: [_sl0.Z?.min ?? null, _sl0.Z?.max ?? null],
        wX: _wcs0.X ?? null, wY: _wcs0.Y ?? null, wZ: _wcs0.Z ?? null,
      });
      const totalSegments = this.pathMeta ? (this.pathMeta.length / 3) : 0;
      const isLarge = totalSegments > 5000;
      const isRotating = this._isRotating && isLarge;
      const drawHash = viewHash + '_' + limitsHash + (isRotating ? '_rot' : '');
      if (!this._cachedPaths || this._cachedViewHash !== drawHash) {
        const pRapid = new Path2D();
        const pCut = new Path2D();
        // Decimación: agresiva al rotar (~2000 segs objetivo) y SUAVE en reposo
        // solo para archivos enormes (>80k segs), para que el stroke no dé tirones
        // en pan/zoom. Los trabajos normales (<80k) se dibujan a full detalle (step 1).
        const STATIC_DECIMATE_OVER = 80000;
        const step = isRotating
          ? Math.ceil(totalSegments / 2000)
          : (totalSegments > STATIC_DECIMATE_OVER ? Math.ceil(totalSegments / STATIC_DECIMATE_OVER) : 1);
        const stepIndex = step * 3;
        const meta = this.pathMeta;
        const coords = this.coords;
        if (meta && coords) {
          for (let idx = 0; idx < meta.length; idx += stepIndex) {
            const type = meta[idx];
            const start = meta[idx+1];
            const len = meta[idx+2];
            if (len < 2) continue;
            const path = type === 0 ? pRapid : pCut;
            const cIdx = start * 3;
            const p0 = _pj({ x: coords[cIdx], y: coords[cIdx+1], z: coords[cIdx+2] });
            path.moveTo(p0.x, p0.y);
            for (let i = 1; i < len; i++) {
              const pi = _pj({ x: coords[cIdx + i*3], y: coords[cIdx + i*3 + 1], z: coords[cIdx + i*3 + 2] });
              path.lineTo(pi.x, pi.y);
            }
          }
        }
        // t_e1f3f979 (regla H): overlay ROJO sobre los segmentos que caen fuera
        // del recorrido. Se calcula junto al cacheo principal (mismo viewHash)
        // para no rehacer el bucle. NO toca el motor — solo añade un Path2D.
        // Si los soft limits no están disponibles (máquina sin M208 leído,
        // tests, mock-server) NO pinta nada: el briefing prohíbe inventar un
        // área por defecto.
        const pOut = new Path2D();
        const _sl = window._softLimits;
        const _wcs = window._wcsOffsets || { X: 0, Y: 0, Z: 0 };
        const _hasLimits = _sl && (_sl.X || _sl.Y || _sl.Z) &&
          ((_sl.X && (_sl.X.min != null || _sl.X.max != null)) ||
           (_sl.Y && (_sl.Y.min != null || _sl.Y.max != null)) ||
           (_sl.Z && (_sl.Z.min != null || _sl.Z.max != null)));
        if (meta && coords && _hasLimits) {
          const oX = _wcs.X ?? 0, oY = _wcs.Y ?? 0, oZ = _wcs.Z ?? 0;
          const lXmin = _sl.X?.min, lXmax = _sl.X?.max;
          const lYmin = _sl.Y?.min, lYmax = _sl.Y?.max;
          const lZmin = _sl.Z?.min, lZmax = _sl.Z?.max;
          for (let idx = 0; idx < meta.length; idx += stepIndex) {
            const start = meta[idx + 1];
            const len = meta[idx + 2];
            if (len < 2) continue;
            const cIdx0 = start * 3;
            let started = false;
            for (let i = 0; i < len; i++) {
              const xi = coords[cIdx0 + i * 3];
              const yi = coords[cIdx0 + i * 3 + 1];
              const zi = coords[cIdx0 + i * 3 + 2];
              const mx = xi + oX, my = yi + oY, mz = zi + oZ;
              const overX = (lXmax != null && mx > lXmax) || (lXmin != null && mx < lXmin);
              const overY = (lYmax != null && my > lYmax) || (lYmin != null && my < lYmin);
              const overZ = (lZmax != null && mz > lZmax) || (lZmin != null && mz < lZmin);
              const over = overX || overY || overZ;
              if (over) {
                const p = _pj({ x: xi, y: yi, z: zi });
                if (!started) { pOut.moveTo(p.x, p.y); started = true; }
                else { pOut.lineTo(p.x, p.y); }
              } else if (started) {
                // cerrar el sub-tramo para no unir dos violaciones lejanas con
                // una línea recta fantasma
                started = false;
              }
            }
          }
        }
        this._cachedPaths = { rapid: pRapid, cut: pCut, out: pOut };
        this._cachedViewHash = drawHash;
      }

      if (this._cachedPaths.rapid) {
        ctx.strokeStyle = isDark ? `rgba(251,191,36,.6)` : `#b45309`;
        ctx.lineWidth = 0.6 / this.scale;
        ctx.setLineDash([5 / this.scale, 3 / this.scale]);
        ctx.stroke(this._cachedPaths.rapid);
      }
      if (this._cachedPaths.cut) {
        ctx.strokeStyle = isDark ? `#06b6d4` : `#10b981`;
        ctx.lineWidth = 1.2 / this.scale;
        ctx.setLineDash([]);
        ctx.stroke(this._cachedPaths.cut);
      }
      // t_e1f3f979: overlay ROJO para los segmentos fuera de área. Se pinta
      // ENCIMA de rapid y cut con un trazo más grueso para que el operario lo
      // vea de un vistazo. No es interactivo (no cursor/hover); el aviso en
      // texto sigue siendo el detalle ("X supera X-MAX en 12,4 mm").
      if (this._cachedPaths.out) {
        ctx.strokeStyle = isDark ? `rgba(239,68,68,.95)` : `rgba(220,38,38,.95)`;
        ctx.lineWidth = 2 / this.scale;
        ctx.setLineDash([]);
        ctx.stroke(this._cachedPaths.out);
      }
      if (this.toolX !== null) {
        ctx.save();
        const r = 4 / this.scale,
          _vm = this.viewMode,
          _tp =
            _vm === `front`
              ? { x: this.toolX, y: 0 }
              : _vm === `iso`
                ? { x: this.toolX + this.toolY * 0.5, y: -this.toolY * 0.866 }
                : _vm === `3d`
                  ? function () {
                      const cx = Math.cos(this.rotAngleX),
                        sx = Math.sin(this.rotAngleX),
                        cy = Math.cos(this.rotAngleY),
                        sy = Math.sin(this.rotAngleY),
                        y1 = -this.toolY * cx,
                        x2 = this.toolX * cy + -this.toolY * sx * sy;
                      return { x: x2, y: y1 };
                    }.call(this)
                  : { x: this.toolX, y: -this.toolY };
        (ctx.setLineDash([]),
          ctx.beginPath(),
          ctx.arc(_tp.x, _tp.y, r, 0, Math.PI * 2),
          (ctx.fillStyle = `#f08020`),
          ctx.fill(),
          (ctx.strokeStyle = `#fff`),
          (ctx.lineWidth = 1 / this.scale),
          ctx.stroke(),
          (ctx.strokeStyle = `rgba(240,128,32,.5)`),
          (ctx.lineWidth = 0.5 / this.scale));
        const ch = 10 / this.scale;
        (ctx.beginPath(),
          ctx.moveTo(_tp.x - ch, _tp.y),
          ctx.lineTo(_tp.x + ch, _tp.y),
          ctx.moveTo(_tp.x, _tp.y - ch),
          ctx.lineTo(_tp.x, _tp.y + ch),
          ctx.stroke(),
          ctx.restore());
      }
      (ctx.restore(), this.drawAxisLabels(ctx, W, H, isDark));
    }
  },
  drawGrid(ctx, W, H, isDark) {
    const gc = isDark ? `#1e293b` : `#c7d2e0`,
      step = 50 * this.scale;
    if (step < 8) return; // Evitar bucles lentos o rejillas densas al alejar mucho el zoom
    ((ctx.strokeStyle = gc), (ctx.lineWidth = 1), ctx.beginPath());
    for (let x = this.offsetX % step; x < W; x += step)
      (ctx.moveTo(x, 0), ctx.lineTo(x, H));
    for (let y = this.offsetY % step; y < H; y += step)
      (ctx.moveTo(0, y), ctx.lineTo(W, y));
    (ctx.stroke(),
      isDark
        ? ((ctx.shadowColor = `rgba(6,182,212,0.8)`),
          (ctx.shadowBlur = 12),
          (ctx.strokeStyle = `rgba(6,182,212,.4)`))
        : ((ctx.shadowBlur = 0), (ctx.strokeStyle = `rgba(8,115,145,.82)`)),
      (ctx.lineWidth = 1.5),
      ctx.setLineDash([]),
      ctx.beginPath(),
      ctx.moveTo(this.offsetX, 0),
      ctx.lineTo(this.offsetX, H),
      ctx.moveTo(0, this.offsetY),
      ctx.lineTo(W, this.offsetY),
      ctx.stroke(),
      isDark && (ctx.shadowBlur = 0));
  },
  // Se rellena desde move.axes[n].min/max cuando llega el object model.
  // null evita presentar como universal el recorrido de una maquina concreta.
  workLimits: { x: null, y: null },
  // t_e1f3f979 (regla H, Fase 2.2 · 2026-09-01): bounding box vs soft limits.
  // Pura, sin tocar el DOM. La usan (a) este módulo para colorear los segmentos
  // fuera de área en el canvas, (b) tests/unit/viz-bounds-warnings.test.js, y
  // (c) potencialmente el visor 3D (viz3dWarnings en rotechos.js:5729) en el
  // futuro. Si bounds es null (código vacío / error de parseo) o TODOS los
  // limits son null (máquina sin M208 leído), devuelve {status:'unknown'} y
  // el caller NO debe pintar aviso NI un falso "todo correcto".
  //
  // Convención de limits: {X:{min,max}, Y:{min,max}, Z:{min,max}} con min/max
  // numéricos o null. Ejes con lim==null se IGNORAN — un eje desconocido no
  // genera violación (no inventamos el recorrido de otra máquina) pero tampoco
  // afirma que ese eje esté bien.
  //
  // wcsOffsets (opcional): si llega, se aplica coord_maquina = coord_fichero +
  // offset[axis] y se compara con el limit. t_717c48cc (jul-2026) demostró que
  // un cero de pieza en X=300 hace que un fichero X0..X300 termine en
  // X300..X600 — sin WCS, el chequeo da VERDE y la máquina choca. Por eso
  // está aquí SIEMPRE que se conozca el offset.
  //
  // overflow: positivo = distancia que se sale del recorrido (mm). Es el dato
  // que el operario necesita leer ("X supera X-MAX en 12,4 mm").
  computeBoundsWarnings(bounds, limits, opts) {
    if (!bounds || !isFinite(bounds.minX)) {
      return { status: 'unknown', reason: 'no_bounds' };
    }
    // t_e1f3f979 (P0 del briefing): si TODOS los limits son null
    // (máquina sin M208 leído, mock-server, primera conexión) NO afirmamos
    // "todo correcto" — un falso verde aquí es peor que no decir nada.
    // Devolvemos 'unknown' para que el caller explique que no se pudo
    // comprobar, en vez de pintar el canvas como si nada pasara.
    const _allNull = !limits ||
      ((limits.X == null || (limits.X.min == null && limits.X.max == null)) &&
       (limits.Y == null || (limits.Y.min == null && limits.Y.max == null)) &&
       (limits.Z == null || (limits.Z.min == null && limits.Z.max == null)));
    if (_allNull) return { status: 'unknown', reason: 'no_limits' };

    const axes = ['X', 'Y', 'Z'];
    const offX = opts?.wcsOffsets?.X ?? 0;
    const offY = opts?.wcsOffsets?.Y ?? 0;
    const offZ = opts?.wcsOffsets?.Z ?? 0;
    const axisOff = { X: offX, Y: offY, Z: offZ };
    const axisMinKey = { X: 'minX', Y: 'minY', Z: 'minZ' };
    const axisMaxKey = { X: 'maxX', Y: 'maxY', Z: 'maxZ' };
    const violations = [];
    for (const ax of axes) {
      const lim = limits && limits[ax];
      const fMin = bounds[axisMinKey[ax]];
      const fMax = bounds[axisMaxKey[ax]];
      if (!isFinite(fMin) || !isFinite(fMax)) continue;
      // lim == null/undefined → desconocido → NO inventamos, NO añadimos
      // violación, pero seguimos con el resto de ejes.
      if (lim == null) continue;
      const lMin = lim.min;
      const lMax = lim.max;
      const off = axisOff[ax];
      const mMin = fMin + off;
      const mMax = fMax + off;
      if (lMax != null && mMax > lMax) {
        violations.push({
          axis: ax, side: 'max',
          fileValue: fMax, machineValue: mMax,
          wcsOffset: off, limit: lMax,
          overflow: mMax - lMax,
        });
      }
      if (lMin != null && mMin < lMin) {
        violations.push({
          axis: ax, side: 'min',
          fileValue: fMin, machineValue: mMin,
          wcsOffset: off, limit: lMin,
          overflow: lMin - mMin,
        });
      }
    }
    if (violations.length === 0) return { status: 'ok' };
    return { status: 'over', violations };
  },
  // t_e1f3f979 (regla H, Fase 2.2 · 2026-09-01): formatea el resultado de
  // computeBoundsWarnings en un mensaje corto apto para un toast. Pura, no
  // toca el DOM; la usa el handler del worker postMessage para avisar al
  // operario de que la trayectoria cae fuera del recorrido ANTES de ejecutar.
  //
  // Contrato:
  //   - { status:'ok' }      → null. NO se muestra nada (el canvas ya basta).
  //   - { status:'unknown' } → string explicando que no se pudo comprobar
  //                            ("Límites no disponibles, no se pudo comprobar").
  //                            Un falso "todo OK" aquí sería peor que callar.
  //   - { status:'over', violations:[...] }
  //                          → string listando cada violación en una sola línea
  //                            ("X supera X-MAX en 12,4 mm; Z cae por debajo
  //                            de Z-MIN en 0,8 mm"). El toast dura 3200 ms
  //                            (TCONF.warn), suficiente para 2-3 violaciones.
  //
  // El segundo parámetro `t(key, fallback)` es la función i18n ya inyectada —
  // se pasa desde fuera (no la importamos aquí) para que el test pueda usar
  // un stub sin montar un DOM. Las claves son:
  //   msg.pathBoundsOver       → "Trayectoria fuera de área: {details}"
  //   msg.pathBoundsOverSide   → "{axis} supera {side} en {overflow} mm"
  //                              (side = "X-MAX" / "Y-MIN" / etc.)
  //   msg.pathBoundsUnknown    → "Límites no leídos, no se pudo comprobar"
  //   msg.pathBoundsDisclaimer → "Macros / WCS / cambios de herramienta pueden
  //                              mover la trayectoria real, el aviso mira solo
  //                              el fichero."
  formatBoundsWarning(result, t) {
    if (!result || result.status === 'ok') return null;
    if (result.status === 'unknown') {
      return t(`msg.pathBoundsUnknown`,
        `Límites de recorrido no disponibles: no se pudo comprobar si la trayectoria cabe.`);
    }
    // status === 'over'. La i18n del proyecto (rotechos-i18n.js:77) no
    // interpola — t(key, fallback) devuelve el string tal cual — así que
    // sustituimos {axis}/{side}/{overflow} aquí. El diccionario EN puede
    // ignorar los placeholders si quiere; basta con que su forma tenga
    // sentido al caer el fallback.
    const fmt = (s, vars) =>
      s.replace(/\{(\w+)\}/g, (_, k) => (vars[k] != null ? String(vars[k]) : `{${k}}`));
    const sideLabel = (ax, side) => `${ax}-${side === 'max' ? 'MAX' : 'MIN'}`;
    const details = result.violations.map((v) => fmt(
      t(`msg.pathBoundsOverSide`, `{axis} supera {side} en {overflow} mm`),
      { axis: v.axis, side: sideLabel(v.axis, v.side), overflow: v.overflow.toFixed(1) }
    )).join('; ');
    const head = t(`msg.pathBoundsOver`, `Trayectoria fuera de área:`);
    const disclaimer = t(`msg.pathBoundsDisclaimer`,
      `Macros / WCS / cambios de herramienta pueden mover la trayectoria real; el aviso mira solo el fichero.`);
    return `${head} ${details} — ${disclaimer}`;
  },
  drawAxisLabels(ctx, W, H, isDark) {
    ((ctx.font = `bold 11px monospace`),
      (ctx.fillStyle = isDark
        ? `rgba(255,255,255,.30)`
        : `rgba(60,40,20,.35)`));
    const vm = this.viewMode;
    (ctx.fillText(`X+`, W - 26, this.offsetY - 6),
      ctx.fillText(
        vm === `front`
          ? `Z+`
          : vm === `iso`
            ? `Y+/Z+`
            : vm === `3d`
              ? `3D`
              : `Y+`,
        this.offsetX + 6,
        15,
      ));
  },
  fitView() {
    if (!this.bounds) return;
    const c = this.canvas,
      W = c.width / (window.devicePixelRatio || 1),
      H = c.height / (window.devicePixelRatio || 1),
      b = this.bounds,
      vm = this.viewMode;
    let bx0,
      bx1,
      by0,
      by1;
    if (vm === `front`) {
      bx0 = b.minX;
      bx1 = b.maxX;
      by0 = -(b.maxZ ?? 0);
      by1 = -(b.minZ ?? 0);
    } else if (vm === `iso`) {
      bx0 = b.minX + b.minY * 0.5;
      bx1 = b.maxX + b.maxY * 0.5;
      by0 = -b.maxY * 0.866 - (b.maxZ ?? 0);
      by1 = -b.minY * 0.866 - (b.minZ ?? 0);
    } else if (vm === `3d`) {
      const cx = Math.cos(this.rotAngleX),
        sx = Math.sin(this.rotAngleX),
        cy = Math.cos(this.rotAngleY),
        sy = Math.sin(this.rotAngleY),
        corners = [
          [b.minX, b.minY, b.minZ ?? 0],
          [b.maxX, b.minY, b.minZ ?? 0],
          [b.minX, b.maxY, b.minZ ?? 0],
          [b.maxX, b.maxY, b.minZ ?? 0],
          [b.minX, b.minY, b.maxZ ?? 0],
          [b.maxX, b.minY, b.maxZ ?? 0],
          [b.minX, b.maxY, b.maxZ ?? 0],
          [b.maxX, b.maxY, b.maxZ ?? 0],
        ];
      bx0 = 1 / 0;
      bx1 = -1 / 0;
      by0 = 1 / 0;
      by1 = -1 / 0;
      corners.forEach(function (c) {
        const y1 = -c[1] * cx - c[2] * sx,
          z1 = -c[1] * sx + c[2] * cx,
          x2 = c[0] * cy + z1 * sy;
        if (x2 < bx0) bx0 = x2;
        if (x2 > bx1) bx1 = x2;
        if (y1 < by0) by0 = y1;
        if (y1 > by1) by1 = y1;
      });
    } else {
      bx0 = b.minX;
      bx1 = b.maxX;
      by0 = -b.maxY;
      by1 = -b.minY;
    }
    const bw = bx1 - bx0 || 1,
      bh = by1 - by0 || 1;
    ((this.scale = Math.max(0.1, Math.min((W - 80) / bw, (H - 80) / bh))),
      (this.offsetX = 40 - bx0 * this.scale + (W - 80 - bw * this.scale) / 2),
      (this.offsetY = 40 - by0 * this.scale + (H - 80 - bh * this.scale) / 2),
      (this.dirty = !0));
  },
  rotAngleX: 0.5,
  rotAngleY: 0.3,
  viewMode: `top`,
  setToolPos(x, y) {
    if (this.toolX === x && this.toolY === y) return;
    if (this.toolX === null || this.toolY === null) {
      this.toolX = x;
      this.toolY = y;
      this._targetX = x;
      this._targetY = y;
      this.dirty = !0;
      return;
    }
    this._targetX = x;
    this._targetY = y;
    const dx = x - this.toolX,
      dy = y - this.toolY;
    if (dx * dx + dy * dy > 1e4) {
      this.toolX = x;
      this.toolY = y;
      this._lerpActive = !1;
      this.dirty = !0;
      return;
    }
    if (!this._lerpActive) {
      this._lerpActive = !0;
      const self = this;
      let tPrev = performance.now();
      (function lerpStep(now) {
        // FIX-3: si la pestaña está oculta, parar el suavizado (la transición
        // hacia el objetivo se reanudará al volver visible con un nuevo
        // setToolPos). Evita un rAF "muerto" corriendo a 60fps sin pintar.
        if (document.hidden) { self._lerpActive = !1; return; }
        now = now || performance.now();
        // Suavizado exponencial independiente de framerate: k = 1 - e^(-dt/τ).
        // τ≈39ms reproduce el tacto del antiguo 0.35/frame a 60Hz, pero ya no se
        // acelera al doble en pantallas de 120Hz.
        const dt = Math.min(now - tPrev, 100);
        tPrev = now;
        const k = 1 - Math.exp(-dt / 39),
          dx = self._targetX - self.toolX,
          dy = self._targetY - self.toolY;
        if (Math.abs(dx) < 0.05 && Math.abs(dy) < 0.05) {
          self.toolX = self._targetX;
          self.toolY = self._targetY;
          self._lerpActive = !1;
          self.dirty = !0;
          return;
        }
        self.toolX += dx * k;
        self.toolY += dy * k;
        self.dirty = !0;
        requestAnimationFrame(lerpStep);
      })();
    }
  },
};
(VIZ.init(),
  $(`vizZoomIn`).addEventListener(`click`, () => {
    const c = VIZ.canvas,
      W = c.width / (window.devicePixelRatio || 1),
      H = c.height / (window.devicePixelRatio || 1);
    ((VIZ.offsetX = W / 2 - (W / 2 - VIZ.offsetX) * 1.25),
      (VIZ.offsetY = H / 2 - (H / 2 - VIZ.offsetY) * 1.25),
      (VIZ.scale *= 1.25),
      (VIZ.dirty = !0));
  }),
  $(`vizZoomOut`).addEventListener(`click`, () => {
    const c = VIZ.canvas,
      W = c.width / (window.devicePixelRatio || 1),
      H = c.height / (window.devicePixelRatio || 1);
    ((VIZ.offsetX = W / 2 - (W / 2 - VIZ.offsetX) / 1.25),
      (VIZ.offsetY = H / 2 - (H / 2 - VIZ.offsetY) / 1.25),
      (VIZ.scale /= 1.25),
      (VIZ.dirty = !0));
  }),
  $(`vizReset`).addEventListener(`click`, () => VIZ.fitView()),
  $(`vizClearFile`).addEventListener(`click`, async () => {
    if (SM._cancelInProgress) return; // doble clic: como el ESC
    if (SM.current === STATES.RUNNING) {
      if (
        !(await confirmDashboard(
          t(`dlg.removeRunningJob.title`, `Quitar trabajo en ejecución`),
          t(`dlg.removeRunningJob.msg`, `<p style="color:var(--red)"><b>ATENCIÓN — el corte se cancela.</b></p><p>Vas a <b>cancelar el corte en curso</b>: se para, se apaga el husillo y Z sube. El archivo se <b>descarga del visor</b>, pero <b>sigue en la SD</b> y puedes volver a cargarlo.</p><p>Si solo quieres parar un momento, pulsa <b>Cancelar</b> aquí y usa <b>PAUSA</b>.</p><p>¿Cancelar el trabajo?</p>`),
        ))
      )
        return;
      _clearPollTimer();
      SM._cancelInProgress = !0;
      SM.busy = !0;
      // FIX: M25 PRIMERO (pausar), luego M0 (cancelar), T0+M5 (spindle off)
      // try/finally garantiza SM.busy = false incluso si falla la red
      try {
        try { await RRF.urgentGcode(`M25\nM0\nT0\nM5`); } catch {}
        await sleep(1500);
        await RRF.gcode(`G91\nG1 Z${CFG.safeZClear ?? 50} F1000\nG90`).catch(() => {});
        // Restaurar modo SEDA (SILK) tras cancelar — evitar quedar en PRO
        try {
          const r = await RRF.gcode(`M98 P"${MACROS.setSilk}"`);
          if (!r) throw new Error(`Fallback`);
        } catch {
          RRF.gcode(FALLBACK_SEDA).catch(() => {});
        }
        RRF.gcode(`M98 P"0:/sys/recover_triggers.g"`).catch(() => {});
        clearJob();
        SM.transition(STATES.IDLE, `archivo quitado desde ejecución`);
        toast(t(`msg.jobCancelledAndRemoved`, `Trabajo cancelado y archivo quitado`), `warn`);
        log(`M25+M0+T0+M5+Z↑+SEDA+triggers — archivo quitado en ejecución`, `warn`);
      } finally {
        SM.busy = !1;
        SM._cancelInProgress = !1;
        startPoll();
      }
      return;
    }
    if (SM.current === STATES.PAUSED) {
      if (
        !(await confirmDashboard(
          t(`dlg.removePausedJob.title`, `Quitar trabajo pausado`),
          t(`dlg.removePausedJob.msg`, `<p style="color:var(--red)"><b>ATENCIÓN — el corte se cancela.</b></p><p>El corte está en <b>PAUSA</b>. Vas a <b>cancelarlo</b>: no se podrá reanudar. El archivo se <b>descarga del visor</b>, pero <b>sigue en la SD</b> y puedes volver a cargarlo.</p><p>Si quieres seguir desde donde se quedó, pulsa <b>Cancelar</b> aquí y luego <b>RESUME</b>.</p><p>¿Cancelar el trabajo?</p>`),
        ))
      )
        return;
      _clearPollTimer();
      SM._cancelInProgress = !0;
      SM.busy = !0;
      // FIX: try/finally garantiza SM.busy = false incluso si falla la red
      try {
        try { await RRF.urgentGcode(`M0\nT0\nM5`); } catch {}
        await RRF.gcode(`G91\nG1 Z${CFG.safeZClear ?? 50} F1000\nG90`).catch(() => {});
        // Restaurar modo SEDA (SILK) tras cancelar
        try {
          const r = await RRF.gcode(`M98 P"${MACROS.setSilk}"`);
          if (!r) throw new Error(`Fallback`);
        } catch {
          RRF.gcode(FALLBACK_SEDA).catch(() => {});
        }
        RRF.gcode(`M98 P"0:/sys/recover_triggers.g"`).catch(() => {});
        clearJob();
        SM.transition(STATES.IDLE, `archivo quitado desde pausa`);
        toast(t(`msg.jobCancelledAndRemoved`, `Trabajo cancelado y archivo quitado`), `warn`);
        log(`M0+T0+M5+Z↑+SEDA+triggers — archivo quitado desde pausa`, `warn`);
      } finally {
        SM.busy = !1;
        SM._cancelInProgress = !1;
        startPoll();
      }
      return;
    }
    await RRF.gcode(`M23 ""`).catch(() => {});
    clearJob();
    SM.transition(STATES.IDLE, `archivo descargado`);
    toast(t(`msg.fileUnloaded`, `Archivo descargado`), `info`);
    log(`Archivo descargado — estado IDLE`, `sys`);
  }));
const VIZ_WORKER_CODE = `
self.onmessage = function(e) {
  let text = e.data.text;
  
  // Calcular offsets de línea en segundo plano para no congelar la UI principal
  // C-rot-02: para archivos grandes evitamos construir el Int32Array entero
  // (que era el grueso del coste para >20MB). El main thread ya descarta
  // SM.gcodeLineMap en ese caso.
  let offsets = null;
  let offsetsArray = null;
  if (text.length <= 20000000) {
    offsets = [0];
    let idx = 0;
    while ((idx = text.indexOf(String.fromCharCode(10), idx)) !== -1) {
      idx++;
      offsets.push(idx);
    }
    offsetsArray = new Int32Array(offsets);
  }

  let cx = 0, cy = 0, cz = 0, cf = 1000;
  let currentType = null;
  let coordsList = [];
  let pathMetaList = [];
  let currentPtsStart = 0;
  let currentPtsLength = 0;
  
  function flush() {
    if (currentPtsLength > 1) {
      pathMetaList.push(currentType === 'rapid' ? 0 : 1, currentPtsStart, currentPtsLength);
    }
  }

  function startPath(type) {
    if (type !== currentType) {
      flush();
      if (currentPtsLength > 0) {
        let len = coordsList.length;
        let lx = coordsList[len - 3];
        let ly = coordsList[len - 2];
        let lz = coordsList[len - 1];
        coordsList.push(lx, ly, lz);
        currentPtsStart = (coordsList.length / 3) - 1;
        currentPtsLength = 1;
      } else {
        currentPtsStart = coordsList.length / 3;
        currentPtsLength = 0;
      }
      currentType = type;
    }
  }

  function addPoint(x, y, z) {
    if (currentPtsLength === 0) {
      currentPtsStart = coordsList.length / 3;
    }
    coordsList.push(x, y, z);
    currentPtsLength++;
  }

  let minX = 1/0, maxX = -1/0, minY = 1/0, maxY = -1/0, minZ = 1/0, maxZ = -1/0;
  let totalLines = 0, cutLines = 0, estimatedTimeMs = 0;

  let cursor = 0;
  let len = text.length;

  while(cursor < len) {
    let nextIdx = text.indexOf(String.fromCharCode(10), cursor);
    if (nextIdx === -1) nextIdx = len;
    
    let raw = text.substring(cursor, nextIdx);
    cursor = nextIdx + 1;
    totalLines++;

    let semi = raw.indexOf(';');
    if (semi !== -1) raw = raw.substring(0, semi);
    
    let line = raw.trim().toUpperCase();
    if (!line) continue;

    // Fast extraction regex for G, X, Y, Z, I, J, R, F
    // G0* permite G0/G1/G2/G3 y también G00/G01/G02/G03 (comunes en CAM de doble dígito)
    let m = line.match(/\\bG0*([0123])\\b|X([+-]?[0-9.]+)|Y([+-]?[0-9.]+)|Z([+-]?[0-9.]+)|I([+-]?[0-9.]+)|J([+-]?[0-9.]+)|R([+-]?[0-9.]+)|F([+-]?[0-9.]+)/g);
    if (!m) continue;

    let nx = cx, ny = cy, nz = cz, iVal = 0, jVal = 0, rVal = null, moveType = null;
    let isG = false;

    for (let i = 0; i < m.length; i++) {
      let token = m[i];
      let c = token[0], v = parseFloat(token.substring(1));
      if (c === 'G') { moveType = v; isG = true; }
      else if (c === 'X') nx = v;
      else if (c === 'Y') ny = v;
      else if (c === 'Z') nz = v;
      else if (c === 'F') cf = v;
      else if (c === 'I') iVal = v;
      else if (c === 'J') jVal = v;
      else if (c === 'R') rVal = v;
    }

    if (!isG && moveType === null) moveType = currentType === 'rapid' ? 0 : (currentType === 'cut' ? 1 : null);
    if (moveType === null) { cx = nx; cy = ny; cz = nz; continue; }

    let typeStr = moveType === 0 ? 'rapid' : 'cut';

    // Interpolation for G2/G3
    if (moveType === 2 || moveType === 3) {
      let dx = nx - cx, dy = ny - cy;
      let cx_arc, cy_arc, r;
      if (rVal !== null) {
        let d2 = dx*dx + dy*dy;
        let d = Math.sqrt(d2);
        if (d > 0) {
          let h = Math.sqrt(Math.max(0, rVal*rVal - d2/4));
          let sign = (moveType === 3) ? 1 : -1;
          if (rVal < 0) sign = -sign;
          cx_arc = cx + dx/2 - sign * h * dy / d;
          cy_arc = cy + dy/2 + sign * h * dx / d;
          r = Math.abs(rVal);
        } else { cx_arc = cx; cy_arc = cy; r = 0; }
      } else {
        cx_arc = cx + iVal; cy_arc = cy + jVal;
        r = Math.sqrt(iVal*iVal + jVal*jVal);
      }

      if (r > 0) {
        let startAngle = Math.atan2(cy - cy_arc, cx - cx_arc);
        let endAngle = Math.atan2(ny - cy_arc, nx - cx_arc);
        
        if (moveType === 2 && endAngle >= startAngle) endAngle -= Math.PI * 2;
        if (moveType === 3 && endAngle <= startAngle) endAngle += Math.PI * 2;
        
        let angleDiff = Math.abs(endAngle - startAngle);
        let segments = Math.max(1, Math.ceil(r * angleDiff / 1.0)); // ~1mm resolution
        
        startPath(typeStr);
        if (currentPtsLength === 0) {
          addPoint(cx, cy, cz);
        }

        for (let i = 1; i <= segments; i++) {
          let a = startAngle + (endAngle - startAngle) * (i / segments);
          let px = cx_arc + r * Math.cos(a);
          let py = cy_arc + r * Math.sin(a);
          let pz = cz + (nz - cz) * (i / segments);
          
          addPoint(px, py, pz);
          minX = Math.min(minX, px); maxX = Math.max(maxX, px);
          minY = Math.min(minY, py); maxY = Math.max(maxY, py);
          minZ = Math.min(minZ, pz); maxZ = Math.max(maxZ, pz);
          cutLines++;
          estimatedTimeMs += (Math.sqrt(Math.pow(px-cx,2) + Math.pow(py-cy,2) + Math.pow(pz-cz,2)) / cf) * 60000;
          cx = px; cy = py; cz = pz;
        }
      } else { moveType = 1; }
    }
    
    if (moveType === 0 || moveType === 1) {
      let dx = nx - cx, dy = ny - cy, dz = nz - cz;
      let dist = Math.sqrt(dx*dx + dy*dy + dz*dz);
      if (dist > 0) {
        let feed = moveType === 0 ? Math.max(cf, 5000) : cf;
        estimatedTimeMs += (dist / feed) * 60000;
      }
      
      startPath(typeStr);
      if (currentPtsLength === 0) {
        addPoint(cx, cy, cz);
      }
      if (typeStr === 'cut') cutLines++;
      
      addPoint(nx, ny, nz);
      minX = Math.min(minX, nx); maxX = Math.max(maxX, nx);
      minY = Math.min(minY, ny); maxY = Math.max(maxY, ny);
      minZ = Math.min(minZ, nz); maxZ = Math.max(maxZ, nz);
      cx = nx; cy = ny; cz = nz;
    }
  }

  flush();
  
  let coordsArray = new Float32Array(coordsList);
  let pathMetaArray = new Int32Array(pathMetaList);
  let hasBounds = coordsList.length > 0;
  
  self.postMessage({
    coords: coordsArray,
    pathMeta: pathMetaArray,
    bounds: hasBounds ? { minX, maxX, minY, maxY, minZ, maxZ } : null,
    lineCount: totalLines,
    cutLines: cutLines,
    estimatedTimeMs: estimatedTimeMs,
    offsets: offsetsArray
  }, [coordsArray.buffer, pathMetaArray.buffer, ...(offsetsArray ? [offsetsArray.buffer] : [])]);
};
`;

// eslint-disable-next-line no-unused-vars -- usado por vizLoadGCode fuera de este módulo (rotechos.js:202,238 (typeof) + 2313 + tests/take_screenshots.js:122,138,158,174)
function vizLoadGCode(text, filename) {
  $(`vizPlaceholder`).style.display = `none`;
  // FIX B-01 (2026-07-05): escapar `filename` antes de innerHTML — el nombre lo elige
  // el operario o viene del firmware; defense-in-depth contra XSS local.
  $(`vizFileName`).innerHTML = escHtml(filename) + ' <span style="color:var(--text-3);font-size:10px;margin-left:6px">(Procesando...)</span>';
  
  if (VIZ.activeWorker) {
    VIZ.activeWorker.terminate();
    VIZ.activeWorker = null;
  }
  if (VIZ.activeBlobUrl) {
    URL.revokeObjectURL(VIZ.activeBlobUrl);
    VIZ.activeBlobUrl = null;
  }
  
  const blob = new Blob([VIZ_WORKER_CODE], {type: 'application/javascript'});
  const blobUrl = URL.createObjectURL(blob);
  VIZ.activeBlobUrl = blobUrl;
  const worker = new Worker(blobUrl);
  VIZ.activeWorker = worker;
  
  worker.onmessage = function(e) {
    const result = e.data;
    VIZ.coords = result.coords;
    VIZ.pathMeta = result.pathMeta;
    VIZ.paths = [{ pts: [1] }]; // Dummy compatibility array
    VIZ.bounds = result.bounds;
    VIZ._cachedPaths = null;
    VIZ._cachedViewHash = null;
    VIZ.dirty = true;
    // Forzar resize + repintado explícito: si la pestaña estaba oculta cuando
    // arrancó el worker, el primer frame del loop() se saltea. Sin este push,
    // el visor queda en blanco hasta que el usuario interactúe (zoom/pan) o
    // se dispare visibilitychange.
    VIZ.resize();
    VIZ.dirty = true;
    VIZ.fitView();
    // Llamar draw() directamente si el RAF está pausado por document.hidden
    if (typeof document !== `undefined` && !document.hidden && VIZ.ctx) {
      try { VIZ.draw(); } catch (e) { LOG.error(`VIZ draw post-parse:`, e); }
    }
    
    $(`vizFileName`).textContent = filename;
    $(`vizClearFile`).style.display = `flex`;
    $(`vizPlaceholder`).style.display = `none`;

    // t_e1f3f979 (regla H): aviso de TEXTO al cargar el G-code si la trayectoria
    // cae fuera del recorrido. Se hace ANTES del toast de "cargada" para que
    // el operario lo vea con prioridad (TCONF.warn=3200 ms, aria-live=assertive,
    // role=alert). El brief prohíbe BLOQUEAR la carga: si hay bounds y los
    // soft limits están disponibles y la pieza cabe, no aparece nada.
    try {
      const _bounds = result.bounds;
      const _sl = window._softLimits || {};
      const _wcs = window._wcsOffsets || { X: 0, Y: 0, Z: 0 };
      const _wrn = VIZ.computeBoundsWarnings(
        _bounds,
        { X: _sl.X ? { min: _sl.X.min ?? null, max: _sl.X.max ?? null } : null,
          Y: _sl.Y ? { min: _sl.Y.min ?? null, max: _sl.Y.max ?? null } : null,
          Z: _sl.Z ? { min: _sl.Z.min ?? null, max: _sl.Z.max ?? null } : null },
        { wcsOffsets: _wcs }
      );
      const _msg = VIZ.formatBoundsWarning(_wrn, t);
      if (_msg) toast(_msg, _wrn.status === 'over' ? `warn` : `info`);
    } catch (_e) {
      LOG.error(`viz bounds warning:`, _e);
    }
    
    SM.gcodeLineMap = result.offsets
      ? { text: text, offsets: result.offsets }
      : (log(`Archivo muy grande (${(text.length / 1e6).toFixed(1)}MB): sin mapa de líneas, draw() usará saltos fijos`, `warn`), null);

    // Lint de seguridad: G-code que enciende el husillo (M3) SIN un dwell de spin-up
    // (G4) → el 1er corte podría empezar con el husillo acelerando. El post propio ya
    // inyecta G4 S3; esto solo avisa de archivos de OTROS CAM. Conservador (mínimo falso
    // positivo): avisa solo si hay M3/M03 y NO hay NINGÚN G4/G04 en todo el archivo.
    SM.gcodeSpindleNoDwell = !1;
    try {
      if (text.length < 8000000) {
        const _clean = text.replace(/\([^)]*\)/g, ` `).replace(/;.*$/gm, ` `);
        SM.gcodeSpindleNoDwell = /\bM0?3\b/.test(_clean) && !/\bG0?4\b/.test(_clean);
      }
    } catch (e) {}
      
    SM.lastLoggedLine = null;
    SM.lastLoggedFilePos = null;
    SM.lastLineLogAt = 0;
    SM.estimatedTotalMs = result.estimatedTimeMs > 0 ? result.estimatedTimeMs : result.cutLines * 500;
    SM.estimatedTotalLines = result.cutLines;
    
    toast(`${t(`msg.pathLoaded`, `Trayectoria cargada:`)} ${filename}`, `ok`);
    if (VIZ.activeWorker === worker) {
      VIZ.activeWorker = null;
    }
    if (VIZ.activeBlobUrl === blobUrl) {
      URL.revokeObjectURL(blobUrl);
      VIZ.activeBlobUrl = null;
    }
    worker.terminate();
  };
  worker.onerror = function(err) {
    $(`vizFileName`).textContent = filename;
    log(`Visor: error procesando el G-code: ${err && err.message ? err.message : err}`, `err`);
    toast(`${t(`msg.pathProcessErr`, `No se pudo procesar la trayectoria de`)} ${filename}`, `err`);
    if (VIZ.activeWorker === worker) {
      VIZ.activeWorker = null;
    }
    if (VIZ.activeBlobUrl === blobUrl) {
      URL.revokeObjectURL(blobUrl);
      VIZ.activeBlobUrl = null;
    }
    worker.terminate();
  };

  worker.postMessage({text: text});
}

// ── Espejo de la trayectoria al pendant móvil ───────────────────────────────
// El visor (VIZ) dibuja en #vizCanvas (cockpit). Cuando la pantalla TRABAJO del
// pendant está a la vista (móvil), copiamos ese bitmap a #mpgVizCanvas para
// mostrar la trayectoria sin refactorizar el visor. No-op si el pendant no está
// visible (offsetParent null en escritorio o en otras pantallas del pendant).
// FIX (2026-08-17): antes era una expresion de funcion nombrada auto-invocada.
// El nombre de una expresion de funcion SOLO existe dentro de su propio cuerpo,
// asi que el listener de visibilitychange (lineas 54-62) lanzaba
// `ReferenceError: mpgVizMirror is not defined` al ocultar/mostrar la pestana:
// ni cancelaba el frame del espejo ni lo re-arrancaba. Declaracion + llamada
// explicita: mismo arranque inmediato, pero el nombre queda en el scope.
function mpgVizMirror() {
  const wrap = $('mpgVizWrap');
  if (wrap && wrap.offsetParent !== null) {
    const src = VIZ.canvas,
      dst = $('mpgVizCanvas');
    if (src && dst) {
      const dpr = window.devicePixelRatio || 1,
        cw = wrap.clientWidth,
        ch = wrap.clientHeight;
      if (cw > 0 && ch > 0) {
        const tw = Math.round(cw * dpr),
          th = Math.round(ch * dpr);
        const dimsChanged = dst.width !== tw || dst.height !== th;
        // dirty-check: copiar el bitmap SOLO si VIZ repintó o cambiaron las
        // dimensiones. Antes se copiaba a 60fps siempre → batería/calor en móvil.
        if (dimsChanged || mpgVizMirror._seq !== (VIZ._seq | 0)) {
          mpgVizMirror._seq = VIZ._seq | 0;
          if (dimsChanged) {
            ((dst.width = tw), (dst.height = th));
          }
          const ctx = dst.getContext(`2d`);
          (ctx.setTransform(1, 0, 0, 1, 0, 0), ctx.clearRect(0, 0, tw, th));
          if (src.width > 0 && src.height > 0) {
            const s = Math.min(tw / src.width, th / src.height),
              dw = src.width * s,
              dh = src.height * s;
            ctx.drawImage(src, (tw - dw) / 2, (th - dh) / 2, dw, dh);
          }
          const empty = $('mpgVizEmpty');
          if (empty)
            empty.style.display = VIZ.paths && VIZ.paths.length ? `none` : `flex`;
        }
      }
    }
  } else {
    // Pendant oculto: forzar recopiado la próxima vez que reaparezca
    mpgVizMirror._seq = -1;
  }
  // FIX-3: NO reagendar si la pestaña está oculta. El listener de
  // visibilitychange re-arranca este bucle. Guardamos el id para poder
  // cancelarlo desde fuera y para que la guarda `if (!mpgVizMirror.raf)`
  // evite duplicados al reanudar.
  if (document.hidden) { mpgVizMirror.raf = 0; return; }
  mpgVizMirror.raf = requestAnimationFrame(mpgVizMirror);
}
mpgVizMirror();

// FIX P3 — Auditoría UI 2026-07-18: exponer VIZ a window.* para robustez
// ante reorden futuro de los <script defer> en index.html. Antes, si alguien
// movía rotechos-viz.js ANTES de rotechos.js, el visualizador 3D quedaba
// inerte silenciosamente (typeof VIZ era undefined en el monolito). Ahora
// se puede detectar vía window.VIZ y fallar con un mensaje claro.
window.VIZ = VIZ;
