// ---
// rotechos-bordeador.js — BORDEADOR: recorrido del perímetro del diseño
// ---
// Extraído de rotechos.js (jul-2026, extracción #5 del roadmap) SIN cambios
// de lógica. El operario verifica las bridas: sube la fresa a Z+safeZClear,
// se posiciona en la esquina mín del bounding box del visor (VIZ.bounds),
// baja a Z+safeZ y recorre los 4 lados del perímetro. Confirmación previa
// con la zona exacta; pausa con timeout de 5 min; cancelable.
//
// ⚠️ SEGURIDAD: este módulo MUEVE LA MÁQUINA (G1 sobre el área de trabajo).
// Su contrato de comportamiento está clavado en tests/e2e-bordeador.spec.js
// (BORD1 gate de estado, BORD2 secuencia exacta de G-code, BORD3
// cancelación) — escrito ANTES de la extracción y verde a ambos lados.
//
// Interfaz con el resto de la app: AppState.bord.{active,paused,cancel,
// pause,resume} (updateUI y el flujo de pausa del núcleo la consumen).
// No exporta ningún símbolo propio — todo privado a la IIFE.
//
// Dependencias en runtime (todas globales, resueltas por orden de defer;
// este archivo carga DESPUÉS de rotechos.js — ver index.html):
//   - rotechos-dom.js    → $()
//   - rotechos-i18n.js   → t()
//   - rotechos-logger.js → LOG
//   - rotechos-viz.js    → VIZ.bounds (defer posterior; solo se lee en click)
//   - rotechos.js        → SM, STATES, CFG, AppState, RRF, toast, log,
//                          confirmDialog, _fetchModel, _unwrap,
//                          _clearPollTimer, _pollRun, startPoll,
//                          updateButtonStates
// ---
  (function () {
    const btn = $(`btnBordeador`);
    let isBordering = !1,
      _abortBord = !1,
      _pauseBord = !1;
    AppState.bord.cancel = null;
    AppState.bord.pause = null;
    AppState.bord.resume = null;
    AppState.bord.active = !1;
    AppState.bord.paused = !1;
    function updateBtnState() {
      const canBorder =
        SM.current === STATES.READY &&
        typeof VIZ !== "undefined" &&
        VIZ.bounds != null;
      btn && (btn.disabled = !canBorder || isBordering);
      const svgDesktop = btn ? btn.querySelector(`svg`) : null;
      isBordering
        ? (btn && btn.classList.add(`running`),
          svgDesktop &&
            ((svgDesktop.style.animation = `spin 1s linear infinite`),
            (svgDesktop.style.animationPlayState = _pauseBord
              ? `paused`
              : `running`)))
        : (btn && btn.classList.remove(`running`),
          svgDesktop && (svgDesktop.style.animation = ``));
    }
    // Lógica del bordeador en updateUI gestionada via AppState.bord.active (sin monkey-patch)
    async function handleBordeadorClick() {
      if (isBordering) return;
      const bounds = typeof VIZ !== "undefined" ? VIZ.bounds : null;
      if (!bounds) {
        toast(t(`msg.bordNoPath`, `Sin trayectoria cargada`), `warn`);
        return;
      }
      if (SM.current !== STATES.READY) {
        toast(t(`msg.bordOnlyReady`, `Bordeador solo disponible en estado READY`), `warn`);
        return;
      }
      const { minX, maxX, minY, maxY } = bounds,
        safeZ = CFG.safeZ ?? 10,
        safeZClear = CFG.safeZClear ?? 50,
        feed = CFG.jogFeedrate ?? 3e3;
      isBordering = !0; // 15-sep: antes del await; con un doble clic salían dos recorridos
      if (
        !(await confirmDashboard(
          t(`dlg.bordeador.title`, `Bordeador — Verificar Bridas`),
          t(`dlg.bordeador.pre`, `El cabezal recorrerá el perímetro del diseño`) +
          ` <strong>${t(`dlg.bordeador.raised`, `con la fresa levantada a`)} Z+${safeZClear}</strong> ` +
          `${t(`dlg.bordeador.then`, `para posicionarse y luego a`)} Z+${safeZ} ${t(`dlg.bordeador.during`, `durante el recorrido`)}.<br><br>` +
          `${t(`dlg.bordeador.zone`, `Zona`)}: X[${minX.toFixed(2)} → ${maxX.toFixed(2)}] \xb7 Y[${minY.toFixed(2)} → ${maxY.toFixed(2)}]<br><br>` +
          t(`dlg.bordeador.clear`, `Aseg\xfarate de que el \xe1rea est\xe1 despejada.`),
        ))
      )
        return void (isBordering = !1);
      ((isBordering = !0),
        (_abortBord = !1),
        (_pauseBord = !1),
        (AppState.bord.active = !0),
        (AppState.bord.paused = !1),
        (AppState.bord.cancel = () => {
          _abortBord = !0;
          _pauseBord = !1;
          AppState.bord.paused = !1;
        }),
        (AppState.bord.pause = () => {
          _pauseBord = !0;
          AppState.bord.paused = !0;
          updateBtnState();
        }),
        (AppState.bord.resume = () => {
          _pauseBord = !1;
          AppState.bord.paused = !1;
          updateBtnState();
        }),
        updateBtnState(),
        updateButtonStates(),
        _clearPollTimer(),
        (SM.pollTimer = setInterval(_pollRun, CFG.pollMs)),   // Sprint 4 f2: poll() se llama _pollRun y vive en rotechos-poll.js
        log(`BORDEADOR — Iniciando recorrido del perímetro`, `cmd`),
        toast(t(`msg.bordStarted`, `Bordeador iniciado…`), `info`));
      const feedZ = Math.min(feed, 500);
      const cmds = [
          `G91\nG1 Z${Math.abs(safeZClear)} F${feedZ}\nG90`,
          `G1 X${minX.toFixed(3)} Y${minY.toFixed(3)} F${feed}`,
          `G91\nG1 Z-${Math.abs(safeZClear - safeZ)} F${feedZ}\nG90`,
          `G1 X${maxX.toFixed(3)} Y${minY.toFixed(3)} F${feed}`,
          `G1 X${maxX.toFixed(3)} Y${maxY.toFixed(3)} F${feed}`,
          `G1 X${minX.toFixed(3)} Y${maxY.toFixed(3)} F${feed}`,
          `G1 X${minX.toFixed(3)} Y${minY.toFixed(3)} F${feed}`,
        ];
      let allOk = !0,
        aborted = !1;
      try {
        for (const cmd of cmds) {
          if (_abortBord) {
            aborted = !0;
            break;
          }
          const _bPauseStart = Date.now();
          while (_pauseBord && !_abortBord) {
            if (Date.now() - _bPauseStart > 300000) {
              _abortBord = !0;
              toast(t(`msg.bordTimeout`, `Bordeador auto-cancelado tras 5min en pausa`), `warn`);
              log(
                `BORDEADOR — Auto-cancelado por timeout de pausa (5min)`,
                `warn`,
              );
              break;
            }
            await new Promise((r) => setTimeout(r, CFG.bordPauseMs));
          }
          if (_abortBord) {
            aborted = !0;
            break;
          }
          // PRIORIDAD 1 P0 (campaña AUDIT-20260803): sin homing, el G1 puede
          // mover la maquina sin saber donde esta. RRF normalmente protege
          // con M564 S1, pero con M564 H0 (override de soft limits) el
          // firmware acepta G1 sin requerir homing previo. Abortamos a
          // nivel de UI para mantener simetria con doJogStep (B-01).
          // El guard va DENTRO del bucle, antes de cada G-code, no solo
          // al inicio: si el operario pierde la referenciacion durante
          // el recorrido (endstop triggered, error de red, etc.), salimos
          // del bucle en vez de seguir moviendo.
          if (!AppState.limits.allHomed) {
            toast(t(`msg.bordBlockedHoming`, `Bordeador abortado: ejecuta HOME antes de continuar`), `warn`);
            aborted = !0;
            break;
          }
          // P1 (campaña AUDIT-20260803): si el operario está revisando las
          // bridas y toca un endstop mientras el cabezal pasa por encima,
          // el G1 choca contra el final. El poll ya actualiza
          // AppState.limits.triggers; aquí lo consultamos antes de cada
          // G-code del recorrido. Mismo patrón que doJogStep (rotechos-jog.js:191).
          const _tg = AppState.limits.triggers;
          if (_tg) {
            // Extraigo el número de cada G1 X+/X-/Y+/Y-
            const _n = cmd.match(/G1\s+([XYZ])(-?\d*\.?\d+)/);
            if (_n) {
              const _ax = _n[1];
              const _dist = parseFloat(_n[2]);
              if (_ax === "X" && ((_dist > 0 && _tg.XMax) || (_dist < 0 && _tg.XMin))) {
                toast(t(`msg.bordEndstopX`, `Bordeador abortado: endstop X activo`), `err`);
                aborted = !0;
                break;
              }
              if (_ax === "Y" && ((_dist > 0 && _tg.YMax) || (_dist < 0 && _tg.YMin))) {
                toast(t(`msg.bordEndstopY`, `Bordeador abortado: endstop Y activo`), `err`);
                aborted = !0;
                break;
              }
            }
          }
          if (!(await RRF.gcode(cmd))) {
            allOk = !1;
            break;
          }
          await new Promise((res) => setTimeout(res, CFG.bordCmdDelayMs));
        }
        if (allOk && !aborted) {
          await new Promise((res) => {
            const _wt = setInterval(async () => {
              if (_abortBord) {
                clearInterval(_wt);
                res();
                return;
              }
              const d = await _fetchModel("state", 1500);
              const _st = _unwrap(d);
              if (!_st || _st.status === `idle`) {
                clearInterval(_wt);
                res();
              }
            }, CFG.bordPollMs);
            setTimeout(() => {
              clearInterval(_wt);
              res();
            }, CFG.bordTimeoutMs);
          });
          if (_abortBord) aborted = !0;
        }
      } catch (e) {
        LOG.error("Bordeador error:", e);
        allOk = !1;
      } finally {
        // P2 (campaña AUDIT-20260803): restaurar el estado fisico al terminar
        // (exito, cancelado o error). Si no se hace, kinematicMode=1 queda
        // activo aunque el operario queria estar en SEDA, y el husillo sigue
        // girando si la cancelacion es a media ejecucion. El firmware
        // (bordeador.g del sys/) SI restaura; este modulo debia hacerlo
        // tambien al volver al cockpit.
        (async () => {
          try { await RRF.urgentGcode("M5"); } catch (e) { LOG.warn("bordeador M5 cleanup:", e); }
          try { await RRF.gcode("M98 P\"0:/sys/restore_kinematics.g\""); } catch (e) { LOG.warn("bordeador kinematics:", e); }
        })();
        ((isBordering = !1),
          (_abortBord = !1),
          (_pauseBord = !1),
          (AppState.bord.active = !1),
          (AppState.bord.paused = !1),
          (AppState.bord.cancel = null),
          (AppState.bord.pause = null),
          (AppState.bord.resume = null),
          updateBtnState(),
          updateButtonStates(),
          startPoll());
      }
      aborted
        ? (toast(t(`msg.bordCancelled`, `Contorno cancelado`), `warn`),
          log(t(`msg.bordLogCancelled`, `BORDEADOR — Cancelado por usuario`), `warn`))
        : allOk
          ? (toast(
              t(`msg.bordCompleted`, `Bordeador completado ✓ — Coloca las bridas fuera del perímetro`),
              `ok`,
            ),
            log(t(`msg.bordLogCompleted`, `BORDEADOR — Recorrido completado`), `cmd`))
          : (toast(t(`msg.bordCommErr`, `Bordeador: error en comunicación con el firmware`), `err`),
            log(t(`msg.bordLogErr`, `BORDEADOR — Error durante el recorrido`), `err`));
    }
    (btn && btn.addEventListener(`click`, handleBordeadorClick),
      updateBtnState());
  })();
