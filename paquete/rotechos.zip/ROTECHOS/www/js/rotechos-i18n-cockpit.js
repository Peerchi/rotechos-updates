// Fragmento i18n — COCKPIT / PANEL DE TRABAJO.  (Agente A)
// Claves EN de los textos del cockpit (los que marques con data-i18n en el HTML).
// Formato: "clave": "English text". Clave sugerida con prefijo work./jog./ovr.
window.I18N && window.I18N.add({

  // ── Topbar ──────────────────────────────────────────────────────────────────
  "work.lastJobTitle":     "LAST JOB",
  "work.maxAbbr":          "max.",
  "work.config":           "SETTINGS",
  "work.configTitle":      "Machine configuration",
  "work.schoolMode":       "SCHOOL MODE",
  "work.schoolModeTitle":  "Enable school mode: shows explanations on hover over panels",
  "work.themeTitle":       "Toggle theme",
  "work.fullscreenTitle":  "Full screen",
  "work.reconnectTitle":   "Reconnect",
  "work.kinTitle":         "SEDA MODE (manual)",


  // ── DRO / Coordinates ───────────────────────────────────────────────────────
  "jog.droTitle":      "POSITION",
  "jog.homedWarning":  "Machine not homed — run Home before working",
  "jog.endstops":      "Endstops",
  "jog.distanceLabel": "DISTANCE (mm)",
  "jog.speedLabel":    "SPEED",
  "jog.speedOption.slow":   "Slow ×0.5",
  "jog.speedOption.normal": "Normal ×1.0",
  "jog.speedOption.fast":   "Fast ×2.0",
  "jog.probeLabel":    "Z probe",
  "jog.probeTitle":    "Z probe (touch probe, M558) — Green: free · Red: triggered",
  "jog.zeroXTitle":    "Set X=0",
  "jog.zeroYTitle":    "Set Y=0",
  "jog.zeroZTitle":    "Set Z=0",
  "jog.zeroAllTitle":  "Set XYZ=0",
  "jog.diagHeader":    "Live GPIO diagnostics",
  "jog.diagNote":      "ℹ Pins without a connected sensor may show HIGH due to the MCU's internal pull-up. This is normal and does not indicate a fault.",
  "jog.diagTitle":     "Live GPIO diagnostics: shows the raw value (HIGH/LOW) of each sensor pin. If a pin reads HIGH without a connected sensor, this is normal (internal MCU pull-up).",
  "jog.diag.noSignal": "no signal",
  "jog.diag.noConfig": "unconfigured",
  "jog.diag.activated": "TRIGGERED",
  "jog.diag.probeActivated": "TRIGGERED",
  "jog.diag.free": "FREE",
  "jog.diag.probeZ": "Z Probe (M558)",
  "jog.diag.errHttp": "HTTP Error",
  "jog.diag.networkErr": "network error",


  // ── Jog card ────────────────────────────────────────────────────────────────
  "jog.locked":  "JOG LOCKED — MACHINE RUNNING",
  "jog.title":   "JOG",

  // ── Viz / G-code viewer ─────────────────────────────────────────────────────
  "work.noFile":         "No file",
  "work.vizRemaining":   "REMAINING",
  "work.vizRapid":       "Rapid move (G0)",
  "work.vizCut":         "Cut (G1/G2/G3)",
  "work.vizToolPos":     "Tool position",
  "work.vizClear":       "REMOVE",
  "work.vizClearTitle":  "Remove loaded G-code file",

  // Estado vacío del visor G-code (t_914db8a1 — sustituye el contenido
  // inactivo de #vizPlaceholder por un panel con acción CARGAR G-CODE, zona
  // de drop y últimos trabajos). Sin semántica nueva: cada cadena es la
  // traducción literal del castellano que ya vive en index.html:130-138.
  "work.vizEmptyTitle":    "Load G-code",
  "work.vizEmptySub":      "Choose a saved file or drag one into this area.",
  "work.vizEmptyOpenFiles":"LOAD G-CODE",
  "work.vizEmptyDrop":     "…or drop a .gcode / .g file here to upload and load it",
  "work.vizEmptyRecent":   "Recent jobs",
  "work.vizEmptyAll":      "VIEW FULL HISTORY",

  // ── Console ─────────────────────────────────────────────────────────────────
  "work.consoleTab":       "G-CODE CONSOLE",
  "work.consoleFoldTitle": "Collapse console",
  "work.consoleUnfoldTitle":"Expand console",
  "work.consoleSendTitle": "Send command",
  "work.consoleClearTitle":"Clear lines",

  // ── E-stop / Control column ──────────────────────────────────────────────────
  "work.estopLabel":  "E-STOP",
  "work.estopSub":    "EMERGENCY",
  // t_da03dda6: cuando el paro esta ACTIVO (SM=ERROR), el boton deja de
  // describir la ACCION que va a ejecutarse y pasa a describir el ESTADO
  // de la maquina. ES = texto fuente en rotechos-state-ui.js (fallback).
  "work.estopActiveLabel": "E-STOP ON",
  "work.estopActiveSub":   "M112 SENT",
  "qa.clearAlarm":    "HIDE NOTICE",

  // ── State card metrics ───────────────────────────────────────────────────────
  // "Feed Rate", no "Feed": el ES es "Avance" y en fresado la traduccion
  // estandar es feed rate. Ademas el pendant ya dice FEEDRATE
  // ("pendant.run.feed.lbl"), asi que "Feed" a secas dejaba las dos vistas
  // diciendo cosas distintas para el mismo dato. El texto viene de la clave
  // huerfana "ovr.feedLbl", que HUER-5 detecto que era la BUENA justo antes de
  // que HUER-4a la borrara por muerta.
  "work.feedLbl":  "Feed Rate",
  "work.timeLbl":  "Time",

  // ── Progress card ────────────────────────────────────────────────────────────
  "work.progressTitle": "Progress",
  "work.elapsed":       "Elapsed",
  "work.remaining":     "Remaining",
  "work.totalEst":      "Est. total",

  // ── Exec card ────────────────────────────────────────────────────────────────
  "work.macros":  "MACROS",
  "work.contour": "OUTLINE",

  // ── Override card ────────────────────────────────────────────────────────────
  "ovr.title":    "SPEEDS",

  // ── Files / SD button ────────────────────────────────────────────────────────
  "file.open":    "FILES",

  // ── Macros modal ─────────────────────────────────────────────────────────────
  "work.macrosTitle":   "Macros",
  "work.macrosLoading": "Loading macros…",

  // ── Files modal ──────────────────────────────────────────────────────────────
  "file.title":   "Files",
  "file.loading": "Loading files…",
  "file.refresh": "Refresh",
  "file.upload":  "Upload G-code",

  // ── Sys file modal ───────────────────────────────────────────────────────────
  "sys.loading":  "Loading…",

  // ── File editor modal ────────────────────────────────────────────────────────
  "work.close":    "Close",
  "work.saveToSD": "Save to SD",

  // ── School / tooltip texts ───────────────────────────────────────────────────
  "work.telemSchool":
    "<strong>Controller Telemetry</strong>MCU (microcontroller) temperature measured in real time. Green = normal value, yellow = caution, red = excessive temperature. An overheated MCU can cause step losses or firmware safety stops.",

  "work.kinSchool":
    "<strong>Kinematic Profile</strong>Controls motion physics. SEDA (StealthChop) prioritizes silent and smooth movement, ideal for manual fine positioning. RAYO (SpreadCycle) activates during jobs and configures drivers for maximum torque to prevent step loss.",

  "work.connSchool":
    "<strong>Connection Status</strong>Indicates whether RotechOS is communicating with the Duet/RepRapFirmware controller. Green = connected and responding, red = no connection (firmware not responding or the network link failed). Polling runs every 2 seconds. If connection is lost during a job, the machine KEEPS CUTTING autonomously: the pill turns red and a notice appears, but the job does NOT stop. Do not approach the machine just because the pill is red.",

  "work.themeSchool":
    "<strong>Light/Dark Theme</strong>Toggles between dark (anthracite, recommended in low-light workshop environments) and light (ivory, better for well-lit workshops or outdoor use). Preference is saved automatically.",

  "work.fullscreenSchool":
    "<strong>Full Screen</strong>Hides the browser bar and shows RotechOS full screen. Ideal for workshop use or a dedicated touch screen. Press again (or Esc) to exit.",

  "work.reconnectSchool":
    "<strong>Reconnect to Firmware</strong>Attempts to re-establish communication with RepRapFirmware without reloading the page. Useful if the network link was briefly interrupted or the firmware took time to start. If the controller is active, reconnection takes less than 2 seconds.",


  "jog.droSchool":
    "<strong>Work Coordinates (WCS)</strong>Show the current tool position in the work coordinate system. X and Y are the horizontal axes, Z is the vertical axis. Values update in real time. Use the X=0, Y=0, Z=0 buttons to set the part origin at the current tool position.",

  "jog.wcsSchool":
    "<strong>G54 — Work Offset (WCS)</strong>Shows positions relative to the part origin you define with the Zero buttons. This is the system you will use 99% of the time for machining.",

  "jog.mcsSchool":
    "<strong>MCS — Machine Coordinates</strong>Shows absolute positions relative to the machine's mechanical origin (home). Useful for verifying the real tool position or diagnosing reference issues.",

  "jog.zeroXSchool":
    "<strong>X=0 — Set X origin</strong>Defines the current tool position as X=0 in the work system. Use it after centering the tool over the part's reference edge. Firmware sends G10 L20 P0 X0.",

  "jog.zeroYSchool":
    "<strong>Y=0 — Set Y origin</strong>Defines the current position as Y=0. Use it after positioning the tool on the front or side reference edge. Together with X=0 it establishes the XY part origin. Firmware sends G10 L20 P0 Y0.",

  "jog.zeroZSchool":
    "<strong>Z=0 — Set part surface</strong>Defines the current position as Z=0, normally the top surface of the workpiece. Lower the bit until it touches the workpiece (with paper or a height probe), then press Z=0. Firmware sends G10 L20 P0 Z0.",

  "jog.zeroAllSchool":
    "<strong>XYZ=0 — Reset all origins</strong>Sets X, Y and Z simultaneously to zero at the current position. Useful when the part origin is the same point on all three axes, such as the top corner of a block.",

  "jog.endstopsSchool":
    "<strong>Limit Switches — Live status</strong>Indicators showing the current state of each end-stop sensor. Green = free, red = triggered. If a switch triggers during normal movement it signals a positioning error or collision. They are also used as reference during homing.",

  "jog.titleSchool":
    "<strong>Incremental Movement</strong>Manually moves the machine axis by axis. Choose the step size (0.1 to 500 mm) and press the direction buttons. Short moves are slow (precision) and long moves are fast (positioning). The Z axis is limited to 10 mm maximum for safety.",

  "jog.xySchool":
    "<strong>X/Y Jog buttons</strong>Move the tool on the horizontal axes. The distance depends on the selected step (in PULSE mode) or the tool moves while you hold the button (in CONTINUOUS mode). Keyboard arrow keys also work.",

  "jog.zSchool":
    "<strong>Current Z position</strong>Shows the Z axis position in real time in millimetres relative to the part origin (PIEZA). A negative value means the bit is below the reference surface (Z=0). Watch this value during machining: if it drops further than expected, STOP the job (CANCEL) and check that the part zero is still correct — the bit may have shifted or the material may have moved.",

  "jog.stepSchool":
    "<strong>Step Size (mm)</strong>Select the distance per press, in millimetres. Short steps (0.1, 1) → low speed (precision). Long steps (50, 100, 200, 500) → high speed (fast positioning). The Z axis only accepts up to 10 mm for safety.",

  "work.vizSchool":
    "<strong>G-code Viewer</strong>Shows the toolpath of the loaded file in 3D. The green line shows the already-executed path. Switch between Top, Front and ISO views to review the machining before launching it.",

  "work.vizTopSchool":
    "<strong>Top view</strong>Shows the XY plane of the toolpath: the view you would see looking down at the part from above. Most useful for checking the bit path on the horizontal plane and confirming the part is correctly centred.",

  "work.vizFrontSchool":
    "<strong>Front view</strong>Shows the XZ plane: the depth of each cutting pass seen from the front. Useful for checking Z values and total machining depth, and verifying that no moves go deeper than expected.",

  "work.vizIsoSchool":
    "<strong>Isometric view (ISO)</strong>A 3D perspective view showing all three axes simultaneously. Lets you visualise the complete part and detect errors not visible in flat views, such as toolpaths colliding with clamps or unexpected Z jumps.",

  "work.viz3dSchool":
    "<strong>Free 3D view</strong> — Right-click drag to rotate. Scroll to zoom.",
  "viz3d.warn.zPositive":
    "DANGER: the file contains moves to Z positive. Safe maximum Z = 0 (Z0 is the highest point — above it the cutter enters the spindle housing). Open the G-code and remove any Z > 0 before machining.",

  "work.consoleSchool":
    "<strong>G-code Console</strong>Real-time log of all commands sent and firmware responses. Commands appear in blue, errors in red, warnings in yellow. In Expert mode you can type G-code commands manually in the field below and send them with Enter.",

  "work.estopSchool":
    "<strong>EMERGENCY STOP (Software)</strong>Sends M112 via software to immediately stop motors and turn off the spindle. Use in case of imminent danger. ⚠ <strong>Note:</strong> Causes loss of work coordinates (WCS) as motors lose power. Requires a firmware reboot (M999) and re-homing afterwards.",

  "work.stateSchool":
    "<strong>Machine Status</strong>Shows the current controller phase: IDLE (no file, waiting), READY (file loaded, ready to start), RUNNING (job running), PAUSED (job paused, can be resumed), ERROR (emergency stop, requires reset and re-homing). Colour changes with state.",

  "work.progressSchool":
    "<strong>Job Progress</strong>Shows the progress of the running G-code file: percentage complete, elapsed time since start and estimated remaining time. Remaining time is calculated dynamically and may vary with machining complexity. The bar fills left to right.",

  "work.macrosSchool":
    "<strong>MACROS</strong>Runs custom macros (M98). Configure them in Settings > Macros.",

  "work.contourSchool":
    "<strong>Outline</strong>Runs a perimeter trace of the loaded G-code's boundaries to verify the part fits on the work table.",

  "work.spindleSchool":
    "<strong>SPINDLE</strong>Turns the spindle on or off. Make sure the bit is properly secured.",

  "ovr.titleSchool":
    "<strong>Override (in-cutter speed adjustments)</strong>Adjusts feed rate and spindle speed in real time without stopping the job. 100% = value programmed in the G-code. Reduce feed if there are vibrations or poor cut quality.",

  "ovr.feedResetSchool":
    "<strong>Reset Feed Rate to 100%</strong>Restores feed rate to 100% of the programmed value. Use it when you have finished adjusting and want to return to the original program feed.",

  "ovr.feedMinusSchool":
    "<strong>Reduce Feed Rate</strong>Lowers feed rate by 5%. Use it if you see vibrations, poor finish or hear the spindle struggling.",

  "ovr.feedBarSchool":
    "<strong>Feed Rate bar</strong>Shows the current feed rate percentage relative to the programmed value. Click anywhere on the bar to adjust directly.",

  "ovr.feedPlusSchool":
    "<strong>Increase Feed Rate</strong>Raises feed rate by 5%. Use it if machining is going well and you want to speed up.",

  "ovr.spResetSchool":
    "<strong>Reset Spindle to 100%</strong>Restores spindle speed to 100% of the programmed value. If you lowered the speed to test the material, use this button to return to the optimal CAM cutting speed.",

  "ovr.spMinusSchool":
    "<strong>Reduce Spindle Speed</strong>Lowers spindle speed by 5%. Useful if the material burns or the bit vibrates.",

  "ovr.spBarSchool":
    "<strong>Spindle Speed bar</strong>Shows the current spindle speed percentage. Click anywhere to adjust directly.",

  "ovr.spPlusSchool":
    "<strong>Increase Spindle Speed</strong>Raises spindle speed by 5%. Excessive RPM may damage the bit or material.",

  "work.schoolModeSchool":
    "<strong>School Mode</strong>Enables or disables visual aids and educational tooltips when hovering over control panel displays and buttons.",

  "work.configSchool":
    "<strong>Machine Configuration</strong>Accesses the SD card persistent parameter editor. Allows modifying limits, motor currents, and configuring firmware behavior. Edit with caution: incorrect values can cause locks or physical crashes.",

  // (t_73119cd8) School tip coherente con la nueva etiqueta "ABORT JOB".
  "work.stopSchool":
    "<strong>ABORT JOB — Clean Stop (no reboot)</strong>Stops the active job or macro in a controlled manner (M25+M0): raises the Z axis, turns off the spindle, and keeps the controller powered. <strong>Advantage:</strong> Preserves workpiece coordinate systems (WCS), so you do not lose your zero reference. To halt a run-away homing, use the emergency stop button.",

  "work.recoverSchool":
    "<strong>RE-ARM — Re-arm sensors (no M999)</strong>Re-enables safety limit switches/triggers and clears homing status without restarting the controller. Use if sensors remain triggered and the machine behaves abnormally after a sensor alarm or aborted macro. Do not use while homing is in progress.",

  "work.resetSchool":
    "<strong>RESET — Reboot firmware</strong>Restarts the RepRapFirmware controller after an emergency stop or error. Equivalent to power cycling the machine. After a reset, homing (G28) is mandatory to restore coordinates. Only available when the machine is in an ERROR state.",

  "work.playPauseSchool":
    "<strong>START / PAUSE</strong>Controls the execution of the current job. Launches a loaded file, pauses execution mid-cut safely (raising Z and allowing feed overrides), or resumes from a paused state.",

  "jog.zJogSchool":
    "<strong>Z and A Axes</strong>Z+ raises the spindle, Z- lowers it towards the workpiece. A axis (if installed) controls the rotation of the 4th axis. Use extreme caution when lowering Z to avoid crashing the tool into the material.",

  "work.vizPlaceholderSchool":
    "<strong>G-code Viewer</strong>Drag and drop a .gcode file directly into this area to load and visualize its toolpath, or click LOAD G-CODE to manage one.",

  // Pendant School tooltips (5 claves añadidas t_4557eb03)
  "pendant.dash.files.school":
    "<strong>Files</strong>Opens the SD card file manager: upload, select or remove G-code files.",
  "pendant.dash.start.school":
    "<strong>Start</strong>Launches the currently loaded G-code file (equivalent to M24). Disabled while the machine is busy or errored.",
  "pendant.dash.pause.school":
    "<strong>Pause</strong>Pauses the active job safely (M25): raises Z, stops the spindle and keeps state so you can RESUME later without losing the work origin.",
  "pendant.jog.fine.school":
    "<strong>Precision step (0.25×)</strong>Reduces jog distance to one quarter of the current step. Use it close to the workpiece for fine inspection without overshooting.",
  "pendant.sp.preset.school":
    "<strong>Spindle preset</strong>Sets the target RPM directly on the spindle control card. The machine will ramp the spindle to this speed when turned on.",


  // ── Pendant / Mobile view ────────────────────────────────────────────────────
  // Dashboard tab labels (pendant.dash.*) and bottom-nav (pendant.nav.*)
  "pendant.dash.files":      "FILES",
  "pendant.dash.start":      "START",
  "pendant.dash.pause":      "PAUSE",
  "pendant.dash.spindle":    "SPINDLE",
  "pendant.dash.home":       "HOME",
  "pendant.dash.work":       "WORK",
  "pendant.dash.wcs":        "WCS",
  "pendant.dash.jog":        "JOG",
  "pendant.dash.macros":     "MACROS",
  "pendant.nav.dash":        "PANEL",

  // Error overlay
  "pendant.error.title": "ERROR STATE",
  "pendant.error.msg":   "The machine is locked after the emergency stop was pressed or a critical fault was detected. Press the button below to reboot the firmware and restore the connection.",
  "pendant.error.reset": "REBOOT MACHINE",

  // State pill / header
  "pendant.state.idle":   "IDLE",
  "pendant.state.nofile": "No file",

  // Jog card
  "pendant.jog.locked":   "JOG LOCKED — MACHINE RUNNING",
  "pendant.jog.step.lbl": "STEP",
  "pendant.jog.fine":     "FINE",
  "pendant.jog.home.all": "HOME ALL",
  "pendant.jog.sondaz":   "PROBE Z",
  "pendant.jog.back":     "◀ BACK",

  // WCS tab
  "pendant.wcs.title": "WORK OFFSETS",
  "pendant.wcs.home":  "HOME ALL",
  "pendant.wcs.jog":   "JOG",

  // Files tab

  // Run card
  "pendant.run.feed.lbl":    "FEEDRATE",
  "pendant.run.spindle.lbl": "SPINDLE",
  "pendant.run.trans.lbl":   "ELAPSED",
  "pendant.run.remain.lbl":  "REMAINING",
  "pendant.run.start":       "START",
  "pendant.run.pause":       "PAUSE",
  "pendant.run.dash":        "DASH",

  // Viz (G-code viewer) inside pendant
  "pendant.viz.empty": "Load a file (FILES tab) to see the toolpath",

  // Spindle card
  "pendant.sp.rpm.lbl":    "CURRENT RPM",
  // Modo láser (t_028bceef): la cifra deja de ser RPM y pasa a ser potencia del
  // diodo (0–100 %). El cockpit y el pendant usan esta clave cuando
  // CFG.spindleMode === 'laser'.
  "pendant.sp.power.lbl": "CURRENT POWER",
  // La etiqueta del RPM objetivo llevaba el data-i18n en el <div> ENTERO, que
  // contiene el <span id=pendant2SpTarget> que rellena pendantSetSpTarget()
  // (rotechos.js:4424): setNodeText() habria arrasado el " RPM" posterior.
  // Resuelto envolviendo solo el texto traducible en su propio <span>
  // (index.html:2180); el id y el JS no cambian. "RPM" queda fuera a proposito:
  // es identico en los dos idiomas.
  "pendant.sp.target.lbl": "Target:",
  "pendant.sp.on":         "START",
  "pendant.sp.off":        "STOP",

  // Macros tab
  "pendant.macros.lbl":        "QUICK ACCESS",
  "pendant.macros.bordeador":  "OUTLINE",
  "pendant.macros.sondaz":     "PROBE Z",
  "pendant.macros.sac":        "SAC / M6",
  // (t_73119cd8) mismo cambio que en qa.goto0: aclarar que va a WCS, no MCS.
  "pendant.macros.goto0":      "GOTO 0 PART",
  // (t_df203d89) mismo cambio que en qa.park: "PARK Z" engañaba (mueve 3 ejes).
  "pendant.macros.park":       "PARK",
  "pendant.macros.recover":    "RE-ARM",
  "pendant.macros.all.hdr":    "ALL MACROS",
  "pendant.macros.empty":      "No macros",

  // Empty state when no G-code on SD
  "pendant2.noGcode": "No G-code files on the SD",
  "pendant2.noResults": "No results",
  "pendant2.filesCount": "files",

  // ── Corte de luz (manual §10) ─────────────────────────────────────────────
  // El contenedor padre usa data-i18n-html porque lleva <br>/<b>/<ol>/<li>.
  // OJO AL ORDEN, que es al contrario de lo que parece: applyI18n barre
  // [data-i18n] en rotechos-i18n.js:150 y [data-i18n-html] en la :151, o sea
  // el innerHTML del CONTENEDOR se escribe DESPUES y se lleva por delante lo
  // que applyOne acabara de poner en cada <li>. Por eso los 4 pasos van en
  // ingles AQUI DENTRO: es esta cadena la que lee el operario. Las claves
  // li.g1b-paso-* se mantienen declaradas (el HTML que inyecta esta cadena las
  // sigue llevando y el gate las cuenta como usadas), pero no son las que
  // pintan. Si algun dia se invierte el orden de esas dos lineas, esto sigue
  // funcionando: las dos fuentes dicen lo mismo en ingles.
  "div.10-se-fue-la-luz-7c4a":     "10. Power outage?",
  "div.g1b-se-fue-la-luz-texto":   "If power is cut mid-job, the machine stops and loses its work position (motors without power forget the steps).<br><br><b>Steps when the power returns:</b><ol class=\"ui-pad-f76c\"><li data-i18n=\"li.g1b-paso-1\">Press <b>HOME ALL</b> (key <b>H</b> or quick action button) to reference all axes.</li><li data-i18n=\"li.g1b-paso-2\">Re-probe <b>Z0</b> with the <b>Z probe</b> using the <b>same pad and same point</b> as in the original setup.</li><li data-i18n=\"li.g1b-paso-3\">Verify the origin with <b>GOTO 0</b> and, if possible, run the <b>outline</b> along the perimeter loaded in the original G-code to confirm XY matches.</li><li data-i18n=\"li.g1b-paso-4\"><b>The job must be restarted from the beginning</b> — RotechOS does not recover jobs interrupted by power loss (the already-cut piece has been machined and re-machining the same area worsens the finish).</li></ol><b>Tip:</b> on long pieces, monitor the finish in the re-machined area — it may need a manual pass with the cutter.",
  "li.g1b-paso-1":                 "Press <b>HOME ALL</b> (key <b>H</b> or quick action button) to reference all axes.",
  "li.g1b-paso-2":                 "Re-probe <b>Z0</b> with the <b>Z probe</b> using the <b>same pad and same point</b> as in the original setup.",
  "li.g1b-paso-3":                 "Verify the origin with <b>GOTO 0</b> and, if possible, run the <b>outline</b> along the perimeter loaded in the original G-code to confirm XY matches.",
  "li.g1b-paso-4":                 "<b>The job must be restarted from the beginning</b> — RotechOS does not recover jobs interrupted by power loss (the already-cut piece has been machined and re-machining the same area worsens the finish).",

  // ── Modal OTA ──────────────────────────────────────────────────────────────
  "cfg.ota.check":     "Check for updates",
  "cfg.ota.check.hint":"Checks whether a newer version is available on GitHub. If so, the notice offers «Install now». Nothing is installed without your confirmation.",
  "cfg.ota.zip":       "Install from a ZIP",
  "cfg.ota.zip.hint":  "The release ZIP as downloaded, without unzipping it. Works without internet (for example, connected to the RotechOS network). Keeps your calibration, motor mapping and WiFi.",
  "aria.cfg.ota.zip":  "ZIP of a RotechOS release",

  // ── Licencia ───────────────────────────────────────────────────────────────
  // El <h3> lleva un <svg> (icono GitHub) + texto + <span> con la versión.
  // La clave cubre SOLO el texto del <h3>, el <svg> y el <span> ya tienen sus
  // propias claves. La clave del <h3> empieza con un espacio para mantener el
  // hueco tras el icono.
  "h3.gnu-general-public-l-5eae": " GNU General Public License v3 ",
  "span.gpl-3-0-e1af":            "GPL-3.0",

  // ── Sonda Z y husillo ──────────────────────────────────────────────────────
  // info.probe: HTML con <strong> y <code>. Mantener estructura.
  "info.probe": "Configuration of the Z touch probe (Tool connector, pin E.7) and the automatic tool change positions (SAC / M6). The <strong class=\"mcfg-txt-1d93\">probing values</strong> (speeds, acceleration) are per-machine calibration; the <strong class=\"mcfg-txt-1d93\">positions</strong> (X derived from travel limits, Y physical, Z probe→table) are per-machine preferences. They persist in <code>config-machine.g</code> (calibration) and in <code>config.g</code> (preference) with dual-write.",
  // school.probe: tooltip del botón SONDA Z. HTML con <strong>.
  "school.probe": "<strong>Z touch probe / SAC</strong>Contact probe for Z height (Tool connector, pin E.7) and automatic tool change positions (M6). Probing speeds, Z acceleration and probe-to-table distance are per-machine calibration.",
  // span con el límite de corriente del TMC2160: cifras y unidades idénticas.
  "span.tmc2160-m-x-rms-3100-36ab": "TMC2160 · max RMS 3100 mA (board limit with R0.05Ω)",

  // ── Tooltips de jog del móvil (index.html:2024-2031) ──────────────────────
  // X+ = mover derecha, X- = mover izquierda, Y+ = retroceder, Y- = avanzar,
  // Z+ = subir husillo, Z- = bajar husillo. Sin cifras (las pone el propio botón).
  "title.m-j-x-positivo-xxxx": "Jog X+ — move right",
  "title.m-j-x-negativo-xxxx": "Jog X- — move left",
  "title.m-j-y-positivo-c2a1": "Jog Y+ — move back in Y",
  "title.m-j-y-negativo-xxxx": "Jog Y- — advance",
  "title.m-j-z-positivo-7c9f": "Jog Z+ — raise spindle",
  "title.m-j-z-negativo-xxxx": "Jog Z- — lower spindle",

  // ── Tooltip "SIMULAR (M37)" ────────────────────────────────────────────────
  "title.simular-m37-7c4a": "Simulate job (M37)",

  // ── A11Y-3: aria-label / title del cockpit ────────────────────────────────
  // Auditadas en docs/dev/hallazgos/A11Y-1-aria-pendant-sin-traduccion.md
  // §2.2 y §3.2. Las 9 del pendant las cubre A11Y-2 (obrera6); los 2 title
  // del pendant también (coherencia de bloque). Aquí solo cockpit.

  // Velocidad de jog (group + tooltip gemelo sobre el mismo elemento)
  "aria.cockpit.lastJob":       "Last job",
  "aria.cockpit.speedSelector":  "Jog speed",
  "aria.cockpit.jogStepSelector": "Distance per press",
  "title.cockpit.speedSelector": "Global jog speed multiplier (Slow 0.5× / Normal 1× / Fast 2×)",

  // Indicador Shift+JOG
  "title.cockpit.jogSlowIndicator":
    "Hold Shift during a jog to reduce speed to 25% (useful close to the material)",

  // Lectura efectiva del paso activo
  "title.cockpit.feedEffective":
    "Effective feed rate of the active step with the current multiplier",

  // Botones del visualizador G-code
  "aria.cockpit.vizZoomIn":  "Zoom in",
  "aria.cockpit.vizZoomOut": "Zoom out",
  "aria.cockpit.vizReset":   "Reset view",

  // Estado vacío del visor G-code (t_914db8a1) — aria-label del botón
  // principal y de la zona de drop. Pareja de las 6 work.vizEmpty* arriba;
  // aquí solo la versión accesible (lectores de pantalla con lang="en").
  "aria.cockpit.vizEmptyOpenFiles": "Open the file manager",
  "aria.cockpit.vizEmptyDrop":      "Drop a G-code file here",

  // Consola G-code (title ya tiene work.consoleFoldTitle / consoleUnfoldTitle / consoleSendTitle / consoleClearTitle;
  // aquí cubrimos el aria-label gemelo de los mismos botones)
  "aria.cockpit.consoleUnfold": "Expand console",
  "aria.cockpit.consoleIn":     "Send manual G-code command",
  "aria.cockpit.consoleSend":   "Send command",
  "aria.cockpit.consoleClear":  "Clear lines",

  // Columna derecha — paro / reset / play-pause / spindle
  "aria.cockpit.estop":      "Emergency stop: stop the machine immediately",
  "aria.cockpit.resetEstop": "Reboot firmware after emergency stop",
  "aria.cockpit.playPause":  "Start or pause the machining job",
  "aria.cockpit.spindle":    "Turn the spindle on or off",

  // C-M01 (audit 2026-08-14, severidad MEDIA): skip-link WCAG 2.4.1.
  // Enlace que aparece al tabular y salta al contenido principal (#mainContent).
  // Texto = descripción del destino, no instrucciones de UI (WAI-ARIA APG).
  "aria.skipToMain":         "Skip to main content",

  // Botón Cerrar del modal Macros (mismo texto en aria-label y title)
  "aria.cockpit.rmMacrosClose":  "Close",
  "title.cockpit.rmMacrosClose": "Close",

  // Eje A deshabilitado — 7 inputs del configurador
  // (M92, M906, M569, M203, M201, M566, M425 — §3.2 del acta).
  // Una sola clave cubre los 7 por ser idéntica la cadena ES.
  "title.cockpit.axisAdisabled":
    "A axis disabled: this machine only has X/Y/Z",

  // C-A01 — JOG buttons (X-/X+/Y-/Y+/Z-/Z+): aria-label + title
  // Pareja de claves por eje: aria-label corto, title descriptivo.
  // Mismas direcciones que el ES: positivo = derecha/operario/alejar Z.
  "aria.cockpit.jogXPlus":   "Move X positive (right)",
  "aria.cockpit.jogXMinus":  "Move X negative (left)",
  "aria.cockpit.jogYPlus":   "Move Y positive (toward operator)",
  "aria.cockpit.jogYMinus":  "Move Y negative (toward back of machine)",
  "aria.cockpit.jogZPlus":   "Raise Z (away from material)",
  "aria.cockpit.jogZMinus":  "Lower Z (toward material — verify clearance first)",
  "title.cockpit.jogXPlus":   "Move X positive (toward the right)",
  "title.cockpit.jogXMinus":  "Move X negative (toward the left)",
  "title.cockpit.jogYPlus":   "Move Y positive (toward the operator)",
  "title.cockpit.jogYMinus":  "Move Y negative (toward the back of the machine)",
  "title.cockpit.jogZPlus":   "Raise Z (away from the material)",
  "title.cockpit.jogZMinus":  "Lower Z (toward the material — verify clearance)",

  // C-A02 — sliders feed/spindle: aria-label + title (misma cadena;
  // el control es accesible sin texto visible).
  "aria.cockpit.feedSlider":    "Feed override (10–200%)",
  "title.cockpit.feedReset":    "Reset feed to 100%",
  "title.cockpit.spindleReset": "Reset spindle to 100%",
  "title.cockpit.feedSlider":   "Feed override (10–200%)",
  "aria.cockpit.spindleSlider": "Spindle override (10–200%)",
  "title.cockpit.spindleSlider":"Spindle override (10–200%)",

  // ── aria-label del PENDANT (index.html:1899-1921, 2355-2371) ───────────────
  // Cierra el bug A11Y-1: con lang="en" el lector de pantalla oia espanol.
  // 4 del DRO (ejes X/Y/Z + husillo) y 5 del anillo de navegacion inferior.
  // Patron "Go to ..." + vocabulario del proyecto (JOG, WCS = work offsets,
  // SPINDLE, MACROS).
  "aria.pendant.wcs.x":      "Go to work offsets (X axis)",
  "aria.pendant.wcs.y":      "Go to work offsets (Y axis)",
  "aria.pendant.wcs.z":      "Go to work offsets (Z axis)",
  "aria.pendant.spindle":    "Go to spindle",
  "aria.pendant.nav.dash":   "Go to main panel",
  "aria.pendant.nav.wcs":    "Go to work offsets",
  "aria.pendant.nav.jog":    "Go to jog",
  "aria.pendant.nav.run":    "Go to job",
  "aria.pendant.nav.macros": "Go to macros",

  // ── Cabos sueltos de a11y/i18n cerrados por la directora (2026-07-30) ──────
  // Los 3 botones del selector de velocidad de jog no tenian data-i18n, asi que
  // su nombre accesible (que sale del texto) se anunciaba en espanol con la UI
  // en ingles — visto en el arbol de accesibilidad: "Normal / Lento / Rapido".
  // Y los 2 ultimos title sin clave del pendant.
  "title.pendant.jogMode":   "Current jog mode",
  "title.pendant.jogFine":   "Enable 0.25x precision (slow movement for inspection close to the material)",

  // ── ARIA-LABEL — Pendant (search/sort + spindle RPM slider) — M-M02 a11y ──
  // H-CFG-11 auditoría UI 2026-08-14: 3 inputs del pendant sin programmatic
  // name. Aquí solo las traducciones EN que data-i18n-aria-label resuelve
  // cuando I18N.locale='en'.
  "aria.pendant.files.search": "Search in the pendant file list",
  "aria.pendant.files.sort":   "Sort the pendant file list",
  "aria.pendant.spindle.rpm":  "Target spindle RPM in the pendant",
  "title.pendant.spindle.rpm": "Target spindle RPM in the pendant",
});
