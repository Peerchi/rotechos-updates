// ---
// rotechos-config-homing-maint.js — Banner de mantenimiento del toggle
// "Requerir HOME (G28)" en la pestana REFERENCIAR.
// ---
// Modulo perezoso (t_ec990fc0, 2026-09-05). Antes vivia inline en
// rotechos-config-modal.js dentro del bloque "§4.3 #5 — Mantenimiento
// temporal del toggle Requerir HOME" (~96 lineas, l.2242-2337 en
// lote/2026-09-05). Se carga de forma perezosa al abrir la pestana
// REFERENCIAR, mismo patron que el resto de modulos perezosos
// (`__loadCfgSearch`, `__loadPinesUi`, ...).
//
//   1. Las pestanas y el panel (`#mcfgHomingRequired`, `#mcfgTabHoming`)
//      estan SIEMPRE en el DOM (la UI los crea con el modal en frio).
//   2. La primera vez que cfgPopulate entra en la rama HOMING,
//      rotechos-config-modal.js invoca `__loadHomingMaint()` y el modulo
//      se inyecta via createElement('script').
//   3. En cuanto resuelve, expone `window.ROTECHOS_HOMING_MAINT = { ... }`
//      y el modal llama a setOn()/clearOn()/renderBanner() en los puntos
//      correctos del flujo de populate.
//
// POR QUE SE EXTRAE (criterio de la tarjeta t_ec990fc0):
//   - El bloque lee/escribe SOLO localStorage (`rotechos.homingRequiredOffSince`)
//      y DOM. NO toca config.g ni envia M-codes (la unica excepcion es el
//      boton REACTIVAR, que invoca cfgPersistGlobalLine + RRF.gcode, pero
//      este vive en un click handler del usuario, no en el flujo automatico).
//   - Como el resto de modulos perezosos: aislado, autocontenido y solo
//      se carga si la UI de HOMING entra en juego.
//
// Dependencias globales (cargadas antes por orden de defer):
//   - rotechos-dom.js     → $()
//   - rotechos-i18n.js    → t()
//   - rotechos.js         → escHtml, toast, log
//   - rotechos-config-persist.js → cfgPersistGlobalLine
//   - RRF                 → gcode (para el boton REACTIVAR)
//   - HTML en index.html  → #mcfgHomingRequired, #mcfgTabHoming
// ---
'use strict';
(function () {
  const HOMING_MAINT_KEY = `rotechos.homingRequiredOffSince`;

  function _setHomingMaintTs(ts) {
    try { localStorage.setItem(HOMING_MAINT_KEY, String(ts)); }
    catch (_) { /* modo privado / storage lleno: no bloquear al user */ }
  }
  function _clearHomingMaintTs() {
    try { localStorage.removeItem(HOMING_MAINT_KEY); }
    catch (_) { /* idem */ }
  }
  function _getHomingMaintTs() {
    try {
      const raw = localStorage.getItem(HOMING_MAINT_KEY);
      if (!raw) return 0;
      const ts = parseInt(raw, 10);
      return Number.isFinite(ts) && ts > 0 ? ts : 0;
    } catch (_) { return 0; }
  }

  /** Calcula la duración humana entre `from` y `now`. Idempotente: si from es 0
   *  (sin marca de tiempo), devuelve "hace tiempo". Si la diferencia es negativa
   *  o > 24h, devuelve ">24h" para reflejar la antigüedad. */
  function _homingMaintAgeLabel(from, now) {
    if (!from) return `hace tiempo`;
    const dMs = now - from;
    if (dMs < 0) return `hace tiempo`;
    const min = Math.floor(dMs / 60000);
    if (min < 1) return `hace <1 min`;
    if (min < 60) return `hace ${min} min`;
    const h = Math.floor(min / 60);
    if (h < 24) return `hace ${h} h`;
    return `hace >24 h`;
  }

  /** Renderiza o elimina el banner de mantenimiento. Idempotente:
   *  - si requireHoming=true, elimina el banner si existe.
   *  - si requireHoming=false, crea (o actualiza) el banner al inicio del panel.
   *  El banner usa la clase CSS pre-existente .mcfg-warn-box (ya en rotechos.css:3771),
   *  no requiere CSS nuevo. */
  function _renderHomingMaintBanner() {
    const tab = $(`mcfgTabHoming`);
    if (!tab) return;  // pestaña no en DOM → no hacer nada
    const banner = $(`mcfgHomingMaintBanner`);
    const elReq = $(`mcfgHomingRequired`);
    const reqOff = elReq ? !elReq.checked : false;
    if (!reqOff) {
      if (banner) banner.remove();
      return;
    }
    // Requerir homing está OFF → mostrar banner con la fecha de desactivación
    const ts = _getHomingMaintTs();
    const age = _homingMaintAgeLabel(ts, Date.now());
    const dateStr = ts ? new Date(ts).toLocaleString() : `—`;
    // Texto i18n: claves nuevas — fallback ES por contrato (rotechos-i18n.js:78-81)
    const title = t(`cfg.homing.maintTitle`, `MANTENIMIENTO TEMPORAL — Homing obligatorio desactivado`);
    const body = t(`cfg.homing.maintBody`,
      `El homing obligatorio está desactivado desde <strong>${dateStr}</strong> (${age}). ` +
      `Mientras esté así, cualquier ejecución sin referenciar previamente puede ` +
      `estampar un eje contra el bastidor. Reactiva el toggle cuando termines la prueba.`,
      { dateStr, age });
    const btnLabel = t(`cfg.homing.maintReactivate`, `Reactivar homing obligatorio`);
    const html =
      `<div class="mcfg-warn-box" id="mcfgHomingMaintBanner" role="alert" data-i18n-html-pending="cfg.homing.maintBody">` +
        `<div class="mcfg-warn-header-2" data-i18n="cfg.homing.maintTitle">${escHtml(title)}</div>` +
        `<p style="margin:0 0 10px;font-size:12px;line-height:1.5" data-i18n="cfg.homing.maintBody">${body}</p>` +
        `<button type="button" class="sm-btn" id="btnHomingMaintReactivate" ` +
          `style="background:var(--warn-strong);color:var(--text-inv);border:none;font-weight:700">${escHtml(btnLabel)}</button>` +
      `</div>`;
    // Si ya existe, lo sustituimos; si no, lo creamos al inicio del panel.
    if (banner) {
      banner.outerHTML = html;
    } else {
      // Insertar como primer hijo del panel — operatorio claro en el flujo visual.
      tab.insertAdjacentHTML(`afterbegin`, html);
    }
    // Bind del botón REACTIVAR (idempotente: si el DOM se sustituyó, el listener
    // anterior queda colgado en el nodo viejo; lo re-bindeamos contra el nuevo).
    const btn = $(`btnHomingMaintReactivate`);
    if (btn) {
      btn.onclick = async () => {
        const req = $(`mcfgHomingRequired`);
        if (!req) return;
        // Mismo código que el onchange del toggle → consistencia con la UX del toggle.
        req.checked = true;
        const reqBool = `true`;
        cfgPersistGlobalLine(`requireHoming`,
          `global requireHoming = ${reqBool}  ; Si false: permite RAYO y ejecución sin homing previo`);
        RRF.gcode(`set global.requireHoming = ${reqBool}\nM564 H1`);
        toast(`${t(`msg.homingRequired`, `Homing obligatorio`)} ${t(`msg.enabled`, `activado`)}`, `info`);
        log(`requireHoming → true (MANTENIMIENTO CERRADO vía banner — ${new Date().toISOString()})`, `info`);
        _clearHomingMaintTs();
        _renderHomingMaintBanner();
      };
    }
  }

  // API expuesta. `bindOnce()` lo invoca el modal tras cargar el modulo (de
  // momento no necesita enganchar listeners extra — el toggle de HOMING es
  // un input del HTML que cfgPopulate ya gestiona). Las tres primitivas
  // (`setOn`, `clearOn`, `renderBanner`) las invoca el modal en los
  // mismos puntos donde antes llamaba a las funciones inline.
  window.ROTECHOS_HOMING_MAINT = {
    setOn: _setHomingMaintTs,
    clearOn: _clearHomingMaintTs,
    renderBanner: _renderHomingMaintBanner,
    // expuesta para tests / depuración
    _getTs: _getHomingMaintTs,
    _ageLabel: _homingMaintAgeLabel,
    HOMING_MAINT_KEY,
  };
})();
