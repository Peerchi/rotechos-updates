/* ---
 * rotechos-const.js — Constantes compartidas del shell.
 *
 * Bloques extraídos del monolito rotechos.js (tarjeta t_4d48a09a, 2026-08-11):
 *   - #9  MACROS          (rutas de macros RRF, antes L173-186 monolito)
 *   - #10 FALLBACK_SEDA   (cadena M201+M566, antes L203 monolito)
 *   - #20 CFG             (constantes de UI, antes L609-642 monolito)
 *
 * POR QUÉ ES UN MÓDULO DEFER Y NO LITERAL INLINE:
 *   - MACROS lo consumen 4 defer modules (rotechos-file-ops, rotechos-macros,
 *     rotechos-modules, rotechos-viz) y el monolito. Si fuera inline, cada defer
 *     tendría que redeclararlo → drift garantizado.
 *   - FALLBACK_SEDA lo consume rotechos-file-ops.js:64 además del monolito
 *     (4 call sites: L773 forceError, L2285 Escape, L2826 cancelMacro,
 *     L3266 _showLimitDialog). Cadena M201+M566 que se ejecuta cuando algo
 *     ya ha ido mal — NO cambiar ni un valor ni el orden.
 *   - CFG lo consumen 8 defer modules (rotechos-jog, rotechos-bordeador,
 *     rotechos-led, rotechos-viz, rotechos-gcode-map, rotechos-spindle,
 *     rotechos-config-modal) y el monolito. rotechos-config-modal.js MUTA CFG
 *     (maxRPM, spindleMin, spindleRamp, mistEnabled, coolEnabled, jogFeedX/Y/Z/A
 *     en L886-908 / L947-948 / L1270-1274 / L2398-2408) — debe seguir siendo
 *     el MISMO objeto para que las mutaciones se vean desde el monolito.
 *
 * CONTRATO DE CARGA:
 *   Este módulo debe cargarse con <script defer> ANTES que:
 *     - rotechos.js (monolito)
 *     - rotechos-file-ops.js (lee MACROS.setSilk y FALLBACK_SEDA)
 *     - rotechos-macros.js (lee MACROS.*)
 *     - rotechos-modules.js (lee MACROS.sondaZ)
 *     - rotechos-viz.js (lee MACROS.setSilk)
 *     - rotechos-config-modal.js (lee y MUTA CFG)
 *     - rotechos-gcode-map.js (lee CFG.logDebounceMs, CFG.logMaxLen)
 *     - rotechos-jog.js / rotechos-bordeador.js / rotechos-led.js
 *       / rotechos-spindle.js (leen CFG.*)
 *
 * PUENTES EN EL MONOLITO (rotechos.js):
 *   El monolito conserva `const FALLBACK_SEDA = window.FALLBACK_SEDA;` y
 *   `const CFG = window.CFG;` para preservar:
 *     - el assert `tests/unit/lint-gcode.test.js:292` que exige literalmente
 *       `SOURCE.includes('const FALLBACK_SEDA = ')` sobre el contenido de
 *       rotechos.js (test defensivo contra futuras regresiones de inline
 *       hardcoded).
 *     - el contrato interno del monolito: el resto del archivo referencia
 *       `CFG.xxx` y `FALLBACK_SEDA` como si fueran locales — el puente
 *       mantiene ese patrón sin tocar los 50 call sites.
 *   MACROS no necesita puente en el monolito: el monolito ya lo expone a
 *   `window.MACROS` desde su origen (rotechos.js:187 histórico); aquí la
 *   declaración se MUEVE y la asignación a window se queda en este módulo.
 *
 * PENDIENTE DE BANCO (Sergi, jul-2026): FALLBACK_SEDA acaba en la placa.
 *   El string `M201 X80 Y80 Z30\nM566 X30 Y30 Z10 P1` se ejecuta como
 *   urgentGcode de emergencia. Su contenido refleja los valores SEDA
 *   auditados vs globals SEDA en sys/globals.g:57-64 (acel MÁS alta que
 *   silk para aborto rápido, jerk MENOR para evitar tirones al abortar).
 *   NO modificar desde la UI — sale del firmware set_silk.g.
 * --- */

// ---
// MACROS — Paths centralizados de macros ejecutables vía M98
// Cambiar el nombre de una macro = cambiar aquí, no buscar en el código.
// ---
const MACROS = {
  // Perfiles cinemáticos (sys — sin prefijo: RRF los busca en 0:/sys/)
  setSilk:    `set_silk.g`,
  setPro:     `ramp_to_pro.g`,
  // Macros de sistema
  homeAll:    `0:/sys/homeall.g`,
  // Macros de usuario
  goto0:      `0:/macros/goto0.g`,
  park:       `0:/macros/park.g`,
  coreografia: `0:/macros/coreografia.g`,
  sondaZ:     `0:/macros/sonda_Z.g`,
  probe3d:    `0:/macros/probe3d.g`,
  clearZero:  `0:/macros/clear_zero.g`,
};
window.MACROS = MACROS; // exponer para depuración y acceso desde index.html

// H-03 (auditoría acel/jerk 2026-07-11): constante única para el fallback SEDA
// "safety-off" que se ejecuta cuando el macro `set_silk.g` no está disponible
// (SD corrupta, SD no montada, error de parseo). Esta constante reemplaza las 5
// réplicas literales `M201 X80 Y80 Z30\nM566 X30 Y30 Z10 P1` que existían en
// catch-blocks de `RRF.gcode(\`M98 P\"${MACROS.setSilk}\"\`)`.
//
// VALORES (auditados vs globals SEDA en sys/globals.g:57-64):
//   acel X80 Y80  vs silk_accel_x/y = 60  (MÁS alto: aborto rápido)
//   acel Z30      vs silk_accel_z = 20  (MÁS alto: aborto rápido)
//   jerk X30 Y30  vs silk_jerk_x/y = 80  (MENOR: sin tirones al abortar)
//   jerk Z10      vs silk_jerk_z = 25  (MENOR: sin tirones al abortar)
//
// Diseño tácito: priorizar la velocidad de frenado (acel alta) sin saltos
// peligrosos (jerk bajo). El comentario en los call-sites ahora apunta aquí.
const FALLBACK_SEDA = `M201 X80 Y80 Z30\nM566 X30 Y30 Z10 P1`;
window.FALLBACK_SEDA = FALLBACK_SEDA; // exponer para rotechos-file-ops.js y otros defers

// ---
// CONFIGURACIÓN Y CONSTANTES
// ---
// Objeto de constantes de UI. Los defer modules leen y mutan estas
// propiedades en caliente (rotechos-config-modal.js cambia maxRPM,
// spindleMin, spindleRamp, mistEnabled, coolEnabled, jogFeedX/Y/Z/A —
// por eso CFG se expone a window y se reutiliza por referencia, no por
// copia: cualquier `CFG.maxRPM = 22000` desde el modal se ve al instante
// en todos los consumidores.
const CFG = {
  maxRPM: 24e3,
  pollMs: 500,        // RUNNING/PAUSED: 2 req/s — reduce carga ESP32 durante mecanizado
  pollIdleMs: 3000,   // IDLE: 0.33 req/s — reduce carga ESP32 al máximo cuando no se trabaja
  jogFeedrate: 1e3,
  jogFeedX: 1e3,
  jogFeedY: 1e3,
  jogFeedZ: 500,
  jogFeedA: 1e3,
  mistEnabled: !1,
  coolEnabled: !1,
  safeZ: 10,
  safeZClear: 50,
  spindleMin: 6e3,
  spindleRamp: 0,        // Segundos de rampa al arrancar spindle (0 = sin rampa, directo)
  consoleMaxLines: 200,
  otaLogMax: 20,
  logDebounceMs: 120,
  logMaxLen: 140,
  ovDebounceMs: 120,
  ovFeedSyncMs: 4e3,
  ovFeedWarnMs: 8e3,   // H-2 (2026-08-17_busca-el-monolito): si el feed override
                       // diverge del firmware más de este tiempo, avisar al
                       // operario (toast err). Antes: 0s de aviso, divergía
                       // silenciosamente mientras la red parpadeaba.
  ovSpindleSyncMs: 2e3,
  pollRaceTimeoutMs: 1500,
  bordTimeoutMs: 300e3,
  bordPollMs: 300,
  bordCmdDelayMs: 150,
  bordPauseMs: 200,
  axisFlashMs: 700,
  reloadDelayMs: 1500,
  otaReloadMs: 3e3,
  reconnRetries: 45,
  reconnIntervalMs: 2e3,
  reconnFirstMs: 3e3,
};
window.CFG = CFG; // exponer para defers (rotechos-jog, rotechos-bordeador,
                  // rotechos-led, rotechos-viz, rotechos-gcode-map,
                  // rotechos-spindle, rotechos-config-modal) y para el
                  // monolito, que conserva un puente local `const CFG = window.CFG`.

// ---
// R-02 (2026-08-30) — SSOT de "¿esta macro necesita confirmarse?"
// ---
// POR QUÉ EXISTE
//   Había CUATRO sitios decidiendo esto por su cuenta con listas blancas de
//   nombres que NO coincidían entre sí (medido el 2026-08-30):
//     · rotechos-macros.js:155  (lista del cockpit)   …|park|coreografia
//     · rotechos-macros.js:867  (rmMacrosCenterList)  …|park|torno
//     · rotechos.js:5519        (icono ⚠ del pendant) …|goto|home   (sin park)
//     · rotechos.js:pendantExecMacro                  sin lista: confirma SIEMPRE
//   Consecuencias reales, contra las macros que existen de verdad en
//   ROTECHOS/macros/ (`ls ROTECHOS/macros/*.g`):
//     · `torno` NO EXISTE — patrón muerto que nunca casó con nada.
//     · `coreografia.g` SÍ existe, mueve la máquina, y `rmMacrosCenterList`
//       la ejecutaba SIN preguntar. Es justamente la macro que el protocolo
//       de banco usa para demostrar el escudo M581.
//     · `spindle_warmup.g` (arranca el husillo), `clear_zero.g` (borra el
//       cero de pieza) y `probe_xy_auto.g` no estaban en NINGUNA lista.
//
// LA REGLA, Y POR QUÉ ES ÉSTA
//   La decisión ya estaba tomada y escrita en rotechos.js (K-COB-01,
//   t_752b8b07): «la lista solo conoce nombres de archivo, no lo que hace la
//   macro». Una lista blanca de nombres es una apuesta a que nadie añadirá
//   una macro nueva que mueva la máquina — y el operario puede crear las
//   suyas. Así que se invierte: se confirma SIEMPRE, salvo la única macro
//   cuyo uso legítimo ES con la máquina en marcha.
//
//   `vssc.g` (Variable Spindle Speed Control, anti-chatter) es esa excepción:
//   se lanza a propósito mientras se está cortando, y los cuatro sitios ya la
//   excluían por separado con `/vssc/i`.
//
// LO QUE ESTA FUNCIÓN **NO** DECIDE
//   Con QUÉ se pregunta. Eso sigue siendo de cada superficie y es intencionado:
//     · cockpit  → `confirmDashboard` (solo pregunta en MODO ESCUELA)
//     · pendant  → `confirmDialog`    (pregunta siempre)
//   Unificar eso reabriría una decisión de producto de Sergi. Aquí solo se
//   unifica QUÉ macros entran en la pregunta, que es donde estaba el fallo.
const MACRO_SIN_CONFIRMACION = /vssc/i;
function macroNecesitaConfirmacion(nombre) {
  return !MACRO_SIN_CONFIRMACION.test(String(nombre || ``));
}
window.MACRO_SIN_CONFIRMACION = MACRO_SIN_CONFIRMACION;
window.macroNecesitaConfirmacion = macroNecesitaConfirmacion;
