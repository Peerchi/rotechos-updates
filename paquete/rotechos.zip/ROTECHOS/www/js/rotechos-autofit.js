/* ---
 * rotechos-autofit.js — la interfaz se ajusta sola a la pantalla del operario.
 *
 * POR QUE EXISTE (decision de Sergi, 2026-08-26)
 * ---
 * "No quiero tener que hacer scroll con el raton en el dashboard ni en las
 * ventanas de configuracion: quiero tenerlo todo al alcance de la vista."
 *
 * Medido en navegador ANTES de tocar nada (mock en :3099, SW desregistrado):
 *
 *   Dashboard, columna derecha (PARO -> EJECUTAR):
 *     1280x720  -> se pasa 275 px      1512x945 -> 82 px      1920x1080 -> 328 px
 *   Dashboard, columna izquierda (DRO + JOG):
 *     1280x720  -> 83 px               #jogCard ademas scrollea por dentro 111 px
 *   Modal de CONFIGURACION a 1512x945 (panel util: 623 px de 945):
 *     11 de 21 pestanas obligaban a scroll (motores 429, LED RGB 357, PIN 275,
 *     identidad 108, velocidades 84, sonda 75, teclado 61, controladora 43,
 *     referenciar 34) y el propio MENU lateral se pasaba 205 px.
 *
 * El dato que explica el bug de raiz: a 1920x1080 el desborde es MAYOR que a
 * 1512x945. La compactacion del cockpit estaba escalonada por ANCHO de
 * viewport (@media width>=1920 anade +6 px de padding a cada tarjeta) con una
 * sola banda por ALTURA (max-height:960px, bloque K2 de rotechos.css). O sea:
 * el layout crecia con el ancho de la pantalla mientras que lo que decide si
 * algo cabe es el ALTO. Una pantalla ancha y baja (1920x800, muy comun en
 * portatiles de taller) recibia la version mas holgada en el sitio con menos
 * altura disponible.
 *
 * QUE HACE
 * --------
 * Para cada contenedor que no debe scrollear (las dos columnas del cockpit, el
 * menu lateral de configuracion y el panel de ajustes activo) mide cuanto pide
 * su contenido y cuanto hay, y aplica un factor con `zoom`:
 *
 *   1. Mide a 1:1 (zoom vacio): natural = scrollHeight, hueco = clientHeight.
 *   2. Si no cabe, PRIMERO pliega texto explicativo por niveles (data-fit-level
 *      en el contenedor; las reglas viven en rotechos.css). Nunca pliega un
 *      control: solo prosa que se puede recuperar en MODO ESCUELA o en la
 *      propia ventana de ayuda.
 *   3. Con el contenido ya plegado, calcula z = hueco / natural y lo aplica.
 *   4. Si sobra sitio (pantallas grandes), z sube hasta MAX para que el panel
 *      respire en vez de dejar un hueco muerto abajo.
 *
 * POR QUE `zoom` Y NO `transform: scale()`
 * ---
 * `zoom` reflowea de verdad: el hijo conserva su caja renderizada (medido:
 * .col-right a zoom .85 sigue ocupando sus 885 px en pantalla) y lo que cambia
 * es el espacio logico que ve el contenido (885 -> 1041 px), asi que el texto
 * se recoloca y las coordenadas de pulsacion siguen siendo correctas.
 * `transform: scale()` NO reflowea (deja el hueco original y desalinea el area
 * pulsable) y ademas emborrona el texto en pantallas sin HiDPI.
 *
 * Un navegador sin soporte de `zoom` (Firefox < 126) ignora la propiedad y se
 * queda EXACTAMENTE con el comportamiento anterior: scroll dentro de la
 * columna. Degradacion limpia, sin pantalla rota.
 *
 * LO QUE ESTE MODULO NO HACE
 * ---
 *  - No toca el pendant movil (<768 px): ahi el scroll con el dedo es correcto
 *    y los botones grandes son deliberados (v173/v182).
 *  - No toca .col-center: el visor 3D dimensiona su canvas por clientWidth y
 *    reparte altura por flex; ya cabia en las 7 medidas y meterle zoom solo
 *    conseguiria un canvas escalado.
 *  - No toca las pestanas de DOCUMENTACION del modal (GUIA MECANIZADO y WIKI
 *    CNC): son textos largos de lectura, no controles. Decision de Sergi
 *    2026-08-26: ahi el scroll se acepta; encogerlos hasta que quepan seria
 *    ilegible y paginarlos, peor para leer.
 *  - No baja de MIN ni sube de MAX: por debajo del suelo se prefiere un scroll
 *    honesto a un texto que no se lee de pie frente a la maquina.
 * --- */
'use strict';

const AUTOFIT = {
  /* Suelo de legibilidad. El cockpit aguanta mas compactacion que el modal
     porque sus textos son etiquetas cortas (AVANCE, WCS, RPM) mientras que en
     configuracion se leen numeros que se teclean (pasos/mm, corrientes). */
  MIN_COCKPIT: 0.78,
  /* 0.80 y no 0.85: el modal tiene un suelo tipografico propio de 13 px
     (rotechos.css, "#machineConfigModal .mcfg-panel *{font-size:max(13px,...)}"),
     asi que a 0.80 el texto mas pequeno del panel sigue siendo 10,4 px — por
     encima del suelo de 10 px que el proyecto adopto en v171 para lo que se
     lee de pie frente a la maquina. Cada decima contaba: con 0.85 VELOCIDADES
     a 1280x720 se quedaba a 12 px de caber y con 0.82, ya en MODO ESCUELA, a
     10, y con el buscador nuevo en la cabecera LED RGB se quedaba a 8.
     0,78 es el limite real: 13 x 0,78 = 10,14 px, todavia por encima del suelo
     de 10 px de v171. Por debajo de ahi ya no se encoge mas — se recorta mas
     prosa, que es lo que hacen los niveles de plegado.
     En el cockpit el suelo es mas bajo (0.78) y ahi el compromiso SI se nota:
     sus etiquetas parten de 10 px, asi que en la pantalla mas apretada bajan a
     ~8. Es la decision de Sergi de 2026-08-26, tomada a sabiendas: antes de
     partir la vista en dos, se encoge. */
  MIN_MODAL: 0.78,
  /* Suelo MODAL unico: en cualquier ancho el modal respeta 0.78 (mismo suelo
     tipografico que el resto del proyecto, 13 px * 0.78 = 10.14 px). Por debajo
     de ese suelo ya no se encoge mas — se recoloca o se pliega prosa, que es
     lo que hacen los niveles de plegado y la barra lateral reordenada en
     TABLETA vertical (768-879 px). Antes MODAL_MIN_NARROW=0.55 permitia bajar
     a 0.55 en <880 px, pero a ese zoom los textos de ayuda se quedaban a
     ~6-7 px, ilegibles, y el gate daba verde a costa de encoger el texto.
     Acta: docs/dev/hallazgos/tableta-config-acabado-lineas-enteras.md. */
  /* MAX: techo de crecimiento en pantalla grande.
     Antes 1.25 (25%): un monitor 2000x1100 que sobraba 4% quedaba en z=1
     (el guard "1 < z < 1.08 -> z=1" en fitOne se lo comia), y para cuando
     sobraba lo bastante para notarlo el cap ya era inutil. Sergi lo quiere
     al reves en t_709342b8: que aproveche el monitor. Medido: entre 1.0 y
     1.20 el operario no mueve el cuello para leer y los controles no se
     salen de la caja del cockpit. Por encima de 1.20 la tarjeta del visor
     empieza a tapar a la del estado y el operario se echa hacia atras.
     1.15 = 15% = un crecimiento util en QHD (2560x1440 sobra un 33% sobre
     1920x1080, asi que un cap de 15% protege de pasarse) sin volver la
     interfaz gigante en un 4K. */
  MAX: 1.15,
  /* 18-oct-2026 (Sergi): «quiero que el dashboard ocupe la pantalla completa
     aprovechando los espacios en cualquier tamano de pantalla». Hasta aqui el
     crecimiento iba por el tamano del MONITOR y con techo 1.15, asi que a
     2560x1440 la columna derecha dejaba 472 px vacios abajo y a 1440x900 la
     izquierda 171. Ahora las dos columnas del cockpit crecen en proporcion a
     su ANCHO (que ya sigue al monitor, ver rotechos.css «pantalla completa»):
     a zoom = ancho / COL_REF_W el contenido ve siempre los 300 px para los que
     esta disenado, y si no cabe de alto la correccion de fitOne lo baja hasta
     que cabe. El modal de configuracion sigue con MAX. */
  COL_REF_W: 300,
  MAX_COCKPIT: 2.2,
  /* La barra superior y las tarjetas del centro (cabecera del visor, ESTADO y
     consola) siguen a las columnas. El lienzo del visor NO lleva zoom: dibuja
     por clientWidth y traduce el doble toque a coordenadas de maquina. */
  /* Lo que el crecimiento deja libre en la columna derecha (px a escala 1)
     para los paneles que aparecen solos: progreso (131 px medidos a 1440x900),
     REINICIAR tras un PARO (118). Sin esta reserva, al aparecer uno el zoom
     bajaba y el PARO encogia justo al pulsarlo. */
  RESERVA_DERECHA: 140,
  /* Si uno ya esta a la vista, ya cuenta en el contenido: se descuenta. */
  TRANSITORIOS: [`resetPanel`, `progressCard`],
  _reservaLibre() {
    const visto = this.TRANSITORIOS.reduce((s, id) => {
      const el = $(id);
      return s + (el && el.offsetParent !== null ? el.offsetHeight : 0);
    }, 0);
    return Math.max(0, this.RESERVA_DERECHA - visto);
  },
  BARRA_REF: { w: 1440, h: 900 },
  MAX_BARRA: 2,
  /* Tolerancia en px: por debajo de esto el navegador no pinta barra. */
  TOL: 1,
  /* Margen de seguridad al calcular el factor. Sin el, el redondeo del
     navegador dejaba residuos de 2-4 px (medido: motores +2, visor +4) — dos
     pixeles de desborde pintan barra igual que doscientos. Con 2 aun quedaba
     1 px en VELOCIDADES por el redondeo del factor a 3 decimales; 4 cierra.
     4-oct: 6. En el Mac, con la fuente del sistema (SF Pro), la columna
     izquierda a 1280x720 en MODO ESCUELA se quedaba a +2 px con 4. */
  MARGIN: 6,
  /* Niveles de plegado definidos en rotechos.css (data-fit-level 1..3). */
  LEVELS: 3,
  /* Paneles de lectura: se les permite scroll y no se les toca el zoom. */
  DOCS: [`mcfgTabGuide`, `mcfgTabGlossary`],

  _raf: 0,   /* handle del setTimeout de coalescencia */
  _obs: null,
  initialized: !1,

  /* ── Contenedores vivos en este momento ──────────────────────────────── */
  boxes() {
    const list = [];
    // La condicion es que el COCKPIT este a la vista, no la clase layout-pc:
    // en 1024x768 el cuerpo no lleva esa clase y las dos columnas se quedaban
    // sin ajustar (medido: +12 y +6 px con factor 1, o sea autofit ni corria).
    // Por debajo de 768 px el .cockpit es display:none y aqui no entra nada:
    // el pendant movil se scrollea con el dedo a proposito.
    const cockpit = $q(`.cockpit`);
    if (cockpit && getComputedStyle(cockpit).display !== `none`) {
      list.push($q(`.col-left`), $q(`.col-right`));
    }
    const cfg = $(`machineConfigModal`);
    if (cfg && cfg.classList.contains(`show`)) {
      list.push($q(`.mcfg-sidebar`, cfg));
      // El panel visible se elige por style.display (rotechos-config-modal.js
      // apaga todos los .mcfg-panel y enciende uno). Si es de lectura, fuera.
      const panel = Array.from(cfg.querySelectorAll(`.mcfg-panel`))
        .find((p) => p.style.display !== `none` && p.offsetParent !== null);
      if (panel && !this.DOCS.includes(panel.id)) list.push($q(`.mcfg-content`, cfg));
    }
    return list.filter(Boolean);
  },

  /* ── Lo que se esconde DENTRO ────────────────────────────────────────────
     Una tarjeta con scroll propio recorta su contenido y el contenedor ni se
     entera: `.col-left` decia caber mientras el #jogCard escondia 111 px con
     los botones de Z fuera de la vista, y el layout_gate cazaba los tres
     botones de velocidad de jog 15 px por debajo del viewport. Para el
     encargo eso es exactamente lo mismo que un scroll: contenido que hay que
     buscar. Asi que su desborde se suma al del contenedor. */
  oculto(box) {
    let extra = 0;
    box.querySelectorAll(`*`).forEach((el) => {
      const oy = getComputedStyle(el).overflowY;
      if (oy !== `auto` && oy !== `scroll`) return;
      const dif = el.scrollHeight - el.clientHeight;
      if (dif > this.TOL) extra += dif;
    });
    return extra;
  },

  /* ── Medida: cuanto cabe del contenido, a la escala actual ───────────── */
  ratio(box) {
    const natural = box.scrollHeight + this.oculto(box);
    if (natural <= 0) return 1;
    return (box.clientHeight - this.MARGIN) / natural;
  },

  /* ── Factor de crecimiento por viewport (t_709342b8, 2026-09-02) ──────
     El autofit nacio en pantallas de 1280x720..1920x1080 y solo MEDIA el
     contenido contra el cliente. En monitores grandes (2000x1100, 2560x1440)
     el contenido de las tarjetas se estira con el viewport, asi que el ratio
     se queda en 0.99 aunque la app se ve "mas pequena" en proporcion al
     monitor. Sergi quiere que aproveche la pantalla: en un 2000x1100 el
     contenido se infla un 4 % de ancho y un 2 % de alto sobre 1920x1080
     (2000/1920 y 1100/1080), asi que un factor ~1.03 aprovecha ese plus.
     El cap MAX (1.15) protege de pasarse en QHD/4K. Por debajo del tamano
     de referencia (1920x1080) devuelve 1: no compensa pantallas pequenas,
     deja que el suelo MIN_COCKPIT siga mandando.
     Se evalua contra window.innerWidth/innerHeight: la caja puede ser
     pequena (una columna del cockpit) pero el monitor es grande, y la
     razon de crecer es el monitor, no la caja. */
  viewportFactor() {
    const w = window.innerWidth, h = window.innerHeight;
    if (w <= 0 || h <= 0) return 1;
    const refW = 1920, refH = 1080;
    const fW = w / refW, fH = h / refH;
    const raw = Math.sqrt(fW * fH);
    return raw > 1 ? raw : 1;
  },

  /* ── Columnas laterales del cockpit (18-oct-2026) ────────────────────── */
  _esColumna(box) {
    return box.classList.contains(`col-left`) || box.classList.contains(`col-right`);
  },

  /* Solo con el cockpit a tres columnas (>1024 px). En tableta vertical la
     columna izquierda es una FILA con POSICION y JOG lado a lado: su ancho no
     dice nada del tamano de su contenido. */
  _factorColumna(box) {
    if (window.innerWidth <= 1024) return 1;
    const w = box.getBoundingClientRect().width;
    return w > 0 ? w / this.COL_REF_W : 1;
  },

  /* Alto del contenido sin el reparto del sobrante (los botones y el JOG
     crecen con flex y a 1:1 llenan siempre la columna, asi que scrollHeight no
     dice cuanto ocupan de verdad). Se mide con zoom 1. */
  _naturalMin(box) {
    box.dataset.fitMidiendo = `1`;
    try {
      const top = box.getBoundingClientRect().top;
      let fondo = top;
      for (const k of box.children) {
        if (k.offsetParent === null) continue;
        fondo = Math.max(fondo, k.getBoundingClientRect().bottom);
      }
      return fondo - top + (parseFloat(getComputedStyle(box).paddingBottom) || 0);
    } finally {
      delete box.dataset.fitMidiendo;
    }
  },

  /* Escala de la barra superior: va ANTES de ajustar las columnas porque su
     alto decide cuanto les queda. Se mide contra 1440x900, la pantalla para la
     que esta pensada, y crece por el lado que se agota antes. */
  _escalaBarra() {
    const raiz = document.documentElement;
    const cockpit = $q(`.cockpit`);
    const visible = cockpit && getComputedStyle(cockpit).display !== `none`;
    const f = Math.min(window.innerWidth / this.BARRA_REF.w, window.innerHeight / this.BARRA_REF.h);
    if (!visible || window.innerWidth < this.BARRA_REF.w || f <= 1.02) {
      raiz.style.removeProperty(`--ui-escala-barra`);
      return;
    }
    raiz.style.setProperty(`--ui-escala-barra`, String(Math.round(Math.min(this.MAX_BARRA, f) * 1000) / 1000));
  },

  /* Escala del centro: la menor de las dos columnas, para que ESTADO y la
     consola no se lean mas grandes que los botones de al lado. */
  _escalaCentro() {
    const raiz = document.documentElement;
    const zs = [$q(`.col-left`), $q(`.col-right`)]
      .map((c) => (c ? Number(c.dataset.fit) : NaN))
      .filter((n) => Number.isFinite(n));
    const z = zs.length === 2 && window.innerWidth >= this.BARRA_REF.w ? Math.min(...zs) : 1;
    if (z > 1.02) raiz.style.setProperty(`--ui-escala-centro`, String(Math.round(z * 1000) / 1000));
    else raiz.style.removeProperty(`--ui-escala-centro`);
  },

  /* Zoom propio de la pestana visible del modal (1 si no lo tiene o si el
     contenedor no es el panel de configuracion). */
  _zoomPestana(box) {
    if (!box.classList.contains(`mcfg-content`)) return 1;
    for (const k of box.children) {
      if (k.offsetParent === null) continue;
      const zk = parseFloat(getComputedStyle(k).zoom);
      if (Number.isFinite(zk) && zk > 0 && zk < 1) return zk;
    }
    return 1;
  },

  /* ── Ajuste de un contenedor ─────────────────────────────────────────── */
  fitOne(box) {
    // Suelo MODAL unico (MIN_MODAL=0.78) para mcfg-content y mcfg-sidebar: el
    // modal respeta el suelo tipografico del proyecto en cualquier viewport.
    // Antes tenia un suelo dinamico por ancho (<880 px -> 0.55); revertido por
    // el acabado de t_e5a08c8a: el gate daba verde a costa de encoger el texto.
    // El cockpit sigue con MIN_COCKPIT=0.78 independiente del ancho.
    const min = (box.classList.contains(`mcfg-content`) || box.classList.contains(`mcfg-sidebar`))
      ? this.MIN_MODAL
      : this.MIN_COCKPIT;

    // Siempre se mide a 1:1: un zoom heredado de la medida anterior falsearia
    // scrollHeight (esta en px logicos, no en px de pantalla).
    box.style.zoom = ``;
    delete box.dataset.fitLevel;
    // La marca de recortado cambia el relleno: se quita antes de medir.
    box.querySelectorAll(`.fit-recortado`).forEach((el) => el.classList.remove(`fit-recortado`));

    let level = 0;
    let z = this.ratio(box);

    // Paso 1: plegar prosa mientras no quepa y queden niveles.
    // Antes de subir un nivel se prueba el suelo de verdad: la cuenta a 1:1
    // no ve que al encoger el texto gana ancho logico y ocupa menos lineas.
    // Medido (26-oct-2026): MOTORES a 1024x768 daba 0,771 a nivel 2 (1 px de
    // mas a 0,78), saltaba a nivel 3 y acababa a 0,91 —letra mas grande y los
    // avisos cortados en una linea— cuando a 0,78 con nivel 2 ya cabia.
    // El suelo es de letra en pantalla: si la pestana ya trae zoom propio en
    // rotechos.css (VELOCIDADES a 0,84 entre 940 y 1080 px), la prueba se
    // hace al factor que deja su letra justo en el suelo, no por debajo.
    const zPestana = this._zoomPestana(box);
    const zPrueba = Math.min(1, min / zPestana);
    while (z < min && level < this.LEVELS) {
      box.style.zoom = String(Math.round(zPrueba * 1000) / 1000);
      const cabe = box.scrollHeight <= box.clientHeight + this.TOL;
      box.style.zoom = ``;
      if (cabe) { z = zPrueba; break; }
      box.dataset.fitLevel = String(++level);
      this._setFitLineHeight(box);
      z = this.ratio(box);
    }

    // Paso 2: escalar. Si el contenido cabe justo (z esta cerca de 1) y
    // el viewport es mas grande que 1920x1080, crecemos con el
    // viewportFactor: el contenido se infla visualmente y aprovecha la
    // pantalla. El guard "z<1.02 -> z=1" se mantiene para jitter. Si el
    // contenido pide mas de lo que hay (z<1), el viewportFactor no
    // interviene: el encogimiento va por la cuenta del ratio, no por
    // compensar el tamano del monitor.
    if (z > 1 && z < 1.02) z = 1;
    // Solo crece la columna mas ancha que su diseno; las demas siguen la regla
    // de siempre (a 1280x720 eso deja el PARO del mismo tamano que en main).
    const col = this._esColumna(box) && this._factorColumna(box) > 1.02;
    if (col) {
      // Cabe a 1:1 -> crece hasta su ancho de diseno; si no cabe, encoge.
      const cabe = box.scrollHeight <= box.clientHeight + this.TOL && this.oculto(box) <= this.TOL;
      if (cabe) {
        const reserva = box.classList.contains(`col-right`) ? this._reservaLibre() : 0;
        const zAlto = (box.clientHeight - this.MARGIN) / (this._naturalMin(box) + reserva);
        z = Math.max(1, Math.min(this._factorColumna(box), zAlto));
      }
    } else {
      const vf = this.viewportFactor(box);
      if (vf > 1 && z >= 0.99) z = z * vf;
    }
    z = Math.min(col ? this.MAX_COCKPIT : this.MAX, Math.max(min, z));

    // Escala 1 = no se toca el zoom (mejor no ensuciar el estilo inline), pero
    // NO se sale por aqui: antes se hacia y dejaba pasar los casos en que la
    // primera medida decia «cabe» por unos pocos px y el reflujo posterior la
    // desmentia (medido: MOTORES a 1100x800 con MODO ESCUELA, factor 1 y 7 px
    // de desborde). La comprobacion de abajo es la que manda.
    if (Math.abs(z - 1) < 0.005) {
      z = 1;
      box.style.zoom = ``;
    } else {
      box.style.zoom = String(Math.round(z * 1000) / 1000);
    }

    // Paso 3: correccion. Al cambiar la escala cambia el ancho logico y el
    // contenido se recoloca —en los paneles a dos columnas el reparto entre
    // ellas cambia entero—, asi que una sola pasada no siempre converge
    // (medido: VELOCIDADES se quedaba a 4 px con el factor aun por encima del
    // suelo). Tres pasadas bastan; cada una es una medida, no un repintado.
    // Ojo tambien al desborde HORIZONTAL, que nunca es aceptable: si crecer
    // lo provoca, se vuelve a escala 1.
    // Si tras corregir sigue sin caber y quedan niveles de plegado, se sube uno
    // mas y se vuelve a empezar. Sin esto habia un hueco: cuando el factor
    // aterrizaba JUSTO por encima del suelo (0,781 con min 0,78) el bucle de
    // niveles no subia, la correccion no podia bajar del suelo y el desborde se
    // quedaba ahi. Medido: VELOCIDADES a 1440x900 y 1600x900 en MODO ESCUELA se
    // pasaba 7 y 19 px con nivel 2, mientras a 1280x720 —mas apretada— cabia
    // porque ahi si llegaba al nivel 3.
    for (let i = 0; i < 3; i++) {
      // El desborde horizontal solo invalida el ajuste cuando se ha CRECIDO:
      // ahi lo ha provocado el zoom y hay que deshacerlo. Al encoger, en
      // cambio, un panel que ya era mas ancho que su hueco (los paneles a dos
      // columnas en pantallas estrechas) no tiene la culpa el zoom — y abortar
      // ahi dejaba el ajuste vertical a medias: medido, MOTORES a 1100x800 se
      // quedaba con factor 1 y 7 px de desborde porque este guard saltaba
      // antes de corregir.
      if (z > 1 && box.scrollWidth > box.clientWidth + this.TOL) {
        z = 1;
        box.style.zoom = ``;
        break;
      }
      if (box.scrollHeight <= box.clientHeight + this.TOL) break;
      const nuevo = Math.max(min, z * this.ratio(box));
      if (Math.abs(nuevo - z) < 0.002) break;   // ya no baja: suelo alcanzado
      z = nuevo;
      box.style.zoom = String(Math.round(z * 1000) / 1000);
    }
    // Ultimo recurso: sigue sin caber, el factor ya esta en el suelo y aun hay
    // niveles de plegado sin usar. Se sube uno y se rehace la medida entera.
    if (box.scrollHeight > box.clientHeight + this.TOL &&
        z <= min + 0.001 && level < this.LEVELS) {
      box.dataset.fitLevel = String(level + 1);
      this._setFitLineHeight(box);
      const previo = box.style.zoom;
      box.style.zoom = ``;
      const z2 = Math.min(this.MAX, Math.max(min, this.ratio(box)));
      box.style.zoom = Math.abs(z2 - 1) < 0.005 ? `` : String(Math.round(z2 * 1000) / 1000);
      if (box.scrollHeight > box.clientHeight + this.TOL) {
        // Ni con el nivel de mas: se deja el mejor de los dos y se acepta.
        box.style.zoom = previo;
      } else {
        z = z2;
      }
    }
    box.dataset.fit = String(Math.round(z * 1000) / 1000);
  },

  /* ── Inyecta la altura de línea real por elemento plegado (t_e5a08c8a) ───
     El CSS del plegado usa calc(N * var(--fit-lh)) para cortar por líneas
     exactas. --fit-lh se inyecta midiendo el line-height computado de cada
     caja plegable. Se hace a nivel de la caja plegable (.mcfg-info-box,
     .mcfg-warn-box, #mcfgPinWarning, .mcfg-panel > * sin controles) porque
     cada una puede llevar line-height distinto (medido: 1.65em la info-box
     de school-mode, 1.45em la speed-overview, 1.2em los mcfg-section-title).
     Sin la medida por elemento, una sola --fit-lh haría que una caja se
     quedara corta y otra se pasara. La medida se hace UNA sola vez por
     fitOne — line-height no cambia con el zoom (es proporcional al font-size
     y el zoom se aplica al box entero).
     La función es defensiva: si el getComputedStyle falla, no inyecta nada y
     el CSS usa su fallback (1.5em), que cabe siempre y nunca recorta a
     media línea. */
  _setFitLineHeight(box) {
    try {
      const sel = `.mcfg-info-box:not(.fit-abierto), .mcfg-warn-box:not(.fit-abierto), #mcfgPinWarning:not(.fit-abierto), .mcfg-row-icon [data-i18n="cfg.modal.subtitleHelp"]:not(.fit-abierto)`;
      const targets = box.querySelectorAll(sel);
      // Targets directos: solo los que están visibles y no abiertos.
      for (const el of targets) {
        this._setOneLineHeight(el);
      }
      // Hijos directos del panel sin controles (regla de nivel 2/3).
      const panel = box.classList.contains('mcfg-content') ? box : null;
      if (panel) {
        // Los hijos de cada .mcfg-panel, como el CSS (`.mcfg-panel>*`); con `:scope > *` se
        // median los paneles y la prosa cortaba a media linea (acta interfaz-acabado-3).
        const direct = panel.querySelectorAll(`:scope > .mcfg-panel > *`);
        for (const el of direct) {
          if (el.classList.contains('fit-abierto')) continue;
          // Solo si NO contiene controles (mismo predicado que el CSS).
          if (el.matches(`:has(input,select,button,textarea,canvas,table)`)) continue;
          // Solo si ya tiene max-height efectivo del plegado (es decir, está plegado).
          // El CSS aplica el max-height cuando data-fit-level está en el panel.
          if (panel.dataset.fitLevel === '2' || panel.dataset.fitLevel === '3') {
            this._setOneLineHeight(el);
          }
        }
      }
      // La cabecera del modal también se pliega (regla ~5259).
      const modal = document.getElementById('machineConfigModal');
      if (modal && modal.classList.contains('show')) {
        const cab = modal.querySelectorAll(`.mcfg-row-icon [data-i18n="cfg.modal.subtitleHelp"]:not(.fit-abierto)`);
        for (const el of cab) this._setOneLineHeight(el);
      }
    } catch (e) {
      if (window.LOG?.warn) LOG.warn(`autofit.setFitLineHeight: ${e.message}`);
    }
  },

  _setOneLineHeight(el) {
    try {
      const cs = getComputedStyle(el);
      let lh = parseFloat(cs.lineHeight);
      if (!isFinite(lh) || lh <= 0) {
        // line-height "normal" — cae al font-size multiplicado por 1.2 (mínimo WCAG).
        const fs = parseFloat(cs.fontSize) || 12;
        lh = fs * 1.2;
      }
      // Padding vertical: con box-sizing:border-box el max-height del
      // autofit lo INCLUYE, y la altura neta disponible para texto es
      // max-height - padTop - padBot. Si no tenemos esto en cuenta, una
      // caja con padding 12+12 (=24 px) y max-height 16.8 px (1 línea de
      // lh 16.8) deja la altura de texto en -7.2 px; el navegador la
      // reporta como 24 px (padding manda) y la regla NO recorta, pero
      // el detector de t_e5a08c8a lo lee como "media línea" porque
      // clientHeight ≠ múltiplo de lh. Compensamos inyectando también
      // el padding como variable CSS.
      let padTop = parseFloat(cs.paddingTop);
      let padBot = parseFloat(cs.paddingBottom);
      if (!isFinite(padTop)) padTop = 0;
      if (!isFinite(padBot)) padBot = 0;
      const padY = Math.round((padTop + padBot) * 100) / 100;
      el.style.setProperty('--fit-lh', `${Math.round(lh * 100) / 100}px`);
      // SIEMPRE, tambien cuando vale 0: `--fit-pad` SE HEREDA (es una custom
      // property), y una caja sin padding dentro de otra que si lo tiene
      // calculaba su recorte con un relleno inexistente y cortaba a media
      // linea. Inyectar el 0 corta la herencia. Medido el 22-sep en LED RGB.
      el.style.setProperty('--fit-pad', `${padY}px`);
    } catch (e) {
      // Si getComputedStyle lanza, no inyectamos nada: el CSS usa su fallback.
    }
  },

  /* Marca `.fit-recortado` solo donde el texto no cabe: la flecha y el corte a linea entera
     cuelgan de esa clase (rotechos.css, INTERFAZ-ACABADO-3; acta 2026-10-03_interfaz-acabado-3). */
  _marcarRecortes() {
    const cfg = $(`machineConfigModal`);
    if (!cfg || !cfg.classList.contains(`show`)) return;
    const sel = `.mcfg-info-box, .mcfg-warn-box, #mcfgPinWarning, .mcfg-row-icon [data-i18n="cfg.modal.subtitleHelp"], .mcfg-content[data-fit-level="2"] > .mcfg-panel > *, .mcfg-content[data-fit-level="3"] > .mcfg-panel > *`;
    for (const el of cfg.querySelectorAll(sel)) {
      if (el.classList.contains(`fit-recortado`)) {
        el.classList.remove(`fit-recortado`);
        this._setOneLineHeight(el);
      }
      if (el.classList.contains(`fit-abierto`) || el.clientHeight === 0) continue;
      const cs = getComputedStyle(el);
      if (cs.maxHeight === `none` || cs.overflowY !== `hidden`) continue;
      if (el.scrollHeight > el.clientHeight + 1) {
        el.classList.add(`fit-recortado`);
        el.style.setProperty(`--fit-pad`, `${parseFloat(cs.paddingTop) || 0}px`);
      }
    }
  },

  /* ── Ajuste sincrono de todo lo visible ──────────────────────────────────
     Lo usan los tests (que miden justo despues de cambiar de pestana, sin
     esperar al debounce) y refresh() cuando le toca. */
  apply() {
    // 16-sep (informe F): el observador se calla mientras escribimos. fitOne()
    // toca `style.zoom` y `class` de las MISMAS cajas que el observador vigila,
    // asi que cada pasada se disparaba a si misma. Medido en reposo TOTAL —sin
    // clics, sin resize, sin cambios de estado—: 78 apply() en 5 s, una cada
    // ~64 ms, para siempre, y cada una lee 12 veces la geometria. En una tablet
    // de taller encendida todo el dia eso es bateria y calor a cambio de nada.
    // Lo que viene de FUERA (contenido nuevo, resize, abrir el modal) sigue
    // disparando igual: solo se ignora el eco de nuestras propias escrituras.
    if (this._obs) this._obs.disconnect();
    try {
      this._escalaBarra();
      this.boxes().forEach((b) => this.fitOne(b));
      this._escalaCentro();
      this._marcarRecortes();
    } catch (e) {
      // Un fallo aqui no puede tumbar la interfaz: en el peor caso vuelve el
      // scroll de siempre.
      if (window.LOG?.warn) LOG.warn(`autofit: ${e.message}`);
    } finally {
      // Las cajas de los textos vivos se apuntan con el ajuste ya hecho: son
      // la referencia con la que _cajasIguales() decide si hace falta otro.
      this._apuntarCajas();
      // Re-suscribir SIEMPRE, tambien si fitOne lanzo: sin esto, un fallo
      // puntual dejaria el autofit sordo al contenido durante toda la sesion.
      if (this._obs) this._observeAll();
    }
  },

  /* ── API publica: recalcular todo (coalescido) ───────────────────────────
     Con setTimeout y NO con requestAnimationFrame a proposito: rAF no se
     ejecuta en una pestana en segundo plano, y ahi es justo donde se abre la
     interfaz muchas veces (la dejas cargando en otra pestana mientras preparas
     la maquina). Medido: con rAF el primer ajuste no llegaba a correr y la
     columna derecha aparecia con sus 275 px de desborde hasta que tocabas la
     ventana. Los 50 ms agrupan ademas la rafaga de mutaciones del arranque. */
  refresh() {
    this._todo = true;
    this._programar();
  },

  _programar() {
    if (this._raf) return;
    this._raf = setTimeout(() => {
      this._raf = 0;
      if (!this._todo && this._textos.size && this._cajasIguales()) {
        this._textos.clear();
        return;
      }
      this._todo = false;
      this.apply();
    }, 50);
  },

  /* ── Textos vivos: el DRO y las lecturas que cambian solas (8-oct-2026) ──
     Mientras un eje se mueve el DRO reescribe sus cifras 60 veces por
     segundo, y cada reescritura llegaba aqui como una mutacion del contenido
     de la columna. Medido moviendo los ejes 5 s en un portatil: 50 pasadas
     de ajuste completas, 274 layouts y 3 s de hilo principal ocupado; en una
     tablet de taller eso es un DRO que se arrastra.
     Un cambio que SOLO sustituye el texto de un elemento y deja su caja igual
     (ancho, alto, desborde propio y numero de lineas) no puede mover nada mas
     de la pagina, asi que el ajuste daria lo mismo. En ese caso se mide solo
     ese elemento y no se rehace el ajuste. Si la caja cambia, si el elemento
     es nuevo, o si en la misma tanda hay cualquier otra mutacion, se ajusta
     todo como siempre. */
  _textos: new Set(),
  _cajas: new Map(),
  _todo: false,

  _soloTexto(recs) {
    for (const r of recs) {
      if (r.type !== `childList` || r.target === document.body) return false;
      for (const lista of [r.addedNodes, r.removedNodes]) {
        for (const n of lista) {
          // Texto suelto, o un elemento sin hijos elemento (los decimales
          // atenuados del DRO: <span class="dro-dec">).
          if (n.nodeType !== 3 && !(n.nodeType === 1 && n.childElementCount === 0)) return false;
        }
      }
    }
    return true;
  },

  _caja(el) {
    return `${el.offsetWidth},${el.offsetHeight},${el.scrollWidth},${el.scrollHeight},${el.getClientRects().length}`;
  },

  _cajasIguales() {
    for (const el of this._textos) {
      if (!el.isConnected || this._cajas.get(el) !== this._caja(el)) return false;
    }
    return true;
  },

  _apuntarCajas() {
    for (const el of this._textos) this._cajas.set(el, ``);
    this._textos.clear();
    for (const el of this._cajas.keys()) {
      if (el.isConnected) this._cajas.set(el, this._caja(el));
      else this._cajas.delete(el);
    }
  },

  _alMutar(recs) {
    if (this._soloTexto(recs)) {
      for (const r of recs) this._textos.add(r.target);
    } else {
      this._todo = true;
    }
    this._programar();
  },

  /* Un clic sobre una explicacion recortada la abre entera (y la vuelve a
     cerrar). Delegado en el modal: los paneles se crean y se apagan por
     display, asi que enganchar listeners caja por caja se perderia la mitad. */
  _clics() {
    const cfg = $(`machineConfigModal`);
    if (!cfg) return;
    cfg.addEventListener(`click`, (e) => {
      if (e.target.closest(`details.mcfg-adv`)) return;
      // Cualquier bloque recortado: las cajas con nombre propio y los hijos de
      // panel que el nivel 2-3 recorta por ser prosa (ver rotechos.css).
      const caja = e.target.closest(`.mcfg-info-box, .mcfg-warn-box, #mcfgPinWarning, [data-i18n="cfg.modal.subtitleHelp"], [data-fit-level="2"] .mcfg-panel>*, [data-fit-level="3"] .mcfg-panel>*`);
      // Dentro de un contenedor con nivel de plegado, o en la cabecera del
      // modal (que va recortada de serie, sin depender del nivel).
      if (!caja || !(caja.closest(`[data-fit-level]`) || caja.closest(`.mcfg-row-icon`))) return;
      const abriendo = !caja.classList.contains(`fit-abierto`);
      // Solo una explicacion abierta a la vez. Sin esto, abrir tres seguidas
      // suma su alto y devuelve el scroll que este modulo existe para quitar;
      // asi el panel vuelve a su sitio en cuanto abres la siguiente.
      cfg.querySelectorAll(`.fit-abierto`).forEach((x) => x.classList.remove(`fit-abierto`));
      if (abriendo) caja.classList.add(`fit-abierto`);
    });
  },

  init() {
    if (this.initialized) return;
    this.initialized = !0;
    this._clics();
    this.refresh();
    window.addEventListener(`resize`, () => this.refresh());
    // .cockpit anima su `top` (0,3 s) y desde el 18-oct ese top depende de la
    // escala de la barra: el ajuste se hacia al principio de la animacion, con
    // la columna aun alta, y al acabar sobraban 3-8 px (gate sin-scroll a
    // 1920x1080 y 2560x1440). Se rehace cuando la animacion termina.
    $q(`.cockpit`)?.addEventListener(`transitionend`, (e) => {
      if (e.target === e.currentTarget && e.propertyName === `top`) this.refresh();
    });
    // El contenido cambia solo: aparece #progressCard al lanzar un trabajo,
    // se cambia de pestaña en el modal, o el operario enciende MODO ESCUELA y
    // salen las explicaciones.
    this._obs = new MutationObserver((recs) => this._alMutar(recs));
    this._watch = [$q(`.col-left`), $q(`.col-right`), $(`machineConfigModal`), document.body].filter(Boolean);
    this._observeAll();
  },

  /* Suscripcion del observador, aparte de init() porque apply() la corta y la
     repone en cada pasada (ver el comentario de apply). */
  _observeAll() {
    this._watch.forEach((n) => this._obs.observe(n, {
      childList: true,
      subtree: n === document.body ? false : true,
      attributes: true,
      attributeFilter: [`class`, `style`],
    }));
  },
};

(function initAutofit() {
  if (document.readyState === `loading`) {
    document.addEventListener(`DOMContentLoaded`, () => AUTOFIT.init(), { once: true });
  } else {
    AUTOFIT.init();
  }
})();

window.AUTOFIT = AUTOFIT;
