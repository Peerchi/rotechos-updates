/* ---
 * rotechos-confirm.js — Modal genérico de confirmación.
 *
 * Extraído del monolito (rotechos.js:2757-2827) en la primera ronda de
 * extracción de bloques DOM puros sin estado compartido (ranking
 * docs/dev/hallazgos/2026-08-11_kimi2_monolito_candidatos_extraccion.md
 * bloque 28, RANK 1, 71 líneas, riesgo 1).
 *
 * API pública
 *   confirmDialog(titleOrOpts, [msg], [opts]) → Promise<boolean>
 *     Tres formas aceptadas (HALLAZGO-1 2026-08-18):
 *       1. confirmDialog(title, msg)
 *              Forma histórica de 2 args. Botones siempre 'Confirmar'/
 *              'Cancelar'. Sigue soportada para no romper los ~12
 *              call-sites del monolito que ya la usaban (rotechos-jog,
 *              rotechos-fm, etc.).
 *       2. confirmDialog({title, body, confirmText, cancelText, danger})
 *              Forma objeto. La usan los 4 sitios PIN (rotechos-config-
 *              modal.js:1829,:1862 y rotechos-modules.js:356,:416) y la
 *              prefirieron los call-sites nuevos para no perder el
 *              contrato visual. `danger` se acepta pero el botón OK ya
 *              es `class=btn-danger` por defecto en index.html, así que
 *              es NO-OP visual (dejamos la pista en metadata por si
 *              alguien quiere diferenciar en el futuro).
 *       3. confirmDialog(title, msg, {confirmText, cancelText})
 *              Forma 3-arg. La usa rotechos-file-ops.js:87-93 para el
 *              lint al cargar — antes se IGNORABA el 3er arg
 *              (HALLAZGO-2 del mismo informe), ahora se aplica.
 *     title     : string — se pinta en #confirmTitle
 *     body/msg  : string HTML — se pinta en #confirmMsg (ya escapado por
 *                 el llamador; el modal no re-escapa para no romper el
 *                 contrato histórico que pinta HTML con var(--*) y
 *                 <strong>, etc.). Si el mensaje incluye datos del
 *                 operario, el llamador DEBE usar `escHtml(...)`.
 *
 *   Resuelve:
 *     true  → click en #btnConfirmOk o tecla Enter
 *     false → click en #btnConfirmCancel, tecla Escape, o guard de
 *             re-entrada cuando ya hay un modal abierto
 *
 * Dependencias (todas disponibles al ejecutarse este módulo):
 *   - $             : id-puro DOM helper (rotechos.js:57) — por eso este
 *                     módulo se carga ANTES de rotechos.js
 *   - LOG.warn      : emite el guard de re-entrada
 *   - navigator.vibrate : haptic en OK (stub: si no existe, no rompe)
 *   - document      : addEventListener / removeEventListener
 *
 * Contexto histórico (no borrar):
 *   - BUG-01 (Gemini UI review 2026-07-11): Escape cerraba visualmente
 *     el modal sin resolver la promesa → un Enter posterior disparaba
 *     la acción pendiente. Fix: el listener de keydown captura Escape
 *     y llama handleCancel/cleanup.
 *   - RE-ENTRADA: si ya hay un modal abierto, denegamos el nuevo
 *     inmediatamente con resolve(false) y un LOG.warn. Antes se
 *     apilaban listeners y un solo OK resolvía dos promesas → dos
 *     acciones de máquina con una pulsación.
 *   - FIX-A11Y-01 · D-01: foco guardado en `globalThis.__rotechosModalLastFocus`
 *     antes de mostrar el modal, devuelto en cleanup() si aún existe.
 *     El V01 global (rotechos.js) lo limpia cuando corre antes por
 *     Escape; el `if` evita pisar un foco legítimo.
 *
 * Carga: <script src="/js/rotechos-confirm.js" defer></script>
 *        posición: inmediatamente ANTES de rotechos.js, para que
 *        window.confirmDialog esté definido cuando rotechos.js y
 *        rotechos-file-ops.js lo busquen en DOMContentLoaded.
 * --- */
(function () {
  'use strict';
  /** Confirmacion de DASHBOARD: pregunta SIEMPRE (27-sep, ver dentro de la función).
   *
   *  HISTÓRICO — decisión de producto de Sergi (2026-08-29), revocada el 27-sep: en el panel, quien maneja la
   *  maquina a diario no quiere un dialogo por cada accion rutinaria; el modo
   *  escuela es el que existe para acompanar a quien esta aprendiendo, y ahi si
   *  se pregunta. Fuera de el, la accion se ejecuta directamente.
   *
   *  Se usa SOLO en acciones del cockpit. Todo lo que borra, sobrescribe o toca
   *  firmware —gestor de archivos, copias, configuracion, OTA, borrar macros—
   *  sigue con confirmDialog() y pregunta siempre, porque ahi lo que se pierde
   *  no se recupera moviendo un slider.
   *
   *  Para volver a armar UNA confirmacion concreta basta cambiar su llamada de
   *  confirmDashboard( a confirmDialog(. */
  function confirmDashboard(arg1, arg2, arg3) {
    // 27-sep, decisión de Sergi tras el análisis de la interfaz (D1): pregunta SIEMPRE, también
    // fuera del modo escuela. Con la regla del 29-ago se aceptaban solos avisos que solo salen
    // cuando algo va mal —sin cero de pieza («empezará en la esquina de la MÁQUINA»), sin
    // homing, quitar un trabajo en marcha— y encender el husillo arrancaba al primer clic sin
    // el aviso «que no haya nadie cerca de la fresa».
    return confirmDialog(arg1, arg2, arg3);
  }

  function confirmDialog(arg1, arg2, arg3) {
    return new Promise((resolve) => {
      // HALLAZGO-1/2 (2026-08-18): aceptar las 3 firmas.
      //   - objeto único: confirmDialog({title, body, confirmText, cancelText, danger})
      //   - 2 args:      confirmDialog(title, msg)                       (legacy)
      //   - 3 args:      confirmDialog(title, msg, {confirmText, cancelText})
      // Antes el módulo aceptaba solo (title, msg): si le pasabas un objeto,
      // title era `[object Object]` (textContent) y el body/buttons caían a
      // vacíos/'Confirmar' — exactamente lo que reportaban los 4 sitios PIN.
      let _title, _body, _opts;
      if (arg1 && typeof arg1 === `object` && !Array.isArray(arg1) &&
          (typeof arg1.title === `string` || typeof arg1.body === `string` ||
           typeof arg1.msg === `string`)) {
        _opts = arg1;
        _title = arg1.title;
        _body = arg1.body != null ? arg1.body : arg1.msg;
      } else {
        _title = arg1;
        _body = arg2;
        _opts = arg3;
      }
      const confirmText = (_opts && (_opts.confirmText || _opts.okText)) || `Confirmar`;
      const cancelText = (_opts && _opts.cancelText) || `Cancelar`;
      // RE-ENTRADA: si ya hay un confirm abierto, DENEGAR el nuevo (resolve false).
      // Antes se apilaban listeners sobre el mismo modal y un solo OK resolvía
      // las dos promesas a true → dos acciones de máquina con una pulsación.
      if ($(`confirmModal`).classList.contains(`show`)) {
        LOG.warn(`confirmDialog re-entrante denegado:`, _title);
        return resolve(false);
      }
      // FIX-A11Y-01 · D-01: guardar quién tenía el foco antes de mostrar el
      // modal, para devolvérselo al cerrar (clic en OK/Cancel o Escape). Mismo
      // patrón que rotechos-config-modal.js:1670 y rotechos-macros.js:297…
      globalThis.__rotechosModalLastFocus = document.activeElement;
      $(`confirmTitle`).textContent = _title;
      $(`confirmMsg`).innerHTML = _body;
      $(`confirmModal`).classList.add(`show`);
      const ok = $(`btnConfirmOk`),
        can = $(`btnConfirmCancel`);
      // HALLAZGO-1 (2026-08-18): aplicar los textos de los botones que el
      // caller pidió. Antes esto era estático 'Confirmar'/'Cancelar' (definido
      // en index.html), por eso el operario veía "Confirmar" en los 4 sitios
      // PIN cuando el contrato visual pedía "Activar PIN" / "Quitar PIN".
      // Restauramos los textos por-defecto del HTML en cleanup() para no
      // contaminar la siguiente invocación si el siguiente caller no pasa opts.
      const okDefault = ok.textContent;
      const canDefault = can.textContent;
      ok.textContent = confirmText;
      can.textContent = cancelText;
      function cleanup() {
        (($(`confirmModal`).classList.remove(`show`),
          ok.removeEventListener(`click`, handleOk),
          can.removeEventListener(`click`, handleCancel),
          $(`confirmModal`).removeEventListener(`rotechos:backdrop-cierre`, handleCancel),
          document.removeEventListener(`keydown`, handleKey)),
          // HALLAZGO-1 (2026-08-18): devolver el botón a su texto por-defecto
          // del HTML para que el siguiente confirmDialog sin opts arranque
          // con 'Confirmar'/'Cancelar' y NO con el texto del caller previo.
          // Si el caller también había dejado otro foco, el restore que viene
          // abajo del original ya estaba antes — lo conservamos.
          ok.textContent = okDefault,
          can.textContent = canDefault,
          // FIX-A11Y-01 · D-01: devolver foco al botón que abrió el modal si
          // cleanup() corre por click OK/Cancel. Si corre por Escape, el V01
          // global (rotechos.js:2373-2375) ya hizo focus() y limpió el global;
          // el `if` evita pisar un foco legítimo que el V01 acaba de mover.
          globalThis.__rotechosModalLastFocus &&
          (globalThis.__rotechosModalLastFocus.focus(),
            (globalThis.__rotechosModalLastFocus = null)));
      }
      function handleOk() {
        if (navigator.vibrate) navigator.vibrate(20);
        (cleanup(), resolve(!0));
      }
      function handleCancel() {
        (cleanup(), resolve(!1));
      }
      function handleKey(e) {
        if (e.key === `Enter`) {
          e.preventDefault();
          handleOk();
          return;
        }
        // BUG-01 (Gemini UI review): si Escape cierra visualmente el modal pero
        // no llamamos a handleCancel, la promesa queda hanging → el await del
        // caller queda esperando para siempre. El operario cree haber cancelado
        // pero la próxima resolución (OK/true) ejecuta la acción pendiente.
        //
        // Por qué funciona este fix (mecanismo verificado por Claude 2026-07-11):
        // tres listeners ven este Escape. (1) El global V01 (document, registrado
        // en carga) corre PRIMERO: quita .show del modal superior y hace
        // stopPropagation. (2) ESTE listener (document, registrado al abrir el
        // confirm, es decir DESPUÉS) corre en segundo lugar — stopPropagation NO
        // frena listeners del mismo nodo, solo targets posteriores — y resuelve
        // la promesa a false vía handleCancel/cleanup. (3) KBSHORTCUTS (window,
        // Escape→M112) NUNCA corre: el stopPropagation de V01 corta la fase
        // document→window. El stopPropagation de aquí es defensa en profundidad
        // para el caso en que V01 no corra (foco en input). El cleanup elimina
        // los 3 listeners: un Enter posterior NO dispara la acción antigua.
        if (e.key === `Escape`) {
          e.preventDefault();
          e.stopPropagation();
          handleCancel();
        }
      }
      // 29-sep: cerrar pinchando en el fondo = Cancelar. Antes el fondo solo quitaba la
      // clase show: la promesa quedaba pendiente con los listeners vivos y un Enter posterior
      // la resolvia a true (se ejecutaba la accion que el operario creyo descartada).
      (ok.addEventListener(`click`, handleOk),
        can.addEventListener(`click`, handleCancel),
        $(`confirmModal`).addEventListener(`rotechos:backdrop-cierre`, handleCancel),
        document.addEventListener(`keydown`, handleKey));
    });
  }
  // Exponer al scope global: el monolito y los módulos diferidos
  // (rotechos-file-ops.js, rotechos-wcs.js, rotechos-modules.js) lo
  // llaman como `confirmDialog(...)` sin prefijo, y los tests lo
  // localizan por firma top-level `function confirmDialog(...)`. El
  // nombre de los argumentos (title/msg) sigue siendo válido porque la
  // firma lógica interna mantiene arg1/arg2/arg3 pero la función
  // declarada es la misma.
  window.confirmDialog = confirmDialog;
  window.confirmDashboard = confirmDashboard;
})();
