// Fragmento i18n — STRINGS DINÁMICOS DE JS (toasts, diálogos, logs, estados). (Agente C)
// Claves EN de los textos que el JS genera en runtime y que envuelvas con
// t("clave","texto ES por defecto"). Formato: "clave": "English text".
// Clave sugerida con prefijo msg./dlg./state.
window.I18N && window.I18N.add({
  // ── Estado de la máquina ──────────────────────────────────────────────────
  "state.ready":   "READY",
  "state.running": "RUNNING",
  "state.paused":  "PAUSED",
  "state.error":   "ERROR",
  "state.idle":    "IDLE",
  // A — SEÑAL DE ESPERA (t_d9f3c73d): estado transitorio del badge cuando
  // el primer rr_model del ciclo sigue colgado > 350 ms. El fallback en
  // castellano es "ESPERANDO RESPUESTA" (rotechos-poll.js:_paintAwaiting,
  // rotechos-jog.js:_STATE_ES.AWAITING).
  "state.awaiting": "WAITING RESPONSE",

  // ── Etiquetas dinámicas de botón ───────────────────────────────────────────
  "btn.startJob":   "START JOB",
  "btn.pause":      "PAUSE",
  "btn.resume":     "RESUME",
  "btn.spindleOn":  "TURN SPINDLE ON",
  "btn.spindleOff": "TURN SPINDLE OFF",
  // Texto del play/pause mientras dura la simulación M37
  // (rotechos.js:943, fallback "SIMULANDO…").
  "btn.simulating": "SIMULATING…",
  // Botón "RECARGAR" del banner de service worker actualizado
  // (rotechos.js:340, fallback "RECARGAR").
  "btn.reloadNow":  "RELOAD",
  // Botón cerrar del modal OTA (rotechos-ota.js:177, fallback "Cerrar").
  "btn.close":      "Close",
  // Estado del badge del pendant cuando no hay conexión
  // (rotechos.js:802, fallback "DESCONECTADO").
  "state.disconnected": "DISCONNECTED",

  // ── Toasts de conexión / sesión ───────────────────────────────────────────
  "msg.connRestored":  "Connection restored",
  // HUECO-4: microcorte recuperado sin llegar a DESCONECTADO.
  "msg.connRestoredMicro": "Reconnected",
  "msg.connLost":      "Lost UI connection — the CNC keeps running the job on its own; do not power off the machine. Wait a few seconds: the UI will reconnect. If it doesn't, reload the page (F5).",
  "msg.connFailed":    "Could not connect",
  "msg.reconnected":   "Reconnected — reloading…",
  "msg.reconAlreadyInProgress": "Reconnection already in progress — please wait",
  // Reboot overlay — post-M999 (rotechos.js:1009-1012) y post-aplicar-motores
  // (rotechos-config-modal.js:2940-2942). Antes hardcoded ES.
  "msg.rebootReconnected":      "RECONNECTED",
  "msg.rebootReloadingInterface":"Reloading interface…",
  "msg.rebootRestarting":       "RESTARTING",
  "msg.rebootApplyingMotors":   "Applying motor configuration…",
  "msg.readOnly":      "Read-only mode active",
  "msg.controlTaken":  "Control taken — this tab is now active",
  "msg.cmdTimeout":    "Command timed out — UI unblocked",
  "msg.newUpdateReload": "New update available. Please reload the page.",

  // ── Toasts de trabajo / archivo ───────────────────────────────────────────
  "msg.jobDone":        "Job completed",
  "msg.jobCancelled":   "Job cancelled (ESC)",
  "msg.jobStartErr":    "Error starting job",
  "msg.fileNoActive":   "Cannot load a file while the machine is working",
  "msg.sacSensorYOff":  "Sensor Y position is outside the configured travel area. Check Settings → Soft Limits or correct the sensor position.",
  // ── G3: lint al cargar (aviso, no bloquea) ──
  "dlg.busyCmd.title":      "Machine busy",
  "dlg.busyCmd.msg":        "this command moves axes or the spindle, or runs a macro. Send anyway?",
  "dlg.lintLoad.title":     "File does not look generated for RotechOS",
  "dlg.lintLoad.has":       "has",
  "dlg.lintLoad.problems":  "problem(s) RRF will reject",
  "dlg.lintLoad.andMore":   "and",
  "dlg.lintLoad.more":      "more",
  "dlg.lintLoad.help":      "<b>How to fix it:</b> regenerate the file with the RotechOS postprocessor (supplied separately with the machine) — most of these errors disappear. If you cannot, open the file in SETTINGS → Macros or in a text editor, fix the marked lines and re-upload. Cancel here means the file will NOT be loaded; Load anyway uploads it but RRF may reject it when sending commands.",
  "dlg.lintLoad.loadAnyway":"Load anyway?",
  "dlg.lintLoad.yes":       "Load anyway",
  "dlg.lintLoad.no":        "Cancel",
  // ── Notificaciones del navegador (HALLAZGO-25, ARREGLO 2026-08-23) ───────
  // sendNotif(title, body, icon, titleKey) usa titleKey para traducir el
  // TÍTULO. El body sigue delegado al caller (Halt: ${_haltReason} y Final
  // de carrera ${ax} son dinámicos, no se puede prefijar con una clave
  // genérica). Ver tests/unit/notif.test.js para la firma y los call-sites.
  "notif.jobComplete":     "Job completed",
  "notif.jobError":        "Job error",
  "notif.halt":            "Halt",
  "notif.softLimit":       "Soft Limit reached",
  "notif.endstop":         "Endstop triggered",
  "msg.lintLoadWarnings":   "file loaded with lint warnings — check the CONSOLE tab (bottom panel of the cockpit) for the details",
  "msg.firmwareErrors": "Firmware started with errors — check console",
  // Paquete de diagnostico exportable (2026-08-31). Son msg.* y por tanto
  // clave de seguridad para el gate de i18n: sin EN, un operario anglofono
  // ve texto en espanol justo cuando algo le esta fallando.
  "msg.diagBuilding":  "Building diagnostic package…",
  "msg.diagReady":     "Diagnostic package ready",
  "msg.diagErr":       "Could not build the diagnostic package",
  "button.exportar-diagnostico": "EXPORT DIAGNOSTICS",
  "msg.estopActivated": "✕ EMERGENCY STOP ACTIVATED",

  // ── Toasts de parada / recuperación ──────────────────────────────────────
  "msg.softStopDone":   "Clean stop executed",
  "msg.m25EnMacro":     "Cannot pause now: a macro is running (e.g. tool change). Wait or use STOP.",
  "dlg.softStop.title": "Abort job",
  "dlg.softStop.msg":   "The job is cancelled: the machine stops, Z goes up and the spindle turns off. The file stays on the SD. For a short stop, use PAUSE; in an emergency, STOP.",
  "dlg.softStop.cancel": "Cancel",
  "msg.softStopErr":    "Error executing stop",
  "msg.sensorsRearmed": "Safety sensors re-armed (no M999)",
  "msg.sensorsErr":     "Error re-arming sensors",
  "msg.softLimit":      "Soft Limit — Job paused",
  "msg.macroRunning":     "A macro is already running",
  "msg.macroDeleted":     "Macro",
  "msg.macroDeletedSfx":  "deleted",
  "msg.macroErrPfx":      "Error in",

  // ── Toasts de movimiento / jog ────────────────────────────────────────────
  "msg.jogBlocked":     "Jog blocked — a macro or command is running; wait for it to finish (the RUNNING pilot on the top bar will go off)",
  "msg.jogBlockedJob":  "Jog blocked during job",
  // B — DOBLE JOG (t_d9f3c73d): toast info cuando el segundo doJogStep cae
  // en el guard _jogBusy. Cooldown 350 ms (rotechos-jog.js:_JOG_REJECT_COOLDOWN_MS).
  // El texto ES (fallback) es "Jog en curso: la segunda pulsación se ha
  // ignorado (espera a que termine)" — ver
  // docs/dev/propuestas/2026-08-13_propuesta-rechazo-doble-jog.md.
  "msg.jogAlreadyRunning": "Jog in progress: second press ignored (wait for it to finish)",
  // Huérfanas detectadas el 27-jul-2026: rotechos-jog.js las pasaba a t() pero
  // no existían en ningún diccionario, así que en EN salía el fallback en ES.
  // t() NO interpola: guarda solo la parte estatica y el eje/valor se
  // concatenan en el call site (mismo patron que msg.zLimitWarn).
  "msg.jogBloqueadoMáquinaEn":  "JOG blocked — machine running",
  "msg.jogBloqueadoTrabajoEn":  "JOG blocked — job paused",
  "msg.jogFreeZBlocked":        "In FREE mode, Z only moves in preset steps",
  "msg.jogLibreFirstTime":      "FREE mode: the machine moves while you hold the button",
  "msg.jogRefFirst":            "Home the machine (HOME) before using FREE mode",
  "msg.límiteSoftwareAxisMax":  "Software limit",
  "msg.límiteSoftwareAxisMin":  "Software limit",
  "msg.errorAlMoverAxis":       "Error moving",
  "msg.noSePuedeModificar":     "Cannot change the spindle while running",
  "msg.zLimitWarn":     "mm for safety — to go lower go to SETTINGS → Motors and uncheck the cap, or mount the part closer to Z0",
  "msg.endstopBlock":   "✕ Action blocked: endstop active",
  "msg.noHomed":        "Machine doesn't know where it is yet: press the HOME button on the top bar (or HOME ALL under COCKPIT). Until you home it, the controller refuses to move to a coordinate for safety.",
  "msg.noHomedEstop":   "You pressed the red emergency stop button — before starting another job you must HOME all 3 axes again (HOME on the top bar, or COCKPIT menu). If you try to cut without homing, the workpiece will come out offset.",
  "msg.notReady":       "Action blocked: machine is not in READY state (it doesn't accept commands/cuts). Wait for the current job to finish, or press STOP on the top bar. If the machine has been idle for several minutes and is still PAUSED, press RESUME.",
  "msg.noWcsDuring":    "Cannot change WCS during a job",
  "msg.wcsErrSet":      "Error setting offset",
  "msg.jogLimitXmax":   "Movement blocked: X Max endstop active — press the −X button (move left) to back off the limit",
  "msg.jogLimitYmin":   "Movement blocked: Y Min endstop active — press the +Y button (move back) to back off the limit",
  "msg.jogLimitYmax":   "Movement blocked: Y Max endstop active — press the −Y button (move forward) to back off the limit",
  "msg.jogLimitZmin":   "Movement blocked: Z Min endstop active — press the +Z button (raise) to back off the limit",
  "msg.jogLimitZmax":   "Movement blocked: Z Max endstop active — press the −Z button (lower) to back off the limit",

  // ── Toasts de WCS / Zero ─────────────────────────────────────────────────
  "msg.zeroX":   "X zero set",
  "msg.zeroY":   "Y zero set",
  "msg.zeroZ":   "Z zero set",
  "msg.zeroAll": "XYZ zero set",

  // ── Toasts de spindle ─────────────────────────────────────────────────────
  "msg.spindleOff": "Spindle OFF",

  // ── Toasts de bordeador ───────────────────────────────────────────────────
  "msg.bordBlockedHoming": "Edge finder aborted: run HOME before continuing",
  "msg.bordEndstopX":      "Edge finder aborted: X endstop triggered",
  "msg.bordEndstopY":      "Edge finder aborted: Y endstop triggered",
  "msg.bordStarted":   "Perimeter check started…",
  "msg.bordPaused":    "Perimeter check paused",
  "msg.bordResumed":   "Perimeter check resumed",
  "msg.bordCancelled": "Perimeter check cancelled",
  "msg.bordTimeout":   "Perimeter check auto-cancelled after 5 min pause",
  "msg.bordCommErr":   "Perimeter check: firmware communication error",
  "msg.bordOnlyReady": "Perimeter check only available in READY state",
  "msg.bordNoPath":    "No toolpath loaded",
  "msg.cfgBloqueadoTrabajo": "With a job running or paused, the configuration is not saved.",
  "msg.restoreBloqueadoTrabajo": "With a job running or paused, a backup is not restored.",
  "msg.controlRecuperado": "The other tab was closed — this one takes control.",
  // HALLAZGO-5 (informe 2026-08-17): toast diferenciado cuando el watchdog de UI
  // pausó el trabajo (vs. pausa manual del operario). El texto debe dejar claro
  // que la pausa fue automática, no del operario, y qué hacer (comprobar WiFi,
  // RESUME manual). EN corto y directo.
  "msg.watchdogPause": "Job paused because UI connection was lost. Check WiFi and press RESUME when you regain control.",

  // ── Toasts de comandos / consola ─────────────────────────────────────────
  "msg.cmdErr":        "Error sending command",
  "msg.cmdFirmwareErr": "Firmware rejected the command",
  "msg.cmdHttpErr":    "Firmware returned an HTTP error",
  "msg.cmdNetworkErr": "Could not reach the firmware",

  // ── HUECO-2 / HUECO-3 (t_e558a603): que operacion fallo y que esta tardando.
  // El operario veia «error» sin saber si fallo el guardado, la subida o el
  // palpado; y una operacion lenta no daba ninguna senal. Ver
  // rotechos-op-feedback.js y docs/dev/hallazgos/2026-09-06_C-robustez-percibida.md
  "msg.opFalloPrefijo":   "Could not",
  "msg.opFalloSinCausa":  "no cause recorded; retry and check the connection to the machine",
  "msg.opCausaHttp":      "the firmware replied HTTP ${status}",
  "msg.opCausaFirmware":  "the firmware rejected it: ${errMsg}",
  "msg.opCausaTimeout":   "the firmware did not confirm in time — it may still have run",
  "msg.opCausaRed":       "could not reach the machine (${error}) — check the WiFi",
  "msg.opCausaEscudo":    "the security shield blocked it",
  "msg.opLentaSufijo":    "is taking a while — still in progress, do not repeat the order",
  "msg.opGuardarConfig":  "save the configuration",
  "msg.opSubirArchivo":   "upload the file",
  "msg.opPalparZ":        "probe Z",
  "msg.fullscreenErr": "Browser did not allow fullscreen",
  "msg.feedReset":     "Feed Rate → 100%",
  "msg.spindleReset":  "Spindle Speed → 100%",

  // ── Toasts de backup / restaurar ─────────────────────────────────────────
  "msg.restoreOk":    "Backup restored. Restarting…",
  "msg.restoreErr":   "Error restoring backup — the SD may be partial; check the WiFi connection to the CNC and retry the restore from SETTINGS → Backup",
  "msg.restoreRollbackOk": "Reverted to previous state: ${files}.",  // A3-02: post-failure rollback report
  "msg.restoreRollbackFail": "Could not restore: ${files}. The SD may still be partial — check the WiFi connection to the CNC and retry the restore from SETTINGS → Backup.",
  "msg.invalidZip":   "Select a valid .zip file",
  "msg.uploadActive": "Cannot upload files with an active job",
  "msg.noTabFiles":   "Load the tab first to scan files",
  "msg.fileListErr":  "Error reading file list",
  "msg.backupErr":    "Error generating backup: ",

  // ── Toasts de firmware / reset ────────────────────────────────────────────
  "msg.resetting":   "Restarting firmware…",
  "msg.resetOk":     "✓ Machine restarted → IDLE",
  "msg.resetFailed": "Could not reconnect after reset",

  // ── Toasts de archivos (file manager) ────────────────────────────────────
  "msg.fileDeleteErr":   "Error deleting",
  "msg.fileDeletedSfx":  "deleted",

  // ── Toasts de quick-actions ───────────────────────────────────────────────
  "msg.homingStarted": "Homing started…",
  "msg.homingErr":     "Error: G28",
  "msg.recoverDuringHoming": "Homing in progress: wait for it to finish before recovering sensors",
  "msg.probeStarted":  "Probe Z started…",
  "msg.probeErr":      "Error: sonda_Z.g",
  "msg.m6Sent":        "M6 sent…",
  "msg.m6Err":         "Error: M6",
  "msg.goto0":         "Going to 0…",
  "msg.goto0Err":      "Error: goto0.g",
  "msg.parking":       "Parking…",
  "msg.parkErr":       "Error: park.g",

  // ── Toasts de probe XY ───────────────────────────────────────────────────
  "msg.probeAutoOn":  "Auto probing activated",
  "msg.probeAutoOff": "Auto probing deactivated",
  "msg.probeAutoOk":  "Auto probing started…",
  "msg.probeAutoErr": "Error launching probe_xy_auto.g",

  // ── Toasts de config ──────────────────────────────────────────────────────
  "msg.restoreActiveBusy": "Cannot restore with an active job",

  // ── Wizard ────────────────────────────────────────────────────────────────
  "msg.wizardDone":    "Initial setup completed ✓",
  "msg.wizCalcAxis":   "Select an axis first",
  "msg.wizInvalidDist":"Invalid distance",
  "msg.wizNoMeasure":  "Missing requested or measured distance",
  "msg.wizNoSteps":    "Could not read current steps/mm",
  "msg.wizMovedPfx":   "Moved",
  "msg.wizMovedSfx":   "now measure it",

  // ── Job history ───────────────────────────────────────────────────────────
  "msg.histCleared":  "History cleared",
  "msg.histCounters": "Counters reset",

  // ── Diálogos — títulos ────────────────────────────────────────────────────
  "dlg.multiTab.title":       "Another session active",
  "dlg.homeAll.title":        "Home All",
  "dlg.probeZ.title":         "Probe Z",
  "dlg.toolChange.title":     "Tool change",
  "dlg.park.title":           "Park",
  "dlg.recoverSensors.title": "Recover sensors",
  "dlg.spindleOn.title":      "Turn Spindle On",
  "dlg.spindleOn.pre":        "Spindle will start at",
  "dlg.spindleOn.warn":       "Make sure no one is near the cutter.",
  "dlg.macroRun.title":       "Run macro",
  "dlg.macroRun.pre":         "Macro",
  "dlg.macroRun.moves":       "moves the machine.",
  "dlg.macroRun.clear":       "Verify the area is clear.",
  "dlg.macroRun.will":        "Will move the machine",
  "dlg.macroRun.cont":        "Continue?",
  // Fase 3.3 §8 (t_1b74ed31): el operario debe saber que el .g es el contrato,
  // no el nombre. Le decimos dónde leerlo (SETTINGS → Macros) sin abrir otra pestaña.
  "dlg.macroRun.reviewHint":  "What the macro does is the contents of the .g on the SD; review it under SETTINGS → Macros before continuing if this is the first time you run it.",
  // Fase 4.12 (t_88c6a0dd): risk badge + ficha de la macro antes de ejecutar.
  "macro.risk.alto":            "HIGH",
  "macro.risk.medio":           "MEDIUM",
  "macro.risk.bajo":            "LOW",
  "macro.risk.title":           "Estimated risk when running",
  "macro.ficha.path":           "Path",
  "macro.ficha.size":           "Size",
  "macro.ficha.lines":          "lines",
  "macro.ficha.lastEdit":       "Last edited",
  "macro.ficha.lastEditUnk":    "unknown",
  "macro.ficha.noFetch":        "Could not read the file",
  "macro.ficha.noEffects":      "No effects detected",
  "macro.tag.motion":           "Moves machine",
  "macro.tag.home":             "Homing",
  "macro.tag.wcs":              "Changes WCS",
  "macro.tag.spindle":          "Spindle",
  "macro.tag.coolant":          "Coolant",
  "macro.tag.tool":             "Tool change",
  "macro.tag.probe":            "Probe",
  "macro.tag.unknown":          "Non-UI commands",
  "dlg.macroDelete.title":    "Delete macro",
  "dlg.macroDelete.q":        "Delete",
  "dlg.macroSave.title":      "Save macro to SD",
  "dlg.macroSave.will":       "You are about to overwrite",
  "dlg.macroSave.warn":       "on the SD. The machine executes this file: review the code before continuing.",
  "dlg.macroPendant.title":       "Run macro",
  "dlg.fileDelete.title":     "Delete file",
  "dlg.fileDelete.pre":       "Delete",
  "dlg.fileDelete.warn":      "This action cannot be undone.",
  // M-M01 (2026-08-14): confirm condicional al reset de feed/spindle override.
  // Solo se muestra cuando el slider != 100; si ya está en 100, reset directo.
  // {pct} se sustituye en runtime por el valor numérico actual del slider.
  "dlg.overrideReset.title":  "Reset override to 100%?",
  "dlg.overrideReset.body":   "Your current <strong>{pct}%</strong> adjustment will be lost.",
  // ── ARIA-LABEL de modales (accesibilidad) ───────────────────────────────
  // Cubre los 12 modales no críticos (no probe, no welcome, no PIN).
  // Los 3 críticos (probeEditor, probe3d, welcome) se mantienen en ES y se
  // señalan como pendientes decisión Sergi en docs/dev/hallazgos.
  "dlg.aria.macros":          "Macros",
  "dlg.aria.files":           "Files",
  "dlg.aria.fileEditor":     "File editor",
  "dlg.aria.machineConfig":  "Machine configuration",
  "dlg.aria.parkEditor":     "Park — Editor",
  "dlg.aria.macro":          "Edit macro",
  "dlg.aria.license":        "GNU General Public License v3",
  "dlg.aria.newMacro":       "Create macro",
  "dlg.aria.jobSummary":     "Job completed",
  "dlg.aria.zcal":           "Calibrate Z sensor (martyr)",
  "dlg.aria.probeEditor":    "Z probe — Probing settings",
  "dlg.aria.probe3dConfig":  "3D Probe — Configuration",
  "dlg.aria.welcome":        "Welcome to RotechOS",
  // SM-1 (jul-2026): la entrada a modo LIBRE exige confirmación obligatoria.
  // Se dispara al tocar la pill activa. Si cancelas, vuelves a paso 1.
  "dlg.jogLibre.title":      "Switch to FREE mode",
  // 4.5 (t_cf7736bc): el aviso nombra Z. En LIBRE X/Y se mueven mientras
  // mantienes la flecha; Z sigue haciéndolo por pasos (regla A de
  // rotechos-jog.js mpgJog:897). Sin esta línea, el operario espera
  // comportamiento continuo en Z y la primera pulsación larga da un único
  // paso y para — sorpresa justamente en el eje donde cuesta cara.
  "dlg.jogLibre.body1":      "In FREE mode X and Y move WHILE you hold the arrow — an accidental touch can travel several centimetres. Z still moves in preset steps only (the step you selected before entering FREE).",
  "dlg.jogLibre.body2":      "Do you confirm switching to FREE mode?",
  "dlg.restoreBackup.title":  "Restore backup?",
  "dlg.restoreBackup.titleOtherMachine": "Restore a backup from ANOTHER machine?",
  "dlg.restoreBackup.titleNoIdentity":   "Restore a backup of UNKNOWN origin?",
  "dlg.restoreBackup.date":              "Backup date",
  // Identidad de máquina (config-machine.g: set global.machineName)
  "msg.machineNameOk":     "Machine name saved",
  "msg.machineNameVacio":  "The machine name cannot be empty",
  // t_58518f6d FASE 4.19: identidad estable para soporte tecnico
  "msg.soporteCopied":     "Support block copied to clipboard",
  "msg.soporteNoHelper":   "Could not generate the support block",
  "msg.soporteCopiaManual": "Copy this block by hand",
  "cfg.modal.machineLbl":  "Machine",
  "cfg.about.identity":    "Machine identity",
  "cfg.about.identityLbl": "Name of this machine",
  "cfg.about.identitySave": "Save name",
  "cfg.about.identityHint":
    "Identifies the machine in the interface and is recorded in backups to warn you if you restore a backup from another machine. Stored in config-machine.g and applied with M550.",
  // Placeholder del nombre por defecto de la máquina (campo identidad, NO PIN).
  // El PIN (cfg.pin.*) se queda intacto por seguridad.
  "cfg.about.identityPh":   "My CNC",
  "dlg.restoreFactory.title": "Restore factory configuration",
  "dlg.bordeador.title":      "Perimeter Check — Check Clamps",
  "dlg.bordeador.pre":        "The head will trace the design perimeter",
  "dlg.bordeador.raised":     "with the cutter raised to",
  "dlg.bordeador.then":       "to position, then at",
  "dlg.bordeador.during":     "during the run",
  "dlg.bordeador.zone":       "Area",
  "dlg.bordeador.clear":      "Make sure the area is clear.",
  "dlg.startJob.title":       "Start machining",
  "dlg.startJob.file":        "File",
  "dlg.startJob.posWcs":      "Position in ${wcs}",
  "dlg.startJob.check":       "Verify the cutter is above the workpiece.",
  "dlg.loadCancel.title":     "Job in progress",
  "dlg.loadCancel.pre":       "There is an active job",
  "dlg.loadCancel.q":         "Cancel current job and load",
  "dlg.noHomed.title":        "MACHINE NOT HOMED",
  "dlg.checklist.title":      "Pre-machining checklist",
  "dlg.wcsZeroAll.title":     "Set XYZ origin",
  "dlg.wcsZeroX.title":       "Set X origin",
  "dlg.wcsZeroY.title":       "Set Y origin",
  "dlg.wcsZeroZ.title":       "Set Z origin",
  "dlg.dangerCmd.title":      "Dangerous command",
  "dlg.motorsReboot.title":   "Reboot required",
  "dlg.histClear.title":      "Clear history",
  "dlg.histReset.title":      "Reset counters",
  "dlg.probeAutoXY.title":    "Auto XY probing",

  // ── Diálogos — mensajes (sin HTML dinámico; los que tienen partes variables
  //    se construyen en el JS con concatenación y no se traducen aquí) ───────
  "dlg.multiTab.msg":
    "<p>Another RotechOS tab is active and controlling the machine.</p>" +
    '<p style="color:var(--yellow);margin-top:8px">This tab is in <strong>read-only mode</strong> — movement controls are locked.</p>' +
    '<p style="color:var(--text-3);margin-top:6px;font-size:11px">Close the other tab or confirm to take control.</p>',
  "dlg.homeAll.msg":    "Home all axes? Each axis will travel to its limit switch.",
  "dlg.probeZ.msg":     "PROBE Z: the machine will go to the fixed button (at X max), touch it and set Z=0 at the table plus the material thickness set in SETTINGS → PROBE Z. Before: clear path to the button, tool mounted, hands away. If the thickness is not your material's, zero will be wrong. The macro sonda_Z.g will run. Continue?",
  "dlg.wizS10.title":   "Probe Z (step 10)",
  "dlg.wizS10.msg":     "The machine will lower the probe until it touches your workpiece. Before continuing, clear the work area of any obstacles (loose parts, tools, hands, chips). If anything goes wrong, press STOP or type M112 to abort immediately. Continue?",
  "dlg.toolChange.msg": "Tool change (M6): before continuing, <b>stop the spindle</b> and wait for the cutter to come to a complete stop. If a tool is currently installed, loosen and remove it first. The machine will lift Z, move to the tool-change zone and wait. After installing the new tool, tighten it and press READY to continue from where it left off. Continue?",
  "dlg.park.msg":       "The machine will move to the parking zone (back and up) and release the X/Y motors so you can move the gantry by hand. The workpiece position is NOT lost. To resume, press HOME on the top bar. Continue?",
  "dlg.recoverSensors.msg":
    "Re-arm the safety sensors and clear the homing state. The firmware is NOT restarted. Only press this right after a STOP during a homing or if a trigger2 (emergency) left the sensors disabled. Do NOT press it during an active homing — it would disable the protection mid-movement.",
  "dlg.restoreBackup.msg":
    "All files in /sys/ and /macros/ will be overwritten with the ZIP content. Firmware will restart.",
  "dlg.restoreBackup.msgOtherMachine":
    "This backup comes from machine <strong>\"{backup}\"</strong>, but the current machine is <strong>\"{current}\"</strong>.",
  "dlg.restoreBackup.msgNoIdentity":
    "This backup does not state which machine it comes from (origin <strong>unknown</strong>: it was created with an older version). The current machine is <strong>\"{current}\"</strong>.",
  "dlg.restoreBackup.warnCalib": "<br><br><strong>The following will be overwritten</strong>: steps/mm, work area, probe offsets and motor currents.",
  "dlg.restoreBackup.noConfigMachine": "<br><br><strong style=color:var(--warn-strong)>This backup does not include <code>sys/config-machine.g</code>.</strong> If you have an HTTP PIN (M551) configured, it will be erased on restore. Go back to CONFIGURATION → HTTP PIN and define it again if you want to keep it.",
  "dlg.restoreFactory.msg":
    "Load <strong>0:/sys/config.g.bak</strong> as the active configuration?<br><br>" +
    "This will overwrite the current <code>config.g</code> settings: <strong>steps/mm, work area, probe offsets and motor currents</strong>.<br>" +
    '<strong style="color:var(--warn-strong)">The machine will restart automatically.</strong><br><br>' +
    '<span style="color:var(--text-3);font-size:11px">Cannot be undone from the UI. If you need a different calibration, edit <code>sys/config.g</code> on the SD with a text editor, or go to CONFIGURATION → MOTORS and re-enter the values.</span>',
  "dlg.wcsZeroAll.msg":
    "Set the current position as workpiece origin (0,0,0) on ALL THREE axes?<br><strong>This is destructive</strong>: the next cut will start at the current position, NOT at the corner of the material. If in doubt, cancel and run Z PROBE for Z first, and the fixed probe for X/Y. Continue?",
  "dlg.wcsZeroX.msg":
    "Set the current position as workpiece origin on <b>X</b>?<br>The next cut in X will start here, NOT at the edge of the material. If in doubt, cancel and use the fixed probe for X. Continue?",
  "dlg.wcsZeroY.msg":
    "Set the current position as workpiece origin on <b>Y</b>?<br>The next cut in Y will start here, NOT at the edge of the material. If in doubt, cancel and use the fixed probe for Y. Continue?",
  "dlg.wcsZeroZ.msg":
    "Set the current position as workpiece origin on <b>Z</b>?<br><strong>This is destructive in Z</strong>: half a millimetre of error and the cutter will pass above or below the workpiece. If in doubt, cancel and run Z PROBE. Continue?",
  "dlg.dangerCmd.msg":
    " may disconnect the machine or change network settings.<br>Send anyway?",
  "dlg.motorsReboot.msg":
    '<p style="margin-bottom:10px">Changes to <strong>steps/mm</strong> and <strong>current</strong> require a full board restart to apply correctly.</p>' +
    '<p style="color:var(--yellow);font-size:11px">The machine will stop and lose its homing position.</p>',
  "dlg.histClear.msg":
    "All <strong>recorded jobs</strong> will be deleted (maintenance counters are NOT touched).<br>" +
    '<span style="color:var(--text-3);font-size:11px">An audit entry is left on the SD in <code>sys/jobhistory.json</code> with the deleted count (timestamp + previous <code>jobsCount</code>). Cannot be undone from the UI.</span><br>' +
    "Continue?",
  "dlg.histReset.msg":
    "Spindle hours and accumulated distance will be set to zero.<br>The <strong>job history is NOT touched</strong>.<br>" +
    '<span style="color:var(--text-3);font-size:11px">An audit entry is left on the SD in <code>sys/jobhistory.json</code> with the previous values (timestamp + snapshot).</span><br>' +
    "Do this after actual maintenance. Continue?",
  "dlg.probeAutoXY.msg":
    "The machine will probe X and Y automatically by moving toward the workpiece.<br>" +
    "<b>Place the probe diagonally at the corner, in the air, at edge height.</b><br>Start?",
  "dlg.noHomed.msg":
    '<p style="color:var(--red)">WARNING! You have not homed the axes. With «Require HOME» on (the normal setting) the machine <strong>will refuse the job</strong>. Only in maintenance mode will it start, and then it does not know where it is and software limits <strong>will not work</strong>: the cutter may leave the material or hit the clamp.</p>' +
    '<p>Fix: cancel this dialog and press <strong>HOME</strong> (G28) in the top bar. The machine will reference all 3 axes and you will then be able to start safely.</p>' +
    '<p>Start anyway? (NOT recommended)</p>',
  "dlg.checklist.msg":
    '<div style="text-align:left;line-height:2;font-size:13px">' +
    "<div>☐ <strong>Cutter secured</strong> — Is the collet nut tight?</div>" +
    "<div>☐ <strong>Workpiece clamped</strong> — Is the material fixed to the table?</div>" +
    "<div>☐ <strong>Z origin correct</strong> — Have you run Probe Z or set Z=0 manually?</div>" +
    "<div>☐ <strong>XY origin correct</strong> — Is the cutter above the correct corner?</div>" +
    "<div>☐ <strong>Area clear</strong> — No cables, clamps or tools in the work area?</div>" +
    '</div><p style="color:var(--yellow);font-size:11px;margin-top:10px">Confirm only if all points are verified.</p>',

  // ── Missing dynamic keys from Prompt 5 ────────────────────────────────────
  "msg.noFile": "No file",
  "probe.active": "Z Probe: TRIGGERED",
  "probe.free": "Z Probe: CLEAR",
  "probe.noData": "Z Probe: No data",
  "school.hintIdleNoFile": "Load a G-code file from the FILES panel to begin.",
  "school.hintIdleFile": "File loaded. Run Home All (G28) if you haven't, then press START JOB.",
  "school.hintReady": "Verify the XYZ origin is over the workpiece and press START JOB.",
  "school.hintRunning": "Job in progress. You can adjust Feed and Spindle overrides. Press PAUSE if you need to intervene.",
  "school.hintPaused": "Job paused. Press RESUME to continue or ESC / CANCEL to abort.",
  "school.hintError": "Error detected. Press RESET to reboot the firmware, then you must run Home All (G28).",

  // ── I18N-4 (jul-2026): Claves de seguridad añadidas al inglés (msg.* y dlg.*)
  // 3 placeholders puros (msg.err, msg.msg, msg._warn0) se omiten a propósito: el texto
  // mostrable es dinámico (${err} / ${msg} / ${_warn[0]}) y no se puede internacionalizar.
  "dlg.goto0.msg": "The machine will move to (X0, Y0) of the current workpiece origin (WCS) — not the machine origin. Before Go to 0, make sure you already fixed the workpiece origin with ZERO XY. If in doubt, cancel and go to CEROS → FIJAR origen. Continue?",
  "dlg.goto0.title": "Go to 0",
  "dlg.noOrigin.msg": "<p style=\"color:var(--yellow)\">You have not set the workpiece zero (X0 Y0 Z0): if you press Start, the cut will begin at the <strong>machine corner</strong>, not where your material sits — you will ruin the piece and the cutter may hit the workpiece clamp.</p><p><strong>How to set the origin before starting:</strong></p><ol style=\"text-align:left;line-height:1.7;margin:6px 0 10px 18px\"><li>Position the cutter over the corner of the piece you want as X0 Y0 (top-left corner, by convention).</li><li>Press <strong>Zero XY</strong> on the RIGHT panel (target icon).</li><li>Lower the cutter until it touches the surface of the workpiece (paper between cutter and table) and press <strong>Zero Z</strong>.</li><li>As a more reliable alternative, use <strong>Z Probe</strong> (antenna icon) in the top bar — the probe measures the height automatically.</li></ol><p>If your G-code already comes in absolute machine coordinates and you know what you are doing, you can continue. If not, cancel and set the origin first.</p><p>Start anyway?</p>",
  "dlg.noSpinUp.msg": "<p style=\"color:var(--yellow)\">The G-code starts the spindle (M3) but does NOT wait for it to reach target RPM before cutting (G4 missing): the first cut will begin while the spindle is still ramping up, with a risk of <strong>breaking the cutter</strong> and a poor finish.</p><p><strong>How to fix it:</strong></p><ul style=\"text-align:left;line-height:1.7;margin:6px 0 10px 18px\"><li>If you generate the G-code with the RotechOS postprocessor, this problem should NOT appear — regenerate the file from your CAM.</li><li>If it comes from another CAM (Fusion, VCarve, EstlCAM…): open the file in SETTINGS → Macros or in a text editor, find the line <code>M3 S…</code> and add right after it <code>G4 S3</code> (3-second pause).</li><li>If your spindle is a manual Makita and is already at full speed before starting, you can continue.</li></ul><p>Start anyway?</p>",
  "dlg.noSpinUp.title": "SPINDLE WITHOUT STARTUP WAIT",
  "msg.abriendoFname": "Opening ${f.name}…",
  "msg.alturaZDeSeguridad": "Safe Z height → ${v} mm",
  "msg.análisisCompletado": "Analysis complete",
  // El número de MB se concatena en el call site (rotechos-fm.js:77/142) — el
  // mismo patrón que msg.zLimitWarn: la clave guarda solo la parte estática.
  // Antes (jul-2026) tenía "50" BAKED IN, lo que silenciosamente mentía si
  // MAX_UPLOAD_MB cambiaba de 50 a cualquier otro valor.
  "msg.archivoDemasiadoGrandeMáx": "MB — too large. To upload it, zip it on your PC, unzip it onto the SD with a card reader, and drag the loose files into the OTA zone of SETTINGS.",
  "msg.archivoNoVálido": "Invalid file",
  "msg.atajosRestauradosAValores": "Shortcuts restored to defaults",
  "msg.backupExportadoPartslengthArchivos": "Backup exported — ${parts.length} files",
  "led.pat.deepbreath": "Deep breath",
  "led.pat.ready_pulse": "Fade-in → steady",
  "led.pat.running_flow": "Job flow",
  "led.pat.smoothpulse": "Soft heartbeat",
  "led.pat.pulse_error": "1 Hz pulse (alarm)",
  "led.pat.ov_home_fill": "HOMING — progressive fill",
  "led.pat.ov_goto0": "GO TO 0 — dimmed convergence",
  "led.pat.ov_park_fade": "PARK — organic fade-out",
  "led.pat.ov_probe_z": "Z PROBE — probing",
  "led.pat.ov_probe3d": "3D PROBE — sweep",
  "led.pat.ov_spindle_ramp": "SPINDLE — ramp-up (M3)",
  "led.pat.ov_spindle_brake": "SPINDLE — ramp-down (M5)",
  "led.pat.ov_thermal": "THERMAL ALARM — heat wave",
  "led.pat.ov_config": "CONFIG MODE — purple cylon",
  "led.pat.ov_estop": "EMERGENCY STOP — strobe",
  "led.pat.ov_toolchange_wait": "TOOL CHANGE — waiting",
  "led.pat.ov_job_done": "JOB COMPLETE — celebration",
  "led.pat.ov_boot": "BOOT — welcome sequence",
  "jobs.empty": "No jobs recorded yet",
  "msg.otaProtegido": "File ignored: ${name}. It belongs to each individual machine (calibration or WiFi credentials) and OTA does not replace it. To recover a calibration use SETTINGS → BACKUP → Restore.",
  "dlg.otaConfigG.title": "Replace config.g?",
  "dlg.otaConfigG.body": "<p><strong>config.g</strong> holds the motor mapping of THIS machine: which driver moves each axis, the direction of rotation and the endstops. If you changed them in SETTINGS they will be lost, and an axis may move the wrong way.</p><p>Upload it only if the release notes ask for it. Afterwards, before moving anything, check MOTORS and ENDSTOPS and test each axis with your hand on the stop button.</p>",
  "dlg.otaConfigG.yes": "Replace config.g",
  "dlg.otaConfigG.no": "Discard",
  "work.estopNoEntregado": "M112 NOT DELIVERED: USE THE E-STOP",
  "work.estopEnviando": "SENDING M112…",
  "msg.estopReenviado": "Network back: the emergency stop had NOT reached the machine and has been sent now.",
  "kb.home":       "Home All (G28)",
  "kb.stop":       "Emergency stop",
  "kb.spindle":    "Spindle ON / OFF",
  "kb.modeSilk":   "SEDA mode (manual)",
  "kb.modePro":    "RAYO mode (production)",
  "kb.zeroX":      "Zero X (G10 L20 X0)",
  "kb.zeroY":      "Zero Y",
  "kb.zeroZ":      "Zero Z",
  "kb.console":    "Open console",
  "kb.config":     "Open configuration",
  "kb.change":     "Change",
  "kb.resetTitle": "Restore default key",
  "msg.blockedPaused": "Blocked while PAUSED: would alter the job on resume",
  "msg.blockedRunning": "Blocked: a job is RUNNING (pause first)",
  // t_ee1497a0 (2026-09-01): tras un paro de emergencia la herramienta puede
  // quedar clavada en la pieza. La regla: bloquea TODO (HOME, sonda, M6,
  // husillo, ceros, macros con movimiento, iniciar trabajo, JOG XY/-Z).
  // El único movimiento que se permite es +Z, con confirmación explícita.
  // La UI dice cómo salir del estado y recuerda que +Z sigue accesible.
  "msg.blockedEStop": "Emergency stop active. Re-arm to regain control. You can move Z up to free the tool.",
  "msg.estopSinMovimiento": "After the E-STOP the machine accepts no moves. Press RESET and then HOME (Z goes up before X/Y move).",
  // Diálogo de confirmación para el +Z tras paro. NO es un jog normal: el
  // operario debe saber que está moviendo la herramienta después del paro.
  "dlg.estopZretirar.title": "Retract the tool in +Z",
  "dlg.estopZretirar.body": "The emergency stop is active. Moving Z up will pull the bit away from the material.<br><br>Before confirming, make sure the tool can rise freely without hitting anything.<br><br><strong>Move Z up?</strong>",
  "msg.capturaDeTeclaCancelada": "Key capture cancelled",
  "msg.cargandoFilename": "Loading …",
  "msg.cargandoFname": "Loading ${f.name}…",
  "msg.colisiónDeDriversDupesjoin": "Driver collision: ${dupes.join(', ')} — a TMC2160 driver cannot move two axes at the same time. Check M584 in SETTINGS → Motors and assign each axis to a different driver (P0, P1, P2, …). If in doubt, open the .g via SETTINGS → 'View config.g' and look for the line M584 X… Y… Z…; that is the current mapping.",
  "msg.pinActivateConfirm": "Activate PIN",
  "msg.pinActivateL1": "With an active PIN, the emergency stop from the browser requires you to have logged in.",
  "msg.pinActivateL2": "We recommend a physical mushroom button wired to the firmware shield (M581, already active).",
  "msg.pinActivateL3": "The PIN travels unencrypted over HTTP — it protects from casual access, NOT from someone capturing traffic.",
  "msg.pinActivateL4": "Continue and save the PIN?",
  "msg.pinActivateTitle": "Activate HTTP PIN",
  "msg.pinDuplicado": "There are several M551 lines in config-machine.g. Edit the SD and keep only one before continuing.",
  "msg.pinEmpty": "The PIN is empty or only contains forbidden characters",
  "msg.pinFactoryDefaultNotice": "<strong style=color:var(--warn-strong)>Factory PIN detected.</strong> This machine ships with a default PIN (<code>123456789</code>). We recommend you <strong>change it</strong> below or <strong>remove it entirely</strong> from SETTINGS → HTTP PIN. If you do nothing, the PIN stays the same and anyone who has read the manual can enter the panel.",
  // t_8ebcb0bc — banner "MÁQUINA SIN CALIBRAR" en CONFIGURACIÓN cuando la
  // máquina usa los fallbacks genéricos de config.g (config-machine.g ausente
  // o trivial). Texto ES inline en index.html; este es el override EN.
  "msg.calibNotDone": "<strong style=\"color:var(--warn-strong)\">NOT CALIBRATED — do not machine.</strong> Generic <code>config.g</code> values. Calibrate in <strong>FIRST RUN</strong>.",
  "msg.pinFailedApply": "Could not apply the PIN — helper not available",
  // B1-02 (acta B1 2026-09-06): el botón "Saltar y terminar" del paso 12
  // del wizard muestra un toast informativo cuando el operario decide
  // dejar el PIN de fábrica. NO es un error ni una alerta — es la
  // decisión del operario. La UI no le miente: el PIN sigue siendo el
  // de fábrica, pero le recuerda que puede cambiarlo.
  "msg.pinSkippedFactory":     "You decided to keep the factory PIN. You can change it any time from SETTINGS → HTTP PIN.",
  // HALLAZGO-7 (informe 2026-08-18-busca-mensajes-v2): módulo rotechos-auth.js completo sin i18n.
  // 6 strings del overlay + mensajes de error PIN (HALLAZGO-4 ya apuntaba al rechazo).
  // El fallback ES vive dentro del código JS; las claves EN viven aquí.
  "msg.pinOverlayTitle":       "HTTP PIN required",
  "msg.pinOverlayBody":        "The machine requires the HTTP password. Enter it to continue. The PIN travels unencrypted over HTTP — it protects from casual access, not from anyone capturing traffic.",
  "msg.pinOverlayBtnOk":       "Log in",
  "msg.pinOverlayBtnCancel":   "Cancel",
  "msg.pinOverlayEmptyError":  "Empty PIN.",
  "msg.pinOverlayRejected":    "Wrong PIN. Try again.",
  // HALLAZGO-8: lockout 30s tras 5 fallos. {secs} se sustituye por código JS
  // (rotechos-auth.js:_isLockedOut → window.toast warn). Coherente con la
  // política HALLAZGO-6: t() NO expande plantillas; el .replace('{secs}', n)
  // lo hace el código que conoce el número.
  // Motivos DISTINTOS del escudo (2026-08-31). Antes los tres compartian
  // msg.shieldAbort y uno de ellos —el bloqueo temporal— pedia un PIN que
  // no se podia teclear en ninguna parte.
  "msg.shieldLockout":         "Too many failed attempts. Wait a few seconds and try again — nothing to type right now.",
  "msg.shieldBusy":            "A PIN is required, but it is not requested while the machine is moving. Pause or stop the job and retry.",
  // HUECO-5: el escudo falló por red; dice qué revisar y no pide PIN.
  "msg.shieldNetwork":         "Command could not be sent: the controller is unreachable. Check the WiFi or the network cable and retry.",
  "msg.pinLockoutWarn":        "Too many attempts — wait {secs}s before retrying.",
  "msg.pinMismatch": "The two fields do not match",
  // t_4f22bdc3 (2026-09-01): feedback EN VIVO en el input del PIN (panel
  // Configuración → PIN HTTP). El validador (`rotechos-auth.js:validateM551Pin`)
  // devuelve `{ok, motivo, caracter, restantes}`; cada motivo tiene su
  // clave i18n aquí. El fallback ES vive en el segundo argumento de `t(...)`
  // en rotechos-auth.js (fuente de verdad en castellano). Sincronizadas
  // con la clave hermana del panel modal (`_setPin`, rotechos-config-modal.js).
  "msg.pinCharset.restantes":         "{n} characters left",
  "msg.pinCharset.excedido":          "Over by {n}",
  "msg.pinCharset.demasiado-largo":   "Maximum 24 characters (current: {n}).",
  "msg.pinCharset.espacio":           "The PIN cannot contain spaces. Remove the space and retype.",
  "msg.pinCharset.caracter-invalido": "Character not allowed: {ch}. Only letters, digits and the symbols - _ . @ # ! ? , : are accepted.",
  "msg.pinCharset.desconocido":       "Invalid PIN. Check the allowed characters and the maximum length.",
  "msg.pinRemoveConfirm": "Remove PIN",
  "msg.pinRemoveL1": "You are about to remove the HTTP PIN. The UI will reopen without asking for a password.",
  "msg.pinRemoveL2": "If you had a PIN configured, this change is applied on save.",
  "msg.pinRemoveL3": "Removing the PIN leaves the machine accessible to anyone on the workshop network (neighbour, guest, technician on your WiFi): it is not a barrier against someone who knows what they are doing.",
  "msg.pinRemoveTitle": "Remove HTTP PIN",
  "msg.pinRemoveVerifyFail": "Could not confirm the PIN removal — ${count} M551 line(s) still in config-machine.g. Edit the SD manually before continuing.",
  "msg.pinRemoved": "HTTP PIN removed. The UI reopens without a password.",
  "msg.pinSaved": "PIN saved. The UI and HTTP API will require this PIN from now on.",
  "msg.pinStatusActive": "Status: PIN active — length ${len}",
  "msg.pinStatusFactorySuffix": "FACTORY PIN (123456789). We recommend changing it.",
  "msg.pinStatusNone": "Status: (no PIN)",
  "msg.comandoCríticoPerdidoCmd": "Critical command lost: ${cmd}",
  "msg.feedOverrideLost": "Feed override NOT applied to firmware. Check the connection (the requested value and the firmware value are shown in the status panel).",
  "msg.comandoSinRespuestaInterfaz": "Command without response — UI unblocked",
  "msg.conectadoARotechos": "Connected to RotechOS",
  "msg.configMaquinaNoLeida": "Could not read config-machine.g — save ABORTED to avoid overwriting your calibration (steps/mm, currents, work area, probe). NOTHING has been saved. What to do: (1) check the WiFi connection to the machine, (2) open SETTINGS → open and verify the MOTORS / SPEEDS / SOFT-LIMITS / BACKLASH tabs still show your real values, (3) retry the change you wanted to save. If your calibration no longer appears on screen, do NOT touch anything and contact support.",
  "msg.configModalLoadFail": "Could not load the SETTINGS module — try opening it again. If it keeps failing, reload the page (this refreshes the cache and the SETTINGS module loads eagerly on the next open).",
  "msg.configSoloEscritorio": "Settings are configured from a computer. Open RotechOS on a PC connected to the same network as the machine.",
  "msg.configgNoCargado": "config.g not loaded",
  "msg.configgRestauradoDeFábrica": "config.g restored to factory defaults ✓ — restarting…",
  "msg.restoreFactoryM999FailLog": "Restore to defaults → config.g written, M999 failed (not applied in firmware)",
  "msg.restoreM999Failed": "config.g written to the SD but the reboot (M999) failed — restart the machine by hand to apply the changes",
  "msg.configuraciónGuardada": "Configuration saved ✓",
  "msg.toolsSacGuardado": "Tool change saved ✓ — the TABLE is saved with each row's own buttons",
  "msg.conflictoConConflict1label": "Conflicts with: ${conflict[1].label}",
  "msg.contornoCancelado": "Perimeter check cancelled",
  "msg.ejeAxMaxFalta": "Axis ${ax} MAX: pin missing. Enter the pin (e.g. C.6) or use the placeholder.",
  "msg.ejeAxMinFalta": "Axis ${ax} MIN: pin missing. Enter the pin (e.g. A.8) or use the placeholder.",
  "msg.elGuardadoNoSe": "Save NOT confirmed on the SD — the upload was retried and the read-back did not match. Your change is NOT on the SD. Retry the save; if it fails again, check the WiFi connection to the machine and that the SD is not full or write-protected.",
  "msg.endstopsActualizados": "Endstops updated",
  "msg.errorAlAnalizarGcode": "Error analyzing G-code",
  "msg.errorAlCargarFilename": "Error loading ${filename}",
  "msg.m23NoAbierto": "The machine could not open ${filename}",
  "msg.errorAlEjecutarMname": "Error executing \"${m.name}\" — the firmware returned an error. Check the CONSOLE tab (bottom panel) for the cause: it may be a flaky WiFi link, a line with bad syntax in the .g, or the macro requires a state the machine does not have (e.g. previous HOME, or workpiece under the probe). Fix the cause and press the macro again.",
  "msg.errorAlGuardarFilename": "Error saving ${filename}",
  "msg.errorAlLanzarHealth_checkg": "Error launching health_check.g",
  "msg.errorAlLeerEl": "Error reading the file",
  "msg.errorAlLeerFname": "Error reading ${f.name}",
  "msg.errorAlReanudar": "Error resuming",
  "msg.errorLeyendoSensoresGpio": "Error reading GPIO sensors",
  "msg.errorRestaurandoBackup": "Error restoring backup — check the WiFi connection to the CNC and retry from SETTINGS → Backup",
  "msg.escribeElNombreDel": "Enter the .g filename",
  "msg.escribeUnNombrePara": "Enter a name for the macro",
  "msg.estaTeclaEstáReservada": "This key is reserved for jog",
  "msg.estopNetworkError": "⚠ NETWORK ERROR: use the physical machine button!",
  "msg.executingMacro": "Executing ",
  "msg.filenameGuardadoEnSd": "${filename} saved to SD",
  "msg.endstopJobPaused": "Endstop ${ax} triggered — Job paused",
  "msg.endstopMoveStopped": "Physical endstop ${ax} triggered — move stopped. Do NOT power off the machine. To back away from the endstop, press the jog button that goes the opposite way (if you're not sure which one, try −X, +Y, −Y, +Z, −Z in that order, one step at a time). If the endstop triggers repeatedly, check that the workpiece doesn't stick out of the work area.",
  "msg.formatoNoSoportadoGcode": "Unsupported format (.gcode .g .nc .cnc .tap)",
  "msg.homingRequired": "Homing required",
  "msg.jogBlockedHoming": "Jog blocked: run HOME first (HOME button on the top bar or G28) — without HOME the safety limits don't know where the machine is and the firmware could bypass M564 H0 if it's on",
  "msg.iniciandoSmloadedfile": "Starting: ${SM.loadedFile || \"—\"}",
  "msg.introduceVelocidadMinimaY": "Enter the minimum and maximum speed",
  "msg.lblFmtkeyk": "${lbl} → ${fmtKey(k)}",
  "msg.listoFilename": "✓ Ready: ${filename}",
  "msg.macroAppstatemacronameCompletada": "Macro \"${AppState.macro.name || ``}\" completed",
  "msg.macroGuardada": "Macro saved",
  "msg.macroCrearInvalida": "Cannot create the macro: ${n} invalid line(s). RRF 3.5.4 limit: 256 non-comment chars/line. Edit and press Create again.",
  "msg.macroGuardarInvalida": "Cannot save: ${v.errors.length} invalid line(s) — ${head}${more}. RRF 3.5.4 limit: 256 non-comment chars/line.",
  "msg.macroNameAñadida": "Macro \"${name}\" added",
  "msg.macroNameSanitized": "Filename sanitized → \"${cleanFile}\"",
  "msg.macroPausada": "Macro paused",
  "msg.macroReanudada": "Macro resumed",
  "msg.macroSoloLanzador": "The current code is just a launcher (M98 to the same .g). Uploaded as-is to the SD it would loop forever. Replace with real G-code (G28, G1, M3, etc.) and Save again. Press Cancel to keep as reference.",
  "msg.macroUploadSession": "Error uploading .g to the SD — change NOT persisted. Check WiFi and SD (full or write-protected) and try Save again.",
  "msg.macroUploadNotCreated": "Error uploading .g to the SD — macro NOT created: your code is NOT lost (it remains in the editor); only the copy to 0:/macros/ failed. Check the WiFi link to the machine, that the SD is not full or write-protected, and press Save again. If it still fails, edit the macro from SETTINGS → Macros and try via the 'existing' route.",
  "msg.macrosActualizadas": "Macros updated",
  "msg.noEncuentroM92": "M92 line not found in config-machine.g",
  "msg.noEncuentroM208": "M208 ${tag} line not found in config-machine.g",
  "msg.noFilesFound": "No files found",
  "msg.noSePudoLeer": "Could not read ",
  "msg.noSePuedeEliminar": "Cannot delete while running: stop the current job first (press STOP in the top bar, wait until the state becomes READY) and try again. If it is PAUSED, press RESUME until it finishes, then STOP.",
  "msg.noUploadRunning": "Cannot upload files while a job is running",
  "msg.nombreSanitizadoSafename": "File name sanitized — the SD only accepts letters, digits, hyphen and dot; we replaced the invalid characters (spaces, accents, ñ, symbols) with underscores. If you want a different name, rename it on your PC before uploading.",
  "msg.notificacionesActivadas": "Notifications enabled",
  "msg.notificacionesDesactivadas": "Notifications disabled",
  "msg.notificacionesNoDisponiblesEn": "Notifications not available in this browser",
  "msg.otaZipRejected": "ZIP not supported — unzip it on your PC (double-click), open the folder it created, and drag the loose files (.html, .js, .css, .gz, etc.) into this OTA zone. .gz files are uploaded as they are: the board serves them compressed.",
  "msg.otaHowto": "Download it, unzip it, and drop the loose files into the upload area in SETTINGS.",
  "msg.otaBehind": "You are {n} versions behind; this one includes them all, install only the latest.",
  "msg.otaInProgress": "Checking…",
  "msg.otaNewVersion": "New version available",
  "msg.otaOffline": "No connection to the update server (on the RotechOS network this device has no internet). The machine works as usual. To update without internet, download the ZIP on another device and use «Install from a ZIP».",
  "msg.otaInstallNow": "Install now",
  "msg.otaHowtoInstall": "Or download it and use «Install from a ZIP» in SETTINGS → UPDATE (OTA).",
  "msg.otaInstNoZip": "the file is not a ZIP",
  "msg.otaInstZipRoto": "the ZIP is damaged",
  "msg.otaInstZipCifrado": "the ZIP is encrypted",
  "msg.otaInstSinInflate": "this browser cannot unzip the ZIP; update it or upload the loose files",
  "msg.otaInstCrc": "{f} is damaged inside the ZIP",
  "msg.otaInstNoRotechos": "this ZIP is not a RotechOS release (ROTECHOS/www/index.html or ROTECHOS/sys/VERSION is missing)",
  "msg.otaInstFallo": "The installation did not complete",
  "msg.otaInstAuth": "the machine did not accept the connection (PIN)",
  "msg.otaInstTitulo": "Installing RotechOS {v}",
  "msg.otaInstQuieto": "Do not switch the machine off or close this page.",
  "msg.otaInstSubida": "could not write {f} ({e}). The SD card is half updated: repeat the installation.",
  "msg.otaInstHecho": "Files written. Restarting the board…",
  "msg.otaInstSinPaquete": "this release has no installable package; download it from GitHub",
  "msg.otaInstBajando": "Downloading RotechOS {v}",
  "msg.otaInstSinRed": "could not download ({e}). If this device has no internet, download the ZIP on another one and use «Install from a ZIP» in SETTINGS → UPDATE (OTA)",
  "msg.otaInstSha": "the download does not match the published one; try again in a few minutes",
  "msg.otaInstOrigenGithub": "downloaded from GitHub",
  "dlg.otaInst.title": "Install RotechOS {v}",
  "dlg.otaInst.body": "{n} files will be written to the machine's SD card ({o}). It takes a few minutes: do not switch the machine off or close this page until it finishes.",
  "dlg.otaInst.older": "It is OLDER than the installed one ({v}).",
  "dlg.otaInst.same": "It is the same version you already have; it will be written again.",
  "dlg.otaInst.keep": "Your calibration (config-machine.g), motor mapping (config.g) and WiFi are kept.",
  "dlg.otaInst.after": "The board restarts when it finishes. Then, before HOME, jog each axis a little with your hand on the emergency stop.",
  "dlg.otaInst.yes": "Install",
  "dlg.otaInst.no": "Cancel",
  "msg.otaRepoUnavailable": "The automatic update check is not available in this build. To update, download the new release from GitHub and drag the loose files into the upload area in SETTINGS (OTA).",
  "msg.otaUpToDate": "Up to date",
  "msg.otaViewRelease": "View on GitHub",
  "msg.otraPestañaHaTomado": "Another tab has taken control",
  "msg.parkgActualizado": "Change applies to this session only — park.g on the SD has NOT been modified. Only the in-memory copy of the Park macro (used by the UI when you press PARK) is regenerated here; if you reload or restart the machine it reverts to the park.g in 0:/macros/. To save the new code to the SD, edit park.g from SETTINGS → Macros and press Save.",
  "msg.microstepRecalcTitle":     "Recalculate steps/mm",
  "msg.microstepRecalcBody":      "Changing microstepping <strong>rescales steps/mm</strong> so the machine keeps moving the same distance. Without rescaling, a 100 mm cut would come out at a different size.<br><br><strong>Planned changes:</strong><br>${lines}<br><br>Apply the recalculation and save?",
  "msg.microstepRecalcCancel":    "Recalculation cancelled — nothing was saved",
  "msg.pasosmmAxisV": "Steps/mm ${axis} → ${v}",
  "msg.pasosmmInválidos": "Invalid steps/mm",
  "msg.pausando": "Pausing…",
  "msg.pausaNoAplicada": "⚠ Could not pause — firmware did not respond. The spindle is STILL CUTTING — keep away.",
  "msg.perfilDeTecladoExportado": "Keyboard profile exported",
  "msg.perfilImportado": "Profile imported",
  "msg.permisoDenegado": "Permission denied",
  "msg.probe3dgActualizado": "Change applies to this session only — probe3d.g on the SD has NOT been modified. Only the in-memory copy of the 3D probe macro (used by the UI when you launch the 3D probe) is regenerated here; if you reload or restart the machine it reverts to the probe3d.g in 0:/macros/. To save the new code to the SD, edit probe3d.g from SETTINGS → Macros and press Save.",
  "msg.probegSoloSesion": "Change applies to this session only — the real probe is calibrated in SETTINGS → Probe. Only the in-memory copy used by this UI has changed; the .g on the SD (sonda_Z.g) has NOT been touched. To save the change to the SD, edit sonda_Z.g from SETTINGS → Macros and press Save.",
  "msg.readOnlyTab": "Tab is read-only — another session controls the machine",
  "msg.reanudandoTrabajo": "Resuming job",
  "msg.referenciaLosEjesAntes": "Home the axes before enabling RAYO mode",
  "msg.rpmMaximoAjustadoA": "Max RPM adjusted to 24000 (spindle limit)",
  "msg.rpmMinimoAjustadoA": "Min RPM adjusted to 6000 (spindle safety)",
  "msg.rpmMinimoMnDebe": "Min RPM (${mn}) must be lower than max (${mx})",
  // t_028bceef — modo LÁSER (tostadas de validación en el modal SPINDLE)
  "msg.laserRangoInvalido": "Laser power: range 0–100 (%) required",
  "msg.laserMinDebeMenorMax": "Laser min power (${mn}) must be lower than max (${mx})",
  "msg.sacValActivadoDesactivado": "SAC ${s}",
  "msg.seleccionaUnaPestaña": "Select a tab",
  "msg.simulateBusy": "Simulation only available when the machine is in READY/IDLE state",
  "msg.simulateDone": "Simulation complete: ${_human}",
  "msg.simulateErr": "Error launching simulation",
  "msg.simulateNoFile": "Load a .gcode file before simulating",
  "msg.simulateTimeout": "Simulation produced no result after 30 s",
  "msg.simulatingStarted": "Simulating…",
  "msg.sinConexionBuscando": "No connection — looking for the machine…",
  "msg.softLimitAxisSide": "Soft limit ${axis} ${s} → ${v} mm",
  "msg.teclaReservadaDelNavegador": "Browser-reserved key",
  "msg.trabajoCancelado": "Job cancelled",
  "msg.trabajoReanudado": "Job resumed",
  "msg.valorInválidoParaAxis": "Invalid value for ${axis} ${side}",
  "msg.wizAreaInvalid": "Enter all three travels in mm",
  "msg.wizAreaNoFn": "Limits function not available",

  // ── RECUPERADO 2026-08-27 de una copia fantasma de iCloud ──────────────
  // Estas nueve claves se escribieron el 27-ago de madrugada y desaparecieron
  // del fichero real: vivian SOLO en `rotechos-i18n-dynjs 2.js`, una copia que
  // iCloud bifurca cuando dos procesos escriben a la vez y que .gitignore
  // oculta (patron `* [0-9].js`), asi que ni git ni ningun gate las veian.
  // Mientras faltaron, un operario en ingles leia SEIS avisos criticos en
  // espanol — entre ellos el del escudo de autenticacion. Lo cantaba
  // tests/unit/i18n-gate.test.js ("faltan traducciones de seguridad").
  // El fallback ES vive como segundo argumento de t() en el codigo JS.
  "btn.reabrirBienvenida":      "Replay welcome",
  "msg.macroAbortada":          "Macro aborted by emergency stop",
  "msg.shieldAbort":            "PIN rejected: the auth shield blocked the command (closed session or stale cached PIN). Open SETTINGS → PIN and re-enter it.",
  "msg.vizEmptyBadType":        "Only .gcode / .g / .nc / .cnc / .tap / .txt files are accepted",
  "msg.vizEmptyLoadFail":       "Uploaded, but the file could not be loaded automatically",
  "msg.vizEmptyNoUpload":       "Upload not available right now — use LOAD G-CODE",
});

window.I18N && window.I18N.add({
  "qa.homeAllSchool": "<strong>Home All (G28)</strong>Seeks the machine's mechanical origin. Mandatory upon powering up the controller or after an error state. The Z axis raises first for safety before X and Y move.",
  "qa.probezSchool": "<strong>Probe Z</strong>Runs the Z-probe macro: the machine goes to the fixed button, touches it and sets Z=0 at the table plus the material thickness set in SETTINGS → PROBE Z. ⚠ <strong>CRITICAL!</strong> If that thickness is not your material's, the zero is wrong and the tool will cut too deep or too shallow.",
  "qa.m6School": "<strong>ATC / M6</strong>Initiates the Assisted Tool Change sequence (M6). The machine moves to the tool change position and probes the new tool to compensate for height difference. <strong>Note:</strong> This does NOT find the workpiece zero; you must set Z0 on the material before running the job.",
  "qa.goto0School": "<strong>Go To 0</strong>Moves the tool to the X=0, Y=0 coordinates of the current work coordinate system. Useful to visually verify that the workpiece origin is correct before starting a job.",
  "qa.parkSchool": "<strong>Park</strong>Moves the spindle to a safe clearance zone (usually all the way back) and releases the X and Y motors to facilitate loading and unloading material on the table.",
  // C1 (FASE C): botón SIMULAR (M37)
  "qa.simulateSchool": "<strong>Simulate (M37)</strong>Runs RRF's built-in simulator: calculates the estimated job time WITHOUT moving the machine. Useful to verify a large file fits the time you have available and to detect errors without wasting material. The result is shown in a toast when complete.",
  "qa.simulate": "SIMULATE",
  "cfg.spindleWarmupSchool": "<strong>Spindle Warmup</strong>Executes a progressive RPM ramp to preheat the spindle bearings. Preheating the bearings at low RPM before cutting distributes grease and drastically prolongs the high-frequency spindle's lifespan. Use it as the first action of the day, especially in winter or after a long downtime.",
  "cfg.healthCheckSchool": "<strong>Diagnostics</strong>Opens an advanced dashboard with real-time readings of TMC drivers, board temperature sensors, and fan status."
});

window.I18N && window.I18N.add({
  // ── Missing General and Button i18n Keys ──────────────────────────────────
  "div.rotechos-brand": "RotechOS",
  "span.rotechos-e3d5": "RotechOS Pendant",
  "div.cnc-controller-0976": "CNC CONTROLLER",
  "title.temperatura-mcu-e886": "MCU Temperature",
  "span.idle-a5da": "IDLE",
  "span.g54-e11d": "PART",
  "span.mcs-e56d": "MACHINE",
  "span.mcs-e56d-ax": "MACH",
  "button.x-0-1474": "X 0",
  "button.y-0-c884": "Y 0",
  "button.z-0-d830": "Z 0",
  "button.xyz-0-37a8": "XYZ 0",
  "div.esperando-datos-6280": "Waiting for data…",
  "button.z-d5c8": "Z▲",
  "button.z-506e": "Z▼",
  "button.a-13fe": "A+",
  "div.rot-e1d9": "ROT",
  "button.a-f041": "A-",
  "h2.g-code-c814": "G-CODE",
  "button.top-a4ff": "TOP",
  "button.front-5835": "FRONT",
  "button.iso-5b51": "ISO",
  "button.3d-76aa": "3D",
  "div.progreso-de-ejecuci--79f2": "Execution progress",
  "span.running-7510": "running",
  "span.en-marcha-b135": "RUNNING",
  "placeholder.env-a-un-comando-g28-f472": "Send command (G28, M119...)",
  "div.m-quina-en-estado-er-7ebb": "Machine in ERROR state",
  "title.home-all-g28-6eb9": "Home All (G28)",
  "title.sonda-z-medir-altura-55b3": "Z Probe: measure workpiece height",
  "title.cambio-de-herramient-efe6": "Tool change (M6)",
  "title.ir-a-0-origen-de-pie-0c32": "Go to 0 (workpiece origin)",
  "title.aparcar-m-quina-en-z-8f19": "Park machine in safe zone",
  "div.spindle-rpm-c6a7": "Spindle RPM",
  // t_028bceef: etiqueta equivalente cuando el modo de cabezal es láser.
  "div.spindle-power":     "Laser power",
  "dlg.spManual.title": "SWITCH ON THE SPINDLE",
  "dlg.spManual.msg": "Manual spindle: switch it on with its own switch and wait for it to reach speed before starting. RotechOS cannot switch it on.",
  "dlg.spManual.msgResume": "Manual spindle: switch it on with its own switch and wait for it to reach speed before resuming. RotechOS cannot switch it on.",
  "msg.spManual": "Manual spindle: switch it on and off with its own switch.",
  "msg.spManualStop": "Manual spindle: it is still turning. Switch it off with its own switch.",
  "spindle.manual": "MANUAL",
  "spindle.manualDial": "RPM on the dial",
  "title.spindle-mode-manual": "Manual (Makita RT0701C): speed is set on the dial and it is switched on with its own switch. RotechOS cannot start or stop it.",
  "span.spindle-manual": "Manual",
  "span.spindle-manual-sub": "Makita, dial<br>and switch",
  "cfg.spindle.manual.hint": "Manual spindle: RotechOS cannot start or stop it. On pause, abort or after an E-STOP it will remind you to switch it off with its own switch.",
  "pendant.sp.manual": "Manual spindle: set the speed on its dial and switch it on or off with its own switch. RotechOS cannot stop it.",
  "span.override-6da8": "Override",
  "span.wcs-06c0": "WCS",
  "span.iniciar-trabajo-e250": "START JOB",
  "span.spindle-on-fe95": "TURN SPINDLE ON",
  "span.avance-47b2": "Feed Rate",
  "span.spindle-4b1b": "Spindle",
  "span.jog-shift-hint-9a3e": "SHIFT (hold) + MOVE = 25% speed",
  "span.m98-4c9a": "M98",
  "span.cfg-fdd7": "CFG",
  "title.idioma-language-949e": "Language / Idioma",
  "option.es-04c1": "ES",
  "option.en-aa85": "EN",
  "title.informaci-n-del-sist-34f8": "System Information",
  "title.restaurar-configurac-220b": "Restore factory configuration from 0:/sys/config.g.bak",
  "span.max-26a4": "MAX",
  "span.min-ce31": "MIN",
  "p.direcci-n-hacia-la-q-63b2": "Direction each axis moves when homing. Read from <code>sys/homeall.g</code> (read-only: homing is not regenerated from here).<br><strong style=\"color:var(--warn-strong)\">Important:</strong> the direction must match the side where you mounted the <em>endstop</em>. If you pick the opposite direction, the axis will travel to the mechanical stop without the firmware noticing — risk of crashing the axis into the frame. If unsure, leave it on <strong>TOWARDS +MAX</strong> (the most common direction; even so, check it on your machine before the first homing).<br><br><strong style=\"color:var(--text-1)\">What is an endstop?</strong> A sensor at each end of the axis (X/Y/Z) — inductive or microswitch, depending on your machine — that tells the firmware when the axis reaches the edge. Homing looks for that sensor.",
  "p.genera-d820": "Speeds read from sys/homeall.g (read-only)",
  "button.m119-b6b3": "READ INPUTS",
  "div.min-ce31": "MIN",
  "placeholder.d-11-51e8": "D.11",
  "option.nc-9058": "NC",
  "option.no-c2f3": "NO",
  "title.x-min-endstop-bb20": "X Min endstop",
  "div.max-26a4": "MAX",
  "placeholder.c-6-6aa2": "C.6",
  "title.x-max-endstop-8411": "X Max endstop",
  "placeholder.a-8-9205": "A.8",
  "title.y-min-endstop-ebbd": "Y Min endstop",
  "placeholder.d-14-12e8": "D.14",
  "title.y-max-endstop-c429": "Y Max endstop",
  "placeholder.c-7-8bd5": "C.7",
  "title.z-min-endstop-a171": "Z Min endstop",
  "placeholder.d-12-4dc3": "D.12",
  "title.z-max-endstop-7857": "Z Max endstop",
  "span.pwm-8449": "PWM",
  "span.se-al-0-10v-4be8": "0-10V Signal (M950 + M3 S)",
  "span.rel-fbb3": "Relay",
  "span.on-off-simple-d7cb": "Simple ON/OFF (M42 P pin)",
  "span.modbus-rs485-fa3c": "Modbus/RS485",
  "span.vfd-serie-09c1": "Serial VFD (M950 + driver)",
  // t_028bceef — 4.º modo de cabezal LÁSER (SPIN/TTL/PWM, no RPM)
  "span.l-ser-ttl": "Laser",
  "span.ttl-pwm-spd-b-1": "TTL/PWM on SPD (M950 + M3 S)",
  "placeholder.auto-9df2": "Auto",
  // ── PLACEHOLDER (no críticos) ────────────────────────────────────────────
  // Búsqueda de la lista de archivos del pendant (modo móvil).
  // Los placeholders del PIN y el nombre de máquina siguen en ES porque son
  // textos asociados a seguridad/acceso y los decide Sergi.
  "placeholder.fm.search": "Search…",
  "div.par-metros-de-palpad-afd2": "Probing parameters",
  "div.el-motor-a-se-mueve--237f": "The A motor moves synchronized with Y (Gantry configuration). Adds the A motor to your M584 line as Y{primary}:{free}, where {primary} is the current Y driver in your config.g; the X, Y and Z mapping is kept as-is. Motor parameters (current, steps/mm...) for the A axis also apply to the physical driver.",
  "div.el-eje-a-funciona-co-cc71": "The A axis operates as an independent rotary axis (typical 4th CNC axis). Adds A{free} to your M584 line in config.g, using the driver from P0 to P3 that is left unused; the X, Y and Z mapping is kept as-is. Steps/mm for the A axis are interpreted as steps/degree.",
  "div.driver-f-sico-inacti-e0ec": "Physical driver inactive. The M584 line is left with no A axis and the X, Y and Z mapping is kept as-is.",
    "div.resistencia-de-sensa-d232": "BTT Scylla V1.0 + TMC2160 — Sense resistor R0.05Ω. Including M569.9 P{n} R0.05 per driver in config.g is mandatory. Do not exceed the nominal current of your motors · Motor Voltage: 24-56 V DC.",
    "span.tmc2160-486c": "TMC2160",
    "p.pulsa-una-tarjeta-pa-b1f6": "Tap a card to invert rotation. S1 = normal · S0 = inverted.",
  "p.activo-8903": "Active: M569 P{n} D2 · omits M906 · current managed by external driver · STEP/DIR/EN signals on board pins.",
  // Fase 3.3 §10 (t_1b74ed31): aviso que se concatena al diálogo genérico de
  // reboot SOLO cuando el operario acaba de activar un driver externo
  // (mcfgExtX/Y/Z/A). El riesgo es real: si el dial hardware del driver
  // externo queda mal, el motor puede quemarse — y ese dato no estaba en el
  // diálogo genérico de reboot.
  "msg.extdrvRestartWarn": "You have activated an external driver: the firmware will omit M906 for that axis and current will be managed by the driver's hardware dial. If that dial is misconfigured, the motor can burn.",
  "p.los-pasos-50-500mm-s-2cfe": "Steps 50-500mm only apply to XY. The Z axis is limited to 10mm maximum for safety to prevent collisions.",
  "label.x-mm-798d": "X (mm)",
  "label.y-mm-ec51": "Y (mm)",
  "label.z-mm-30db": "Z (mm)",
  "label.a-mm-025d": "A (mm)",
  "p.0-velocidad-del-movi-da63": "0 = current movement speed",
  "div.apoya-un-3edd": "How to measure backlash: Rest a dial indicator against the table or tool. Move the axis 10 mm in one direction, record the reading. Move 10 mm in the opposite direction and return to the starting point. The difference between the expected and actual position is the backlash. Repeat 3 times and average.",
  "div.cnc-controller-a91d": "CNC Controller",
  "cfg.about.version": "Version",
  "div.interface-87c2": "Interface & Customization",
  "div.2026-rotech-a317": "© 2026 Rotech",
  "div.software-719d": "Software",
  "div.rotechos-2026-rotech-e371": "RotechOS · © 2026 Rotech",
  "div.licencia-gplv3-basad-dcbf": "GPLv3 License · Based on Duet Web Control © Duet3D Ltd · GPLv3",
  "span.licensed-under-gpl-v-a60f": "Licensed under GPL v3",
  "div.mantenimiento-diagn--945b": "Maintenance / Diagnostics",
  "button.calentar-husillo-ram-ceda": "HEAT SPINDLE",
  "button.diagn-stico-del-sist-e626": "DIAGNOSTICS",
  "div.cada-estado-de-la-m-ceb0": "Each machine state has a fixed color and animation designed for maximum visual clarity in industrial environments.",
  "th.estado-3397": "State",
  "th.color-cb5f": "Color",
  "th.animaci-3ac5": "Animation",
  "th.prop-65b8": "Meaning",
  "td.idle-a5da": "IDLE",
  "td.azul-gris-f80c": "Slate Blue",
  "td.respiraci-4d90": "Deep breathing",
  "td.energizado-inactivo--104a": "Energized, inactive. Fades into the environment",
  "td.listo-81c3": "READY",
  "td.verde-14e6": "Green",
  "td.fade-in-4f5f": "Fade-in → static",
  "td.referenciado-s-7af6": "Referenced, solid and reliable",
  "td.en-marcha-b135": "RUNNING",
  "td.azul-582d": "Blue",
  "td.luz-fija-de-trabajo-fc2d": "Steady work light",
  "td.sin-animaci-b027": "No animation. Illuminates without fatigue",
  "td.pausado-d281": "PAUSED",
  "td.naranja-2d06": "Orange",
  "td.latido-suave-cee8": "Soft beat",
  "td.precauci-4bec": "Polite caution, stress-free",
  "td.error-bb1c": "ERROR",
  "td.rojo-puro-5ab3": "Pure red",
  "td.pulso-1-hz-b5bd": "Pulse 1 Hz",
  "td.nico-al-100-alarma-c-be46": "100% duty. Critical E-Stop alarm",
  "div.pin-ab6d": "Pin: PD6 (RRF: D.6) — 25 WS2812b LEDs. Animations are sent from the interface via M150. Colors and animations are linked to the machine state (industrial color psychology). Use Save to persist brightness configuration.",
  "div.gu-c931": "Quick guide to what is happening when each LED pattern appears.",
  "th.significado-operativ-c1a1": "Operational meaning",
  "td.sistema-energizado-e-9972": "System energized in standby (IDLE).",
  "td.quina-lista-y-refere-ab76": "Machine ready and referenced (READY).",
  "td.trabajo-activo-sin-d-54d6": "Active job without distractions (RUNNING).",
  "td.proceso-detenido-en--6a48": "Process stopped waiting for action (PAUSED).",
  "td.alarma-o-error-cr-4da8": "Alarm or critical error (ERROR).",
  "td.flash-verde-600-ms-c1b7": "Green flash 600 ms",
  "td.final-de-carrera-act-9c38": "Limit switch activated (rising edge).",
  "td.llenado-progresivo-s-41a0": "Smooth progressive fill",
  "td.home-all-g28-en-curs-d9a7": "Home all / G28 in progress, with confirmation at completion.",
  "td.convergencia-atenuad-ab83": "Attenuated convergence",
  "td.macro-ir-a-0-en-ejec-c2ce": "Macro Go to workpiece origin running.",
  "td.apagado-org-cc3c": "Organic shut down",
  "td.macro-aparcar-en-eje-76d0": "Macro Park (safe zone) running.",
  "td.xel-de-sondeo-21f0": "Probing pixel",
  "td.medici-4c14": "Z measurement (sonda_Z) and contact trigger.",
  "td.estela-lenta-5131": "Slow trail",
  "td.palpador-3d-g29-en-m-7cc7": "3D probe / G29 surface mapping.",
  "td.transici-39a2": "Thermal transition",
  "td.warm-up-de-spindle-s-b097": "Spindle warm-up (if called by macro).",
  "td.pulso-naranja-f6f2": "Orange pulse",
  "td.cambio-de-herramient-9974": "Tool change (M6 / toolchange).",
  "td.amanecer-11f7": "Sunrise",
  "td.finalizaci-4ea1": "Successful job completion (M30 / job completed).",
  "p.exporta-todos-los-ar-6b02": "Exports all files from 0:/sys/ and 0:/macros/ as a ZIP archive. To restore, upload the ZIP using the panel below.",
  "span.mcs-000-000-5488": "MACH 000.000",
  "button.x-0-44b1": "X 0",
  "button.y-0-59f0": "Y 0",
  "button.z-0-77df": "Z 0",
  "button.xyz-0-69a1": "XYZ 0",
  "div.cargando-archivos-6cd3": "Loading files…",
  "span.mm-min-46e1": "mm/min",
  "span.rpm-fe22": "RPM",
  "pendant.viz.toggle": "PATH",
  "pendant.nav.dash.school": "Pantalla principal: estado de la máquina, controles rápidos y posición actual.",
  "pendant.nav.wcs.school": "Establecer el cero de pieza en X, Y o Z. Toca X 0 / Y 0 / Z 0 después de tocar la pieza con la herramienta.",
  "pendant.nav.jog.school": "Mover la herramienta paso a paso. Elige distancia (0.1, 1, 10, 50 mm) y luego toca las flechas del eje.",
  "pendant.nav.run.school": "Cargar un archivo G-code, iniciar, pausar o cancelar el trabajo. Mantén el botón rojo CANCELAR a mano.",
  "pendant.nav.macros.school": "Ejecutar macros guardadas: homing, calibración, cambios de herramienta. Lista de 56 macros disponibles.",
  // (t_73119cd8) "CANCEL" junto a PARO confundía: ¿cancela qué? Es la
  // parada limpia de TRABAJO (M25+M0). El sufijo "JOB" lo aclara.
  "button.parar-ab78": "ABORT JOB",
  "div.cargando-4042": "Loading…",
  "div.mensaje-del-sistema-7c28": "SYSTEM MESSAGE",
  "button.cancelar-ea78": "CANCEL",
  "button.continuar-a89f": "CONTINUE",
  "div.final-de-carrera-act-241e": "Limit switch active",
  "div.trabajo-pausado-y-sp-86ed": "Job paused and spindle stopped. Physically release the sensor before continuing.",
  "button.paro-2948": "E-STOP",
  "title.paro-de-emergencia-m-df69": "Emergency Stop (M112)",
  "aria-label.paro-de-emergencia-3105": "Emergency Stop",
  "jobsum.title": "Job Completed",
  "jobsum.sub": "Job Summary",
  "jobsum.file": "File",
  "jobsum.dur": "Duration",
  "jobsum.end": "Finished",
  "jobsum.close": "Close",

  // ── ZCAL / Wasteboard Z-Calibration Assistant ──────────────────────────────
  "zcal.title": "Calibrate Z Sensor (spoilerboard)",
  "zcal.step1.desc": "Measure the distance between the <b>fixed sensor trigger</b> and the <b>spoilerboard surface</b> (<code>z_sensor_to_table</code>).",
  "zcal.step1.li1": "Insert the endmill you <b>use the most</b> (trigger point varies slightly by tool).",
  "zcal.step1.li2": "Axes must be referenced (homing completed).",
  "zcal.homing.warn": "Perform <b>homing (G28)</b> first: probing requires machine coordinates.",
  "zcal.btn.probe": "Probe sensor ▸",
  "zcal.step2.desc": "Step 1/2 — Probing the fixed sensor…",
  "zcal.btn.next": "Next ▸",
  "zcal.step3.desc": "Step 2/2 — Lower the tool over the <b>SPOILERBOARD</b> (not the sensor) until a piece of paper drags with light friction.",
  "zcal.step3.zmachine": "Machine Z:",
  "zcal.btn.paper": "Paper drags",
  "zcal.step4.desc": "Measured distance (sensor → bed):",
  "zcal.step4.hint": "Will be saved as <code>z_sensor_to_table</code> in config.g and applied immediately.",
  "zcal.btn.discard": "Discard",
  "zcal.cancel": "Cancel",
  "zcal.btn.open": "Calibrate with wizard",

  // ── ZCAL JS dynamic messages ──────────────────────────────────────────────
  "zcal.msg.homeRequired": "Perform homing (G28) before calibrating",
  "zcal.msg.probingSensor": "Probing sensor…",
  "zcal.msg.probeError": "Probing error. Check the sensor.",
  "zcal.msg.readError": "Could not read trigger height (probe_trigger_z).",
  "zcal.msg.sensorTriggered": "Sensor trigger:",
  "zcal.msg.mmMachine": "mm (machine) ✓",
  "zcal.msg.readZMachineError": "Could not read machine Z coordinate",

  // ── Languages ─────────────────────────────────────────────────────────────
  // wlc.langES / wlc.langEN y wlc.next viven en rotechos-i18n.js:39,41,42.
  // t_c4601972 (camino-novato H2) ya está cerrado: la línea 2420 de index.html
  // tiene el botón Siguiente del paso 1. La redefinición previa de wlc.next
  // aquí como "Next →" pisaba "Next" y rompía e2e-novato-welcome-textos.spec.js:354
  // (el test busca getByRole('button', { name: 'Next', exact: true })).
  "wlc.langES": "Spanish",
  "wlc.langEN": "English",
});

window.I18N && window.I18N.add({
  "msg.slowConnection": "Slow connection to the CNC — reboot the router or move it closer",
  "msg.telemetryDelayed": "position feedback is delayed; move the router closer to the CNC or reboot the router if it persists",
  "msg.overtemperature": "Overtemperature",
  "msg.powerFailure": "Power failure",
  "msg.requiresM999": "requires M999",
  "msg.overtemperatureUpper": "OVERTEMPERATURE",
  "msg.powerFailureUpper": "POWER FAILURE",
  "msg.rebootRequired": "reboot required",
  "msg.bordLogCancelled": "CONTOUR — Cancelled by user",
  "msg.bordCompleted": "Perimeter check completed ✓ — Place clamps outside the perimeter",
  "msg.bordLogCompleted": "CONTOUR — Path completed",
  "msg.bordLogErr": "CONTOUR — Error during path execution",
  "msg.zBabystepping": "Z Micro-adjust",
  "msg.macroCancelEnviada": "Cancel of \"${name}\" sent — checking that it stops…",
  "msg.babystepMax": "Z fine adjust during a job: max ${max} mm per press",
  "msg.macroEnCurso": "A macro is running: wait for it to end, or stop it with STOP or the E-stop button",
  "msg.m25EnCambioHerramienta": "Tool change in progress: stopping now would wait behind it. To stop NOW, use STOP or the E-stop button.",
  "msg.noReanudar": "NOT resuming: ${motivo}. Cancel the job with STOP and home again.",
  "msg.pausaConDialogo": "A firmware prompt is waiting: answer it first. To stop now, use STOP or the E-stop button.",
  "msg.macroDetenida": "Macro \"${name}\" stopped",
  "msg.macroSigue": "Macro \"${name}\" may still be running: press STOP or use the E-stop button",
  "msg.restoreFactoryLog": "Restore to defaults → config.g.bak applied",
  "msg.saveConfigErr": "Error saving config.g — ",
  "msg.softLimitCompare": "the minimum",
  "msg.softLimitMustBeLess": "must be LESS than the maximum",
  "msg.current": "Current",
  "msg.currentWarnBody": "watch motor and driver temperature",
  "msg.enabled": "enabled",
  "msg.disabledUpper": "DISABLED",
  "msg.enabledPlural": "enabled",
  "msg.disabledUpperPlural": "DISABLED",
  "msg.softLimitsDisableTitle": "Disable soft limits",
  "msg.softLimitsDisableBody": "You are about to <strong>disable soft limits</strong>. From now on the machine can move outside the work area and <strong>crash into the endstops</strong>.<br><br>Do you confirm this is what you want to do?",
  // t_b68324ca (sep-2026): el operario intenta guardar la pestaña Referenciar
  // sin haber elegido un orden de homing, y el homeall.g actual no tiene marca
  // "; Orden:" (versión antigua o desconocido). Sin esta elección, persistir
  // "Z primero" por defecto pisaría el orden real con uno que la propia UI
  // declara no-detectable. La consecuencia potencial es un pórtico bajo que
  // ejecuta G28 XY antes de subir Z → choque contra la herramienta.
  // t_b68324ca: el botón "Descargar backup" se desactiva cuando /sys y /macros
  // no devuelven archivos. Si el usuario llega por re-render / cambio de pestaña
  // y el array está vacío, abortamos en lugar de descargar un ZIP con sólo
  // metadata.json. El toast explica por qué.
  "msg.backupNoFiles": "No files to back up — click the Backup tab again to re-scan.",
  // t_b68324ca: estado intermedio mientras rr_filelist está en vuelo.
  "msg.loading": "Loading…",
  "msg.guardando": "Saving…",
  "aria.cfg.extdrv.x": "External driver X",
  "aria.cfg.extdrv.y": "External driver Y",
  "aria.cfg.extdrv.z": "External driver Z",
  "msg.tmcLimitWarn": "exceeds the TMC2160 RMS limit on this board (3100 mA with R0.05Ω)",
  "msg.external": "External",
  "msg.savedToSD": "Saved to SD, but",
  "msg.commandsNotHotApplied": "command(s) were NOT hot-applied — the firmware refuses that change without a restart (typically M584 or M569). Restart the machine NOW from the top bar (REINICIAR button) or from the REBOOT pill in SETTINGS → General. If you keep working without restarting, that change will NOT be active.",
  "msg.savedSfx": "Saved",
  "msg.uploadedSfx": "uploaded",
  "msg.uploadErrorPfx": "Error uploading",
  "msg.notificationsBlocked": "Notifications blocked by the browser — to enable them, click the lock/truck icon to the left of the URL, find \"Notifications\" or \"Permissions\" and set RotechOS to \"Allow\". Then re-check the checkbox and reload the page (F5). Until you do, the app will not alert you when a job finishes.",
  // FIX C4EF (carril-3, 2026-08-15): toasts de write-temp + rename atómico
  // para subidas de interfaz.rotechos-fm.js:atomicUpload.
  "msg.atomicUploadTmpFail":   "Upload to temporary file failed — the original file on the SD was NOT touched. Check the connection and try again.",
  "msg.atomicUploadFinalFail": "Final upload failed — a temporary copy was left on the SD as a rescue. You can rename it from the file manager or retry the upload.",
  "msg.savedSfxUpper": "saved",
  "dlg.spindleWarmup.title": "Warm up spindle",
  "dlg.spindleWarmup.msg": "This STARTS the spindle and ramps it up from 8,000 to 24,000 RPM (~1 min) to warm up the bearings. The cutter will SPIN at high speed for one minute. Before starting, step away from the cutter, keep the area clear, and DO NOT bring your hands close until the ramp has finished and the spindle has stopped. Start?",
  "msg.warmupStarted": "Warmup started…",
  "msg.warmupErr": "Error launching spindle_warmup.g",
  "dlg.upload.title": "Upload",
  "dlg.upload.fileSfx": "file",
  "dlg.upload.pluralSfx": "s",
  "dlg.upload.msg": "Will be uploaded to the machine's SD card",
  "dlg.upload.overwrite": "Existing files will be overwritten.",
  "msg.limitSwitch": "Limit Switch",
  "msg.axis": "Axis",
  "msg.softLimitBody": "The machine has reached a software limit and has paused automatically.<br>Verify that coordinates do not exceed the work area.",
  "msg.limitSwitchPre": "The limit switch of",
  "msg.limitSwitchPost": "axis has triggered during execution.<br>The machine has paused automatically. Check for collision.",
  "msg.limitSwitchAction": "Press <strong>Resume</strong> to continue the job or <strong>Cancel</strong> to abort it."
});

window.I18N && window.I18N.add({
  "dlg.removeRunningJob.title": "Remove running job",
  "dlg.removeRunningJob.msg": "<p style=\"color:var(--red)\"><b>WARNING — the cut will be cancelled.</b></p><p>You are about to <b>cancel the running cut</b>: it stops, the spindle turns off and Z goes up. The file is <b>unloaded from the viewer</b> but <b>stays on the SD card</b>, so you can load it again.</p><p>If you only want to stop for a moment, press <b>Cancel</b> here and use <b>PAUSE</b>.</p><p>Cancel the job?</p>",
  "dlg.removePausedJob.title": "Remove paused job",
  "dlg.removePausedJob.msg": "<p style=\"color:var(--red)\"><b>WARNING — the cut will be cancelled.</b></p><p>The cut is <b>PAUSED</b>. You are about to <b>cancel it</b>: it cannot be resumed. The file is <b>unloaded from the viewer</b> but <b>stays on the SD card</b>, so you can load it again.</p><p>If you want to continue from where it stopped, press <b>Cancel</b> here and then <b>RESUME</b>.</p><p>Cancel the job?</p>",
  "dlg.unsavedClose.title": "Unsaved changes",
  "dlg.unsavedClose.msg": "You have unsaved changes in",
  "dlg.unsavedClose.q": "Close anyway and discard them?",
  "msg.jobCancelledAndRemoved": "Job cancelled and file removed",
  "msg.fileUnloaded": "File unloaded",
  "msg.pathLoaded": "Path loaded:",
  "msg.pathProcessErr": "Could not process path of",
  "msg.pathBoundsOver":       "Path out of bounds:",
  "msg.pathBoundsOverSide":   "{axis} exceeds {side} by {overflow} mm",
  "msg.pathBoundsUnknown":    "Machine limits not available — could not verify whether the path fits",
  "msg.pathBoundsDisclaimer": "macros / WCS / tool changes can shift the real path; the warning only inspects the file",
  "msg.errorIn": "Error in",
  "msg.loadingPfx": "Loading",
  "msg.cantDeleteRunning": "Cannot delete while job is running",
  "msg.deletedSfx": "deleted",
  "msg.deleteErr": "Error deleting file",
  "msg.listUpdated": "List updated",
  "msg.cantUploadDuringJob": "Cannot upload files during a job",
  "msg.nameSanitized": "Name sanitized →",
  "msg.noFileName": "Missing file name — tap the folder icon above to pick a .g from the SD before Save",
  "msg.loadFailedSaveLocked": "Could not read the file from the SD — save is blocked to avoid overwriting it; close this editor, reopen the file from the folder icon, and try again",
  "msg.error": "Error",
  "dlg.largeJog.title": "Large movement",
  "dlg.largeJog.msg": "You are about to move axis",
  "dlg.largeJog.clear": "Make sure there is no collision.",
  "dlg.largeJog.confirm": "Continue?",
  // NV-01 (13-sep): aviso de paso grande sin recorte. Solo informa.
  "dlg.largeJog.sinLimitesOff": "Travel limits are disabled: this move will not be clipped.",
  "dlg.largeJog.sinLimitesDesconocidos": "The travel limits of this axis are not known yet: this move will not be clipped."
});

// ── Strings dinámicos ───────────────────────────────────────────────────────
// Aquí vivían 21 claves de un módulo WIFI (pestaña RED) que NUNCA se cableó:
// escaneo de redes, chip de estado, banner AP y diálogo de guardar red. No
// existía ni el HTML ni el JS que las consumiera, así que el gate de i18n las
// reportaba como huérfanas en cada sprint. Retiradas el 2026-08-01 por decisión
// de Sergi (HUER-3 §3.2.a opción A). Los textos EN están en el historial de git
// si algún día se rescata el módulo. Lo que SÍ está vivo del WiFi es otra cosa
// y vive en rotechos-i18n-config.js: msg.wifiApFail/wifiApOk (toasts de
// rotechos-modules.js:228,232) y dlg.wifiAp.* (líneas 186-187) — NO tocar.
window.I18N && window.I18N.add({
  // ── Asistente de primer arranque (12 pasos) ──────────────────────────────
  // Antes no existia NINGUNA clave wiz.*: el asistente entero salia en
  // espanol con setLang("en"). t() no interpola: las partes variables
  // (paso, eje, medidas) se concatenan fuera de la clave.
  "wiz.step": "Step",
  "wiz.btn.finish": "Finish ✓",
  "wiz.btn.next": "Next →",
  "wiz.s1.h": "Welcome to RotechOS",
  "wiz.s1.p": "This wizard guides you step by step through setting up your CNC router for the first time. Most setups finish in a few minutes, though the M92 calibration step can take longer if you need to measure with a caliper.",
  "wiz.s1.hint": "You can press <strong>Skip step</strong> at any time, or close the wizard and resume later.",
  "wiz.s2.h": "Controller connection test",
  "wiz.s2.p": "Checking communication with RepRapFirmware...",
  "wiz.s2.wait": "Waiting for a response...",
  "wiz.s2.ok": "RRF online and responding correctly",
  "wiz.s2.ko": "No response from RRF — check USB cable / network",
  "wiz.s2.neterr": "Network error:",
  "wiz.s3.h": "Machine identity",
  "wiz.s3.p": "Give this machine a name to identify it on the local network.",
  "wiz.s3.name": "Name",
  "wiz.s3.hint": "Applied with <code>M550 P\"&lt;name&gt;\"</code>. Changing it needs a reboot for mDNS to pick it up.",
  "wiz.s4.h": "Network connection",
  "wiz.s4.p": "If the machine runs on wired Ethernet, skip this step. Otherwise set SSID and password.",
  "wiz.s4.detect": "Detecting interface type...",
  "wiz.s4.wifiDetected": "WiFi interface detected.",
  "wiz.s4.ethDetected": "Ethernet interface detected.",
  "wiz.s4.ethTitle": "Wired connection active",
  "wiz.s4.ethIp": "IP address:",
  "wiz.s4.ethHint": "No WiFi credentials required. Press Next to continue.",
  "wiz.s4.ethLog": "Wizard Ethernet: IP ${ip}, no credentials to send",
  "wiz.s4.indetDetected": "Could not determine the interface type. Showing network options.",
  "wiz.s4.pwd": "Password",
  "wiz.s4.ssid": "SSID (your WiFi network name)",
  "wiz.s4.ssidph": "My WiFi network",
  "wiz.s4.ssidHint": "What's your home WiFi network name? It is the one shown in your phone or laptop network list (the \"SSID\").",
  "wiz.s4.pwdHint": "Same password you type to connect your phone to that WiFi. It is stored in the controller, not sent over the Internet.",
  "wiz.s4.m587hintBody": "Stores the WiFi name and password in the controller's memory (M587). The machine will join that network on the next reboot.",
  "wiz.s4.indetHelp": "If you are using a wired Ethernet cable, leave the fields empty and press Next. If you want WiFi, fill them in below.",
  "wiz.s4.errTitle": "WiFi connection failed",
  "wiz.s4.errBody": "Could not connect to \"${ssid}\" after 12s. The WiFi network \"RotechOS\" (AP) is still active, so the machine is reachable. Check the SSID spelling, the password, and that the router is in range. Click Retry without re-typing.",
  "wiz.s4.retry": "Retry",
  "wiz.s5.h": "Motor test",
  "wiz.s5.p": "Press each button to move the axis 10mm slowly. Confirm every axis moves in the right direction.",
  "wiz.s5.hint": "If an axis runs backwards, swap S0↔S1 for that driver on the Motors tab.",
  "wiz.s6.h": "Endstop check",
  "wiz.s6.p": "Trigger each sensor by hand and watch the state on the main panel (X/Y/Z indicators). When all of them respond, press next.",
  "wiz.s6.hint": "You can run <code>M119</code> in the console to read the state as text.",
  // (t_73119cd8) "Run M119" era un código, no una acción. El operario quiere
  // saber el estado de las entradas; la acción es eso, no el comando M119.
  "wiz.s6.btn": "Read inputs",
  "wiz.s7.h": "Initial homing",
  "wiz.s7.p": "Run G28 to home every axis: each axis will move to its physical stop to find the origin. Before pressing the button, make sure the work area is clear.",
  "wiz.s7.warn": "⚠ Before continuing: remove hands, tools and loose parts from the axis travel path. Keep your hand near the red emergency (E-STOP) button on the UI while the machine moves. If anything touches or jams, press E-STOP immediately.",
  "wiz.s7.btn": "Run G28 (HOME)",
  "wiz.s7.busy": "Homing in progress...",
  "wiz.s7.ok": "Homing started",
  "wiz.s7.ko": "Could not start G28",
  "wiz.s8.h": "Work area (software limits)",
  "wiz.s8.p": "Usable travel of YOUR machine from the origin. The software will not allow moves outside this area (M208).",
  "wiz.s8.z": "Z travel (mm)",
  "wiz.s8.zHint": "Measure vertical travel with the probe down. Z0 on top, Z-115 at the bottom (RRF convention). Always enter the travel as a POSITIVE number; the software stores it as negative (M208). Factory example: X530, Y830, Z115 → X 0..530, Y 0..830, Z -115..0 mm.",
  "wiz.s8.btn": "Apply area",
  // t_c2d89697 (2026-09-07) E1: la pestaña cambió de «TRAVEL LIMITS» a
  // «SOFT LIMITS» para caber en la sidebar (136 px). Mantener el
  // tutorial sincronizado con el nombre real.
  "wiz.s8.hint": "Measure the real travel of each axis (stop to stop, minus a safety margin). If jog blocks before the stop while measuring, turn Software Limits off temporarily (SOFT LIMITS tab) and back on when done.",
  "wiz.s8.ok": "Area applied and persisted:",
  "wiz.s9.h": "Steps/mm calibration (M92)",
  "wiz.s9.p": "Every axis has a configured steps-per-mm value (M92) that tells it how far to move for every millimetre requested. If your cuts come out slightly larger or smaller than your design software expected, measure and re-tune here. The spindle does NOT run during calibration.",
  "wiz.s9.sel": "1) Select an axis",
  "wiz.s9.dist": "Distance to move (mm)",
  "wiz.s9.distHint": "Set the mm to move first. The default is 100 mm. Measure with a caliper how far the axis ACTUALLY moves and note it: you will use it in step 3.",
  "wiz.s9.move": "2) Move",
  "wiz.s9.real": "ACTUAL distance measured with a caliper (mm)",
  "wiz.s9.realph": "how far it actually moved",
  "wiz.s9.apply": "3) Compute and apply",
  "wiz.s9.hint": "Check the axis has clear travel before moving. After calibrating, HOME again.",
  "wiz.s9.selected": "Selected axis:",
  "wiz.s9.okSfx": "steps/mm · applied and saved to config.g ✓",
  "wiz.s9.ko": "Could not apply the new value.",
  // B1-03 (acta B1 2026-09-06): aviso inline bajo el input "real" del
  // paso 9 del wizard. Sin calibre, cualquier valor tecleado se persiste
  // como pasos/mm y la máquina se mueve la mitad o el doble de lo
  // pedido. El aviso es explícito: "no pulses Aplicar si no has
  // medido". Si no tienes calibre a mano, el operario puede omitir el
  // paso y volver más tarde.
  "wiz.s9.realWarn":    "Measure the actual travel with a caliper.",
  "wiz.s9.realWarnSfx": "Without a reliable measurement, do not press \"Compute and apply\": the value will be saved to config.g and the machine will move wrong. If you don't have a caliper to hand, press \"Skip step\" above and come back later.",
  // B1-03 (acta B1 2026-09-06): confirmDialog antes de aplicar M92. La
  // pregunta honesta al operario: "¿has medido con calibre?". Sin
  // medida, no debe pulsar Sí. El wizard sigue avanzando al Cancelar.
  "dlg.wizCal.title":   "Calibrate steps/mm of axis {axis}",
  "dlg.wizCal.l1":      "You are about to recompute and save the steps/mm for axis {axis} to config.g. The machine will move differently from now on.",
  "dlg.wizCal.l2":      "Have you measured the ACTUAL distance with a caliper?",
  "dlg.wizCal.l3":      "If you have not measured or you are unsure, press Cancel, leave the \"ACTUAL distance\" field empty, and press \"Skip step\" above. Come back when you have a caliper to hand.",
  "dlg.wizCal.confirm": "Yes, I measured with a caliper",
  "wiz.s10.h": "Z probe test",
  "wiz.s10.p": "The probe goes to the fixed button and sets Z=0 at the table plus the material thickness set in PROBE Z. Clear path and hands away before running it.",
  "wiz.s10.btn": "Run sonda_Z.g",
  "wiz.s11.h": "Spindle test",
  "wiz.s11.p": "Run the spindle at 6000 RPM for 3 seconds. Confirm rotation and direction before continuing.",
  "wiz.s11.warn": "⚠ Before starting: make sure the cutter is free of material, hands and tools, and that the work area is clear. If you see or hear anything wrong during the 3-second test, press Stop immediately.",
  "wiz.s11.on": "Run 3s at 6000 RPM",
  "wiz.s11.off": "Stop",
  // t_c4601972 (camino-novato H3): copy honesto + CTA al HOME ALL
  "wiz.s12.h": "Initial setup complete",
  "wiz.s12.p": "You have finished the initial setup. Before cutting, press <strong>HOME ALL</strong> on the cockpit top bar (or run G28) and set the workpiece origin (X=0, Y=0, Z=0).",
  "wiz.s12.hint": "You can relaunch this wizard from the <strong>FIRST SETUP</strong> tab at any time.",
  "wiz.s12.pinTitle": "HTTP PIN (optional)",
  "wiz.s12.pinDesc": "Optional HTTP password to prevent casual access to the interface. It is NOT encryption: the PIN travels over plain HTTP. If you enable it, the browser's red stop button sits behind the login — use a physical E-stop mushroom or the firmware shield if you have an emergency before signing in.",
  "wiz.s12.pinPh": "PIN (optional)",
  "wiz.s12.pinCfm": "repeat the PIN",
  "wiz.s12.pinSave": "Save PIN and finish",
  "wiz.s12.pinRemove": "Remove PIN and finish",
  "wiz.s12.pinSkip": "Skip and finish without a PIN",
  "wiz.title.1": "Welcome",
  "wiz.title.2": "Connection",
  "wiz.title.3": "Identity",
  "wiz.title.4": "WiFi",
  "wiz.title.5": "Motor test",
  "wiz.title.6": "Endstops",
  "wiz.title.7": "Homing",
  "wiz.title.8": "Work area",
  "wiz.title.9": "Steps calibration",
  "wiz.title.10": "Z probe",
  "wiz.title.11": "Spindle",
  "wiz.title.12": "Done",

  // ── ARIA-LABEL — Modales secundarios (file editor / macros / viz3d / GC) — M-M02 a11y ──
  // H-CFG-11 auditoría UI 2026-08-14: inputs de modales file editor, newMacro,
  // gcEditor, viz3d y fm sin programmatic name. Aquí solo las traducciones EN
  // que data-i18n-aria-label resuelve cuando I18N.locale='en'.
  "aria.fm.tvFiles.fileInput":  "Upload G-code file to the SD server",
  "aria.fm.fileEditor.area":    "G-code file editor",
  "aria.fm.fileInput":          "Upload G-code files to the SD server from the file manager",
  "aria.fm.newMacro.name":      "Human-readable macro name",
  "aria.fm.newMacro.file":      "SD file name for the macro",
  "aria.fm.newMacro.code":      "Macro G-code body",
  "aria.cfg.viz3d.file":        "Load G-code file to preview its 3D trajectory",
  "aria.cfg.viz3d.g0Opacity":   "G0 (rapid) trajectory opacity in the 3D viewer (0 invisible, 100 opaque)",
  "title.cfg.viz3d.g0Opacity":  "G0 (rapid) trajectory opacity in the 3D viewer (0 invisible, 100 opaque)",
  "aria.cfg.viz3d.g1Opacity":   "G1 (cut) trajectory opacity in the 3D viewer (0 invisible, 100 opaque)",
  "title.cfg.viz3d.g1Opacity":  "G1 (cut) trajectory opacity in the 3D viewer (0 invisible, 100 opaque)",

  // ── t_442c9a8b (2026-08-17): traducciones EN para los 11 toasts críticos
  // añadidos por cambios sin commitear del repo principal (rotechos.js,
  // rotechos-config-modal.js, rotechos-poll.js). El gate de i18n (scripts/
  // i18n_check.py) bloqueaba porque faltaban estas claves de seguridad
  // (msg.*): el operario vería el fallback ES en toasts de paro, soft-limit,
  // rampa spindle, jog feed, brillo LED, toggle SEDA/RAYO, guardar PIN/about
  // y conexión inestable. t() NO interpola: las partes dinámicas (eje, valor,
  // estado) se concatenan en el call site (mismo patrón que msg.zLimitWarn).
  "msg.kinToggleBlocked":       "Cannot switch SEDA/RAYO while the machine is ${state}. Stop the job first.",
  "msg.softLimitVacioNo":       "Soft limit: fields ${fields} cannot be empty. To disable the axis limit, delete it from config-machine.g using the file editor.",
  // FIX Fase 4.4 (carril 4): validación min<max al guardar (hallazgo F
  // matriz-coherencia 2026-09-01). El operario podía teclear X min=600 /
  // max=500 y el botón Guardar aceptaba el soft limit invertido — M208
  // con min >= max NO protege el eje (cualquier movimiento aborta). Z es
  // el caso caro: signo invertido baja la fresa contra la mesa.
  "msg.softLimitInvRangeX":     "Soft limit X: the minimum (${min}) must be LESS than the maximum (${max}). M208 with min \u2265 max does not protect the axis.",
  "msg.softLimitInvRangeY":     "Soft limit Y: the minimum (${min}) must be LESS than the maximum (${max}). M208 with min \u2265 max does not protect the axis.",
  "msg.softLimitInvRangeZ":     "Soft limit Z: the minimum (${min}) must be LESS than the maximum (${max}). M208 with min \u2265 max does not protect the axis (and inverted sign drives the cutter into the bed).",
  // FIX Fase 4.4: confirmar si la posición actual queda fuera del nuevo
  // rango. El siguiente jog aborta con "outside soft limit" sin contexto,
  // y el operario no entiende por qué.
  "msg.softLimitPosOutTitle":   "Current position falls outside the new range",
  "msg.softLimitPosOutBody":    "If you save, the machine will not be able to move until you run HOME again.\n\n${axes}\n\nSave anyway?",
  // t_080e0a9d (Fase 4.4 resto, 2026-09-02): texto bajo el SVG del volumen
  // cuando AppState.cache.machinePos aún no se ha rellenado (mock-server o
  // primer poll). Se pinta en slvPosText por renderSoftLimitsVolume.
  "slv.noPos":                 "Current position not yet read (waiting for first poll)",
  "msg.rampSpindleClampeadoA":  "Spindle ramp ${ramp}s out of range, clamped to 60s (safety cap)",
  "msg.guardarPinUsarBoton":    "PIN: use the \"Define / change PIN\" button — not the generic Save.",
  "msg.guardarAboutUsarBoton":  "Machine name: use the dedicated \"Save name\" button — not the generic Save.",
  "msg.guardarEstaPestañaNo":   "This tab has no generic Save button — it uses its own dedicated save controls.",
  "msg.jogFeedInvalido":        "Jog feed ${id} must be > 0 (got ${raw}); restored to ${def}",
  "msg.jogFeedClampeadoA":      "Jog feed ${id} too high (${v}); clamped to 20000 mm/min",
  "msg.ledBrilloInvalido":      "LED brightness invalid, restored to 128",
  "msg.ledBrilloClampeadoA":    "LED brightness ${bright} out of range (1–255), clamped to 255",
  "msg.connInstable":           "Unstable connection — retrying…",
  "msg.connReintentando":       "Retrying connection…",
  "msg.conectado":              "Connected",
  "msg.porQue.sinArchivo":      "No file loaded. Open FILES and pick a G-code.",
  "msg.porQue.noListo":         "The machine is not ready to cut yet. Check the status above.",
  "msg.porQue.spindle":         "The spindle can't be used right now. Check the machine status.",
  "msg.porQue.sinConexion":     "No connection to the machine. Check the cable or the WiFi.",
  "msg.porQue.generico":        "This action is not available right now.",

  // ── WiFi de la máquina (CONFIGURACIÓN → Red y banner de la red propia), 6-oct ──
  "cfg.wifi.st.unknown": "Could not read the network state.",
  "cfg.wifi.st.ap": "Now: own RotechOS network (http://192.168.1.1).",
  "cfg.wifi.st.client": "Now: connected to \u00ab${ssid}\u00bb, IP ${ip}.",
  "cfg.wifi.st.none": "Now: no network (${state}).",
  "dlg.wifiApOnly.title": "Work on the own network",
  "dlg.wifiApOnly.msg": "The machine will leave your WiFi and create its <strong>RotechOS</strong> network. This screen will lose the connection.<br><br>1. Connect this device to the RotechOS network (factory password <code>rotechos</code>).<br>2. Open <code>http://192.168.1.1</code>.<br><br>From now on it will always start that way.",
  "msg.wifiModoNoGuardado": "The network change could not be saved. Nothing has been changed.",
  "msg.wifiApOnlyOn": "The machine will always work on its RotechOS network (http://192.168.1.1).",
  "msg.wifiApOnlyOff": "From the next start-up the machine will look for your WiFi first. To change now, press \u00abUse my WiFi\u00bb.",
  "msg.wifiSsidVacio": "Enter the name of your WiFi network.",
  "dlg.wifiJoin.title": "Connect to your WiFi",
  "msg.wifiJoinEnviado": "Joining \u00ab${ssid}\u00bb. Connect this device to that network.",
  "msg.wifiApStay": "The machine will always work on its RotechOS network. You can change it in CONFIGURATION \u2192 Network.",
  "msg.wifiApStayNoGuardado": "You are still on the RotechOS network, but it could not be saved for the next start-ups. Repeat it from CONFIGURATION \u2192 Network.",
});
