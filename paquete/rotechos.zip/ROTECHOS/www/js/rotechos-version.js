/* ---
 * rotechos-version.js — Información de versión embebida
 *
 * Este módulo expone constantes que cualquier otra parte de la app puede
 * consultar para saber qué build está corriendo. Es la única fuente de
 * verdad de la versión.
 *
 * QUÉ HACE
 *   - Expone `window.ROTECHOS_VERSION` con la versión date-stamp actual
 *     (alineada con <title>RotechOS · Panel CNC vX</title>).
 *   - Expone `window.ROTECHOS_BUILD` con la fecha de build (ISO date).
 *   - Expone `window.ROTECHOS_PILLAR` con los pilares activos del bundle.
 *   - Expone `window.ROTECHOS_GIT_SHA` con el SHA del commit, o "dev"
 *     si todavía no se inyectó. Se puede actualizar vía `setGitSha()`.
 *
 * CACHE-BUSTING
 *   - `window.ROTECHOS_CACHE_BUST` se usa como `?v=ROTECHOS_CACHE_BUST` en
 *     <script src> y <link href> del index.html. Cambiar este valor
 *     fuerza a los navegadores a re-descargar el bundle ignorando caché.
 *
 * NOTAS DE DISEÑO
 *   - Cero dependencias externas (vanilla JS). Sin fetch, sin eval,
 *     sin new Function. Funciona offline.
 *   - Compatible con hard reload: cambiar la versión obliga al
 *     navegador a pedir el bundle nuevo.
 *   - El módulo se congela parcialmente para evitar mutaciones accidentales
 *     en `window.ROTECHOS.GIT_SHA` desde código de UI, pero permite la
 *     actualización controlada vía `setGitSha()`.
 *
 * USO
 *   window.ROTECHOS_VERSION      → "v2026.07"
 *   window.ROTECHOS_BUILD        → "2026-07-19"
 *   window.ROTECHOS_PILLAR       → "CORE+LOG+CFG+VIZ3D"
 *   window.ROTECHOS_GIT_SHA      → "d198639" (o "dev")
 *   window.ROTECHOS_CACHE_BUST   → "v2026.07"
 *   window.ROTECHOS.setGitSha(sha) → actualiza el SHA si es válido.
 *
 * CÓMO ACTUALIZAR EN UNA RELEASE
 *   1. Editar VERSION y BUILD abajo.
 *   2. Actualizar el `<title>RotechOS · Panel CNC vX</title>` del index.html.
 *   3. Commit + tag: `git tag -a vYYYY.MM.DD -m "release: ..."`.
 *   4. Cuando hagas deploy.sh, el SHA del HEAD puede inyectarse con un
 *      `sed -i "s/\"dev\"/\"${SHORT_SHA}\"/" rotechos-version.js` o vía
 *      `setGitSha()` desde tu CI.
 * --- */

(function () {
  // ──────────────── EMBEBIDO: única fuente de verdad ────────────────
  // Para bump: cambiar VERSION arriba y BUILD abajo. No tocar nada más.
  const VERSION = "v2026.10";         // versión canónica del producto (v2026.09 -> v2026.10 el 2026-10-04: primera publicada en Peerchi/rotechos-updates)
  // ⚠️ BUILD NO SE TOCA SIN SUBIR TAMBIEN VERSION. El esquema canonico es
  // VERSION = vYYYY.MM y BUILD = YYYY-MM-DD **del mismo ano-mes**, y hay un
  // unitario que lo exige (`VERSION: VERSION y BUILD embebidos son
  // coherentes`). Ponerle a BUILD una fecha de agosto con VERSION en v2026.07
  // pone la suite en rojo: se comprobo el 2026-08-30 (977 pass / 1 fail).
  //
  // Y ESTA PAREJA ESTA DESFASADA A PROPOSITO, no por descuido: lleva desde el
  // 2026-07-19 mientras `sw.js` se bumpeaba 55 veces en 14 dias
  // (`git log --since=2026-08-16 --oneline -- ROTECHOS/www/sw.js | wc -l`).
  // Subirla es DECLARAR UNA RELEASE (v2026.08), y eso lo decide Sergi, no un
  // agente — mas aun con una entrega a beta-testers a punto de salir, porque
  // es el numero que los usuarios van a citar en cada incidencia. Queda como
  // decision abierta en el encargo de beta.
  //
  // Mientras tanto, la pregunta practica —"¿que build hay en la SD?"— ya NO
  // depende de este literal: la responde `SW_CACHE`, que se DERIVA del
  // service worker y no puede quedarse atras. Ver justo debajo.
  // VERSION y BUILD suben JUNTOS: el esquema canónico es vYYYY.MM +
  // YYYY-MM-DD del MISMO año-mes, y hay un unitario que lo exige
  // (`VERSION: VERSION y BUILD embebidos son coherentes`). Mover uno solo
  // pone la suite en rojo — comprobado el 2026-08-30 (977/1).
  //
  // Llevaban desde el 19-jul sin moverse mientras `sw.js` se bumpeaba 55
  // veces en 14 días. Con la máquina delante, "¿qué build hay en la SD?"
  // no tenía respuesta, y es la primera pregunta ante cualquier rareza.
  const BUILD   = "2026-10-09";      // ISO date de este build (YYYY-MM-DD)
  const PILLAR  = "CORE+LOG+CFG+VIZ3D"; // pilares activos en este build

  let _gitSha = "dev"; // placeholder hasta que rotechos.js (o CI) lo inyecte

  // ──────────────── Helpers internos ────────────────
  function _safeWarn(msg, ctx) {
    // LOG puede o no estar cargado en este punto (orden de scripts).
    // Si existe, usa logger; si no, swallow silenciosamente.
    try {
      if (typeof LOG !== "undefined" && LOG && typeof LOG.warn === "function") {
        LOG.warn(msg, ctx);
      }
    } catch (_) { /* swallow */ }
  }

  // ──────────────── API pública ────────────────
  // Globales planos para acceso rápido desde cualquier punto sin
  // prefijo de namespace.
  // ──────────────── Identidad REAL de lo que se esta sirviendo ────────────────
  // POR QUE ESTE CAMPO EXISTE
  //   VERSION y BUILD son literales que un humano tiene que acordarse de
  //   tocar, y la evidencia dice que no se acuerda: BUILD estuvo 6 semanas
  //   desfasado. `CACHE_NAME` de sw.js, en cambio, se bumpea en CADA cambio
  //   de UI porque si no, el navegador sirve codigo viejo — es el unico
  //   identificador del proyecto que no puede quedarse atras sin que algo
  //   se rompa antes. Asi que la identidad se DERIVA de el en vez de teclearse.
  //
  //   Responde a la pregunta del banco: "¿que bytes exactos hay en la SD?".
  //   `ROTECHOS/sys/VERSION` y `global fwVersion` siguen siendo la respuesta
  //   para el FIRMWARE (los actualiza Sergi al escribir la tarjeta); esto es
  //   la respuesta para la UI, que es la que cambia cuatro veces al dia.
  //
  //   Es asincrono a proposito y no bloquea el arranque: si `caches` no existe
  //   (contexto inseguro, navegador viejo, SW aun no activo) el campo se queda
  //   en null y nadie se entera. Nunca debe poder tumbar el shell.
  let _swCache = null;
  function _leerCacheSW() {
    try {
      if (typeof caches === "undefined" || !caches || typeof caches.keys !== "function") return;
      caches.keys().then((ks) => {
        const hit = (ks || []).filter((k) => /^rotechos-v\d+$/.test(k)).sort(
          (a, b) => parseInt(a.slice(10), 10) - parseInt(b.slice(10), 10),
        ).pop();
        if (hit && hit !== _swCache) {
          _swCache = hit;
          window.ROTECHOS_SW_CACHE = hit;
        }
      }).catch(() => { /* sin cache: el campo se queda en null, no es un error */ });
    } catch (_) { /* idem */ }
  }
  // OJO AL MOMENTO EN QUE SE LEE (medido el 2026-08-30):
  //   este fichero es el script #1 de los 37 que carga index.html. Cuando
  //   corre, el service worker todavia no se ha registrado y `caches.keys()`
  //   devuelve []. Una sola lectura al arrancar da SIEMPRE null — verificado
  //   con Playwright: `caches.keys()` -> ["rotechos-v232"] a los 6 s, pero el
  //   campo se quedaba en null porque nadie volvia a mirar.
  //   Por eso se engancha a los dos momentos en que la respuesta cambia:
  //   `serviceWorker.ready` (el SW ya instalo y precacheo) y `controllerchange`
  //   (llego un bump de CACHE_NAME y la caché vieja se purgo). La lectura
  //   inicial se conserva para el caso de recarga con SW ya activo.
  _leerCacheSW();
  try {
    if (typeof navigator !== "undefined" && navigator.serviceWorker) {
      navigator.serviceWorker.ready.then(_leerCacheSW).catch(() => {});
      navigator.serviceWorker.addEventListener("controllerchange", _leerCacheSW);
    }
  } catch (_) { /* contexto sin serviceWorker: SW_CACHE se queda en null */ }

  // ──────────────── INSTALL UUID (fallback cuando no hay mcuId de la placa) ────────────────
  // POR QUE EXISTE
  //   RRF expone el unique ID del MCU en `rr_model?key=boards` → mainBoard.mcuId.
  //   Ese es EL identificador estable de la unidad (no cambia nunca, no
  //   depende del navegador ni del sitio). Cuando esta disponible, ese
  //   campo manda y este UUID queda como "instalacion del navegador",
  //   claramente etiquetado para no confundir con la placa fisica.
  //
  //   Cuando NO esta disponible (mock-server, modo demo, navegador antes
  //   del primer poll, primera visita): generamos un UUID v4 y lo guardamos
  //   en `localStorage`. Sobrevive a recargas; se pierde al borrar datos
  //   del sitio; identifica la INSTALACION, NO la placa.
  //
  // SEGURIDAD
  //   El UUID es local NUNCA viaja a terceros ni a URLs. Solo aparece:
  //     - en el bloque "Para soporte tecnico" de la pestana IDENTIDAD.
  //     - en el manifest.json del paquete de diagnostico.
  //   El paquete lo redaccion no aplica a este UUID (no es credencial).
  //   El display UI lo muestra con prefijo legible.
  //
  // ROBUSTEZ
  //   - Si `crypto.randomUUID` no existe (HTTP antiguo), cae a `Math.random`
  //     con formato UUID v4 canonico (xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx).
  //   - Si `localStorage` no esta disponible (modo privado de algunos
  //     navegadores, tests sin shim), el helper devuelve el UUID generado
  //     en memoria para esta sesion; no persiste pero la UI puede mostrar
  //     algo en lugar de "(no disponible)".
  //   - Nunca bloquea; nunca lanza.
  const INSTALL_UUID_KEY = "rotechos-installation-uuid";
  const _LOCAL_UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

  function _genUuidV4() {
    // Intento 1: crypto.randomUUID (navegadores modernos, siempre sobre
    // HTTPS o localhost). Barato; garantiza formato canonico.
    try {
      if (typeof crypto !== "undefined" && crypto && typeof crypto.randomUUID === "function") {
        const u = crypto.randomUUID();
        if (typeof u === "string" && _LOCAL_UUID_RE.test(u)) return u;
      }
    } catch (_) { /* sigue */ }
    // Intento 2: fallback manual. Garantiza la version 4 (el 13er nibble
    // es "4" y el 17º es uno de 8/9/a/b). NO es criptograficamente
    // seguro — el plan no lo exige; solo pedimos que sea estable, no
    // colisionable en un taller de 5 maquinas.
    let s = "";
    const hex = "0123456789abcdef";
    for (let i = 0; i < 36; i++) {
      if (i === 8 || i === 13 || i === 18 || i === 23) {
        s += "-";
        continue;
      }
      if (i === 14) { s += "4"; continue; }          // version 4
      if (i === 19) { s += hex[(Math.random() * 4) | 8]; continue; }  // variant 8/9/a/b
      s += hex[(Math.random() * 16) | 0];
    }
    return s;
  }

  function _readStorage(key) {
    try {
      if (typeof localStorage === "undefined" || !localStorage) return null;
      const v = localStorage.getItem(key);
      return typeof v === "string" ? v : null;
    } catch (_) { return null; }
  }

  function _writeStorage(key, val) {
    try {
      if (typeof localStorage === "undefined" || !localStorage) return false;
      localStorage.setItem(key, String(val));
      return true;
    } catch (_) { return false; }
  }

  function ensureLocalUuid() {
    const existe = _readStorage(INSTALL_UUID_KEY);
    if (typeof existe === "string" && _LOCAL_UUID_RE.test(existe)) return existe;
    const nuevo = _genUuidV4();
    _writeStorage(INSTALL_UUID_KEY, nuevo);
    return nuevo;
  }

  function _boardFromCache() {
    try {
      const c = window.AppState && window.AppState.cache;
      if (!c || !c.boards) return null;
      const raw = c.boards;
      const lista = Array.isArray(raw)
        ? raw
        : (raw && Array.isArray(raw.result) ? raw.result : (raw ? [raw] : []));
      if (!lista.length) return null;
      const principal = lista.find((b) => b && (b.canAddress === 0 || b.canAddress == null || !("canAddress" in b))) || lista[0];
      return principal || null;
    } catch (_) { return null; }
  }

  function _pickKey(obj, nombres) {
    if (!obj || typeof obj !== "object") return null;
    for (const n of nombres) {
      if (obj[n] != null && obj[n] !== "") return obj[n];
    }
    return null;
  }

  // ──────────────── identitySnapshot — el BLOQUE para soporte ────────────────
  // Devuelve un objeto plano con todo lo que el operario va a tener que
  // dictar o copiar: nombre de maquina (si existe), identificador estable
  // de la placa (mcuId, si el poll ya lo trae) o UUID de instalacion como
  // fallback etiquetado, versiones de UI, navegador, viewport.
  //
  // NUNCA lanza: si falta una fuente devuelve null para ese campo. Asi
  // la UI puede seguir pintando los demas.
  function identitySnapshot() {
    const w = (typeof window !== "undefined") ? window : {};
    // navigator puede ser null en algunos contextos de test: defender.
    const nav = (typeof navigator !== "undefined" && navigator) ? navigator : null;
    const ua = (nav && typeof nav.userAgent === "string") ? nav.userAgent : null;
    const idioma = (nav && typeof nav.language === "string") ? nav.language : null;
    const viewport = (typeof w.innerWidth === "number" && typeof w.innerHeight === "number")
      ? `${w.innerWidth}x${w.innerHeight}` : null;
    const placa = _boardFromCache();
    const mcuId = _pickKey(placa, ["mcuId", "mcuUniqueId", "uniqueId", "uniqueID"]);
    const mcuType = _pickKey(placa, ["mcuType", "mcuName"]);
    const rrfVersion = _pickKey(placa, ["firmwareVersion", "firmwareName"]);
    return {
      nombreMaquina: null, // el caller (UI) lo rellena desde configModal
      identificadorPlaca: mcuId || null,
      mcuType: mcuType || null,
      rrfVersion: rrfVersion || null,
      instalacionUuid: ensureLocalUuid(),
      rotechosVersion: w.ROTECHOS_VERSION || VERSION,
      rotechosBuild: w.ROTECHOS_BUILD || BUILD,
      rotechosPillar: w.ROTECHOS_PILLAR || PILLAR,
      rotechosSwCache: w.ROTECHOS_SW_CACHE || _swCache,
      rotechosGitSha: w.ROTECHOS_GIT_SHA || _gitSha,
      navegador: ua,
      viewport: viewport,
      idioma: idioma,
      generadoEn: new Date().toISOString(),
    };
  }

  // ──────────────── renderSoporteBloque — pinta el sub-panel "Para soporte" ────────────────
  // Sincrona DOM-only: busca `#mcfgSupportId`, `#mcfgSupportName`,
  // `#mcfgSupportRrf`, `#mcfgSupportVersions`, `#mcfgSupportUuid`,
  // `#mcfgSupportBtn` y los rellena desde `identitySnapshot()`. Nunca
  // rompe la app si los nodos no existen.
  //
  // El numero de serie del MCU se muestra corto (ultimos 6 chars) por
  // defecto, con opcion a revelar el completo: el operario no tiene que
  // dictar 24 caracteres hex cada vez.
  function _setText(id, val) {
    try {
      const el = document.getElementById(id);
      if (!el) return;
      el.textContent = (val == null || val === "") ? "—" : String(val);
    } catch (_) { /* no DOM: tests */ }
  }

  function renderSoporteBloque(opts) {
    const o = (opts && typeof opts === "object") ? opts : {};
    const snap = identitySnapshot();
    if (o.nombreMaquina) snap.nombreMaquina = o.nombreMaquina;
    _setText("mcfgSupportName", snap.nombreMaquina);
    if (snap.identificadorPlaca) {
      const id = String(snap.identificadorPlaca);
      const corto = id.length > 8 ? `…${id.slice(-8)}` : id;
      _setText("mcfgSupportId", corto);
      _setText("mcfgSupportIdFull", id);
    } else {
      _setText("mcfgSupportId", null);
      _setText("mcfgSupportIdFull", null);
    }
    _setText("mcfgSupportMcu", snap.mcuType);
    _setText("mcfgSupportRrf", snap.rrfVersion);
    _setText("mcfgSupportUuid", snap.instalacionUuid);
    _setText("mcfgSupportVersions",
      `${snap.rotechosVersion} (build ${snap.rotechosBuild}) · SW ${snap.rotechosSwCache} · ${snap.rotechosGitSha}`);
    _setText("mcfgSupportEnv", `${snap.navegador || "?"} · ${snap.viewport || "?"} · ${snap.idioma || "?"}`);
  }

  // ──────────────── copiarBloqueSoporte — para pegar en un correo ────────────────
  // Devuelve el multi-linea listo para pegar (o lo escribe en clipboard).
  // Sin credenciales, sin texto traducible, sin campos opcionales nulos.
  function copiarBloqueSoporte(opts) {
    const o = (opts && typeof opts === "object") ? opts : {};
    const snap = identitySnapshot();
    if (o.nombreMaquina) snap.nombreMaquina = o.nombreMaquina;
    const lineas = [];
    lineas.push(`# RotechOS — soporte tecnico`);
    lineas.push(`Nombre maquina: ${snap.nombreMaquina || "(no definido)"}`);
    if (snap.identificadorPlaca) {
      lineas.push(`ID placa (mcuId): ${snap.identificadorPlaca}`);
      if (snap.mcuType) lineas.push(`MCU: ${snap.mcuType}`);
      if (snap.rrfVersion) lineas.push(`RRF: ${snap.rrfVersion}`);
    } else {
      lineas.push(`ID placa: (no reportado por la placa)`);
      lineas.push(`UUID instalacion (NO identifica la placa fisica): ${snap.instalacionUuid}`);
    }
    lineas.push(`RotechOS: ${snap.rotechosVersion} (build ${snap.rotechosBuild})`);
    lineas.push(`Pilar: ${snap.rotechosPillar}`);
    lineas.push(`Cache SW: ${snap.rotechosSwCache || "(aun sin registrar)"}`);
    lineas.push(`GIT SHA: ${snap.rotechosGitSha}`);
    lineas.push(`Navegador: ${snap.navegador || "?"}`);
    lineas.push(`Viewport: ${snap.viewport || "?"}`);
    lineas.push(`Idioma: ${snap.idioma || "?"}`);
    lineas.push(`Generado: ${snap.generadoEn}`);
    const texto = lineas.join("\n");
    // Intento de clipboard (async; no esperamos — el caller lo intenta y
    // punto). Si falla, sigue funcionando el modal con el texto visible.
    try {
      if (typeof navigator !== "undefined" && navigator.clipboard
          && typeof navigator.clipboard.writeText === "function") {
        navigator.clipboard.writeText(texto).catch(() => {});
      }
    } catch (_) { /* no clipboard API */ }
    return texto;
  }

  // Globales planos para acceso rapido desde cualquier punto.
  window.ROTECHOS_VERSION    = VERSION;
  window.ROTECHOS_BUILD      = BUILD;
  window.ROTECHOS_SW_CACHE   = _swCache;
  window.ROTECHOS_PILLAR     = PILLAR;
  window.ROTECHOS_GIT_SHA    = _gitSha;
  window.ROTECHOS_CACHE_BUST = VERSION;
  // IDENTIDAD Y LICENCIA decia «Version 1.0» fijo, sin relacion con esta version. La pinta de aqui.
  try {
    const _pintaVersion = () => { const el = document.getElementById("aboutVersion"); if (el) el.textContent = VERSION; };
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", _pintaVersion); else _pintaVersion();
  } catch (_) { /* sin DOM (unitarios) */ }

  // Namespaced object con API no congelada (para setGitSha).
  // NO exportamos `Object.freeze` para permitir actualización de GIT_SHA.
  window.ROTECHOS = {
    VERSION, BUILD, PILLAR,
    // Identidad derivada del service worker; null hasta que `caches.keys()`
    // resuelve (unos ms tras el arranque) y en contextos sin Cache API.
    get SW_CACHE() { return _swCache; },
    get GIT_SHA() { return _gitSha; },
    get CACHE_BUST() { return VERSION; },
    setGitSha(sha) {
      if (typeof sha === "string" && /^[0-9a-f]{7,40}$/.test(sha)) {
        _gitSha = sha;
        window.ROTECHOS_GIT_SHA = sha;
        return true;
      }
      _safeWarn("ROTECHOS.setGitSha: SHA inválido, ignorando.", { sha });
      return false;
    },
    // Nuevos helpers para el bloque "Para soporte tecnico" (Fase 4.19).
    // DEVUELVEN OBJETOS PLANOS — no mutan globales para no contaminar
    // otros consumidores del modulo.
    identitySnapshot,
    ensureLocalUuid,
    renderSoporteBloque,
    copiarBloqueSoporte,
    // Exponer la regex para tests y depuracion.
    INSTALL_UUID_KEY,
  };
})();
