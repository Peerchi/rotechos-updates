// ---
// rotechos-fm.js — FILE MANAGER: gestión de archivos G-code en la SD
// ---
// Extraído de rotechos.js (jul-2026, extracción #3 del roadmap) SIN cambios
// de lógica, en 3 tramos: el objeto FM (list/upload/download/fmtSize sobre
// rr_filelist/rr_upload/rr_download), fmLoadList + renderFileList (lista
// del cockpit con cargar/editar/eliminar), y fmHandleFiles + drop zone
// (subida con saneado de nombre, progreso XHR y límite 50MB).
// FM.upload PAUSA el polling (_clearPollTimer) durante la subida y lo
// reanuda SIEMPRE (onload/onerror/ontimeout): sin esa pausa el WiFi se
// satura y el watchdog de daemon.g pausaría un corte en marcha.
//
// Dependencias en runtime (todas globales, resueltas por orden de defer;
// este archivo carga DESPUÉS de rotechos.js — ver index.html):
//   - rotechos-dom.js  → $()
//   - rotechos-i18n.js → t()
//   - rotechos.js      → _fetchRRF, TARGET_IP, toast, log, escHtml,
//                        confirmDialog, sleep, _clearPollTimer, startPoll,
//                        SM, STATES, RRF, loadFile, _SVG_PLAY
//
// editingFileName/editingFileDir se declaran AQUÍ (solo este módulo los
// escribe, desde el botón editar) pero los lee el editor de archivos que
// sigue en rotechos.js — estado compartido cross-file, como _cfgRaw.
//
// La llamada inicial a fmLoadList() vive en la IIFE async de inicio de
// rotechos.js (no en DOMContentLoaded): se ejecuta en AMBAS ramas del
// ternario post-await (éxito y fallo de RRF.connect). Con guard `typeof`
// por la carrera del boot (await + respuesta < 1 ms en localhost puede
// ganar a este defer #14). Ver el comentario en rotechos.js:3345/3351/3368.
//
// ⚠️ tests/unit/fm.test.js extrae el objeto FM completo por regex anclada
//    a inicio de línea y al cierre en indent 2, y el regex de extensiones
//    inline: si reindentas el objeto o cambias el filtro, actualiza el test.
// ---
// API pública consumida por rotechos.js, rotechos-pendant.js y rotechos-viz.js:
/* exported FM, fmLoadList, editingFileName, editingFileDir */
// eslint-disable-next-line no-unused-vars -- usado por editingFileName fuera de este módulo (rotechos.js:3568 + este módulo línea 196)
let editingFileName = null,
// eslint-disable-next-line no-unused-vars -- usado por editingFileDir fuera de este módulo (rotechos.js:3587 + este módulo línea 197)
  editingFileDir = `0:/sys`;
// H-4-02: expone editingFileName para test e2e del lint del editor
Object.defineProperty(window, 'editingFileName', {
  get() { return editingFileName; },
  set(v) { editingFileName = v; },
  configurable: true
});
// H-4-02 (decisión 2026-08-17, opción A): expone editingFileDir para que el
// pendant (rotechos-pendant.js) pueda reutilizar fileEditorModal + btnEditorSave
// (el editor con lint). Sin esto, el editor guarda en el dir por defecto
// (`0:/sys`) en lugar del dir del archivo que el operario está editando
// (en el pendant los archivos viven en `0:/gcodes`).
Object.defineProperty(window, 'editingFileDir', {
  get() { return editingFileDir; },
  set(v) { editingFileDir = v; },
  configurable: true
});
const FM = {
    dir: `0:/gcodes`,
    fmtSize(b) {
      return b < 1024
        ? `${b} B`
        : b < 1048576
          ? `${(b / 1024).toFixed(1)} KB`
          : `${(b / 1048576).toFixed(2)} MB`;
    },
    async list() {
      try {
        return await _fileList(this.dir);
      } catch {
        return null;
      }
    },
    // `opts.silenciarFallo` (t_e558a603): quien envuelve la subida con su
    // propio mensaje —atomicUpload, que sube dos veces— pide no duplicar el
    // toast. La causa sigue quedando en `FM._lastUploadFail` para que ese
    // envoltorio pueda nombrarla.
    async upload(file, onProgress, altName, opts) {

      const MAX_UPLOAD_MB = 50;
      if (file.size > MAX_UPLOAD_MB * 1024 * 1024) {
        // ES = el template literal del fallback ya expande ${MAX_UPLOAD_MB}.
        // EN = concatenamos el número delante del texto estático del diccionario
        // (la clave guarda solo la parte fija; ver msg.archivoDemasiadoGrandeMáx
        // en rotechos-i18n-dynjs.js).
        // Guarda con typeof por la carrera del boot: rotechos-fm.js carga
        // después de rotechos.js pero la IIFE de inicio de este módulo puede
        // dispararse antes de que rotechos-i18n.js haya publicado window.I18N.
        // Mismo patrón que rotechos-config-modal.js:666.
        const _isEn = (typeof I18N !== "undefined" && I18N.lang === "en");
        toast(`${_isEn ? `${MAX_UPLOAD_MB} ` : ``}${t(`msg.archivoDemasiadoGrandeMáx`, `Archivo demasiado grande (máx ${MAX_UPLOAD_MB}MB). Para subirlo, comprímelo a un ZIP en tu PC, descomprímelo en la SD con un lector de tarjetas y arrastra los archivos sueltos a la zona OTA de CONFIGURACIÓN.`)}`, `err`);
        log(
          `Upload rechazado: ${file.name} (${(file.size / 1048576).toFixed(1)}MB > ${MAX_UPLOAD_MB}MB)`,
          `err`,
        );
        return !1;
      }
      // D-03: rr_upload iba sin escudo — escribe macros y ficheros de interfaz
      // en la SD; cubre tambien atomicUpload, que sube por aqui. Va antes de
      // parar el poll: un aborto no debe dejarlo muerto.
      if (typeof window !== `undefined` && window.rotechosShieldMsg
        && !await window.rotechosShieldMsg.guard(TARGET_IP, `FM.upload`)) return !1;
      // Pausar polling para evitar colapso de red y desconexiones falsas
      _clearPollTimer();
      return new Promise((resolve) => {
        const xhr = new XMLHttpRequest();
        const fname = altName || file.name;
        // HUECO-2 y HUECO-3 (t_e558a603, acta 2026-09-06_C-robustez-percibida.md):
        // subir era MUDA en los dos extremos. Si tardaba, ninguna senal (el
        // `onProgress` solo lo consumen algunos call-sites); si fallaba con
        // HTTP 500 o {err:N}, `resolve(!1)` sin decir NADA — cada llamador
        // improvisaba su propio toast generico o ninguno. El operario veia
        // «error» sin saber si fallo el guardado, la subida o el palpado.
        //
        // El aviso de lentitud se CANCELA en todas las salidas (onload/onerror/
        // ontimeout), asi que no hay toast tardio sobre algo ya terminado.
        const _of = (typeof window !== `undefined` && window.rotechosOpFeedback) || null;
        const _opNombre = t(`msg.opSubirArchivo`, `subir el archivo`) + ` (${fname})`;
        const _lento = _of ? _of.opSlow(_opNombre) : null;
        const _fin = (ok, lf) => {
          if (_lento) _lento();
          // La causa queda registrada SIEMPRE (aunque el toast se silencie), para
          // que atomicUpload pueda decir el motivo en su propio mensaje sin
          // duplicar el aviso.
          FM._lastUploadFail = ok ? null : (lf || null);
          if (!ok && _of && !(opts && opts.silenciarFallo)) _of.opFail(_opNombre, lf);
          resolve(ok);
        };
        (xhr.open(
          `POST`,
          `${TARGET_IP}/rr_upload?name=${encodeURIComponent(this.dir + `/` + fname)}&time=${Date.now()}`,
        ),
          xhr.setRequestHeader("Content-Type", "application/octet-stream"),
          (xhr.timeout = 300000), // 5 minutos (evitar fallos en archivos >15MB)
          (xhr.upload.onprogress = (e) => {
            e.lengthComputable && onProgress(e.loaded / e.total);
          }),
          (xhr.onload = () => {
            startPoll();
            // B-1: HTTP 200 no garantiza éxito en RRF — también devuelve {err:N}
            // con status 200. Como backup.js (b266a7a), parsear y verificar err===0.
            if (xhr.status < 300) {
              try {
                const json = JSON.parse(xhr.responseText);
                // `err:N` es el firmware rechazando, no un fallo de red: se
                // reporta como tal para que el operario no culpe al WiFi.
                _fin(json.err === 0, json.err === 0 ? null : {
                  reason: `firmware`, errMsg: `err:${json.err}`, at: Date.now(),
                });
              } catch {
                _fin(!1, { reason: `firmware`, errMsg: `respuesta ilegible de la placa`, at: Date.now() });
              }
            } else {
              _fin(!1, { reason: `http`, status: xhr.status, at: Date.now() });
            }
          }),
          (xhr.onerror = () => { startPoll(); _fin(!1, { reason: `network`, error: `error de red`, at: Date.now() }); }),
          (xhr.ontimeout = () => { startPoll(); _fin(!1, { reason: `timeout`, at: Date.now() }); }),
          xhr.send(file));
      });
    },
    // ── atomicUpload: write-temp + rename atómico para subidas de interfaz ──
    // FIX C4EF (carril-3, 2026-08-15): protege contra cortes de subida en la
    // actualización de la interfaz. Patrón:
    //   1. Sube a `name + ".tmp.UUID"` en el mismo dir (RRF usa temp+rename
    //      interno en `rr_upload`, así que la `.tmp` queda atómica en la SD
    //      si la red corta a mitad).
    //   2. Si la `.tmp` se subió BIEN, sube al nombre final. RRF sobreescribe
    //      el destino de forma atómica (temp+rename interno). Si la SD ya
    //      tenía un `name` previo, lo preserva hasta el último instante.
    //   3. Si la subida final es OK, borra la `.tmp`. Si falla, la `.tmp`
    //      queda en la SD como rescate manual (toast warn lo notifica).
    //
    // Limitaciones honestas: la rotación final NO es renombrado atómico de
    // cliente, porque RRF no expone `rr_move`/rename por HTTP. La protección
    // real viene del temp+rename INTERNO de RRF en cada `rr_upload`. Este
    // helper garantiza que la versión ANTERIOR del archivo en la SD (si
    // existía) NO se sustituye hasta que la nueva está verificada.
    //
    // Devuelve `true` solo si .tmp → final → cleanup se completaron. Si
    // falla un paso intermedio, devuelve `false` y deja la `.tmp` en la SD
    // para rescate manual.
    async atomicUpload(file, onProgress, altName) {
      const MAX_UPLOAD_MB = 50;
      if (file.size > MAX_UPLOAD_MB * 1024 * 1024) {
        // Mismo patrón que en upload(): ES expande vía template literal, EN
        // concatena. Guarda con typeof por la carrera del boot (ver upload()).
        const _isEn = (typeof I18N !== "undefined" && I18N.lang === "en");
        toast(`${_isEn ? `${MAX_UPLOAD_MB} ` : ``}${t(`msg.archivoDemasiadoGrandeMáx`, `Archivo demasiado grande (máx ${MAX_UPLOAD_MB}MB). Para subirlo, comprímelo a un ZIP en tu PC, descomprímelo en la SD con un lector de tarjetas y arrastra los archivos sueltos a la zona OTA de CONFIGURACIÓN.`)}`, `err`);
        log(`Upload rechazado: ${file.name} (${(file.size / 1048576).toFixed(1)}MB > ${MAX_UPLOAD_MB}MB)`, `err`);
        return !1;
      }
      const fname = altName || file.name;
      const tmpName = `${fname}.tmp.${Date.now()}.${Math.random().toString(36).slice(2, 8)}`;
      // Fase 1: subir a `tmpName`. Si falla, NO tocamos el destino original.
      log(`atomicUpload: fase 1/2 → ${tmpName}`, `sys`);
      const okTmp = await this.upload(file, (p) => onProgress?.(p * 0.5), tmpName, { silenciarFallo: !0 });
      if (!okTmp) {
        // HUECO-3 (t_e558a603): el mensaje decia que fallo y que el original
        // seguia intacto —correcto— pero no POR QUE. `FM._lastUploadFail` ya
        // trae la causa exacta (HTTP 500 / err:N / timeout / red); anadirla es
        // la diferencia entre «revisa la conexion» y saber que la placa
        // contesto 500.
        const _porQue = (typeof window !== `undefined` && window.rotechosOpFeedback)
          ? window.rotechosOpFeedback.causa(FM._lastUploadFail) : null;
        toast(t(`msg.atomicUploadTmpFail`, `Subida a temporal falló — el archivo original en la SD NO fue tocado. Revisa la conexión y vuelve a intentarlo.`)
          + (_porQue ? ` (${_porQue})` : ``), `err`);
        log(`atomicUpload: fase 1 falló (${tmpName}) — destino preservado`, `err`);
        return !1;
      }
      // Fase 2: subir al nombre final. RRF sobreescribe de forma atómica
      // (internamente temp+rename). Si falla, la `.tmp` queda como rescate.
      log(`atomicUpload: fase 2/2 → ${fname}`, `sys`);
      const okFinal = await this.upload(file, (p) => onProgress?.(0.5 + p * 0.5), fname, { silenciarFallo: !0 });
      if (!okFinal) {
        const _porQue = (typeof window !== `undefined` && window.rotechosOpFeedback)
          ? window.rotechosOpFeedback.causa(FM._lastUploadFail) : null;
        toast(t(`msg.atomicUploadFinalFail`, `Subida final falló — la copia temporal "${tmpName}" quedó en la SD como rescate. Puedes renombrarla desde el file manager o reintentar la subida.`)
          + (_porQue ? ` (${_porQue})` : ``), `warn`);
        log(`atomicUpload: fase 2 falló (${fname}) — .tmp ${tmpName} preservada para rescate`, `warn`);
        return !1;
      }
      // Fase 3: cleanup — borrar la `.tmp`. Si falla, NO es grave: el archivo
      // está bien y la `.tmp` ocupa espacio, pero el trabajo está hecho.
      try {
        const dir = this.dir;
        await _fetchRRF(`${TARGET_IP}/rr_delete?name=${encodeURIComponent(dir + `/` + tmpName)}`, { method: `GET` }, 5000);
        log(`atomicUpload: cleanup OK (${tmpName} borrada)`, `sys`);
      } catch (e) {
        log(`atomicUpload: cleanup .tmp falló (${tmpName}) — archivo en destino OK, pero queda .tmp ocupando espacio: ${e?.message || e}`, `warn`);
      }
      onProgress?.(1);
      return !0;
    },
    async download(filename) {
      try {
        const r = await RRF.download(this.dir + '/' + filename);
        return r.ok ? r.text() : null;
      } catch {
        return null;
      }
    },
  };
async function fmLoadList() {
  const list = $(`fmList`);
  if (!list) return;
  list.innerHTML = `<div class="fm-empty">Cargando…</div>`;
  let files = null;
  try {
    const data = await FM.list();
    data?.files &&
      (files = data.files.filter(
        (f) => f.type === `f` && /\.(gcode|g|nc|cnc|tap|txt)\s*$/i.test(f.name),
      ));
  } catch {}
  ((files ||= []), renderFileList(files));
}
function renderFileList(files) {
  const list = $(`fmList`),
    count = $(`fmCount`);
  if (list) {
    if (!files || !files.length) {
      ((list.innerHTML = `<div class="fm-empty">No hay archivos G-code</div>`),
        count && (count.textContent = `0 archivos`));
      return;
    }
    ((list.innerHTML = ``),
      count &&
        (count.textContent = `${files.length} archivo${files.length === 1 ? `` : `s`}`),
      files.forEach((f) => {
        const row = document.createElement(`div`);
        ((row.className =
          `fm-file-row` + (f.name === SM.loadedFile ? ` active-file` : ``)),
          (row.innerHTML = `



<button class="fm-file-load-btn" title="Cargar ${escHtml(f.name)}">



<span class="fm-file-ico">



<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>



</span>



<span class="fm-file-name">${escHtml(f.name)}</span>



<span class="fm-file-meta">${FM.fmtSize(f.size)}</span>



${_SVG_PLAY}



</button>



<div class="fm-file-actions">



<button class="fm-action-btn edit" title="Editar archivo"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/></svg></button>



<button class="fm-action-btn del" title="Eliminar"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4h6v2"/></svg></button>



</div>`),
          row
            .querySelector(`.fm-file-load-btn`)
            .addEventListener(`click`, async () => {
              toast(t(`msg.cargandoFname`, `Cargando ${f.name}…`, { "f.name": f.name }), `info`);
              let gcode = null;
              // No descargar el G-code (puede ser de varios MB) si hay un trabajo
              // activo: saturaría el WiFi compitiendo con el polling del trabajo.
              // En idle sí se descarga para ver la trayectoria (flujo normal/seguro).
              if (SM.current !== STATES.RUNNING) {
                try {
                  gcode = await FM.download(f.name);
                } catch {}
              }
              (await loadFile(f.name, gcode), fmLoadList());
            }),
          row
            .querySelector(`.fm-action-btn.edit`)
            .addEventListener(`click`, async () => {
              toast(t(`msg.abriendoFname`, `Abriendo ${f.name}…`, { "f.name": f.name }), `info`);
              const content = await FM.download(f.name);
              content === null
                ? toast(t(`msg.errorAlLeerFname`, `Error al leer ${f.name}`, { "f.name": f.name }), `err`)
                : ((editingFileName = f.name),
                  (editingFileDir = FM.dir),
                  ($(`editorFilename`).textContent =
                    f.name),
                  ($(`editorStatus`).textContent =
                    FM.fmtSize(f.size)),
                  ($(`fileEditorArea`).value = content),
                  document
                    .getElementById(`fileEditorModal`)
                    .classList.add(`show`));
            }),
          row
            .querySelector(`.fm-action-btn.del`)
            .addEventListener(`click`, async () => {
              // Guard ANTES de borrar: antes el M30 se enviaba primero y el aviso
              // "no se puede eliminar" llegaba con el archivo ya borrado de la SD.
              if (SM.loadedFile === f.name && SM.current === STATES.RUNNING) {
                toast(t(`msg.noSePuedeEliminar`, `No se puede eliminar mientras se ejecuta: para borrar este archivo primero detén el trabajo actual (pulsa STOP en la barra superior, espera a que el estado pase a LISTO) y vuelve a intentarlo. Si está en PAUSA, pulsa REANUDAR hasta que termine y luego STOP.`), `warn`);
                return;
              }
              if (
                !(await confirmDialog(
                  t(`dlg.fileDelete.title`, `Eliminar archivo`),
                  `${t(`dlg.fileDelete.pre`, `¿Eliminar`)} <strong>${escHtml(f.name)}</strong>?<br>${t(`dlg.fileDelete.warn`, `Esta acción no se puede deshacer.`)}`,
                ))
              )
                return;
              // Usar la API HTTP rr_delete en lugar del comando M30 para evitar inyección
              const r = await RRF.deleteFile(`${FM.dir}/${f.name}`);
              (log(`rr_delete: ${FM.dir}/${f.name}`, `cmd`),
                toast(
                  r ? `"${f.name}" ${t(`msg.fileDeletedSfx`, `eliminado`)}` : t(`msg.fileDeleteErr`, `Error al eliminar`),
                  r ? `ok` : `err`,
                ),
                r &&
                  (SM.loadedFile === f.name &&
                    ((SM.loadedFile = null),
                    SM.transition(STATES.IDLE, `archivo eliminado`)),
                  fmLoadList()));
            }),
          list.appendChild(row));
      }));
  }
}
async function fmHandleFiles(files) {
  // No subir durante un trabajo: FM.upload pausa el polling (hasta 5 min) y sin el
  // latido uiBeat el watchdog de daemon.g PAUSARÍA el corte a mitad.
  if (SM.current === STATES.RUNNING) {
    toast(t(`msg.noUploadRunning`, `No se puede subir archivos durante un trabajo`), `warn`);
    return;
  }
  const prog = $(`fmProgress`),
    bar = $(`fmProgressBar`);
  for (const file of files) {
    (prog && prog.classList.add(`show`), bar && (bar.style.transform = `scaleX(0)`));
    const safeName = file.name.replace(/[^\w.-]/g, `_`).replace(/_+/g, `_`);
    safeName !== file.name &&
      (toast(t(`msg.nombreSanitizadoSafename`, `Nombre sanitizado: "${file.name}" → "${safeName}" — la SD solo admite letras, números, guión y punto; hemos sustituido los caracteres no válidos (espacios, acentos, eñes, símbolos) por guiones bajos. Si quieres otro nombre, cámbialo en tu PC antes de subir.`), `warn`),
      log(`Nombre sanitizado: "${file.name}" → "${safeName}"`, `sys`));
    const uploadFile =
      safeName === file.name
        ? file
        : new File([file], safeName, { type: file.type });
    log(`Subiendo: ${safeName} (${FM.fmtSize(file.size)})`, `sys`);
    // FIX C4EF (carril-3, 2026-08-15): la actualización de la interfaz es
    // la única operación que cruza archivos de sistema (config.g, macros,
    // gcodes) y para ella un corte a mitad puede dejar la SD con un
    // fichero truncado. El drop zone usa ahora `atomicUpload` (write-temp
    // + rename) por defecto: la versión anterior del archivo en la SD
    // queda intacta hasta que la nueva está verificada. Si la red cae a
    // mitad, el operario ve un toast y puede reintentar la subida.
    const ok = await FM.atomicUpload(
      uploadFile,
      (p) => {
        if (bar) bar.style.transform = `scaleX(${p})`;
      },
      safeName,
    );
    (bar && (bar.style.transform = `scaleX(1)`),
      toast(
        ok ? `"${safeName}" ${t(`msg.uploadedSfx`, `subido`)}` : `${t(`msg.uploadErrorPfx`, `Error subiendo`)} "${safeName}"`,
        ok ? `ok` : `err`,
      ),
      log(
        ok ? `✓ ${safeName} ${t(`msg.uploadedSfx`, `subido`)}` : `✗ ${t(`msg.uploadErrorPfx`, `Error subiendo`)} ${safeName}`,
        ok ? `cmd` : `err`,
      ),
      await sleep(400),
      prog && prog.classList.remove(`show`),
      bar && (bar.style.transform = `scaleX(0)`));
  }
  fmLoadList();
}
(document
  .getElementById(`fmFileInput`)
  ?.addEventListener(`change`, function () {
    this.files.length && fmHandleFiles(Array.from(this.files));
  }),
  $(`fmUploadZone`)?.addEventListener(`click`, () => {
    $(`fmFileInput`)?.click();
  }));
const zone = $(`fmUploadZone`);
if (zone) {
  (zone.addEventListener(`dragover`, (e) => {
    (e.preventDefault(), zone.classList.add(`drag-over`));
  }),
    zone.addEventListener(`dragleave`, () =>
      zone.classList.remove(`drag-over`),
    ),
    zone.addEventListener(`drop`, (e) => {
      (e.preventDefault(), zone.classList.remove(`drag-over`));
      const files = Array.from(e.dataTransfer.files).filter((f) =>
        /\.(gcode|g|nc|cnc|tap|txt)\s*$/i.test(f.name),
      );
      files.length
        ? fmHandleFiles(files)
        : toast(t(`msg.formatoNoSoportadoGcode`, `Formato no soportado (.gcode .g .nc .cnc .tap)`), `warn`);
    }));
}
// B-1 FIXE2E-02 (2026-08-04): publicación del handle global al final del módulo,
// después de definir FM y registrar todos los listeners. window.FM es el
// punto de entrada que usan los tests e2e (control positivo err=0 y mutación
// err=1) para invocar FM.upload y verificar la resolución de la Promise.
window.FM = FM;
