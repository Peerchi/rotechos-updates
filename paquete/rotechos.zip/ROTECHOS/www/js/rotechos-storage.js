/* ---
 * rotechos-storage.js — Wrapper tipado sobre localStorage
 *
 * Centraliza los 13 accesos directos a localStorage que existían dispersos
 * por rotechos.js (10), rotechos-modules.js (2) y rotechos-i18n.js (1).
 *
 * API pública: window.STORE
 * (STORE y no Storage: el nombre Storage SOMBREA el interfaz nativo del
 *  navegador — si el módulo no carga, Storage.get falla tarde con un
 *  TypeError ambiguo en vez de un ReferenceError inmediato. Pasó en jul-2026.)
 *   STORE.get(key, default?)            → valor casteado o default
 *   STORE.set(key, value)               → true si OK, false si validación falla
 *   STORE.has(key)                      → bool
 *   STORE.remove(key)                   → void
 *   STORE.keys()                        → array de claves lógicas conocidas
 *
 * Convención:
 *   - Las claves lógicas (p.ej. 'ui.theme') se mapean a claves físicas
 *     (p.ej. 'rotechos-theme') mediante KEY_MAP.
 *   - Las claves físicas se MANTIENEN como estaban antes del refactor para
 *     no romper la persistencia de usuarios en producción.
 *   - El schema declara el tipo (string|number|boolean|json) y restricciones
 *     opcionales (values, min, max, default).
 *
 * Reglas:
 *   - Todos los accesos a localStorage están envueltos en try/catch
 *     (Safari private mode, cuota excedida, etc.).
 *   - Si la validación falla, NO se escribe y se loggea warning.
 *
 * Auditoría clean code jul-2026: 5.4 → 5.7/10 (PR #1).
 * --- */
(function () {
  'use strict';

  // ---
  // SCHEMA
  // ---

  // Mapa lógico → físico. Mantener los físicos para no romper persistencia.
  const KEY_MAP = {
    'ui.theme':                  'rotechos-theme',
    'ui.consolaPlegada':         'rotechos-consola-plegada',
    'jog.speedLevel':            'rotechos-jog-speed-level',
    'jog.libreToastShown':       'rotechosLibreToastShown',
    'wizard.welcomed':           'rotechos-welcomed',
    'wizard.firstCut':           'rotechos-firstcut',
    'wizard.step':               'rotechos-wiz-step',
    'jobhistory.markedCreated':  'rotechos-jobhist-created',
    'jobhistory.last':           'rotechos-jobhist-last',
    'macros.custom':             'rotechos_macros_v1',
    'viz3d.prefs':               'rotechos-viz3d-prefs',
    'kb.bindings':               'rotechos-kbindings',
    'ota.log':                   'rotechOtaLog',
    'i18n.lang':                 'rotechos_lang',
    'mpg.showViz':               'rotechos-mpgviz',
    'notif.enabled':             'rotechos-notif-enabled',
  };

  // Schemas. Si una clave no aparece en SCHEMAS, el valor se trata como string crudo.
  const SCHEMAS = {
    'ui.theme':                 { type: 'string',  default: 'dark',  values: ['dark', 'light'] },
    'ui.consolaPlegada':        { type: 'boolean', default: true },
    'jog.speedLevel':           { type: 'string',  default: 'normal', values: ['slow', 'normal', 'fast'] },
    'jog.libreToastShown':      { type: 'boolean', default: false },
    'wizard.welcomed':          { type: 'boolean', default: false },
    'wizard.firstCut':          { type: 'string',  default: '' },
    'wizard.step':              { type: 'number',  default: 1,       min: 1, max: 12 },
    'jobhistory.markedCreated': { type: 'boolean', default: false },
    'jobhistory.last':          { type: 'json',    default: null },
    'macros.custom':            { type: 'json',    default: [] },
    'viz3d.prefs':              { type: 'json',    default: null },
    'kb.bindings':              { type: 'json',    default: {} },
    'ota.log':                  { type: 'json',    default: [] },
    'i18n.lang':                { type: 'string',  default: 'es' },
    'mpg.showViz':              { type: 'boolean', default: false },
    'notif.enabled':            { type: 'boolean', default: false },
  };

  // ---
  // HELPERS PRIVADOS
  // ---

  function _physKey(logicalKey) {
    return KEY_MAP[logicalKey] || logicalKey;
  }

  function _cast(raw, schema) {
    if (raw === null || raw === undefined) return undefined;
    if (!schema) return raw;
    try {
      switch (schema.type) {
        case 'number': {
          const n = parseFloat(raw);
          return Number.isNaN(n) ? schema.default : n;
        }
        case 'boolean':
          // Acepta 'true'/'1' como true; 'false'/'0'/'null'/'' como false.
          // Coherente con los usos previos del código (=== '1', === 'true', truthy).
          if (raw === true || raw === false) return raw;
          return raw === 'true' || raw === '1';
        case 'json':
          try { return JSON.parse(raw); } catch (_) { return schema.default; }
        case 'string':
        default:
          return String(raw);
      }
    } catch (_) {
      return schema.default;
    }
  }

  function _serialize(value, schema) {
    if (!schema) return String(value);
    switch (schema.type) {
      case 'json':      return JSON.stringify(value);
      case 'boolean':   return value ? 'true' : 'false';
      case 'number':    return String(value);
      case 'string':
      default:          return String(value);
    }
  }

  function _validate(value, schema) {
    if (!schema) return true;
    if (schema.type === 'number') {
      if (typeof value !== 'number' || Number.isNaN(value)) return false;
      if (schema.min !== undefined && value < schema.min) return false;
      if (schema.max !== undefined && value > schema.max) return false;
    }
    if (schema.type === 'boolean' && typeof value !== 'boolean') return false;
    if (schema.values && Array.isArray(schema.values) && !schema.values.includes(value)) return false;
    return true;
  }

  // _safeLs: cualquier acceso a localStorage puede tirar (Safari private,
  // cuota, deshabilitado por el user). Devuelve { ok, value }.
  function _safeLs(op) {
    try {
      if (typeof localStorage === 'undefined') return { ok: false, value: null };
      return { ok: true, value: op() };
    } catch (e) {
      LOG.warn('rotechos-storage: localStorage no disponible', e?.message || e);
      return { ok: false, value: null };
    }
  }

  // ---
  // API PÚBLICA
  // ---

  function get(logicalKey, defaultOverride) {
    const physKey = _physKey(logicalKey);
    const schema = SCHEMAS[logicalKey];
    const fallback = defaultOverride !== undefined
      ? defaultOverride
      : (schema ? schema.default : undefined);

    const r = _safeLs(() => localStorage.getItem(physKey));
    if (!r.ok || r.value === null) return fallback;
    return _cast(r.value, schema);
  }

  function set(logicalKey, value) {
    const physKey = _physKey(logicalKey);
    const schema = SCHEMAS[logicalKey];

    if (schema && !_validate(value, schema)) {
      LOG.warn(`rotechos-storage: valor inválido para ${logicalKey}`, value);
      return false;
    }

    const serialized = _serialize(value, schema);
    const r = _safeLs(() => localStorage.setItem(physKey, serialized));
    if (!r.ok) {
      LOG.warn(`rotechos-storage: no se pudo escribir ${logicalKey}`);
      return false;
    }
    return true;
  }

  function has(logicalKey) {
    const physKey = _physKey(logicalKey);
    const r = _safeLs(() => localStorage.getItem(physKey));
    return r.ok && r.value !== null;
  }

  function remove(logicalKey) {
    const physKey = _physKey(logicalKey);
    _safeLs(() => localStorage.removeItem(physKey));
  }

  function keys() {
    return Object.keys(KEY_MAP);
  }

  // ---
  // EXPOSICIÓN
  // ---

  window.STORE = {
    get,
    set,
    has,
    remove,
    keys,
    // Acceso de testing/avanzado (no usar en producción):
    _KEY_MAP: KEY_MAP,
    _SCHEMAS: SCHEMAS,
  };
})();
