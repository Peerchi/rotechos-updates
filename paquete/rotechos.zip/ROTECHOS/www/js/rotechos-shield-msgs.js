/* ---
 * rotechos-shield-msgs.js — Mensajes honestos del escudo de autenticación.
 *
 * Extraído de rotechos.js (t_79518921). Pura: depende solo de `t()` y de `r`.
 * Antes había un único mensaje; ahora tres según motivo (bloqueo-temporal /
 * overlay-suprimido / sin motivo). Test: tests/unit/shield-msg.test.js.
 *
 * HUECO-5: con motivo `network-error` la placa no responde, y el mensaje dice
 * red, no PIN. El escudo sigue bloqueando igual: solo cambia lo que se dice.
 *
 * Se carga DESPUÉS de rotechos-i18n.js (necesita t()) y ANTES de rotechos.js.
 * --- */
(function () {
  'use strict';

  function get(r) {
    const m = r && r.motivo;
    if (m === `network-error`) {
      // Fallo de red, no de seguridad: no menciona escudo ni PIN, dice qué revisar.
      const fb = `No se pudo enviar la orden: la placa no responde. Revisa el WiFi o el cable de red y vuelve a probar.`;
      return (typeof t === `function`) ? t(`msg.shieldNetwork`, fb) : fb;
    }
    if (m === `bloqueo-temporal`) {
      const s = (r && r.segundos) || 30;
      const fb = `Demasiados intentos fallidos. Espera ${s} s y vuelve a intentarlo — no hace falta que introduzcas nada ahora.`;
      return (typeof t === `function`) ? t(`msg.shieldLockout`, fb) : fb;
    }
    if (m === `overlay-suprimido`) {
      const fb = `Se necesita el PIN, pero no se pide con la máquina en marcha. Pausa o detén el trabajo y repite la acción.`;
      return (typeof t === `function`) ? t(`msg.shieldBusy`, fb) : fb;
    }
    const fb = `Acción bloqueada por el escudo de seguridad (PIN requerido) — vuelve a introducir el PIN o espera a que termine el bloqueo`;
    return (typeof t === `function`) ? t(`msg.shieldAbort`, fb) : fb;
  }

  // D-03 (15-sep): escudo para las rutas privilegiadas que NO pasan por
  // RRF.gcode — rr_filelist del pendant, rr_reset y los rr_upload de FM, macros
  // y restore. Sin el, un 401 sale como error generico y el PIN no se pide
  // nunca por ahi. Helper unico, no una quinta copia.
  // Con trabajo en marcha no se abre overlay (H-N6: taparia el boton rojo del
  // cockpit); con `motivo` de red no hay toast (culpa del cable, el poll ya lo
  // dice) pero se bloquea igual. true = se puede seguir.
  async function guard(baseIp, tag) {
    const A = window.rotechosAuth;
    if (!A || typeof A.tryConnect !== `function`) return true;
    const enTrabajo = (typeof SM !== `undefined` && typeof STATES !== `undefined`
      && (SM.current === STATES.RUNNING || SM.current === STATES.PAUSED));
    const r = await A.tryConnect(baseIp, ``, undefined, enTrabajo);
    if (r && r.ok) return true;
    if (typeof log === `function`) log(`${tag} abortado: escudo auth (${(r && r.motivo) || `rechazo`})`, `warn`);
    if (typeof toast === `function` && !(r && r.motivo === `network-error`)) toast(get(r), `warn`);
    return false;
  }

  if (typeof window.rotechosShieldMsg === `undefined`) {
    window.rotechosShieldMsg = { get, guard };
  }
})();
