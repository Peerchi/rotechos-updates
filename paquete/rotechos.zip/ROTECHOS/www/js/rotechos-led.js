/* ---
 * RotechOS — LED ANIMATION ENGINE v6 (Módulo Independiente)
 * Arquitectura Semántica SEDA vs RAYO — Time-Based Animation
 * --- */
const LED = window.LED = {
  N: 25,
  E: 0,
  _timer: null,
  _mode: null,
  _prevState: null,
  _sending: false,
  _lastLeds: null,
  _lastSentLeds: null,
  _lastSendTs: 0,
  _overlay: null,
  _gcodeHooked: false,
  _stateStart: 0,
  _crossfade: null,
  fps: 15, // Global FPS estandarizado (reducido para no saturar ESP32)
  /* Paleta industrial desaturada — colores elegantes y profesionales */
  _profiles: {
    IDLE: { r: 30, g: 50, b: 110, pct: 0.35, anim: "deepbreath" },
    READY: { r: 25, g: 120, b: 70, pct: 0.4, anim: "ready_pulse" },
    RUNNING: { r: 15, g: 30, b: 90, pct: 0.5, anim: "running_flow" },
    PAUSED: { r: 180, g: 80, b: 5, pct: 0.6, anim: "smoothpulse" },
    ERROR: { r: 140, g: 10, b: 12, pct: 1.0, anim: "pulse_error" },
  },
  
  _overlayDefs: {
    HOME_ALL: { mode: "ov_home_fill", durationMs: 9500, color: { r: 30, g: 60, b: 140, pct: 0.45 } },
    GOTO0: { mode: "ov_goto0", durationMs: 5200, color: { r: 25, g: 120, b: 70, pct: 0.4 } },
    PARK: { mode: "ov_park_fade", durationMs: 7000 },
    PROBE_Z: { mode: "ov_probe_z", durationMs: 6500, color: { r: 100, g: 30, b: 150, pct: 0.6 } },
    PROBE3D: { mode: "ov_probe3d", durationMs: 9000, color: { r: 15, g: 30, b: 90, pct: 0.5 } },

    // Nuevos Overlays SEDA vs RAYO
    SPINDLE_RAMP: { mode: "ov_spindle_ramp", durationMs: 3500, color: { r: 180, g: 80, b: 5, pct: 0.7 } },
    SPINDLE_BRAKE: { mode: "ov_spindle_brake", durationMs: 2500, color: { r: 10, g: 100, b: 120, pct: 0.7 } },
    THERMAL_WARNING: { mode: "ov_thermal", durationMs: 6000, color: { r: 160, g: 35, b: 10, pct: 0.8 } },
    CONFIG_MODE: { mode: "ov_config", durationMs: 0, color: { r: 90, g: 20, b: 150, pct: 0.5 } },
    ALARM_ESTOP: { mode: "ov_estop", durationMs: 0, color: { r: 140, g: 10, b: 12, pct: 1.0 } },

    TOOLCHANGE: { mode: "ov_toolchange_wait", durationMs: 0, color: { r: 180, g: 80, b: 5, pct: 0.6 } },
    JOB_DONE: { mode: "ov_job_done", durationMs: 7000, color: { r: 25, g: 120, b: 70, pct: 0.5 } },
    BOOT: { mode: "ov_boot", durationMs: 4200, color: { r: 30, g: 120, b: 90, pct: 0.5 } },
  },

  /* --- PRIORIDAD ENTRE OVERLAYS (Fase 4.13, t_27c1af02) --- */
  /* Por que existe: el orden entre overlays LED funcionaba POR ACCIDENTE.
   * El paro de emergencia ganaba al flujo de RUNNING porque
   * ALARM_ESTOP tenia durationMs: 0 (infinito) y startOverlay()
   * reemplazaba el activo. Si alguien edita esa duracion "para que se
   * apague solo", el operario vera el flujo azul de RUNNING con la
   * maquina parada. Es un fallo de seguridad silencioso: la animacion
   * es la UNICA senal que distingue paro de emergencia de paro normal
   * a 5 m (ver comentario _hookGcode lineas 142-148).
   *
   * Esta tabla convierte el orden en CONTRATO. Reglas:
   *   - ALARM_ESTOP = 200. Siempre pasa, nada lo pisa (exencion dura).
   *   - THERMAL_WARNING = 110. Sobre-driver termico gana al homing.
   *   - HOME_ALL / PROBE_Z / PROBE3D / PARK / GOTO0 = 100. Macros.
   *   - TOOLCHANGE / JOB_DONE = 90. Eventos de trabajo.
   *   - SPINDLE_RAMP / SPINDLE_BRAKE = 80. Husillo.
   *   - CONFIG_MODE = 70. Wifi / M552.
   *   - BOOT = 10. Unico de baja prioridad (la bienvenida).
   *
   * canStartOverlay(name) consulta esta tabla y rechaza si el activo
   * tiene mayor o igual prioridad, EXCEPTO si el nuevo es ALARM_ESTOP
   * (que SIEMPRE pasa). Cubierto por tests/unit/led-state-priority.test.js.
   */
  STATE_PRIORITY: {
    ALARM_ESTOP: 200,
    THERMAL_WARNING: 110,
    HOME_ALL: 100,
    GOTO0: 100,
    PARK: 100,
    PROBE_Z: 100,
    PROBE3D: 100,
    TOOLCHANGE: 90,
    JOB_DONE: 90,
    SPINDLE_RAMP: 80,
    SPINDLE_BRAKE: 80,
    CONFIG_MODE: 70,
    BOOT: 10,
  },

  /* canStartOverlay: ¿el overlay `name` puede desplazar al activo? */
  canStartOverlay(name) {
    // ALARM_ESTOP SIEMPRE pasa: nada pisa un paro de emergencia.
    if (name === "ALARM_ESTOP") return true;
    // Si no hay overlay activo, todo pasa.
    if (!this._overlay) return true;
    // Si el activo es ALARM_ESTOP, NADIE lo pisa (ni JOB_DONE ni
    // THERMAL_WARNING; el operario tiene que ver el estroboscopico
    // hasta que el operador confirme la salida del estado de error).
    if (this._overlay.name === "ALARM_ESTOP") return false;
    // Regla general: solo se pisa un overlay de menor prioridad.
    const incoming = this.STATE_PRIORITY[name];
    const active = this.STATE_PRIORITY[this._overlay.name];
    if (typeof incoming !== "number" || typeof active !== "number") {
      // Si una clave cae fuera de la tabla (futuro overlay sin catalogar),
      // NO desplazamos: seguridad > conveniencia. El que añade un nuevo
      // overlay tiene que catalogarlo en STATE_PRIORITY.
      return false;
    }
    return incoming > active;
  },
  
  cfg: { brightness: 128, on: true },

  /* --- t_194d645b: GANANCIA DE VISUALIZACIÓN DEL CANVAS ---
   * Por que existe: un LED WS2812 real a rgb(19,25,55) emite luz y se ve
   * perfectamente en el taller. Ese mismo rgb pintado sobre un canvas
   * oscuro en una pantalla es indistinguible del negro: la previsualización
   * es físicamente fiel e inútil en la práctica. Aplicamos una ganancia
   * SOLO al pintado para que el operario pueda juzgar el patrón que ha
   * elegido sin tocar el byte que sale hacia la tira.
   *
   * LIMITE INNEGOCIABLE: este factor se aplica EXCLUSIVAMENTE dentro de
   * `_drawPreview`, sobre los componentes que se pasan a `fillStyle` y
   * `shadowColor`. NO se aplica en `_scaleRGB`, `_scaleRawRGB`, `_sendSolid`
   * ni en la terna que sale hacia la placa. Si lo mueve, hay hardware
   * detrás y no hay banco para comprobarlo.
   *
   * Calculo del valor: con cfg.brightness por defecto (128) y pct=1.0,
   * el pico eléctrico del perfil ERROR es
   *   140 * (128/255) * 1.0 ≈ 70 sobre 255.
   * 70 * 3.0 = 210, que cae en la zona alta del rango (200..255) y deja
   * el orden relativo entre los cinco patrones:
   *   IDLE     19 * 3.0 = 57
   *   READY    24 * 3.0 = 72
   *   RUNNING  23 * 3.0 = 69
   *   PAUSED   54 * 3.0 = 162
   *   ERROR    70 * 3.0 = 210
   * El operario sigue percibiendo IDLE más apagado que PAUSED, y PAUSED
   * más apagado que ERROR — la diferencia entre estados sigue siendo
   * información, no se aplana. Cubierto por
   * tests/unit/led-preview-gain.test.js. */
  PREVIEW_GAIN: 3.0,
  
  init() {
    this.cfg.on = true;
    this.applyToUI();
    this._hookStateChange();
    this._hookUI();
    this._hookVisibility();
    this._hookGcode();
    this.startOverlay("BOOT");
  },
  
  save() {
    if (typeof cfgPersistComment === "function")
      cfgPersistComment("rotech-led", this.cfg.brightness);
  },
  
  applyToUI() {
    const el = (id) => $(id);
    if (el("ledRgbBrightness")) {
      el("ledRgbBrightness").value = this.cfg.brightness;
      el("ledRgbBrightnessVal").textContent = this.cfg.brightness;
    }
    if (el("ledRgbOn")) el("ledRgbOn").checked = this.cfg.on;
  },
  
  readFromUI() {
    const el = (id) => $(id);
    this.cfg.brightness = parseInt(el("ledRgbBrightness")?.value) || 128;
    this.cfg.on = el("ledRgbOn")?.checked ?? true;
  },
  
  _hookUI() {
    const sl = $(`ledRgbBrightness`), lbl = $(`ledRgbBrightnessVal`);
    if (sl && lbl) {
      sl.addEventListener("input", () => { lbl.textContent = sl.value; });
    }
    $$("[data-led-preview]").forEach((btn) => {
      btn.addEventListener("click", () => {
        this.readFromUI();
        $$("[data-led-preview]").forEach((b) => b.classList.remove("led-previewing"));
        btn.classList.add("led-previewing");
        const state = btn.getAttribute("data-led-preview");
        this._startForState(state, true);
      });
    });
    const onChk = $(`ledRgbOn`);
    if (onChk) {
      onChk.addEventListener("change", () => {
        this.readFromUI();
        if (!this.cfg.on) {
          this.stop();
          this._sendSolid(0, 0, 0);
        } else {
          this.onStateChange(typeof SM !== 'undefined' ? SM.current : 'IDLE');
        }
        this._updateDisabledBanner();
      });
    }
    // Fase 4.13 (t_27c1af02): sincronizar el banner con el estado
    // inicial. Si el operario recargo la pagina con la tira apagada,
    // el banner tiene que estar visible sin tener que tocar el toggle.
    this._updateDisabledBanner();
  },

  /* --- Banner de tira deshabilitada (Fase 4.13, t_27c1af02) --- */
  /* Por que existe: si el operario apaga la tira LED desde la pestana
   * CONFIGURACION > LED, el modulo LED apaga la salida y el panel se
   * queda mudo. El operario pierde la REDUNDANCIA entre color fisico y
   * color en pantalla: si la maquina entra en ERROR, no ve el rojo en
   * la tira. Esto era aceptable cuando la pantalla estaba al lado de
   * la maquina, pero no cuando se opera a distancia (el operador mira
   * el badge IDLE en pantalla y la tira fisica para confirmar).
   *
   * El banner es la senal explicita: "la tira fisica esta apagada; el
   * badge en pantalla sigue funcionando; si necesitas la redundancia,
   * vuelve a activar la tira". Asi el operario nunca confunde "no veo
   * color" con "la maquina esta en IDLE". */
  _updateDisabledBanner() {
    const banner = $("ledDisabledBanner");
    if (!banner) return;
    banner.style.display = this.cfg.on ? "none" : "";
  },
  
  _hookVisibility() {
    document.addEventListener("visibilitychange", () => {
      if (document.hidden) {
        if (this._timer) {
          clearInterval(this._timer);
          this._timer = null;
          this._wasRunning = {
            state: this._prevState,
            overlay: this._overlay ? { ...this._overlay } : null,
          };
        }
      } else if (this._wasRunning) {
        if (this._wasRunning.overlay) {
          this._overlay = this._wasRunning.overlay;
          this._mode = this._overlay.mode;
          this._timer = setInterval(() => this._tick(), 1000 / this.fps);
        } else {
          this._startForState(this._wasRunning.state);
        }
        this._wasRunning = null;
      }
    });
  },
  
  _hookGcode() {
    if (this._gcodeHooked || typeof RRF === "undefined" || typeof RRF.gcode !== "function") return;
    this._gcodeHooked = true;
    const orig = RRF.gcode.bind(RRF);
    // C§21: este envoltorio recibia solo `cmd` y se tragaba el segundo
    // argumento. REANUDAR y START mandan `RRF.gcode(cmd, {signal})` con la
    // senal del watchdog de 30 s (rotechos.js), y aqui se perdia: el watchdog
    // no podia abortar ese fetch. Lo acotaba el timeout propio de 15 s de
    // RRF.gcode, asi que el efecto era pequeno, pero cualquier `opts` futuro
    // se habria perdido igual y en silencio. `...rest`, como el envoltorio de
    // urgentGcode de aqui abajo, que si lo hacia bien.
    RRF.gcode = async (cmd, ...rest) => {
      try { this._onGcodeBefore(cmd); } catch (e) { LOG.warn("LED gcodeBefore:", e); }
      const res = await orig(cmd, ...rest);
      try { this._onGcodeAfter(cmd, res); } catch (e) { LOG.warn("LED gcodeAfter:", e); }
      return res;
    };
    // El E-Stop NO pasa por RRF.gcode: va por RRF.urgentGcode('M112')
    // (rotechos.js:2273 y el resto de rutas de paro). Sin envolverlo tambien,
    // _overlayFromCmd('M112') -> ALARM_ESTOP era codigo MUERTO y tras un paro de
    // emergencia el operario veia el destello suave de ERROR en vez del
    // estroboscopico rojo/blanco que este modulo documenta como alarma. En una
    // maquina esa es la senal por la que alguien a distancia distingue "parada
    // de emergencia" de "parada normal".
    if (typeof RRF.urgentGcode === "function") {
      const origUrgent = RRF.urgentGcode.bind(RRF);
      RRF.urgentGcode = (cmd, ...rest) => {
        // Antes de enviar, y sin await: el M112 tiene timeout de 600 ms y la
        // senal visual no puede esperar a la respuesta del firmware.
        try { this._onGcodeBefore(cmd); } catch (e) { LOG.warn("LED urgentBefore:", e); }
        return origUrgent(cmd, ...rest);
      };
    }
  },
  
  _hookStateChange() {
    if (typeof SM === "undefined" || this._stateHooked) return;
    this._stateHooked = true;
    const origTransition = SM.transition.bind(SM);
    SM.transition = (toState, reason) => {
      const ok = origTransition(toState, reason);
      try {
        if (ok) {
          if (toState === "READY" && /trabajo completado/i.test(String(reason ?? "")))
            this.startOverlay("JOB_DONE");
          if (this._overlay?.name === "TOOLCHANGE" && toState !== "PAUSED")
            this.endOverlay();
          // OJO: "HALTED" NO existe en STATES (rotechos.js:631 = IDLE/READY/
          // RUNNING/PAUSED/ERROR/SIMULATING; grep de HALTED en todo www/js = 0).
          // Esta rama es codigo MUERTO, residuo de un enum antiguo. NO se borra
          // aqui a proposito: la alarma ya se dispara por la via del M112
          // (_hookGcode envuelve tambien urgentGcode), y tocar la maquina de
          // estados para reintroducir un HALTED real es cambio de firmware y
          // sale PENDIENTE BANCO. Se deja documentado para que nadie vuelva a
          // darlo por funcionando.
          if (toState === "HALTED")
            this.startOverlay("ALARM_ESTOP"); // Parada de emergencia RRF
          else
            this.onStateChange(toState);
        }
      } catch (e) { LOG.warn("LED transition hook:", e); }
      return ok;
    };
    const origForce = SM.forceError.bind(SM);
    SM.forceError = (reason) => {
      origForce(reason);
      try {
        const rStr = String(reason || "").toLowerCase();
        if (rStr.includes("heater fault") || rStr.includes("temp")) {
          this.startOverlay("THERMAL_WARNING");
        } else {
          this.onStateChange("ERROR");
        }
      } catch (e) { LOG.warn("LED forceError hook:", e); }
    };
  },
  
  onStateChange(state) {
    if (!this.cfg.on) {
      this.stop();
      return;
    }
    if (this._overlay) {
      // Si estamos en un overlay, no lo cortamos, solo actualizamos a qué estado volverá.
      // Excepto si es ALARM_ESTOP (nada puede cortarlo a menos que salga del HALTED).
      this._prevState = state;
      this._updateHud();
      return;
    }
    if (state === this._prevState && this._mode) return;
    $$("[data-led-preview]").forEach((b) => b.classList.remove("led-previewing"));
    this._startForState(state);
    this._updateHud();
  },

  /* --- HUD: estado activo + patron activo en la pestana LED --- */
  /* Fase 4.13 (t_27c1af02): el operario veia el canvas pero no sabia
   * que estado de la maquina estaba representando. Esto escribe los
   * dos spans #ledStateActive y #ledPatternActive con la traduccion
   * del estado SM.current y del _mode (animacion o overlay) en curso.
   * Es SOLO presentacion: el LED es redundancia, el contrato vive en
   * _hookStateChange + startOverlay. Si _hookGcode dispara un nuevo
   * overlay, endOverlay restaura el estado "base" anterior. */
  _PATTERN_LABELS: {
    deepbreath: "Respiración profunda",
    ready_pulse: "Fade-in → estático",
    running_flow: "Flujo de trabajo",
    smoothpulse: "Latido suave",
    pulse_error: "Pulso 1 Hz (alarma)",
    ov_home_fill: "HOMING — llenado progresivo",
    ov_goto0: "IR A 0 — convergencia atenuada",
    ov_park_fade: "APARCAR — apagado orgánico",
    ov_probe_z: "SONDA Z — probing",
    ov_probe3d: "SONDA 3D — barrido",
    ov_spindle_ramp: "HUSILLO — ramp-up (M3)",
    ov_spindle_brake: "HUSILLO — ramp-down (M5)",
    ov_thermal: "ALARMA TÉRMICA — onda de calor",
    ov_config: "MODO CONFIG — cylon púrpura",
    ov_estop: "PARO EMERGENCIA — estroboscópico",
    ov_toolchange_wait: "CAMBIO HTA — espera",
    ov_job_done: "TRABAJO COMPLETADO — celebración",
    ov_boot: "ARRANQUE — secuencia de bienvenida",
  },
  _updateHud() {
    const sEl = $("ledStateActive");
    const pEl = $("ledPatternActive");
    if (!sEl || !pEl) return;
    const smState = (typeof SM !== "undefined" && SM.current) ? SM.current : "—";
    // Nombre del estado como en la cabecera (INACTIVO, LISTO...), no la clave interna (IDLE).
    const meta = (typeof STATE_META !== "undefined") ? STATE_META[smState] : null;
    sEl.textContent = meta ? t(meta.key, meta.fallback) : smState;
    const modeLabel = t(`led.pat.${this._mode}`, this._PATTERN_LABELS[this._mode] || this._mode || "—");
    pEl.textContent = modeLabel;
  },
  
  stop() {
    if (this._timer) {
      clearInterval(this._timer);
      this._timer = null;
    }
    this._mode = null;
    this._crossfade = null;
  },
  
  startOverlay(name, opts = {}) {
    const def = this._overlayDefs[name];
    if (!def || !this.cfg.on) return;

    // Fase 4.13 (t_27c1af02): consulta el contrato de prioridad antes de
    // aplicar. Si el activo tiene mayor o igual prioridad Y el nuevo no
    // es ALARM_ESTOP, NO desplazamos. Esto convierte el comportamiento
    // actual (que funcionaba por accidente) en un contrato explicito.
    if (!this.canStartOverlay(name)) {
      return;
    }

    const currentRGB = this._getCurrentRGB();
    this.stop();
    const now = Date.now();
    let duration = def.durationMs;
    
    // Si viene de un comando de larga duración física, extendemos la animación a infinito (0)
    // para que finalice exactamente cuando la placa termine de procesar el G-code.
    if (opts.fromCmd && /\b(m98|g28|g29|m6)\b/i.test(opts.fromCmd)) {
      duration = 0;
    }
    
    this._overlay = {
      name,
      mode: def.mode,
      startAt: now,
      endAt: duration ? now + duration : 0,
      fromCmd: opts.fromCmd || null,
      data: opts.data || {},
    };
    
    const fromLeds = this._lastLeds ? this._lastLeds.map(c => [...c]) : Array.from({ length: this.N }, () => [0, 0, 0]);
    this._crossfade = { fromLeds, startMs: now, durMs: 300 };
    
    if (name === "PARK") this._overlay.data.startRGB = currentRGB || [0,0,0];

    this._mode = def.mode;
    this._stateStart = now;
    this._tick();
    this._timer = setInterval(() => this._tick(), 1000 / this.fps);
    this._updateHud();
  },

  endOverlay() {
    if (!this._overlay) return;
    this._overlay = null;
    this.stop();
    this.onStateChange(typeof SM !== 'undefined' ? SM.current : 'IDLE');
    this._updateHud();
  },
  
  _startForState(state, once) {
    this.stop();
    this._prevState = state;
    const profile = this._profiles[state];
    if (!profile) {
      this._sendSolid(0, 0, 0);
      return;
    }
    
    const now = Date.now();
    const fromLeds = this._lastLeds ? this._lastLeds.map(c => [...c]) : Array.from({ length: this.N }, () => [0, 0, 0]);
    this._crossfade = { fromLeds, startMs: now, durMs: 500 };
    
    this._mode = profile.anim;
    this._once = !!once;
    this._stateStart = now;
    
    // Si estamos probando la UI (once = true), la duración forzada es ~4 segundos
    this._previewEndAt = once ? now + 4000 : 0;
    
    this._tick();
    this._timer = setInterval(() => this._tick(), 1000 / this.fps);
  },
  
  _tick() {
    if (this._sending) return;
    const now = Date.now();
    
    if (this._overlay?.endAt && now >= this._overlay.endAt) {
      this.endOverlay();
      return;
    }
    if (this._once && now >= this._previewEndAt) {
      this.stop();
      return;
    }
    
    const tMs = now - this._stateStart; // Tiempo desde que inició la animación
    const m = this._mode;
    
    if (m === "deepbreath") this._animDeepBreath(tMs);
    else if (m === "ready_pulse") this._animReadyPulse(tMs);
    else if (m === "running_flow") this._animRunningFlow(tMs);
    else if (m === "smoothpulse") this._animSmoothPulse(tMs);
    else if (m === "pulse_error") this._animPulseError(tMs);
    else if (m === "ov_home_fill") this._animOvHomeFill(tMs);
    else if (m === "ov_goto0") this._animOvGoto0(tMs);
    else if (m === "ov_park_fade") this._animOvParkFade(tMs);
    else if (m === "ov_probe_z") this._animOvProbeZ(tMs);
    else if (m === "ov_probe3d") this._animOvProbe3d(tMs);
    else if (m === "ov_spindle_ramp") this._animOvSpindleRamp(tMs);
    else if (m === "ov_spindle_brake") this._animOvSpindleBrake(tMs);
    else if (m === "ov_thermal") this._animOvThermal(tMs);
    else if (m === "ov_config") this._animOvConfig(tMs);
    else if (m === "ov_estop") this._animOvEstop(tMs);
    else if (m === "ov_toolchange_wait") this._animOvToolchangeWait(tMs);
    else if (m === "ov_job_done") this._animOvJobDone(tMs);
    else if (m === "ov_boot") this._animOvBoot(tMs);
  },
  
  _onGcodeBefore(cmd) {
    const s = String(cmd ?? "");
    if (!s || /\bM150\b/i.test(s)) return;
    if (this._overlay?.name === "TOOLCHANGE" && /\b(M24|M0|M5)\b/i.test(s))
      this.endOverlay();
    
    const ov = this._overlayFromCmd(s);
    if (ov) this.startOverlay(ov, { fromCmd: s });
  },
  
  _onGcodeAfter(cmd, res) {
    if (!this._overlay || !this._overlay.fromCmd) return;
    if (this._overlay.fromCmd === String(cmd ?? "") && !res) {
      // Si el comando terminó y el overlay era de duración infinita (ej. macros),
      // lo cortamos ahora. Si tenía una duración fija, dejamos que termine por tiempo.
      if (this._overlay.endAt === 0) {
        this.endOverlay();
      }
    }
  },
  
  _overlayFromCmd(cmd) {
    const s = String(cmd ?? ""), l = s.toLowerCase();
    
    // Parada de Emergencia (E-Stop)
    if (/\bm112\b/.test(l)) return "ALARM_ESTOP";
    
    // Spindle Start / Stop
    if (/\bm3\b/.test(l)) return "SPINDLE_RAMP";
    if (/\bm5\b/.test(l)) return "SPINDLE_BRAKE";
    
    // Config / WIFI
    if (/\bm552\b/.test(l)) return "CONFIG_MODE";
    
    // Macros
    if (/\bm98\b/.test(l)) {
      if (l.includes("0:/sys/homeall.g")) return "HOME_ALL";
      if (l.includes("0:/macros/goto0.g")) return "GOTO0";
      if (l.includes("0:/macros/park.g")) return "PARK";
      if (l.includes("0:/macros/sonda_z.g")) return "PROBE_Z";
      if (l.includes("0:/macros/probe3d.g")) return "PROBE3D";
      if (/warm|calent/.test(l)) return "SPINDLE_RAMP"; // Reutilizamos el efecto rampa para macros de calentamiento
    }
    // Nota: toolchange.g fue eliminado (rotechos.js:3338). M6 suelto lo captura
    // la regex de la línea siguiente, no hace falta rama dedicada.
    
    if (/\bg28\b/i.test(s)) return "HOME_ALL";
    if (/\bg29\b/i.test(s)) return "PROBE3D";
    if (/\bm6\b/i.test(s)) return "TOOLCHANGE";
    
    return null;
  },
  
  /* --- Utilidades Matemáticas y de Color --- */
  _scaleRGB(p, f) {
    const b = this.cfg.brightness / 255;
    return [
      Math.round(p.r * b * p.pct * f),
      Math.round(p.g * b * p.pct * f),
      Math.round(p.b * b * p.pct * f)
    ];
  },
  
  _scaleRawRGB(rgb, f) {
    const b = this.cfg.brightness / 255;
    return [
      Math.round(rgb[0] * b * f),
      Math.round(rgb[1] * b * f),
      Math.round(rgb[2] * b * f)
    ];
  },
  
  _clamp(v, min, max) { return Math.max(min, Math.min(max, v)); },
  
  _smooth(v) {
    v = this._clamp(v, 0, 1);
    return v * v * (3 - 2 * v);
  },
  
  _lerp(a, b, t) { return a + (b - a) * t; },
  
  _getCurrentRGB() {
    if (Array.isArray(this._lastLeds) && this._lastLeds[0])
      return this._lastLeds[0].slice(0, 3);
    return null;
  },
  
  _sendSolid(r, g, b) {
    const leds = Array.from({ length: this.N }, () => [r, g, b]);
    this._sendLeds(leds);
  },
  
  async _sendLeds(leds) {
    if (this._crossfade) {
      const now = Date.now();
      let t = (now - this._crossfade.startMs) / this._crossfade.durMs;
      if (t >= 1) {
        this._crossfade = null;
      } else {
        t = this._smooth(t);
        const from = this._crossfade.fromLeds;
        leds = leds.map((c, i) => {
          const fColor = from[i] || from[0] || [0, 0, 0];
          return [
            Math.round(this._lerp(fColor[0], c[0], t)),
            Math.round(this._lerp(fColor[1], c[1], t)),
            Math.round(this._lerp(fColor[2], c[2], t))
          ];
        });
      }
    }
    
    if (this._ledsUnchanged(leds)) {
      this._drawPreview(leds);
      return;
    }
    
    // THROTTLE DE RED INTELIGENTE (Delta Diffing)
    const now = Date.now();
    if (now - (this._lastSendTs || 0) < 250) {
      this._drawPreview(leds);
      return;
    }
    
    let totalDiff = 0;
    if (this._lastSentLeds) {
      for (let i = 0; i < this.N; i++) {
        const a = this._lastSentLeds[i];
        const b = leds[i];
        totalDiff += Math.abs(a[0] - b[0]) + Math.abs(a[1] - b[1]) + Math.abs(a[2] - b[2]);
      }
    } else {
      totalDiff = 99999;
    }
    
    if (totalDiff < 150 && (now - (this._lastSendTs || 0)) < 1000) {
      this._drawPreview(leds);
      return;
    }
    
    this._lastSendTs = now;
    this._lastSentLeds = leds.map(c => [...c]);
    this._sending = true;
    this._drawPreview(leds);
    
    try {
      // Optimización de comandos solidos vs individuales
      let isSolid = true;
      const first = leds[0];
      for (let i = 1; i < this.N; i++) {
        if (leds[i][0] !== first[0] || leds[i][1] !== first[1] || leds[i][2] !== first[2]) {
          isSolid = false;
          break;
        }
      }
      
      // 27-sep (análisis de la interfaz, A3): un fotograma LED a LED eran 25 órdenes M150 en un solo
      // rr_gcode (~580 bytes), y RRF 3.5.4 guarda como mucho 256 bytes por petición en el canal HTTP
      // (GCodeInput.h:17); si no cabe, NetworkGCodeInput::Put lo rechaza entero (GCodeInput.cpp:220-237)
      // y contesta {"err":1}: en la placa la animación no llegaba nunca a la tira. Ahora se agrupan los
      // LED contiguos del mismo color (S = cuántos) y, si aun así no cabe, se manda el color medio.
      // keepPoll: no reinicia el sondeo en cada fotograma.
      const cmd = isSolid
        ? `M150 E${this.E} R${first[0]} U${first[1]} B${first[2]} S${this.N} F0`
        : this._frameCmd(leds);
      await RRF.gcode(cmd, { keepPoll: true });
    } finally {
      this._sending = false;
    }
  },
  
  // Fotograma como UNA petición que quepa en el búfer HTTP de RRF (256 bytes con el NUL final):
  // tramos de LED contiguos del mismo color con S = longitud del tramo; si no cabe, color medio.
  _frameCmd(leds) {
    const MAX = 240;
    const runs = [];
    for (let i = 0; i < leds.length; i++) {
      const c = leds[i];
      const last = runs[runs.length - 1];
      if (last && last.c[0] === c[0] && last.c[1] === c[1] && last.c[2] === c[2]) last.n++;
      else runs.push({ c, n: 1 });
    }
    const lines = runs.map((r, k) => `M150 E${this.E} R${r.c[0]} U${r.c[1]} B${r.c[2]} S${r.n}${k === runs.length - 1 ? " F0" : " F2"}`);
    const joined = lines.join("\n");
    if (joined.length <= MAX) return joined;
    const avg = [0, 1, 2].map((j) => Math.round(leds.reduce((a, c) => a + c[j], 0) / leds.length));
    return `M150 E${this.E} R${avg[0]} U${avg[1]} B${avg[2]} S${leds.length} F0`;
  },

  _ledsUnchanged(leds) {
    if (!this._lastLeds || this._lastLeds.length !== leds.length) {
      this._lastLeds = leds;
      return false;
    }
    for (let i = 0; i < leds.length; i++) {
      const a = this._lastLeds[i], b = leds[i];
      if (a[0] !== b[0] || a[1] !== b[1] || a[2] !== b[2]) {
        this._lastLeds = leds;
        return false;
      }
    }
    return true;
  },
  
  _drawPreview(leds) {
    const cv = $(`ledPreviewCanvas`);
    if (!cv) return;
    const ctx = cv.getContext("2d"), w = cv.width, h = cv.height, lw = w / this.N;
    ctx.clearRect(0, 0, w, h);
    // t_194d645b: la ganancia de visualización SOLO se aplica a los
    // componentes que se pasan a fillStyle/shadowColor. La terna `leds`
    // original (la que sale por _sendLeds hacia _sendSolid y de ahí a la
    // tira via M150) queda INTACTA: el hardware recibe exactamente los
    // mismos bytes que antes de este cambio. clamp 0..255 para que un
    // factor >1 sobre un perfil claro (ej. ERROR con brightness 255) no
    // desborde ni pinte "rgb(280,...)".
    const g = this.PREVIEW_GAIN;
    leds.forEach((c, i) => {
      const pr = Math.min(255, Math.round(c[0] * g));
      const pg = Math.min(255, Math.round(c[1] * g));
      const pb = Math.min(255, Math.round(c[2] * g));
      ctx.fillStyle = `rgb(${pr},${pg},${pb})`;
      ctx.shadowColor = `rgb(${pr},${pg},${pb})`;
      ctx.shadowBlur = 6;
      ctx.beginPath();
      ctx.roundRect(i * lw + 1, 2, lw - 2, h - 4, 3);
      ctx.fill();
    });
    ctx.shadowBlur = 0;
  },
  
  /* --- BASE PROFILES (Time-Based) --- */
  
  // IDLE: SEDA. Respiración de 12s, rango 30% -> 80% (Blue)
  _animDeepBreath(tMs) {
    const cycle = 12000;
    const phase = (tMs % cycle) / cycle; // 0 a 1
    // Seno de 0 a PI*2, mapeado de 0 a 1
    let f = (Math.sin(phase * Math.PI * 2 - Math.PI/2) + 1) / 2;
    f = 0.3 + 0.5 * f; // Entre 0.3 y 0.8
    const [r, g, b] = this._scaleRGB(this._profiles.IDLE, f);
    this._sendSolid(r, g, b);
  },
  
  // READY: SEDA. Fade-in inicial rápido (2.5s) y luego un latido levísimo (90% - 100%)
  _animReadyPulse(tMs) {
    const p = this._profiles.READY;
    if (tMs < 2500) {
      const f = this._smooth(tMs / 2500);
      const [r, g, b] = this._scaleRGB(p, f);
      this._sendSolid(r, g, b);
    } else {
      const cycle = 4000;
      const phase = (tMs % cycle) / cycle;
      let f = (Math.sin(phase * Math.PI * 2) + 1) / 2;
      f = 0.9 + 0.1 * f; // Latido entre 0.9 y 1.0
      const [r, g, b] = this._scaleRGB(p, f);
      this._sendSolid(r, g, b);
    }
  },
  
  // RUNNING: SEDA (Flujo). Una onda gélida que viaja por la tira, acelerando según el movimiento real de la máquina.
  _animRunningFlow(tMs) {
    const p = this._profiles.RUNNING;
    
    // Inicializar o restablecer en el primer frame
    if (tMs < 50 || !this._lastFlowTs) {
      this._lastFlowTs = Date.now();
      this._prevPos = null;
      this._moveSpeed = 0;
      this._flowOffset = 0;
    }
    
    // Sincronización con velocidad real de la máquina (DRO.wcs)
    if (typeof DRO !== "undefined" && Array.isArray(DRO.wcs)) {
      const nowPos = DRO.wcs.slice(0, 3);
      let dist = 0;
      if (this._prevPos) {
        dist = Math.sqrt(
          Math.pow(nowPos[0] - this._prevPos[0], 2) +
          Math.pow(nowPos[1] - this._prevPos[1], 2) +
          Math.pow(nowPos[2] - this._prevPos[2], 2)
        );
      }
      this._prevPos = nowPos;
      // Filtro paso bajo (suavizado)
      this._moveSpeed = (this._moveSpeed || 0) * 0.85 + dist * 0.15;
    }
    
    const now = Date.now();
    const dt = now - this._lastFlowTs;
    this._lastFlowTs = now;
    
    // Mapear velocidad a multiplicador de flujo (drift básico a 1.0x, aceleración hasta 5.0x)
    let mult = 1.0;
    if (this._moveSpeed > 0.0001) {
      mult = 1.0 + Math.min(this._moveSpeed * 12, 4.0);
    }
    
    // Base: 1 LED cada 800ms (0.00125 LEDs/ms)
    const baseSpeed = 0.00125;
    this._flowOffset = (this._flowOffset + dt * baseSpeed * mult) % this.N;
    const offset = this._flowOffset;
    
    const leds = Array.from({ length: this.N }, (_, i) => {
      // Distancia envuelta (wrap-around)
      let d = Math.abs(i - offset);
      if (d > this.N / 2) d = this.N - d; 
      
      let f = 1 - (d / (this.N / 1.5));
      f = this._clamp(f, 0, 1);
      f = 0.7 + 0.3 * this._smooth(f); // Brillo base 70%, pico al 100%
      return this._scaleRGB(p, f);
    });
    this._sendLeds(leds);
  },
  
  // PAUSED: SEDA. Naranja latido 4s (5% -> 100%)
  _animSmoothPulse(tMs) {
    const cycle = 4000;
    const phase = (tMs % cycle) / cycle;
    let f = (Math.sin(phase * Math.PI * 2 - Math.PI/2) + 1) / 2;
    f = 0.05 + 0.95 * f;
    const [r, g, b] = this._scaleRGB(this._profiles.PAUSED, f);
    this._sendSolid(r, g, b);
  },
  
  // ERROR: RAYO. Destello estroboscópico agresivo rojo.
  _animPulseError(tMs) {
    const cycle = 1000; // 1Hz = 1000ms
    const t = tMs % cycle;
    // Doble parpadeo rápido en los primeros 300ms
    const on = (t < 100) || (t > 200 && t < 300);
    if (on) {
      const [r, g, b] = this._scaleRGB(this._profiles.ERROR, 1);
      this._sendSolid(r, g, b);
    } else {
      this._sendSolid(0, 0, 0);
    }
  },
  
  /* --- NUEVOS OVERLAYS --- */
  
  // SPINDLE RAMP: Vúmetro desde el centro (Ámbar), dinámico con las RPM reales
  _animOvSpindleRamp(tMs) {
    const def = this._overlayDefs.SPINDLE_RAMP;
    
    // Obtener RPM reales y calcular ratio
    const rpmText = $("sRPM")?.textContent || "0";
    const currentRpm = parseInt(rpmText.replace(/\D/g, "")) || 0;
    const maxRpm = (typeof CFG !== "undefined" && CFG.maxRPM) || 24000;
    const rpmPct = maxRpm > 0 ? Math.min(currentRpm / maxRpm, 1.0) : 0;
    
    // Mezcla de progreso basado en tiempo y progreso real (redundancia)
    const timeProgress = this._clamp(tMs / def.durationMs, 0, 1);
    const progress = Math.max(timeProgress, rpmPct);
    
    const t = this._smooth(progress);
    const mid = Math.floor(this.N / 2);
    const head = Math.floor(t * mid);
    
    const leds = Array.from({ length: this.N }, (_, i) => {
      const d = Math.abs(i - mid);
      if (d <= head) {
        const f = (d === head) ? 1.0 : 0.7;
        return this._scaleRGB(def.color, f);
      }
      return [0, 0, 0];
    });
    this._sendLeds(leds);
  },
  
  // SPINDLE BRAKE: Flash expansivo cian + vu-meter retráctil según deceleración de RPM
  _animOvSpindleBrake(tMs) {
    const def = this._overlayDefs.SPINDLE_BRAKE;
    
    // Obtener RPM reales
    const rpmText = $("sRPM")?.textContent || "0";
    const currentRpm = parseInt(rpmText.replace(/\D/g, "")) || 0;
    const maxRpm = (typeof CFG !== "undefined" && CFG.maxRPM) || 24000;
    const rpmPct = maxRpm > 0 ? Math.min(currentRpm / maxRpm, 1.0) : 0;
    
    const timeProgress = this._clamp(tMs / def.durationMs, 0, 1);
    const progress = Math.min(1 - timeProgress, rpmPct);
    
    const mid = Math.floor(this.N / 2);
    const head = Math.floor(progress * mid);
    
    const leds = Array.from({ length: this.N }, (_, i) => {
      const d = Math.abs(i - mid);
      if (d <= head) {
        const f = (1 - timeProgress) * 0.8;
        return this._scaleRGB(def.color, f);
      }
      return [0, 0, 0];
    });
    this._sendLeds(leds);
  },
  
  // THERMAL WARNING: Onda de brasas incandescentes que se expande desde el centro (calor radiante).
  _animOvThermal(tMs) {
    const def = this._overlayDefs.THERMAL_WARNING;
    const speed = 400; // ms por LED de propagación
    const offset = (tMs / speed) % (this.N / 2);
    const mid = (this.N - 1) / 2;
    
    const leds = Array.from({ length: this.N }, (_, i) => {
      const d = Math.abs(i - mid);
      const distToWave = Math.abs(d - offset);
      const wavePeak = Math.exp(-(distToWave * distToWave) / 5.0); // Ancho de la onda
      const pulse = 0.15 + 0.15 * (Math.sin(tMs / 300) + 1) / 2;
      const finalF = this._clamp(wavePeak * 0.7 + pulse, 0, 1);
      return this._scaleRGB(def.color, finalF);
    });
    this._sendLeds(leds);
  },
  
  // CONFIG MODE: Cylon púrpura (RAYO Suave)
  _animOvConfig(tMs) {
    const def = this._overlayDefs.CONFIG_MODE;
    const cycle = 2000;
    const t = (tMs % cycle) / cycle;
    // Ping pong de 0 a 1 y vuelta a 0
    const head = (t < 0.5 ? t * 2 : 2 - t * 2) * (this.N - 1);
    const width = 2.5;
    
    const leds = Array.from({ length: this.N }, (_, i) => {
      const d = Math.abs(i - head);
      if (d > width) return [0, 0, 0];
      const f = this._clamp(1 - (d / width), 0, 1);
      return this._scaleRGB(def.color, f);
    });
    this._sendLeds(leds);
  },
  
  // ALARM_ESTOP: RAYO (Estroboscópico Rojo/Blanco)
  _animOvEstop(tMs) {
    const cycle = 200; // 5 Hz alternancia
    const phase = (tMs % cycle) / cycle;
    if (phase < 0.5) {
      // Rojo
      const [r, g, b] = this._scaleRGB(this._overlayDefs.ALARM_ESTOP.color, 1);
      this._sendSolid(r, g, b);
    } else {
      // Blanco
      const bVal = Math.round(255 * (this.cfg.brightness / 255));
      this._sendSolid(bVal, bVal, bVal);
    }
  },
  
  /* --- OLD OVERLAYS (Refactorizados a tMs) --- */
  
  _animOvHomeFill(tMs) {
    const def = this._overlayDefs.HOME_ALL;
    const total = def.durationMs;
    const fillTime = total * 0.7; // 70% llenando
    const p = def.color;
    
    if (tMs < fillTime) {
      const t = this._smooth(tMs / fillTime);
      const head = t * (this.N - 1);
      const leds = Array.from({ length: this.N }, (_, i) => {
        const d = head - i;
        if (d < 0) return [0, 0, 0];
        const f = this._clamp(1 - d / 5, 0, 1);
        return this._scaleRGB(p, f);
      });
      this._sendLeds(leds);
    } else {
      const t = (tMs - fillTime) / (total - fillTime);
      const wave = t < 0.5 ? t * 2 : (1 - t) * 2;
      const f = 0.5 + 0.5 * this._smooth(wave);
      const [r, g, b] = this._scaleRGB(p, f);
      this._sendSolid(r, g, b);
    }
  },
  
  _animOvGoto0(tMs) {
    const def = this._overlayDefs.GOTO0;
    const t = this._smooth(this._clamp(tMs / def.durationMs, 0, 1));
    const left = (t * (this.N - 1)) / 2;
    const right = this.N - 1 - left;
    const sigma = 1.8;
    const leds = Array.from({ length: this.N }, (_, i) => {
      const d1 = i - left, d2 = i - right;
      const f = Math.max(
        Math.exp(-(d1 * d1) / (2 * sigma * sigma)),
        Math.exp(-(d2 * d2) / (2 * sigma * sigma))
      );
      return this._scaleRGB(def.color, this._clamp(f, 0, 1));
    });
    this._sendLeds(leds);
  },
  
  _animOvParkFade(tMs) {
    const def = this._overlayDefs.PARK;
    const t = this._smooth(this._clamp(tMs / def.durationMs, 0, 1));
    const f = this._lerp(1, 0.05, t);
    const base = this._overlay?.data?.startRGB || [0,0,0];
    const [r, g, b] = this._scaleRawRGB(base, f);
    this._sendSolid(r, g, b);
  },
  
  _animOvProbeZ(tMs) {
    const def = this._overlayDefs.PROBE_Z;
    const travelTime = def.durationMs * 0.8;
    
    if (tMs >= travelTime) {
      // Blinking
      const blinkCycle = 200;
      const on = ((tMs - travelTime) % blinkCycle) < (blinkCycle/2);
      if (on) {
        const [r, g, b] = this._scaleRGB(def.color, 1);
        this._sendSolid(r, g, b);
      } else {
        this._sendSolid(0, 0, 0);
      }
    } else {
      const phase = tMs / travelTime;
      const bounce = phase < 0.5 ? phase * 2 : (1 - phase) * 2;
      const head = Math.round(this._smooth(bounce) * (this.N - 1));
      const w = 4;
      const leds = Array.from({ length: this.N }, (_, i) => {
        const d = Math.abs(i - head);
        if (d > w) return [0, 0, 0];
        const f = this._clamp(1 - d / (w + 0.01), 0, 1) * 0.6;
        return this._scaleRGB(def.color, f);
      });
      this._sendLeds(leds);
    }
  },
  
  _animOvProbe3d(tMs) {
    const def = this._overlayDefs.PROBE3D;
    const t = this._clamp(tMs / def.durationMs, 0, 1);
    const head = t * (this.N - 1);
    const leds = Array.from({ length: this.N }, (_, i) => {
      const d = head - i;
      if (d < 0) return [0, 0, 0];
      const f = Math.exp(-d / 5.5);
      return this._scaleRGB(def.color, this._clamp(f, 0, 1));
    });
    this._sendLeds(leds);
  },
  
  _animOvToolchangeWait(tMs) {
    const p = this._overlayDefs.TOOLCHANGE.color;
    const cycle = 4000;
    const phase = (tMs % cycle) / cycle;
    let f = (Math.sin(phase * Math.PI * 2 - Math.PI/2) + 1) / 2;
    f = 0.2 + 0.8 * this._smooth(f);
    const [r, g, b] = this._scaleRGB(p, f);
    this._sendSolid(r, g, b);
  },
  
  _animOvJobDone(tMs) {
    const def = this._overlayDefs.JOB_DONE;
    const rise = def.durationMs * 0.35;
    const hold = def.durationMs * 0.3;
    const fade = def.durationMs - rise - hold;
    
    if (tMs < rise) {
      const t = this._smooth(tMs / rise);
      const c = (this.N - 1) / 2;
      const head = t * (this.N / 2);
      
      const leds = Array.from({ length: this.N }, (_, i) => {
        const d = Math.abs(i - c);
        if (d <= head) {
          const waveDist = Math.abs(d - head);
          const flash = Math.exp(-waveDist / 1.5); 
          const base = this._scaleRGB(def.color, 0.7);
          const b = this.cfg.brightness / 255;
          
          return [
            Math.round(this._lerp(base[0], 255 * b, flash)),
            Math.round(this._lerp(base[1], 255 * b, flash)),
            Math.round(this._lerp(base[2], 255 * b, flash))
          ];
        }
        return [0, 0, 0];
      });
      this._sendLeds(leds);
    } else if (tMs < rise + hold) {
      const baseColor = this._scaleRGB(def.color, 1.0);
      const glow = Math.round(40 * (this.cfg.brightness / 255));
      this._sendSolid(
        this._clamp(baseColor[0] + glow, 0, 255),
        this._clamp(baseColor[1] + glow, 0, 255),
        this._clamp(baseColor[2] + glow, 0, 255)
      );
    } else {
      const t = this._smooth((tMs - rise - hold) / fade);
      const baseColor = this._scaleRGB(def.color, 1.0);
      const glow = Math.round(40 * (this.cfg.brightness / 255));
      const a = [
        this._clamp(baseColor[0] + glow, 0, 255),
        this._clamp(baseColor[1] + glow, 0, 255),
        this._clamp(baseColor[2] + glow, 0, 255)
      ];
      const b = this._scaleRGB(this._profiles.IDLE, 1.0);
      this._sendSolid(
        Math.round(this._lerp(a[0], b[0], t)),
        Math.round(this._lerp(a[1], b[1], t)),
        Math.round(this._lerp(a[2], b[2], t))
      );
    }
  },
  
  _animOvBoot(tMs) {
    const def = this._overlayDefs.BOOT;
    const total = def.durationMs;
    const fill = total * 0.55;
    const hold = total * 0.2;
    const fade = total - fill - hold;
    
    if (tMs < fill) {
      const t = this._smooth(tMs / fill);
      const head = t * (this.N - 1);
      
      const leds = Array.from({ length: this.N }, (_, i) => {
        const d = head - i;
        if (d < 0) return [0, 0, 0];
        
        const trail = Math.exp(-d / 6.0);
        const base = this._scaleRGB(this._profiles.IDLE, trail);
        
        const headDist = Math.abs(i - head);
        const scan = Math.exp(-(headDist * headDist) / 1.5);
        const b = this.cfg.brightness / 255;
        
        return [
          Math.round(this._lerp(base[0], 255 * b, scan)),
          Math.round(this._lerp(base[1], 255 * b, scan)),
          Math.round(this._lerp(base[2], 255 * b, scan))
        ];
      });
      this._sendLeds(leds);
    } else if (tMs < fill + hold) {
      const pulse = (tMs - fill) / hold;
      const f = 0.7 + 0.3 * (Math.sin(pulse * Math.PI * 2 - Math.PI/2) + 1) / 2;
      const [r, g, b] = this._scaleRGB(this._profiles.IDLE, f);
      this._sendSolid(r, g, b);
    } else {
      const t = this._smooth((tMs - fill - hold) / fade);
      const a = this._scaleRGB(this._profiles.IDLE, 0.7);
      const targetState = typeof SM !== 'undefined' ? SM.current : 'IDLE';
      const pTarget = this._profiles[targetState] || this._profiles.IDLE;
      const b = this._scaleRGB(pTarget, 1.0);
      this._sendSolid(
        Math.round(this._lerp(a[0], b[0], t)),
        Math.round(this._lerp(a[1], b[1], t)),
        Math.round(this._lerp(a[2], b[2], t))
      );
    }
  }
};
document.addEventListener("DOMContentLoaded", () => setTimeout(() => LED.init(), 800));
