/* ---
 * rotechos-dom.js — Helpers de acceso al DOM
 *
 * Centraliza los ~78 accesos directos a `document.getElementById` /
 * `document.querySelector` / `document.querySelectorAll` que existían
 * dispersos por rotechos.js (66), rotechos-led.js (5), rotechos-viz.js (3),
 * rotechos-ota.js (2) y rotechos-i18n.js (2).
 *
 * IMPORTANTE — Compatibilidad con el código existente:
 * rotechos.js ya define en línea 18-19:
 *   const $  = (id)  => document.getElementById(id);
 *   const $$ = (sel) => document.querySelectorAll(sel);
 *
 * Esos helpers siguen EXISTIENDO y conservando su semántica:
 *   - `$(id)` sigue siendo SOLO para IDs puros (sin '#').
 *   - `$$(sel)` sigue siendo `querySelectorAll`.
 *
 * Este módulo AÑADE dos helpers nuevos para los casos que NO cubrían:
 *   - `$q(sel, root?)` → `querySelector` (selector CSS, admite '#', '.', etc.)
 *   - `$qa(sel, root?)` → alias explícito de `$$` con `root` opcional
 *
 * Convención de uso:
 *   - `$(id)` cuando el argumento es un ID sin '#' (caso 90% del código).
 *   - `$q(sel)` cuando el argumento es un selector CSS ('.clase', '#id',
 *     'input[name="x"]:checked', '[data-attr]', etc.).
 *   - `$$(sel)` / `$qa(sel)` para listas.
 *
 * Auditoría clean code jul-2026: 5.7 → 6.0/10 (PR #2).
 * --- */
(function () {
  'use strict';

  // ---
  // $q(sel, root?) — querySelector para selectores CSS
  //
  // `root` opcional: cualquier nodo que implemente querySelector (Element,
  // Document, DocumentFragment). Si el root no lo implementa, devuelve null
  // en vez de tirar (los mocks de test deben implementar querySelector).
  // ---
  function $q(sel, root) {
    if (!sel) return null;
    const scope = root || document;
    return typeof scope.querySelector === 'function' ? scope.querySelector(sel) : null;
  }

  // ---
  // $qa(sel, root?) — querySelectorAll para selectores CSS
  // Alias de $$ pero con `root` opcional (mismo patrón que $q).
  // Devuelve SIEMPRE un array (no un NodeList, para evitar surprises).
  // ---
  function $qa(sel, root) {
    if (!sel) return [];
    const scope = root || document;
    return typeof scope.querySelectorAll === 'function' ? Array.from(scope.querySelectorAll(sel)) : [];
  }

  // ---
  // Exposición
  // ---

  // Si rotechos.js ya está cargado, sus helpers $ y $$ prevalecen.
  // Solo añadimos los que faltan. window.$q y window.$qa son nuevos.
  if (typeof window.$q !== 'undefined') {
    LOG.warn('rotechos-dom: $q ya estaba definido, se sobreescribe');
  }
  window.$q = $q;
  window.$qa = $qa;

  // Si por algún motivo $ o $$ NO existen (p.ej. tests que cargan
  // rotechos-dom.js ANTES que rotechos.js), los definimos también.
  // Esto permite usar el módulo como standalone para tests.
  if (typeof window.$ === 'undefined') {
    window.$ = (id) => document.getElementById(id);
  }
  if (typeof window.$$ === 'undefined') {
    window.$$ = (sel) => Array.from(document.querySelectorAll(sel));
  }
})();