/* ---
 * rotechos-modal-backdrop.js — Cierre por clic en el backdrop de los modales.
 *
 * Solo el clic cuyo objetivo es el propio .modal-overlay elimina la clase
 * show; los clics sobre los controles internos (checkbox, inputs, selects,
 * botones) NO se interceptan ni cierran el modal. Esto preserva el contrato
 * exacto del bloque extraído del monolito (rotechos.js:4036-4047).
 *
 * ---
 * Por qué NO usamos `$$` (helper global del monolito):
 *   El nuevo archivo es un script clásico con ámbito global compartido.
 *   Si aquí declaramos `const $$ = ...` colisiona con `const $$` de
 *   rotechos.js (línea 72) y revienta la carga. Para mantener el módulo
 *   totalmente autónomo y ESTRICTO (sin publicaciones window, sin
 *   declaraciones en ámbito global compartido), usamos directamente
 *   document.querySelectorAll, que es lo único que necesita este código.
 *
 * Por qué NO usamos bindFastTouch:
 *   bindFastTouch llama preventDefault + stopPropagation en cualquier
 *   pointerdown que alcance el overlay (es la regla para evitar "ghost
 *   clicks" en botones de acción). En un overlay eso rompería los
 *   controles NATIVOS del interior del modal (checkbox "Modo Escuela"
 *   del wizard, inputs, selects) que dependen del default del click.
 *   Por eso el cierre por backdrop se hace con un listener click normal
 *   y SOLO si el target es el propio overlay.
 *
 * ---
 * Posición de carga (ver ROTECHOS/www/index.html):
 *   Inmediatamente DESPUÉS de rotechos.js y ANTES de rotechos-ui-feedback.js.
 *   Carga con `defer`, por lo que se ejecuta cuando el DOM está parseado y
 *   rotechos.js ya terminó de registrar su API; este módulo no consume
 *   ninguna API del monolito (solo `document`), así que el orden solo
 *   importa como convención y para que el módulo figure antes de los
 *   módulos que sí dependen del monolito.
 *
 * Consumidores: ninguno. El módulo no publica API. Su único efecto
 * observable es: tras cargarlo, los .modal-overlay se cierran al
 *   hacer clic directamente sobre el backdrop.
 *
 * Extraído de rotechos.js (t_391f0813, ago-2026).
 * --- */
'use strict';

(function () {
  // Donde EMPEZO la ultima pulsacion (28-sep). Un toque que abre un modal en su
  // pointerdown (el jog del movil con paso grande abre «Movimiento grande» asi)
  // genera despues un click en el punto donde se levanta el dedo; si ahi ya esta
  // el backdrop, ese click fantasma cerraba el modal en el acto, como un
  // «Cancelar» que nadie pulso. Solo cierra si la pulsacion empezo en el propio
  // backdrop. Un click sin pointerdown previo (teclado, .click()) cierra igual que antes.
  var inicio = null;
  if (document.addEventListener) {
    document.addEventListener('pointerdown', function (e) { inicio = e.target; }, true);
  }
  var overlays = document.querySelectorAll('.modal-overlay');
  overlays.forEach(function (ov) {
    ov.addEventListener('click', function (e) {
      var empezo = inicio;
      inicio = null;
      if (e.target === ov && (empezo === null || empezo === ov)) {
        ov.classList.remove('show');
        // 29-sep: aviso a quien abrio el modal. confirmDialog lo trata como Cancelar;
        // sin esto su promesa quedaba pendiente y un Enter posterior la resolvia a true.
        if (typeof ov.dispatchEvent === 'function' && typeof CustomEvent === 'function') {
          ov.dispatchEvent(new CustomEvent('rotechos:backdrop-cierre'));
        }
      }
    });
  });
})();
