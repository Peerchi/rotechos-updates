/* ---
 * RotechOS — Módulos auxiliares (WIZARD + JOBHIST)
 * Extraídos de rotechos.js para reducir el tamaño del monolito.
 * IMPORTANTE: este script debe cargarse DESPUÉS de rotechos.js — usa
 *   $, RRF, _fetchModel, _unwrap, _fetchRRF, TARGET_IP, MACROS, log,
 *   toast, confirmDialog, window.SM. Todos esos viven en rotechos.js.
 * --- */

// ---
// MÓDULO 2 — ASISTENTE DE PRIMER ARRANQUE
// ---
const WIZARD = (function () {
  let step = STORE.get(`wizard.step`);
  const TOTAL = 12;
  let initialized = false;
  function setStep(n) {
    step = Math.max(1, Math.min(TOTAL, n));
    STORE.set(`wizard.step`, step);
    // Bloque onboarding WiFi jul-2026: si los listeners no se han enganchado
    // aún (caso APDetector.openConfig() que llama setStep ANTES de que el
    // usuario navegue al wizard por la barra de tabs), engancharlos ahora.
    // Idempotente: bindOnce usa `initialized` para no duplicar.
    if (!initialized) { bindOnce(); initialized = true; }
    render();
  }
  function html(s) { return s.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;"); }
  function seleccionarInterfazRed(entradas) {
    const candidatas = Array.isArray(entradas)
      ? entradas.filter((interfaz) => interfaz && typeof interfaz === 'object')
      : [];
    const tipo = (interfaz) => typeof interfaz.type === 'string' ? interfaz.type.toLowerCase() : '';
    const activa = (interfaz) => typeof interfaz.state === 'string' && interfaz.state.toLowerCase() === 'active';
    const preferencias = [
      (interfaz) => tipo(interfaz) === 'wifi' && activa(interfaz),
      (interfaz) => tipo(interfaz) === 'ethernet' && activa(interfaz),
      (interfaz) => tipo(interfaz) === 'wifi',
      (interfaz) => tipo(interfaz) === 'ethernet',
    ];
    for (const preferida of preferencias) {
      const interfaz = candidatas.find(preferida);
      if (interfaz) return interfaz;
    }
    return null;
  }
  async function leerInterfazRedPreferida() {
    const respuesta = await _fetchModel('network.interfaces', 3000);
    return seleccionarInterfazRed(respuesta && _unwrap(respuesta));
  }
  function render() {
    if (!$("wizContent")) return;
    $("wizStepLabel").textContent = `${t('wiz.step','Paso')} ${step}/${TOTAL}`;
    $("wizProgress").style.transform = `scaleX(${step / TOTAL})`;
    $("wizBtnPrev").style.visibility = step === 1 ? "hidden" : "visible";
    $("wizBtnNext").textContent = step === TOTAL ? t('wiz.btn.finish','Finalizar ✓') : t('wiz.btn.next','Siguiente →');
    $("wizBtnSkip").style.visibility = (step === 1 || step === TOTAL) ? "hidden" : "visible";
    const titles = ["Bienvenida","Conexión","Identidad","WiFi","Test motores","Endstops","Homing","Área de trabajo","Calibración pasos","Sonda Z","Husillo","Final"].map((es, i) => t(`wiz.title.${i + 1}`, es));
    $("wizStepTitle").textContent = titles[step - 1] || "";
    const c = $("wizContent");
    if (step === 1) {
      c.innerHTML = `<div style="text-align:center;padding:20px 0"><div style="margin-bottom:16px;color:var(--purple)"><svg viewBox="0 0 24 24" fill="none" height="40" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" width="40"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/></svg></div><h3 style="margin-bottom:10px;color:var(--text-1)">${t('wiz.s1.h','Bienvenido a RotechOS')}</h3><p style="color:var(--text-2)">${t('wiz.s1.p','Este asistente te guiará paso a paso para configurar tu router CNC por primera vez. Lo habitual es hacerlo en pocos minutos, aunque el paso de calibración M92 puede requerir más si necesitas medir con calibre.')}</p><p style="color:var(--text-3);font-size:11px;margin-top:14px">${t('wiz.s1.hint','Puedes pulsar <strong>Omitir paso</strong> en cualquier momento, o cerrar el asistente y retomarlo más tarde.')}</p></div>`;
    } else if (step === 2) {
      c.innerHTML = `<h3>${t('wiz.s2.h','Test de conexión con la controladora')}</h3><p>${t('wiz.s2.p','Comprobando comunicación con RepRapFirmware...')}</p><div id=wizConnResult style="margin-top:14px;padding:10px;border-radius:6px;background:var(--bg-raised);font-family:var(--mono);font-size:12px">${t('wiz.s2.wait','Esperando respuesta...')}</div>`;
      (async () => {
        try {
          const r = await _fetchRRF(`${TARGET_IP}/rr_status?type=1`);
          const ok = r.ok;
          const el = $("wizConnResult");
          if (el) el.innerHTML = ok
            ? `<span style="color:var(--green-strong);display:flex;align-items:center;gap:6px"><svg viewBox="0 0 24 24" fill="none" height="13" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" width="13"><polyline points="20 6 9 17 4 12"/></svg> ${t('wiz.s2.ok','RRF online y respondiendo correctamente')}</span>`
            : `<span style="color:var(--red);display:flex;align-items:center;gap:6px"><svg viewBox="0 0 24 24" fill="none" height="13" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" width="13"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg> ${t('wiz.s2.ko','Sin respuesta de RRF — revisa cable USB / red')}</span>`;
        } catch (e) {
          const el = $("wizConnResult"); if (el) el.innerHTML = `<span style="color:var(--red);display:flex;align-items:center;gap:6px"><svg viewBox="0 0 24 24" fill="none" height="13" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" width="13"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg> ${t('wiz.s2.neterr','Error de red:')} ${escHtml(e.message)}</span>`;
        }
      })();
    } else if (step === 3) {
      c.innerHTML = `<h3>${t('wiz.s3.h','Identidad de la máquina')}</h3><p>${t('wiz.s3.p','Asigna un nombre que identifique a esta máquina en la red local.')}</p><label class=mcfg-lbl style=margin-top:10px>${t('wiz.s3.name','Nombre')}</label><input type=text id=wizMachineName class=in-txt value="RotechCNC" maxlength=24><p style="color:var(--text-3);font-size:11px;margin-top:8px">${t('wiz.s3.hint','Se aplicará con <code>M550 P\\"&lt;nombre&gt;\\"</code>. Cambiar requiere reinicio para que el mDNS lo refleje.')}</p>`;
      // Precargar la identidad YA persistida (si la hay) para que reabrir el
      // wizard no proponga "RotechCNC" sobre una máquina que ya tiene nombre.
      // Nunca bloquea: si la lectura falla, se queda el valor por defecto.
      (async () => {
        try {
          if (typeof cfgMachineRead !== `function` || typeof window.cfgGetStringGlobal !== `function`) return;
          const actual = window.cfgGetStringGlobal(await cfgMachineRead(), `machineName`);
          const inp = $(`wizMachineName`);
          if (actual && inp) inp.value = actual;
        } catch (e) { LOG.warn(`wizard paso 3: no se pudo leer la identidad actual:`, e); }
      })();
    } else if (step === 4) {
      // C2/b (2026-08-11): el paso 4 discrimina por type ∈ {"wifi",
      // "ethernet", null}. La ruta del object model
      // network.interfaces[i].type está verificada en t_bec47b12 contra
      // RRF 3.5.4 (WiFiInterface.cpp:344, W5500Interface.cpp:62).
      //   - type === "ethernet" → NO inputs, muestra IP, NO emite M587.
      //   - type === "wifi"     → inputs + M587 (flujo actual intacto).
      //   - type ausente/null   → copy neutro, conserva inputs (no bloquea).
      c.innerHTML = `
        <h3>${t('wiz.s4.h', 'Conexión de red')}</h3>
        <p>${t('wiz.s4.p', 'Si vas a usar la máquina conectada por cable Ethernet, omite este paso. De lo contrario, configura SSID y contraseña.')}</p>
        <div id="wiz4NetStatus" style="margin-top:8px;padding:10px 12px;border-radius:6px;background:var(--bg-raised);font-size:12px;color:var(--text-2);font-family:var(--mono)">
          ${t('wiz.s4.detect', 'Detectando tipo de interfaz...')}
        </div>
        <div id="wiz4Branch"></div>`;
      // Best-effort: lee el tipo del object model. Si falla, cae a la rama
      // indeterminada (no bloquea el primer arranque).
      (async () => {
        let iface = null;
        try {
          iface = await leerInterfazRedPreferida();
        } catch (e) { LOG.warn('wizard paso 4: lectura de interfaces de red falló:', e); }
        const detectedType = (iface && typeof iface.type === 'string') ? iface.type : null;
        const statusEl = $('wiz4NetStatus');
        const branchEl = $('wiz4Branch');
        if (!branchEl) return;
        if (detectedType === 'ethernet') {
          if (statusEl) statusEl.innerHTML =
            `<span style="color:var(--green-strong)">${t('wiz.s4.ethDetected', 'Interfaz Ethernet detectada.')}</span>`;
          const ip = (iface && (iface.actualIP || '')).toString() || '0.0.0.0';
          branchEl.innerHTML = `
            <div style="margin-top:12px;padding:14px;border:1px solid var(--green);border-radius:8px;background:var(--bg-raised)">
              <div style="font-weight:700;color:var(--text-1);font-size:13px;margin-bottom:6px">${t('wiz.s4.ethTitle', 'Conexión por cable activa')}</div>
              <div style="color:var(--text-2);font-size:12px;line-height:1.6">${t('wiz.s4.ethIp', 'Dirección IP:')} <strong style="font-family:var(--mono);color:var(--green-strong)">${escHtml(ip)}</strong></div>
              <div style="color:var(--text-3);font-size:11px;margin-top:8px;line-height:1.5">${t('wiz.s4.ethHint', 'No se necesitan credenciales WiFi. Pulsa Siguiente para continuar.')}</div>
            </div>`;
          branchEl.dataset.netType = 'ethernet';
          branchEl.dataset.netIp = ip;
        } else if (detectedType === 'wifi') {
          if (statusEl) statusEl.innerHTML =
            `<span style="color:var(--green-strong)">${t('wiz.s4.wifiDetected', 'Interfaz WiFi detectada.')}</span>`;
          branchEl.innerHTML = `
            <label class="mcfg-lbl" style="margin-top:14px">${t('wiz.s4.ssid','SSID (nombre de tu red WiFi)')}</label>
            <input type="text" id="wizSsid" class="in-txt" placeholder="${t('wiz.s4.ssidph','Mi red WiFi')}">
            <p style="color:var(--text-3);font-size:11px;margin-top:4px;line-height:1.5">${t('wiz.s4.ssidHint','¿Cómo se llama tu red WiFi de casa? Es el nombre que aparece en la lista de redes de tu móvil u ordenador.')}</p>
            <label class="mcfg-lbl" style="margin-top:10px">${t('wiz.s4.pwd','Contraseña')}</label>
            <input type="password" id="wizPwd" class="in-txt" placeholder="••••••••">
            <p style="color:var(--text-3);font-size:11px;margin-top:4px;line-height:1.5">${t('wiz.s4.pwdHint','La misma que usas para conectar tu móvil a esa red. Se guarda solo en la controladora, no se envía a Internet.')}</p>
            <p style="color:var(--text-3);font-size:11px;margin-top:8px;line-height:1.5">${t('wiz.s4.m587hintBody','Guarda el nombre y la contraseña de tu WiFi en la memoria de la controladora (M587). Tras un reinicio, la máquina se unirá a esa red automáticamente.')}</p>`;
          branchEl.dataset.netType = 'wifi';
        } else {
          // Tipo ausente / desconocido / ilegible: copy NEUTRO, conserva inputs.
          if (statusEl) statusEl.innerHTML =
            `<span style="color:var(--warn-strong)">${t('wiz.s4.indetDetected', 'No se pudo determinar el tipo de interfaz. Mostrando opciones de red.')}</span>`;
          branchEl.innerHTML = `
            <p style="color:var(--text-3);font-size:11px;margin-top:10px;line-height:1.5">${t('wiz.s4.indetHelp','Si estás conectado por cable Ethernet, deja los campos vacíos y pulsa Siguiente. Si quieres WiFi, rellena los campos de abajo.')}</p>
            <label class="mcfg-lbl" style="margin-top:14px">${t('wiz.s4.ssid','SSID (nombre de tu red WiFi)')}</label>
            <input type="text" id="wizSsid" class="in-txt" placeholder="${t('wiz.s4.ssidph','Mi red WiFi')}">
            <label class="mcfg-lbl" style="margin-top:8px">${t('wiz.s4.pwd','Contraseña')}</label>
            <input type="password" id="wizPwd" class="in-txt" placeholder="••••••••">
            <p style="color:var(--text-3);font-size:11px;margin-top:8px;line-height:1.5">${t('wiz.s4.m587hintBody','Guarda el nombre y la contraseña de tu WiFi en la memoria de la controladora (M587). Tras un reinicio, la máquina se unirá a esa red automáticamente.')}</p>`;
          branchEl.dataset.netType = 'unknown';
        }
      })();
    } else if (step === 5) {
      c.innerHTML = `<h3>${t('wiz.s5.h','Test de motores')}</h3><p>${t('wiz.s5.p','Pulsa cada botón para mover el eje 10mm a velocidad lenta. Confirma que cada eje se mueve en la dirección correcta.')}</p><div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:14px"><button class=btn-save id=wizMoveXp>X +10</button><button class=btn-save id=wizMoveXm>X -10</button><button class=btn-save id=wizMoveYp>Y +10</button><button class=btn-save id=wizMoveYm>Y -10</button><button class=btn-save id=wizMoveZp>Z +5</button><button class=btn-save id=wizMoveZm>Z -5</button></div><p style="color:var(--text-3);font-size:11px;margin-top:14px">${t('wiz.s5.hint','Si un eje gira al revés, en la pestaña Motores cambia S0↔S1 para ese driver.')}</p>`;
      const mv = async (axis, dist, feed) => { await RRF.gcode(`G91`); await RRF.gcode(`G1 ${axis}${dist} F${feed}`); await RRF.gcode(`G90`); };
      bindFastTouch($("wizMoveXp"), () => { if (machineMoveBlocked(true)) return; mv("X", 10, 600); });
      bindFastTouch($("wizMoveXm"), () => { if (machineMoveBlocked(true)) return; mv("X", -10, 600); });
      bindFastTouch($("wizMoveYp"), () => { if (machineMoveBlocked(true)) return; mv("Y", 10, 600); });
      bindFastTouch($("wizMoveYm"), () => { if (machineMoveBlocked(true)) return; mv("Y", -10, 600); });
      bindFastTouch($("wizMoveZp"), () => { if (machineMoveBlocked(true)) return; mv("Z", 5, 300); });
      bindFastTouch($("wizMoveZm"), () => { if (machineMoveBlocked(true)) return; mv("Z", -5, 300); });
    } else if (step === 6) {
      c.innerHTML = `<h3>${t('wiz.s6.h','Verificación de endstops')}</h3><p>${t('wiz.s6.p','Activa físicamente cada sensor con el dedo y observa el estado en el panel principal (indicadores X/Y/Z). Cuando todos respondan correctamente, pulsa siguiente.')}</p><p style="color:var(--text-3);font-size:11px;margin-top:14px">${t('wiz.s6.hint','Puedes ejecutar <code>M119</code> en la consola para ver el estado en texto.')}</p><button class=btn-save id=wizCheckEndstops style=margin-top:10px>${t('wiz.s6.btn','Ejecutar M119')}</button>`;
      // A-1 (FIXE2E-03a, 2026-08-05): SIN machineMoveBlocked, a proposito y a
      // diferencia de los otros 11 puntos del wizard. M119 solo REPORTA el
      // estado de los endstops: no mueve un eje, no arranca el husillo y no
      // escribe configuracion. La funcion se llama machineMoveBlocked y aqui no
      // hay movimiento que bloquear; el guard llego por uniformidad y era el
      // unico de los 12 sin comentario que lo justificara. Bloquearlo no aporta
      // seguridad y le quita al operario un diagnostico legitimo justo cuando
      // sospecha de un sensor. NO lo "restaures" por simetria con las lineas de
      // arriba: e2e-fix-wizard-guard.spec.js lo cubre con un test dedicado.
      $("wizCheckEndstops")?.addEventListener("click", () => { RRF.gcode("M119"); });
    } else if (step === 7) {
      c.innerHTML = `<h3>${t('wiz.s7.h','Homing inicial')}</h3><p>${t('wiz.s7.p','Ejecuta G28 para referenciar todos los ejes: cada eje se desplazará hasta su tope físico buscando el origen. Antes de pulsar el botón, asegúrate de que la zona de trabajo está despejada.')}</p><div style="margin-top:12px;padding:10px 12px;border:1px solid #b8852a;border-radius:6px;background:#2a200a;color:var(--text-2);font-size:12px;line-height:1.5">${t('wiz.s7.warn','⚠ Antes de continuar: retira manos, herramientas y piezas sueltas del recorrido de los ejes. Mantén la mano cerca del botón rojo de emergencia (PARO) de la UI mientras se mueve la máquina. Si algo toca o se atasca, pulsa PARO inmediatamente.')}</div><button class=btn-save id=wizHome style=margin-top:14px>${t('wiz.s7.btn','Ejecutar G28 (HOME)')}</button><div id=wizHomeResult style=margin-top:10px;font-size:12px;color:var(--text-2)></div>`;
      bindFastTouch($("wizHome"), async () => { if (machineMoveBlocked(true)) return; const el = $("wizHomeResult"); if (el) el.textContent = t('wiz.s7.busy','Homing en curso...'); const r = await RRF.gcode("G28"); if (el) el.innerHTML = r
          ? `<span style="color:var(--green-strong);display:flex;align-items:center;gap:6px"><svg viewBox="0 0 24 24" fill="none" height="13" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" width="13"><polyline points="20 6 9 17 4 12"/></svg> ${t('wiz.s7.ok','Homing iniciado')}</span>`
          : `<span style="color:var(--red);display:flex;align-items:center;gap:6px"><svg viewBox="0 0 24 24" fill="none" height="13" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" width="13"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg> ${t('wiz.s7.ko','Error al iniciar G28')}</span>`; });
    } else if (step === 8) {
      c.innerHTML = `<h3>${t('wiz.s8.h','Área de trabajo (límites software)')}</h3><p>${t('wiz.s8.p','Recorrido útil de TU máquina desde el origen. El software no permitirá movimientos fuera de esta área (M208).')}</p>
<div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;margin-top:10px">
<div><label class=mcfg-lbl>X (mm)</label><input type=number id=wizAreaX class=in-txt step=1></div>
<div><label class=mcfg-lbl>Y (mm)</label><input type=number id=wizAreaY class=in-txt step=1></div>
<div><label class=mcfg-lbl>${t('wiz.s8.z','Recorrido Z (mm)')}</label><input type=number id=wizAreaZ class=in-txt step=1><p style="color:var(--text-3);font-size:10px;margin-top:4px">${t('wiz.s8.zHint','Mide el recorrido vertical con la sonda baja. Z0 arriba, Z-115 abajo (convención RRF). Introduce el recorrido siempre POSITIVO; el software lo guarda como negativo (M208). Ejemplo real de fábrica: X530, Y830, Z115 → X 0..530, Y 0..830, Z -115..0 mm.')}</p></div>
</div>
<button class=btn-save id=wizAreaApply style=margin-top:10px>${t('wiz.s8.btn','Aplicar área')}</button>
<div id=wizAreaResult style=margin-top:8px;font-size:12px></div>
<p style="color:var(--text-3);font-size:11px;margin-top:10px">${t('wiz.s8.hint','Mide el recorrido real de cada eje (de tope a tope, menos margen de seguridad). Si el jog se bloquea antes del tope al medir, desactiva temporalmente Límites Software (pestaña LÍMITES) y reactívalos al acabar.')}</p>`;
      (async () => {
        try {
          const ax = _unwrap(await _fetchModel(`move.axes`)) || [];
          if ($("wizAreaX")) $("wizAreaX").value = Math.round(ax[0]?.max ?? 0);
          if ($("wizAreaY")) $("wizAreaY").value = Math.round(ax[1]?.max ?? 0);
          if ($("wizAreaZ")) $("wizAreaZ").value = Math.round(Math.abs(ax[2]?.min ?? 0));
        } catch {}
      })();
      $("wizAreaApply")?.addEventListener("click", async () => {
        if (machineMoveBlocked()) return;  // A-1: limites no deben cambiar con trabajo en marcha
        const vx = parseFloat($("wizAreaX")?.value), vy = parseFloat($("wizAreaY")?.value), vz = parseFloat($("wizAreaZ")?.value);
        if (!isFinite(vx) || !isFinite(vy) || !isFinite(vz) || vx <= 0 || vy <= 0 || vz <= 0)
          return toast(t(`msg.wizAreaInvalid`, "Introduce los tres recorridos en mm"), "warn");
        // t_b8cd40c2: el modal de CONFIGURACION es PEREZOSO y _applyM208Instant
        // vive dentro. Un novato llega aqui sin haberlo abierto nunca, asi que
        // hay que cargarlo antes de comprobar. Sin esto, el paso 8 del asistente
        // moria con «Funcion de limites no disponible» en la primera puesta en
        // marcha — precisamente el flujo que no puede fallar.
        try { await window.__ensureConfigModal?.(); } catch (_) { /* el typeof de abajo decide */ }
        if (typeof window._applyM208Instant !== "function")
          return toast(t(`msg.wizAreaNoFn`, "Función de límites no disponible"), "err");
        // En la cola de escrituras, como el onchange de LIMITES (26-sep).
        await window.cfgEnCola(async () => {
          await window._applyM208Instant("X", "max", vx);
          await window._applyM208Instant("Y", "max", vy);
          await window._applyM208Instant("Z", "min", -vz);
        });
        const el = $("wizAreaResult");
        if (el) el.innerHTML = `<span style="color:var(--green-strong)">${t('wiz.s8.ok','Área aplicada y persistida:')} X 0-${vx} · Y 0-${vy} · Z -${vz}…0 mm</span>`;
      });
    } else if (step === 9) {
      c.innerHTML = `<h3>${t('wiz.s9.h','Calibración de pasos/mm (M92)')}</h3><p>${t('wiz.s9.p','Cada eje tiene configurados unos pasos por mm (M92) que indican cuánto se mueve por cada milímetro pedido. Si tus cortes quedan ligeramente más grandes o pequeños de lo que pediste en el software de diseño, mide y reajusta aquí. El husillo NO arranca durante la calibración.')}</p>
<div style="display:flex;gap:6px;margin:8px 0"><button class=btn-save data-cal-axis=X>X</button><button class=btn-save data-cal-axis=Y>Y</button><button class=btn-save data-cal-axis=Z>Z</button></div>
<div id=wizCalSel style="font-size:11px;color:var(--text-3);margin-bottom:8px">${t('wiz.s9.sel','1) Selecciona un eje')}</div>
<label class=mcfg-lbl>${t('wiz.s9.dist','Distancia a mover (mm)')}</label><input type=number id=wizCalDist class=in-txt value=100>
<p style="color:var(--text-3);font-size:10px;margin-top:4px">${t('wiz.s9.distHint','Define primero los mm a mover. El valor por defecto es 100 mm. Mide con un calibre lo que se desplaza REALMENTE el eje y apúntalo: lo usarás en el paso 3.')}</p>
<button class=btn-save id=wizCalMove style=margin-top:6px>${t('wiz.s9.move','2) Mover')}</button>
<label class=mcfg-lbl style=margin-top:10px>${t('wiz.s9.real','Distancia REAL medida con calibre (mm)')}</label><input type=number id=wizCalReal class=in-txt placeholder="${t('wiz.s9.realph','lo que se movió de verdad')}" step=0.01>
<!-- B1-03 (acta B1 2026-09-06): aviso inline bajo el input "real". Sin calibre,
     cualquier valor tecleado se persiste como pasos/mm y la máquina se mueve
     la mitad o el doble de lo pedido. El aviso es explícito: "no pulses
     Aplicar si no has medido". Y en el botón Aplicar hay un confirmDialog
     que refuerza el mismo mensaje antes de tocar la SD. -->
<p style="color:var(--warn-strong);font-size:11px;margin-top:4px;line-height:1.4"><strong>${t('wiz.s9.realWarn','Mide con calibre la distancia recorrida.')}</strong> ${t('wiz.s9.realWarnSfx','Sin medida fiable, no pulses «Calcular y aplicar»: el valor se guardará en config.g y la máquina se moverá mal. Si no tienes calibre a mano, pulsa arriba «Omitir paso» y vuelve más tarde.')}</p>
<button class=btn-save id=wizCalApply style=margin-top:6px>${t('wiz.s9.apply','3) Calcular y aplicar')}</button>
<div id=wizCalResult style="margin-top:10px;font-size:12px"></div>
<p style="color:var(--text-3);font-size:11px;margin-top:10px">${t('wiz.s9.hint','Verifica que el eje tiene recorrido libre antes de mover. Tras calibrar, vuelve a hacer HOME.')}</p>`;
      let calAxis = null;
      const AXI = { X: 0, Y: 1, Z: 2 };
      c.querySelectorAll("[data-cal-axis]").forEach((b) =>
        b.addEventListener("click", () => {
          calAxis = b.getAttribute("data-cal-axis");
          if ($("wizCalSel")) $("wizCalSel").textContent = `${t('wiz.s9.selected','Eje seleccionado:')} ${calAxis}`;
        }),
      );
      $("wizCalMove")?.addEventListener("click", async () => {
        if (!calAxis) return toast(t(`msg.wizCalcAxis`, "Selecciona un eje primero"), "warn");
        if (machineMoveBlocked(true)) return;  // A-1: calibracion mueve la maquina
        // 14-sep: sin homing no se mueve, igual que el jog (doJogStep).
        if (!AppState.limits.allHomed) return toast(t("zcal.msg.homeRequired", "Haz homing (G28) antes de calibrar"), "err");
        const d = parseFloat($("wizCalDist")?.value) || 0;
        if (!d) return toast(t(`msg.wizInvalidDist`, "Distancia inválida"), "warn");
        const feed = calAxis === "Z" ? 300 : 600;
        await RRF.gcode("G91"); await RRF.gcode(`G1 ${calAxis}${d} F${feed}`); await RRF.gcode("G90");
        toast(`${t(`msg.wizMovedPfx`, `Movido`)} ${calAxis} ${d}mm — ${t(`msg.wizMovedSfx`, `ahora mídelo`)}`, "info");
      });
      $("wizCalApply")?.addEventListener("click", async () => {
        if (!calAxis) return toast(t(`msg.wizCalcAxis`, "Selecciona un eje primero"), "warn");
        if (machineMoveBlocked(true)) return;  // A-1: M92 cambia pasos, debe parar antes
        const req = parseFloat($("wizCalDist")?.value) || 0;
        const real = parseFloat($("wizCalReal")?.value) || 0;
        if (!req || !real) return toast(t(`msg.wizNoMeasure`, "Faltan la distancia pedida o la medida"), "warn");
        // B1-03 (acta B1 2026-09-06): el sistema recalcula y guarda M92 sin
        // verificar que el operario realmente midiera con calibre. Eso le
        // "miente": le dice que la calibración se aplicó cuando en realidad
        // el valor es invento. Antes de tocar la SD, confirmamos honestamente:
        // "si no has medido, salta el paso y vuelve con un calibre".
        const ack = await confirmDialog({
          title: t(`dlg.wizCal.title`, `Calibrar pasos/mm del eje ${calAxis}`),
          body:
            `<p>${t(`dlg.wizCal.l1`, `Vas a recalcular y guardar los pasos/mm del eje ${calAxis} en config.g. La máquina se moverá de forma distinta a partir de ahora.`)}</p>` +
            `<p><strong style="color:var(--warn-strong)">${t(`dlg.wizCal.l2`, `¿Has medido con calibre la distancia REAL?`)}</strong></p>` +
            `<p style="font-size:11px;color:var(--text-3)">${t(`dlg.wizCal.l3`, `Si no has medido o tienes dudas, pulsa Cancelar, deja el campo «Distancia REAL» vacío y pulsa arriba «Omitir paso». Vuelve cuando tengas un calibre a mano.`)}</p>`,
          confirmText: t(`dlg.wizCal.confirm`, `Sí, he medido con calibre`),
          cancelText: t(`button.cancelar-ea78`, `Cancelar`),
        }).catch(() => false);
        if (!ack) return;
        let cur = null;
        try { cur = parseFloat(_unwrap(await _fetchModel(`move.axes[${AXI[calAxis]}].stepsPerMm`))); } catch {}
        if (!cur || !isFinite(cur)) return toast(t(`msg.wizNoSteps`, "No pude leer los pasos/mm actuales"), "err");
        const next = +(cur * req / real).toFixed(3);
        // t_b8cd40c2: mismo motivo que el paso 8 — _applyM92Instant vive en el
        // modal perezoso y este paso se ejecuta sin haberlo abierto.
        try { await window.__ensureConfigModal?.(); } catch (_) { /* el typeof decide */ }
        const ok = typeof window._applyM92Instant === "function" && (await window.cfgEnCola(() => window._applyM92Instant(calAxis, next)));
        const el = $("wizCalResult");
        if (el) el.innerHTML = ok
          ? `<span style="color:var(--green-strong)">${calAxis}: ${cur} → <b>${next}</b> ${t('wiz.s9.okSfx','pasos/mm · aplicado y guardado en config.g ✓')}</span>`
          : `<span style="color:var(--red)">${t('wiz.s9.ko','No se pudo aplicar el nuevo valor.')}</span>`;
      });
    } else if (step === 10) {
      c.innerHTML = `<h3>${t('wiz.s10.h','Test de sonda Z')}</h3><p>${t('wiz.s10.p','La sonda va al pulsador fijo y pone Z=0 en la mesa más el grosor de material configurado en SONDA Z. Recorrido libre y manos fuera antes de ejecutarla.')}</p><button class=btn-save id=wizProbe style=margin-top:14px>${t('wiz.s10.btn','Ejecutar sonda_Z.g')}</button><p style="color:var(--text-3);font-size:11px;margin-top:14px">Pin de sonda: E.7. Si no la tienes instalada, omite este paso.</p>`;
      $("wizProbe")?.addEventListener("click", async () => {
        // 14-sep: la guarda de SONDA Z (cfgProbeGuard) exige además el homing.
        if (machineMoveBlocked(true) || !cfgProbeGuard("probe")) return;
        if (!(await confirmDialog(
          t(`dlg.wizS10.title`, "Sonda Z (paso 10)"),
          t(`dlg.wizS10.msg`,
            "La máquina bajará el palpador hasta tocar tu pieza. Antes de continuar, retira todos los obstáculos de la zona de trabajo (piezas sueltas, herramientas, manos, viruta). Si algo va mal, pulsa PARO o teclea M112 para abortar de inmediato. ¿Continuar?"
          ),
        ))) return;
        RRF.gcode(`M98 P"${MACROS.sondaZ}"`);
      });
    } else if (step === 11) {
      c.innerHTML = `<h3>${t('wiz.s11.h','Test del husillo')}</h3><p>${t('wiz.s11.p','Arrancar el husillo a 6000 RPM durante 3 segundos. Confirma giro y dirección antes de continuar.')}</p><div style="margin-top:12px;padding:10px 12px;border:1px solid #b8852a;border-radius:6px;background:#2a200a;color:var(--text-2);font-size:12px;line-height:1.5">${t('wiz.s11.warn','⚠ Antes de arrancar: comprueba que la fresa está libre de material, manos y herramientas, y que la zona de trabajo está despejada. Si ves o escuchas algo raro durante los 3 segundos de prueba, pulsa Detener inmediatamente.')}</div><div style="display:flex;gap:8px;margin-top:14px"><button class=btn-save id=wizSpindleOn>${t('wiz.s11.on','Arrancar 3s a 6000 RPM')}</button><button class=btn-cancel id=wizSpindleOff>${t('wiz.s11.off','Detener')}</button></div>`;
      bindFastTouch($("wizSpindleOn"), async () => { if (machineMoveBlocked(true)) return; await RRF.gcode("T0\nM3 S6000"); setTimeout(() => RRF.gcode("T0\nM5"), 3000); });
      bindFastTouch($("wizSpindleOff"), () => RRF.gcode("T0\nM5"));
    } else if (step === 12) {
      // Fix t_c4601972 (camino-novato H3): el copy "Máquina lista para producción" +
      // "Has completado el asistente. La configuración inicial se ha aplicado correctamente"
      // es engañoso — todavía no se ha hecho HOME ni se ha cargado G-code. El novato
      // se queda parado. Severidad MEDIA. Cambio a copy honesto + CTA al botón HOME ALL.
      c.innerHTML = `<div style="text-align:center;padding:20px 0"><div style="margin-bottom:16px;color:var(--green-strong)"><svg viewBox="0 0 24 24" fill="none" height="40" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" width="40"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg></div><h3 style="margin-bottom:10px;color:var(--green-strong)">${t('wiz.s12.h','Configuración inicial completada')}</h3><p style="color:var(--text-2)">${t('wiz.s12.p','Has terminado la configuración inicial. Antes de empezar a cortar, pulsa <strong>HOME ALL</strong> en la barra superior del cockpit (o ejecuta G28) y fija el origen de pieza (X=0, Y=0, Z=0).')}</p><p style="color:var(--text-3);font-size:11px;margin-top:14px">${t('wiz.s12.hint','Puedes relanzar este asistente desde la pestaña <strong>PRIMER ARRANQUE</strong> en cualquier momento.')}</p>`
        // Bloque opcional de PIN HTTP. Decisión expresa del briefing (punto 2):
        // "Configurable desde CONFIGURACIÓN y desde el wizard del primer arranque".
        // Como NO queremos incrementar el total de pasos (preservar wizard.step y
        // localStorage ya guardados), lo metemos en el mismo paso 12 como bloque
        // colapsable. El PIN es opcional: si el operario no hace nada, el wizard
        // termina igualmente al pulsar "Finalizar".
        //
        // t_042f109c (2026-08-18, decisión Sergi): la máquina trae un PIN de
        // fábrica 123456789. Un PIN que el operario no sabe que existe no
        // protege nada, así que este paso SIEMPRE muestra un aviso arriba
        // cuando el PIN actual es el de fábrica y todavía no se ha
        // acknowledged (mecanismo: localStorage `rotechos.pinFactoryAck`).
        // El bloque admite 3 acciones: (a) cambiar el PIN, (b) quitarlo del
        // todo, (c) dejarlo como está y seguir. La decisión es del operario,
        // no de la UI.
        + `<div id="wizPinBlock" style="margin-top:24px;padding:14px;border:1px solid #2a2a35;border-radius:8px;background:#0d0d12;text-align:left">`
        // Aviso de PIN de fábrica. Se muestra/oculta desde el IIFE de abajo
        // según `isFactoryPin(cur)` y el flag de acknowledgment. El HTML
        // existe SIEMPRE en el DOM para que i18n/tests puedan contar
        // elementos de forma estable.
        + `<div id="wizPinFactoryNotice" data-i18n-html="msg.pinFactoryDefaultNotice" style="display:none;margin-bottom:12px;padding:10px 12px;border:1px solid var(--warn-strong-edge);background:var(--warn-strong-soft);border-radius:6px;color:var(--text-1);font-size:12px;line-height:1.55"><strong style="color:var(--warn-strong)">PIN de fábrica detectado.</strong> Esta máquina viene con un PIN por defecto (<code>123456789</code>). Te recomendamos <strong>cambiarlo</strong> desde abajo o <strong>quitarlo</strong> del todo desde CONFIGURACIÓN → PIN HTTP. Si no haces nada, el PIN seguirá siendo ese y cualquiera que lea el manual podrá entrar al panel.</div>`
        + `<div style="font-weight:700;color:var(--text-1);font-size:13px;margin-bottom:6px">${t('wiz.s12.pinTitle','PIN HTTP (opcional)')}</div>`
        + `<div style="color:var(--text-3);font-size:11px;line-height:1.5;margin-bottom:10px">${t('wiz.s12.pinDesc','Contraseña HTTP opcional para evitar accesos casuales a la UI. NO es cifrado: el PIN viaja por HTTP plano. Si lo activas, el botón rojo del navegador queda detrás de la sesión — usa una seta física o el escudo de firmware si tienes una urgencia sin haber iniciado sesión.')}</div>`
        // HUECO-4: wrappers relative para que el ojo se posicione dentro
        // del input. El módulo rotechos-auth.js cuelga el botón del ojo al final
        // del bloque (más abajo, tras el innerHTML).
        + `<div style="display:flex;gap:8px;align-items:center;margin-top:8px">`
        + `<div style="position:relative;flex:1;min-width:0"><input type=password id=wizPin class=in-txt maxlength=24 placeholder="${t('wiz.s12.pinPh','PIN (opcional)')}" style="flex:1;font-family:var(--font-mono,monospace)" autocomplete=new-password></div>`
        + `<div style="position:relative;flex:1;min-width:0"><input type=password id=wizPinCfm class=in-txt maxlength=24 placeholder="${t('wiz.s12.pinCfm','repite el PIN')}" style="flex:1;font-family:var(--font-mono,monospace)" autocomplete=new-password></div>`
        + `</div>`
        + `<div style="display:flex;gap:8px;margin-top:10px;flex-wrap:wrap">`
        + `<button class=btn-save id=wizPinSave style="font-size:12px">${t('wiz.s12.pinSave','Guardar PIN y terminar')}</button>`
        // Botón "Quitar PIN" — solo aparece si hay PIN configurado (visible
        // tanto si es el de fábrica como si es uno personalizado). El confirm
        // dice honestamente lo que implica quitarlo (t_042f109c §4).
        + `<button class="btn-2nd" id=wizPinRemove style="font-size:12px;display:none">${t('wiz.s12.pinRemove','Quitar PIN y terminar')}</button>`
        + `<button class=btn-cancel id=wizPinSkip style="font-size:12px">${t('wiz.s12.pinSkip','Saltar y terminar sin PIN')}</button>`
        + `</div>`
        + `<div id=wizPinStatus style="margin-top:8px;font-size:11px;color:var(--text-3);min-height:14px"></div>`
        + `</div></div>`;

      // Estado del PIN actual (lee la SD). Defensivo: si la lectura falla,
      // deja el bloque visible igualmente (el operario puede configurar uno).
      (async () => {
        const statusEl = $('wizPinStatus');
        const factoryNoticeEl = $('wizPinFactoryNotice');
        const removeBtn = $('wizPinRemove');
        let cur = '';
        try {
          if (typeof window.cfgMachineRead === `function` && typeof window.cfgGetPin === `function`) {
            const raw = await window.cfgMachineRead();
            if (raw != null) {
              cur = window.cfgGetPin(raw);
              if (cur && statusEl) statusEl.textContent = `PIN actual: ${'*'.repeat(cur.length)} (${cur.length} caracteres). Déjalo vacío para mantenerlo, o cámbialo.`;
            }
          }
        } catch (_) { /* defensivo */ }

        // t_042f109c (2026-08-18): si el PIN actual es el de fábrica y el
        // operario todavía no ha acknowledgeado (vía cambio o removal),
        // mostrar el aviso naranja arriba del bloque. El flag
        // `rotechos.pinFactoryAck` se setea en cuanto el operario hace
        // una de las dos acciones (cfgPersistPin / cfgRemovePin), de
        // modo que un re-arranque del wizard NO le machaque el aviso
        // una y otra vez.
        try {
          if (factoryNoticeEl) {
            const acked = (() => { try { return localStorage.getItem('rotechos.pinFactoryAck') === '1'; } catch (_) { return false; } })();
            const isFac = (typeof window.rotechosAuth?.isFactoryPin === `function`)
              ? window.rotechosAuth.isFactoryPin(cur)
              : (cur === `123456789`);
            factoryNoticeEl.style.display = (isFac && !acked) ? `block` : `none`;
          }
        } catch (_) { /* defensivo */ }

        // Si hay PIN configurado (sea de fábrica o personalizado), el botón
        // "Quitar PIN y terminar" aparece (con confirmDialog honesto). Si no
        // hay PIN, queda oculto — el operario usará "Saltar".
        if (removeBtn) {
          removeBtn.style.display = cur ? `` : `none`;
          removeBtn.addEventListener(`click`, async () => {
            const ack = await confirmDialog({
              title: t('msg.pinRemoveTitle', 'Quitar PIN HTTP'),
              body:
                `<p>${t('msg.pinRemoveL1', 'Vas a quitar el PIN HTTP. La UI volverá a abrirse sin pedir contraseña.')}</p>` +
                `<p>${t('msg.pinRemoveL2', 'Si tenías un PIN configurado, este cambio se aplica al guardar.')}</p>` +
                `<p><strong style="color:var(--warn-strong)">${t('msg.pinRemoveL3', 'Quitar el PIN deja la máquina accesible para cualquiera en la red del taller (vecino, invitado, técnico en tu WiFi): no es una barrera contra alguien que sepa lo que hace.')}</strong></p>`,
              confirmText: t('msg.pinRemoveConfirm', 'Quitar PIN'),
              cancelText: t('button.cancelar-ea78', 'Cancelar'),
              danger: true,
            }).catch(() => false);
            if (!ack) return;
            if (typeof window.cfgRemovePin !== `function` || typeof window.cfgMachineRead !== `function`) {
              if (statusEl) statusEl.textContent = `No se pudo quitar el PIN (helper no disponible).`;
              return;
            }
            try {
              await window.cfgEsperarEscrituras?.();
              const raw = await window.cfgMachineRead();
              if (raw == null) return;
              const updated = window.cfgRemovePin(raw);
              const ok = await window.cfgMachineWrite(updated);
              if (ok) {
                try { localStorage.setItem('rotechos.pinFactoryAck', '1'); } catch (_) {}
                setStep(step + 1);
              } else if (statusEl) statusEl.textContent = `No se pudo quitar el PIN (consulta los avisos).`;
            } catch (_) {
              if (statusEl) statusEl.textContent = `No se pudo quitar el PIN (error de red o de SD).`;
            }
          });
        }

        // Botón "Saltar y terminar" — equivale a pulsar "Finalizar" sin PIN.
        // B1-02 (acta B1 2026-09-06): si el PIN actual es el de fábrica y
        // todavía no se ha acknowledgeado, marcamos el ack al saltar para
        // que el aviso naranja no reaparezca en cada re-arranque del
        // wizard. Es una "salida honesta": el operario SABE que el PIN
        // sigue siendo el de fábrica (no le mentimos) pero puede cerrar
        // el aviso y seguir con su trabajo. El aviso seguirá saliendo si
        // re-abre el wizard desde CONFIGURACIÓN (es lo correcto: lo
        // vuelve a ver una vez por sesión de wizard).
        const skipBtn = $('wizPinSkip');
        if (skipBtn) skipBtn.addEventListener(`click`, () => {
          try {
            const wasAcked = (() => { try { return localStorage.getItem('rotechos.pinFactoryAck') === '1'; } catch (_) { return false; } })();
            const isFac = (typeof window.rotechosAuth?.isFactoryPin === `function`)
              ? window.rotechosAuth.isFactoryPin(cur)
              : (cur === `123456789`);
            if (isFac && !wasAcked) {
              try { localStorage.setItem('rotechos.pinFactoryAck', '1'); } catch (_) {}
              // Aviso al operario de lo que acaba de aceptar: el PIN de
              // fábrica sigue activo. Si lo quiere cambiar, sigue
              // teniéndolo en CONFIGURACIÓN → PIN HTTP. NO mentir: el
              // PIN no se ha tocado.
              if (typeof toast === `function`) {
                toast(t(`msg.pinSkippedFactory`, `Has decidido dejar el PIN de fábrica. Puedes cambiarlo en cualquier momento desde CONFIGURACIÓN → PIN HTTP.`), `info`);
              }
            }
          } catch (_) { /* defensivo: el skip sigue funcionando aunque falle el ack */ }
          setStep(step + 1);
        });

        // HUECO-4: ojo muestra/oculta en los 2 inputs del wizard. Idempotente.
        try {
          if (typeof window !== `undefined` && window.rotechosAuth &&
              typeof window.rotechosAuth.bindPinVisibilityToggle === `function`) {
            window.rotechosAuth.bindPinVisibilityToggle(`wizPin`);
            window.rotechosAuth.bindPinVisibilityToggle(`wizPinCfm`);
          }
        } catch (_) { /* defensivo */ }

        // t_4f22bdc3 (2026-09-01): validador charset + longitud en vivo
        // para los inputs del wizard. Mismo patrón que en el panel
        // Configuración (`bindPinInputValidator`): contador de caracteres
        // restantes + mensaje de error específico si teclea fuera del
        // set M551. El wizard crea los inputs runtime, así que el bind
        // se hace aquí y no en el autoinit del módulo rotechos-auth.js.
        try {
          if (typeof window !== `undefined` && window.rotechosAuth &&
              typeof window.rotechosAuth.bindPinInputValidator === `function`) {
            window.rotechosAuth.bindPinInputValidator(`wizPin`);
            window.rotechosAuth.bindPinInputValidator(`wizPinCfm`);
          }
        } catch (_) { /* defensivo */ }

        // Botón "Guardar PIN y terminar". Si falla la persistencia, el
        // wizard SIGUE (el PIN es opcional, no debe abortar el cierre).
        const saveBtn = $('wizPinSave');
        if (saveBtn) saveBtn.addEventListener(`click`, async () => {
          const a = ($('wizPin')?.value ?? ``).trim();
          const b = ($('wizPinCfm')?.value ?? ``).trim();
          if (!a && !b) { setStep(step + 1); return; } // vacío + vacío = saltar
          if (!a || !b) {
            if (statusEl) statusEl.textContent = `Rellena los dos campos (o déjalos vacíos para saltar).`;
            return;
          }
          if (a !== b) {
            if (statusEl) statusEl.textContent = `Los dos campos no coinciden.`;
            return;
          }
          // t_4f22bdc3 (2026-09-01): aborta si el PIN no pasa el validador
          // de charset/longitud. Aunque el feedback EN VIVO ya muestra
          // el error, el operario puede pulsar Guardar sin mirar. Usamos
          // la misma primitiva pura que el panel Configuración para que
          // ambos sitios compartan UN punto de verdad.
          if (typeof window.rotechosAuth?.validateM551Pin === `function`) {
            const v = window.rotechosAuth.validateM551Pin(a);
            if (!v.ok) {
              const fallbackPorMotivo = {
                'demasiado-largo':   `PIN demasiado largo (máximo 24 caracteres).`,
                'espacio':            `El PIN no admite espacios. Quítalo y vuelve a teclear.`,
                'caracter-invalido':  `Carácter no permitido en el PIN. Solo letras, dígitos y los símbolos - _ . @ # ! ? , :.`,
                'desconocido':        `PIN no válido. Revisa el charset y la longitud.`,
              };
              const msg = t(
                `msg.pinCharset.${v.motivo}`,
                fallbackPorMotivo[v.motivo] || fallbackPorMotivo['desconocido']
              );
              if (statusEl) statusEl.textContent = msg;
              return;
            }
          }
          // AVISO INELUDIBLE: el operario debe confirmar que el paro del
          // navegador queda detrás de la sesión (decisión expresa del briefing).
          const ack = await confirmDialog({
            title: t('msg.pinActivateTitle', 'Activar PIN HTTP'),
            body:
              `<p>${t('msg.pinActivateL1', 'Con un PIN activo, el paro de emergencia desde el navegador exige haber iniciado sesión.')}</p>` +
              `<p>${t('msg.pinActivateL2', 'Recomendamos una seta física cableada al escudo de firmware (M581, ya activo).')}</p>`,
            confirmText: t('msg.pinActivateConfirm', 'Activar PIN'),
            cancelText: t('button.cancelar-ea78', 'Cancelar'),
            danger: true,
          }).catch(() => false);
          if (!ack) return;
          if (typeof window.cfgPersistPin === `function`) {
            const ok = await window.cfgPersistPin(a);
            if (ok) {
              // t_042f109c: operario ha acknowledged el PIN de fábrica (lo
              // ha cambiado). Marcar para no volver a mostrarle el aviso
              // naranja en próximos arranques del wizard.
              try { localStorage.setItem('rotechos.pinFactoryAck', '1'); } catch (_) {}
              setStep(step + 1);
            }
            else if (statusEl) statusEl.textContent = `No se pudo guardar el PIN (consulta los avisos).`;
          } else {
            setStep(step + 1);
          }
        });
      })();
    }
  }
  async function next() {
    if (step === 3) {
      const name = $(`wizMachineName`)?.value?.trim();
      if (name) {
        await RRF.gcode(`M550 P"${window.escGcodeArg(name)}"`);
        log(`Nombre de máquina → ${name}`, "sys");
        // Persistir la identidad como global per-máquina en config-machine.g.
        // El M550 de arriba solo vive en runtime: al reiniciar volvería el
        // nombre de config.g. Se usa cfgPersistStringGlobal (NO
        // cfgPersistGlobalLine, cuya regex de extracción descarta strings).
        if (typeof window.cfgPersistStringGlobal === "function") {
          const okId = await window.cfgPersistStringGlobal(`machineName`, name);
          log(okId
            ? `Identidad persistida — set global.machineName = "${name}"`
            : `Identidad NO persistida (config-machine.g no legible) — el nombre solo vive hasta el reinicio`,
          okId ? "sys" : "warn");
        }
      }
    } else if (step === 4) {
      // FASE 3 onboarding WiFi jul-2026: tras M587, verificar que la WiFi cliente
      // realmente conectó antes de avanzar. Sin esto, un SSID/contraseña mal
      // tecleado ejecuta M587 correctamente pero la máquina sigue en AP y el
      // operario no se entera hasta que falla algo más tarde.
      //
      // C2/b (2026-08-11): la rama Ethernet del paso 4 no captura credenciales
      // ni emite M587 — la IP viene del DHCP y el enlace ya está activo.
      //   - netType === 'ethernet' → log + avanzar (sin M587, sin M552).
      //   - netType === 'wifi' | 'unknown' (con inputs) → flujo actual intacto.
      //
      // La rama Ethernet también tolera netType ausente (pasada de la versión
      // anterior al patch, p.ej. wizard ya pintado sin esperar al fetch):
      // si NO hay inputs wizSsid/wizPwd Y hay netIp, es Ethernet. Defensivo.
      const branchEl = $('wiz4Branch');
      const netType = branchEl?.dataset?.netType || '';
      const netIp   = branchEl?.dataset?.netIp   || '';
      const hasSsidInput = !!$('wizSsid');
      const hasPwdInput  = !!$('wizPwd');
      if ((netType === 'ethernet') || (!hasSsidInput && !hasPwdInput && netIp)) {
        // Ethernet: nada que configurar, ningún M587 que emitir.
        log(t('wiz.s4.ethLog', `Wizard Ethernet: IP ${netIp}, sin credenciales que enviar`, { ip: netIp }), `sys`);
        if (step < TOTAL) setStep(step + 1);
        return;
      }
      const ssid = $(`wizSsid`)?.value?.trim(), pwd = $(`wizPwd`)?.value;
      if (!ssid || !pwd) {
        // Sin credenciales → sigue al siguiente paso (asume ethernet o skip).
        log(`Wizard WiFi: sin SSID/password, paso omitido`, `sys`);
        if (step < TOTAL) setStep(step + 1);
        return;
      }
      // 5-oct: WPA2 pide 8-63 caracteres; RRF rechaza el M587 y rr_gcode no lo dice.
      if (pwd.length < 8 || pwd.length > 63) {
        toast(t(`msg.wifiPwdLen`, `La contraseña WiFi debe tener entre 8 y 63 caracteres.`), `err`);
        return;
      }
      // D-02: saneo comun (control chars + comillas), no solo comillas.
      // A§14: quitar comillas EN SILENCIO cambiaba la contrasena y la maquina
      // no asociaba nunca, sin decir por que. Ahora se avisa antes de mandarla.
      const ssidOk = window.escGcodeArg(ssid), pwdOk = window.escGcodeArg(pwd);
      if ([...ssid + pwd].some((c) => c < ` ` || c === `\x7F`)) {
        toast(t(`msg.wifiCredsSaneadas`,
          `El SSID o la contraseña llevan caracteres de control; se han quitado para poder enviarlos. Si la red no asocia, es por eso.`), `warn`);
        log(`Wizard WiFi: credenciales saneadas antes del M587`, `warn`);
      }
      await RRF.gcode(`M587 S"${ssidOk}" P"${pwdOk}"`);
      log(`WiFi M587 aplicado: ${ssid}`, `sys`);
      const wizErr = $(`wizWifiErr`);
      if (wizErr) wizErr.style.display = `none`;
      // ¿La UI está servida por el AP de commissioning? Entonces NO se puede
      // verificar la asociación desde aquí: al pasar el módulo a cliente, el AP
      // desaparece y este dispositivo pierde la conexión (la verificación
      // fallaría siempre, incluso con credenciales correctas). Flujo correcto:
      // M587 → aviso al usuario → M999. Tras el reboot, config.g hace M552 S1
      // y el módulo se une a la red del usuario (M587 persiste en el módulo).
      let netState = null;
      try { netState = window.APDetector ? await APDetector._check() : null; } catch (e) {}
      if (netState === `ap`) {
        const okGo = await confirmDialog(
          t(`dlg.wifiAp.title`, `Credenciales guardadas`),
          t(`dlg.wifiAp.msg`,
            `La máquina se reiniciará para unirse a "${html(ssid)}".<br><br>` +
            `1. Espera unos 40 segundos.<br>` +
            `2. Conecta este dispositivo a tu red WiFi.<br>` +
            `3. Abre <code>http://rotechcnc.local</code> (o la IP que asigne tu router).`),
        );
        if (!okGo) return;
        log(`Wizard WiFi: M999 para unirse a ${ssid} (commissioning AP)`, `sys`);
        await RRF.gcode(`M999`);
        $(`rebootOverlay`)?.classList.add(`show`);
        return;
      }
      // Cliente/ethernet: reciclar el módulo WiFi para que asocie YA con la red
      // nueva (M587 solo guarda credenciales, no fuerza la reasociación) y
      // verificar la asociación real antes de avanzar.
      // A§14 (auditoria 15-sep, PENDIENTE BANCO): iban en DOS peticiones, y la
      // segunda viajaba por la misma WiFi que la primera acababa de tirar. Si
      // el modulo bajaba antes de recibir el S1, la maquina quedaba fuera de la
      // red hasta un reinicio FISICO. En una sola peticion, RRF ejecuta las dos
      // lineas sin depender de que el enlace siga vivo entre medias.
      // 5-oct: G4 para que el S1 no llegue antes de parar (WiFiInterface.cpp:1072).
      await RRF.gcode(`M552 S0\nG4 S3\nM552 S1`);
      log(`WiFi M552 S0/S1: reasociando (esperando 12s)`, `sys`);
      await new Promise((r) => setTimeout(r, 12000));
      // Comprobar estado real de la red
      let ok = false;
      try {
        const nw = await leerInterfazRedPreferida();
        if (nw && nw.state === `active` && (nw.ssid || ``).toString() === ssid) ok = true;
      } catch (e) { LOG.warn(`Wizard WiFi: poll network falló:`, e); }
      if (!ok) {
        // Mostrar error inline en el paso, NO avanzar. El usuario puede
        // corregir SSID/contraseña y darle Siguiente otra vez, o pulsar
        // el botón Reintentar que reenvía los inputs tal cual están.
        // R-RED-02 (2026-08-12, t_2c15d777): el hallazgo del inventario
        // obrera2 (rotechos-modules.js:433) decía que "no hay botón
        // Reintentar" y el usuario tenía que borrar y volver a teclear.
        // Los inputs #wizSsid/#wizPwd NO se borran entre intentos (no
        // re-renderizamos el paso), así que basta con un botón visible
        // que llame a next() y un mensaje que explique que NO hay que
        // re-tipear.
        // Construimos el cuerpo del error sustituyendo ${ssid} en el template
        // i18n por la versión escapada (XSS: un SSID "<img onerror=...>" no
        // debe romper el HTML del panel). El template del default ES lleva
        // el placeholder ${ssid}; el EN idem.
        const safeSsid = typeof escHtml === `function` ? escHtml(ssid) : ssid.replace(/</g, `&lt;`);
        const errBodyRaw = t(`wiz.s4.errBody`,
          `No se pudo conectar a "${ssid}" tras 12s. La red WiFi "RotechOS" (AP) sigue activa y la máquina responde. Revisa el nombre exacto del SSID y la contraseña, y que el router esté cerca. Pulsa Reintentar sin re-tipear: los campos siguen rellenos.`, { "ssid": ssid });
        const errBody = errBodyRaw.replace(/\$\{ssid\}/g, safeSsid);
        const errTitle = t(`wiz.s4.errTitle`, `No se pudo conectar al WiFi`);
        const retryLbl = t(`wiz.s4.retry`, `Reintentar`);
        if (!wizErr) {
          const c = $(`wizContent`);
          if (c) {
            const div = document.createElement(`div`);
            div.id = `wizWifiErr`;
            div.style.cssText = `margin-top:10px;padding:10px 12px;border-radius:6px;background:var(--warn-strong-soft);border:1px solid var(--warn-strong-edge);color:var(--warn-strong);font-size:12px;line-height:1.5`;
            div.innerHTML = `<div style="font-weight:700;margin-bottom:6px">${errTitle}</div><div>${errBody}</div><button class="btn-save" id="wizWifiRetry" style="margin-top:8px">${retryLbl}</button>`;
            c.appendChild(div);
            const retryBtn = $(`wizWifiRetry`);
            if (retryBtn) retryBtn.addEventListener(`click`, () => { next(); });
          }
        } else {
          wizErr.style.display = `block`;
        }
        toast(t(`msg.wifiApFail`, `No se pudo conectar a ${ssid} tras 12s — revisa que el SSID y la contraseña son correctos y que el router está cerca; la red 'RotechOS' sigue disponible como fallback. Vuelve a este paso cuando lo soluciones (NO pulses Siguiente).`, { "ssid": ssid }), `err`);
        log(`Wizard WiFi: asociación fallida a ${ssid} tras 12s`, `err`);
        return; // NO avanzar
      }
      toast(t(`msg.wifiApOk`, `Conectado a ${ssid} ✓`), `ok`);
      log(`WiFi conectado: ${ssid} ✓`, `sys`);
    } else if (step === TOTAL) {
      try {
        await RRF.gcode(`set global.firstBootCompleted = true`);
        // Persistir en config.g — un set en vivo no sobrevive al reinicio
        if (typeof window.cfgPersistGlobalLine === "function")
          await window.cfgPersistGlobalLine(`firstBootCompleted`,
            `global firstBootCompleted = true ; El wizard de primer arranque lo pone a true al completarse (paso 11)`);
        toast(t(`msg.wizardDone`, "Configuración inicial completada ✓"), "ok");
        log("Wizard completado — firstBootCompleted = true (persistido)", "sys");
      }
      catch (e) { LOG.error(e); }
      return;
    }
    if (step < TOTAL) setStep(step + 1);
  }
  function prev() { if (step > 1) setStep(step - 1); }
  function bindOnce() {
    $(`wizBtnNext`)?.addEventListener("click", next);
    $(`wizBtnPrev`)?.addEventListener("click", prev);
    $(`wizBtnSkip`)?.addEventListener("click", () => { if (step < TOTAL) setStep(step + 1); });
  }
  return {
    // Bloque onboarding WiFi jul-2026: APDetector.openConfig() llama
    // WIZARD.setStep(4) para saltar al paso WiFi. Sin este método público
    // el botón del banner AP no podía redirigir al operario al paso correcto.
    setStep,
    onShow() { if (!initialized) { bindOnce(); initialized = true; } render(); },
  };
})();
window.WIZARD = WIZARD;

// ---
// MÓDULO 3 — HISTORIAL DE TRABAJOS (persiste en 0:/sys/jobhistory.json)
// ---
const JOBHIST = (function () {
  const REMOTE_PATH = "0%3A%2Fsys%2Fjobhistory.json";
  // `audit` es append-only: registra TODO clear/reset con snapshot previo.
  // Cap a 500 (mismo criterio que `jobs`): evita que el JSON crezca sin
  // límite en la SD; el cap se aplica al final del array (las entradas más
  // recientes son las más útiles para diagnóstico). Nadie lo borra desde la
  // UI: solo por SD directa o reseteo de fábrica. Decisión de producto
  // deliberada — ver acta 2026-09-01_auditoria-reseteos-jobhistory.md.
  const AUDIT_CAP = 500;
  // t_a5ea80e4: tareas de mantenimiento con su UMBRAL POR DEFECTO en horas
  // de husillo. Los IDs son la key canonica persistente en
  // jobhistory.json::taskThresholds — RENOMBRAR = reset silencioso de las
  // preferencias del operario, no se hace sin aviso. `labelKey` apunta a
  // la entrada de i18n (rotechos-i18n-config.js) con la etiqueta visible.
  // Umbrales conservadores alineados con los avisos que ya tenia el banner
  // histMaintAlert (50/100/250 h) + limpieza electronica a 500h que era el
  // unico de los 4 pedidos por la tarjeta que faltaba.
  const MAINT_TASKS = [
    { id: "cleanAndLubeGuides", defaultThresholdHours: 50  },
    { id: "inspectCollet",      defaultThresholdHours: 100 },
    { id: "inspectBelts",       defaultThresholdHours: 250 },
    { id: "cleanElectronics",   defaultThresholdHours: 500 },
  ];
  // Color visual del progreso. <70% verde (tranquilo), 70-100% ambar
  // (cerca de vencer), >=100% rojo (vencido). Porcentajes fijos para que
  // un cambio de threshold no recolore el mismo estado fisico.
  const PROGRESS_WARN_PCT = 90;   // >= 90% del umbral = amarillo
  let data = { jobs: [], spindleSeconds: 0, distanceMeters: 0, audit: [], tasks: {}, taskThresholds: {} };
  // t_a5ea80e4: inicializacion defensiva de tasks/taskThresholds. Si el JSON
  // cargado ya trae las claves (caso normal desde este commit) las
  // respetamos; si es un JSON antiguo (sin estos campos) las rellenamos con
  // defaults. Asi el siguiente scheduleSave() los persiste sin perder
  // spindleSeconds / distanceMeters / audit / jobs. Patron identico al
  // que ya usabamos para `audit` en load().
  function _initMaintDefaults() {
    if (!data.tasks || typeof data.tasks !== "object") data.tasks = {};
    if (!data.taskThresholds || typeof data.taskThresholds !== "object") data.taskThresholds = {};
    MAINT_TASKS.forEach((tk) => {
      if (!data.tasks[tk.id] || typeof data.tasks[tk.id] !== "object") {
        data.tasks[tk.id] = { lastResetHours: 0, lastResetAt: null };
      }
      // Si el JSON persistido no trae umbral para esta tarea, usamos el
      // default del catalogo. Si lo trae, lo respetamos — el operario
      // edito el threshold desde la UI y no queremos pisarselo.
      if (typeof data.taskThresholds[tk.id] !== "number" || data.taskThresholds[tk.id] <= 0) {
        data.taskThresholds[tk.id] = tk.defaultThresholdHours;
      }
    });
  }
  _initMaintDefaults();
  let lastStatus = "idle", jobStart = 0, jobFile = "", lastSpindleCheck = 0;
  let initialized = false, saveTimer = null;
  // FASE 4.17 (t_f6dc18a8): sub-vista activa dentro del panel jobhistory.
  // Vive en memoria (no en SD), arranca en "jobs" la primera vez y se
  // recuerda entre clicks de pestana sin necesidad de persistir nada.
  let activeSubTab = "jobs";
  // loaded: el JSON de la SD ya se ha leído (200) o no existe (404). Hasta
  // entonces NO se guarda: un navegador nuevo (sin el flag de localStorage)
  // subía su historial vacío encima del de la SD y lo borraba.
  let loaded = false;
  async function load() {
    try {
      const pin = (typeof window !== `undefined` && window.rotechosAuth && typeof window.rotechosAuth.getStoredPin === `function`)
        ? window.rotechosAuth.getStoredPin() : ``;
      const url = `${TARGET_IP}/rr_download?name=${REMOTE_PATH}&password=${encodeURIComponent(pin)}&t=${Date.now()}`;
      const r = await _fetchRRF(url, { cache: `no-store` }, 5000);  // D-04: el PIN va en la URL
      if (r.ok) {
        const j = JSON.parse(await r.text());
        if (j && Array.isArray(j.jobs)) {
          // Lo registrado en memoria antes de poder leer la SD se suma, no se pierde.
          if (!loaded) { j.jobs = data.jobs.concat(j.jobs); j.spindleSeconds = (+j.spindleSeconds || 0) + (data.spindleSeconds || 0); }
          data = j;
        }
        loaded = true;
      } else if (r.status === 404) loaded = true;  // aún no existe: se puede crear
      if (!Array.isArray(data.audit)) data.audit = [];
      _initMaintDefaults();
    } catch (e) {
      // Un JSON corrupto o sin red: se avisa y NO se marca como leído.
      LOG.warn(`JOBHIST load:`, e);
    }
  }
  function scheduleSave() {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(async () => {
      try {
        if (!loaded) await load();
        if (!loaded) throw Error(`historial de la SD sin leer; no se sobrescribe`);
        const blob = new Blob([JSON.stringify(data)], { type: "application/json" });
        const pin = (typeof window !== `undefined` && window.rotechosAuth && typeof window.rotechosAuth.getStoredPin === `function`)
          ? window.rotechosAuth.getStoredPin() : ``;
        const url = `${TARGET_IP}/rr_upload?name=${REMOTE_PATH}&password=${encodeURIComponent(pin)}&time=${Date.now()}`;
        const r = await _fetchRRF(url, { method: `POST`, body: blob, cache: `no-store` }, 8000);  // D-04
        // Una subida rechazada se daba por buena y el historico se perdia sin rastro.
        if (!r.ok) throw Error(`HTTP ${r.status}`);
        STORE.set(`jobhistory.markedCreated`, true);
      } catch (e) { LOG.error("JOBHIST save error:", e); }
    }, 500);
  }
  // _recordAudit(event, prev): append de UNA entrada con snapshot del estado
  // anterior. `prev` es el objeto plano que el caller conoce (p.ej.
  // { jobsCount: N } o { spindleSeconds: S, distanceMeters: D }). El
  // timestamp y el origen (ui/local por ahora — cuando exista login será
  // el user) los añade este helper para que ningún caller se los olvide.
  // NO se expone borrado desde la UI — solo el cap AUDIT_CAP aplica la
  // política de retención.
  function _recordAudit(event, prev) {
    if (!Array.isArray(data.audit)) data.audit = [];
    data.audit.push({
      when: new Date().toISOString(),
      event,
      who: "ui:local",
      prev: prev || {},
    });
    while (data.audit.length > AUDIT_CAP) data.audit.shift();
  }
  function _maintThresholdFor(taskId) {
    // t_a5ea80e4: helper puro — devuelve el umbral efectivo para una tarea.
    // Prioriza el umbral persistido (lo que el operario pudo editar en
    // una version futura); si no existe o es invalido, cae al default del
    // catalogo MAINT_TASKS. Asi el render nunca se queda sin numero.
    const persisted = data.taskThresholds && data.taskThresholds[taskId];
    if (typeof persisted === "number" && persisted > 0) return persisted;
    const cat = MAINT_TASKS.find((x) => x.id === taskId);
    return cat ? cat.defaultThresholdHours : 100;
  }
  function _maintTaskEntry(taskId) {
    // t_a5ea80e4: helper puro — devuelve la entrada persistida de la tarea
    // o un fallback vacio si por algun motivo no existe en data.tasks.
    // Los campos siempre son number/ISO/null — el caller no tiene que
    // defenderse de undefined.
    const e = (data.tasks && data.tasks[taskId]) || null;
    if (!e) return { lastResetHours: 0, lastResetAt: null };
    return {
      lastResetHours: typeof e.lastResetHours === "number" ? e.lastResetHours : 0,
      lastResetAt: typeof e.lastResetAt === "string" ? e.lastResetAt : null,
    };
  }
  function _maintProgress(taskId) {
    // t_a5ea80e4: helper puro, 100% testeable sin DOM.
    // Devuelve { hoursSince, threshold, ratio, pct, status } donde:
    //   - hoursSince: horas de husillo desde el ultimo reset de la tarea
    //   - threshold: umbral efectivo (persistido o default)
    //   - ratio: hoursSince / threshold (>=1 significa vencida)
    //   - pct: ratio * 100, redondeado a 0 decimales para pintar la barra
    //   - status: "ok" (ratio<0.9), "warn" (0.9<=ratio<1), "overdue" (>=1)
    // Si lastResetAt es null (nunca revisada), partimos de 0 — la tarea
    // envejece desde el primer minuto de uso, igual que el banner original.
    const e = _maintTaskEntry(taskId);
    const threshold = _maintThresholdFor(taskId);
    const currentHours = (data.spindleSeconds || 0) / 3600;
    const hoursSince = Math.max(0, currentHours - (e.lastResetHours || 0));
    const ratio = threshold > 0 ? hoursSince / threshold : 0;
    const pct = Math.round(ratio * 100);
    let status = "ok";
    if (ratio >= 1) status = "overdue";
    else if (ratio * 100 >= PROGRESS_WARN_PCT) status = "warn";
    return { hoursSince, threshold, ratio, pct, status };
  }
  function fmtDuration(secs) {
    if (secs < 60) return `${secs}s`;
    if (secs < 3600) return `${Math.floor(secs / 60)}m ${secs % 60}s`;
    return `${Math.floor(secs / 3600)}h ${Math.floor((secs % 3600) / 60)}m`;
  }
  function render() {
    if (!$(`histStatJobs`)) return;
    $(`histStatJobs`).textContent = data.jobs.length;
    $(`histStatSpindle`).textContent = (data.spindleSeconds / 3600).toFixed(2) + " h";
    $(`histStatDist`).textContent = (data.distanceMeters / 1000).toFixed(2) + " km";
    // FASE 4.17 (t_f6dc18a8): la sub-vista "Mantenimiento" reusa los mismos
    // stat cards. Se duplican con sufijo "2" para que la sub-vista Trabajos
    // y la sub-vista Mantenimiento muestren la misma cifra sin tener que
    // re-renderizar el card de cabecera cada vez que se cambia de sub-tab.
    const s2 = $(`histStatSpindle2`); if (s2) s2.textContent = (data.spindleSeconds / 3600).toFixed(2) + " h";
    const d2 = $(`histStatDist2`);     if (d2) d2.textContent = (data.distanceMeters / 1000).toFixed(2) + " km";
    const tb = $(`histTbody`);
    if (data.jobs.length === 0) {
      tb.innerHTML = `<tr><td colspan=4 style="padding:20px;text-align:center;color:var(--text-3);font-style:italic">${t(`jobs.empty`, `Sin trabajos registrados todavía`)}</td></tr>`;
    } else {
      tb.innerHTML = data.jobs.slice(0, 200).map((j) => {
        const statusColor = j.status === "completed" ? "var(--green)" : j.status === "canceled" ? "var(--text-3)" : "var(--red)";
        const statusLabel = j.status === "completed" ? "✓ Completado" : j.status === "canceled" ? "Cancelado" : "✗ Error";
        const safeFile = typeof escHtml === "function" ? escHtml(j.file || "—") : (j.file || "—").replace(/</g,"&lt;").replace(/>/g,"&gt;");
        return `<tr style="border-bottom:1px solid var(--border)"><td style="padding:6px 10px;color:var(--text-2)">${j.date}</td><td style="padding:6px 10px;color:var(--text-1)">${safeFile}</td><td style="padding:6px 10px;text-align:right;color:var(--text-2)">${fmtDuration(j.duration || 0)}</td><td style="padding:6px 10px;text-align:center;color:${statusColor};font-weight:700">${statusLabel}</td></tr>`;
      }).join("");
    }
    const alert = $(`histMaintAlert`);
    const distanceKm = data.distanceMeters / 1000;
    // t_a5ea80e4: el banner global histMaintAlert ahora se dispara por las
    // tareas VENCIDAS de data.tasks, no por los antiguos cortes hard-coded
    // (50/100/250 h, 500/1000 km). Mantiene el mismo contrato: un solo
    // banner, texto en castellano, dispara `display:block` con la tarea
    // mas urgente. Si no hay tareas vencidas pero hay alguna cerca del
    // umbral (>= PROGRESS_WARN_PCT), tambien avisa pero en ambar claro.
    // La lista en texto se construye con las etiquetas ES canonicas de
    // MAINT_TASKS para que el operario vea "Limpieza de la electronica"
    // en vez de un id interno.
    const _taskLabelEs = {
      cleanAndLubeGuides: "limpieza y engrase de guias",
      inspectCollet:      "revision de la pinza del husillo",
      inspectBelts:       "revision de correas / husillos de bolas",
      cleanElectronics:   "limpieza de la electronica",
    };
    const overdue = [];
    const nearDue = [];
    MAINT_TASKS.forEach((tk) => {
      const p = _maintProgress(tk.id);
      if (p.status === "overdue") overdue.push(tk);
      else if (p.status === "warn") nearDue.push(tk);
    });
    let msg = "";
    if (overdue.length > 0) {
      const list = overdue.map((tk) => `${_taskLabelEs[tk.id]} (${Math.round(_maintProgress(tk.id).hoursSince)} h / ${_maintThresholdFor(tk.id)} h)`).join("; ");
      msg = `Tareas vencidas: ${list}.`;
    } else if (nearDue.length > 0) {
      const list = nearDue.map((tk) => `${_taskLabelEs[tk.id]} (${Math.round(_maintProgress(tk.id).hoursSince)} h / ${_maintThresholdFor(tk.id)} h)`).join("; ");
      msg = `Tareas proximas a vencer: ${list}.`;
    }
    // Aviso de distancia recorrida (ejes). Mantenido del comportamiento
    // previo porque la tarjeta no lo quita — solo anade los 4 contadores.
    // El kilometraje sigue acumulandose con la app, no con el husillo, asi
    // que es un aviso paralelo (no excluyente) para el operario.
    if (distanceKm >= 1000) msg += (msg ? " · " : "") + `Ejes ${distanceKm.toFixed(0)} km — engrasar guias.`;
    else if (distanceKm >= 500 && !msg) msg = `Ejes ${distanceKm.toFixed(0)} km — comprobar lubricacion de guias.`;
    if (msg) { alert.style.display = "block"; alert.textContent = "Mantenimiento sugerido: " + msg; }
    else alert.style.display = "none";
    // Nueva tabla por tarea. Se pinta dentro del sub-panel Mantenimiento,
    // que ya tiene su propio thead en el HTML (t_a5ea80e4 anade los
    // #histMaintTaskTbody / .hist-task-reset al panel).
    renderMaintTasks();
    // FASE 4.17 (t_f6dc18a8): la sub-vista Auditoria se re-pinta junto con
    // el resto de stat cards. Asi un reset de contadores que dispara
    // _recordAudit() se ve al volver a la pestana sin tener que salir y
    // entrar del modal.
    renderAuditoria();
  }
  function renderMaintTasks() {
    // t_a5ea80e4: pinta la tabla de tareas de mantenimiento dentro del
    // sub-panel Mantenimiento (#histMaintTaskTbody). Construye el HTML en
    // una sola innerHTML con escHtml defensivo para las etiquetas
    // externas. La barra de progreso es un <div> hijo con ancho % —
    // asi se anima con CSS y respeta el tema (oscuro/claro).
    const tb = $(`histMaintTaskTbody`);
    if (!tb) return;
    if (!MAINT_TASKS.length) {
      tb.innerHTML = `<tr><td colspan=6 style="padding:20px;text-align:center;color:var(--text-3);font-style:italic">—</td></tr>`;
      return;
    }
    const esc = (typeof escHtml === "function") ? escHtml : (s) => String(s).replace(/</g, "&lt;");
    const dtFmt = (iso) => {
      if (!iso) return t(`cfg.hist.task.neverReset`, "Sin revisar");
      try { return new Date(iso).toLocaleString("es-ES"); } catch { return iso; }
    };
    tb.innerHTML = MAINT_TASKS.map((tk) => {
      const e = _maintTaskEntry(tk.id);
      const p = _maintProgress(tk.id);
      const labelText = t(`cfg.hist.task.${tk.id}`, tk.id);
      const label = esc(labelText);
      const last = esc(dtFmt(e.lastResetAt));
      const since = esc(p.hoursSince.toFixed(1));
      const thr = esc(String(p.threshold));
      const colorVar = p.status === "overdue" ? "var(--red)"
                      : p.status === "warn" ? "var(--warn-strong)"
                      : "var(--green)";
      const statusLabel = p.status === "overdue" ? t(`cfg.hist.task.overdue`, "Vencida") : "";
      const barWidth = Math.min(100, Math.max(0, p.pct));
      return `<tr style="border-bottom:1px solid var(--border)" class="hist-task-row" data-task="${esc(tk.id)}">` +
        `<td style="padding:6px 10px;color:var(--text-1)">${label}</td>` +
        `<td style="padding:6px 10px;color:var(--text-2)">${last}</td>` +
        `<td style="padding:6px 10px;text-align:right;color:var(--text-2)">${since} h</td>` +
        `<td style="padding:6px 10px;text-align:right;color:var(--text-2)">${thr} h</td>` +
        `<td style="padding:6px 10px"><div class="hist-task-bar" aria-label="${since} horas de ${thr}" style="background:var(--border);height:8px;border-radius:4px;overflow:hidden"><div style="width:${barWidth}%;background:${colorVar};height:100%;transition:width .3s"></div></div>${statusLabel ? `<div style="color:var(--red);font-size:10px;font-weight:700;margin-top:2px">${statusLabel}</div>` : ""}</td>` +
        `<td style="padding:6px 10px;text-align:center"><button type="button" class="btn-cancel hist-task-reset" data-task="${esc(tk.id)}" data-i18n="cfg.hist.task.btn.markDone">${esc(t(`cfg.hist.task.btn.markDone`, "Marcar revisado"))}</button></td>` +
      `</tr>`;
    }).join("");
  }
  async function hookState(model) {
    if (typeof _fetchModel !== "function" || typeof _unwrap !== "function") return;
    try {
      // Usa el estado que ya trae el sondeo; pedirlo otra vez duplicaba el trafico.
      const s = model?._rrfRaw ? { status: model._rrfRaw } : _unwrap(await _fetchModel("state", 1500));
      if (!s || !s.status) return;
      const cur = s.status;
      if (cur === "processing" && lastStatus !== "processing") {
        jobStart = Date.now();
        jobFile = window.SM?.loadedFile || "";
      }
      if (lastStatus === "processing" && cur !== "processing") {
        const dur = Math.round((Date.now() - jobStart) / 1000);
        const status = cur === "idle" ? "completed" : cur === "halted" || cur === "off" ? "error" : "canceled";
        const job = { date: new Date().toLocaleString("es-ES"), file: jobFile, duration: dur, status };
        data.jobs.unshift(job);
        // t_709342b8: el progressCard del rail derecho en reposo reusa el
        // dato del ultimo trabajo. Para no obligar a cargar el modulo del
        // historial (lazy) leemos de STORE una copia ligera que el rail
        // puede consultar en cualquier momento. Solo el primero: el historial
        // completo vive en data.jobs, este es el puntero.
        try { STORE.set("jobhistory.last", job); } catch (_) {}
        // CAP al persistir: sin esto el json crecía sin límite en la SD (el render
        // ya recortaba a 200, pero el ARCHIVO seguía engordando para siempre)
        if (data.jobs.length > 200) data.jobs = data.jobs.slice(0, 200);
        if (data.jobs.length > 500) data.jobs.length = 500;
        scheduleSave(); render();
      }
      lastStatus = cur;
      // Acumular horas spindle
      const now = Date.now();
      if (lastSpindleCheck > 0) {
        const dt = (now - lastSpindleCheck) / 1000;
        if (window.SM?.spindleOn) { data.spindleSeconds += dt; if (Math.floor(data.spindleSeconds) % 30 === 0) scheduleSave(); }
      }
      lastSpindleCheck = now;
    } catch (e) {}
  }
  function exportCsv() {
    // FASE 4.17 (t_f6dc18a8): CSV puede contener NOMBRES DE FICHERO DE CLIENTES
    // (informacion comercial). Se anade una linea de aviso al principio del
    // archivo para que cualquiera que abra el CSV sepa que ese dato viaja
    // dentro. Decision de producto: una linea basta; un exportador dedicado
    // iria en otra tarjeta.
    const rows = [
      `# AVISO: este CSV contiene nombres de fichero del cliente (informacion comercial). Tratalo como datos confidenciales.`,
      `Fecha;Archivo;Duración (s);Estado`,
      ...data.jobs.map((j) => `"${j.date}";"${(j.file || "").replace(/"/g, "''")}";${j.duration || 0};${j.status}`),
    ];
    const blob = new Blob([rows.join("\n")], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href = url; a.download = `rotechos-history-${Date.now()}.csv`; a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    toast(`Historial exportado (${data.jobs.length} trabajos)`, "ok");
  }
  function renderAuditoria() {
    // FASE 4.17 (t_f6dc18a8): pinta la sub-vista "Auditoria". Read-only:
    // solo se rellena data.audit desde _recordAudit(). Aqui se formatea
    // cada entrada como una fila de tabla (when ISO -> local, event legible,
    // who literal, prev pretty-printed). Si no hay entradas, mensaje "vacio"
    // para que el operario sepa que la funcion existe pero no se ha usado.
    const tb = $("histAuditTbody");
    if (!tb) return;
    const audit = Array.isArray(data.audit) ? data.audit : [];
    if (audit.length === 0) {
      tb.innerHTML = `<tr><td colspan=4 style="padding:20px;text-align:center;color:var(--text-3);font-style:italic">Sin registros de auditoría todavía</td></tr>`;
      return;
    }
    // Las entradas se persisten en orden cronologico (push). Pintamos las
    // mas recientes arriba (unshift para que se vea igual que jobs).
    const ordered = audit.slice().reverse();
    tb.innerHTML = ordered.slice(0, 200).map((e) => {
      const safeEvent = typeof escHtml === "function" ? escHtml(e.event || "—") : String(e.event || "—");
      const safeWho = typeof escHtml === "function" ? escHtml(e.who || "—") : String(e.who || "—");
      // Pretty-print del snapshot `prev`. Lo serializamos tal cual lo
      // escribio _recordAudit(): { jobsCount: N } o { spindleSeconds, distanceMeters }.
      const prevStr = e.prev && typeof e.prev === "object" && Object.keys(e.prev).length
        ? Object.entries(e.prev).map(([k, v]) => `${k}=${v}`).join(", ")
        : "—";
      const safePrev = typeof escHtml === "function" ? escHtml(prevStr) : prevStr.replace(/</g, "&lt;");
      const whenLocal = (() => {
        try { return new Date(e.when).toLocaleString("es-ES"); } catch { return e.when || "—"; }
      })();
      const safeWhenLocal = typeof escHtml === "function" ? escHtml(whenLocal) : whenLocal.replace(/</g, "&lt;");
      return `<tr style="border-bottom:1px solid var(--border)">` +
        `<td style="padding:6px 10px;color:var(--text-2)">${safeWhenLocal}</td>` +
        `<td style="padding:6px 10px;color:var(--text-1)">${safeEvent}</td>` +
        `<td style="padding:6px 10px;color:var(--text-2)">${safeWho}</td>` +
        `<td style="padding:6px 10px;color:var(--text-2)">${safePrev}</td>` +
        `</tr>`;
    }).join("");
  }
  function _showSubTab(name) {
    // FASE 4.17 (t_f6dc18a8): conmutador de sub-tabs internos del panel
    // jobhistory. Solo cambia visibilidad de los 3 sub-paneles hermanos; los
    // stat cards de cabecera y el banner de alerta se siguen viendo siempre.
    // El estado vive en `activeSubTab` (memoria, no SD): se reinicia al
    // recargar, que es el comportamiento menos surprising para el operario.
    const map = {
      jobs:  { panel: "histSubPanelJobs",  btn: "histSubtabJobs"  },
      maint: { panel: "histSubPanelMaint", btn: "histSubtabMaint" },
      audit: { panel: "histSubPanelAudit", btn: "histSubtabAudit" },
    };
    const target = map[name] || map.jobs;
    activeSubTab = name;
    Object.values(map).forEach(({ panel, btn }) => {
      const p = $(panel), b = $(btn);
      if (!p || !b) return;
      const isActive = (panel === target.panel);
      p.hidden = !isActive;
      b.classList.toggle("active", isActive);
      b.setAttribute("aria-selected", isActive ? "true" : "false");
    });
    // Si vamos a Auditoria, re-render por si el helper recibio entradas
    // nuevas desde la ultima vez que se abrio esta sub-vista.
    if (name === "audit") renderAuditoria();
  }
  function bindOnce() {
    $(`histBtnExport`)?.addEventListener("click", exportCsv);
    // FASE 4.17 (t_f6dc18a8): el segundo boton "Resetear contadores" de la
    // sub-vista Mantenimiento (id=histBtnResetMaint2) dispara el MISMO
    // handler. Asi no hay codigo paralelo: un solo lugar cambia spindleSeconds
    // y distanceMeters, y un solo lugar registra el evento en la auditoria.
    const _resetHandler = async () => {
      if (typeof confirmDialog === "function" ? !(await confirmDialog(t(`dlg.histReset.title`, "Resetear contadores"), t(`dlg.histReset.msg`, "Se pondrán a cero las horas de husillo y los kilómetros acumulados.<br>El <strong>historial de trabajos NO se toca</strong>.<br><span style=\"color:var(--text-3);font-size:11px\">Queda un registro de auditoría en <code>sys/jobhistory.json</code> con los valores previos (timestamp + snapshot).</span><br>Hazlo tras un mantenimiento real. ¿Continuar?"))) : !confirm("¿Resetear contadores de mantenimiento?")) return;
      // Auditoría: capturamos AMBOS contadores ANTES de ponerlos a cero. El
      // historial de trabajos NO se toca — queda intacto como prueba de qué
      // se estaba haciendo cuando se decidió hacer el servicio.
      const _prev = { spindleSeconds: data.spindleSeconds, distanceMeters: data.distanceMeters };
      data.spindleSeconds = 0; data.distanceMeters = 0; _recordAudit("maintenanceCountersReset", _prev); scheduleSave(); render(); toast(t(`msg.histCounters`, "Contadores reseteados"), "ok");
    };
    $(`histBtnResetMaint`)?.addEventListener("click", _resetHandler);
    $(`histBtnResetMaint2`)?.addEventListener("click", _resetHandler);
    // FASE 4.17 (t_f6dc18a8): bind de las 3 sub-tabs. Delegamos en
    // _showSubTab(name) para que el conmutador viva en un solo sitio y sea
    // facil testarlo estaticamente.
    document.querySelectorAll(`.hist-subtab`).forEach((btn) => {
      btn.addEventListener("click", () => _showSubTab(btn.dataset.subtab || "jobs"));
    });
    $(`histBtnClear`)?.addEventListener("click", async () => {
      if (typeof confirmDialog === "function" ? !(await confirmDialog(t(`dlg.histClear.title`, "Limpiar historial"), t(`dlg.histClear.msg`, "Se borrarán <strong>todos</strong> los trabajos registrados (los contadores de mantenimiento NO se tocan).<br><span style=\"color:var(--text-3);font-size:11px\">Queda un registro de auditoría en <code>sys/jobhistory.json</code> con el total borrado (timestamp + <code>jobsCount</code> previo). No se puede deshacer desde la UI.</span><br>¿Continuar?"))) : !confirm("¿Borrar historial de trabajos?")) return;
      // Auditoría: capturamos el conteo ANTES de vaciar. El mensaje del
      // diálogo ya promete que los contadores de mantenimiento se conservan,
      // así que NO registramos prev para esos — solo lo que efectivamente se
      // pierde (los trabajos en sí).
      const _prevJobsCount = data.jobs.length;
      data.jobs = []; _recordAudit("historyCleared", { jobsCount: _prevJobsCount }); scheduleSave(); render(); toast(t(`msg.histCleared`, "Historial limpiado"), "ok");
    });
    // t_a5ea80e4: boton "Marcar revisado" por tarea de mantenimiento.
    // Delegamos en un unico listener sobre el tbody (#histMaintTaskTbody)
    // y leemos data-task del boton que lanzo el evento. Asi no hay que
    // wirear N listeners cuando N tareas crezca en el futuro.
    const maintTb = $(`histMaintTaskTbody`);
    if (maintTb) {
      maintTb.addEventListener("click", async (ev) => {
        const btn = ev.target.closest(".hist-task-reset");
        if (!btn) return;
        const taskId = btn.getAttribute("data-task");
        if (!taskId || !MAINT_TASKS.find((x) => x.id === taskId)) return;
        // Confirmacion: el dialogo dice QUE se pierde (la fecha) y QUE se
        // conserva (la auditoria). Patron paralelo al reset global, con
        // texto adaptado a UNA tarea.
        const taskLabel = t(`cfg.hist.task.${taskId}`, taskId);
        const dlgTitle = t(`cfg.hist.task.dlg.title`, "Marcar mantenimiento como hecho");
        const dlgMsg = t(`cfg.hist.task.dlg.msg`, "Se pierde la fecha de la ultima revision de esta tarea. Solo queda un registro en la pestana Auditoria. Hazlo tras hacer el mantenimiento real. ?Continuar?");
        if (typeof confirmDialog === "function"
            ? !(await confirmDialog(dlgTitle, dlgMsg))
            : !confirm("?Marcar '" + taskLabel + "' como revisado?")) return;
        // Auditoria: capturamos la entrada previa ANTES de sobrescribir.
        // El evento se nombra "taskReset:<id>" para que el log de auditoria
        // sea trivial de filtrar por tarea.
        const entry = _maintTaskEntry(taskId);
        const prev = {
          lastResetHours: entry.lastResetHours,
          lastResetAt: entry.lastResetAt,
          thresholdHours: _maintThresholdFor(taskId),
        };
        // Importante: NO tocamos data.spindleSeconds. "Marcar revisado" es
        // registrar un hito en el tiempo — los contadores globales siguen
        // acumulando. Asi el operario puede hacer 4 servicios sin perder
        // el total real de horas de husillo.
        data.tasks[taskId] = {
          lastResetHours: (data.spindleSeconds || 0) / 3600,
          lastResetAt: new Date().toISOString(),
        };
        _recordAudit("taskReset:" + taskId, prev);
        scheduleSave(); render();
        toast(t(`msg.histTaskDone`, "Tarea marcada como revisada") + ": " + taskLabel, "ok");
      });
    }
  }
  // Inicialización pasiva (carga inicial al arrancar para empezar a registrar desde el primer trabajo)
  setTimeout(async () => {
    await load();
    // Usar registerUIHook si está disponible (evita duplicar polling del main loop)
    if (typeof registerUIHook === "function") {
      registerUIHook("jobhist", hookState);
    }
  }, 2000);
  return {
    onShow() { if (!initialized) { bindOnce(); initialized = true; } render(); _showSubTab(activeSubTab); },
    // t_709342b8: expone el ultimo trabajo (mas reciente) para que el
    // progressCard del rail pueda rellenarse en reposo con el dato del
    // historial. Devuelve null si aun no se ha cargado la historia o si
    // esta vacia. Solo lectura: el modulo sigue siendo dueno de data.jobs.
    lastJob() { return Array.isArray(data.jobs) && data.jobs.length ? data.jobs[0] : null; },
  };
})();
window.JOBHIST = JOBHIST;
