// ---
// rotechos-config-tools-table.js — Tabla de herramientas editable (M563).
// ---
// Modulo perezoso (t_ec990fc0, 2026-09-05). Antes vivia inline en
// rotechos-config-modal.js dentro del bloque "t_33991c62 — Tabla de
// herramientas editable" (~297 lineas, l.5002-5298 en lote/2026-09-05).
// Se carga al abrir la pestana HERRAMIENTAS, con el mismo patron que
// rotechos-config-pins-ui.js (CONTROLADORA) y rotechos-config-accel-curve.js
// (VELOCIDADES): una cache de promesa evita fetches duplicados si la UI
// reentra y `bindOnce()` es idempotente (no duplica listeners).
//
//   1. La pestana y el tbody (#mcfgToolsTbody, #mcfgToolForm, los botones
//      Anadir / Guardar / Cancelar) estan SIEMPRE en el DOM.
//   2. La primera vez que el operario ABRE la pestana HERRAMIENTAS,
//      rotechos-config-modal.js invoca `__loadToolsTable()` y el modulo
//      se inyecta via createElement('script').
//   3. En cuanto resuelve, expone `window.ROTECHOS_TOOLS_TABLE = { ... }`
//      y el modal llama a `bindOnce()` para enganchar listeners.
//   4. El populate se hace con `load()` cada vez que la pestana se
//      muestra (lee config-machine.g en vivo).
//
// POR QUE SE EXTRAE (criterio de la tarjeta t_ec990fc0):
//   - Es el segundo bloque cohesionado MAS grande del modal sin hablar
//     con RRF: 297 lineas que SOLO leen/escriben config-machine.g
//     (per-machine, no la toca una OTA) y dibujan una tabla HTML.
//   - Persistencia en helpers puros cfgGetToolsTable / cfgSetToolsTable
//     que ya viven en rotechos-config-persist.js (test unitario
//     tests/unit/cfg-tools-table.test.js). Solo pintura, validacion y
//     confirmDialog siguen en la UI.
//   - El PIN y la Identidad (escriben SD) y el CFG_FIELDS/cfgPopulate
//     (capa que habla con RRF) estan CONGELADOS hasta despues del
//     primer banco, por decision de la direccion.
//
// Dependencias globales (cargadas antes por orden de defer):
//   - rotechos-dom.js         → $()
//   - rotechos-i18n.js        → t()
//   - rotechos-logger.js      → LOG
//   - rotechos.js             → toast, log, confirmDialog
//   - rotechos-config-persist.js → cfgMachineRead/Write, cfgGetToolsTable,
//                                   cfgSetToolsTable, _cfgMachineRaw,
//                                   _cfgMachineLoadOk
//   - HTML en index.html      → #mcfgToolsTbody, #mcfgToolForm, #btnMcfgToolAdd,
//                                #btnMcfgToolSave, #btnMcfgToolCancel
// ---
'use strict';
(function () {
  /** Estado mutable del form inline. `null` cuando no hay edición en curso. */
  let _toolsEditing = null; // {p, name, D, F, Z, mat, R} | null

  /**
   * Lee el contenido en RAM de config-machine.g, llama al helper puro y
   * repinta el tbody de la tabla. Llamada al abrir la pestaña y tras cada
   * guardado. Defensiva: si falla la lectura, deja la tabla intacta.
   */
  async function load() {
    const tbody = $(`mcfgToolsTbody`);
    const hint = $(`mcfgToolsHint`);
    if (!tbody) return;
    try {
      if (typeof cfgMachineRead !== `function`) return;
      const raw = await cfgMachineRead();
      if (raw == null) return;
      const tools = (typeof window.cfgGetToolsTable === `function`)
        ? window.cfgGetToolsTable(raw)
        : [];
      tbody.innerHTML = tools.map(renderToolRow).join(``);
      // Hint al lado del botón Añadir: cuenta las tools distintas de 0.
      const extras = tools.filter((tl) => tl.p !== 0).length;
      if (hint) {
        hint.textContent = extras === 0
          ? t(`msg.toolsCountNone`, `Sin herramientas adicionales (solo Tool 0 / Spindle)`)
          : t(`msg.toolsCountN`, `${extras} herramienta(s) adicional(es) · Tool 0 (Spindle) protegida`).replace(`{n}`, String(extras));
      }
      // NOTA: NO cancelamos el form aquí. El comentario original decía
      // "se invalidó la sesión al repintar", pero `load()` se invoca desde
      // tres sitios:
      //   1. Al abrir la pestaña HERRAMIENTAS (`_onToolsTabOpen`) — el
      //      operario puede pulsar "Añadir herramienta" inmediatamente y
      //      un `cancelForm()` tardío (load es async) le cerraba el form
      //      justo después de abrirlo. Sintoma medido en la e2e:
      //      `#mcfgToolDiam` queda con `display:none` aunque el botón
      //      Add se clickó correctamente.
      //   2. Desde `saveForm()` — que ya llama `cancelForm()` antes de
      //      `load()`, por lo que es redundante.
      //   3. Desde `remove()` — mismo caso, ya canceló antes.
      // Por eso `load()` solo repinta la tabla; el caller decide si debe
      // cerrar el form antes (save/remove) o no (tab open).
    } catch (e) {
      LOG.warn(`tools-table load:`, e);
    }
  }

  /**
   * Genera el HTML de una fila de la tabla. Tool 0 sale SIN botones Editar /
   * Borrar (protegida) y con un candado visual. Las demás llevan los dos
   * botones con `data-act=edit|remove` y `data-p=<n>` para delegación.
   *
   * Atributos: nombre escapado para evitar inyección si el operario teclea
   * `<` o `>` en el nombre (XSS defense-in-depth; _sanitizeToolsName ya
   * bloquea `"`/`;`/`\n`/`\r`, pero `<` y `>` siguen siendo legales en M563
   * y queremos que la UI los muestre literalmente).
   */
  function renderToolRow(tool) {
    const p = Number(tool.p);
    const nameEsc = String(tool.name ?? '').replace(/[&<>]/g, (c) => ({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]));
    const mat = tool.mat ? String(tool.mat).replace(/[&<>]/g, (c) => ({'&':'&amp;','<':'&lt;','>':'&gt;'}[c])) : `<span style="color:var(--text-3)">—</span>`;
    const dStr = (tool.D !== null && tool.D !== undefined) ? tool.D : `<span style="color:var(--text-3)">—</span>`;
    const fStr = (tool.F !== null && tool.F !== undefined) ? tool.F : `<span style="color:var(--text-3)">—</span>`;
    const zStr = (tool.Z !== null && tool.Z !== undefined) ? String(tool.Z) : `0.00`;
    const sp = tool.R ? t(`cfg.tools.spindleYes`, `Sí`) : t(`cfg.tools.spindleNo`, `No`);
    if (p === 0) {
      return `<tr style="background:var(--bg-raised)">` +
        `<td>${p}</td>` +
        `<td><strong>${nameEsc}</strong></td>` +
        `<td>${dStr}</td><td>${fStr}</td><td>${zStr}</td><td>${mat}</td><td>${sp}</td>` +
        `<td><span data-i18n="cfg.tools.tool0" style="color:var(--text-3);font-size:10px">${t(`cfg.tools.tool0`, `Tool 0 (Spindle) — protegida`)}</span></td>` +
        `</tr>`;
    }
    return `<tr data-p="${p}">` +
      `<td>${p}</td>` +
      `<td>${nameEsc}</td>` +
      `<td>${dStr}</td><td>${fStr}</td><td>${zStr}</td><td>${mat}</td><td>${sp}</td>` +
      `<td>` +
        `<button class="sm-btn mcfg-txt" data-act=edit data-p=${p} title="${t(`cfg.tools.edit`, `Editar`)}" aria-label="${t(`cfg.tools.edit`, `Editar`)} tool ${p}">${t(`cfg.tools.edit`, `Editar`)}</button> ` +
        `<button class="sm-btn mcfg-danger" data-act=remove data-p=${p} title="${t(`cfg.tools.remove`, `Borrar`)}" aria-label="${t(`cfg.tools.remove`, `Borrar`)} tool ${p}">${t(`cfg.tools.remove`, `Borrar`)}</button>` +
      `</td>` +
      `</tr>`;
  }

  /** Muestra el form inline; si `tool` viene, lo pre-rellena (modo editar). */
  function openForm(tool) {
    const form = $(`mcfgToolForm`);
    if (!form) return;
    // Auto-asignar nº si es alta nueva (siguiente libre). Si es edición,
    // forzamos el campo disabled (solo lectura).
    let nextP = 1;
    if (!tool) {
      // Buscar el siguiente P libre recorriendo el tbody.
      const tbody = $(`mcfgToolsTbody`);
      if (tbody) {
        const used = new Set();
        tbody.querySelectorAll(`tr[data-p]`).forEach((tr) => {
          const p = Number(tr.dataset.p);
          if (!isNaN(p)) used.add(p);
        });
        for (let i = 1; i < 100; i++) {
          if (!used.has(i)) { nextP = i; break; }
        }
      }
    } else {
      nextP = Number(tool.p);
    }
    $(`mcfgToolPNum`).value = String(nextP);
    $(`mcfgToolName`).value = tool ? (tool.name ?? '') : '';
    $(`mcfgToolDiam`).value = tool && tool.D !== null && tool.D !== undefined ? tool.D : '';
    $(`mcfgToolFlutes`).value = tool && tool.F !== null && tool.F !== undefined ? tool.F : '2';
    $(`mcfgToolZ`).value = tool && tool.Z !== null && tool.Z !== undefined ? tool.Z : '0';
    $(`mcfgToolMat`).value = tool && tool.mat ? tool.mat : '';
    $(`mcfgToolSpindle`).value = tool && tool.R ? '1' : '0';
    _toolsEditing = tool ? { ...tool } : { p: nextP, name: '', R: 0, D: null, F: 2, Z: 0, mat: '' };
    form.style.display = '';
    // Foco al campo nombre para que el operario empiece a teclear.
    setTimeout(() => $(`mcfgToolName`)?.focus(), 0);
  }

  /** Cierra el form inline y limpia el estado de edición. */
  function cancelForm() {
    const form = $(`mcfgToolForm`);
    if (form) form.style.display = 'none';
    _toolsEditing = null;
  }

  /**
   * Lee los inputs del form, valida, y persiste la tabla vía cfgSetToolsTable
   * + cfgMachineWrite. Tool 0 está protegida por el helper, no aquí.
   *
   * Validaciones:
   *  - Nombre: rechazo duro de `"`/`;`/`\n`/`\r` y vacío.
   *  - Diam: número 0-99 (opcional)
   *  - Flutes: entero 1-99 (default 2)
   *  - Z: número libre (signo explica el briefing, no bloqueamos)
   *  - P (nº): 1-99 (0 es la tool inmortal; el input está disabled al editar)
   */
  async function saveForm() {
    const nameEl = $(`mcfgToolName`);
    const diamEl = $(`mcfgToolDiam`);
    const flutesEl = $(`mcfgToolFlutes`);
    const zEl = $(`mcfgToolZ`);
    const matEl = $(`mcfgToolMat`);
    const spEl = $(`mcfgToolSpindle`);
    const pNum = Number($(`mcfgToolPNum`)?.value);
    if (!Number.isInteger(pNum) || pNum < 1 || pNum > 99) {
      toast(t(`msg.toolsInvalidP`, `Número de herramienta inválido (1-99)`), `err`);
      return;
    }
    const rawName = nameEl?.value ?? '';
    // Validamos el nombre con la misma lógica del persist (rechazo duro si
    // lleva `"`, `;`, `\n`, `\r`).
    if (/[";\n\r]/.test(rawName) || !rawName.trim()) {
      toast(t(`msg.toolsInvalidName`, `Nombre inválido. No admite comillas, saltos de línea ni ';' y no puede estar vacío.`), `err`);
      return;
    }
    const diam = diamEl?.value !== '' && diamEl?.value !== undefined ? Number(diamEl.value) : null;
    if (diam !== null && (!isFinite(diam) || diam < 0 || diam > 99)) {
      toast(t(`msg.toolsInvalidDiam`, `Diámetro fuera de rango (0-99 mm)`), `err`);
      return;
    }
    const flutes = flutesEl?.value !== '' && flutesEl?.value !== undefined ? Math.round(Number(flutesEl.value)) : null;
    if (flutes !== null && (!Number.isInteger(flutes) || flutes < 1 || flutes > 99)) {
      toast(t(`msg.toolsInvalidFlutes`, `Filos debe ser entero 1-99`), `err`);
      return;
    }
    const zVal = zEl?.value !== '' && zEl?.value !== undefined ? Number(zEl.value) : 0;
    if (!isFinite(zVal)) {
      toast(t(`msg.toolsInvalidZ`, `Offset Z inválido`), `err`);
      return;
    }
    const mat = String(matEl?.value ?? '').trim().slice(0, 24) || null;
    const sp = Number(spEl?.value) === 1 ? 1 : 0;
    const newTool = { p: pNum, name: rawName.trim().slice(0, 24), R: sp, D: diam !== null ? String(diam) : null, F: flutes !== null ? String(flutes) : null, Z: String(zVal), mat };
    // En la cola: otro escritor de config-machine.g en vuelo se pisaba en silencio.
    await cfgEnCola(async () => { try {
      const raw = await cfgMachineRead();
      if (raw == null || (typeof _cfgMachineLoadOk !== `undefined` && !_cfgMachineLoadOk)) {
        toast(t(`msg.configMaquinaNoLeida`, `No se pudo leer config-machine.g — guardado ABORTADO`), `err`);
        return;
      }
      const tools = window.cfgGetToolsTable(raw);
      // Reemplazar si existe P=<pNum>, o añadir.
      const idx = tools.findIndex((tl) => tl.p === pNum);
      if (idx >= 0) tools[idx] = newTool; else tools.push(newTool);
      const newRaw = window.cfgSetToolsTable(raw, tools);
      const ok = await cfgMachineWrite(newRaw);
      if (!ok) {
        toast(t(`msg.toolsSaveFailed`, `No se pudo guardar la tabla de herramientas`), `err`);
        return;
      }
      _cfgMachineRaw = newRaw;
      cancelForm();
      await load();
      toast(t(`msg.toolsSaved`, `Tabla de herramientas guardada en config-machine.g ✓`), `ok`);
      log(`Tools → ${idx >= 0 ? 'edit' : 'add'} P${pNum} "${newTool.name}"`, `sys`);
    } catch (e) {
      LOG.error(`tools-table saveForm:`, e);
      toast(t(`msg.toolsSaveFailed`, `No se pudo guardar la tabla de herramientas`), `err`);
    }
    });
  }

  /**
   * Borra una herramienta por P. Tool 0 está protegida: aunque el botón no
   * se renderiza para P=0, defendemos también aquí (defense-in-depth). Pide
   * confirmDialog antes de borrar (es destructivo).
   */
  async function remove(p) {
    p = Number(p);
    if (!Number.isInteger(p) || p <= 0) {
      toast(t(`msg.toolsCannotDeleteP0`, `La herramienta 0 (Spindle) está protegida y no puede borrarse.`), `err`);
      return;
    }
    // Leer la tool que se va a borrar para mostrar el nombre en el diálogo.
    let toolName = '';
    try {
      const raw = await cfgMachineRead();
      if (raw != null) {
        const tools = window.cfgGetToolsTable(raw);
        const t0 = tools.find((x) => x.p === p);
        if (t0) toolName = t0.name;
      }
    } catch (_) {}
    const ack = await confirmDialog({
      title: t(`msg.toolsRemoveTitle`, `Borrar herramienta`),
      body: `<p>${t(`msg.toolsRemoveBody`, `Vas a borrar la herramienta P${p} ("${toolName || ''}") de config-machine.g. G-codes existentes que seleccionen T${p} fallarán hasta que definas una nueva con ese número o cambies el programa.`)}</p>`,
      confirmText: t(`cfg.tools.remove`, `Borrar`),
      cancelText: t(`cfg.tools.cancel`, `Cancelar`),
      danger: true,
    }).catch(() => false);
    if (!ack) return;
    // En la cola: otro escritor de config-machine.g en vuelo se pisaba en silencio.
    await cfgEnCola(async () => { try {
      const raw = await cfgMachineRead();
      if (raw == null || (typeof _cfgMachineLoadOk !== `undefined` && !_cfgMachineLoadOk)) {
        toast(t(`msg.configMaquinaNoLeida`, `No se pudo leer config-machine.g — guardado ABORTADO`), `err`);
        return;
      }
      const tools = window.cfgGetToolsTable(raw).filter((x) => x.p !== p);
      const newRaw = window.cfgSetToolsTable(raw, tools);
      const ok = await cfgMachineWrite(newRaw);
      if (!ok) {
        toast(t(`msg.toolsRemoveFailed`, `No se pudo borrar la herramienta`), `err`);
        return;
      }
      _cfgMachineRaw = newRaw;
      cancelForm();
      await load();
      toast(t(`msg.toolsRemoved`, `Herramienta P${p} borrada ✓`), `ok`);
      log(`Tools → remove P${p}`, `sys`);
    } catch (e) {
      LOG.error(`tools-table remove:`, e);
      toast(t(`msg.toolsRemoveFailed`, `No se pudo borrar la herramienta`), `err`);
    }
    });
  }

  /** Handler click delegado en la tabla: enruta a editar o borrar. */
  function onTableClick(e) {
    const btn = e.target.closest(`button[data-act]`);
    if (!btn) return;
    const act = btn.dataset.act;
    const p = Number(btn.dataset.p);
    if (act === `edit`) {
      const tr = btn.closest(`tr`);
      if (!tr) return;
      // Re-leemos del estado actual (no del tbody) — fuente única el helper.
      (async () => {
        const raw = await cfgMachineRead();
        if (raw == null) return;
        const all = window.cfgGetToolsTable(raw);
        const tool = all.find((x) => x.p === p);
        if (tool) openForm(tool);
      })();
    } else if (act === `remove`) {
      remove(p);
    }
  }

  /**
   * Engancha los listeners de los botones y del tbody. Idempotente: usa
   * flags internos para que una segunda llamada (p.ej. al re-abrir el
   * modal) no duplique handlers.
   */
  let _bound = false;
  function bindOnce() {
    if (_bound) return;
    _bound = true;
    $(`mcfgToolsTbody`)?.addEventListener(`click`, onTableClick);
    $(`btnMcfgToolAdd`)?.addEventListener(`click`, () => openForm(null));
    $(`btnMcfgToolSave`)?.addEventListener(`click`, saveForm);
    $(`btnMcfgToolCancel`)?.addEventListener(`click`, cancelForm);
    // Esc dentro del form cancela (UX; no destructivo, solo cierra).
    $(`mcfgToolForm`)?.addEventListener(`keydown`, (e) => {
      if (e.key === `Escape`) { e.preventDefault(); cancelForm(); }
    });
  }

  // API expuesta. El `bindOnce()` lo invoca el modal tras cargar el modulo;
  // `load()` lo invoca al abrir la pestana para repintar desde la SD.
  window.ROTECHOS_TOOLS_TABLE = { load, openForm, cancelForm, saveForm, remove, onTableClick, bindOnce };
})();
