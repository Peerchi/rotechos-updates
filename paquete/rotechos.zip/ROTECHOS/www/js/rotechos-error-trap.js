/* ---
 * rotechos-error-trap.js — Trampas globales de error y rechazo no manejado
 *
 * Reconstruido (jul-2026) tras detectar que index.html cargaba
 * `/js/rotechos-error-trap.js` entre logger y storage, pero el fichero
 * no existía: el navegador respondía 404, el SW no lo precacheaba y la
 * carga limpia fallaba. Este módulo es DELIBERADAMENTE mínimo.
 *
 * QUÉ HACE
 *   - Registra dos handlers globales (`window.error` y
 *     `window.unhandledrejection`) que reenvían el evento a
 *     window.LOG.error (cargado por rotechos-logger.js, justo antes).
 *   - Defensa ante evento/LOG incompletos: si el handler se ejecuta
 *     en un momento en que LOG aún no está disponible (caso teórico
 *     cuando un <script> posterior aborta y revienta este módulo),
 *     cae a console.error sin lanzar.
 *   - Defensa ante eventos malformados: si `event.error` no tiene
 *     mensaje (p.ej. ErrorEvent sintético en tests), usa el filename
 *     y la lineno cuando estén.
 *   - Sin estado compartido, sin exports, sin DOM: solo instala y se
 *     olvida. Nada de los otros módulos usa este módulo; este módulo
 *     no usa nada más que LOG (defensivamente, console).
 *
 * CONTRATO con LOG.error
 *   - Eventos `error` (ErrorEvent):
 *       name  = 'window.onerror'  (identifica la fuente al loguear)
 *       ctx   = { message, source, line, col, stack }
 *         · message: ev.message (string), '' si ausente
 *         · source:  ev.filename (URL del script), null si ausente
 *         · line:    ev.lineno (number), null si ausente
 *         · col:     ev.colno  (number), null si ausente
 *         · stack:   ev.error?.stack || null  (stack del Error interno)
 *   - Eventos `unhandledrejection` (PromiseRejectionEvent):
 *       name  = 'unhandledrejection'
 *       ctx   = { reason, stack }
 *         · reason: String(reason) si es Error, reason si es string, '' si undefined
 *         · stack:  reason?.stack || null
 *   - Si LOG no existe: console.error('rotechos-error-trap · window.onerror · <msg>',
 *                                       JSON.stringify(ctx))
 *     El prefijo identifica el módulo y el tipo de evento para que la
 *     consola del desarrollador siga siendo diagnóstica.
 *
 * POR QUÉ ES AUTO-BOOTSTRAP (al igual que rotechos-logger.js)
 *   - El IIFE se ejecuta al cargar el <script>. Tras él, los handlers
 *     están activos sin requerir setup externo.
 *   - Si el módulo se carga en un sandbox sin window real (tests unit
 *     vía vm), la guarda `typeof window !== 'undefined'` evita tirar
 *     y simplemente no hace nada.
 *
 * ORDEN DE CARGA en index.html
 *   - Va DESPUÉS de rotechos-logger.js (necesita LOG disponible) y
 *     ANTES de rotechos-storage.js y todos los demás consumidores de
 *     LOG. Así, cualquier error que se dispare más tarde queda
 *     capturado aunque sea el primer y único sitio que loguea.
 *
 * NO HACE
 *   - No muestra UI (no es banner, no es toast). El log es el canal.
 *   - No reemplaza `console.error` (lo usa como fallback defensivo).
 *   - No captura errores de <script> con src externo — eso dispara
 *     `error` en window igual que cualquier excepción, así que ya
 *     entra por el handler global.
 * --- */

(function () {
  'use strict';

  // ── Detección de entorno ─────────────────────────────────────────────
  // Mismo patrón que rotechos-logger.js: opera si hay window, sale
  // silenciosamente si no (tests en vm sin DOM).
  if (typeof window === 'undefined') return;

  // ── Helpers de extracción defensiva del evento ──────────────────────
  // ErrorEvent → ctx = { message, source, line, col, stack }
  // PromiseRejectionEvent → ctx = { reason, stack }
  function _describeError(ev) {
    if (!ev || typeof ev !== 'object') return null;

    // unhandledrejection: prioriza por 'reason' (PromiseRejectionEvent)
    if ('reason' in ev || 'promise' in ev) {
      const reason = ev.reason;
      let reasonStr;
      if (reason == null) reasonStr = '';
      else if (typeof reason === 'string') reasonStr = reason;
      else if (reason && typeof reason.message === 'string') reasonStr = 'Error: ' + reason.message;
      else reasonStr = String(reason);
      const stack = (reason && typeof reason === 'object' && reason.stack) || null;
      return { name: 'unhandledrejection', ctx: { reason: reasonStr, stack: stack } };
    }

    // error global / ErrorEvent
    const ctx = {};
    ctx.message = (ev.message != null) ? String(ev.message) : '';
    if (ev.filename) ctx.source = String(ev.filename); else ctx.source = null;
    if (ev.lineno != null) ctx.line = ev.lineno; else ctx.line = null;
    if (ev.colno != null) ctx.col = ev.colno; else ctx.col = null;
    ctx.stack = (ev.error && typeof ev.error === 'object' && ev.error.stack) || null;
    return { name: 'window.onerror', ctx: ctx };
  }

  // ── Resolución defensiva del logger ─────────────────────────────────
  // Si por la razón que sea LOG no está aún en window (por ejemplo,
  // este módulo se carga antes que rotechos-logger.js en un orden
  // accidental, o un test inyecta un entorno reducido), caemos a
  // console.error sin lanzar. La promesa es: NO romper la app por
  // intentar loguear.
  // ── ANILLO DE INCIDENCIAS (2026-08-31) ─────────────────────────────────────
  // POR QUE VIVE AQUI Y NO EN EL MODULO DE DIAGNOSTICO
  //   El paquete exportable (`rotechos-diag.js`) se carga PEREZOSAMENTE, al
  //   pulsar el boton — el arranque en frio ya va 138 KB por encima de su
  //   objetivo y no admite un modulo mas. Pero un anillo perezoso no sirve de
  //   nada: los fallos que hay que capturar son justo los del arranque, y para
  //   cuando el operario pulsa "exportar" ya han pasado. Asi que el anillo vive
  //   en el modulo que YA es eager y cuyo trabajo es exactamente este.
  //   Coste medido: ~600 B en crudo.
  //
  // POR QUE EN MEMORIA Y NUNCA EN localStorage / SD / IndexedDB
  //   Un log persistido puede acabar conteniendo el SSID y la contrasena del
  //   WiFi (`wifi-passwords.g` los guarda en claro en la tarjeta). Un anillo
  //   volatil se vacia al recargar y no deja rastro que exfiltrar. Se pierde
  //   historial entre sesiones a proposito: el flujo es "te pasa algo, exportas
  //   y lo mandas", no "consulto meses de historico".
  //
  // POR QUE NO SE TOCA rotechos-logger.js
  //   El logger es el escalon de mas abajo y lo usan los 37 modulos. Envolverlo
  //   desde aqui (y no editarlo) mantiene su contrato intacto: si este anillo
  //   petara, `LOG` sigue funcionando igual.
  var _ANILLO_MAX = 200;
  var _anillo = [];
  function _anotar(nivel, nombre, ctx) {
    try {
      _anillo.push({
        ts: new Date().toISOString(),
        nivel: nivel,
        msg: String(nombre == null ? '' : nombre),
        ctx: ctx || null,
      });
      if (_anillo.length > _ANILLO_MAX) _anillo.splice(0, _anillo.length - _ANILLO_MAX);
    } catch (_) { /* el anillo NUNCA puede romper el camino de error */ }
  }
  window.__rotechosLogRing = {
    snapshot: function () { return _anillo.slice(); },
    // `push` existe para que otros modulos (p.ej. el propio LOG, si algun dia
    // se engancha) puedan anotar sin conocer el interior.
    push: function (nivel, nombre, ctx) { _anotar(nivel, nombre, ctx); },
    get length() { return _anillo.length; },
  };

  // Envoltorio de LOG.error/LOG.warn. Se instala en cuanto LOG existe; si aun
  // no ha cargado (orden de scripts), se reintenta una vez en DOMContentLoaded.
  function _envolverLog() {
    try {
      var LOG = window.LOG;
      if (!LOG || LOG.__anilloInstalado) return;
      ['error', 'warn'].forEach(function (nivel) {
        var orig = LOG[nivel];
        if (typeof orig !== 'function') return;
        LOG[nivel] = function (nombre, ctx) {
          _anotar(nivel, nombre, ctx);
          return orig.apply(this, arguments);
        };
      });
      LOG.__anilloInstalado = true;
    } catch (_) { /* swallow */ }
  }
  _envolverLog();
  try {
    window.addEventListener('DOMContentLoaded', _envolverLog);
  } catch (_) { /* swallow */ }

  function _safeLogError(name, ctx) {
    try {
      const LOG = (typeof window !== 'undefined' && window.LOG) || null;
      if (LOG && typeof LOG.error === 'function') {
        LOG.error(name, ctx);
        return;
      }
    } catch (_) { /* swallow */ }
    // Fallback: nunca debe pasar en producción (logger va antes), pero
    // si pasa, al menos queda huella en consola para el desarrollador.
    try {
      let payload;
      try { payload = JSON.stringify(ctx); } catch (_) { payload = String(ctx); }
      // eslint-disable-next-line no-console
      console.error('rotechos-error-trap · ' + name + ' · ' + (ctx && ctx.message != null ? ctx.message : ''), payload);
    } catch (_) { /* swallow */ }
  }

  // ── Handlers ─────────────────────────────────────────────────────────
  // addEventListener con { passive: true } no aplica aquí (no son
  // eventos cancelables por defecto para touch/wheel). Mantenemos la
  // firma mínima y nunca re-lanzamos la excepción (eso generaría un
  // bucle infinito contra este mismo handler).
  function _onError(ev) {
    try {
      const desc = _describeError(ev);
      if (!desc) return; // ev nulo o sin campos utilizables → no loguear
      _safeLogError(desc.name, desc.ctx);
    } catch (_) { /* swallow */ }
  }

  function _onUnhandledRejection(ev) {
    try {
      const desc = _describeError(ev);
      if (!desc) return;
      _safeLogError(desc.name, desc.ctx);
    } catch (_) { /* swallow */ }
  }

  window.addEventListener('error', _onError);
  window.addEventListener('unhandledrejection', _onUnhandledRejection);
})();