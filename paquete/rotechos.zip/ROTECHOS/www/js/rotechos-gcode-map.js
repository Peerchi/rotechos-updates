/* ---
 * rotechos-gcode-map.js — Mapa binario de líneas de G-code + hms()
 *
 * Extraído del monolito (rotechos.js:1170-1298) en la tarjeta kanban
 * t_409c393c (bloques 18 y 19 del mapa de monolito de Kimi2, ago-2026).
 * Cuatro funciones que viajan juntas por contrato:
 *
 *   1. `buildGCodeLineMap(text)` — construye `{text, offsets:Int32Array}` con
 *      la posición de inicio de cada línea (O(n), escaneo único).
 *
 *   2. `gcodeLineAtOffset(map, offset)` — bsearch O(log n) sobre los
 *      offsets, devuelve `{line, text}` para un byte-position arbitrario.
 *      La línea visible para el operario sale sin el \r final cuando el
 *      archivo trae CRLF.
 *
 *   3. `logRunningGCodeLine(data)` — consumidor IMPURO del mapa: traduce
 *      el `filePosition` del firmware al número de línea visible y la
 *      registra en la consola (con debounce). Muta `SM.lastLoggedFilePos`,
 *      `SM.lastLoggedLine`, `SM.lastLineLogAt`. Por eso viaja con el
 *      módulo: ya estaba acoplada al mapa en el monolito.
 *
 *   4. `hms(ms)` — `Math.floor(ms/1000)` → HH:MM:SS con padding 2d.
 *
 * SÍMBOLOS EXTERNOS QUE NECESITA `logRunningGCodeLine` (provistos por el
 * monolito o por módulos cargados antes, vía window.* si hace falta):
 *   - `SM`        (window.SM)        estado del ciclo (.current, .gcodeLineMap,
 *                                     .lastLoggedFilePos, .lastLoggedLine,
 *                                     .lastLineLogAt)
 *   - `STATES`    (window.STATES)    enum { IDLE, RUNNING, ... }
 *   - `CFG`       (window.CFG)       .logDebounceMs, .logMaxLen
 *   - `log(msg, kind)`               helper de consola
 *
 * `buildGCodeLineMap`, `gcodeLineAtOffset` y `hms` son PURAS — sin DOM,
 * sin globales, sin mocks. Esta es la razón por la que cada una tiene un
 * test unitario dedicado que extrae el cuerpo por regex desde el monolito.
 *
 * RED DE SEGURIDAD (NO TOCAR — son la red que protege la extracción):
 *   - tests/unit/gcode-line-map.test.js — 11 tests sobre buildGCodeLineMap
 *     y gcodeLineAtOffset (CRLF, bsearch, O(log n), null/undefined). El
 *     test lee `ROTECHOS/www/js/rotechos.js` con `fs.readFileSync` y aplica
 *     un regex `function NAME(PARAMS) { ... }` sobre el cuerpo. Por eso
 *     en el monolito se conserva un PUENTE mínimo con la MISMA firma:
 *     `function hms(ms) { return window.hms(ms); }` etc. Los tests siguen
 *     pasando sin tocarlos.
 *   - tests/unit/hms.test.js — 11 tests sobre hms (bordes de segundo,
 *     minuto, hora, padding a 2 dígitos). Misma estrategia de extracción
 *     por regex; mismo puente en el monolito.
 *
 * Si en el futuro los tests se migran a apuntar al módulo nuevo, los
 * puentes se eliminan sin más. Mientras tanto, viven como reenvíos
 * triviales de una línea.
 *
 * CARGA: este módulo debe ir ANTES de rotechos.js en index.html. Motivo:
 * rotechos.js (línea ~1873) llama `logRunningGCodeLine(data)` y (líneas
 * 1268, 1273, 1274, 1871) llama `hms(...)`. Con `defer`, los scripts se
 * ejecutan en orden de aparición; cargar este módulo antes garantiza que
 * los puentes `const hms = window.hms` (etc.) encuentran la
 * implementación cuando el monolito la pide.
 *
 * Si `log` aún no existe (tests sin shell), `logRunningGCodeLine` falla
 * silenciosamente solo si NO se le llama; el módulo se carga pero la
 * función no se invoca fuera del monolito. Tests unitarios no la cubren.
 * --- */
(function () {
  'use strict';

  // ---
  // 1. buildGCodeLineMap(text)
  //
  // Constructor canónico del mapa. En producción rotechos-viz.js construye
  // su propio mapa por fast-path (offsets precomputados por su parser,
  // evita re-escanear archivos grandes), pero ESTA es la spec canónica
  // que cubren los tests unitarios.
  // ---
  function buildGCodeLineMap(text) {
    const src = String(text ?? ``);
    const offsets = [];
    let idx = 0;
    offsets.push(0);
    while ((idx = src.indexOf("\n", idx)) !== -1) {
      idx++;
      offsets.push(idx);
    }
    return {
      text: src,
      offsets: new Int32Array(offsets),
    };
  }

  // ---
  // 2. gcodeLineAtOffset(map, offset)
  //
  // Búsqueda binaria sobre los offsets de inicio de línea. Devuelve
  // `{line: 1-based, text}` para un byte-position arbitrario del firmware.
  // Si el archivo termina sin \n, la última línea se extiende hasta
  // `map.text.length` y se le quita el \r/\n final con el replace.
  // ---
  function gcodeLineAtOffset(map, offset) {
    if (!map || !map.offsets) return null;
    const offsets = map.offsets;
    let lo = 0,
      hi = offsets.length - 1,
      idx = 0;
    while (lo <= hi) {
      const mid = (lo + hi) >> 1;
      offsets[mid] <= offset ? ((idx = mid), (lo = mid + 1)) : (hi = mid - 1);
    }
    const start = offsets[idx];
    const end = idx < offsets.length - 1 ? offsets[idx + 1] : map.text.length;
    const lineText = map.text.substring(start, end).replace(/\r?\n?$/, "");
    return { line: idx + 1, text: lineText };
  }

  // ---
  // 3. logRunningGCodeLine(data)
  //
  // Consumidor IMPURO del mapa. Solo se ejecuta en RUNNING y con un mapa
  // ya construido. Aplica 3 filtros de debounce (filePosition monotónico,
  // misma línea, frecuencia mínima vía CFG.logDebounceMs) antes de emitir
  // `log(` L${line}: ${texto}`, `cmd`)`. Muta 3 campos de SM.
  // ---
  function logRunningGCodeLine(data) {
    if (typeof SM === 'undefined' || typeof STATES === 'undefined') return;
    if (SM.current !== STATES.RUNNING || !SM.gcodeLineMap || !SM.gcodeLineMap.offsets) return;
    const filePos = data?.jobModel?.filePosition ?? data?.filePosition;
    if (typeof filePos !== `number` || filePos < 0) return;
    if (SM.lastLoggedFilePos != null && filePos <= SM.lastLoggedFilePos) return;
    const entry = gcodeLineAtOffset(SM.gcodeLineMap, filePos);
    if (!entry) return;
    SM.lastLoggedFilePos = filePos;
    if (SM.lastLoggedLine === entry.line) return;
    const now = Date.now();
    const debounce = (typeof CFG !== 'undefined' ? CFG.logDebounceMs : 250);
    if (now - (SM.lastLineLogAt ?? 0) < debounce) return;
    ((SM.lastLoggedLine = entry.line), (SM.lastLineLogAt = now));
    let txt = (entry.text ?? ``).trim();
    if (!txt || txt.startsWith(`;`) || txt.startsWith(`(`)) return;
    const maxLen = (typeof CFG !== 'undefined' ? CFG.logMaxLen : 200);
    (txt.length > maxLen &&
      (txt = txt.slice(0, maxLen - 3) + `...`),
      log(` L${entry.line}: ${txt}`, `cmd`));
  }

  // ---
  // 4. hms(ms) — HH:MM:SS con padding a 2 dígitos, sin límite de 24h.
  //
  // Pura, sin DOM. Tests: tests/unit/hms.test.js (11 casos: bordes 0/1s,
  // 59s/1min, 59m59s/1h, padding de componentes <10, 24h exacto).
  // ---
  function hms(ms) {
    const s = Math.floor(ms / 1e3);
    return [Math.floor(s / 3600), Math.floor((s % 3600) / 60), s % 60]
      .map((v) => String(v).padStart(2, `0`))
      .join(`:`);
  }

  // Exposición como global. El monolito hace `const X = window.X` justo
  // después para que sus llamadas internas (líneas 1206, 1268, 1273, 1274,
  // 1871, 1873) sigan funcionando con el mismo nombre, sin tocar nada.
  // NO pisar si ya existía (defensa por si el shell todavía la publica
  // durante una transición, mismo patrón que rotechos-dom-utils.js:72).
  // Publicamos en `globalThis` (que en navegador es `window` y en Node es
  // el objeto global). Permite que los tests unitarios (extraen el cuerpo
  // del monolito por regex y lo evalúan en Node con `new Function`) vean
  // los puentes `return globalThis.X(...)` sin reventar con
  // `ReferenceError: window is not defined`.
  if (typeof globalThis.buildGCodeLineMap === 'undefined') {
    globalThis.buildGCodeLineMap = buildGCodeLineMap;
  }
  if (typeof globalThis.gcodeLineAtOffset === 'undefined') {
    globalThis.gcodeLineAtOffset = gcodeLineAtOffset;
  }
  if (typeof globalThis.logRunningGCodeLine === 'undefined') {
    globalThis.logRunningGCodeLine = logRunningGCodeLine;
  }
  if (typeof globalThis.hms === 'undefined') {
    globalThis.hms = hms;
  }
})();
