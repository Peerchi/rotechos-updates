// ════════════
// rotechos-jog.js — JOG COMPLETO: manual, overrides, LIBRE (B7)
// ════════════
// Extraído de rotechos.js (jul-2026, extracción #7 — ÚLTIMA fila del
// roadmap) SIN cambios de lógica, en 4 tramos en su orden original:
//   1. Shift detector (jogJog ×0.25) + selector Lento/Normal/Rápido con
//      persistencia en STORE (su restore va en DOMContentLoaded a
//      propósito — ver comentario TDZ del propio código).
//   2. updateJogFeedEffective + JOG_FEED/_m203Limits/_m201Accel +
//      jogFeedFor (feed con techo M203) + doJogStep (jog por pasos con
//      confirmación ≥50mm) + barras de override (ovPct/ovBarColor/
//      updateOvBar) + sliders feed/spindle.
//   3. initMPG: pad de jog del pendant (pills de paso, toggle FINO B2,
//      modo LIBRE con gate de homing).
//   4. b7JogFree: streaming de microsegmentos del modo LIBRE (150ms,
//      buffer máx 2 en vuelo, paradas obligatorias en pointerup/blur/
//      visibilitychange/strikes).
//
// ⚠️ SEGURIDAD (riesgo ALTO del roadmap): TODO este archivo mueve la
// máquina. Su contrato de comportamiento son los 8 tests de
// tests/e2e-libre.spec.js (BL1-BL8: gate de homing, streaming, paradas)
// + el test 7 de e2e.spec.js (confirmación de jog ≥50mm) + los unit de
// tests/unit/jog-feed.test.js. El gate del roadmap (BL4 determinista +
// e2e-fallos en verde) se verificó el 2026-07-11: BL4 5/5 aislado,
// e2e-fallos 3/3, batería completa 47/47 ×3 consecutivos.
//
// Dependencias en runtime (todas globales, resueltas por orden de defer;
// este archivo carga DESPUÉS de rotechos.js — ver index.html):
//   - rotechos-dom.js     → $(), $$()
//   - rotechos-i18n.js    → t()
//   - rotechos-logger.js  → LOG
//   - rotechos-storage.js → STORE
//   - rotechos.js         → SM, STATES, CFG, AppState, RRF, toast, log,
//                           confirmDialog, machineMoveBlocked, poll,
//                           _clearPollTimer, startPoll, bindFastTouch,
//                           setText, flash*, KIN/CoordMode si aplica
//
// Consumidores externos: updateOvBar (updateUI de rotechos.js:~1900 y
// rotechos-spindle.js), updateJogFeedEffective (pills de paso del
// cockpit, en rotechos.js), JOG_FEED/_m203Limits/_m201Accel (los muta
// applyRotechJogFeeds en rotechos-config-modal.js al releer config.g).
//
// ⚠️ tests/unit/jog-feed.test.js extrae jogFeedFor/ovPct/ovBarColor por
//    regex anclada a indent 0 (cierre `\n}`): si reindentas, actualízalo.
// ════════════
/* exported updateOvBar, updateJogFeedEffective, JOG_FEED */

// H2-bis (post-refactor, 2ª auditoría): _jogMode sube a top-level del archivo.
// El audit detectó que el binding estaba dentro de una IIFE (L519) y el guard
// `typeof _jogMode !== 'undefined'` en _b7Start (L878, scope top-level) era
// INERTE: typeof siempre devolvía 'undefined', cortocircuitando el blindaje
// de seguridad del path de streaming LIBRE (b7JogFree). Re-armarlo requiere
// que _jogMode sea visible desde _b7Start.
//
// Las asignaciones dentro de la IIFE original (LAS setters del pill de modo,
// _jogMode = 'step'/'free') ahora NO re-declaran: solo asignan al
// top-level. La declaración es solo 'let' (no 'var') para respetar el modo
// strict del monolito.
let _jogMode = `step`;
let _jogDisplayStep = 1;
let _jogFreeFeedFor = null;
// ── Shift detector — activa el "jogJog" (sub-velocidad 25%) mientras se mantenga
// pulsada. Funciona tanto en jog buttons como en jog por teclado.
document.addEventListener('keydown', (e) => {
  if (e.key === 'Shift' && !_shiftJogActive) {
    _shiftJogActive = true;
    const ind = $('jogSlowIndicator');
    if (ind) ind.classList.add('active');
    updateJogFeedEffective();
  }
});
document.addEventListener('keyup', (e) => {
  if (e.key === 'Shift' && _shiftJogActive) {
    _shiftJogActive = false;
    const ind = $('jogSlowIndicator');
    if (ind) ind.classList.remove('active');
    updateJogFeedEffective();
  }
});
// Reset on blur (evita que quede "atascado" si se suelta fuera de ventana)
window.addEventListener('blur', () => {
  _shiftJogActive = false;
  const ind = $('jogSlowIndicator');
  if (ind) ind.classList.remove('active');
  updateJogFeedEffective();
});

// ── Selector de velocidad de jog (Lento/Normal/Rápido) ──
// Persiste el nivel entre sesiones vía STORE. Si no hay valor guardado
// o es inválido, usa 'normal' (default conservador).
const jogSpeedSelector = $('jogSpeedSelector');
const jogStepSelector = $('jogStepSelector');

// Los selectores nativos delegan la posición de su menú al navegador. Para que
// el JOG no abra opciones hacia el borde inferior, la capa visual es propia y
// se ancla siempre sobre su botón; el <select> original mantiene el estado y
// los listeners existentes del cockpit.
function setupJogUpwardSelect(select) {
  if (!select || select.dataset.upwardReady === `true`) return null;
  select.dataset.upwardReady = `true`;
  select.classList.add(`jog-select-native`);
  const wrap = document.createElement(`div`);
  wrap.className = `jog-select-wrap`;
  select.parentNode.insertBefore(wrap, select);
  wrap.appendChild(select);
  const trigger = document.createElement(`button`);
  trigger.type = `button`;
  trigger.className = `jog-select-trigger`;
  trigger.setAttribute(`aria-haspopup`, `listbox`);
  trigger.setAttribute(`aria-expanded`, `false`);
  trigger.setAttribute(`aria-label`, select.getAttribute(`aria-label`) || ``);
  const menu = document.createElement(`div`);
  menu.className = `jog-select-menu hidden`;
  menu.setAttribute(`role`, `listbox`);
  menu.setAttribute(`aria-label`, select.getAttribute(`aria-label`) || ``);
  const close = () => {
    menu.classList.add(`hidden`);
    trigger.setAttribute(`aria-expanded`, `false`);
  };
  const sync = () => {
    const option = select.options[select.selectedIndex];
    trigger.textContent = option?.textContent || `—`;
    menu.querySelectorAll(`[role=option]`).forEach((item) => {
      item.setAttribute(`aria-selected`, String(item.dataset.value === select.value));
    });
  };
  Array.from(select.options).forEach((option) => {
    const item = document.createElement(`button`);
    item.type = `button`;
    item.className = `jog-select-option`;
    item.setAttribute(`role`, `option`);
    item.dataset.value = option.value;
    item.textContent = option.textContent;
    item.addEventListener(`click`, () => {
      select.value = option.value;
      select.dispatchEvent(new Event(`change`, { bubbles: true }));
      close();
      trigger.focus();
    });
    menu.appendChild(item);
  });
  trigger.addEventListener(`click`, () => {
    const opening = menu.classList.contains(`hidden`);
    document.querySelectorAll(`.jog-select-menu:not(.hidden)`).forEach((open) => open.classList.add(`hidden`));
    menu.classList.toggle(`hidden`, !opening);
    trigger.setAttribute(`aria-expanded`, String(opening));
    if (opening) menu.querySelector(`[aria-selected=true]`)?.focus();
  });
  trigger.addEventListener(`keydown`, (event) => {
    if (event.key === `Escape`) close();
    if (event.key === `ArrowDown` || event.key === `ArrowUp`) {
      event.preventDefault();
      if (menu.classList.contains(`hidden`)) trigger.click();
    }
  });
  document.addEventListener(`click`, (event) => { if (!wrap.contains(event.target)) close(); });
  select.addEventListener(`change`, sync);
  wrap.append(trigger, menu);
  sync();
  return { sync };
}
// Sin binding a proposito: al selector de PASO nadie le asigna `.value` por
// programa (`grep -n jogStepSelector` da solo su declaracion y esta linea), y
// `setupJogUpwardSelect` ya engancha su propio listener de `change`. Se llama
// por su efecto —construye el desplegable— y el handle sobraba: lo cazaba
// eslint como `no-unused-vars` y dejaba el gate de lint en rojo.
setupJogUpwardSelect(jogStepSelector);
const jogSpeedUpwardSelect = setupJogUpwardSelect(jogSpeedSelector);
function applyJogSpeedLevel(level, announce = false) {
  if (!level || !JOG_SPEED_MULT[level]) return;
  JOG_SPEED_LEVEL = level;
  STORE.set(`jog.speedLevel`, level);
  if (jogSpeedSelector) jogSpeedSelector.value = level;
  jogSpeedUpwardSelect?.sync();
  if (typeof updateJogFeedEffective === 'function') updateJogFeedEffective();
  if (announce) {
    toast(
      `Jog ${level === 'slow' ? 'LENTO' : level === 'fast' ? 'RÁPIDO' : 'NORMAL'} (×${JOG_SPEED_MULT[level]})`,
      'info',
      1500,
    );
  }
}
if (jogSpeedSelector) {
  jogSpeedSelector.addEventListener('change', () => applyJogSpeedLevel(jogSpeedSelector.value, true));
}

// Al cargar la webapp: restaurar el nivel persistido, seleccionar su valor y pintar
// el feed efectivo. DIFERIDO a DOMContentLoaded a propósito: JOG_SPEED_LEVEL,
// JOG_SPEED_MULT y SM (vía updateJogFeedEffective) se declaran más abajo
// (~3370-3400) y leerlos aquí en top-level aborta el monolito entero por TDZ.
window.addEventListener('DOMContentLoaded', () => {
  const saved = STORE.get(`jog.speedLevel`);
  if (saved && JOG_SPEED_MULT[saved]) JOG_SPEED_LEVEL = saved;
  if (jogSpeedSelector) jogSpeedSelector.value = JOG_SPEED_LEVEL;
  // LA PANTALLA MENTIA SOBRE LA VELOCIDAD DE JOG (medido 2026-08-30).
  // Asignar `.value` al <select> nativo NO repinta el desplegable propio que
  // construye setupJogUpwardSelect: su etiqueta visible solo se actualiza en
  // `sync()`. Sin esta llamada, al restaurar el nivel persistido el <select>
  // quedaba en `slow` y el operario leia "Normal ×1.0".
  // Reproducido en navegador contra el mock: fijar LENTO -> select=slow y
  // etiqueta "Lenta ×0.5"; recargar -> select=slow pero etiqueta "Normal ×1.0".
  // En un control de maquina, que la pantalla y el movimiento discrepen sobre
  // la velocidad del jog no es cosmetico. `applyJogSpeedLevel` ya hacia esta
  // misma llamada (mas arriba); a este camino se le olvido.
  jogSpeedUpwardSelect?.sync();
  if (typeof updateJogFeedEffective === 'function') updateJogFeedEffective();
});

/** Actualiza el texto del feed efectivo (paso × multiplicador, topado por M203). */
function updateJogFeedEffective(pendantStep) {
  if (Number.isFinite(pendantStep)) _jogDisplayStep = pendantStep;
  const feeds = (step, free = false) => {
    const feed = (ax) => free && ax !== `Z` && _jogFreeFeedFor ? _jogFreeFeedFor(ax)
      : jogFeedFor(ax, ax === `Z` && SM.current === STATES.ERROR ? 1 : step);
    const x = feed(`X`), y = feed(`Y`), z = feed(`Z`);
    return `${x === y ? `XY ${x}` : `X ${x} · Y ${y}`} · Z ${z} mm/min`;
  };
  const summary = (step, free = false) => `${t(`jog.stepReadout`, `Paso`)}: ${step} mm · ${t(`jog.feedReadout`, `Avance`)}: ${feeds(step, free)}`;
  const desktop = $(`jogFeedEffective`), pendant = $(`mpgJogSummary`);
  if (desktop) desktop.textContent = summary(SM.step || 1);
  if (pendant) pendant.textContent = _jogMode === `free`
    ? `${t(`jog.holdReadout`, `XY continuo · Z por pasos`)} · ${summary(_jogDisplayStep, true)}`
    : summary(_jogDisplayStep);
  [[`jogLongWarning`, SM.step], [`mpgJogWarning`, _jogDisplayStep]].forEach(([id, step]) => {
    const el = $(id);
    if (!el) return;
    el.hidden = !(step > JOG_HOLD_MAX_STEP);
    el.textContent = t(`jog.longWarning`, `Pasos largos: el movimiento sigue aunque sueltes. Para pararlo, PARO.`);
  });
}
// ════════════
// JOG — MOVIMIENTO MANUAL Y OVERRIDES
// ════════════
const JOG_FEED = {
    0.1: { xy: 60, z: 30 },
    1: { xy: 300, z: 150 },
    5: { xy: 800, z: 400 },
    10: { xy: 1500, z: 800 },
    // 18-oct: X/Y de los pasos largos bajan de 4000-4500 a 2000. En la máquina real
    // un paso de 200 mm se atascaba en Normal (4500) y Rápida (6000) y movía bien en
    // Lenta (2250). Con 640 pasos/mm a x16 (40 pasos enteros/mm) son ~900 y ~1200 rpm
    // frente a ~450: el motor pierde par por encima. Rápida queda en JOG_XY_SAFE_MAX.
    50: { xy: 2000, z: 1500 },
    100: { xy: 2000, z: 1500 },
    200: { xy: 2000, z: 1500 },
    500: { xy: 2000, z: 1500 },
  },
  JOG_Z_MAX = 10,
  // Tope del microajuste Z (M290) con trabajo (26-sep). En RRF la R de M290 es el MODO
  // (R1 relativo) y la distancia va en Z: el `M290 R${dist}` de antes no movía nada.
  // RRF ya limita cada orden relativa a ±1 mm (GCodes2.cpp:2762).
  JOG_BABYSTEP_MAX = 1;
// ── Multiplicador global de velocidad de jog (selector 3 niveles) ──
  // "Lento" = 0.5x (inspección cerca del material)
  // "Normal" = 1x (default)
  // "Rápido" = 2x (posicionamiento)
  // Se aplica en jogFeedFor() ANTES de los techos (JOG_XY_SAFE_MAX y M203).
  // 18-oct: "Rápido" ya no llega al M203 en X/Y. Se para en JOG_XY_SAFE_MAX, los
  // 2250 mm/min que la máquina real movió sin atascarse en Lenta.
  // PENDIENTE BANCO: subirlo solo tras mover 200 mm en X e Y a esa velocidad.
// Los pasos cortos son para precisión, no para velocidad.
let JOG_SPEED_LEVEL = 'normal';  // 'slow' | 'normal' | 'fast'
const JOG_SPEED_MULT = { slow: 0.5, normal: 1.0, fast: 2.0 },
  JOG_XY_SAFE_MAX = 2250,  // mm/min; techo de X/Y/A en el jog, además del M203
  _m203Limits = { X: 6000, Y: 6000, Z: 1500, A: 3000 },
  _m201Accel = { X: 80, Y: 80, Z: 30, A: 80 };
const _JOG_RAPID_STEP = 100;
function jogFeedFor(ax, step) {
  const e = JOG_FEED[step] || JOG_FEED[1];
  let f = ax === `Z` ? e.z : e.xy;
  // Shift + jog = jogJog (sub-velocidad para inspección, 25% de la base).
  // Útil cuando la herramienta está cerca del material y quieres avanzar milímetro a milímetro.
  // B2: el toggle FINO del pendant se acumula aquí (cualquiera de los dos → ×0.25).
  if (_shiftJogActive || _pendantFineJogActive) f = Math.max(50, Math.round(f * 0.25));
  // Multiplicador global (Lento/Normal/Rápido). Se acumula con Shift.
  f = Math.round(f * (JOG_SPEED_MULT[JOG_SPEED_LEVEL] || 1.0));
  if (ax !== `Z`) f = Math.min(f, JOG_XY_SAFE_MAX);
  return Math.min(f, _m203Limits[ax] || 99999);
}
// Avisos de guarda compartidos por doJogStep y el modo LIBRE (un solo texto por aviso).
function jogMsgOcupado() {
  return t(`msg.jogBlocked`, `Jog bloqueado: hay una macro o un comando en marcha — espera a que termine (el piloto RUNNING de la barra superior se apagará)`);
}
function jogMotivoTope(axis, dirSign) {
  const locks = AppState.limits && AppState.limits.endstopJogLocks;
  const lockKey = `${axis}${dirSign > 0 ? `+` : `-`}`;
  if (locks?.[lockKey]) return t(`msg.jogEndstopLocked`, `JOG bloqueado en este sentido mientras el final físico esté activo; libera el sensor y usa el sentido contrario para alejarte.`);
  const tg = AppState.limits && AppState.limits.triggers;
  if (!tg) return null;
  if (axis === `X` && dirSign > 0 && tg.XMax) return t(`msg.jogLimitXmax`, `Movimiento bloqueado: tope X Max activo — pulsa el botón −X (mover izquierda) para alejarte del final de carrera`);
  if (axis === `Y` && dirSign < 0 && tg.YMin) return t(`msg.jogLimitYmin`, `Movimiento bloqueado: tope Y Min activo — pulsa el botón +Y (mover atrás) para alejarte del final de carrera`);
  if (axis === `Y` && dirSign > 0 && tg.YMax) return t(`msg.jogLimitYmax`, `Movimiento bloqueado: tope Y Max activo — pulsa el botón −Y (mover adelante) para alejarte del final de carrera`);
  if (axis === `Z` && dirSign < 0 && tg.ZMin) return t(`msg.jogLimitZmin`, `Movimiento bloqueado: tope Z Min activo — pulsa el botón +Z (subir) para alejarte del final de carrera`);
  if (axis === `Z` && dirSign > 0 && tg.ZMax) return t(`msg.jogLimitZmax`, `Movimiento bloqueado: tope Z Max activo — pulsa el botón −Z (bajar) para alejarte del final de carrera`);
  return null;
}
function flashAxis(axis) {
  [`tv`, `rm`, `mpg`].forEach((prefix) => {
    const el = $(prefix + axis);
    if (!el) return;
    el.style.color = `var(--green)`;
    el.style.textShadow = `var(--glow-green)`;
    if (el._axisFlashTimer) clearTimeout(el._axisFlashTimer);
    el._axisFlashTimer = setTimeout(() => {
      el.style.color = ``;
      el.style.textShadow = ``;
      el._axisFlashTimer = null;
    }, CFG.axisFlashMs);
  });
}
let _jogBusy = !1;
const JOG_HOLD_MAX_STEP = 10;  // mm: por encima, mantener pulsado no repite el paso
let _shiftJogActive = !1;  // Shift+click en jog = jogJog (sub-velocidad)
let _pendantFineJogActive = !1;  // B2: toggle FINO del pendant (móvil). Equivalente móvil del Shift del cockpit. Se acumula con Shift: ambos activos = ×0.25.
// 18-oct (E2): un final físico corta todos los temporizadores propios de la UI.
// RRF 3.5.4 no aporta aquí una parada de jog segura demostrada; quedan como
// máximo dos segmentos B7 en vuelo y un segmento del jog por pasos.
const _jogHoldStops = new Set();
let _b7StopExternal = () => {};
window.stopJogContinuous = () => {
  _jogHoldStops.forEach((stop) => stop());
  _b7StopExternal();
};
// B — DOBLE JOG (t_d9f3c73d): cooldown 350 ms para evitar spam del toast
// cuando el operario insiste en la tecla durante el rechazo. Mismo número
// que el umbral de la Propuesta A — coherente con la nota de decisión.
let _jogRejectLastAt = 0;
const _JOG_REJECT_COOLDOWN_MS = 350;
async function doJogStep(axis, dirSign, paso) {
  // `paso`: el móvil llega con su _jogStep (mismas guardas, 13-sep); sin él, SM.step.
  if (paso === undefined) paso = SM.step;
  // B (t_d9f3c73d): vibración SOLO cuando la pulsación pasa todos los
  // guards (aceptada). Antes vibraba ANTES del guard _jogBusy (líneas 185-186
  // originales), lo que significaba que un rechazo también vibraba — confuso
  // porque el operario no sabe si fue feedback de acción exitosa o de rechazo.
  // La vibración ahora se mueve al final del try, junto al flash del eje.
  if (AppState.macro.running || SM.busy) {
    toast(jogMsgOcupado(), `warn`);
    return;
  }
  if (SM.current === STATES.TRANSITIONING) {
    toast(t(`msg.rrfTransitioning`, `Jog bloqueado: espera a confirmación del firmware`), `warn`);
    return;
  }
  // 14-nov: arranque incompleto (config.g cortado): sin escudo ni perfil SEDA no se mueve.
  if (AppState?.cache?.configComplete === false) {
    toast(t(`msg.blockedBootIncompleto`, `Bloqueado: la configuración no terminó de cargar al arrancar. Corrige el error que indica el aviso rojo y reinicia la placa.`), `warn`);
    return;
  }
  // P0 (t_ee1497a0, 2026-09-01): tras un paro de emergencia, el JOG solo
  // permite RETIRAR la herramienta en +Z. Cualquier otro movimiento (X, Y,
  // -Z) corta con aviso. +Z pide confirmación explícita: el operario debe
  // saber por qué se está moviendo la máquina después de un paro.
  //
  // Decisión de producto: bloqueamos aquí el caso GENERAL y delegamos en
  // machineMoveBlocked() para el resto de botones (HOME, M6, etc). El +Z
  // permitido se gestiona en este path porque es el ÚNICO punto donde un
  // jog sigue adelante tras el paro. Se modela con un flag local que el
  // resto del handler respeta: bypassea B-01 (allHomed) y soft limits JS
  // (la posición puede ser stale tras un paro), pero mantiene el guard de
  // triggers (endstops físicos del poll, sí son señal real).
  //
  // PENDIENTE BANCO: lo que RRF hace con un G1 después de un M112 no se ha
  // probado contra la Scylla. Esta guarda arregla la INTERFAZ, no afirma
  // que el firmware rechace el comando.
  let _postEstopZ = false;
  // 5-oct: tras M112 RRF ignora movimientos hasta M999 (GCodes2.cpp:597-599).
  if (SM.current === STATES.ERROR && SM._rebootPending) {
    return toast(t(`msg.estopSinMovimiento`, `Tras el PARO la máquina no acepta movimientos. Pulsa RESET y después HOME (sube Z antes de mover X/Y).`), `warn`);
  }
  if (SM.current === STATES.ERROR) {
    const isZUp = axis === `Z` && dirSign > 0;
    if (!isZUp) {
      toast(
        t(
          `msg.blockedEStop`,
          `Parada de emergencia activa. Rearma para recuperar el control. Puedes subir Z para retirar la herramienta.`,
        ),
        `warn`,
      );
      return;
    }
    // +Z tras paro: confirmación EXPLÍCITA. No es un jog normal: el
    // operario debe aceptar que entiende por qué se está moviendo la
    // herramienta después del paro. Si cancela, no se envía nada.
    // Re-entrada: si ya hay un modal abierto, confirmDialog devuelve false
    // → caída segura (no se mueve).
    const _ok = await confirmDialog(
      t(`dlg.estopZretirar.title`, `Retirar la herramienta en +Z`),
      t(
        `dlg.estopZretirar.body`,
        `La parada de emergencia está activa. Subir Z alejará la fresa del material.<br><br>Antes de confirmar, asegúrate de que la herramienta puede subir libremente sin colisionar con nada.<br><br><strong>¿Subir Z?</strong>`,
      ),
    );
    if (!_ok) return;
    _postEstopZ = true;
  }
  const _tope = jogMotivoTope(axis, dirSign);
  if (_tope) return toast(_tope, "err");
  // B-01: sin homing no se debe mover. RRF normalmente protege con M564 S1,
  // pero si el usuario activo M564 H0 (override de soft limits) el jog pasa
  // y puede mover la maquina sin que sepamos donde esta.
  //
  // VA AQUI, ANTES de la rama isActive, y no mas abajo: con un trabajo en
  // RUNNING/PAUSED el eje Z se convierte en babystep (M290) y hace return en
  // esta misma funcion, asi que un guard colocado despues NUNCA se ejecutaba
  // en ese camino. Y M290 MUEVE: es exactamente lo que este guard existe para
  // impedir. Lo detecto el propio test de B-01, que estaba en rojo.
  //
  // PENDIENTE BANCO: confirma en maquina que este guard no rompe el flujo
  // habitual (HOME al primer arranque, jog con M564 S1 por defecto) ni el
  // microajuste Z legitimo durante un trabajo iniciado CON homing.
  //
  // P0 (t_ee1497a0): en el caso +Z post-estop la herramienta puede estar
  // clavada y la máquina sin homing (escenario típico de paro en mitad de
  // trabajo). Si bloqueamos por allHomed, el operario NUNCA podrá subir Z
  // para liberar la herramienta, que es exactamente el caso que la spec
  // pide resolver. Bypass para ese path; en cualquier otro caso, el guard
  // sigue siendo duro.
  //
  // 11-oct: el bloqueo obedece «Requerir HOME» (global.requireHoming, el mismo
  // que pone M564 H en el firmware). Antes era incondicional: con la opción
  // desactivada el firmware ya aceptaba el G1, pero la interfaz no lo enviaba.
  // Con la opción OFF se mueve, avisando una vez de que la posición no es real.
  const _homReq = !(AppState.cache && AppState.cache.requireHoming === false);
  if (!_postEstopZ && !AppState.limits.allHomed && !_homReq && !AppState.limits.avisoSinHome) {
    AppState.limits.avisoSinHome = true;
    toast(t(`msg.jogSinHome`, `Moviendo SIN HOME (Requerir HOME desactivado): la máquina no sabe dónde está y los límites de recorrido no actúan. Vigila los finales de carrera.`), `warn`);
  }
  if (!_postEstopZ && !AppState.limits.allHomed && _homReq) {
    toast(t(`msg.jogBlockedHoming`, `Jog bloqueado: ejecuta HOME primero (botón HOME de la barra superior o G28) — sin HOME los límites de seguridad no saben dónde está la máquina y el firmware podría ignorar M564 H0 si está activo`), `warn`);
    return;
  }
  const isActive = SM.current === STATES.RUNNING || SM.current === STATES.PAUSED;
  let dist = dirSign * paso;
  if (isActive) {
    if (axis === `Z` && Math.abs(dist) > JOG_BABYSTEP_MAX)
      toast(t(`msg.babystepMax`, `Microajuste Z con trabajo: máximo ${JOG_BABYSTEP_MAX} mm por pulsación`, { max: JOG_BABYSTEP_MAX }), `warn`);
    else if (axis === `Z`) {
      const r = await RRF.gcode(`M290 R1 Z${dist}`);
      if (!r) {
        toast(`${t(`msg.errorAlMoverAxis`, `Error al mover`)} ${axis}`, `err`);
        return;
      }
      log(
        `Z-Babystepping: ${dist > 0 ? `+` : `-`}${Math.abs(dist)}mm`,
        `cmd`,
      );
      toast(
        `${t(`msg.zBabystepping`, `Microajuste Z`)}: ${dist > 0 ? `+` : `-`}${Math.abs(dist)}mm`,
        `info`,
      );
    }
    else toast(t(`msg.jogBlockedJob`, `Jog bloqueado durante trabajo`), `warn`);
    return;
  }
  if (axis === `Z` && paso > JOG_Z_MAX) {
    toast(t(`msg.zLimitWarn`, `Z limitado a ${JOG_Z_MAX}mm por seguridad — para bajar más ve a CONFIGURACIÓN → Motores y desmarca el tope, o monta la pieza más cerca de Z0`), `warn`);
    return;
  }
  if (_jogBusy) {
    // B (t_d9f3c73d): segundo jog mientras el primero sigue en vuelo.
    // Mostrar toast info con cooldown 350 ms para no acumular si el
    // operario insiste. NO vibración aquí (la vibración indica acción
    // aceptada, no rechazo).
    const now = Date.now();
    if (now - _jogRejectLastAt >= _JOG_REJECT_COOLDOWN_MS) {
      _jogRejectLastAt = now;
      if (typeof toast === `function`) {
        toast(
          t(`msg.jogAlreadyRunning`, `Jog en curso: la segunda pulsación se ha ignorado (espera a que termine)`),
          `info`,
        );
      }
    }
    return;
  }
  // ── Soft limit enforcement en UI (RRF solo aplica M208 a ejes homed) ──
  // Solo aplica si _softLimitsEnabled (M564 S1). Con S0 el usuario ha
  // desactivado los soft limits → no bloquear en la capa JS.
  //
  // P0 (t_ee1497a0): en el path +Z post-estop, la _machinePos puede ser
  // stale (el poll puede no haber llegado todavía tras el paro). Si
  // truncamos dist por soft limits calculados sobre una posición ficticia,
  // bloqueamos el rescate. El RRF físico (topes / M208 si están activos) es
  // la última línea. Aquí bypasseamos para que el +Z pueda subir hasta
  // donde el hardware le deje.
  if (!_postEstopZ) {
    const _lim = _softLimits[axis];
    // Sin HOME la posición del poll es ficticia (0 al arrancar): recortar contra
    // ella bloquearía movimientos legítimos. RRF tampoco aplica M208 a ejes sin
    // referenciar, así que la UI hace lo mismo (solo alcanzable con Requerir HOME OFF).
    if (_softLimitsEnabled && AppState.limits.allHomed === true && _lim && _lim.min !== null && _lim.max !== null) {
      const _cur = _machinePos[axis] ?? 0;
      const _tgt = _cur + dist;
      if (dist > 0 && _tgt > _lim.max) {
        dist = parseFloat((_lim.max - _cur).toFixed(4));
        if (dist <= 0) { toast(`${t(`msg.límiteSoftwareAxisMax`, `Límite software`)} ${axis} Max: ${_lim.max}mm`, `warn`); return; }
        toast(`${t(`msg.límiteSoftwareAxisMax`, `Límite software`)} ${axis} Max (${_lim.max}mm)`, `warn`);
      } else if (dist < 0 && _tgt < _lim.min) {
        dist = parseFloat((_lim.min - _cur).toFixed(4));
        if (dist >= 0) { toast(`${t(`msg.límiteSoftwareAxisMin`, `Límite software`)} ${axis} Min: ${_lim.min}mm`, `warn`); return; }
        toast(`${t(`msg.límiteSoftwareAxisMin`, `Límite software`)} ${axis} Min: ${_lim.min}mm`, `warn`);
      }
    }
  }
  _jogBusy = !0;
  // P0 (t_ee1497a0): feed REDUCIDO para +Z post-estop. Usamos el perfil
  // LENTO existente (JOG_FEED[1] = {z: 150} × JOG_SPEED_MULT.slow=0.5 =
  // 75 mm/min) sin importar el SM.step que tenga el operario. Si el operario
  // tenía SM.step=500, el feed reducido manda; si era 1mm, da igual. Cap por
  // _m203Limits.Z (1500 mm/min) — el 75 queda muy por debajo.
  let feed = jogFeedFor(axis, _postEstopZ ? 1 : paso);
  // P0 (t_ee1497a0): forzamos modo "precise" (sin M201 prefix rapid). Tras
  // un paro, no queremos la aceleración rápida de un JOG de posicionamiento.
  const rapidMode = !_postEstopZ && paso >= _JOG_RAPID_STEP;
  // 5-oct: sin M201 (sin M400 y con una caché vieja); el jog usa la del modo activo.
  const jogCmd = 'G91\nG1 ' + axis + dist + ' F' + feed + '\nG90';
  try {
    const r = await RRF.gcode(jogCmd);
    if (!r) {
      toast(`${t(`msg.errorAlMoverAxis`, `Error al mover`)} ${axis}`, `err`);
      _jogBusy = !1;
      return;
    }
    log(
      `Jog ${axis}${dist > 0 ? `+` : `-`}${paso}mm F${feed}${rapidMode ? ` RAPID` : ``}`,
      `cmd`,
    );
    flashAxis(axis);
    // B (t_d9f3c73d): vibración SOLO en éxito. Antes se ejecutaba antes
    // del guard (rotechos-jog.js:185-186 originales) y por tanto también
    // vibraba en un rechazo — confunde al operario.
    navigator.vibrate?.(20);
  } catch {
    toast(`${t(`msg.errorAlMoverAxis`, `Error al mover`)} ${axis}`, `err`);
    _jogBusy = !1;
    return;
  }
  // Actualización optimista de posición — evita que el siguiente jog use datos stale del poll
  // (el poll puede tardar hasta 500ms en reflejar la nueva posición)
  _machinePos[axis] = parseFloat(((_machinePos[axis] ?? 0) + dist).toFixed(4));
  const lockMs = Math.max(250, (Math.abs(paso) / (feed / 60)) * 1000 + 120);
  setTimeout(() => {
    _jogBusy = !1;
  }, lockMs);
}
($$(`[data-axis][data-dir]`).forEach((b) => {
  // V2-001: Jog continuo al mantener pulsado (pointerdown > umbral -> setInterval que
  // reenvía el mismo jogCmd cada JOG_HOLD_INTERVAL_MS). El click corto (< JOG_HOLD_TRIGGER_MS)
  // sigue funcionando como antes: un tap = un step. Esto NO rompe el comportamiento
  // actual (el handler 'click' sigue ahí), solo añade el modo hold.
  const axis = b.dataset.axis;
  const dir = b.dataset.dir === `+` ? 1 : -1;
  let holdTimer = null;
  let holdInterval = null;
  let didHold = false;
  let pulsado = false;
  const startHold = () => {
    didHold = false;
    pulsado = true;
    if (holdTimer) clearTimeout(holdTimer);
    if (holdInterval) { clearInterval(holdInterval); holdInterval = null; }
    // 31-oct: cada paso es un G1 entero que soltar no cancela (500 mm a F2000 son 15 s). Con
    // un paso largo no hay modo continuo: al soltar sale un solo paso, por el click.
    if (SM.step > JOG_HOLD_MAX_STEP) return;
    holdTimer = setTimeout(async () => {
      // Entramos en modo continuo: calculamos el primer step (reusa doJogStep) y luego
      // repetimos el MISMO jogCmd periódicamente. Para no duplicar lógica, dejamos que
      // doJogStep se ejecute una vez; después, mientras siga pulsado, enviamos el mismo
      // comando cada JOG_HOLD_INTERVAL_MS. doJogStep ya gestiona _jogBusy internamente.
      didHold = true;
      if (navigator.vibrate) navigator.vibrate(20);
      try { await doJogStep(axis, dir); } catch {}
      // 15-sep: si se soltó durante ese primer paso, no arranca el continuo. Antes el
      // intervalo se creaba después de soltar y nadie lo paraba: el eje seguía moviéndose.
      if (!pulsado) return;
      // Con trabajo, Z es microajuste (M290): una pulsación, un paso.
      if (SM.current === STATES.RUNNING || SM.current === STATES.PAUSED) return;
      holdInterval = setInterval(() => {
        // doJogStep ya respeta _jogBusy; si está ocupado, simplemente este tick no hace nada.
        doJogStep(axis, dir).catch(() => {});
      }, 100);
    }, 250);
  };
  const endHold = () => {
    pulsado = false;
    if (holdTimer) { clearTimeout(holdTimer); holdTimer = null; }
    if (holdInterval) { clearInterval(holdInterval); holdInterval = null; }
  };
  _jogHoldStops.add(endHold);
  // 31-oct: solo el boton principal. Con el derecho se abre el menu y el pointerup no llega.
  b.addEventListener(`pointerdown`, (e) => { e.preventDefault(); if (e.button === 0) startHold(e); });
  b.addEventListener(`pointerup`, endHold);
  b.addEventListener(`pointerleave`, endHold);
  b.addEventListener(`pointercancel`, endHold);
  b.addEventListener(`contextmenu`, endHold);
  // Si la ventana pierde el foco con el boton pulsado, el pointerup puede no llegar nunca.
  window.addEventListener(`blur`, endHold);
  document.addEventListener(`visibilitychange`, endHold);
  // El handler 'click' sigue para taps cortos (sub-250ms suelta antes de que dispare el hold).
  b.addEventListener(`click`, async () => {
    if (didHold) { didHold = false; return; } // el hold ya envió los comandos
    await doJogStep(axis, dir);
  });
}),
  (function () {
    const KEY_MAP = {
      ArrowRight: { axis: `X`, dir: 1 },
      ArrowLeft: { axis: `X`, dir: -1 },
      ArrowUp: { axis: `Y`, dir: 1 },
      ArrowDown: { axis: `Y`, dir: -1 },
      PageUp: { axis: `Z`, dir: 1 },
      PageDown: { axis: `Z`, dir: -1 },
    };
    // En escritorio, mantener una flecha pulsada debe ser un movimiento
    // continuo real. Antes se descartaba `e.repeat`, así que el navegador solo
    // producía un paso y el operario tenía que golpear la tecla varias veces.
    // Reutilizamos doJogStep para conservar HOME, finales, soft-limits, PARO y
    // el paso seleccionado. Mientras el comando anterior está en vuelo no se
    // encola otro: el siguiente tick lo intenta de nuevo sin lanzar toasts de
    // "ocupado" ni saturar el ESP32.
    const KEYBOARD_JOG_INTERVAL_MS = 90;
    let keyboardHold = null;
    function stopKeyboardJog() {
      const hold = keyboardHold;
      keyboardHold = null;
      if (!hold) return;
      hold.held = false;
      if (hold.timer) clearTimeout(hold.timer);
      document
        .querySelectorAll(`.jog-btn.active,.jog-z-btn.active`)
        .forEach((btn) => btn.classList.remove(`active`));
    }
    async function keyboardJogTick(hold) {
      if (!hold.held || keyboardHold !== hold) return;
      if (SM.current === STATES.RUNNING || SM.current === STATES.PAUSED) {
        stopKeyboardJog();
        return;
      }
      if (!_jogBusy) {
        try { await doJogStep(hold.axis, hold.dir); } catch (_) {}
        // 31-oct: como el raton: un paso largo no se repite (ni se cancela al soltar).
        if (SM.step > JOG_HOLD_MAX_STEP) return;
      }
      if (hold.held && keyboardHold === hold)
        hold.timer = setTimeout(() => keyboardJogTick(hold), KEYBOARD_JOG_INTERVAL_MS);
    }
    function startKeyboardJog(map, code) {
      stopKeyboardJog();
      const hold = { axis: map.axis, dir: map.dir, code, held: true, timer: null };
      keyboardHold = hold;
      document
        .querySelectorAll(`.jog-btn.active,.jog-z-btn.active`)
        .forEach((btn) => btn.classList.remove(`active`));
      document
        .querySelectorAll(
          `.jog-btn[data-axis="${hold.axis}"][data-dir="${hold.dir > 0 ? `+` : `-`}"],.jog-z-btn[data-axis="${hold.axis}"][data-dir="${hold.dir > 0 ? `+` : `-`}"]`,
        )
        .forEach((btn) => btn.classList.add(`active`));
      keyboardJogTick(hold);
    }
    _jogHoldStops.add(stopKeyboardJog);
    window.addEventListener(`blur`, stopKeyboardJog);
    document.addEventListener(`visibilitychange`, stopKeyboardJog);

    document.addEventListener(`keydown`, async (e) => {
      const map = KEY_MAP[e.key];
      if (!map) return;
      const tag = document.activeElement?.tagName;
      if (
        tag === `INPUT` ||
        tag === `TEXTAREA` ||
        tag === `SELECT`
      )
        return;
      // P0 (t_ee1497a0): tras un paro de emergencia, solo +Z (PageUp) se
      // permite por teclado — y pasa por doJogStep, que pide confirmación
      // explícita + feed reducido. El resto (X, Y, -Z) sigue cortando aquí.
      if (
        SM.current === STATES.ERROR &&
        !(map.axis === `Z` && map.dir > 0)
      )
        return;
      // BUG-02 (Gemini UI review): no ejecutar jog por teclado si hay un modal
      // abierto. El filtro por tag capturaba inputs dentro del modal, pero un
      // modal con foco en <button> o en el propio overlay dejaba pasar las
      // pulsaciones de flechas/X/Y/Z → movimiento físico accidental.
      if (document.querySelector(".modal-overlay.show")) return;
      if (SM.current === STATES.RUNNING) return;
      if (SM.current === STATES.PAUSED) {
        if (map.axis === `Z`) {
          e.preventDefault();
          const dist = map.dir * SM.step;
          if (e.repeat) return;
          if (Math.abs(dist) > JOG_BABYSTEP_MAX) {
            toast(t(`msg.babystepMax`, `Microajuste Z con trabajo: máximo ${JOG_BABYSTEP_MAX} mm por pulsación`, { max: JOG_BABYSTEP_MAX }), `warn`);
            return;
          }
          // 31-oct: por doJogStep, que exige HOME antes del M290 (que mueve) y avisa si falla.
          await doJogStep(`Z`, map.dir);
        }
        return;
      }
      e.preventDefault();
      // Los keydown repetidos del sistema operativo ya están cubiertos por el
      // temporizador propio; no deben iniciar otra cadena en paralelo.
      if (keyboardHold?.code === e.code) return;
      startKeyboardJog(map, e.code);
    });
    document.addEventListener(`keyup`, (e) => {
      if (keyboardHold?.code === e.code) stopKeyboardJog();
    });
  })());
function ovPct(val) {
  // 100% queda en el CENTRO de la barra (50%). Por debajo (10-100%) ocupa la mitad
  // izquierda, por encima (100-200%) la mitad derecha. Centro = velocidad nominal.
  return val <= 100 ? ((val - 10) / 90) * 50 : 50 + ((val - 100) / 100) * 50;
}
function ovBarColor(val) {
  if (val <= 100) {
    const t = (val - 10) / 90;
    return `linear-gradient(90deg, rgba(6,182,212,0.5), rgb(${Math.round(6 - t * 6)},${Math.round(182 + t * 30)},${Math.round(212 - t * 106)}))`;
  } else if (val <= 150) {
    const t = (val - 100) / 50;
    return `linear-gradient(90deg, rgba(0,212,106,0.4), rgb(${Math.round(0 + t * 255)},${Math.round(212 - t * 59)},${Math.round(106 - t * 106)}))`;
  } else {
    const t = Math.min(1, (val - 150) / 50),
      g = Math.round(153 - t * 153);
    return `linear-gradient(90deg, rgba(255,153,0,0.4), rgb(255,${g},0))`;
  }
}
function updateOvBar(fillId, trackId, val) {
  const pct = ovPct(val),
    fill = $(fillId),
    track = $(trackId);
  if (
    (fill &&
      ((fill.style.transform = `scaleX(${pct / 100})`),
      (fill.style.background = ovBarColor(val)),
      val <= 100
        ? (fill.style.boxShadow = `0 0 12px rgba(6,182,212,0.4)`)
        : val <= 150
          ? (fill.style.boxShadow = `0 0 12px rgba(255,153,0,0.4)`)
          : (fill.style.boxShadow = `0 0 14px rgba(255,59,59,0.5)`)),
    track)
  ) {
    const marker = track.querySelector(`.ov-bar-marker`);
    marker && (marker.style.left = pct + `%`);
  }
}
// La cadena de estado compartido con el poll (_ovFeedTs, _ovSpindleTs,
// _m220Timer, _m221Timer, _spindleRunning, _ovFeedTarget, _ovFeedRetries)
// se quedó DECLARADA en rotechos.js (~1175): la lee/escribe updateUI en
// cada ciclo y declararla aquí (defer posterior) crearía una ventana TDZ
// en el arranque del núcleo. Este módulo solo la asigna en handlers.
// _spindleOvPct y _spindleNominalRpm fueron retirados (jul-2026): ahora
// viven en window.SPINDLE (rotechos-spindle.js), única fuente de verdad.
// Acceso: SPINDLE.getOvPct() / SPINDLE.setOvPct(v) /
//         SPINDLE._getNominal() / SPINDLE._setNominal(rpm).
function syncFeedSlider(val) {
  ((val = Math.round(+val)), updateOvBar(`feedBarFill`, `feedBarTrack`, val));
  const fs = $(`feedSlider`),
    fv = $(`feedVal`);
  (fs && (fs.value = val),
    fv && (fv.textContent = `${val}%`),
    (_ovFeedTs = Date.now()),
    (_ovFeedTarget = val),
    (_ovFeedRetries = 0),
    (_ovFeedUnmatchedTs = 0),   // H-2: nuevo intento del operario → reset reloj
    (_ovFeedWarned = !1),       // H-2: permitir un aviso fresco si vuelve a diverger
    clearTimeout(_m220Timer),
    (_m220Timer = setTimeout(
      () => RRF.urgentGcode(`M220 S${val}`).catch(() => {}),
      CFG.ovDebounceMs,
    )));
}
// Nombre del G-code sin la ruta de la SD (0:/gcodes/...), que en el movil se comia la cabecera.
function _sinRuta(p) {
  return String(p || ``).replace(/^.*[\\/]/, ``);
}

function syncSpindleSlider(val) {
  val = Math.round(+val);
  const spindleMax =
      parseInt($(`mcfgSpindleMax`)?.value) || 24000;
  let maxOverride = 100;
  if (SPINDLE._getNominal() > 0)
    maxOverride = Math.min(Math.floor((spindleMax / SPINDLE._getNominal()) * 100), 200);
  val = Math.min(val, maxOverride);
  SPINDLE.setOvPct(val);
  updateOvBar(`spindleBarFill`, `spindleBarTrack`, val);
  const ss = $(`spindleSlider`),
    sv = $(`spindleVal`);
  ss && ((ss.value = val), (ss.max = maxOverride));
  sv && (sv.textContent = `${val}%`);
  _ovSpindleTs = Date.now();
  clearTimeout(_m221Timer);
  _m221Timer = setTimeout(() => {
    // Solo re-aplicar la velocidad si el husillo está EN MARCHA. Si está parado,
    // ajustar el override NO debe arrancarlo (antes mandaba M3 y lo reencendía).
    if (SPINDLE._getNominal() > 0 && _spindleRunning) {
      let targetRpm = Math.round((SPINDLE._getNominal() * val) / 100);
      const minRpm = CFG.spindleMin || 6000;
      targetRpm = Math.max(minRpm, Math.min(spindleMax, targetRpm));
      // Sin reintentos (urgentGcode): uno tardío podría rearrancar tras un M5.
      RRF.gcode(`M3 S${targetRpm}`).catch(() => {});
    }
  }, CFG.ovDebounceMs);
}
($(`feedSlider`).addEventListener(`input`, function () {
  syncFeedSlider(this.value);
}),
  $(`feedMinus`).addEventListener(`click`, () => {
    const s = $(`feedSlider`);
    syncFeedSlider(Math.max(+s.min, s.value - 5));
  }),
  $(`feedPlus`).addEventListener(`click`, () => {
    const s = $(`feedSlider`);
    syncFeedSlider(Math.min(+s.max, +s.value + 5));
  }),
  // M-M01 (2026-08-14): confirmación condicional. Si el override ya está
  // en 100%, reset directo (un click). Si está en cualquier otro valor,
  // modal genérico antes de perder el ajuste del operario.
  $(`feedReset`).addEventListener(`click`, async () => {
    const pct = +$(`feedSlider`).value;
    if (pct !== 100) {
      const ok = await confirmDashboard(
        t(`dlg.overrideReset.title`, `Restablecer override al 100%?`),
        t(`dlg.overrideReset.body`, `Tu ajuste actual de {pct}% se perderá.`)
          .replace(`{pct}`, String(pct)),
      );
      if (!ok) return;
    }
    (syncFeedSlider(100), toast(t(`msg.feedReset`, `Velocidad de avance → 100%`), `ok`));
  }),
  $(`spindleSlider`).addEventListener(`input`, function () {
    syncSpindleSlider(this.value);
  }),
  $(`spindleMinus`).addEventListener(`click`, () => {
    const s = $(`spindleSlider`);
    syncSpindleSlider(Math.max(+s.min, s.value - 5));
  }),
  $(`spindlePlus`).addEventListener(`click`, () => {
    const s = $(`spindleSlider`);
    syncSpindleSlider(Math.min(+s.max, +s.value + 5));
  }),
  // M-M01 (2026-08-14): idem feedReset — idem lógica, sin toast duplicado.
  $(`spindleReset`).addEventListener(`click`, async () => {
    const pct = +$(`spindleSlider`).value;
    if (pct !== 100) {
      const ok = await confirmDashboard(
        t(`dlg.overrideReset.title`, `Restablecer override al 100%?`),
        t(`dlg.overrideReset.body`, `Tu ajuste actual de {pct}% se perderá.`)
          .replace(`{pct}`, String(pct)),
      );
      if (!ok) return;
    }
    (syncSpindleSlider(100), toast(t(`msg.spindleReset`, `Velocidad del husillo → 100%`), `ok`));
  }),
  (function initSliderTracks() {
    const fs = $(`feedSlider`),
      ss = $(`spindleSlider`);
    (fs && updateOvBar(`feedBarFill`, `feedBarTrack`, +fs.value),
      ss && updateOvBar(`spindleBarFill`, `spindleBarTrack`, +ss.value));
    function addBarClick(trackId, syncFn) {
      const track = $(trackId);
      track &&
        track.addEventListener(`click`, function (e) {
          const rect = track.getBoundingClientRect(),
            pct = Math.max(
              0,
              Math.min(1, (e.clientX - rect.left) / rect.width),
            ),
            val = Math.round(10 + pct * 190);
          syncFn(Math.round(val / 5) * 5);
        });
    }
    (addBarClick(`feedBarTrack`, syncFeedSlider),
      addBarClick(`spindleBarTrack`, syncSpindleSlider));
  })());

((function initMPG() {
    // B2 enmendado: el operario selecciona paso (toogle) o LIBRE (ninguna activa).
    // Estado del modo se mantiene en `_jogMode` ('step' | 'free') y `_jogStep` (mm).
    // El handler de pills (B2+F2 anterior) absorbido aquí, sin bindFastTouch
    // (cuyo listener 'click' hace stopPropagation y cancela handlers siguientes).
    let _jogStep = 1;
    _jogMode = `step`;  // 'step' (con pill activa) o 'free' (LIBRE) — asignación top-level
    const _pad = $(`pendant2-jog-grid`);
    const _badge = $(`mpgModeBadge`);

    function _updateModeBadge() {
      updateJogFeedEffective(_jogStep);
      const hold = $(`mpgBtnHold`);
      if (hold) hold.setAttribute(`aria-pressed`, String(_jogMode === `free`));
      if (!_badge) return;
      if (_jogMode === `free`) {
        _badge.textContent = `LIBRE`;
        _badge.setAttribute(`data-mode`, `free`);
        if (_pad) _pad.classList.add(`pendant2-pad-free`);
        // Gate de homing: en modo LIBRE, requiere máquina homeada.
        // AppState.limits.allHomed es boolean (true/false). Con mock-server o sin
        // referencia, queda undefined → LIBRE deshabilitado por defecto.
        const homed = typeof AppState !== `undefined` && AppState.limits && (AppState.limits.allHomed === true
          || (AppState.cache && AppState.cache.requireHoming === false));
        if (!homed) _badge.setAttribute(`data-mode`, `not-homed`);
        else _badge.setAttribute(`data-mode`, `free`);
      } else {
        _badge.textContent = `${t(`pendant.jog.step.lbl`, `PASO`)} ${_jogStep}`;
        _badge.setAttribute(`data-mode`, `step`);
        if (_pad) _pad.classList.remove(`pendant2-pad-free`);
      }
    }
    // Estado inicial: pill "1" activa (ya viene en el HTML). El badge refleja eso.
    // Si por alguna razón no está activa, la activamos.
    const _initActive = $q(`#mpgView .x-step.active`);
    if (_initActive) _jogStep = parseFloat(_initActive.dataset.step);
    else {
      const _first = $q(`#mpgView .x-step[data-step="1"]`);
      if (_first) {
        _first.classList.add(`active`);
        _jogStep = 1;
      }
    }
    _updateModeBadge();

    // El continuo se solicita desde su control visible y conserva la confirmación obligatoria.
    async function _askLibreConfirm() {
      if (typeof confirmDialog !== `function`) return true; // sin modal: degrada a TOCTOU legacy (no debería pasar)
      return await confirmDialog(
        t(`dlg.jogLibre.title`, `Pasar a modo LIBRE`),
        `${t(`dlg.jogLibre.body1`, `En modo LIBRE los ejes X e Y se mueven MIENTRAS mantengas pulsada una flecha: un toque involuntario puede recorrer varios centímetros. El eje Z sigue moviéndose solo por pasos (el último paso que tenías seleccionado antes de entrar en LIBRE).`)}<br><br><strong>${t(`dlg.jogLibre.body2`, `¿Confirmas que quieres pasar a modo LIBRE?`)}</strong>`,
      );
    }
    function _reactivateDefaultPill() {
      // Vuelve a paso: deja pill 1 activa y sale de LIBRE.
      _jogMode = `step`;
      _jogStep = 1;
      $$(`#mpgView .x-step`).forEach((b) => b.classList.remove(`active`));
      const _first = $q(`#mpgView .x-step[data-step="1"]`);
      if (_first) _first.classList.add(`active`);
      _updateModeBadge();
    }
    // 31-oct: el lector de pantalla anuncia el paso elegido (antes, un «seleccionado» fijo en el 1).
    const _syncPillPressed = (btn) => btn.setAttribute(`aria-pressed`, String(btn.classList.contains(`active`)));
    $$(`#mpgView .x-step`).forEach((btn) => {
      _syncPillPressed(btn);
      new MutationObserver(() => _syncPillPressed(btn)).observe(btn, { attributes: true, attributeFilter: [`class`] });
    });
    let _libreConfirmPending = false;
    $(`mpgBtnHold`)?.addEventListener(`click`, async () => {
      if (_libreConfirmPending || _jogMode === `free`) return;
      _libreConfirmPending = true;
      try {
        if (await _askLibreConfirm()) {
          $$(`#mpgView .x-step`).forEach((b) => b.classList.remove(`active`));
          _jogMode = `free`;
          _updateModeBadge();
        } else _reactivateDefaultPill();
      } finally {
        _libreConfirmPending = false;
      }
    });
    $$(`#mpgView .x-step`).forEach((btn) => {
      function run(ev) {
        if (ev && ev.cancelable) ev.preventDefault();
        $$(`#mpgView .x-step`).forEach((b) => b.classList.remove(`active`));
        btn.classList.add(`active`);
        _jogStep = parseFloat(btn.dataset.step);
        _jogMode = `step`;
        _updateModeBadge();
      }
      btn.addEventListener(`click`, run, true);
      btn.__jogToggleB2 = run;
    });
    async function mpgJog(axis, dir) {
      if (navigator.vibrate) navigator.vibrate(20);
      if (SM.current === STATES.RUNNING) {
        toast(t(`msg.jogBloqueadoMáquinaEn`, `JOG bloqueado — máquina en marcha`), `warn`);
        return;
      }
      if (SM.current === STATES.PAUSED) {
        toast(t(`msg.jogBloqueadoTrabajoEn`, `JOG bloqueado — trabajo en pausa`), `warn`);
        return;
      }
      // B7: en modo LIBRE, X/Y los gestiona el streaming (pointerdown B7); el
      // click unico es NO-OP para no duplicar movimientos. Z, en cambio, usa
      // SIEMPRE el ultimo _jogStep preestablecido (regla A: LIBRE no aplica a Z).
      if (_jogMode === `free` && axis !== `Z`) return;
      // Mismas guardas que el escritorio (Sergi, 13-sep; acta 2026-09-13_pendant-jog-doble-envio-sin-guardas.md).
      await doJogStep(axis, dir === `+` ? 1 : -1, _jogStep);
    }
    // Un toque = un paso: el pointerdown de bindFastTouch ya mueve; el click solo
    // actúa sin puntero (detail 0: teclado o .click()). acta 2026-09-13_pendant-jog-doble-envio-sin-guardas.md
    const _soloSinPuntero = (fn) => (ev) => { if (!ev || ev.detail === 0) fn(); };
    (document
      .getElementById(`mpgYp`)
      .addEventListener(`click`, _soloSinPuntero(() => mpgJog(`Y`, `+`))),
      document
        .getElementById(`mpgYm`)
        .addEventListener(`click`, _soloSinPuntero(() => mpgJog(`Y`, `-`))),
      document
        .getElementById(`mpgXp`)
        .addEventListener(`click`, _soloSinPuntero(() => mpgJog(`X`, `+`))),
      document
        .getElementById(`mpgXm`)
        .addEventListener(`click`, _soloSinPuntero(() => mpgJog(`X`, `-`))),
      document
        .getElementById(`mpgZp`)
        .addEventListener(`click`, _soloSinPuntero(() => mpgJog(`Z`, `+`))),
      document
        .getElementById(`mpgZm`)
        .addEventListener(`click`, _soloSinPuntero(() => mpgJog(`Z`, `-`))),
      document
        .getElementById(`mpgBtnStart`)
        .addEventListener(`click`, () => $(`btnPlayPause`)?.click()),
      document
        .getElementById(`mpgBtnPause`)
        .addEventListener(`click`, () => $(`btnPlayPause`)?.click()),
      document
        .getElementById(`mpgBtnHome`)
        .addEventListener(`click`, () => $(`btnQaHomeAll`)?.click()),
      $(`mpgBtnEStop`).addEventListener(`click`, () => {
        $(`btnEStop`).click();
      }));

      // B2: FINO = toggle pegajoso ×0.25 (paridad con Shift del cockpit).
      // aria-pressed refleja el estado para CSS y a11y.
      const fineBtn = $(`mpgBtnFine`);
      if (fineBtn) {
        fineBtn.addEventListener(`click`, () => {
          _pendantFineJogActive = !_pendantFineJogActive;
          fineBtn.setAttribute(`aria-pressed`, _pendantFineJogActive);
          updateJogFeedEffective();
          if (navigator.vibrate) navigator.vibrate(15);  // feedback táctil breve
        });
      }
      // B2: bindFastTouch en los 6 botones de movimiento (touchstart con preventDefault
      // elimina el retardo ~300ms del clic en iOS y Android; compatible con mouse en desktop).
      const pendantJogBtns = [`mpgYp`,`mpgXm`,`mpgXp`,`mpgYm`,`mpgZp`,`mpgZm`];
      pendantJogBtns.forEach((id) => {
        const el = $(id);
        if (!el || typeof bindFastTouch !== `function`) return;
        // Mapear id → eje/dirección
        const map = { mpgYp:[`Y`,`+`], mpgXm:[`X`,`-`], mpgXp:[`X`,`+`], mpgYm:[`Y`,`-`], mpgZp:[`Z`,`+`], mpgZm:[`Z`,`-`] };
        bindFastTouch(el, (ev) => {
          if (ev && ev.cancelable) ev.preventDefault();
          // Solo ejecutar si el botón no está deshabilitado (H-5: ninguno de los 6 está disabled).
          mpgJog(map[id][0], map[id][1]);
        });
      });
      // H-5: PARAR retirado del panel; CANCELAR de TRABAJO → #btnSoftStop.
    ($$(`.mpg-feed-pre-btn`).forEach((btn) => {
      btn.addEventListener(`click`, () => {
        const currentFeed = parseInt($(`feedSlider`)?.value ?? `100`);
        btn.dataset.feedAbs
          ? syncFeedSlider(parseInt(btn.dataset.feedAbs))
          : btn.dataset.feedDelta &&
            syncFeedSlider(currentFeed + parseInt(btn.dataset.feedDelta));
      });
    }),
      (window.updateMPG = function (data, sm, pct, elapsedFmt, remainFmt, isPaused) {
        const isConnected = typeof SM !== 'undefined' && SM.connected;
        // Coordenadas (MCS/WCS, formato, suavizado) las gestiona ahora la capa DRO.
        // === DRO: fijar objetivo; la capa DRO anima a 60fps (mpg + pendant2 + cockpit) ===
        if (data?.coords?.xyz) DRO.setTarget(data.coords.xyz, data.coords.machine ?? null, isConnected);  // 31-oct: sin coordenadas, ni un cero
        const pill = $(`mpgStatePill`);
        // Corre en cada ciclo de telemetria: solo se escribe lo que cambia.
        if (pill) writeProp(pill.dataset, `state`, sm);
        // Traducción ES de estados para mpgStateTxt
        // A — SEÑAL DE ESPERA (t_d9f3c73d): AWAITING aparece cuando el poll
        // está esperando respuesta (state.status colgado > 350 ms). El
        // dataset.state del pendant lo pinta rotechos-poll.js:_paintAwaiting.
        // updateMPG puede pisarlo si SM.current es coherente; por eso el
        // poll tiene que re-pintar tras el ciclo si sigue en awaiting.
        // AUD-VIS (20-sep): era una COPIA a mano y se quedo corta — sin HOMING ni
        // SIMULATING, el fallback `|| sm` los pintaba EN INGLES en el movil, y
        // HOMING es movimiento real de los ejes. Se deriva de `STATE_META`
        // (rotechos.js), la fuente unica que ya usa el cockpit. AWAITING no vive
        // alli (lo pinta el poll, no es estado de SM): se añade aparte.
        const _STATE_ES = { AWAITING: t("state.awaiting", "ESPERANDO RESPUESTA") };
        if (typeof STATE_META !== `undefined`) {
          for (const [_k, _m] of Object.entries(STATE_META)) _STATE_ES[_k] = t(_m.key, _m.fallback);
        }
        setText(`mpgStateTxt`, !isConnected ? t("state.disconnected", "DESCONECTADO") : (_STATE_ES[sm] || sm));
        const mpgFileEl = $('mpgFilename');
        if (mpgFileEl) {
            writeText(mpgFileEl, SM.loadedFile ? _sinRuta(SM.loadedFile) : t(`msg.noFile`, `Sin archivo`));
            // Atenuado = "no hay archivo cargado". La opacidad era 0.3, que
            // componia 1.78:1 (oscuro) y 1.54:1 (claro) sobre el fondo del
            // header: por debajo de AA 4.5:1, medido con axe-core en
            // t_54ca5590. El minimo medido para AA es 0.71 en oscuro y 0.88
            // en claro; se usa 0.9 para cumplir en ambos temas con un solo
            // valor. Sigue leyendose como texto atenuado frente al 1 del
            // nombre de archivo real, que es la senal que distingue los dos
            // estados.
            mpgFileEl.style.opacity = SM.loadedFile ? '1' : '0.9';
        }
        setText(`mpgWCS`, $(`mWCS2`)?.textContent || t(`span.g54-e11d`, `PIEZA`));
        const isError = sm === `ERROR`;
        const isActive = sm === `RUNNING` || sm === `PAUSED` || (isError && !!SM.loadedFile && !!SM.jobStartTime);
        $(`mpgProgWrap`).style.display = isActive && SM.loadedFile ? `flex` : `none`;
        const pctEl = $(`mpgProgPct`);
        writeText(pctEl, `${pct}%`);
        const mpgBar = $(`mpgProgBar`);
        if (mpgBar) {
          mpgBar.style.transform = `scaleX(${pct / 100})`;
          writeProp(mpgBar, `className`, `mpg-prog-bar-fill` + (isPaused ? ` paused` : ``));
        }
        writeText($(`mpgProgElapsed`), elapsedFmt);
        writeText($(`mpgProgRemaining`), remainFmt);
        const rpm = data?.spindles?.[0]?.active ?? data?.spindle?.current ?? data?.params?.spindleSpeeds?.[0] ?? 0;
        const spindleState = data?.spindles?.[0]?.state;
        const spindleRunning = spindleState == null ? rpm > 0 : spindleState === `forward` || spindleState === `reverse`;
        const mpgRpmEl = $(`mpgRPM`);
        writeText(mpgRpmEl, !isConnected ? `---` : String(Math.round(rpm)));
        const mpgSpBar = $(`mpgSpindleBar`);
        if (mpgSpBar) mpgSpBar.style.transform = `scaleX(${!isConnected ? 0 : Math.min(rpm / CFG.maxRPM, 1)})`;
        const mpgSpStatus = $(`mpgSpindleStatus`);
        // 3-oct (acabado-3): sin el `!isActive` que tenia, en marcha se quedaba «PARADO» con el husillo a 18000.
        writeText(mpgSpStatus, !isConnected ? `---` : document.body.classList.contains(`spindle-manual`) ? t(`spindle.manual`, `MANUAL`) : (spindleRunning ? t(`state.running`, `EN MARCHA`) : t(`state.idle`, `PARADO`)));
        // H-5: overrides móviles Feed/Spindle retirados del pendant.
        writeProp($(`mpgBtnStart`), `disabled`, sm !== `READY` && sm !== `PAUSED`);
        // Hermana movil de C§13 (auditoria visual 20-sep): el tile decia
        // «INICIAR» con el trabajo PAUSADO; el cockpit si dice «REANUDAR»
        // (rotechos.js:857). Va tambien el gemelo de TRABAJO, que dispara la
        // MISMA accion. Se mueve `data-i18n` y el cache `i18nEs`, no solo el
        // texto: applyOne() restaura ese cache en espanol y volveria a
        // «INICIAR» al cambiar de idioma.
        const _rean = sm === `PAUSED`;
        [[`mpgBtnStart`, `pendant.dash.start`, `INICIAR`],
          [`pendant2RunBtnStart`, `pendant.run.start`, `INICIAR`]].forEach(([id, k0, es0]) => {
          const sp = $(id)?.querySelector(`span`);
          if (!sp) return;
          const k = _rean ? `btn.resume` : k0;
          if (sp.getAttribute(`data-i18n`) === k) return;
          const es = _rean ? `REANUDAR` : es0;
          sp.setAttribute(`data-i18n`, k);
          sp.dataset.i18nEs = es;
          sp.textContent = t(k, es);
        });
        writeProp($(`mpgBtnPause`), `disabled`, sm !== `RUNNING`);
        // HOME disponible también en IDLE (antes solo READY/PAUSED → recién
        // arrancado y sin archivo, el botón quedaba muerto). Solo se bloquea cortando.
        writeProp($(`mpgBtnHome`), `disabled`, sm === `RUNNING` || sm === `HOMING` || sm === `SIMULATING`);
        // Los gemelos de TRABAJO copian el estado de estos. ABORTAR nunca se deshabilita.
        [[`pendant2RunBtnStart`, `mpgBtnStart`], [`pendant2RunBtnPause`, `mpgBtnPause`]].forEach(([g, o]) => {
          if ($(g) && $(o)) writeProp($(g), `disabled`, $(o).disabled);
        });
        // === DRO de pantallas secundarias PENDANT2 ===
        try {
          // (coords pendant2 jog/wcs/run/mcs ahora las pinta la capa DRO a 60fps)
          // RUN stats
          const rf = $(`pendant2RunFeed`);
          writeText(rf, !isConnected ? `---` : Math.round((data?.currentMove?.requestedSpeed ?? 0) * 60));
          const rr = $(`pendant2RunRPM`);
          writeText(rr, !isConnected ? `---` : String(Math.round(rpm)));
          writeText($(`pendant2RunPct`), pct + "%");
          const rbar = $(`pendant2RunBar`); if (rbar) rbar.style.transform = `scaleX(${pct / 100})`;
          writeText($(`pendant2RunElapsed`), elapsedFmt);
          writeText($(`pendant2RunRemain`), remainFmt);
          const dfn = $(`pendant2ProgFname`);
          if (dfn && typeof SM !== "undefined" && SM.loadedFile) writeText(dfn, _sinRuta(SM.loadedFile));
          // (pendant2FeedBar era un id del stub #h4bis-dormant-stubs —
          // display:none, no se ve. La barra visible del override feed es
          // `pendant2RunFeedBar`, actualizada más abajo. Esta escritura
          // quedó muerta; se retira H-3 del busca-pendant v1.)
          const spBig = $(`pendant2SpBig`);
          if (spBig) {
            writeText(spBig, !isConnected ? `---` : String(Math.round(rpm)));
            spBig.style.color = !isConnected ? "var(--text-2)" : (spindleRunning ? "var(--green)" : "var(--text-2)");
          }
          const spBarFull = $(`pendant2SpBarFull`);
          if (spBarFull) spBarFull.style.transform = `scaleX(${!isConnected ? 0 : Math.min(rpm / CFG.maxRPM, 1)})`;
          const rfo = $(`pendant2RunFeedBar`), rfv = $(`pendant2RunFeedVal`), fo = (data?.params?.speedFactor ?? 100);
          if (rfo) rfo.style.transform = `scaleX(${Math.min(fo, 200) / 200})`;
          writeText(rfv, Math.round(fo) + "%");
        } catch (e) {
          LOG.warn("PENDANT2 updateMPG error:", e);
        }
      }));
  })());

// ════════════
// B7 — Motor de JOG continuo (LIBRE)
// Streaming de microsegmentos. Mantener pulsada una flecha = movimiento
// continuo; soltar = parar. Buffer máximo 2 segmentos en vuelo. Paradas
// obligatorias: pointerup, pointercancel, pointerleave, touchcancel,
// blur de ventana, visibilitychange, strikes del poll. Feeds: X/Y desde
// jogFeedFor() con techo M203; Z al 50% del feed libre X/Y. FINO ×0.25.
// Gate de homing: sin máquina referenciada, LIBRE no disponible. Modo
// Escuela: toast de primera vez por sesión al activar LIBRE.
// Cero cambios en firmware (.g): todo es lado UI.
// ════════════
((function b7JogFree() {
  const B7_INTERVAL_MS = 150;     // periodo entre segmentos
  const B7_MAX_BUFFER = 2;        // segmentos en vuelo max
  const B7_DURATION_MS = 150;     // duracion de un segmento (d = feed * duracion)

  // Estado del motor LIBRE
  let _active = false;
  let _axis = null;     // 'X' | 'Y' | 'Z' con signo: 'X+' | 'X-' | 'Y+' | 'Y-' | 'Z+' | 'Z-'
  let _intervalId = null;
  let _bufferCount = 0;  // segmentos enviados sin respuesta
  let _lastSegmentAt = 0;
  let _predPos = null;   // posicion prevista tras los segmentos ya enviados (recorte)

  function _b7IsMachineRunning() {
    return typeof SM !== `undefined` && STATES && SM.current === STATES.RUNNING;
  }
  function _b7IsMachinePaused() {
    return typeof SM !== `undefined` && STATES && SM.current === STATES.PAUSED;
  }
  function _b7IsMachineError() {
    return typeof SM !== `undefined` && STATES && SM.current === STATES.ERROR;
  }
  // #pendantJogLock bloquea LIBRE. El lock se muestra por el SM (updateButtonStates
  // y similares). Aqui comprobamos tanto el SM (corrida) como la visibilidad
  // del propio pendantJogLock.
  function _b7IsJogLocked() {
    if (_b7IsMachineRunning() || _b7IsMachinePaused() || _b7IsMachineError()) return true;
    const lock = $('pendantJogLock');
    if (lock && getComputedStyle(lock).display !== `none`) return true;
    return false;
  }
  function _b7IsHomed() {
    return typeof AppState !== `undefined` && AppState.limits && AppState.limits.allHomed === true;
  }
  // 11-oct: LIBRE exige HOME solo con «Requerir HOME» activado (global.requireHoming).
  function _b7HomeOk() {
    if (_b7IsHomed()) return true;
    return typeof AppState !== `undefined` && AppState.cache && AppState.cache.requireHoming === false;
  }
  function _b7IsSchoolMode() {
    return document.body.classList.contains(`school-mode`);
  }
  // Feed para LIBRE: para X/Y usa jogFeedFor a velocidad normal (nivel 1x).
  // Para Z usa el 50% del feed libre de X/Y. Ambos topados por M203.
  // FINO multiplica x0.25 encima.
  function _b7FeedFor(axis) {
    // Para LIBRE, usamos un step "grande" (50) que se acerca al feed maximo
    // disponible, de modo que el streaming recorra el maximo por segmento.
    const step = 50;
    let f = jogFeedFor(axis, step);
    if (axis === `Z`) f = Math.round(f * 0.5);
    if (typeof _pendantFineJogActive !== `undefined` && _pendantFineJogActive) f = Math.max(50, Math.round(f * 0.25));
    return f;
  }
  _jogFreeFeedFor = _b7FeedFor;
  updateJogFeedEffective();
  // Distancia de un segmento: feed (mm/min) * duracion (min).
  // Para 150 ms y feed 2000 mm/min = 2000 * 0.0025 = 5 mm.
  // El M203 limita en ultima instancia (lo aplicamos en RRF.gcode por feed).
  function _b7SegmentDistance(axis) {
    const f = _b7FeedFor(axis);
    return (f * B7_DURATION_MS) / 60000;
  }
  // Toast de primera vez por sesion (solo Modo Escuela).
  function _b7ShowFirstTimeToast() {
    if (!_b7IsSchoolMode()) return;
    if (STORE.get(`jog.libreToastShown`)) return;
    STORE.set(`jog.libreToastShown`, true);
    toast(t(`msg.jogLibreFirstTime`, `Modo LIBRE: la maquina se mueve mientras mantengas pulsado`), `info`);
  }
  // Guardas en CADA segmento (Sergi, 13-sep): mismas condiciones y avisos que doJogStep.
  function _b7Motivo(ax, sign) {
    if (_b7IsJogLocked()) return t(`msg.jogBloqueadoMáquinaEn`, `JOG bloqueado — maquina en marcha`);
    if (!_b7HomeOk()) return t(`msg.jogRefFirst`, `Referencia la maquina antes (HOME) para usar LIBRE`);
    if (AppState.macro.running || SM.busy) return jogMsgOcupado();
    return jogMotivoTope(ax, sign);
  }
  // Envia un segmento si hay hueco en el buffer.
  async function _b7SendSegment() {
    if (!_active || !_axis) return;
    const sign = _axis.slice(-1);  // '+' o '-'
    const baseAx = _axis[0];
    const motivo = _b7Motivo(baseAx, sign === `-` ? -1 : 1);
    if (motivo) {
      _b7Stop();
      toast(motivo, `warn`);
      return;
    }
    if (_bufferCount >= B7_MAX_BUFFER) return;  // buffer lleno
    const d = _b7SegmentDistance(baseAx);
    let dNum = sign === `-` ? -d : d;
    // Recorte en el límite; el poll llega tarde: se usa también la posición prevista.
    let ultimo = false;
    const lim = _softLimits[baseAx];
    if (_softLimitsEnabled && _b7IsHomed() && lim && lim.min !== null && lim.max !== null) {
      const real = _machinePos[baseAx] ?? 0;
      const cur = _predPos === null ? real : (dNum > 0 ? Math.max(real, _predPos) : Math.min(real, _predPos));
      if (dNum > 0 && cur + dNum > lim.max) { dNum = lim.max - cur; ultimo = true; }
      else if (dNum < 0 && cur + dNum < lim.min) { dNum = lim.min - cur; ultimo = true; }
      if (ultimo && (sign === `-` ? dNum > -0.001 : dNum < 0.001)) {
        _b7Stop();
        toast(`${t(sign === `-` ? `msg.límiteSoftwareAxisMin` : `msg.límiteSoftwareAxisMax`, `Límite software`)} ${baseAx} ${sign === `-` ? `Min` : `Max`}: ${sign === `-` ? lim.min : lim.max}mm`, `warn`);
        return;
      }
      _predPos = cur + dNum;
    }
    const dist = dNum.toFixed(4);
    const f = _b7FeedFor(baseAx);  // 31-oct: el eje sin signo; con `X+` no se aplicaba el tope M203
    const code = `G91\nG1 ${baseAx}${dist} F${f}\nG90`;
    _bufferCount++;
    _lastSegmentAt = Date.now();
    if (ultimo) {
      _b7Stop();
      toast(`${t(sign === `-` ? `msg.límiteSoftwareAxisMin` : `msg.límiteSoftwareAxisMax`, `Límite software`)} ${baseAx} ${sign === `-` ? `Min` : `Max`}: ${sign === `-` ? lim.min : lim.max}mm`, `warn`);
    }
    try {
      await RRF.gcode(code);
    } catch (e) {
      LOG.warn(`[B7] Error enviando segmento:`, e);
    } finally {
      _bufferCount = Math.max(0, _bufferCount - 1);
    }
  }
  // Arranca el streaming.
  function _b7Start(axis) {
    if (_active) _b7Stop();
    if (_b7IsJogLocked()) {
      toast(t(`msg.jogBloqueadoMáquinaEn`, `JOG bloqueado — maquina en marcha`), `warn`);
      return;
    }
    if (!_b7HomeOk()) {
      toast(t(`msg.jogRefFirst`, `Referencia la maquina antes (HOME) para usar LIBRE`), `warn`);
      return;
    }
    if (_jogMode !== `free`) {
      // El operario no esta en modo LIBRE (hay una pill activa).
      // Salimos silenciosamente; el pad sigue funcionando en modo paso.
      return;
    }
    // A: LIBRE solo afecta a X/Y. El eje Z usa siempre pasos preestablecidos
    // (mpgJog ya retorna cuando _jogMode==='free'; aqui blindamos el path de
    // streaming para que un pointerdown en Z+/Z- no haga NADA en modo LIBRE).
    if (axis[0] === `Z`) {
      toast(t(`msg.jogFreeZBlocked`, `En modo LIBRE, Z solo se mueve con pasos preestablecidos`), `warn`);
      return;
    }
    _active = true;
    _axis = axis;
    _bufferCount = 0;
    _predPos = null;
    _b7ShowFirstTimeToast();
    // Primer segmento inmediato
    _b7SendSegment();
    // Luego cada B7_INTERVAL_MS
    _intervalId = setInterval(_b7SendSegment, B7_INTERVAL_MS);
    if (navigator.vibrate) navigator.vibrate(20);
  }
  // Detiene el streaming en seco.
  function _b7Stop() {
    if (!_active) return;
    _active = false;
    _axis = null;
    if (_intervalId !== null) {
      clearInterval(_intervalId);
      _intervalId = null;
    }
  }
  _b7StopExternal = _b7Stop;
  // Handler unificado: cuando se hace pointerdown en una flecha, si estamos
  // en modo LIBRE y la maquina esta homeada, arrancamos el streaming. Las
  // paradas se enganchan en cada flecha para que cada flecha tenga su propio
  // set de paradas (mas robusto que un set global).
  function _b7AttachBtn(id, axis) {
    const el = $(id);
    if (!el) return;
    const _start = () => { _b7Start(axis); };
    const _stop = () => { _b7Stop(); };
    el.addEventListener(`pointerdown`, _start);
    // Paradas obligatorias (todas). Si el browser dispara mas de una, _b7Stop
    // es idempotente (early-return si !_active).
    el.addEventListener(`pointerup`, _stop);
    el.addEventListener(`pointercancel`, _stop);
    el.addEventListener(`pointerleave`, _stop);
    el.addEventListener(`touchcancel`, _stop);
    el.addEventListener(`touchend`, _stop);
    // Backup: si la ventana pierde foco o se oculta, paramos en seco.
    window.addEventListener(`blur`, _stop);
    document.addEventListener(`visibilitychange`, _stop);
  }
  // El ciclo principal actualiza SM.connected antes de ejecutar los hooks de UI.
  registerUIHook(`b7-connection`, () => {
    if (typeof SM !== `undefined` && SM.connected === false) _b7Stop();
  });
  // Mapeo id -> eje con signo (B7)
  // Las celdas del pad (filas 2 y 3 del grid 3x3):
  //   fila 1: Z+ | Y+ | Z-
  //   fila 2: X- | (modo) | X+
  //   fila 3: FINO | Y- | (vacia)
  // Las flechas operativas en LIBRE son: Y+, Y-, X+, X-, Z+, Z-.
  _b7AttachBtn(`mpgYp`, `Y+`);
  _b7AttachBtn(`mpgYm`, `Y-`);
  _b7AttachBtn(`mpgXp`, `X+`);
  _b7AttachBtn(`mpgXm`, `X-`);
  _b7AttachBtn(`mpgZp`, `Z+`);
  _b7AttachBtn(`mpgZm`, `Z-`);
})());
