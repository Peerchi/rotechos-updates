// ---
// rotechos-config-modal-core.js — SHIM EAGER del modal de CONFIGURACIÓN.
//
// Por qué existe (t_b8cd40c2, 5.º intento de extracción del modal).
//   El modal pesa 278 KB — la fila roja del objetivo de software (153 KB).
//   Para reducirlo hay que sacarlo del arranque en frío, pero NO todo se
//   puede mover: tres símbolos del modal son CONSUMIDOS en caliente por
//   módulos que están en el shell inicial:
//
//     · `_endstopCfg`        rotechos.js (poll, status), rotechos-poll.js
//                            (vigilancia GPIO desde el primer tick) y
//                            varios tests e2e que escriben en
//                            `window._endstopCfg.Y.minOn` antes de abrir
//                            la pestaña.
//     · `parseRotechPills`   Lo usa el propio modal y nada más: PERO el
//                            parser es pequeño y deja el contrato claro
//                            en un fichero con un único cometido, mejor
//                            que compartir frontera con 5072 líneas.
//     · `CFG_FIELDS.mcfgSacSensorZ`  ZCAL (rotechos.js:4750) lo lee SIN
//                            abrir el modal — la calibración del sensor
//                            Z escribe el global y reinicia. Si el modal
//                            es perezoso, el ZCAL falla en silencio.
//
//   Lo que se queda en el modal (LAZY) es TODO lo demás: CFG_FIELDS (sin
//   la entrada del sensor Z), HW_LIMITS, hwCheck, CFG_AXIS_GROUPS,
//   CFG_GPIO_MAP, openMachineConfig, cfgPopulate, loadPersistentUiConfig,
//   _applyM92/208Instant, las funciones de populate/save por pestaña,
//   las barras TMC, el modo eje A, los handlers de teclado.
//
// Posición en index.html: defer, justo DESPUÉS de `rotechos.js`. El orden
// entre ambos da igual y conviene no afirmar lo contrario: este shim publica
// en `window` (no declara bindings léxicos), y todos los consumidores del
// monolito —`_endstopCfg` en el poll, `CFG_FIELDS.mcfgSacSensorZ` en ZCAL,
// el chequeo de SHELL_SENTINELS— leen dentro de funciones que corren en
// `boot.init()`, es decir con DOMContentLoaded ya disparada y TODOS los
// defer ejecutados. Ningún acceso ocurre en el top-level de rotechos.js.
//
// Tests por regex: tests/unit/parse-rotech-pills.test.js (extrae
// `parseRotechPills` por regex sobre este fichero, NO sobre el modal).
//
// SHELL_SENTINELS: `parseRotechPills`, `hydrateEndstopCfg` (módulos nuevos
// del shell). `CFG_FIELDS`, `HW_LIMITS`, `openMachineConfig` SALEN de la
// tabla porque son perezosos — la auditoría B1 ya documentó esa trampa.
// ---
'use strict';
/* exported parseRotechPills, hydrateEndstopCfg, CFG_FIELDS */
// _endstopCfg se publica en window (no se declara const local — ver nota
// detallada en el bloque de window._endstopCfg abajo). El `exported` queda
// declarado para que ESLint no proteste por identificador no usado si el
// shim se carga en un contexto con análisis estático.

// Estado unificado de endstops por eje:
//   off      — true cuando no hay ningún sensor configurado en ese eje
//   minOn    — sensor MIN (−) habilitado
//   maxOn    — sensor MAX (+) habilitado
//   trigLevel — valor GPIO que indica "activado" (1=HIGH, 0=LOW)
//
// t_b8cd40c2: este objeto se publica DIRECTAMENTE en `window._endstopCfg`
// (NO declaramos `const _endstopCfg = {...}` local). El motivo: cuando los
// tests concatenan SOURCE_CORE con SOURCE_MODAL en el mismo `new Function`,
// ambos declararían `const _endstopCfg` en el mismo scope y reventaría con
// "Identifier '_endstopCfg' has already been declared" — exactamente el
// SyntaxError que tumbó el 3.er intento. En producción (scripts clásicos
// con defer), cada `<script>` tiene su propio scope top-level y la
// declaración local en el shim no molestaría, pero al evitar la `const`
// local evitamos también el conflicto en tests sin tocar el contrato
// público (`window._endstopCfg` sigue siendo el mismo objeto).
//
// El modal perezoso MUTA este objeto desde su `customPopulate` de M574 /
// `; rotech-pills=` cuando el operario abre CONFIGURACIÓN → Endstops —
// el poll ve la mutación en el siguiente tick porque apunta al MISMO
// objeto (es la misma referencia, no una copia).
window._endstopCfg = {
  X: { off: !0, minOn: !1, maxOn: !1, trigLevel: 1 },
  Y: { off: !0, minOn: !1, maxOn: !1, trigLevel: 1 },
  Z: { off: !0, minOn: !1, maxOn: !1, trigLevel: 1 },
  // STUB del eje A (NO QUITAR): no hay endstop A real (su UI se eliminó), pero
  // muchos loops de estado/polling iteran 4 ejes y acceden _endstopCfg[ax] por
  // corchete. Sin esta entrada, ax='A' = undefined → "Cannot read 'off'" en cada
  // ciclo. Queda "apagado" (off:true) → nunca se muestra ni dispara. Igual que _softLimits.A.
  A: { off: !0, minOn: !1, maxOn: !1, trigLevel: 1 },
};
// El poll (rotechos-poll.js) evalúa los triggers GPIO por esta ruta — MISMO
// objeto, las mutaciones del parser M574/M581 (en el modal perezoso) le llegan
// en vivo. Por eso este objeto vive en un shim eager: el poll debe verlo desde
// el primer tick, no tras el primer click en CONFIGURACIÓN.
AppState.cache.endstopCfg = window._endstopCfg;

/**
 * Parser ÚNICO de la línea `; rotech-pills=` de config.g (SSOT en la SD).
 * Soporta dos formatos:
 *   - NUEVO (por lado):  ax:minOn|maxOn:typeMin|typeMax:trig   ej "X:0|1:nc|nc:1"
 *   - LEGACY (agregado): ax:state:type:trig                    ej "X:on:nc:1"
 *     (el legacy no distinguía lados → se asume el sensor en el lado MAX)
 * Devuelve { X:{minOn,maxOn,typeMin,typeMax,trigLevel}, ... } o null si no existe.
 *
 * Pura: no toca window, no toca AppState, no toca DOM. Los tests
 * `tests/unit/parse-rotech-pills.test.js` la extraen por regex de este
 * fichero (no del modal) para verificar que el contrato sigue intacto
 * tras cualquier reorganización del modal perezoso.
 */
function parseRotechPills(raw) {
  const m = raw && raw.match(/;\s*rotech-pills=([^\n]+)/);
  if (!m) return null;
  const out = {};
  m[1].split(`,`).forEach((entry) => {
    const parts = entry.split(`:`).map((s) => s.trim());
    const ax = parts[0];
    if (![`X`, `Y`, `Z`, `A`].includes(ax)) return;
    const stateRaw = parts[1] || ``, typeRaw = parts[2] || ``, trig = parts[3];
    let minOn, maxOn, typeMin, typeMax;
    if (stateRaw.includes(`|`)) {
      const [mo, xo] = stateRaw.split(`|`);
      minOn = mo === `1` || mo === `on`;
      maxOn = xo === `1` || xo === `on`;
      const [tmin, tmax] = typeRaw.split(`|`);
      typeMin = (tmin || `nc`).toLowerCase();
      typeMax = (tmax || tmin || `nc`).toLowerCase();
    } else {
      // Legacy: estado único → sensor en MAX; tipo único aplicado a ambos lados.
      maxOn = stateRaw === `on`;
      minOn = false;
      typeMin = typeMax = (typeRaw || `nc`).toLowerCase();
    }
    const trigLevel = (trig === `0` || trig === `1`) ? Number(trig)
      : (typeMax === `no` ? 0 : 1);
    out[ax] = { minOn, maxOn, typeMin, typeMax, trigLevel };
  });
  return out;
}

/**
 * Hidrata `window._endstopCfg` (y, por referencia, AppState.cache.endstopCfg)
 * a partir del contenido crudo de config.g. Pura respecto al DOM: solo escribe
 * sobre el objeto eager publicado por este shim. La usa:
 *   - El shell tras la descarga de config.g en el boot, para que el poll y el
 *     diagnóstico GPIO (`#btnEndstopDiag`) vean el estado real de los
 *     endstops desde el primer tick, sin esperar a que el operario abra
 *     CONFIGURACIÓN.
 *   - El `customPopulate` de M574 del modal perezoso, que delega en esta
 *     misma función para no duplicar la lógica y mantener una sola SSOT.
 *
 * Comportamiento por eje:
 *   1) Pass M574: mira `M574 {ax}1 S1` (min) y `M574 {ax}2 S1` (max). El
 *      trigLevel se deduce del prefijo `!` en el pin (invertido → 0, NO
 *      invertido → 1). La config real usa `M574 {ax}0 S1` (sin endstop
 *      permanente) + `; rotech-pills=` como override, así que este pass
 *      suele poner ambos lados OFF.
 *   2) Pass `; rotech-pills=`: si existe, sobrescribe minOn/maxOn/trigLevel
 *      por eje (formato moderno `ax:min|max:typeMin|typeMax:trig` o legacy
 *      `ax:state:type:trig`). Este es el caso que hace que el diagnóstico
 *      GPIO funcione correctamente sin abrir el modal.
 *
 * CONTRATO DE NO-SOBRESCRITURA (t_b04be87e): si un eje YA tiene valores
 * distintos de los defaults del shim (off:true, minOn:false, maxOn:false,
 * trigLevel:1), ese eje NO se toca. Esto cubre dos casos:
 *   - tests e2e que siembran `AppState.cache.endstopCfg.X.maxOn = true`
 *     con `addInitScript` antes del primer poll (rotechos-bordeador.js
 *     depende de eso para abortar correctamente cuando gpIn[XMax]=1).
 *   - cualquier consumidor que ya haya mutado `_endstopCfg` y dependa de
 *     que el shim no le pise el estado entre su siembra y el primer poll.
 * Si el operario edita config.g a mano y recarga, el nuevo estado se aplica
 * porque al recargar `_endstopCfg` vuelve a los defaults del shim.
 *
 * El objeto `window._endstopCfg` mantiene sus claves X/Y/Z/A — la entrada A
 * es STUB (off:true) y nunca se hidrata (la UI no expone eje A rotativo).
 *
 * Idempotente: llamar varias veces con el mismo `raw` produce el mismo
 * estado. Si `raw` es null/undefined/vacío, deja el estado como estaba (no
 * resetea a "off") — un `rr_download` fallido no debe borrar la config que
 * el modal ya cargó.
 */
function hydrateEndstopCfg(raw) {
  if (typeof raw !== `string` || !raw) return;
  const cfg = window._endstopCfg;
  if (!cfg) return;
  const lines = raw.split(`\n`);
  const m574 = lines.filter((l) => /^M574\b/.test(l));
  // Detección de "eje en defaults": si los flags del shim son los publicados
  // al cargar (off:true, minOn:false, maxOn:false, trigLevel:1), asumimos
  // que NADIE lo ha tocado y es seguro hidratar. Si difiere, un consumidor
  // lo sembró (tests e2e, código de runtime) y respetamos su valor.
  const isDefault = (e) => e && e.off === true && e.minOn === false &&
                                e.maxOn === false && e.trigLevel === 1;
  // Pass 1: M574 → base de lado activo y trigLevel.
  for (const ax of [`X`, `Y`, `Z`]) {
    if (!isDefault(cfg[ax])) continue;
    const minL = m574.find((l) => RegExp(`^M574 ${ax}1`).test(l));
    const maxL = m574.find((l) => RegExp(`^M574 ${ax}2`).test(l));
    const rawPinMin = minL?.match(/P"([^"]+)"/)?.[1] || ``;
    const rawPinMax = maxL?.match(/P"([^"]+)"/)?.[1] || ``;
    const minActive = !!(minL && /S1\b/.test(minL));
    const maxActive = !!(maxL && /S1\b/.test(maxL));
    const isInverted = (rawPinMin || rawPinMax).startsWith(`!`);
    cfg[ax].minOn = minActive;
    cfg[ax].maxOn = maxActive;
    cfg[ax].off = !minActive && !maxActive;
    cfg[ax].trigLevel = isInverted ? 0 : 1;
  }
  // Pass 2: ; rotech-pills= → override por eje (formato moderno o legacy).
  // Mismo respeto por defaults: solo aplica a ejes en defaults. Esto
  // preserva el comportamiento del modal (que sí sobrescribe) para los ejes
  // que aún no se han tocado desde fuera; los ejes con siembra externa
  // (test e2e) mantienen su estado hasta que el modal los refresca.
  const pills = parseRotechPills(raw);
  if (pills) {
    for (const ax of [`X`, `Y`, `Z`]) {
      if (!isDefault(cfg[ax])) continue;
      const p = pills[ax];
      if (!p) continue;
      cfg[ax].minOn = !!p.minOn;
      cfg[ax].maxOn = !!p.maxOn;
      cfg[ax].off = !cfg[ax].minOn && !cfg[ax].maxOn;
      cfg[ax].trigLevel = p.trigLevel;
    }
  }
}
window.hydrateEndstopCfg = hydrateEndstopCfg;

/**
 * Descarga `config.g` de la SD y lo pasa a `hydrateEndstopCfg` para que
 * `_endstopCfg` esté hidratado desde el primer tick. Pensada para que el
 * shell (`rotechos.js`) la llame en el boot, sin esperar a que el operario
 * abra el modal de CONFIGURACIÓN (el modal sigue siendo perezoso para no
 * inflar el arranque en frío).
 *
 * Si la descarga falla (sin conexión, SD no montada), no rompe el boot:
 * `_endstopCfg` queda con sus valores por defecto (`off:true` en todos los
 * ejes) y se reintentará la próxima vez que `loadPersistentUiConfig` corra
 * dentro del modal. El diagnóstico GPIO mostrará "(sin config)" hasta
 * entonces — coherente con la falta de config.
 *
 * Cachea el resultado en `window._rotechCfgGEager` para que `loadPersistentUiConfig`
 * del modal perezoso lo reuse si ya está disponible, evitando una segunda
 * descarga que duplicaría tráfico en el arranque.
 */
async function ensureConfigGEager() {
  try {
    const base = (typeof window.TARGET_IP === `string`) ? window.TARGET_IP
      : (typeof location !== `undefined` && location.origin) ? location.origin
      : ``;
    if (!base) return;
    const cfgPath = `0:/sys/config.g`;
    const url = `${base}/rr_download?name=${encodeURIComponent(cfgPath)}&time=${Date.now()}`;
    // Fetch crudo: el shim core NO depende de _fetchRRF (vive en rotechos.js)
    // y no debe importarlo para no atar el ciclo de vida del modal a esta
    // carga. Toleramos CORS y status no-ok sin romper el boot.
    const r = await fetch(url, { credentials: `same-origin`, cache: `no-store` });
    if (!r.ok) return;
    const raw = await r.text();
    if (typeof raw !== `string` || !raw) return;
    hydrateEndstopCfg(raw);
    window._rotechCfgGEager = raw;
  } catch {
    /* silencio: la hidratación es best-effort, no rompe el boot */
  }
}
window.ensureConfigGEager = ensureConfigGEager;

// CFG_FIELDS — Tabla declarativa de campos de configuración.
// En este shim solo vive la entrada que el código EAGER lee SIN abrir
// el modal: `mcfgSacSensorZ`, consumida por ZCAL (rotechos.js:4750) cuando
// el operario calibra el sensor Z desde la pantalla principal. El resto
// de entradas (mcfgSacSensorY, mcfgSacProbeFast, mcfgM92X/Y/Z/A, …) viven
// en el modal perezoso porque solo se leen cuando se abre CONFIGURACIÓN.
//
// Estructura de cada campo (idéntica a la del modal):
//   id, kind, gName, matcher, formatter, rtCmd, validate, readUI, writeUI, skip
//
// Test consumidor: tests/unit/cfg-sac-sensor-y-envelope.test.js verifica
// que el modal carga esta entrada cuando se carga (no falla si el modal
// no está abierto al boot — el test abre el modal primero).
// t_b8cd40c2: la entrada de `CFG_FIELDS` se publica DIRECTAMENTE en
// `window.CFG_FIELDS` (sin declarar `const CFG_FIELDS` local). Mismo motivo
// que con `window._endstopCfg`: si lo declaramos como `const` local, los
// tests que concatenan SOURCE_CORE + SOURCE_MODAL en el mismo `new Function`
// revientan con "Identifier 'CFG_FIELDS' has already been declared" porque
// el modal también declara `const CFG_FIELDS = {…}`. El shim expone su
// contenido en window para que el modal pueda MERGEARLO cuando carga
// perezosamente (`Object.assign(window.CFG_FIELDS, CFG_FIELDS_LOCAL)`).
window.CFG_FIELDS = {
  mcfgSacSensorZ: {
    id: 'mcfgSacSensorZ', kind: 'global', gName: 'z_sensor_to_table',
    // PUEDE SER NEGATIVO: si el palpador dispara por DEBAJO del mártir
    // (sensor empotrado bajo la mesa), el valor es negativo. Validar solo que
    // sea numérico finito; el signo lo decide la geometría física, no el JS.
    matcher: /^global z_sensor_to_table = (-?[\d.]+)/m,
    formatter: (v) => `global z_sensor_to_table = ${v}  ; Punto de disparo Z respecto al mártir (negativo = bajo el mártir)`,
    rtCmd: (v) => `set global.z_sensor_to_table = ${v}`,
    validate: (v) => (!isFinite(v) || Math.abs(v) > 20 ? 'z_sensor_to_table debe ser un número entre -20 y 20 mm' : null),
  },
};
// Si el modal perezoso termina cargando y AÑADE entradas al objeto de este
// shim, el código eager (rotechos.js:4750) seguirá viendo el MISMO objeto
// (es por referencia). El modal hace `Object.assign(window.CFG_FIELDS, …)`
// justo antes de cerrar — muta, no reemplaza. Ver
// `rotechos-config-modal.js:CFG_FIELDS_CORE_MERGE`.

// ── Guarda de seguridad fisica de sonda Z y cambio de herramienta ──────────
// t_b8cd40c2: vivia en rotechos-config-modal.js, que ahora es PEREZOSO.
// Sus consumidores estan en el shell (rotechos.js: btnQaSondaZ y btnQaM6) y
// la llaman como `typeof cfgProbeGuard === 'function' && !cfgProbeGuard(x)`.
// Ese patron es FAIL-OPEN: con la funcion ausente NO bloquea, deja pasar. El
// e2e M6-3 lo cazo — con trabajo EN MARCHA el dialogo de M6 se abria igual.
// Por eso es eager: una guarda que solo protege si alguien abrio antes
// CONFIGURACION no es una guarda. Solo depende de simbolos del shell
// (machineMoveBlocked, AppState, toast, t), asi que no arrastra el modal.
function cfgProbeGuard(action) {
  // action ∈ {'probe'|'m6'} — el mensaje y la severidad cambian
  if (typeof machineMoveBlocked === 'function' && machineMoveBlocked()) return false;
  if (typeof AppState === 'undefined' || !AppState || !AppState.limits) return true;
  // allHomed === false → explícitamente NO referenciado. undefined/null → poll no ha llegado.
  if (AppState.limits.allHomed === false) {
    const key = action === 'm6' ? 'msg.m6HomeRequerido' : 'msg.sondaHomeRequerido';
    if (typeof toast === 'function') {
      toast(t(key,
        action === 'm6'
          ? `Haz homing (G28) antes del cambio de herramienta (M6) — la posición de aparcamiento del SAC es una coordenada G53 y necesita referencia válida.`
          : `Haz homing (G28) antes de sondar — sin referencia, la sonda baja a ciegas y puede partir la fresa contra la mesa.`),
        `warn`);
    }
    return false;
  }
  return true;
}
window.cfgProbeGuard = cfgProbeGuard;
