// ---
// rotechos-macros.js — MACROS DEL USUARIO + BUILDERS DE G-CODE
// Extraído de rotechos.js jul-2026 (#6) SIN cambios de lógica.
// Validador (validateGcodeLines) y subida atómica (macroAtomicUpload)
// añadidos sep-2026 (t_f522ec1e).
// ---
/* exported myMacros, renderMacros, macrosRestoreCustom */
// ── Persistencia de macros del usuario ──────────────────────────────────────
// Las macros CREADAS por el usuario (custom:true) se suben a la SD como archivo .g;
// la lista se restaura desde localStorage al recargar. Subida atómica (t_f522ec1e):
// rota macroWriteSD -> FM.atomicUpload (rotechos-fm.js:127, write-temp + rename de RRF).
async function macroAtomicUpload(macroPath, code) {
  if (!FM || typeof FM.atomicUpload !== `function`) {
    log(`macroAtomicUpload: FM.atomicUpload no disponible`, `err`);
    return false;
  }
  const slash = macroPath.lastIndexOf(`/`);
  const dir = slash >= 0 ? macroPath.slice(0, slash) : `0:/macros`;
  const fname = slash >= 0 ? macroPath.slice(slash + 1) : macroPath;
  const blob = new Blob([code], { type: `text/plain` });
  const file = new File([blob], fname);
  const origDir = FM.dir;
  FM.dir = dir;
  try {
    return await FM.atomicUpload(file, undefined, fname);
  } finally {
    FM.dir = origDir;
  }
}
function macrosPersistCustom() {
  STORE.set(`macros.custom`, myMacros.filter((m) => m.custom));
}
// eslint-disable-next-line no-unused-vars -- consumidor: rotechos.js:204,241,3898
function macrosRestoreCustom() {
  const saved = STORE.get(`macros.custom`, []);
  for (const m of saved)
    m && m.path && !myMacros.some((x) => x.path === m.path) && myMacros.push(m);
}
// Fase 4.12 · clasificador de riesgo y ficha del fichero. macroClassify/Inspect/
// FichaHtml/RiskBadge: el operario ve QUÉ hace la macro (path+flags) antes de
// confirmar. Estilos INLINE — la tarjeta prohíbe tocar rotechos.css/index.html.
const RISK_STYLE = {
  alto:  { bg: `#5a1a1a`, fg: `#ff7070`, border: `#a04040` },
  medio: { bg: `#5a431a`, fg: `#ffb060`, border: `#a07030` },
  bajo:  { bg: `#1a4a2a`, fg: `#80d090`, border: `#308050` },
};
const KNOWN_G = new Set([`G0`,`G1`,`G2`,`G3`,`G4`,`G10`,`G17`,`G18`,`G19`,`G20`,`G21`,`G28`,`G29`,`G30`,`G31`,`G32`,`G38`,`G53`,`G54`,`G55`,`G56`,`G57`,`G58`,`G59`,`G90`,`G91`,`G92`,`G98`,`G99`]);
// 26-sep: sin M8, M9 ni M410 — RRF 3.5.4 no los implementa (no hay su `case` en GCodes2.cpp):
// dan «Command is not supported» y no hacen nada. Que la ficha de la macro los marque.
const KNOWN_M = new Set([`M0`,`M1`,`M3`,`M4`,`M5`,`M6`,`M98`,`M99`,`M112`,`M117`,`M118`,`M150`,`M201`,`M203`,`M204`,`M205`,`M206`,`M207`,`M291`,`M400`,`M558`,`M564`,`M566`,`M567`,`M568`,`M574`,`M584`,`M585`,`M586`,`M587`,`M588`,`M589`,`M665`,`M666`,`M667`,`M668`,`M669`,`M84`]);
function macroClassify(content) {
  const f = { hasMotion: false, hasRelMotion: false, hasWcs: false, hasSpindle: false, hasCoolant: false, hasTool: false, hasProbe: false, hasHome: false, unknown: [], lines: 0 };
  let mode = `G90`; // RRF por defecto es absoluto
  // Quita comentarios ; hasta fin de línea (los bloques /* */ no se usan en macros)
  const src = (content || ``).split(`\n`).map((l) => l.split(`;`)[0]).join(`\n`);
  for (const m of src.matchAll(/\b([GMT])\s*(-?\d+(?:\.\d+)?)\b/gi)) {
    const tok = (m[1] + m[2]).toUpperCase();
    const head = tok[0], num = tok.slice(1);
    if (head === `G`) {
      if (num === `90`) mode = `G90`;
      else if (num === `91`) mode = `G91`;
      else if (num === `10`) f.hasWcs = true;
 else if (num === `28`) f.hasHome = true;
 else if (num === `38` || num === `38.2` || num === `38.3` || num === `38.4` || num === `38.5`) f.hasProbe = true;
      else if ([`0`,`1`,`2`,`3`].includes(num)) {
        f.hasMotion = true;
        if (mode === `G91`) f.hasRelMotion = true;
      }
      if (!KNOWN_G.has(tok)) f.unknown.push(tok);
    } else if (head === `M`) {
      if ([`3`,`4`,`5`].includes(num)) f.hasSpindle = true;
      else if ([`8`,`9`].includes(num)) f.hasCoolant = true;
      else if (num === `6`) f.hasTool = true;
      if (!KNOWN_M.has(tok)) f.unknown.push(tok);
    } else if (head === `T`) {
      // T0..T9 son selección de herramienta. Cualquier otro rango no está soportado.
      if (!/^T\d+$/.test(tok) || +num > 9) f.unknown.push(tok);
    }
  }
  f.lines = src.split(`\n`).filter((l) => l.trim()).length;
  f.unknown = [...new Set(f.unknown)].sort();
  f.hasUnknownCommands = f.unknown.length > 0;
  // Riesgo: ponderado por la peor acción que la macro puede hacer sobre la máquina.
  let s = 0;
  if (f.hasHome) s += 2;
  if (f.hasMotion) s += 2;
  if (f.hasTool) s += 2;
  if (f.hasWcs) s += 2;
  if (f.hasProbe) s += 2;
  if (f.hasSpindle) s += 1;
  if (f.hasCoolant) s += 0;
  if (f.unknown.length) s += 1;
  f.risk = s >= 5 ? `alto` : s >= 2 ? `medio` : `bajo`;
  return f;
}
// Risk label localized + inline-style for the badge.
function macroRiskBadge(risk) {
  const map = {
    alto:  { label: t(`macro.risk.alto`,  `ALTO`),  cls: `risk-alto`,  style: RISK_STYLE.alto  },
    medio: { label: t(`macro.risk.medio`, `MEDIO`), cls: `risk-medio`, style: RISK_STYLE.medio },
    bajo:  { label: t(`macro.risk.bajo`,  `BAJO`),  cls: `risk-bajo`,  style: RISK_STYLE.bajo  },
  };
  return map[risk] || map.bajo;
}
// Descarga el .g real de la SD y devuelve la ficha completa. Si falla,
// devuelve fallback con `source` vacío y `risk: 'medio'`.
async function macroInspect(macro) {
  const fallback = {
    name: macro.name, path: macro.path, size: 0, lines: 0, lastEdit: ``,
    flags: macroClassify(``), source: ``, error: null,
  };
  try {
    const r = await RRF.download(macro.path, { timeoutMs: 5000 });
    if (!r.ok) return { ...fallback, error: `HTTP ${r.status}` };
    const text = await r.text();
    // `lastEdit` viene del header `Last-Modified` (RRF lo emite en `rr_download`)
    const lastEdit = r.headers.get(`Last-Modified`) || r.headers.get(`last-modified`) || ``;
    const flags = macroClassify(text);
    return { name: macro.name, path: macro.path, size: text.length, lines: flags.lines, lastEdit, flags, source: text, error: null };
  } catch (e) {
    return { ...fallback, error: String(e && e.message || e) };
  }
}
// Renderiza la ficha (HTML seguro) que va DENTRO del confirmDialog existente.
// Devuelve string HTML; los datos del usuario se escapan con escHtml.
function macroFichaHtml(ficha) {
  const r = (ficha && ficha.flags && ficha.flags.risk) || `medio`;
  const sty = RISK_STYLE[r];
  const chip = (lbl, bg, fg, bd, title) => `<span style="display:inline-block;padding:2px 7px;margin:2px 3px 2px 0;border-radius:8px;font-size:10px;font-weight:600;letter-spacing:0.3px;background:${bg};color:${fg};border:1px solid ${bd}"${title ? ` title="${title}"` : ``}>${escHtml(lbl)}</span>`;
  if (!ficha || ficha.error) {
    return `<div style="margin:8px 0;padding:8px 10px;border-radius:6px;background:${sty.bg}22;border:1px solid ${sty.border};font-size:11px;line-height:1.45">
      <div style="font-weight:600;color:${sty.fg};margin-bottom:3px">⚠ ${escHtml(t(`macro.ficha.noFetch`, `No se ha podido leer el fichero`))}</div>
      <div style="color:var(--text-3);font-family:monospace;font-size:10px">${escHtml(ficha && ficha.path || `?`)}</div>
    </div>`;
  }
  const f = ficha.flags;
  const tags = [];
  if (f.hasMotion)    tags.push(chip(t(`macro.tag.motion`,  `Mueve máquina`),   `#1a3a5a`, `#80b0e0`, `#3060a0`));
  if (f.hasHome)      tags.push(chip(t(`macro.tag.home`,    `Homing`),          `#3a1a5a`, `#c080e0`, `#6030a0`));
  if (f.hasWcs)       tags.push(chip(t(`macro.tag.wcs`,     `Cambia WCS`),      `#5a3a1a`, `#e0a060`, `#a06030`));
  if (f.hasSpindle)   tags.push(chip(t(`macro.tag.spindle`, `Husillo`),         `#5a1a3a`, `#e060a0`, `#a03060`));
  if (f.hasCoolant)   tags.push(chip(t(`macro.tag.coolant`, `Refrigerante`),    `#1a3a3a`, `#60c0c0`, `#308080`));
  if (f.hasTool)      tags.push(chip(t(`macro.tag.tool`,    `Tool change`),     `#5a4a1a`, `#e0c060`, `#a08030`));
  if (f.hasProbe)     tags.push(chip(t(`macro.tag.probe`,   `Sonda`),           `#1a5a3a`, `#60e090`, `#30a060`));
  if (f.unknown.length) tags.push(chip(`${t(`macro.tag.unknown`, `Comandos no UI`)} (${f.unknown.length})`, `#3a3a3a`, `#d0d0d0`, `#707070`, f.unknown.join(`, `)));
  const lastEdit = ficha.lastEdit ? escHtml(ficha.lastEdit) : escHtml(t(`macro.ficha.lastEditUnk`, `desconocida`));
  return `<div style="margin:8px 0;padding:9px 11px;border-radius:6px;background:${sty.bg}1a;border:1px solid ${sty.border};font-size:11px;line-height:1.55;text-align:left">
    <div style="display:flex;gap:8px;margin-bottom:3px"><span style="color:var(--text-3);min-width:90px">${escHtml(t(`macro.ficha.path`, `Ruta`))}</span><span style="font-family:monospace;color:var(--text-2);word-break:break-all">${escHtml(ficha.path)}</span></div>
    <div style="display:flex;gap:8px;margin-bottom:3px"><span style="color:var(--text-3);min-width:90px">${escHtml(t(`macro.ficha.size`, `Tamaño`))}</span><span style="color:var(--text-2)">${ficha.size} B · ${ficha.lines} ${escHtml(t(`macro.ficha.lines`, `líneas`))}</span></div>
    <div style="display:flex;gap:8px;margin-bottom:5px"><span style="color:var(--text-3);min-width:90px">${escHtml(t(`macro.ficha.lastEdit`, `Última edición`))}</span><span style="color:var(--text-2)">${lastEdit}</span></div>
    <div style="margin-top:4px">${tags.join(``) || `<span style="color:var(--text-3);font-size:10px">${escHtml(t(`macro.ficha.noEffects`, `Sin efectos detectados`))}</span>`}</div>
  </div>`;
}
// Validador del editor de macros (t_f522ec1e): RRF 3.5.4 trunca silenciosamente
// líneas non-comment > 256 chars (Configuration.h:163). Reglas alineadas con
// scripts/gcheck.py. Cobertura: tests/unit/macro-editor-validate.test.js.
function validateGcodeLines(content) {
  const errors = [];
  if (!content) return { ok: true, errors };
  const lines = String(content).split('\n');
  let inString = false;
  for (let i = 0; i < lines.length; i++) {
    const raw = lines[i];
    if (/^\t/.test(raw)) {
      errors.push({ line: i + 1, len: 0, msg: `TAB al inicio (RRF solo acepta espacios)` });
    }
    let code = '';
    for (let j = 0; j < raw.length; j++) {
      const c = raw[j];
      if (c === '"') { inString = !inString; code += c; continue; }
      if (c === ';' && !inString) break;
      code += c;
    }
    const codeLen = code.replace(/\s+$/, '').length;
    if (codeLen > 256) {
      errors.push({
        line: i + 1,
        len: codeLen,
        msg: `${codeLen} chars excede RRF 3.5.4 256 non-comment (Configuration.h:163)`,
      });
    }
  }
  return { ok: errors.length === 0, errors };
}
window.validateGcodeLines = validateGcodeLines;
const myMacros = [
    {
      // (t_73119cd8 · Fase 3.2 plan v2) "Ir a 0" ambiguo: podía leerse como
      // cero de máquina o de pieza. Va al WCS X0 Y0 (origen de trabajo) →
      // nombre explícito para que el operario no confunda con MCS.
      name: `Ir al origen de pieza`,
      path: MACROS.goto0,
      code: `M98 P"${MACROS.goto0}"`,
    },
    {
      // (t_73119cd8) "Aparcar" sin destino: ahora aclara que va a la zona
      // segura definida en CONFIGURACIÓN → Aparcar.
      name: `Aparcar (zona segura)`,
      path: MACROS.park,
      code: `M98 P"${MACROS.park}"`,
    },
    {
      // (t_88c6a0dd · Fase 4.12 plan v2) "Coreografía" era un nombre que no
      // decía qué hacía: el operario podía lanzarla pensando que era una
      // presentación visual sin consecuencia. En realidad mueve la máquina
      // en una danza + hace HOME + apaga/enciende el husillo → riesgo ALTO.
      // Renombrado a "Demo de movimiento" para que el nombre refleje el
      // efecto. La ruta en disco sigue siendo `coreografia.g` (los .g son
      // piezas de firmware, no se renombran: MACROS.coreografia en
      // rotechos-const.js se mantiene).
      name: `Demo de movimiento`,
      path: MACROS.coreografia,
      code: `M98 P"${MACROS.coreografia}"`,
    },
    {
      name: `Medir Z`,
      path: MACROS.sondaZ,
      code: `M98 P"${MACROS.sondaZ}"`,
    },
    {
      name: `Palpador 3D`,
      path: MACROS.probe3d,
      code: `M98 P"${MACROS.probe3d}"`,
    },
    {
      name: `Home All (X-Y-Z)`,
      path: MACROS.homeAll,
      code: `M98 P"${MACROS.homeAll}"`,
    },
    {
      // (t_73119cd8) "Limpiar Cero" sonaba a mantenimiento; en realidad
      // resetea los offsets de TRABAJO (G10 L2 X0 Y0 Z0), obligatorio antes
      // de re-fijar el cero de pieza.
      name: `Borrar cero de pieza`,
      path: MACROS.clearZero,
      code: `M98 P"${MACROS.clearZero}"`,
    },
  ];
let editingMacroIdx = -1;
function renderMacros() {
  const mc = $(`macroContainer`),
    mConfig = $(`mcfgMacroList`);
  (mc && (mc.innerHTML = ``),
    mConfig && (mConfig.innerHTML = ``),
    myMacros.forEach((m, i) => {
      if (mc) {
        const row = document.createElement(`div`);
        // Fase 4.12 · badge de riesgo (se actualiza a la baja hasta el primer
        // confirmDialog, que dispara macroInspect() y trae el .g real).
        const _cls0 = macroClassify(m.code || ``);
        const _badge0 = macroRiskBadge(_cls0.risk);
        ((row.className = `macro-row`),
          (row.dataset.macroPath = m.path),
          (row.innerHTML = `



<button class="macro-play-btn" title="Ejecutar: ${escHtml(m.name)}" style="flex:1">



<div class="macro-idx-circle">



<svg width="10" height="10" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"/></svg>



</div>



<div class="macro-info">



<span class="macro-name">${escHtml(m.name)}</span>



<span class="macro-path">${escHtml(m.path)}</span>



</div>


<div class="macro-risk-badge ${_badge0.cls}" title="${escHtml(t(`macro.risk.title`, `Riesgo estimado al ejecutar`))}" style="display:inline-block;padding:2px 8px;border-radius:10px;font-size:10px;font-weight:700;letter-spacing:0.5px;background:${_badge0.style.bg};color:${_badge0.style.fg};border:1px solid ${_badge0.style.border};margin-left:6px;flex-shrink:0">${_badge0.label}</div>


</button><button class="macro-cancel-btn" title="Cancelar macro"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/></svg> STOP</button>`),
          row
            .querySelector(`.macro-play-btn`)
            .addEventListener(`click`, async () => {
              if (AppState.macro.running) {
                toast(t(`msg.macroRunning`, `Ya hay una macro en ejecución`), `warn`);
                return;
              }
              // En RUNNING solo se permite vssc (anti-chatter: su uso ES en marcha)
              if (!/vssc/i.test(m.name) && machineMoveBlocked()) return;
              if (
                // R-02 (2026-08-30): la lista blanca se sustituye por el SSOT
                // `macroNecesitaConfirmacion` (rotechos-const.js). Antes omitia
                // spindle_warmup.g (arranca el husillo) y clear_zero.g (borra el
                // cero de pieza). Sigue usando confirmDashboard: en el cockpit la
                // pregunta solo sale en MODO ESCUELA, y eso no cambia.
                macroNecesitaConfirmacion(m.name) &&
                !(await (async () => {
                  // Fase 4.12 · descargar el .g real y mostrar la ficha
                  // (ruta + última edición + flags de riesgo) en el confirm.
                  const ficha = await macroInspect(m);
                  // Refresca el badge con la info real (built-in cae a `bajo`
                  // porque su `code` es solo "M98 P<path>").
                  const badge = row.querySelector(`.macro-risk-badge`);
                  if (badge) {
                    const newBadge = macroRiskBadge(ficha.flags.risk);
                    badge.className = `macro-risk-badge ${newBadge.cls}`;
                    badge.textContent = newBadge.label;
                    badge.style.background = newBadge.style.bg;
                    badge.style.color = newBadge.style.fg;
                    badge.style.borderColor = newBadge.style.border;
                  }
                  return confirmDashboard(
                    t(`dlg.macroRun.title`, `Ejecutar macro`),
                    `${t(`dlg.macroRun.will`, `Moverá la máquina`)}: <strong>${escHtml(m.name)}</strong>` +
                    macroFichaHtml(ficha) +
                    `<span style="display:block;margin-top:6px;color:var(--text-3);font-size:10px;line-height:1.4">${escHtml(t(`dlg.macroRun.reviewHint`, `Lo que ejecuta la macro es el contenido del .g en la SD; revísalo en SETTINGS → Macros antes de continuar si es la primera vez que la lanzas.`))}</span>` +
                    t(`dlg.macroRun.cont`, `¿Continuar?`),
                  );
                })())
              )
                return;
              AppState.macro.row = row;
              AppState.macro.name = m.name;
              AppState.macro.lanzadaEn = Date.now();
              row.classList.add(`running`);
              updateButtonStates();
              const r = await RRF.gcode(`M98 P"${m.path}"`);
              log(`M98 P"${m.path}"`, `cmd`);
              if (!r) {
                row.classList.remove(`running`);
                AppState.macro.row = null;
                AppState.macro.name = ``;
                toast(t(`msg.errorAlEjecutarMname`, `Error al ejecutar "${m.name}" — el firmware devolvió error. Mira la CONSOLA (panel inferior) para ver la causa: puede ser WiFi inestable, una línea del .g con sintaxis incorrecta o la macro pide un estado que la máquina no tiene (por ejemplo HOME previo o pieza debajo de la sonda). Corrige la causa y vuelve a pulsar la macro.`, { "m.name": m.name }), `err`);
              }
            }),
          row
            .querySelector(`.macro-cancel-btn`)
            .addEventListener(`click`, () => cancelMacro()),
          mc.appendChild(row));
      }
      if (mConfig) {
        const row = document.createElement(`div`);
        ((row.className = `macro-row`),
          (row.style.background = `var(--bg-raised)`),
          (row.innerHTML = `



<div class="macro-info" style="padding:10px 14px">



<span class="macro-name">${escHtml(m.name)}</span>



<span class="macro-path">${escHtml(m.path)}</span>



</div>



<div class="macro-acts" style="display:flex">



<button class="macro-edit" style="width:40px; justify-content:center" title="Editar Macro">



<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/></svg>



</button>



<button class="macro-delete" style="width:40px; justify-content:center" title="Eliminar Macro">



<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4h6v2"/></svg>



</button>



</div>`),
          row.querySelector(`.macro-edit`).addEventListener(`click`, () => {
            ((editingMacroIdx = i),
              m.path === `0:/macros/sonda_Z.g`
                ? openProbeEditor(m.code)
                : m.path === `0:/macros/probe3d.g`
                  ? openProbe3dEditor(m.code)
                  : m.path === `0:/macros/park.g`
                    ? openParkEditor(m.code)
                    : (($(`macroNameIn`).value =
                          m.name),
                        ($(`macroCodeIn`).value = m.code),
                        document
                          .getElementById(`macroModal`)
                          .classList.add(`show`)));
          }),
          row
            .querySelector(`.macro-delete`)
            .addEventListener(`click`, async () => {
              (await confirmDialog(
                t(`dlg.macroDelete.title`, `Eliminar macro`),
                `${t(`dlg.macroDelete.q`, `¿Eliminar`)} "<strong>${escHtml(m.name)}</strong>"?`,
              )) &&
                (m.custom && RRF.deleteFile(m.path).catch(() => {}),
                myMacros.splice(i, 1),
                macrosPersistCustom(),
                renderMacros(),
                toast(`${t(`msg.macroDeleted`, `Macro`)} "${m.name}" ${t(`msg.macroDeletedSfx`, `eliminada`)}`, `warn`));
            }),
          mConfig.appendChild(row));
      }
    }));
}
($(`btnMacroCancel`).addEventListener(`click`, () => {
  $(`macroModal`).classList.remove(`show`);
}),
  $(`btnMacroSave`).addEventListener(`click`, async () => {
    if (editingMacroIdx > -1) {
      const m = myMacros[editingMacroIdx];
      m.name = $(`macroNameIn`).value;
      m.code = $(`macroCodeIn`).value;
      // Validar (custom y built-in): un .g con línea > 256 chars hace que RRF
      // trunque silenciosamente y la macro aborte al ejecutar.
      const v = validateGcodeLines(m.code);
      if (!v.ok) {
        const head = v.errors.slice(0, 3)
          .map((e) => `L${e.line} (${e.len} chars): ${e.msg}`)
          .join(` · `);
        const more = v.errors.length > 3 ? ` · +${v.errors.length - 3} más` : ``;
        toast(t(`msg.macroGuardarInvalida`,
          `No se puede guardar: ${v.errors.length} línea(s) inválida(s) — ${head}${more}. RRF 3.5.4: 256 chars non-comment/línea.`, { "v.errors.length": v.errors.length, "head": head, "more": more }), `err`);
        log(`macro save rechazado: ${v.errors.length} error(es) de validación`, `err`);
        return; // NO cierra el modal: el operario debe corregir.
      }
      // Lanzador por defecto (M98 al propio path): subir crearía bucle infinito.
      const launcherOnly = m.code.trim() === `M98 P"${m.path}"`;
      if (!m.custom && launcherOnly) {
        toast(t(`msg.macroSoloLanzador`,
          `El código actual es solo un lanzador (M98 al propio .g). Eso, subido a la SD, crearía un bucle infinito. Sustituye el contenido por G-code real (G28, G1, M3, etc.) y vuelve a Guardar — el .g se subirá a 0:/macros/. Si querías dejar la macro como referencia, pulsa Cancelar.`), `warn`);
        return;
      }
      // Confirmación al guardar: pisar el .g que la máquina EJECUTA.
      const ok = await confirmDialog(
        t(`dlg.macroSave.title`, `Guardar macro en la SD`),
        `${t(`dlg.macroSave.will`, `Vas a sobrescribir`)} <strong>${escHtml(m.path)}</strong> ` +
        `${t(`dlg.macroSave.warn`, `en la SD. La máquina ejecuta este fichero: revisa el código antes de continuar.`)}`,
      );
      if (!ok) return;
      const up = await macroAtomicUpload(m.path, m.code);
      if (m.custom) {
        macrosPersistCustom();
      }
      toast(
        up
          ? t(`msg.macroGuardada`, `Macro "${m.name}" guardada en ${m.path}`)
          : t(`msg.macroUploadSession`, `Error subiendo el .g a la SD — el cambio NO se persistió en disco. Verifica la conexión WiFi con la máquina, que la SD no esté llena ni protegida contra escritura, y vuelve a pulsar Guardar.`),
        up ? `ok` : `err`,
      );
      log(`Macro "${m.name}" ${up ? `guardada en ${m.path}` : `error al guardar`}`, up ? `sys` : `err`);
      renderMacros();
    }
    $(`macroModal`).classList.remove(`show`);
  }),
  document
    .getElementById(`btnOpenNewMacroConfig`)
    ?.addEventListener(`click`, () => {
      (($(`newMacroName`).value = ``),
        ($(`newMacroFile`).value = ``),
        ($(`newMacroCode`).value = ``),
        (window.__rotechosModalLastFocus = document.activeElement),
        $(`newMacroModal`).classList.add(`show`));
    }),
  $(`btnNewMacroCancel`).addEventListener(`click`, () => {
    $(`newMacroModal`).classList.remove(`show`);
  }),
  $(`btnAddMacro`).addEventListener(`click`, async () => {
    const name = $(`newMacroName`).value.trim(),
      file = $(`newMacroFile`).value.trim(),
      code = $(`newMacroCode`).value.trim();
    if (!name) {
      toast(t(`msg.escribeUnNombrePara`, `Escribe un nombre para la macro`), `warn`);
      return;
    }
    if (!file) {
      toast(t(`msg.escribeElNombreDel`, `Escribe el nombre del archivo .g`), `warn`);
      return;
    }
    let cleanFile = file.replace(/[^\w.-]/g, `_`).replace(/_+/g, `_`);
    cleanFile.endsWith(`.g`) || (cleanFile += `.g`);
    if (cleanFile !== file) {
      toast(t(`msg.macroNameSanitized`, `Nombre de archivo sanitizado → "${cleanFile}"`, { "cleanFile": cleanFile }), `warn`);
    }
    const path = `0:/macros/${cleanFile}`;
    // Subir el .g a la SD ANTES de dar la macro por creada: sin el archivo real, el
    // M98 de ejecución apuntaba a una ruta inexistente y la macro fallaba siempre
    // (y desaparecía al recargar — bug "macros fantasma" de la 2ª auditoría).
    // Validar antes de subir: un .g con línea > 256 chars hace que RRF
    // trunque silenciosamente al ejecutar.
    const v = validateGcodeLines(code);
    if (!v.ok) {
      toast(t(`msg.macroCrearInvalida`,
        `No se puede crear la macro: ${v.errors.length} línea(s) inválida(s). RRF 3.5.4: 256 chars non-comment/línea. Edita y vuelve a Crear.`, { n: v.errors.length }), `err`);
      return;
    }
    if (!(await macroAtomicUpload(path, code))) {
      toast(t(`msg.macroUploadNotCreated`, `Error subiendo el .g a la SD — macro NO creada: tu código NO se ha perdido (sigue en el editor); lo único que ha fallado es la copia a 0:/macros/ de la SD. Comprueba la conexión WiFi con la máquina, que la SD no esté llena ni protegida contra escritura y vuelve a pulsar Guardar. Si vuelve a fallar, edita la macro desde CONFIGURACIÓN → Macros y prueba por la ruta "existente".`), `err`);
      return;
    }
    (myMacros.push({ name, path, code, custom: true }),
      macrosPersistCustom(),
      renderMacros(),
      $(`newMacroModal`).classList.remove(`show`),
      toast(t(`msg.macroNameAñadida`, `Macro "${name}" añadida`, { "name": name }), `ok`),
      log(`Nueva macro: ${name} → ${file} (subida a SD)`, `sys`));
  }));
function openProbeEditor(code) {
  window.__rotechosModalLastFocus = document.activeElement;
  const seekF = code.match(/G1 H3 Z-\d+ F(\d+)/)?.[1] || `300`,
    maxDist = code.match(/G1 H3 Z-(\d+) F/)?.[1] || `30`,
    retract = code.match(/G1 Z(\d+\.?\d*) F\d+\s*;.*retrac/i)?.[1] || `3`,
    precF =
      code.match(/G1 H3 Z-\d+ F(\d+)\s*;.*(?:lento|afin|precis)/i)?.[1] ||
      (code.match(/G1 H3 Z-\d+ F(\d+)/g) || [])
        .map((s) => s.match(/F(\d+)/)[1])
        .pop() ||
      `50`,
    precDist =
      code.match(/G1 H3 Z-(\d+) F\d+\s*;.*(?:lento|afin|precis)/i)?.[1] || `5`,
    blockH = code.match(/G10 L20 Z(-?[\d.]+)/)?.[1] || `0`,
    safeZ = code.match(/G1 Z(\d+\.?\d*) F\d+\s*$/)?.[1] || `5`;
  ($(`probeMaxDist`).value = maxDist),
    ($(`probeSeekF`).value = seekF),
    ($(`probeRetract`).value = retract),
    ($(`probePrecDist`).value = precDist),
    ($(`probePrecF`).value = precF),
    ($(`probeBlockH`).value = blockH),
    ($(`probeSafeZ`).value = safeZ),
    $(`probeEditorModal`).classList.add(`show`);
}
function buildProbeGCode() {
  const maxDist = parseFloat($(`probeMaxDist`).value) || 30,
    seekF = parseFloat($(`probeSeekF`).value) || 300,
    retract = parseFloat($(`probeRetract`).value) || 3,
    precDist = parseFloat($(`probePrecDist`).value) || 5,
    precF = parseFloat($(`probePrecF`).value) || 50,
    blockH = parseFloat($(`probeBlockH`).value) || 0;
  return `; probe.g — Palpado de altura de pieza (RotechOS)



; ---------------------------------------------------------



; 1. Comprobación: la sonda NO debe estar activada al inicio



if sensors.probes[0].value[0] != 0



abort "SONDA YA ACTIVADA — comprueba que no está tocando nada antes de palpar"



; 2. Aproximación rápida (máx ${maxDist} mm)



G91



G1 H3 Z-${maxDist} F${seekF}       ; buscar contacto a ${seekF} mm/min



G90



; 3. Retracción para liberar presión



G91



G1 Z${retract} F600                 ; subir ${retract} mm



G90



; 4. Palpado de precisión (lento)



G91



G1 H3 Z-${precDist} F${precF}      ; afinar a ${precF} mm/min



G90



; 5. Aplicar offset Z (espesor bloque: ${blockH} mm)



G10 L20 Z${blockH}



; 6. Subir a posición segura



G1 Z${parseFloat($(`probeSafeZ`).value) || 5} F600`;
}
(document
  .getElementById(`btnProbeEditorClose`)
  .addEventListener(`click`, () => {
    $(`probeEditorModal`).classList.remove(`show`);
  }),
  document
    .getElementById(`btnProbeEditorSave`)
    .addEventListener(`click`, () => {
      if (editingMacroIdx < 0) return;
      // OJO: este editor genera un probe.g LEGACY (G1 H3) incompatible con la sonda
      // actual (sonda_Z.g delega en el núcleo probe_z_sensor.g con G38.2). NO se sube
      // a la SD para no machacar la macro real; el ajuste operativo (velocidades,
      // tolerancia, alturas) se hace en CONFIGURACIÓN. Antes este botón decía
      // "actualizado" tocando solo la copia en memoria — era engañoso.
      const code = buildProbeGCode();
      ((myMacros[editingMacroIdx].code = code),
        renderMacros(),
        toast(t(`msg.probegSoloSesion`, `Cambio solo en esta sesión — la sonda real se ajusta en CONFIGURACIÓN → Sonda. Aquí solo cambia la copia en memoria que usa esta UI; el .g de la SD (sonda_Z.g) NO se ha tocado. Para guardar el cambio en la SD, edita sonda_Z.g desde CONFIGURACIÓN → Macros y pulsa Guardar.`), `warn`),
        log(`Sonda (copia UI) actualizada — la SD no se toca (editor legacy)`, `sys`),
        $(`probeEditorModal`).classList.remove(`show`));
    }));
const _p3dTabs = [
  { btn: `p3dTabGeom`, panel: `p3dPanelGeom` },
  { btn: `p3dTabVel`, panel: `p3dPanelVel` },
  { btn: `p3dTabOffset`, panel: `p3dPanelOffset` },
  { btn: `p3dTabOp`, panel: `p3dPanelOp` },
];
_p3dTabs.forEach((t) => {
  $(t.btn).addEventListener(`click`, () => {
    (_p3dTabs.forEach((x) => {
      ($(x.btn).classList.remove(`active`),
        ($(x.panel).style.display = `none`));
    }),
      $(t.btn).classList.add(`active`),
      ($(t.panel).style.display = `block`));
  });
});
function buildProbe3dGCode(p) {
  const r = p.ballDiam / 2,
    wcsNum = { G54: 1, G55: 2, G56: 3, G57: 4, G58: 5, G59: 6 }[p.wcs] || 1;
  let code = `; probe3d.g — Palpador 3D (RotechOS)



`;
  return (
    (code += `; Bola Ø${p.ballDiam}mm · Vástago ${p.stemLen}mm · Sonda sensors.probes[${p.probeNum}]\n`),
    (code += `; ---------------------------------------------------------







`),
    p.spindleOff &&
      (code += `; Apagar spindle por seguridad



M5







`),
    p.checkProbe &&
      (code += `; Verificar que el palpador NO está activado\nif sensors.probes[${p.probeNum}].value[0] != 0\n    abort "PALPADOR YA ACTIVO — comprueba que no toca nada"\n\n`),
    (code += `; Subir a altura segura\nG90\nG1 Z${p.safeZ} F${p.travelF}\n\n`),
    p.doZ &&
      ((code += `; ── Palpado Z (superficie superior) --



`),
      (code += `G91\nG1 H3 Z-${p.seekDist} F${p.seekF}    ; búsqueda rápida\nG90\n`),
      (code += `G91\nG1 Z${p.retract} F${p.travelF}         ; retroceso\nG90\n`),
      (code += `G91\nG1 H3 Z-${p.seekDist} F${p.backF}    ; afinado\nG90\n`),
      (code += `G10 L2 P${wcsNum} Z{move.axes[2].machinePosition + ${p.offZ} - ${r}}\n\n`)),
    p.doX &&
      ((code += `; ── Palpado X+ --



`),
      (code += `G1 Z${p.safeZ} F${p.travelF}\n`),
      (code += `G91\nG1 H3 X${p.seekDist} F${p.seekF}     ; búsqueda X+\nG90\n`),
      (code += `G91\nG1 X-${p.retract} F${p.travelF}\nG90\n`),
      (code += `G91\nG1 H3 X${p.seekDist} F${p.backF}    ; afinado X+\nG90\n`),
      p.findCenter
        ? ((code += `var xPlus = move.axes[0].machinePosition







`),
          (code += `; ── Palpado X- --



`),
          (code += `G1 Z${p.safeZ} F${p.travelF}\n`),
          (code += `G91\nG1 H3 X-${p.seekDist} F${p.seekF}   ; búsqueda X-\nG90\n`),
          (code += `G91\nG1 X${p.retract} F${p.travelF}\nG90\n`),
          (code += `G91\nG1 H3 X-${p.seekDist} F${p.backF}  ; afinado X-\nG90\n`),
          (code += `var xMinus = move.axes[0].machinePosition



`),
          (code += `var xCenter = ({var.xPlus} + {var.xMinus}) / 2



`),
          (code += `G10 L2 P${wcsNum} X{var.xCenter + ${p.offX}}\n\n`))
        : (code += `G10 L2 P${wcsNum} X{move.axes[0].machinePosition - ${r} + ${p.offX}}\n\n`)),
    p.doY &&
      ((code += `; ── Palpado Y+ --



`),
      (code += `G1 Z${p.safeZ} F${p.travelF}\n`),
      (code += `G91\nG1 H3 Y${p.seekDist} F${p.seekF}     ; búsqueda Y+\nG90\n`),
      (code += `G91\nG1 Y-${p.retract} F${p.travelF}\nG90\n`),
      (code += `G91\nG1 H3 Y${p.seekDist} F${p.backF}    ; afinado Y+\nG90\n`),
      p.findCenter
        ? ((code += `var yPlus = move.axes[1].machinePosition







`),
          (code += `; ── Palpado Y- --



`),
          (code += `G1 Z${p.safeZ} F${p.travelF}\n`),
          (code += `G91\nG1 H3 Y-${p.seekDist} F${p.seekF}   ; búsqueda Y-\nG90\n`),
          (code += `G91\nG1 Y${p.retract} F${p.travelF}\nG90\n`),
          (code += `G91\nG1 H3 Y-${p.seekDist} F${p.backF}  ; afinado Y-\nG90\n`),
          (code += `var yMinus = move.axes[1].machinePosition



`),
          (code += `var yCenter = ({var.yPlus} + {var.yMinus}) / 2



`),
          (code += `G10 L2 P${wcsNum} Y{var.yCenter + ${p.offY}}\n\n`))
        : (code += `G10 L2 P${wcsNum} Y{move.axes[1].machinePosition - ${r} + ${p.offY}}\n\n`)),
    p.goCenter &&
      (p.doX || p.doY) &&
      ((code += `; Mover al centro/referencia encontrada



`),
      (code += `G1 Z${p.safeZ} F${p.travelF}\n`),
      (code += `${p.wcs}\nG1 X0 Y0 F${p.travelF}\n\n`)),
    (code += `; Subir a posición final segura\nG1 Z${p.finalZ} F${p.travelF}\n`),
    (code += `; Palpado 3D completado ✓`),
    code
  );
}
function openProbe3dEditor(code) {
  const get = (re, def) => code.match(re)?.[1] ?? def;
  (($(`p3dBallDiam`).value = get(
    /Bola Ø([\d.]+)mm/,
    `2`,
  )),
    ($(`p3dStemLen`).value = get(
      /Vástago ([\d.]+)mm/,
      `50`,
    )),
    ($(`p3dProbeNum`).value = get(/probes\[(\d)\]/, `0`)),
    ($(`p3dSeekF`).value = get(
      /H3 [XYZ][\d.-]+ F(\d+)\s*; búsqueda rápida/,
      `500`,
    )),
    ($(`p3dSeekDist`).value = get(
      /H3 [XYZ]([\d.]+) F\d+\s*; búsqueda/,
      `20`,
    )),
    ($(`p3dBackF`).value = get(
      /H3 [XYZ][\d.-]+ F(\d+)\s*; afin/,
      `50`,
    )),
    ($(`p3dRetract`).value = get(
      /G1 [XYZ]([\d.]+) F\d+\s*\nG90\nG91\nG1 H3/,
      `2`,
    )),
    ($(`p3dOffX`).value = get(
      /xCenter \+ ([-\d.]+)\}/,
      `0`,
    )),
    ($(`p3dOffY`).value = get(
      /yCenter \+ ([-\d.]+)\}/,
      `0`,
    )),
    ($(`p3dOffZ`).value = get(
      /machinePosition \+ ([-\d.]+) -/,
      `0`,
    )),
    ($(`p3dSafeZ`).value = get(
      /Subir a altura segura\nG90\nG1 Z([\d.]+)/,
      `10`,
    )),
    ($(`p3dFinalZ`).value = get(
      /posición final segura\nG1 Z([\d.]+)/,
      `20`,
    )),
    ($(`p3dTravelF`).value = get(
      /G1 Z[\d.]+ F(\d+)/,
      `3000`,
    )),
    ($(`p3dApproach`).value = `5`),
    ($(`p3dDoX`).checked = code.includes(`Palpado X`)),
    ($(`p3dDoY`).checked = code.includes(`Palpado Y`)),
    ($(`p3dDoZ`).checked = code.includes(`Palpado Z`)),
    ($(`p3dFindCenter`).checked =
      code.includes(`xCenter`)),
    ($(`p3dGoCenter`).checked =
      code.includes(`Mover al centro`)),
    ($(`p3dSpindleOff`).checked = code.includes(`M5`)),
    ($(`p3dCheckProbe`).checked =
      code.includes(`abort`)));
  const wcsMatch = code.match(/G10 L2 P(\d)/);
  if (wcsMatch) {
    const wcsVal =
        { 1: `G54`, 2: `G55`, 3: `G56`, 4: `G57`, 5: `G58`, 6: `G59` }[
          wcsMatch[1]
        ] || `G54`,
      radio = $q(`input[name="p3dWCS"][value="${wcsVal}"]`);
    radio && (radio.checked = !0);
  }
  (_p3dTabs.forEach((t, i) => {
    ($(t.btn).classList.toggle(`active`, i === 0),
      ($(t.panel).style.display =
        i === 0 ? `block` : `none`));
  }),
    (window.__rotechosModalLastFocus = document.activeElement),
    $(`probe3dModal`).classList.add(`show`));
}
($(`btnProbe3dClose`).addEventListener(`click`, () => {
  $(`probe3dModal`).classList.remove(`show`);
}),
  // Palpado automático XY (experimental): gate persistente + lanzador.
  $(`p3dAutoEnable`)?.addEventListener(`change`, async (e) => {
    const on = e.target.checked;
    const ok = await RRF.gcode(`set global.autoProbeEnabled = ${on ? `true` : `false`}`);
    $(`btnProbeAutoXY`).disabled = !on;
    if (ok)
      toast(
        on ? t(`msg.probeAutoOn`, `Palpado automático activado`) : t(`msg.probeAutoOff`, `Palpado automático desactivado`),
        on ? `warn` : `info`,
      );
  }),
  $(`btnProbeAutoXY`)?.addEventListener(`click`, async () => {
    if (
      !(await confirmDashboard(
        t(`dlg.probeAutoXY.title`, `Palpado automático XY`),
        t(`dlg.probeAutoXY.msg`,
          `La máquina sondeará X e Y automáticamente moviéndose hacia la pieza.<br>` +
          `<b>Coloca el palpador en diagonal a la esquina, en el aire, a la altura del borde.</b><br>¿Empezar?`),
      ))
    )
      return;
    if (machineMoveBlocked()) return;
    const r = await RRF.gcode(`M98 P"0:/macros/probe_xy_auto.g"`);
    toast(
      r ? t(`msg.probeAutoOk`, `Palpado automático iniciado…`) : t(`msg.probeAutoErr`, `Error al lanzar probe_xy_auto.g`),
      r ? `info` : `err`,
    );
  }),
  $(`btnProbe3dSave`).addEventListener(`click`, () => {
    if (editingMacroIdx < 0) return;
    const p = {
      ballDiam: parseFloat($(`p3dBallDiam`).value) || 2,
      stemLen: parseFloat($(`p3dStemLen`).value) || 50,
      probeNum: parseInt($(`p3dProbeNum`).value) || 0,
      doX: $(`p3dDoX`).checked,
      doY: $(`p3dDoY`).checked,
      doZ: $(`p3dDoZ`).checked,
      findCenter: $(`p3dFindCenter`).checked,
      seekF: parseFloat($(`p3dSeekF`).value) || 500,
      seekDist: parseFloat($(`p3dSeekDist`).value) || 20,
      backF: parseFloat($(`p3dBackF`).value) || 50,
      retract: parseFloat($(`p3dRetract`).value) || 2,
      offX: parseFloat($(`p3dOffX`).value) || 0,
      offY: parseFloat($(`p3dOffY`).value) || 0,
      offZ: parseFloat($(`p3dOffZ`).value) || 0,
      wcs:
        $q(`input[name="p3dWCS"]:checked`)?.value || `G54`,
      safeZ: parseFloat($(`p3dSafeZ`).value) || 10,
      finalZ: parseFloat($(`p3dFinalZ`).value) || 20,
      travelF: parseFloat($(`p3dTravelF`).value) || 3e3,
      approach: parseFloat($(`p3dApproach`).value) || 5,
      goCenter: $(`p3dGoCenter`).checked,
      spindleOff: $(`p3dSpindleOff`).checked,
      checkProbe: $(`p3dCheckProbe`).checked,
    };
    // Mismo criterio que btnParkEditorSave y btnProbeEditorSave: el código generado
    // aquí es una copia de trabajo de la UI, no la macro validada que vive en la SD.
    // NO se sube con macroWriteSD para no machacar probe3d.g con una versión que no
    // ha pasado por banco. El toast lo dice en vez de fingir que se guardó.
    ((myMacros[editingMacroIdx].code = buildProbe3dGCode(p)),
      renderMacros(),
      toast(t(`msg.probe3dgActualizado`, `Cambio solo en esta sesión — probe3d.g de la SD NO se ha tocado. Aquí solo se regenera la copia en memoria de la macro (la que usa la UI al lanzar el palpador 3D); al recargar o reiniciar la máquina se vuelve al probe3d.g que hay en 0:/macros/. Para guardar el nuevo código en la SD, edita probe3d.g desde CONFIGURACIÓN → Macros y pulsa Guardar.`), `warn`),
      log(`Palpador 3D (copia UI) actualizado — la SD no se toca`, `sys`),
      $(`probe3dModal`).classList.remove(`show`));
  }));
function openParkEditor(code) {
  const getNum = (re, def) => parseFloat((code.match(re) || [])[1]) || def;
  (($(`parkX`).value = getNum(
    /G53\s+G0\s+X([-\d.]+)/,
    0,
  )),
    ($(`parkY`).value = getNum(
      /G53\s+G0\s+Y([-\d.]+)/,
      0,
    )),
    ($(`parkZ`).value = getNum(
      /G53\s+G0\s+Z([-\d.]+)/,
      0,
    )),
    ($(`parkFeedXY`).value = getNum(
      /G0\s+X.*F(\d+)/,
      3e3,
    )),
    ($(`parkFeedZ`).value = getNum(
      /G0\s+Z.*F(\d+)/,
      1e3,
    )),
    ($(`parkStopSpindle`).checked = code.includes(`M5`)),
    ($(`parkUseMachine`).checked = code.includes(`G53`)),
    (window.__rotechosModalLastFocus = document.activeElement),
    $(`parkEditorModal`).classList.add(`show`));
}
function buildParkGCode() {
  const x = parseFloat($(`parkX`).value) || 0,
    y = parseFloat($(`parkY`).value) || 0,
    z = parseFloat($(`parkZ`).value) || 0,
    fxy = parseFloat($(`parkFeedXY`).value) || 3e3,
    fz = parseFloat($(`parkFeedZ`).value) || 1e3,
    stopSpindle = $(`parkStopSpindle`).checked,
    g53 = $(`parkUseMachine`).checked ? `G53 ` : ``;
  let c = `; park.g — Aparcado (RotechOS)



`;
  return (
    stopSpindle &&
      (c += `M5                           ; apagar spindle



`),
    (c += `G90



`),
    (c += `${g53}G1 Z${z} F${fz}           ; subir Z\n`),
    (c += `${g53}G1 X${x} Y${y} F${fxy}   ; mover a posición de aparcado\n`),
    c.trim()
  );
}
($(`btnParkEditorClose`).addEventListener(`click`, () => {
  $(`parkEditorModal`).classList.remove(`show`);
}),
  $(`btnParkEditorSave`).addEventListener(`click`, () => {
    // OJO: buildParkGCode() genera un park.g SIMPLIFICADO — sin T0, sin M9 y, sobre
    // todo, SIN el guard de homing que sí tiene el park.g real de la SD
    // (ROTECHOS/macros/park.g: "if !move.axes[0].homed || ... abort"). Subirlo
    // sustituiría una macro con guard por una sin él, y park usa G53: sin homing
    // eso es movimiento indefinido. Por eso NO se escribe en la SD. Antes este
    // botón decía "actualizado ✓" tocando solo la copia en memoria — era engañoso.
    editingMacroIdx < 0 ||
      ((myMacros[editingMacroIdx].code = buildParkGCode()),
      renderMacros(),
      toast(t(`msg.parkgActualizado`, `Cambio solo en esta sesión — park.g de la SD NO se ha tocado. Aquí solo se regenera la copia en memoria de la macro Aparcar (la que usa la UI al pulsar APARCAR Z); al recargar o reiniciar la máquina se vuelve al park.g que hay en 0:/macros/. Para guardar el nuevo código en la SD, edita park.g desde CONFIGURACIÓN → Macros y pulsa Guardar.`), `warn`),
      log(`Aparcar (copia UI) actualizado — la SD no se toca`, `sys`),
      $(`parkEditorModal`).classList.remove(`show`));
  }));

// (13-sep) Retirado un 2.º oyente de #btnOpenNewMacroConfig que abría también #macroModal y perdía la macro.

  (function () {
    // t_781ca88e (ago-2026): _renderRmMacrosCentered borrado (muerto, ver K3).
    $(`rmMacrosCenterList`)?.addEventListener(`click`, async (e) => {
      const btn = e.target.closest(`.rm-macro-btn`);
      if (!btn) return;
      const m = myMacros[btn.dataset.index];
      if (!m) return;
      
      // R-02 (2026-08-30) · guard que faltaba. Las otras TRES superficies de
      // macros comprueban `machineMoveBlocked()` antes de lanzar el M98
      // (rotechos-macros.js:153 y rotechos.js:pendantExecMacro); esta no, asi
      // que desde este modal se podia lanzar una macro que mueve la maquina
      // con un trabajo EN MARCHA. Misma excepcion que el resto: vssc.g se
      // permite en marcha a proposito (anti-chatter).
      if (!MACRO_SIN_CONFIRMACION.test(m.name) && machineMoveBlocked()) return;
      // R-02: lista blanca sustituida por el SSOT. La de aqui incluia `torno`
      // (macro que NO EXISTE) y omitia `coreografia` (que si existe y mueve la
      // maquina): la coreografia se ejecutaba sin preguntar desde este modal.
      if (macroNecesitaConfirmacion(m.name)) {
        if (
          !(await (async () => {
            // Fase 4.12 · misma ficha que en el cockpit (ruta + flags riesgo)
            const ficha = await macroInspect(m);
            return confirmDashboard(
              t(`dlg.macroRun.title`, `Ejecutar macro`),
              `<p>${t(`dlg.macroRun.pre`, `La macro`)} <strong>${escHtml(m.name)}</strong> ${t(`dlg.macroRun.moves`, `mueve la máquina.`)}</p>` +
              macroFichaHtml(ficha) +
              `<p style="color:var(--yellow);margin-top:4px">${escHtml(t(`dlg.macroRun.clear`, `Verifica que el área está despejada.`))}</p>`,
            );
          })())
        ) return;
      }
      
      btn.classList.add(`loading`);
      $(`rmMacrosCenterModal`)?.classList.remove(`show`);
      const r = await RRF.gcode(`M98 P"${m.path}"`);
      btn.classList.remove(`loading`);
      toast(r ? `✓ ${m.name}` : `${t(`msg.macroErrPfx`, `Error en`)} "${m.name}"`, r ? `ok` : `err`);
      log(`M98 P"${m.path}"`, `cmd`);
    });
    (// H-5: el pendant ya no tiene botón Macros propio; este modal se abre desde .pendant2-misc-btn.
      document
        .getElementById(`rmMacrosCenterClose`)
        .addEventListener(`click`, () => {
          document
            .getElementById(`rmMacrosCenterModal`)
            .classList.remove(`show`);
        }),
      document
        .getElementById(`rmMacrosCenterModal`)
        .addEventListener(`click`, (e) => {
          e.target === $(`rmMacrosCenterModal`) &&
            document
              .getElementById(`rmMacrosCenterModal`)
              .classList.remove(`show`);
        }));
  })();
