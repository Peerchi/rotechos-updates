/* ---
 * rotechos-file-ops.js — Defer module: carga de archivo y reset de firmware.
 *
 * Sprint 6 fase 2 del programa de reducción del monolito. Saca de rotechos.js
 * los cuerpos REALES de loadFile / doReset / getDestForFile.
 *
 * Notas de la extracción (no las deshagas sin leer el contrato en
 * tests/unit/file-ops-core.test.js, que es la especificación de este fichero):
 *
 *  - `getDestForFile` estaba ANIDADA en el IIFE del gestor OTA y leía `destSel`,
 *    una referencia DOM capturada al construir ese IIFE. Aquí queda desanidada
 *    con lookup perezoso (`$('otaUploadDest')` en cada llamada). Eso arregla de
 *    paso un bug latente de la fachada: `FILE_OPS.getDest` apuntaba a una
 *    función local del IIFE y lanzaba ReferenceError si se invocaba desde fuera.
 *    El lookup perezoso además tolera que el select no exista en el DOM.
 *
 *  - El estado privado del uploader OTA (la cola y la versión en curso) NO migra:
 *    es estado de UI de ese IIFE, no una dependencia de FILE_OPS. Sigue en el
 *    monolito. Este fichero no debe referenciarlo.
 *
 *  - Este módulo carga DESPUÉS del shell (defer, tras rotechos.js). Por eso los
 *    listeners de los botones de reset se enganchan con arrow (`() => doReset()`)
 *    y no por valor: al ejecutarse rotechos.js, `doReset` todavía no existe.
 * --- */
'use strict';

const AUTO_ROUTES = {
  '.g':    `0:/sys`,
  '.cfg':  `0:/sys`,
  '.html': `0:/www`,
  '.js':   `0:/www/js`,
  '.css':  `0:/www/css`,
  '.json': `0:/www/data`,   // school-tips.json (manifest.json va a la raiz: RAIZ_WWW)
  '.png':  `0:/www/icons`,
  '.gcode':`0:/gcodes`,
  '.nc':   `0:/gcodes`,
  '.ngc':  `0:/gcodes`,
  '.tap':  `0:/gcodes`,
  '.cnc':  `0:/gcodes`,
};

// Un .gz va donde su fichero base (rotechos.js.gz → 0:/www/js), y sw.js y
// manifest.json viven en la raiz de www, no en www/js. Antes el .gz caia en
// «destino desconocido» proponiendo 0:/sys y sw.js iba a 0:/www/js: la placa
// seguia sirviendo el service worker viejo y la interfaz no se actualizaba.
const RAIZ_WWW = [`sw.js`, `manifest.json`];
function _otaBase(name) {
  const b = String(name).slice(String(name).lastIndexOf(`/`) + 1).toLowerCase();
  return b.endsWith(`.gz`) ? b.slice(0, -3) : b;
}
function _otaRuta(name) {
  const b = _otaBase(name);
  if (RAIZ_WWW.includes(b)) return `0:/www`;
  return b.includes(`.`) ? AUTO_ROUTES[`.` + b.split(`.`).pop()] : undefined;
}

// Fase 4.11: clasificación legible para el operario.
// `path` se mantiene compatible con getDestForFile (mismo string que ya
// consume el IIFE OTA); `type` y `impact` se usan para:
//   - cola visual (mostrar tipo y, en rojo, el impacto)
//   - confirmDialog de subida (mostrar tipo por archivo y nota global
//     "estos N archivos recargan la UI / requieren reboot del Duet")
//   - historial (registrar el impacto junto con tamaño y fecha)
//
// Categorías (ordenadas por blast-radius de menor a mayor):
//   ui       → recarga de navegador en 3s; el operario NO pierde posición
//              de ejes, solo se refresca el cockpit. .html / .js / .css.
//   gcode    → pieza inerte; se ejecuta solo al seleccionarla y darle
//              INICIAR. .gcode / .nc / .ngc / .tap / .cnc.
//   macro    → archivo .g dentro de /macros/; la UI lo invoca con M98,
//              un cambio se ve en la próxima invocación, sin reboot.
//   firmware → .g en /sys; el Duet lee /sys al arrancar. Subirlo no rompe
//              nada inmediatamente pero requiere reboot manual o M999
//              para releer. Incluye config.g, start.g, home*.g, etc.
//   config   → .cfg en /sys (board.cfg, wifi.cfg): configuración interna.
//              Se trata como firmware porque vive en /sys y requiere
//              reboot del Duet para aplicarse.
//   unknown  → extensión no en AUTO_ROUTES. El operario debe elegir
//              destino antes de subir (addFiles dispara confirmDialog).
function _classify(name, path) {
  // path puede contener '/macros/' por el override del select — en ese
  // caso .g debe contar como macro, no firmware, aunque la extensión sea
  // .g. Para archivos en /sys, .g es firmware.
  if (/\/macros(\/|$)/i.test(path || ``)) {  // el select da `0:/macros`, sin barra final
    return { type: `macro`, impact: `next-invoke` };
  }
  const b = _otaBase(name);
  const ext = b.includes(`.`) ? `.` + b.split(`.`).pop() : ``;
  if ([`.html`, `.js`, `.css`, `.json`, `.png`].includes(ext) || RAIZ_WWW.includes(b)) {
    return { type: `ui`, impact: `reload-ui` };
  }
  if (ext === `.g`) {
    return { type: `firmware`, impact: `reboot-duet` };
  }
  if (ext === `.cfg`) {
    return { type: `config`, impact: `reboot-duet` };
  }
  if (ext === `.gcode` || ext === `.nc` || ext === `.ngc`
      || ext === `.tap` || ext === `.cnc`) {
    return { type: `gcode`, impact: `none` };
  }
  return { type: `unknown`, impact: `none` };
}

function getDestForFile(name) {
  // Lookup perezoso: el select puede no existir todavía (o nunca, en la
  // vista pendant). Si no está, enrutamos por extensión igualmente.
  const destSel = $(`otaUploadDest`);
  if (destSel && destSel.value !== `auto`) return destSel.value;
  return _otaRuta(name) || `0:/sys`;
}

// Fase 4.11: misma ruta que getDestForFile, pero enriquecida con la
// clasificación legible para el operario. Mantiene retrocompatibilidad
// total — el IIFE OTA solo necesita `.path`, los nuevos `.type`/`.impact`
// se usan en la cola visual y el confirmDialog de subida.
function getDestInfo(name) {
  const path = getDestForFile(name);
  const { type, impact } = _classify(name, path);
  return { path, type, impact };
}

// Fase 4.11: predicado puro consumido por addFiles. Devuelve true si
// la extensión del archivo NO está en AUTO_ROUTES y el nombre tiene al
// menos un punto (los archivos sin extensión cuentan como desconocidos
// también — README, LICENSE, etc. acaban en /sys silenciosamente desde
// el Sprint 6 fase 2, lo cual es undesired: este predicado permite al
// IIFE OTA abrir el confirmDialog de "destino desconocido" en lugar de
//colar el archivo en la cola sin avisar).
// El IIFE OTA pasa `name` (basename, no fullPath) y tolera inputs
// degenerados sin lanzar.
function isUnknownExt(name) {
  if (typeof name !== `string` || !name) return false;
  return !_otaRuta(name);  // sin extension o extension sin ruta → desconocido
}

async function _m23Abierto(filename) {
  for (let i = 0; i < 6; i++) {
    const f = _unwrap(await _fetchModel(`job.file`, 1500));
    if (!f || typeof f !== `object` || !(`fileName` in f)) return true;
    if (String(f.fileName || ``).endsWith(`/${filename}`)) return true;
    if (i < 5) await new Promise((r) => setTimeout(r, 300));
  }
  return false;
}
async function loadFile(filename, gcode = null) {
  if (SM.current === STATES.RUNNING || SM.current === STATES.PAUSED) {
    if (
      !(await confirmDialog(
        t(`dlg.loadCancel.title`, `Trabajo en progreso`),
        `${t(`dlg.loadCancel.pre`, `Hay un trabajo activo`)} (<strong>${escHtml(SM.loadedFile || `desconocido`)}</strong>).<br>${t(`dlg.loadCancel.q`, `¿Cancelar trabajo actual y cargar`)} <strong>${escHtml(filename)}</strong>?`,
      ))
    )
      return;
    // FIX: M25 antes de M0 — RRF ignora M0 si está RUNNING
    _clearPollTimer();
    SM._cancelInProgress = !0;
    try { await RRF.urgentGcode(`M25\nM0\nT0\nM5`); } catch {}
    log(`M25+M0+T0+M5 — Trabajo cancelado para reemplazar archivo`, `warn`);
    // Restaurar SEDA tras cancelar
    try { await RRF.gcode(`M98 P"${MACROS.setSilk}"`); } catch { RRF.gcode(FALLBACK_SEDA).catch(() => {}); }
    SM.jobStartTime = null;
    SM.wasSeenRunning = false;
    SM._cancelInProgress = !1;
    SM.transition(STATES.IDLE, `archivo reemplazado`);
    startPoll();
  }
  if (SM.current === STATES.RUNNING) {
    toast(t(`msg.fileNoActive`, `No se puede cargar el archivo mientras la máquina trabaja`), `err`);
    return;
  }
  // G3: lint al cargar — ANTES del M23. Si el usuario cancela en el confirmDialog,
  // el M23 nunca se envía y el archivo no queda armado en la máquina. Bugfix de la
  // 2ª verificación (Claude): el rework anterior corría el lint DESPUÉS del M23
  // y su "cancelar" solo hacía return — el archivo quedaba READY, mentiroso.
  // Avisar SIN BLOQUEAR: errores → confirmDialog con opción de continuar; warnings
  // → toast. Archivos grandes (≥50MB): capar el lint a las primeras 20k líneas
  // para cero jank en móvil (vizLoadGCode ya capeaba con codeLineMap).
  if (gcode && /\.g$/i.test(filename || ``)) {
    const _lintCap = gcode.split(/\r?\n/).slice(0, 20000).join(`\n`);
    const _lintRes = _lintGcode(_lintCap, filename);
    if (_lintRes.errors.length) {
      if (typeof confirmDialog === `function`) {
        const ok = await confirmDialog(
          t(`dlg.lintLoad.title`, `Archivo no parece generado para RotechOS`),
          `<b>${escHtml(filename)}</b> ${t(`dlg.lintLoad.has`, `tiene`)} ${_lintRes.errors.length} ${t(`dlg.lintLoad.problems`, `problema(s) que RRF rechaza`)}:<br><br>${
            _lintRes.errors.slice(0, 5).map((e) => `• ${escHtml(e)}`).join(`<br>`)
          }${_lintRes.errors.length > 5 ? `<br>…${t(`dlg.lintLoad.andMore`, `y`)} ${_lintRes.errors.length - 5} ${t(`dlg.lintLoad.more`, `más`)}` : ``}<br><br>${t(`dlg.lintLoad.help`, `<b>Cómo solucionarlo:</b> regenera el archivo con el postprocesador de RotechOS (se entrega aparte con la máquina) — la mayoría de estos errores desaparecen. Si no puedes, abre el archivo en CONFIGURACIÓN → Macros o un editor de texto, corrige las líneas marcadas y vuelve a subirlo. Cancelar aquí significa que NO se carga; Cargar igualmente lo sube aunque RRF puede rechazarlo al enviar comandos.`)}<br><br>${t(`dlg.lintLoad.loadAnyway`, `¿Cargar igualmente?`)}`,
          { okText: t(`dlg.lintLoad.yes`, `Cargar igualmente`), cancelText: t(`dlg.lintLoad.no`, `Cancelar`) }
        );
        if (!ok) {
          log(`G3: carga cancelada por lint al cargar (${_lintRes.errors.length} errores) — M23 NO enviado`, `warn`);
          return;
        }
      }
    }
    if (_lintRes.warnings.length) {
      toast(t(`msg.lintLoadWarnings`, `${filename}: ${_lintRes.warnings.length} aviso(s) — revisa la consola (panel inferior del cockpit, pestaña CONSOLA)`), `warn`);
      _lintRes.warnings.slice(0, 5).forEach((w) => log(`lint al cargar: ${w}`, `warn`));
    }
  }
  if (
    !(await RRF.gcode(
      // 5-oct: sin encodeURIComponent: RRF no decodifica el nombre (RRF.gcode ya codifica
      // la URL), y «Mi pieza.gcode» llegaba como «Mi%20pieza.gcode»: no encontrado.
      `M23 "0:/gcodes/${window.escGcodeArg(filename)}"`,
    ))
  ) {
    toast(t(`msg.errorAlCargarFilename`, `Error al cargar ${filename}`, { "filename": filename }), `err`);
    return;
  }
  // 6-oct: rr_gcode contesta antes de ejecutar el M23; si RRF no abre el fichero, la
  // interfaz decía LISTO igual. Se mira job.file.fileName (sin dato, se sigue como antes).
  if (!(await _m23Abierto(filename))) {
    toast(t(`msg.m23NoAbierto`, `La máquina no ha podido abrir ${filename}`, { "filename": filename }), `err`);
    return;
  }
  ((SM.loadedFile = filename),
    (SM.jobStartTime = null),
    (SM.wasSeenRunning = false),
    ($(`progFilename`).textContent = filename),
    SM.transition(STATES.READY, `archivo: ${filename}`),
    toast(t(`msg.listoFilename`, `✓ Listo: ${filename}`, { "filename": filename }), `ok`),
    log(`M23 "${filename}" — Archivo cargado, estado READY`, `cmd`),
    gcode
      ? vizLoadGCode(gcode, filename)
      : ((SM.gcodeLineMap = null),
        (SM.lastLoggedLine = null),
        (SM.lastLoggedFilePos = null),
        (SM.lastLineLogAt = 0),
        ($(`vizFileName`).textContent = filename),
        ($(`vizClearFile`).style.display = `flex`)));
}

async function doReset() {
  if (SM.current !== STATES.ERROR || SM._resetInProgress) return;
  SM._estopM112 = null;  // REINICIAR anula el reenvio pendiente del M112
  // D-03: rr_reset iba sin escudo; con PIN, RRF lo rechazaba y la unica via de
  // autenticar era el M999 de respaldo. El guard va ANTES de tocar estado: un
  // aborto no deja _resetInProgress pegado ni la pildora en «Reiniciando…».
  if (typeof window !== `undefined` && window.rotechosShieldMsg
    && !await window.rotechosShieldMsg.guard(TARGET_IP, `doReset`)) return;
  SM._resetInProgress = !0;
  (log(`Enviando reset al firmware…`, `sys`),
    toast(t(`msg.resetting`, `Reiniciando firmware…`), `warn`),
    setConn(!1, `Reiniciando…`),
    ($(`connPill`).className = `conn-pill busy`));
  let resetOk = !1;
  try {
    const r = await _fetchRRF(`${TARGET_IP}/rr_reset`, { method: `GET` });
    resetOk = r.ok || r.status === 0;
  } catch {
    resetOk = !0;
  }
  if (!resetOk)
    try {
      (await RRF.gcode(`M999`), (resetOk = !0));
    } catch {
      resetOk = !0;
    }
  clearJob();
  // Tras halt/emergencia los ejes pierden referencia — forzar homing antes de trabajar
  AppState.limits.allHomed = false;
  AppState.sys.postEmergencyReset = true;
  ((SM.estimatedTotalMs = null),
    (SM.estimatedTotalLines = null),
    log(`Reset enviado — esperando reconexión…`, `sys`));
  let attempts = 0;
  const tryReconnect = async () => {
      (attempts++,
        log(`Intento de reconexión ${attempts}/${CFG.reconnRetries}…`, `sys`),
        (await RRF.connect())
          ? ((SM._resetInProgress = !1),
            // 15-sep (C-9): la reconexión tras el reset cierra el paro. Sin esto, el
            // flag seguía en true (solo lo limpiaba el vigilante de M999) y la próxima
            // reconexión no repintaba «Conectado».
            (SM._rebootPending = !1),
            SM.transition(STATES.IDLE, `RESET completado`),
            setConn(!0, `Conectado`),
            toast(t(`msg.resetOk`, `✓ Máquina reiniciada → IDLE`), `ok`),
            log(`Reconexión exitosa tras reset`, `sys`),
            startPoll())
          : attempts < CFG.reconnRetries
            ? setTimeout(tryReconnect, CFG.reconnIntervalMs)
            : ((SM._resetInProgress = !1),
              setConn(!1, `Sin conexión`),
              toast(t(`msg.resetFailed`, `No se pudo reconectar tras reset`), `err`),
              log(`Sin respuesta tras reset — verifica la máquina`, `err`),
              SM.transition(STATES.IDLE, `reset timeout`)));
    };
  setTimeout(tryReconnect, CFG.reconnFirstMs);
}

// El binding top-level es parte del contrato (tests/unit/file-ops-core.test.js
// comprueba `^const FILE_OPS = window.FILE_OPS =`): actúa de centinela `typeof`
// para el resto del shell. Dentro de este fichero no se consume, de ahí el disable.
// eslint-disable-next-line no-unused-vars
const FILE_OPS = window.FILE_OPS = {
  load: loadFile,
  reset: doReset,
  getDest: getDestForFile,
  // Fase 4.11: clasificación legible para el operario. Consumida por el
  // IIFE OTA en rotechos.js:3025-3349 para colorear la cola visual,
  // enriquecer el confirmDialog de subida y registrar el impacto en
  // el historial. `getDest` se conserva para retrocompatibilidad —
  // `getDest(name) === getDestInfo(name).path`.
  getDestInfo,
  // Fase 4.11: predicado puro que detecta extensiones no enrutables.
  // addFiles lo consulta ANTES de encolar; si true y el select está en
  // 'auto', muestra confirmDialog con opciones de destino en lugar de
  //colar el archivo silenciosamente.
  isUnknownExt,
};
