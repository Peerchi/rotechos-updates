// ---
// rotechos-m999-watchdog.js — Watcher M999 + cadencias del watchdog de
// reconexión tras reboot detectado por M999.
//
// TARJETA t_1f6006ac · FASE 2 del plan de fragmentación del monolito
// (docs/dev/hallazgos/2026-09-09_monolito-diagnostico-y-plan-de-fragmentacion.md §3).
// Extraído del monolito rotechos.js (L903-1003, bloque 6) tal cual: 102 líneas,
// funciones top-level (no IIFE). Carga `defer` ANTES de rotechos.js para que
// el watcher exista cuando `RRF.gcode` (bloque 7, L1033) detecta un reboot
// en el primer ciclo tras la conexión.
//
// QUE HACIA ANTES Y QUE HACE AHORA
//   ANTES: las funciones `M999_TICK_FAST_MS`, `M999_TICK_SLOW_MS` y
//   `_m999WatcherTick` vivían top-level en el monolito. `RRF.gcode` las
//   llamaba por nombre (no por window). `AppState.sys.m999Watcher` se leía
//   desde `btnRecon` (L3792) como "ya hay un reconnect en curso".
//
//   AHORA: este módulo exporta `window.M999_WATCHDOG` con la misma
//   superficie que usan los call-sites del monolito. El monolito pasa de
//   llamar `_m999WatcherTick` directamente a `M999_WATCHDOG.tick()`; el
//   setInterval y el clearInterval los maneja el módulo.
//
//   Tres call-sites en el monolito:
//     · RRF.gcode (L1130, L1149): clear() + start()
//     · btnRecon (L3792): hasActiveWatcher() — guard "ya hay reconexión"
//
// POR QUE ES EAGER (no lazy)
//   El watcher salta en el PRIMER ciclo tras un reboot detectado por M999
//   (latencia mínima 1 s). Si se mueve a lazy, el primer intento de
//   reconexión NO tendría escudo (el módulo no estaría cargado) y la
//   decisión del operador quedaría sin proteger durante ~100 ms. Esto es
//   la regla del plan §2.2 sobre FAIL-OPEN: si roto, el escudo no se ve.
//   `rotechos-m999-watchdog.js` se queda EAGER.
//
// POR QUE window.M999_WATCHDOG Y NO window.WATCHDOG
//   El nombre del plan §3 FASE 2 decía WATCHDOG. Pero ese nombre ya está
//   "reservado" semánticamente (el watchdog de endstops / conexión). El
//   prefijo M999_ lo distingue de otros usos futuros del término y casa
//   con los nombres originales `M999_TICK_FAST_MS` / `M999_TICK_SLOW_MS`.
// ---

// Cadencias del watchdog que re-intenta la conexión durante un reboot
// detectado por M999. FAST = polling agresivo nada más detectar el reboot
// (latencia mínima para reconectar); SLOW = backoff tras un rechazo del
// escudo (PIN mal, lockout, network_error) para no martillear el overlay.
const TICK_FAST_MS = 1000;
const TICK_SLOW_MS = 8000;

async function tick() {
  if (!SM._rebootPending) {
    clearInterval(AppState.sys.m999Watcher);
    AppState.sys.m999Watcher = null;
    return;
  }
  try {
    // FIX H-3 (informe 2026-08-17_busca-superficie-de-seguridad-api-rrf-y-pin-v1):
    // el inline M999 watcher construía la URL /rr_connect a mano y
    // NO usaba tryConnect. Tres problemas: (1) sin overlay si RRF
    // rechaza (operario confunde con problema de red), (2) martillea
    // sin rate-limit, (3) NO clasifica body con errMessage:"password…"
    // → marcaba como conectado falsamente y disparaba reload. Ahora
    // delega en el mismo helper que RRF.connect (línea 817), que ya
    // muestra overlay, respeta rate-limit y clasifica 401/errMessage.
    //
    // FIX H-N6 (0ba47f9, convive con H-N3): pasamos el 4º arg
    // `enTrabajo` para mantener el contrato de `tryConnect(baseIp,
    // pin, fetcher, sinOverlay)`. Durante un reboot `enTrabajo` es
    // false (la sesión no está cortando), así que el comportamiento
    // es el mismo que antes — el escudo muestra overlay si el PIN
    // está mal — pero la firma queda preparada si más adelante se
    // reusa el helper desde otra ruta del watcher.
    const _enTrabajo = (typeof SM !== `undefined` && typeof STATES !== `undefined`
      && (SM.current === STATES.RUNNING || SM.current === STATES.PAUSED));
    let c = null;
    if (typeof window !== `undefined` && window.rotechosAuth && typeof window.rotechosAuth.tryConnect === `function`) {
      c = await window.rotechosAuth.tryConnect(TARGET_IP, ``, undefined, _enTrabajo);
    } else {
      const r = await _fetchRRF(`${TARGET_IP}/rr_connect?password=&time=${Date.now()}`);
      c = { ok: r.ok, body: null };
    }
    if (c && c.ok) {
      SM._rebootPending = !1;
      // H-C: limpiar el flag de pausa de poll regular para que el
      // startPoll() que viene justo después (línea 1000) re-agende
      // polling a la cadencia normal. Sin esto, el flag se quedaría
      // pegado y el siguiente reboot no tendría el escudo.
      AppState.sys.m999InProgress = !1;
      clearInterval(AppState.sys.m999Watcher);
      AppState.sys.m999Watcher = null;
      const ov = $(`rebootOverlay`);
      if (ov) {
        ov._clearTimer?.();
        // Cabeza: div con clase "reboot-util-2" (CSS rotechos.css:3276 aplica
        // font-size:20px; el selector viejo `[style*="font-size:20px"]`
        // nunca matcheaba el HTML estático, así que la rama post-M999
        // tiraba TypeError silencioso — HALLAZGO-11b, derivado de
        // SOSPECHA-4 del informe v2).
        ov.querySelector('.reboot-util-2').textContent =
          t(`msg.rebootReconnected`, `RECONECTADO`);
        ov.querySelector('.mcfg-lbl').innerHTML =
          t(`msg.rebootReloadingInterface`, `Recargando interfaz…`);
        const sp = $(`rebootSpinner`);
        if (sp) {
          sp.style.animation =
            "reboot-spin-reverse 1.5s linear infinite";
          sp.style.stroke = "var(--green2)";
        }
      }
      setConn(!0, "Conectado");
      toast(t(`msg.reconnected`, `Reconectado — recargando…`), "ok");
      startPoll();
      // H-6 (busca-el-monolito 2026-08-17): si btnRecon ya programó
      // un reload en su setTimeout, NO programar otro — el primero
      // gana y el segundo se desperdicia (parpadeo con red inestable).
      if (AppState.sys._reloadScheduled) return;
      AppState.sys._reloadScheduled = !0;
      setTimeout(() => location.reload(), 1500);
      return;
    }
    // FIX H-N3: el escudo rechazó (overlay cancelado, lockout activo,
    // 401 con PIN cacheado stale, network_error). Pasamos a backoff
    // de 8 s para no martillear el overlay cada segundo. Re-armamos
    // el setInterval con la cadencia lenta; el siguiente tick
    // (lento) reintentará `tryConnect`. Si entonces tiene éxito, el
    // camino de arriba (c.ok) corta el watcher y la UI recarga — el
    // siguiente M999 volverá a 1 s (la rama de arriba hace
    // `AppState.sys.m999WatcherTick = M999_TICK_FAST_MS` en el
    // siguiente arranque, vía la asignación justo antes del
    // setInterval). Si sigue rechazando, el propio
    // tick() permanece en SLOW (no vuelve a 1 s).
    if (AppState.sys.m999WatcherTick !== TICK_SLOW_MS) {
      clearInterval(AppState.sys.m999Watcher);
      AppState.sys.m999WatcherTick = TICK_SLOW_MS;
      AppState.sys.m999Watcher = setInterval(tick, TICK_SLOW_MS);
      log(`M999 watcher: escudo rechazó, backoff a ${TICK_SLOW_MS}ms`, `warn`);
    } else {
      log(`M999 watcher: escudo sigue rechazando, manteniendo backoff ${TICK_SLOW_MS}ms`, `warn`);
    }
  } catch {}
}

// FIX H-N3 (informe 2026-08-18_busca-superficie-de-seguridad-api-rrf-y-pin-v2,
// adaptado al HEAD 2026-08-27 que ya lleva el guard H-N6 de 0ba47f9):
// el watcher heredaba un setInterval fijo de 1000ms. Si el PIN cacheado
// estaba mal, `tryConnect` mostraba el overlay en cada tick — el operario
// lo cancelaba y 1 s después reaparecía. Resultado: bucle de overlays
// durante todo el reboot, sin posibilidad de abrir CONFIGURACIÓN para
// corregir el PIN. Ahora el tick arranca a 1 s (latencia mínima para
// detectar reconexión rápida) y, tras un rechazo del escudo, salta a
// 8000 ms (backoff). Si en el siguiente tick lento el escudo sigue
// rechazando, se mantiene en 8 s. Cuando `tryConnect` tiene éxito, el
// watcher corta (clearInterval) y el siguiente reboot vuelve a 1 s.
//
// Convivencia con H-N6 (t_6b0d109b / 0ba47f9): `tryConnect` ahora
// admite un 4º arg `sinOverlay`. Durante un M999 watcher el operario
// NO está cortando (estamos esperando reconexión), así que
// `enTrabajo` queda en false y la firma de 4 args se mantiene solo
// por consistencia de contrato; si en el futuro alguien reusa este
// helper desde otro punto del watcher, el parámetro ya está pasado.
function start() {
  if (AppState.sys.m999Watcher) clearInterval(AppState.sys.m999Watcher);
  AppState.sys.m999WatcherTick = TICK_FAST_MS;
  AppState.sys.m999Watcher = setInterval(tick, TICK_FAST_MS);
}

function clear() {
  if (AppState.sys.m999Watcher) clearInterval(AppState.sys.m999Watcher);
  AppState.sys.m999Watcher = null;
}

function hasActiveWatcher() {
  return !!AppState.sys.m999Watcher;
}

window.M999_WATCHDOG = Object.freeze({
  TICK_FAST_MS,
  TICK_SLOW_MS,
  tick,
  start,
  clear,
  hasActiveWatcher,
});