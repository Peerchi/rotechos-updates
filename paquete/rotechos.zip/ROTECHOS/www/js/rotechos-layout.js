// rotechos-layout.js — LAYOUT RESPONSIVE (pc / tablet / mobile) [NOTAS_JS N001]
'use strict';

(function () {
  // Estado del módulo: layout activo y timer del debounce de VIZ.
  let _layout = 'pc';
  let _layoutTimer = null;

  // Espejo en window: el monolito lo lee en updateStateUI (rotechos.js:883).
  // Usamos getter/setter para que la asignación interna (`_layout = layout`
  // dentro de applyLayout) se refleje automáticamente al exterior.
  Object.defineProperty(window, 'currentLayout', {
    configurable: true,
    enumerable: true,
    get() { return _layout; },
    set(v) { _layout = v; },
  });

  function detectAutoLayout() {
    // Movil apaisado (p.ej. 844x390) = pendant: el panel no cabe en 500 px de alto.
    // Mismo corte que las media queries de rotechos.css.
    const w = window.innerWidth, h = window.innerHeight;
    return w < 768 || (w < 1025 && h <= 500) ? 'mobile' : w < 1025 ? 'tablet' : 'pc';
  }

  function applyLayout(layout) {
    (
      (_layout = layout || detectAutoLayout()),
      document.body.classList.remove('layout-pc', 'layout-tablet', 'layout-mobile'),
      document.body.classList.add(`layout-${_layout}`)
    );
    if (typeof window.VIZ !== 'undefined') {
      if (_layoutTimer) clearTimeout(_layoutTimer);
      _layoutTimer = setTimeout(() => {
        window.VIZ.resize();
        if (window.VIZ.bounds) window.VIZ.fitView();
        window.VIZ.dirty = !0;
        _layoutTimer = null;
      }, 50);
    }
  }

  function initLayout() {
    applyLayout(detectAutoLayout());
    window.addEventListener('resize', () => applyLayout(detectAutoLayout()));
  }

  // Publicamos las funciones en window para que el `typeof initLayout ===
  // 'function'` del DOMContentLoaded central (rotechos.js:3616) siga siendo
  // válido sin tocar el call-site.
  window.detectAutoLayout = detectAutoLayout;
  window.applyLayout = applyLayout;
  window.initLayout = initLayout;
})();
