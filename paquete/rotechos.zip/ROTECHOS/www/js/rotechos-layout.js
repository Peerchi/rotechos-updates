/* ---
 * rotechos-layout.js — LAYOUT RESPONSIVE (pc / tablet / mobile)
 *                        Extraído de rotechos.js (ago-2026, extracción #N)
 *
 * Responsabilidad única: detectar el ancho de la ventana, aplicarlo como
 * clase CSS al <body> y notificar a VIZ para que reacomode la previsualización.
 * Sin estado de máquina, sin i18n, sin red — UI pura.
 *
 * ---
 * Dependencias (todas globales, resueltas por orden de <script defer>;
 * este archivo carga ANTES de rotechos.js — ver index.html):
 *   - rotechos-dom.js → $()  (si por lo que sea no está, los handlers
 *                            de resize siguen funcionando; el módulo se
 *                            degrada a no-tocar-el-DOM)
 *
 * Consumidores (cargan DESPUÉS, leen window.currentLayout / window.initLayout):
 *   - rotechos.js        → lee window.currentLayout en updateStateUI (móvil
 *                          sólo muestra el overlay de error en pantallas
 *                          pequeñas). También invoca initLayout() desde
 *                          el DOMContentLoaded central.
 *   - rotechos-viz.js    → VIZ.resize / VIZ.fitView / VIZ.dirty (opcional:
 *                          typeof VIZ !== 'undefined' lo protege).
 *
 * API pública (window.*):
 *   - window.currentLayout  → 'pc' | 'tablet' | 'mobile' (let semánticamente
 *                             — expuesto como propiedad live, no getter,
 *                             para que `window.currentLayout = 'pc'`
 *                             desde consumidores siga funcionando si
 *                             hiciese falta; hoy sólo se lee).
 *   - window.detectAutoLayout() → 'pc' | 'tablet' | 'mobile'
 *   - window.applyLayout(layout?) → aplica la clase al <body> y dispara
 *                                   el resize debounced de VIZ.
 *   - window.initLayout()    → añade listener de resize y aplica el layout
 *                              actual. Idempotente salvo por el listener,
 *                              que se registra una sola vez.
 *
 * Por qué `currentLayout` se publica en `window` y no como `let` interno:
 *   El monolito lee `currentLayout` desde updateStateUI() (rotechos.js:883)
 *   para decidir si el overlay de error de móvil debe mostrarse. Tras la
 *   extracción, esa lectura pasa por `window.currentLayout` sin tocar el
 *   call-site (la asignación interna también refleja en `window`).
 * --- */
'use strict';

(function () {
  // Estado del módulo: layout activo y timer del debounce de VIZ.
  let _layout = 'pc';
  let _layoutTimer = null;

  // Espejo en window: el monolito lo lee en updateStateUI (rotechos.js:883).
  // Usamos getter/setter para que la asignación interna (`_layout = layout`
  // dentro de applyLayout) se refleje automáticamente al exterior.
  Object.defineProperty(window, 'currentLayout', {
    configurable: true,
    enumerable: true,
    get() { return _layout; },
    set(v) { _layout = v; },
  });

  function detectAutoLayout() {
    // Movil apaisado (p.ej. 844x390) = pendant: el panel no cabe en 500 px de alto.
    // Mismo corte que las media queries de rotechos.css.
    const w = window.innerWidth, h = window.innerHeight;
    return w < 768 || (w < 1025 && h <= 500) ? 'mobile' : w < 1025 ? 'tablet' : 'pc';
  }

  function applyLayout(layout) {
    (
      (_layout = layout || detectAutoLayout()),
      document.body.classList.remove('layout-pc', 'layout-tablet', 'layout-mobile'),
      document.body.classList.add(`layout-${_layout}`)
    );
    if (typeof window.VIZ !== 'undefined') {
      if (_layoutTimer) clearTimeout(_layoutTimer);
      _layoutTimer = setTimeout(() => {
        window.VIZ.resize();
        if (window.VIZ.bounds) window.VIZ.fitView();
        window.VIZ.dirty = !0;
        _layoutTimer = null;
      }, 50);
    }
  }

  function initLayout() {
    applyLayout(detectAutoLayout());
    window.addEventListener('resize', () => applyLayout(detectAutoLayout()));
  }

  // Publicamos las funciones en window para que el `typeof initLayout ===
  // 'function'` del DOMContentLoaded central (rotechos.js:3616) siga siendo
  // válido sin tocar el call-site.
  window.detectAutoLayout = detectAutoLayout;
  window.applyLayout = applyLayout;
  window.initLayout = initLayout;
})();
