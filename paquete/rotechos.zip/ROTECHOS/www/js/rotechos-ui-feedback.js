/* ---
 * rotechos-ui-feedback.js — FEEDBACK UI: toasts + indicador "modificado
 *                            sin guardar" en pestañas de configuración.
 *                            Extraído de rotechos.js (ago-2026, extracción #N)
 *
 * Dos bloques del monolito agrupados aquí porque son UI pura sin estado
 * compartido con la máquina: el toast es feedback efímero y los dirty tabs
 * son estado local del modal de configuración. No tocan firmware, ni
 * polling, ni red, ni i18n.
 *
 * ---
 * Dependencias (todas globales, resueltas por orden de <script defer>;
 * este archivo carga DESPUÉS de rotechos.js — ver index.html):
 *   - rotechos-dom.js → $(), $$()
 *   - rotechos.js     → window.AppState (publicado en la línea 39 del
 *                       monolito: `window.AppState = AppState;`).
 *                       AppState.ui.mcfgDirtyClear lo engancha el IIFE
 *                       de dirty tabs para que rotechos-config-modal.js
 *                       pueda llamarlo tras recargar la config desde la SD.
 *
 * Consumidores (cargan DESPUÉS, llaman window.toast):
 *   - rotechos.js           → 50 call-sites, todos resueltos por el nombre
 *                             global `toast(msg, tipo)`.
 *   - rotechos-file-ops.js, rotechos-fm.js, rotechos-backup.js,
 *     rotechos-config-modal.js, rotechos-macros.js, rotechos-jog.js,
 *     rotechos-spindle.js, rotechos-pendant.js, rotechos-viz.js,
 *     rotechos-ota.js, rotechos-bordeador.js, rotechos-firstcut.js,
 *     rotechos-notif.js, rotechos-wcs.js, rotechos-welcome.js,
 *     rotechos-poll.js, rotechos-modules.js.
 *
 * Tests:
 *   - tests/e2e-*.spec.js usan `#toastMsg` (DOM) y `.toast` (clase CSS).
 *     Funcionan mientras `toast()` siga modificando el mismo #toastMsg;
 *     este módulo lo respeta.
 *
 * API pública (window.*):
 *   - window.toast(msg, tipo?)  → muestra un toast en `#toast` con clase
 *                                  `ok` | `err` | `info` | `warn`.
 *   - window.TCONF              → tabla de tipos → [icono, duración ms].
 *
 * Estado interno (no expuesto):
 *   - dirtyTabs (Set), dirtyClearTimer — dirty tabs.
 *   - markCurrentTabDirty(), clearAllDirty() — dirty tabs. clearAllDirty
 *     también se publica como AppState.ui.mcfgDirtyClear.
 * --- */
'use strict';

// ---
// BLOQUE 15 — toast()
// ---
const TCONF = {
  // Sin emoji: el COLOR del toast (clase .ok/.err/.warn) ya distingue el estado.
  ok: ['', 2800],
  err: ['', 4e3],
  info: ['', 2500],
  warn: ['', 3200],
};
window.TCONF = TCONF;

// Cola FIFO de toasts (HALLAZGO-18): los avisos que llegan mientras otro
// sigue visible esperan su turno, sin cambiar la API síncrona de toast().
const pendingToasts = [];
let toastActivo = false;
// Severidad del toast que se esta mostrando ahora mismo, para poder decidir si
// un aviso urgente puede adelantarlo (ver toast() mas abajo).
let toastActivoTipo = null;

function drainQueue() {
  if (toastActivo || pendingToasts.length === 0) return;

  const { msg, tipo } = pendingToasts.shift();
  const el = $('toast');
  const [ico, dur] = TCONF[tipo] ?? TCONF.info;
  toastActivo = true;
  toastActivoTipo = tipo;
  (
    ($('toastIco').textContent = ico),
    ($('toastMsg').textContent = msg),
    (el.className = `toast show ${tipo}`),
    // A11Y-2 · variacion de aria-live segun severidad (rotechos-ui-feedback.js):
    // errores y warns interrumpen al lector de pantalla (assertive + role=alert,
    // patron equivalente al #endstopOverlay de rotechos.js:121-127). ok/info
    // esperan turno (polite + role=status). aria-atomic=true fija en el HTML
    // (index.html:1886) para que el SR lea el bloque entero en cada cambio.
    (el.setAttribute('aria-live', tipo === 'err' || tipo === 'warn' ? 'assertive' : 'polite')),
    (el.setAttribute('role', tipo === 'err' || tipo === 'warn' ? 'alert' : 'status')),
    (el._t = setTimeout(() => {
      el.className = 'toast';
      el._t = null;
      toastActivo = false;
      toastActivoTipo = null;
      drainQueue();
    }, dur))
  );
}

function toast(msg, tipo, key) {
  // PRIORIDAD DE LO URGENTE (2026-08-21). La cola FIFO de HALLAZGO-18 arreglo
  // que los avisos se pisaran, pero creo un problema peor: un ERROR podia
  // quedarse esperando detras de un informativo. El caso real medido es el
  // arranque — el toast "Conectado a RotechOS" dura 2500 ms — y durante esa
  // ventana el operario pulsaba una accion, fallaba, y no veia el error hasta
  // 2,4 s despues. e2e-robustez-percibida-matriz (F2 y F4) exige que un
  // "Error: M6" se vea en MENOS de 800 ms desde el click; medido antes de este
  // cambio: 2444 ms y 1979 ms.
  //
  // Ahora un err/warn interrumpe a un ok/info en curso y se muestra ya. Entre
  // ellos NO se pisan: si lo que se esta mostrando ya es err o warn, el nuevo
  // espera su turno como hasta ahora. El informativo interrumpido se descarta,
  // no se reencola: reaparecer despues del error confundiria mas que ayudar.
  //
  // Es coherente con lo que el propio modulo ya declaraba para accesibilidad:
  // err y warn salen con aria-live=assertive y role=alert porque "interrumpen
  // al lector de pantalla". No tenia sentido anunciarlos como urgentes y a la
  // vez hacerlos esperar en la cola.
  //
  // HUECO-4: un toast de reconexión desplaza al "Conexión perdida" que ya no es
  // verdad, esté en pantalla o en cola. Es la única excepción a que err y warn
  // no se pisan entre ellos.
  const isRestoreKey = key === 'msg.connRestored' || key === 'msg.connRestoredMicro';
  if (isRestoreKey) {
    // Sin la clave del toast activo, el "perdida" se reconoce por su texto (ES o EN).
    if (toastActivo && toastActivoTipo === 'warn') {
      const _activeTxt = $('toastMsg')?.textContent || '';
      if (/Conexi\u00f3n perdida|Lost UI connection/i.test(_activeTxt)) {
        const el = $('toast');
        if (el && el._t) { clearTimeout(el._t); el._t = null; }
        toastActivo = false;
        toastActivoTipo = null;
      }
    }
    // Barrer los "perdida" encolados en una sola asignación y sin bucle con
    // índice: la mutación de robustez-percibida-c-fix.test.js busca el bucle
    // de HUECO-1 y no debe tocar este bloque.
    const _filtered = pendingToasts.filter(
      (_t) => !/Conexi\u00f3n perdida|Lost UI connection/i.test(_t.msg || ''),
    );
    pendingToasts.length = 0;
    pendingToasts.push(..._filtered);
  }
  const urgente = tipo === 'err' || tipo === 'warn';
  const cediendo = toastActivo && (toastActivoTipo === 'ok' || toastActivoTipo === 'info');
  if (urgente && cediendo) {
    const el = $('toast');
    if (el && el._t) { clearTimeout(el._t); el._t = null; }
    toastActivo = false;
    toastActivoTipo = null;
    // HUECO-1 (t_e558a603, C-FIX 2026-09-07): descartar TAMBIEN los ok/info que
    // esperaban en la cola, no solo el que estaba en pantalla.
    //
    // Medido en `docs/dev/hallazgos/2026-09-06_C-robustez-percibida.md` (S1): el
    // operario oye «conexion perdida» a los 265 ms y «conexion inestable» a los
    // 3465 ms — al reves de la progresion real. La diferencia son 3200 ms
    // EXACTOS, que es `TCONF.warn`: el «inestable» no se genero tarde, se genero
    // a tiempo, se quedo en la cola detras del «Conectado a RotechOS» (ok,
    // 2800 ms), y salio cuando el «perdida» agoto su turno.
    //
    // La regla de arriba (2026-08-21) ya decia que «el informativo interrumpido
    // se descarta, no se reencola: reaparecer despues del error confundiria mas
    // que ayudar». Se aplicaba solo al que estaba EN PANTALLA; los que estaban
    // en la cola sobrevivian y reaparecian igual. Mismo motivo, mismo trato.
    //
    // Solo se descartan ok/info: entre err y warn no se pisan (ver arriba), y un
    // error en cola nunca es ruido — puede ser el unico aviso de que una
    // operacion distinta tambien fallo.
    for (let i = pendingToasts.length - 1; i >= 0; i--) {
      const p = pendingToasts[i].tipo;
      if (p === 'ok' || p === 'info') pendingToasts.splice(i, 1);
    }
    pendingToasts.unshift({ msg, tipo });
    drainQueue();
    return;
  }
  // HUECO-1, segunda via (t_e558a603): la rama de arriba solo actua si hay un
  // ok/info EN PANTALLA. Si la pantalla esta libre pero quedan ok/info
  // ESPERANDO en la cola, un urgente se ponia detras de ellos y volvia a
  // salir en orden invertido — el mismo sintoma por otro camino. Un urgente
  // nunca espera detras de un informativo: se descartan y pasa delante.
  if (urgente && pendingToasts.some((p) => p.tipo === 'ok' || p.tipo === 'info')) {
    for (let i = pendingToasts.length - 1; i >= 0; i--) {
      const p = pendingToasts[i].tipo;
      if (p === 'ok' || p === 'info') pendingToasts.splice(i, 1);
    }
    pendingToasts.unshift({ msg, tipo });
    drainQueue();
    return;
  }
  pendingToasts.push({ msg, tipo });
  drainQueue();
}
window.toast = toast;

// ---
// BLOQUE 53 — INDICADOR "MODIFICADO SIN GUARDAR" en pestañas de config
// ---
(function () {
  const dirtyTabs = new Set();

  function markCurrentTabDirty() {
    const activeTab = $q('.mcfg-tab[data-tab].active');
    if (!activeTab) return;
    const key = activeTab.dataset.tab;
    // Pestañas que no requieren guardado a config.g — no marcar como dirty
    const NON_PERSISTENT = ['about', 'macros', 'guide', 'pines', 'ota', 'viz3d', 'wizard', 'jobhistory', 'keyboard', 'backup'];
    if (NON_PERSISTENT.includes(key)) return;
    if (!dirtyTabs.has(key)) {
      dirtyTabs.add(key);
      activeTab.classList.add('dirty');
    }
  }

  function clearAllDirty() {
    $$('.mcfg-tab.dirty').forEach(t => t.classList.remove('dirty'));
    dirtyTabs.clear();
  }

  // Listener delegado: cualquier cambio en input/select/checkbox dentro del modal de config marca dirty
  const modal = $('machineConfigModal');
  if (modal) {
    modal.addEventListener('change', (e) => {
      // El selector de idioma es preferencia de UI, NO config de máquina: no debe
      // marcar la pestaña como "sin guardar" ni disparar la cadena de reinicio.
      if (e.target.id === 'langSelect') return;
      if (e.target.matches('input, select, textarea')) markCurrentTabDirty();
    });
    modal.addEventListener('input', (e) => {
      if (e.target.matches('input[type="text"], input[type="number"], textarea')) markCurrentTabDirty();
    });
  }

  function clearTabDirty(key) {
    dirtyTabs.delete(key);
    $q(`.mcfg-tab[data-tab="${key}"]`)?.classList.remove('dirty');
  }
  // 15-sep: la pestaña guardada se limpia al confirmarse el guardado
  // (rotechos-config-modal.js llama a mcfgDirtyClearTab). El temporizador queda de
  // respaldo y solo para ESA pestaña: antes limpiaba todas a los 1,5 s, y editar otra
  // pestaña dentro de esa ventana lo cancelaba, así que cerrar avisaba de cambios
  // «sin guardar» que ya estaban guardados.
  AppState.ui.mcfgDirtyClearTab = clearTabDirty;
  $('btnMcfgApply')?.addEventListener('click', () => {
    const key = $q('.mcfg-tab[data-tab].active')?.dataset.tab;
    if (key) setTimeout(() => clearTabDirty(key), 1500);
  });

  // Avisar al cerrar el modal si hay cambios sin guardar. 15-sep: con el diálogo de
  // la interfaz (antes confirm() nativo, sin estilo ni traducción). Si se acepta, se
  // limpian las marcas y se repite el clic: cierra por el camino de siempre.
  $('btnMcfgClose')?.addEventListener('click', (e) => {
    if (!dirtyTabs.size) return;
    e.stopImmediatePropagation();
    const tr = (k, f) => (typeof t === 'function' ? t(k, f) : f);
    const cuerpo = `${tr('dlg.unsavedClose.msg', 'Tienes cambios sin guardar en')}: <b>${[...dirtyTabs].join(', ')}</b>. ${tr('dlg.unsavedClose.q', '¿Cerrar igualmente y descartarlos?')}`;
    const pedir = typeof confirmDialog === 'function'
      ? confirmDialog(tr('dlg.unsavedClose.title', 'Cambios sin guardar'), cuerpo)
      : Promise.resolve(confirm(cuerpo.replace(/<[^>]+>/g, '')));
    pedir.then((ok) => {
      if (!ok) return;
      clearAllDirty();
      $('btnMcfgClose')?.click();
    });
  }, true);

  // También limpiar tras recarga inicial del config
  // (rotechos-config-modal.js:1899 lo llama tras cfgPopulate: typeof
  // AppState.ui.mcfgDirtyClear === 'function' && AppState.ui.mcfgDirtyClear())
  AppState.ui.mcfgDirtyClear = clearAllDirty;
})();

// ── POR QUE NO PUEDO PULSAR ESTO ──────────────────────────────────────────
// El analista OJO-2 recorrio la interfaz como un novato y encontro que pulsar
// INICIAR TRABAJO sin archivo cargado **no dice absolutamente nada**: el boton
// esta `disabled`, el navegador se traga el clic y no pasa nada. El usuario
// concluye que el boton esta roto.
//
// La unica explicacion que habia era el `title` del boton, y decia "Bloqueado
// en estado IDLE": jerga que un novato no entiende, y ademas invisible en movil,
// que es donde no hay raton con el que pasar por encima.
//
// Esto se resuelve una vez para todos los botones de accion, no boton a boton:
// un oyente en fase de CAPTURA ve el clic aunque el destino este deshabilitado
// —los elementos disabled no emiten click, pero el evento si viaja por el arbol
// hasta el punto de impacto— y explica el motivo en el lenguaje del usuario.
//
// Criterio para no convertir esto en una lluvia de avisos: solo se avisa de los
// botones de ACCION principales, y con una ventana anti-repeticion, para que
// aporrear un boton no llene la pantalla de toasts iguales.
(function porQueNoPuedoPulsar() {
  if (typeof document === 'undefined') return;

  const ACCIONES = '.exec-action-btn, .qa-btn, .pendant2-act-btn, .fc-act, .wcs-btn';
  let ultimoAviso = { id: null, at: 0 };

  // El motivo se dice en castellano llano: que falta y donde se consigue.
  // Un mensaje que dice lo que falta sin decir donde arreglarlo esta a medias.
  function motivoDe(btn) {
    const id = btn.id || '';
    const tr = (k, f) => (typeof t === 'function' ? t(k, f) : f);

    if (id === 'btnPlayPause') {
      const hayArchivo = !!(typeof AppState !== 'undefined' && AppState.job && AppState.job.file);
      if (!hayArchivo) return tr('msg.porQue.sinArchivo',
        'No hay ningún archivo cargado. Abre ARCHIVOS y elige un G-code.');
      return tr('msg.porQue.noListo',
        'La máquina todavía no está lista para cortar. Mira el estado, arriba.');
    }
    if (id === 'btnSpindle') return tr('msg.porQue.spindle',
      'El husillo no se puede accionar ahora mismo. Comprueba el estado de la máquina.');
    if (/home/i.test(id)) return tr('msg.porQue.sinConexion',
      'Sin conexión con la máquina. Comprueba el cable o el WiFi.');

    // Para el resto: si el title trae algo legible, se usa; si no, un motivo generico.
    const ti = (btn.title || '').trim();
    const esJerga = !ti || /^Bloqueado en estado/i.test(ti);
    return esJerga
      ? tr('msg.porQue.generico', 'Esta acción no está disponible en este momento.')
      : ti;
  }

  document.addEventListener('click', (ev) => {
    // El evento NUNCA tiene como destino el boton bloqueado —el navegador lo
    // suprime ahi— asi que se busca por COORDENADAS: cual de los botones
    // apagados y visibles ocupa el punto donde se ha pulsado.
    let btn = null;
    const bloqueados = document.querySelectorAll(
      ACCIONES.split(', ').map((s) => s + ':disabled').join(', ') + ', [aria-disabled="true"]'
    );
    for (const b of bloqueados) {
      const r = b.getBoundingClientRect();
      if (r.width < 1 || r.height < 1) continue;
      if (ev.clientX >= r.left && ev.clientX <= r.right && ev.clientY >= r.top && ev.clientY <= r.bottom) { btn = b; break; }
    }
    if (!btn) return;

    const ahora = Date.now();
    if (ultimoAviso.id === (btn.id || 'anon') && ahora - ultimoAviso.at < 3000) return;
    ultimoAviso = { id: btn.id || 'anon', at: ahora };

    if (typeof window.toast === 'function') window.toast(motivoDe(btn), 'warn');
  }, true);   // captura: el clic sobre un disabled no burbujea, pero si baja
})();

// ---
// BLOQUE 54 — ESTADOS VISUALES DE CAMPO (t_8cc28493 FASE 3.1)
//   .f-inherited  → valor heredado del perfil/de fábrica
//   .f-dirty      → modificado y aún no persistido
//   .f-invalid    → valor fuera de rango / formato incorrecto
//
// POR QUÉ AQUI Y NO EN UN FICHERO NUEVO
//   Este módulo ya centraliza feedback visual efímero del modal de
//   configuración (toasts + dirty de pestañas). Los tres estados nuevos
//   son del mismo dominio — feedback visual persistente del modal — y
//   reutilizan `markCurrentTabDirty` (sincronizar tab dirty ↔ field dirty)
//   y `AppState.ui.mcfgDirtyClear` (limpieza post-guardado).
//
// POR QUÉ listeners DELEGADOS, NO POR CAMPO
//   El modal tiene >50 inputs (mcfgM92{X,Y,Z,A} + mcfgM203 + mcfgM201 +
//   mcfgM566 + mcfgSl{X,Y,Z}{0,1} + endstops + sensor + spindle + sac + …).
//   Un listener delegado en #machineConfigModal cubre los 50 con un
//   solo addEventListener y un solo closure de captura. Mismo patron
//   que el bloque 53 (dirty tabs) — un set + cambio = clase.
//
// QUE PASA CON LOS CAMPOS BLOQUEADOS (:disabled / [readonly])
//   El listener los ignora: si el campo está deshabilitado, el navegador
//   no emite eventos de cambio. Para los readonly (pins de endstops)
//   tampoco aplica — son fijos y nunca los toca el operario.
// ---
(function fieldStates() {
  if (typeof document === 'undefined') return;

  // ── API expuesta en AppState.ui (consumida por rotechos-config-modal.js) ──
  // Esto evita imports circulares: el configurador conoce estos nombres
  // pero no necesita importar este módulo directamente. Patrón idéntico
  // a `mcfgDirtyClear` (bloque 53).
  const api = {
    /**
     * Marca un campo como heredado del perfil/fábrica. El valor se puso
     * solo porque cfg.g NO contenía esa línea. Se quita al persistir.
     * @param {HTMLElement} el - input/select/textarea
     */
    markInherited(el) {
      if (!el || !el.classList) return;
      el.classList.add('f-inherited');
      el.dataset.fInherited = '1';
    },
    /** Quita la marca de heredado (el operario va a persistir el valor). */
    clearInherited(el) {
      if (!el || !el.classList) return;
      el.classList.remove('f-inherited');
      delete el.dataset.fInherited;
    },
    /**
     * Marca un campo como invalido. El caller ya conoce el mensaje —
     * aqui solo aplicamos la pista visual (clase CSS).
     */
    markInvalid(el) {
      if (!el || !el.classList) return;
      el.classList.add('f-invalid');
    },
    clearInvalid(el) {
      if (!el || !el.classList) return;
      el.classList.remove('f-invalid');
    },
    /**
     * Marca un campo como pendiente de guardar. Lo usa el listener
     * delegado de abajo, y también cfgPopulate cuando detecta que el
     * valor en UI diverge del persistido en disco.
     */
    markDirty(el) {
      if (!el || !el.classList) return;
      el.classList.add('f-dirty');
      el.dataset.fDirty = '1';
    },
    clearDirty(el) {
      if (!el || !el.classList) return;
      el.classList.remove('f-dirty');
      delete el.dataset.fDirty;
    },
    /**
     * Limpia los 3 estados a la vez. Lo llama clearAllDirty() del
     * bloque 53 (que ya se dispara al pulsar btnMcfgApply).
     */
    clearAllFieldStates() {
      document.querySelectorAll('#machineConfigModal .in-txt.f-dirty, #machineConfigModal .in-txt.f-invalid, #machineConfigModal .in-txt.f-inherited')
        .forEach((el) => {
          el.classList.remove('f-dirty', 'f-invalid', 'f-inherited');
          delete el.dataset.fDirty;
          delete el.dataset.fInherited;
        });
    },
    /**
     * Devuelve el resumen de campos pendientes/invalidos. Lo usa el
     * configurador antes de Guardar — si hay invalidos, BLOQUEA el
     * guardado (validación dura).
     */
    summary() {
      const dirty = document.querySelectorAll('#machineConfigModal .in-txt.f-dirty').length;
      const invalid = document.querySelectorAll('#machineConfigModal .in-txt.f-invalid').length;
      return { dirty, invalid };
    },
  };

  // Publicar en AppState.ui (mismo patrón que el bloque 53)
  if (typeof AppState !== 'undefined' && AppState.ui) {
    AppState.ui.fieldMarkInherited = api.markInherited;
    AppState.ui.fieldClearInherited = api.clearInherited;
    AppState.ui.fieldMarkInvalid = api.markInvalid;
    AppState.ui.fieldClearInvalid = api.clearInvalid;
    AppState.ui.fieldMarkDirty = api.markDirty;
    AppState.ui.fieldClearDirty = api.clearDirty;
    AppState.ui.fieldClearAll = api.clearAllFieldStates;
    AppState.ui.fieldStatesSummary = api.summary;
  }
  // Tambien en window para tests unit (sin AppState)
  if (typeof window !== 'undefined') {
    window.fieldStates = api;
  }

  // ── Listener delegado: input/change marca el campo como dirty ──────────
  // Mismo modal que el bloque 53 (#machineConfigModal), pero este SÍ cubre
  // TODOS los inputs editables (mcfg-num, mcfg-pin-editables, selects, etc.)
  // — los del bloque 53 solo marcaban la pestaña. Aqui marcamos el campo.
  const modal = document.getElementById('machineConfigModal');
  if (modal) {
    // Enganche 'change' (selects y checkboxes emiten change, no input)
    modal.addEventListener('change', (e) => {
      const el = e.target;
      if (!el || !el.matches) return;
      if (!el.matches('input, select, textarea')) return;
      // No marcar campos bloqueados (defensa adicional; el navegador
      // ya filtra eventos sobre :disabled, pero [readonly] los emite).
      if (el.disabled || el.readOnly) return;
      // No marcar el selector de idioma — igual que el bloque 53
      if (el.id === 'langSelect') return;
      api.markDirty(el);
    });
    // Enganche 'input' (typing en text/number/textarea)
    modal.addEventListener('input', (e) => {
      const el = e.target;
      if (!el || !el.matches) return;
      if (!el.matches('input[type="text"], input[type="number"], textarea')) return;
      if (el.disabled || el.readOnly) return;
      if (el.id === 'langSelect') return;
      api.markDirty(el);
    });
  }

  // ── Limpieza al guardar (coordina con clearAllDirty de bloque 53) ─────
  // El botón btnMcfgApply ya dispara clearAllDirty en su setTimeout(1500).
  // Aquí ampliamos la limpieza: ademas de la pestaña, quitamos f-dirty /
  // f-invalid / f-inherited de todos los inputs del modal. Se ejecuta
  // en el mismo setTimeout para que el orden visual sea: persist OK →
  // 1500ms → limpieza total.
  const btnApply = document.getElementById('btnMcfgApply');
  if (btnApply) {
    btnApply.addEventListener('click', () => {
      // El bloque 53 ya programa su clearAllDirty en 1500 ms; este cleanup
      // se engancha al mismo ciclo para mantener el orden de cascada.
      setTimeout(() => api.clearAllFieldStates(), 1500);
    });
  }

  // ── Limpieza al cerrar el modal (mismo cleanup que al guardar) ────────
  // El bloque 53 ya avisa "cambios sin guardar" antes de cerrar. Aqui
  // aseguramos que, si el operario cierra con OK, tambien se limpian
  // los estados visuales (siguiente apertura = sin ruido).
  const btnClose = document.getElementById('btnMcfgClose');
  if (btnClose) {
    btnClose.addEventListener('click', () => {
      // Diferir: el confirm() es síncrono y bloqueante; el cierre efectivo
      // ocurre despues del confirm. 50 ms es suficiente para que el confirm
      // haya terminado sin afectar al usuario.
      setTimeout(() => {
        if (!document.getElementById('machineConfigModal').classList.contains('show')) {
          api.clearAllFieldStates();
        }
      }, 50);
    });
  }
})();
