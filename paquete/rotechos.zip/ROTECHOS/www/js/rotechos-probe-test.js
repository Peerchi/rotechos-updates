// Prueba manual de contacto: lógica pura, sin DOM, red ni comandos de máquina.
(function (root) {
  'use strict';
  const DURATION_MS = 10000;

  function contact(value) {
    const v = Array.isArray(value) ? value[0] : value;
    return typeof v === 'number' && Number.isFinite(v) ? v > 0 : null;
  }

  // El operario debe dejar el pulsador libre ANTES de iniciar la prueba.
  function start(value, now) {
    const pressed = contact(value);
    return {
      status: pressed === null ? 'unavailable' : pressed ? 'inverted' : 'waiting',
      deadline: now + DURATION_MS,
    };
  }

  function sample(state, value, now) {
    if (state.status !== 'waiting') return state;
    if (now >= state.deadline) return { ...state, status: 'timeout' };
    const pressed = contact(value);
    if (pressed === null) return { ...state, status: 'unavailable' };
    return pressed ? { ...state, status: 'ok' } : state;
  }

  const api = { DURATION_MS, contact, start, sample };
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.ROTECHOS_PROBE_TEST = api;
})(typeof window === 'undefined' ? globalThis : window);
