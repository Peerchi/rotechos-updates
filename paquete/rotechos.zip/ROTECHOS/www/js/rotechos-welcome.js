/* ---
 * rotechos-welcome.js — Defer module: wizard de bienvenida (WLC).
 *
 * Sprint 6 fase 2 del programa de reducción del monolito. Saca de rotechos.js
 * el cuerpo REAL del wizard de bienvenida: el objeto `WLC` (show/lang/finish) y
 * la IIFE `initWelcome` que lo dispara en primer arranque si
 * localStorage 'rotechos-welcomed' está vacío.
 *
 * Notas de la extracción (no las deshagas sin releer el contrato en
 * tests/e2e-primer-arranque-wifi.spec.js, que es la especificación):
 *
 *  - Solo se extrae WLC + initWelcome. La función `_maybeShowFirstBootWizard`
 *    (rotechos.js) SE QUEDA en el monolito: depende de SM, _fetchModel,
 *    _unwrap y LOG, no del DOM de bienvenida, y se invoca DESDE el monolito
 *    (rotechos.js:3324, tras `await RRF.connect()`). Mantenerla fuera evita
 *    tener que inyectar medio shell en este fichero.
 *
 *  - Orden de arranque: este defer module se carga ANTES de rotechos.js
 *    (registrado en index.html entre rotechos-config-persist.js y rotechos.js).
 *    Cuando rotechos.js ejecuta la IIFE initWelcome en su antigua línea 4140,
 *    `WLC` ya está en window. Si se moviese este módulo a un defer POST-shell,
 *    initWelcome se evaluaría antes de que WLC exista y `WLC.show(1)` lanzaría
 *    ReferenceError — bug latente que el e2e-primer-arranque-wifi.spec.js
 *    detectaría como "el welcomeModal nunca aparece".
 *
 *  - STORE y $/$$ los expone rotechos-storage.js y rotechos-dom.js, cargados
 *    también antes de rotechos.js. La IIFE initWelcome los consume en cuanto
 *    corre, así que esos dos defer modules deben preceder a este.
 *
 *  - El checkbox `wlcSchool` (index.html:2427) y el badge `#schoolModeBadge`
 *    (rotechos.js) son DOM global; WLC.finish() los toca si están, pero no
 *    asume que existan (chequeos `?.` y `if (sc && sc.checked)`). Idéntico al
 *    original.
 * --- */
'use strict';

const WLC = {
  show(n) {
    // dataset.step es string, == coer defensivo (WLC.show recibe n numerico)
    $$(`#welcomeModal .wlc-step`).forEach((s) => {
      // eslint-disable-next-line eqeqeq
      s.style.display = s.dataset.step == n ? `` : `none`;
    });
  },
  lang(l) {
    try { window.I18N && I18N.setLang(l); } catch {}
    this.show(2);
  },
  // Volver a ver la bienvenida. OJO-2 (t_53a57af3) encontro que se lanzaba UNA
  // sola vez y que despues no habia forma de recuperarla sin abrir la consola
  // del navegador y borrar `wizard.welcomed` a mano. Quien la salto el primer
  // dia —o quien recibe la maquina de segunda mano— se quedaba sin ella para
  // siempre, y son justo los tres pasos que explican PARO, JOG, CEROS y el
  // orden de la primera puesta en marcha.
  // No borra la marca de vista: solo vuelve a enseñarla. Asi no reaparece sola
  // en el siguiente arranque.
  reabrir() {
    const m = $(`welcomeModal`);
    if (!m) return false;
    this.show(1);
    m.classList.add(`show`);
    m.removeAttribute(`data-user-interacted`);
    return true;
  },
  finish() {
    STORE.set(`wizard.welcomed`, true);
    // B2-BIS: marcar interacción del usuario para que _maybeShowFirstBootWizard
    // no re-abra el modal si llega tarde un fetch con firstBootCompleted=true.
    $(`welcomeModal`)?.setAttribute(`data-user-interacted`, `true`);
    // Modo escuela si el operario lo dejó marcado (usa el toggle propio del badge)
    const sc = $(`wlcSchool`);
    if (sc && sc.checked && !document.body.classList.contains(`school-mode`))
      $(`schoolModeBadge`)?.click();
    $(`welcomeModal`)?.classList.remove(`show`);
  },
};
window.WLC = WLC;

// initWelcome se ejecuta al cargar el módulo. Se coloca DESPUÉS de la creación
// de WLC para garantizar que, si llega un fetch con firstBootCompleted=true
// (manejado por _maybeShowFirstBootWizard, que sigue en rotechos.js y se
// invoca tras `await RRF.connect()` en el IIFE de arranque), `WLC` ya esté
// en window.
(function initWelcome() {
  const seen = STORE.get(`wizard.welcomed`);
  if (!seen) {
    WLC.show(1);
    $(`welcomeModal`)?.classList.add(`show`);
  }
})();
// El boton vive en la pestaña PRIMER ARRANQUE del modal de configuracion, que
// es donde alguien iria a buscarlo. Se engancha en cuanto existe: el panel se
// construye con el modal, asi que puede no estar en el DOM al cargar el modulo.
(function engancharReabrir() {
  // Los unitarios cargan este modulo con un `document` simulado que NO trae
  // getElementById: comprobar solo que existe `document` no basta, hay que
  // comprobar la funcion concreta que se va a usar.
  if (typeof document === 'undefined' || typeof document.getElementById !== 'function') return;
  const enganchar = () => {
    const b = document.getElementById('btnReabrirBienvenida');
    if (!b || b.dataset.enganchado) return !!b;
    b.dataset.enganchado = '1';
    b.addEventListener('click', () => {
      const ok = window.WLC && window.WLC.reabrir && window.WLC.reabrir();
      if (!ok && typeof window.toast === 'function') {
        window.toast('No se pudo abrir la bienvenida', 'err');
      }
    });
    return true;
  };
  if (!enganchar()) {
    if (typeof document.addEventListener === 'function')
      document.addEventListener('DOMContentLoaded', enganchar, { once: true });
    // y por si el panel se monta mas tarde, un reintento acotado
    let intentos = 0;
    const iv = setInterval(() => { if (enganchar() || ++intentos > 20) clearInterval(iv); }, 500);
  }
})();
