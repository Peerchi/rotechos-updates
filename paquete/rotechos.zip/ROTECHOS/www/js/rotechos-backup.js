// ---
// rotechos-backup.js — MÓDULO: BACKUP / RESTORE (tab Backup de Configuración)
// ---
// Extraído de rotechos.js (jul-2026, extracción #1 del roadmap) SIN cambios
// de lógica. Escanea /sys y /macros de la SD (rr_filelist), los descarga
// (rr_download) y los empaqueta en un ZIP sin compresión (método STORE:
// crc32 + local headers + central directory + EOCD) generado a mano — sin
// librerías. Restore: drag&drop de un .zip, parseZip byte a byte y subida
// con rr_upload + reinicio del firmware (M999) tras confirmación.
//
// Dependencias en runtime (todas globales, resueltas por orden de defer;
// este archivo carga DESPUÉS de rotechos.js — ver index.html):
//   - rotechos-dom.js  → $()
//   - rotechos-i18n.js → t()
//   - rotechos.js      → _fetchRRF, TARGET_IP, toast, log, escHtml,
//                        setupDragAndDrop, confirmDialog, RRF
//
// No exporta nada: toda la API queda privada a la IIFE (los botones y el
// tab se cablean aquí con addEventListener). Por eso no hay /* exported */.
//
// ⚠️ tests/unit/backup-zip.test.js extrae crc32/buildSimpleZip/parseZip/…
//    por regex anclada a la indentación de 4 espacios del cuerpo: si
//    reindentas este archivo, actualiza el anclaje del test.
// ---
(function () {
    const BACKUP_DIRS = [`0:/sys`, `0:/macros`];
    // Ficheros que NUNCA entran en un backup (hallazgo F8 H-8-02, jul-2026):
    // wifi-passwords.g vive en 0:/sys y guarda el SSID y la contraseña del WiFi
    // del cliente EN CLARO (M552/M587). Sin este filtro, el ZIP que el operario
    // manda por correo a soporte o guarda en un pendrive lleva dentro las
    // credenciales de su red. El cliente las vuelve a introducir a mano tras un
    // restore; es la práctica habitual (DWC hace lo mismo).
    const BACKUP_EXCLUIDOS = /^(wifi-passwords|saved_position)(\.|$)/i; // 15-sep: una posición vieja aplicaba un G92 falso
    // Nombres cortos para mostrar en la UI de "qué se EXCLUYE" — el cliente
    // debe ver ANTES de pulsar Descargar que sus credenciales NO viajan en el
    // ZIP. Si en el futuro BACKUP_EXCLUIDOS crece, este listado es lo que el
    // operario ve en pantalla: no son archivos "secretos" sino archivos
    // EXCLUIDOS (no se incluye la password, no se incluye la configuración
    // personal). Lista sincronizada a mano con el regex (la alternativa era
    // probar el regex con cada nombre de /sys y /macros: frágil y opaco).
    const BACKUP_EXCLUIDOS_NOMBRES = [`sys/wifi-passwords.g`];
    /**
     * Pinta en #backupManifest un resumen de lo que contendrá el ZIP ANTES de
     * que el operario pulse Descargar. Fase 4.10 (t_c56fb349): el manifiesto
     * ya existía como metadata.json DENTRO del ZIP, pero el usuario no lo
     * veía — el botón era "Descargar backup.zip" a ciegas. Ahora se expone
     * lo mismo que luego vivirá dentro del ZIP:
     *   - Identidad de la máquina (machineName)
     *   - Fecha de generación
     *   - Número de archivos
     *   - Versión de la UI (ROTECHOS_VERSION)
     *   - Aviso verde: NO incluye credenciales WiFi (BACKUP_EXCLUIDOS)
     *   - Aviso amarillo: subcarpetas no se incluyen (BACKUP_DIRS solo raíz)
     * Si la identidad no se pudo resolver, se muestra "desconocida" en
     * lugar de fallar en silencio — la práctica del manifest original.
     */
    async function renderBackupManifest(numArchivos, fecha) {
      const el = $(`backupManifest`);
      if (!el) return;
      let machineName = ``;
      try {
        // t_b8cd40c2: `_machineNameFrom` vive en el modal de CONFIGURACION, que
        // ahora es PEREZOSO. Sin asegurar su carga, la identidad salia
        // «desconocida» siempre que el operario no hubiera abierto CONFIGURACION
        // en esa sesion — y en el dialogo de restore esa identidad es la
        // salvaguarda que le dice si esta restaurando en la maquina correcta.
        try { await window.__ensureConfigModal?.(); } catch (_) { /* el typeof decide */ }
        if (typeof window._machineNameFrom === `function` &&
            typeof cfgRead === `function` && typeof cfgMachineRead === `function`)
          machineName = window._machineNameFrom(await cfgRead(), await cfgMachineRead());
      } catch (e) { LOG.warn(`renderBackupManifest: no se pudo resolver la identidad:`, e); }
      const version = (typeof window.ROTECHOS_VERSION === `string` ? window.ROTECHOS_VERSION : `desconocida`);
      const esc = (s) => (typeof escHtml === `function` ? escHtml(s) : String(s ?? ``));
      const fmtFecha = (iso) => {
        try {
          const d = new Date(iso);
          if (isNaN(d.getTime())) return iso;
          return d.toLocaleString(`es-ES`);
        } catch { return iso; }
      };
      const avisoSinCredenciales = t(
        `cfg.backup.manifest.noCredentials`,
        `<span style="color:var(--green-strong)">✓ Este backup NO incluye tus contraseñas WiFi (<code>sys/wifi-passwords.g</code>). Puedes compartirlo sin filtrar tu red.</span>`,
      );
      const avisoSinSubcarpetas = t(
        `cfg.backup.manifest.noSubdirs`,
        `<span style="color:var(--yellow)">⚠ Solo se exportan archivos en la raíz de <code>0:/sys</code> y <code>0:/macros</code>. Los archivos en subcarpetas y los listados a continuación NO entran al ZIP:</span>`,
      );
      const excluidosHtml = BACKUP_EXCLUIDOS_NOMBRES.map(
        (n) => `<div style="color:var(--text-3);font-family:var(--mono,monospace);font-size:11px">· ${esc(n)}</div>`,
      ).join(``);
      el.innerHTML = `
        <div style="border:1px solid var(--border);border-radius:8px;background:var(--bg-card);padding:10px 12px;margin-bottom:10px;font-size:11px;line-height:1.6">
          <div style="text-transform:uppercase;color:var(--text-3);letter-spacing:.6px;font-size:10px;font-weight:700;margin-bottom:6px">${esc(t(`cfg.backup.manifest.hdr`, `Resumen del backup (lo que contendrá el ZIP)`))}</div>
          <div>${esc(t(`cfg.backup.manifest.machine`, `Máquina`))}: <strong>${esc(machineName || `desconocida`)}</strong></div>
          <div>${esc(t(`cfg.backup.manifest.date`, `Fecha`))}: ${esc(fmtFecha(fecha))}</div>
          <div>${esc(t(`cfg.backup.manifest.files`, `Archivos`))}: <strong>${numArchivos}</strong></div>
          <div>${esc(t(`cfg.backup.manifest.uiVersion`, `Versión UI`))}: ${esc(version)}</div>
          <div style="margin-top:6px">${avisoSinSubcarpetas}${excluidosHtml}</div>
        </div>`;
      // El aviso de privacidad va FUERA de #backupManifest a proposito.
      // Esa caja lleva un tope de 90 px (clase `.fm-code`, compartida con la
      // lista de ficheros) y el resumen pide 192: el aviso caia 29 px por
      // debajo del borde visible y no se pintaba — es el hallazgo H7 de la
      // auditoria visual del 20-sep. Levantarle el tope a la caja tambien lo
      // arreglaba, pero estiraba el panel 91 px y ponia rojo gate_sin_scroll
      // (`1280x720 escuela cfg/backup +16px`), asi que sale solo el aviso.
      const priv = $(`backupPrivacidad`);
      if (priv) priv.innerHTML = avisoSinCredenciales;
    }
    async function loadBackupTab() {
      const listEl = $(`backupFileList`);
      const btn = $(`btnBackupExport`);
      const lbl = $(`btnBackupExportLabel`);
      // t_b68324ca (sep-2026): el botón se DESHABILITA por defecto. loadBackupTab
      // lo rehabilita SÓLO si encuentra archivos reales en /sys y /macros. Antes
      // de este parche, el botón quedaba habilitado a ciegas — un operario que
      // pulsaba Descargar con "Archivos: 0" se llevaba un ZIP con SOLO
      // metadata.json (la cabecera de identidad), aunque el toast del filename
      // decía "Backup exportado — 0 archivos". El backup es el SEGURO del
      // operario: viene aquí precisamente cuando teme perder algo, y un ZIP
      // vacío que parece éxito es peor que no hacer nada.
      const _noFilesLbl = t(
        `cfg.backup.btn.export.empty`,
        `Sin archivos que respaldar`,
      );
      const _setEmpty = () => {
        if (btn) btn.disabled = true;
        if (lbl) {
          lbl.textContent = _noFilesLbl;
          lbl.setAttribute(`aria-disabled`, `true`);
        }
      };
      if (btn) btn.disabled = true;
      if (lbl) lbl.textContent = t(`msg.loading`, `Cargando…`);
      listEl.innerHTML = `Escaneando archivos…`;
      try {
        const files = [];
        for (const dir of BACKUP_DIRS)
          (await _fileList(dir, 15000)).files.forEach((f) => {
            f.type === `f` &&
              !BACKUP_EXCLUIDOS.test(f.name) &&
              files.push(`${dir}/${f.name}`);
          });
        ((listEl.innerHTML =
          files
            .map((f) => `<div>· ${escHtml(f.replace(`0:/`, ``))}</div>`)
            .join(``) ||
          `<div style="color:var(--text-3)">${t('msg.noFilesFound', 'Sin archivos encontrados')}</div>`),
          (listEl.dataset.files = JSON.stringify(files)),
          renderBackupManifest(files.length, new Date().toISOString()));
        // t_b68324ca: post-resultado. Si hay archivos, rehabilita + label normal.
        // Si no hay, deshabilita + label explicando por qué. El recheck se hace
        // SIEMPRE, incluso si files.length > 0 — el finally de la rama de error
        // puede dejar el botón habilitado si el último loadBackupTab terminó OK
        // y luego la SD se quedó sin archivos (raro pero observable tras un
        // borrado manual).
        if (files.length > 0) {
          if (btn) btn.disabled = false;
          if (lbl) {
            lbl.textContent = `Descargar backup.zip`;
            lbl.removeAttribute(`aria-disabled`);
          }
        } else {
          _setEmpty();
        }
      } catch {
        listEl.innerHTML = `<span style="color:var(--red)">Error al listar archivos</span>`;
        // Si el listado falló, NO se puede saber si hay archivos. Lo más
        // conservador es dejar el botón deshabilitado (el original quedaba
        // habilitado pero al pulsarlo salía "Primero carga el tab", lo que
        // echa la culpa al operario de un fallo nuestro).
        _setEmpty();
      }
    }
    // 2026-08-21: este modulo es de carga PEREZOSA desde el sprint PESO-5 (v160)
    // y quien lo inyecta es, precisamente, el click en la pestana BACKUP
    // (rotechos.js:3378). Cuando llega aqui a registrar el listener, ese click
    // YA HA PASADO: loadBackupTab no se ejecutaba la primera vez. El operario
    // pulsaba BACKUP, veia el panel sin la lista de ficheros, y si le daba a
    // "Descargar backup" recibia "Primero carga el tab para escanear archivos"
    // —un aviso que le echa la culpa de un fallo nuestro—. Solo funcionaba al
    // salir a otra pestana y volver. Se arranca la carga a mano si la pestana
    // ya esta activa en el momento en que el modulo termina de cargar.
    (document
      .querySelector(`.mcfg-tab[data-tab="backup"]`)
      .addEventListener(`click`, loadBackupTab),
      document
        .querySelector(`.mcfg-tab[data-tab="backup"]`)
        ?.classList.contains(`active`) && loadBackupTab(),
      document
        .getElementById(`btnBackupExport`)
        .addEventListener(`click`, async () => {
          const filesRaw =
            $(`backupFileList`).dataset.files;
          if (!filesRaw) {
            toast(t(`msg.noTabFiles`, `Primero carga el tab para escanear archivos`), `warn`);
            return;
          }
          let files;
          try {
            files = JSON.parse(filesRaw);
          } catch {
            toast(t(`msg.fileListErr`, `Error al leer lista de archivos`), `err`);
            return;
          }
          // t_b68324ca (sep-2026): defensa profunda. Aunque el botón debería
          // estar deshabilitado en este caso (loadBackupTab lo gestiona), un
          // re-render o cambio de pestaña puede dejar el dataset.files con
          // un array vacío ANTES de que la nueva lectura acabe. Mejor abortar
          // limpio que descargar un ZIP con SOLO metadata.json (que el toast
          // anunciaría como "Backup exportado — 0 archivos", confuso).
          if (!Array.isArray(files) || files.length === 0) {
            // Mantener el botón deshabilitado + label explicando por qué.
            // SIN este paso, el `finally` del click handler lo rehabilita
            // ciegamente y deja la UI en un estado inconsistente con los
            // datos que vio el operario.
            const _b = $(`btnBackupExport`);
            const _l = $(`btnBackupExportLabel`);
            if (_b) _b.disabled = true;
            if (_l) {
              _l.textContent = t(
                `cfg.backup.btn.export.empty`,
                `Sin archivos que respaldar`,
              );
              _l.setAttribute(`aria-disabled`, `true`);
            }
            toast(
              t(
                `msg.backupNoFiles`,
                `Sin archivos que respaldar — vuelve a pulsar la pestaña para reescanear.`,
              ),
              `warn`,
            );
            return;
          }
          const btn = $(`btnBackupExport`),
            lbl = $(`btnBackupExportLabel`);
          ((btn.disabled = !0), (lbl.textContent = `Descargando archivos…`));
          try {
            const parts = [];
            for (const path of files) {
              lbl.textContent = `Descargando ${path.split(`/`).pop()}…`;
              const r = await RRF.download(path, { timeoutMs: 15000 });
              // Fail-closed: antes se llamaba a .text() SIN mirar r.ok, así que un
              // 404/500 metía el cuerpo del error en el ZIP como si fuera el
              // contenido del archivo, y el toast final anunciaba "Backup
              // exportado — N archivos". El cliente se llevaba un backup con un
              // config.g que en realidad era una página de error, creyendo que
              // tenía su máquina respaldada. Y restaurarlo escribiría eso en la SD.
              // Se aborta el backup ENTERO: uno parcial que no se anuncia como
              // parcial es peor que no tener backup, porque se confía en él.
              if (!r.ok)
                throw Error(
                  t(`msg.noSePudoLeer`, `No se pudo leer `) + path.split(`/`).pop() + ` (HTTP ${r.status})`,
                );
              const text = await r.text();
              parts.push({ path: path.replace(`0:/`, ``), content: text });
            }
            const zipBytes = buildSimpleZip(parts.concat([await buildBackupMetadata(parts.length)])),
              blob = new Blob([zipBytes], { type: `application/zip` }),
              url = URL.createObjectURL(blob),
              a = document.createElement(`a`);
            ((a.href = url),
              (a.download = `rotechos-backup-${new Date().toISOString().slice(0, 10)}.zip`),
              a.click(),
              URL.revokeObjectURL(url),
              toast(t(`msg.backupExportadoPartslengthArchivos`, `Backup exportado — ${parts.length} archivos`, { "parts.length": parts.length }), `ok`),
              log(`Backup exportado: ${parts.length} archivos`, `ok`));
          } catch (e) {
            toast(t(`msg.backupErr`, `Error generando backup: `) + e.message, `err`);
          } finally {
            ((btn.disabled = !1), (lbl.textContent = `Descargar backup.zip`));
          }
        }));
    // Nombre del manifiesto de identidad dentro del ZIP. Vive en la RAÍZ del
    // ZIP (no bajo sys/ ni macros/) precisamente para que NO se confunda con un
    // archivo de la SD: el restore lo excluye de la subida (ver BACKUP_META
    // en el handler de restaurar).
    const BACKUP_META = `metadata.json`;
    /**
     * Manifiesto legible que identifica de qué máquina y de qué fecha es el
     * backup. Se añade como una entrada más del ZIP para que el restore pueda
     * avisar cuando el backup viene de OTRA máquina (o de ninguna conocida).
     *
     * El nombre sale de config-machine.g (`set global.machineName`) con
     * fallback al M550 de config.g — la misma resolución que usa el modal de
     * configuración (_machineNameFrom en rotechos-config-modal.js).
     */
    async function buildBackupMetadata(numArchivos) {
      let machineName = ``;
      try {
        // Lectura fresca: los cachés de config-persist pueden estar vacíos si
        // el operario nunca abrió el modal de configuración en esta sesión.
        // cfgRead/cfgMachineRead ya cachean internamente, así que no duplica
        // tráfico contra la placa.
        // t_b8cd40c2: `_machineNameFrom` vive en el modal de CONFIGURACION, que
        // ahora es PEREZOSO. Sin asegurar su carga, la identidad salia
        // «desconocida» siempre que el operario no hubiera abierto CONFIGURACION
        // en esa sesion — y en el dialogo de restore esa identidad es la
        // salvaguarda que le dice si esta restaurando en la maquina correcta.
        try { await window.__ensureConfigModal?.(); } catch (_) { /* el typeof decide */ }
        if (typeof window._machineNameFrom === `function`
          && typeof cfgRead === `function` && typeof cfgMachineRead === `function`)
          machineName = window._machineNameFrom(await cfgRead(), await cfgMachineRead());
      } catch (e) { LOG.warn(`buildBackupMetadata: no se pudo resolver la identidad:`, e); }
      return {
        path: BACKUP_META,
        content: JSON.stringify(
          {
            machineName: machineName || `desconocida`,
            date: new Date().toISOString(),
            files: numArchivos,
            generator: `RotechOS`,
            // Soporte necesita saber con que version se hizo un ZIP suelto.
            version: typeof window.ROTECHOS_VERSION === `string` ? window.ROTECHOS_VERSION : `desconocida`,
          },
          null,
          2,
        ),
      };
    }
    function buildSimpleZip(parts) {
      const enc = new TextEncoder();
      let offset = 0;
      const localHeaders = [];
      for (const { path, content } of parts) {
        const nameBytes = enc.encode(path),
          dataBytes = enc.encode(content),
          crc = crc32(dataBytes),
          lh = buildLocalHeader(nameBytes, dataBytes, crc);
        (localHeaders.push({ lh, dataBytes, nameBytes, crc, offset }),
          (offset += lh.length + dataBytes.length));
      }
      const centralDir = localHeaders.map(
          ({ nameBytes, crc, offset, dataBytes }) =>
            buildCentralDir(nameBytes, dataBytes, crc, offset),
        ),
        cdSize = centralDir.reduce((s, b) => s + b.length, 0),
        eocd = buildEOCD(localHeaders.length, cdSize, offset),
        chunks = [
          ...localHeaders.flatMap(({ lh, dataBytes }) => [lh, dataBytes]),
          ...centralDir,
          eocd,
        ],
        total = chunks.reduce((s, c) => s + c.length, 0),
        out = new Uint8Array(total);
      let pos = 0;
      return (
        chunks.forEach((c) => {
          (out.set(c, pos), (pos += c.length));
        }),
        out
      );
    }
    function u16le(n) {
      return new Uint8Array([n & 255, (n >> 8) & 255]);
    }
    function u32le(n) {
      return new Uint8Array([
        n & 255,
        (n >> 8) & 255,
        (n >> 16) & 255,
        (n >> 24) & 255,
      ]);
    }
    function concat(...arrs) {
      const total = arrs.reduce((s, a) => s + a.length, 0),
        out = new Uint8Array(total);
      let p = 0;
      return (
        arrs.forEach((a) => {
          (out.set(a, p), (p += a.length));
        }),
        out
      );
    }
    function buildLocalHeader(nameBytes, dataBytes, crc) {
      return concat(
        new Uint8Array([80, 75, 3, 4]),
        u16le(20),
        u16le(0),
        u16le(0),
        u16le(0),
        u16le(0),
        u32le(crc),
        u32le(dataBytes.length),
        u32le(dataBytes.length),
        u16le(nameBytes.length),
        u16le(0),
        nameBytes,
      );
    }
    function buildCentralDir(nameBytes, dataBytes, crc, offset) {
      return concat(
        new Uint8Array([80, 75, 1, 2]),
        u16le(20),
        u16le(20),
        u16le(0),
        u16le(0),
        u16le(0),
        u16le(0),
        u32le(crc),
        u32le(dataBytes.length),
        u32le(dataBytes.length),
        u16le(nameBytes.length),
        u16le(0),
        u16le(0),
        u16le(0),
        u16le(0),
        u32le(0),
        u32le(offset),
        nameBytes,
      );
    }
    function buildEOCD(count, cdSize, cdOffset) {
      return concat(
        new Uint8Array([80, 75, 5, 6]),
        u16le(0),
        u16le(0),
        u16le(count),
        u16le(count),
        u32le(cdSize),
        u32le(cdOffset),
        u16le(0),
      );
    }
    function crc32(buf) {
      let crc = 4294967295;
      for (let i = 0; i < buf.length; i++) {
        crc ^= buf[i];
        for (let j = 0; j < 8; j++)
          crc = (crc >>> 1) ^ (crc & 1 ? 3988292384 : 0);
      }
      return (crc ^ 4294967295) >>> 0;
    }
    const dropZone = $(`restoreDropZone`),
      fileInput = $(`restoreFileInput`),
      statusEl = $(`restoreStatus`),
      btnRestore = $(`btnRestoreBackup`);
    let restoreZipFile = null;
    
    setupDragAndDrop(dropZone, fileInput, handleRestoreFile, `var(--text-3)`);
    function handleRestoreFile(file) {
      if (!file || !file.name.endsWith(`.zip`)) {
        toast(t(`msg.invalidZip`, `Selecciona un archivo .zip válido`), `warn`);
        return;
      }
      ((restoreZipFile = file),
        (statusEl.style.display = `block`),
        (statusEl.textContent = `✓ Archivo listo: ${file.name} (${(file.size / 1024).toFixed(1)} KB)`),
        (statusEl.style.color = `var(--green)`),
        (btnRestore.disabled = !1),
        (btnRestore.style.opacity = `1`));
    }
    /**
     * Lee el manifiesto de identidad de un ZIP ya parseado.
     * Devuelve `null` cuando el backup no lo trae (formato anterior) o cuando
     * el JSON está corrupto: en ambos casos la procedencia es DESCONOCIDA y el
     * diálogo debe pedir confirmación explícita.
     */
    function leerMetadataBackup(files) {
      const meta = files.find((f) => f.path === BACKUP_META);
      if (!meta) return null;
      try {
        const obj = JSON.parse(new TextDecoder().decode(meta.content));
        return obj && typeof obj === `object` ? obj : null;
      } catch (e) {
        return (LOG.warn(`restore: ${BACKUP_META} ilegible — se trata como procedencia desconocida:`, e), null);
      }
    }

    /**
     * Construye el diálogo de confirmación del restore según la identidad.
     *
     *   A. Identidades IGUALES  → confirmación estándar (mismo texto de siempre).
     *   B. Identidades DISTINTAS→ nombra backup y máquina actual + advertencia.
     *   C. Procedencia AUSENTE  → dice explícitamente "desconocida" + advertencia.
     *
     * La advertencia de sobrescritura (pasos/mm, área de trabajo, offsets de
     * sonda y corrientes) se muestra en B y C, que son los casos en los que el
     * operario puede estar a punto de arruinar la calibración de otra máquina.
     * Los nombres pasan por escHtml: vienen de un ZIP que el operario puede
     * haber editado a mano y el cuerpo del diálogo se inyecta como innerHTML
     * (rotechos.js:2734).
     */
    function construirDialogoRestore(nombreBackup, nombreActual, fechaBackup) {
      const esc = (s) => (typeof escHtml === `function` ? escHtml(s) : String(s ?? ``));
      // Placeholders {backup}/{current}: el texto traducido vive en el
      // diccionario (rotechos-i18n-dynjs.js) y los nombres se sustituyen
      // DESPUÉS, ya escapados. Interpolarlos antes de t() haría que la versión
      // EN —estática— perdiese los nombres, que es justo el dato crítico.
      const rellenar = (txt) =>
        txt.replace(/\{backup\}/g, esc(nombreBackup)).replace(/\{current\}/g, esc(nombreActual));
      const advertencia = t(
        `dlg.restoreBackup.warnCalib`,
        `<br><br><strong>Se sobrescribirán</strong>: pasos/mm, área de trabajo, offsets de sonda y corrientes de motor.`,
      );
      let fechaTxt = ``;
      if (fechaBackup) {
        const d = new Date(fechaBackup);
        if (!isNaN(d.getTime()))
          fechaTxt = `<br>${t(`dlg.restoreBackup.date`, `Fecha del backup`)}: ${esc(d.toLocaleString(`es-ES`))}`;
      }
      // C — sin identidad: procedencia desconocida.
      if (!nombreBackup)
        return {
          title: t(`dlg.restoreBackup.titleNoIdentity`, `¿Restaurar backup de procedencia DESCONOCIDA?`),
          msg:
            rellenar(t(
              `dlg.restoreBackup.msgNoIdentity`,
              `Este backup no indica de qué máquina procede (procedencia <strong>desconocida</strong>: fue creado con una versión anterior). La máquina actual es <strong>"{current}"</strong>.`,
            )) + fechaTxt + advertencia,
        };
      // B — identidad distinta: clonar es legítimo, pero debe ser consciente.
      if (nombreBackup !== nombreActual)
        return {
          title: t(`dlg.restoreBackup.titleOtherMachine`, `¿Restaurar backup de OTRA máquina?`),
          msg:
            rellenar(t(
              `dlg.restoreBackup.msgOtherMachine`,
              `Este backup procede de la máquina <strong>"{backup}"</strong>, pero la máquina actual es <strong>"{current}"</strong>.`,
            )) + fechaTxt + advertencia,
        };
      // A — identidades iguales: confirmación de siempre.
      return {
        title: t(`dlg.restoreBackup.title`, `¿Restaurar backup?`),
        msg:
          t(`dlg.restoreBackup.msg`, `Se sobreescribirán todos los archivos de /sys/ y /macros/ con el contenido del ZIP. El firmware se reiniciará.`) +
          fechaTxt,
      };
    }

    /**
     * FASE A del restore: valida el contenedor entero sin escribir en la SD.
     * El directorio central es el catálogo de entradas esperadas. Cada una
     * debe tener su cabecera local, ocupar exactamente los bytes declarados y
     * superar el CRC32 antes de devolver la lista que consumirá la FASE B.
     */
    function validarZipRestore(buf) {
      const dec = new TextDecoder(),
        fallo = (path, detalle) => {
          throw Error(`ZIP inválido: ${path ? `falló la entrada ${path}: ` : ``}${detalle}`);
        },
        u16 = (pos) => {
          if (pos < 0 || pos + 2 > buf.length) fallo(``, `estructura truncada`);
          return buf[pos] | (buf[pos + 1] << 8);
        },
        u32 = (pos) => {
          if (pos < 0 || pos + 4 > buf.length) fallo(``, `estructura truncada`);
          return (buf[pos] | (buf[pos + 1] << 8) | (buf[pos + 2] << 16) | (buf[pos + 3] << 24)) >>> 0;
        },
        firma = (pos, valor) => pos >= 0 && pos + 4 <= buf.length && u32(pos) === valor;

      let eocd = -1;
      for (let pos = buf.length - 22, limite = Math.max(0, buf.length - 65557); pos >= limite; pos--)
        if (firma(pos, 0x06054b50) && pos + 22 + u16(pos + 20) === buf.length) {
          eocd = pos;
          break;
        }
      if (eocd < 0) fallo(``, `no se encontró el cierre del ZIP completo`);
      if (u16(eocd + 4) !== 0 || u16(eocd + 6) !== 0)
        fallo(``, `los ZIP repartidos en varios discos no son compatibles`);

      const entradasDisco = u16(eocd + 8),
        entradasEsperadas = u16(eocd + 10),
        centralSize = u32(eocd + 12),
        centralOffset = u32(eocd + 16);
      if (entradasDisco !== entradasEsperadas)
        fallo(``, `el número de entradas del catálogo no es coherente`);
      if (centralOffset + centralSize !== eocd)
        fallo(``, `el directorio central está truncado o desplazado`);

      const nombres = new Set(),
        catalogo = [];
      let pos = centralOffset;
      for (let n = 0; n < entradasEsperadas; n++) {
        if (!firma(pos, 0x02014b50))
          fallo(``, `falta la entrada ${n + 1} del directorio central`);
        // Los backups creados antes de H-COB-02 llevan dos bytes reservados
        // de más antes del CRC del directorio central. Se aceptan para no
        // inutilizar copias existentes, pero los nuevos ya salen estándar.
        const leerCentral = (desplazamiento) => {
            const nameLen = u16(pos + 28 + desplazamiento),
              extraLen = u16(pos + 30 + desplazamiento),
              commentLen = u16(pos + 32 + desplazamiento),
              fixedSize = 46 + desplazamiento;
            return {
              crcEsperado: u32(pos + 16 + desplazamiento),
              compSize: u32(pos + 20 + desplazamiento),
              rawSize: u32(pos + 24 + desplazamiento),
              nameLen,
              extraLen,
              commentLen,
              localOffset: u32(pos + 42 + desplazamiento),
              centralEnd: pos + fixedSize + nameLen + extraLen + commentLen,
              path: dec.decode(buf.slice(pos + fixedSize, pos + fixedSize + nameLen)),
            };
          },
          rutaCatalogable = (path) => path === BACKUP_META || /^(sys|macros)\//.test(path),
          estandar = leerCentral(0),
          legado = leerCentral(2),
          central = rutaCatalogable(estandar.path) ? estandar : legado,
          flags = u16(pos + 8),
          method = u16(pos + 10),
          { crcEsperado, compSize, rawSize, localOffset, centralEnd, path } = central;
        if (centralEnd > eocd) fallo(``, `una entrada del catálogo está truncada`);
        if (!rutaCatalogable(path)) fallo(path, `no es una ruta esperada del backup`);
        if (nombres.has(path)) fallo(path, `está duplicada`);
        nombres.add(path);
        if (method !== 0 || compSize !== rawSize)
          fallo(path, `usa compresión no compatible; se requiere método STORE`);
        if (flags & 9) fallo(path, `usa cifrado o descriptor de datos no compatible`);
        if (!firma(localOffset, 0x04034b50)) fallo(path, `falta su cabecera local`);

        const localFlags = u16(localOffset + 6),
          localMethod = u16(localOffset + 8),
          localCrc = u32(localOffset + 14),
          localCompSize = u32(localOffset + 18),
          localRawSize = u32(localOffset + 22),
          localNameLen = u16(localOffset + 26),
          localExtraLen = u16(localOffset + 28),
          localNameEnd = localOffset + 30 + localNameLen,
          dataStart = localNameEnd + localExtraLen,
          dataEnd = dataStart + localCompSize;
        if (dataEnd > centralOffset) fallo(path, `su contenido está truncado`);
        const localPath = dec.decode(buf.slice(localOffset + 30, localNameEnd));
        if (localPath !== path) fallo(path, `su nombre no coincide con la cabecera local`);
        if (localFlags !== flags || localMethod !== method || localCrc !== crcEsperado ||
            localCompSize !== compSize || localRawSize !== rawSize)
          fallo(path, `sus cabeceras no son coherentes`);
        const content = buf.slice(dataStart, dataEnd);
        if (crc32(content) !== crcEsperado) fallo(path, `el CRC32 no coincide`);
        catalogo.push({ path, content, localOffset, dataEnd });
        pos = centralEnd;
      }
      if (pos !== centralOffset + centralSize)
        fallo(``, `el tamaño del directorio central no coincide`);

      let cursor = 0;
      for (const entrada of catalogo.slice().sort((a, b) => a.localOffset - b.localOffset)) {
        if (entrada.localOffset !== cursor)
          fallo(entrada.path, `falta una entrada esperada antes de su contenido`);
        cursor = entrada.dataEnd;
      }
      if (cursor !== centralOffset) fallo(``, `hay datos no catalogados antes del directorio central`);

      const files = catalogo
        .filter((entrada) => !entrada.path.endsWith(`/`))
        .map(({ path, content }) => ({ path, content }));
      for (const { path } of files) {
        const segmentos = path.split(`/`);
        if (path !== BACKUP_META &&
            (!/^(sys|macros)\//.test(path) || segmentos.some((parte) => !parte || parte === `.` || parte === `..`)))
          fallo(path, `no pertenece a sys/ ni macros/`);
      }
      if (!files.some((entrada) => entrada.path !== BACKUP_META))
        fallo(``, `no contiene archivos de máquina`);

      const meta = files.find((entrada) => entrada.path === BACKUP_META);
      if (meta) {
        let obj;
        try { obj = JSON.parse(dec.decode(meta.content)); }
        catch { fallo(BACKUP_META, `no contiene JSON legible`); }
        const numArchivos = files.filter((entrada) => entrada.path !== BACKUP_META).length;
        if (Number.isInteger(obj.files) && obj.files !== numArchivos)
          fallo(BACKUP_META, `declara ${obj.files} archivos pero el ZIP contiene ${numArchivos}`);
      }
      const parsed = parseZip(buf);
      if (parsed.length !== files.length || parsed.some((entrada, index) => entrada.path !== files[index].path))
        fallo(``, `el catálogo y las entradas locales no contienen el mismo conjunto`);
      // 15-sep: sys/wifi-passwords.g no se restaura nunca (el backup tampoco lo guarda):
      // un ZIP manipulado sustituía las credenciales WiFi de la máquina.
      return { ok: true, files: parsed.filter((e) => !(e.path.startsWith(`sys/`) && BACKUP_EXCLUIDOS.test(e.path.slice(4)))) };
    }

    btnRestore.addEventListener(`click`, async () => {
      if (!restoreZipFile) return;
      // 15-sep: con un trabajo en marcha o en pausa no se restaura (el M999 del final
      // reiniciaba la placa en pleno corte).
      if (typeof SM !== `undefined` && (SM.current === STATES.RUNNING || SM.current === STATES.PAUSED)) {
        toast(t(`msg.restoreBloqueadoTrabajo`, `Con un trabajo en marcha o en pausa no se restaura un backup.`), `warn`);
        return;
      }
      // El ZIP se lee ANTES de confirmar para poder nombrar la procedencia en
      // el diálogo. Nada se escribe en la SD hasta que el operario acepta:
      // cancelar deja la configuración EXACTAMENTE como estaba.
      let files;
      try {
        ((statusEl.textContent = `Validando ZIP completo…`),
          (statusEl.style.color = `var(--text-3)`));
        const validacion = validarZipRestore(new Uint8Array(await restoreZipFile.arrayBuffer()));
        files = validacion.files;
      } catch (e) {
        ((statusEl.textContent = t(`msg.restoreErr`, `✗ Error`) + `: ` + e.message + `. NO se ha tocado la SD — revisa la conexión WiFi con el CNC y vuelve a CONFIGURACIÓN → Backup.`),
          (statusEl.style.color = `var(--red)`),
          toast(t(`msg.errorRestaurandoBackup`, `Error restaurando backup — la SD no se ha modificado; revisa la conexión WiFi con el CNC y repite desde CONFIGURACIÓN → Backup`), `err`));
        return;
      }
      const meta = leerMetadataBackup(files);
      const nombreBackup = (meta && typeof meta.machineName === `string` && meta.machineName !== `desconocida`)
        ? meta.machineName
        : ``;
      let nombreActual = ``;
      try {
        // t_b8cd40c2: `_machineNameFrom` vive en el modal de CONFIGURACION, que
        // ahora es PEREZOSO. Sin asegurar su carga, la identidad salia
        // «desconocida» siempre que el operario no hubiera abierto CONFIGURACION
        // en esa sesion — y en el dialogo de restore esa identidad es la
        // salvaguarda que le dice si esta restaurando en la maquina correcta.
        try { await window.__ensureConfigModal?.(); } catch (_) { /* el typeof decide */ }
        if (typeof window._machineNameFrom === `function`
          && typeof cfgRead === `function` && typeof cfgMachineRead === `function`)
          nombreActual = window._machineNameFrom(await cfgRead(), await cfgMachineRead());
      } catch (e) { LOG.warn(`restore: no se pudo leer la identidad actual:`, e); }
      const dlg = construirDialogoRestore(nombreBackup, nombreActual || `desconocida`, meta && meta.date);
      // HUECO-5: si el backup no incluye sys/config-machine.g, el PIN HTTP
      // (M551) actualmente configurado se va a perder. Avisamos en línea, no
      // en rama nueva (cualquier rama A/B/C puede tener este problema).
      const tieneConfigMachine = files.some((f) => f.path === `sys/config-machine.g`);
      if (!tieneConfigMachine) {
        const avisoPin = t(
          `dlg.restoreBackup.noConfigMachine`,
          `<br><br><strong style=color:var(--warn-strong)>Este backup no incluye <code>sys/config-machine.g</code>.</strong> ` +
          `Si tienes un PIN HTTP (M551) configurado, se borrará al restaurar. ` +
          `Vuelve a CONFIGURACIÓN → PIN HTTP y defínelo de nuevo si quieres mantenerlo.`,
        );
        dlg.msg += avisoPin;
      }
      if (!(await confirmDialog(dlg.title, dlg.msg))) return;
      // FIX A3-02: `previos` se declara con `let` FUERA del try para que el
      // catch pueda leerla y ejecutar el rollback. Ver comentario más abajo
      // en el bloque del try para la justificación completa.
      // D-03: el restore escribe sys/ y macros/ enteros y acaba en M999 — la
      // ruta de escritura mas ancha de la interfaz, y sin escudo. Va tras el
      // confirmDialog y antes de leer nada: un aborto no deja nada a medias.
      if (typeof window !== `undefined` && window.rotechosShieldMsg
        && !await window.rotechosShieldMsg.guard(TARGET_IP, `restore`)) return;
      let previos = [];
      {
        ((statusEl.textContent = `Restaurando archivos… por favor espera.`),
          (statusEl.style.color = `var(--text-3)`),
          (btnRestore.disabled = !0));
        try {
          // metadata.json es el manifiesto del propio backup, NO un archivo de
          // la máquina: se excluye para no dejarlo suelto en la raíz de la SD.
          files = files.filter((f) => f.path !== BACKUP_META);
          // H-8-01: config.g se escribe el ultimo y se aborta al primer fallo, sin reiniciar.
          // A3-02: antes de subir se guarda cada destino en `previos` (let, fuera del try,
          // para que el catch la vea) y un fallo los restaura en orden inverso.
          // PENDIENTE BANCO: que un rr_upload cortado no deje el destino a medias.
          // Detalle: docs/dev/hallazgos/2026-09-06_A3-escrituras-a-la-sd.md.
          const orden = files.slice().sort((a, b) => {
            const critico = (p) => (/(^|\/)config\.g$/i.test(p) ? 1 : 0);
            return critico(a.path) - critico(b.path);
          });
          // Snapshot pre-upload: rr_download de cada destino. 404 = no existía.
          statusEl.textContent = `Leyendo estado actual de la SD…`;
          for (const { path } of orden) {
            const rel = `0:/` + path;
            const r = await RRF.download(rel, { timeoutMs: 10000 });
            if (r.ok) {
              const prev = await r.text();
              // Defense-in-depth: igual que en _cfgReadPath (rotechos-config-persist.js:75),
              // quitamos BOM y normalizamos CRLF→LF al guardar el snapshot para
              // que la re-subida no introduzca artefactos de Windows.
              const limpio = prev.replace(/^\uFEFF/, ``).replace(/\r\n/g, `\n`);
              previos.push({ path, prev: limpio, existed: true });
            } else if (r.status === 404) {
              // No existía antes: el rollback debe dejarlo borrado, no inventar
              // contenido. Marcamos existed:false y, en el catch, NO lo
              // re-subimos (RRF no tiene endpoint de borrado desde la UI; lo
              // que escribimos al fallar el upload se queda, y el operario
              // debe decidir si limpiarlo a mano).
              previos.push({ path, prev: null, existed: false });
            } else {
              // Fallo de lectura (red caída antes de empezar). Abortamos sin
              // escribir nada — el snapshot está incompleto y no podemos
              // garantizar rollback.
              throw Error(
                `no se pudo leer ${path} previo al restore (HTTP ${r.status}). ` +
                `NO se ha escrito nada en la SD. Revisa la conexión WiFi con el CNC y repite.`,
              );
            }
          }
          const escritos = [];
          for (const { path, content } of orden) {
            statusEl.textContent = `Subiendo ${path}…`;
            const r = await _fetchRRF(
              `${TARGET_IP}/rr_upload?name=${encodeURIComponent(`0:/` + path)}&time=0`,
              { method: `POST`, body: content },
              30000,
            );
            let errRRF = 0;
            try { errRRF = (await r.clone().json())?.err ?? 0; } catch { errRRF = 0; }
            if (!r.ok || errRRF) {
              const pendientes = orden.length - escritos.length;
              throw Error(
                `falló al escribir ${path} (HTTP ${r.status}). ` +
                `Escritos: ${escritos.join(`, `) || `ninguno`}. ` +
                `Quedan ${pendientes} sin escribir. NO se ha reiniciado: ` +
                `la máquina sigue con su config.g anterior. Revirtiendo los ya subidos…`,
              );
            }
            escritos.push(path);
          }
          // 15-sep: la caché de configuración queda obsoleta: el siguiente Guardar relee.
          if (typeof _cfgRaw !== `undefined`) { _cfgRaw = ``; _cfgMachineRaw = ``; }
          ((statusEl.textContent = `✓ ${files.length} archivos restaurados. Reiniciando firmware…`),
            (statusEl.style.color = `var(--green)`),
            toast(t(`msg.restoreOk`, `Backup restaurado. Reiniciando…`), `ok`),
            log(`Backup restaurado: ${files.length} archivos`, `ok`),
            setTimeout(() => RRF.gcode(`M999`), 1500));
        } catch (e) {
          // ROLLBACK: si algo falló a mitad del bucle principal, recorremos
          // `previos` en orden INVERSO y re-subimos el contenido anterior a
          // cada destino (saltando los que no existían — no hay endpoint de
          // borrado y no queremos escribir algo ficticio). El error de
          // rollback NO enmascara el error original: lo añadimos como sufijo
          // para que el operario vea las dos cosas.
          //
          // config.g va el último también en el rollback: si la red cae
          // mientras estamos revirtiendo, el config.g viejo sigue siendo el
          // que la máquina puede arrancar.
          let rollbackMsg = ``;
          if (typeof previos !== `undefined` && Array.isArray(previos) && previos.length) {
            const revertidos = [];
            const fallaronReversion = [];
            for (let i = previos.length - 1; i >= 0; i--) {
              const { path, prev, existed } = previos[i];
              if (!existed) continue; // no había contenido previo que reponer
              statusEl.textContent = `Revirtiendo ${path}…`;
              try {
                const rr = await _fetchRRF(
                  `${TARGET_IP}/rr_upload?name=${encodeURIComponent(`0:/` + path)}&time=0`,
                  { method: `POST`, body: prev },
                  30000,
                );
                let errRRF = 0;
                try { errRRF = (await rr.clone().json())?.err ?? 0; } catch { errRRF = 0; }
                if (!rr.ok || errRRF) {
                  fallaronReversion.push(`${path} (HTTP ${rr.status})`);
                } else {
                  revertidos.push(path);
                }
              } catch (re) {
                fallaronReversion.push(`${path} (${re.message || `error`})`);
              }
            }
            const partes = [];
            if (revertidos.length)
              partes.push(t(
                `msg.restoreRollbackOk`,
                `Reviertos a su estado anterior: ${revertidos.join(`, `)}.`,
                { files: revertidos.join(`, `) },
              ));
            if (fallaronReversion.length)
              partes.push(t(
                `msg.restoreRollbackFail`,
                `No se pudieron reponer: ${fallaronReversion.join(`, `)}. La SD puede seguir mixta — revisa la conexión WiFi con el CNC y repite la restauración desde CONFIGURACIÓN → Backup.`,
                { files: fallaronReversion.join(`, `) },
              ));
            rollbackMsg = partes.length ? `\n\n` + partes.join(`\n\n`) : ``;
          }
          const finalErr = e.message + rollbackMsg;
          ((statusEl.textContent = t(`msg.restoreErr`, `✗ Error`) + `: ` + finalErr),
            (statusEl.style.color = `var(--red)`),
            (btnRestore.disabled = !1),
            toast(t(`msg.errorRestaurandoBackup`, `Error restaurando backup — la SD puede estar a medias; revisa la conexión WiFi con el CNC y repite la restauración desde CONFIGURACIÓN → Backup`), `err`));
        }
      }
    });
    function parseZip(buf) {
      const files = [],
        dec = new TextDecoder();
      let i = 0;
      for (; i < buf.length - 4; )
        if (
          buf[i] === 80 &&
          buf[i + 1] === 75 &&
          buf[i + 2] === 3 &&
          buf[i + 3] === 4
        ) {
          const nameLen = buf[i + 26] | (buf[i + 27] << 8),
            extraLen = buf[i + 28] | (buf[i + 29] << 8),
            compSize =
              buf[i + 18] |
              (buf[i + 19] << 8) |
              (buf[i + 20] << 16) |
              (buf[i + 21] << 24),
            name = dec.decode(buf.slice(i + 30, i + 30 + nameLen)),
            dataStart = i + 30 + nameLen + extraLen,
            data = buf.slice(dataStart, dataStart + compSize);
          (name.endsWith(`/`) || files.push({ path: name, content: data }),
            (i = dataStart + compSize));
        } else i++;
      return files;
    }

    // ── Export minimo para el paquete de diagnostico (2026-08-31) ────────────
    // `rotechos-diag.js` necesita EXACTAMENTE este empaquetador. La alternativa
    // era duplicar el generador de ZIP (crc32 + cabeceras locales + directorio
    // central + EOCD, ~90 lineas) en un segundo modulo, y dos implementaciones
    // del mismo formato binario divergen: la primera vez que alguien arregle un
    // bug de cabecera aqui, el otro se queda con el bug.
    //
    // Se expone SOLO el constructor de ZIP, no el resto del modulo: nada de
    // `rr_download`, ni la lista de ficheros del backup, ni la denylist. El
    // diagnostico trae su propia allowlist y su propio redactado, que son mas
    // estrictos, y no debe poder reutilizar los de aqui por accidente.
    //
    // Contrato: buildSimpleZip([{ path: string, content: string }]) -> Uint8Array
    window.__buildSimpleZip = buildSimpleZip;
})();
