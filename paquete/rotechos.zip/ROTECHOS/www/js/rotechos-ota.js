// rotechos-ota.js — aviso de actualizaciones.
// Lee el manifest de Peerchi/rotechos-updates al arrancar (en silencio) y con
// el botón «Buscar actualizaciones»; si hay versión nueva, banner con enlace.
// Nada se instala solo (decisión de Sergi, 2026-07-05: nada llega a la máquina
// sin un acto humano). Desde el 8-oct el banner trae «Instalar ahora», y la
// pestaña OTA «Instalar desde un ZIP»: los dos piden confirmación y los hace
// rotechos-ota-install.js. Manifest: { rotechos_version, changelog_es,
// release_url, versiones[], paquete_url, paquete_sha256 } — lo escribe
// scripts/publicar_actualizacion.sh.
// Depende de rotechos.js (_fetchRRF, RRF, toast, log, TARGET_IP, $) y de t().

(function () {
  "use strict";

  const REMOTE_MANIFEST_URL =
    "https://raw.githubusercontent.com/Peerchi/rotechos-updates/main/manifest.json";

  const RELEASES_URL =
    "https://github.com/Peerchi/rotechos-updates/releases";

  const FETCH_TIMEOUT_MS = 10000;

  // rotechos.js inyecta el módulo a los 6 s; 2 s más para no pisar el sondeo.
  const STARTUP_DELAY_MS = 2000;
  const DISMISS_KEY = "rotech_ota_dismissed";

  let _checking = false;

  async function _fetchSD(path) {
    try {
      const r = await RRF.download(path, { timeoutMs: FETCH_TIMEOUT_MS });
      if (!r.ok) throw Error(`HTTP ${r.status}`);
      return await r.text();
    } catch {
      return null;
    }
  }

  function _parseVersion(raw) {
    if (!raw) return null;
    const lines = raw.split(/\r?\n/);
    for (const line of lines) {
      const m = line.match(/(\d{4}-\d{2}-\d{2})/);
      if (m) return m[1];
    }
    return null;
  }

  // Versión instalada: sys/VERSION, o global.fwVersion si falta.
  async function _readLocalVersion() {
    const raw = await _fetchSD("0:/sys/VERSION");
    let ver = _parseVersion(raw);
    if (ver) return ver;

    try {
      const r = await _fetchRRF(
        `${TARGET_IP}/rr_gcode?gcode=M409%20K%22global.fwVersion%22`,
        undefined,
        5000,
      );
      if (r.ok) {
        const json = await r.json();
        const fwVer = json?.result?.fwVersion ?? json?.fwVersion;
        if (fwVer) {
          ver = _parseVersion(String(fwVer));
          if (ver) return ver;
        }
      }
    } catch { /* silencio */ }

    return "0";
  }

  // Publicadas por encima de la local (lista `versiones`; sin ella, 1).
  function _versionsBehind(local, manifest) {
    const list = Array.isArray(manifest?.versiones) ? manifest.versiones : [];
    const n = list.filter((v) => typeof v === "string" && _isNewer(local, v)).length;
    return Math.max(n, 1);
  }

  function _isNewer(local, remote) {
    if (local === "0") return true;
    return remote > local;
  }

  // Manifest con 1 reintento → { kind: "ok", manifest } | "no-server" (HTTP 404:
  // no hay manifest publicado; no es la red, y decirlo así evita que el
  // operario culpe a su WiFi) | "offline" (cualquier otro fallo).
  async function _fetchManifest() {
    let lastError = null;
    let lastStatus = null;
    for (let attempt = 0; attempt < 2; attempt++) {
      try {
        const r = await fetch(REMOTE_MANIFEST_URL, {
          cache: "no-store",
          signal: AbortSignal.timeout(FETCH_TIMEOUT_MS),
        });
        if (r.status === 404) {
          LOG.warn("OTA: manifest URL devuelve 404 — el repositorio público no está publicado en esta build");
          return { kind: "no-server" };
        }
        if (!r.ok) {
          lastStatus = r.status;
          throw Error(`HTTP ${r.status}`);
        }
        const json = await r.json();
        if (!json.rotechos_version) throw Error("Manifest sin rotechos_version");
        return { kind: "ok", manifest: json };
      } catch (e) {
        lastError = e;
        if (attempt === 0) {
          LOG.warn(`OTA: fetch manifest intento ${attempt + 1} fallido — reintentando`, e);
          continue;
        }
        LOG.warn(`OTA: fetch manifest falló tras reintento (HTTP ${lastStatus ?? "n/a"})`, e);
        return { kind: "offline", error: lastError };
      }
    }
    return { kind: "offline", error: lastError ?? new Error("sin respuesta") };
  }

  function _removeBanner() {
    const existing = $("otaUpdateBanner");
    if (existing) existing.remove();
  }

  function _getDismissed() {
    try { return localStorage.getItem(DISMISS_KEY); } catch { return null; }
  }

  function _setDismissed(ver) {
    try { localStorage.setItem(DISMISS_KEY, ver); } catch { /* sin almacenamiento: volverá a avisar */ }
  }

  // Banner de versión nueva (estilos: #otaUpdateBanner en rotechos.css).
  function _showBanner(manifest, localVer) {
    _removeBanner();

    const remoteVer = manifest.rotechos_version;
    const changelog = manifest.changelog_es || manifest.changelog_en || "";
    const releaseUrl = manifest.release_url || RELEASES_URL;

    const banner = document.createElement("div");
    banner.id = "otaUpdateBanner";

    const textSpan = document.createElement("span");
    textSpan.textContent =
      t("msg.otaNewVersion", "Nueva versión disponible") + `: ${remoteVer}` +
      (changelog ? ` — ${changelog}` : "");

    // Cada release es la SD completa: con varias de retraso basta la última.
    const behind = _versionsBehind(localVer, manifest);
    if (behind > 1) {
      textSpan.textContent += ". " + t(
        "msg.otaBehind",
        "Llevas {n} versiones sin actualizar; esta las incluye todas, instala solo la última.",
      ).replace("{n}", String(behind));
    }

    // B-04: solo enlaces a github.com (un manifest manipulado podría traer javascript:).
    const safeUrl = /^https:\/\/github\.com\//i.test(releaseUrl) ? releaseUrl : RELEASES_URL;
    const link = document.createElement("a");
    link.href = safeUrl;
    link.target = "_blank";
    link.rel = "noopener noreferrer";
    link.textContent = t("msg.otaViewRelease", "Ver en GitHub");
    link.className = "ota-banner-link";

    const hint = document.createElement("span");
    hint.textContent = t(
      "msg.otaHowto",
      "Descárgala, descomprímela y arrastra los archivos sueltos a la zona de subida en CONFIGURACIÓN.",
    );
    hint.className = "ota-banner-hint";

    const close = document.createElement("span");
    close.textContent = "\u2715"; // ✕
    close.className = "ota-banner-close";
    close.addEventListener("click", () => {
      _setDismissed(remoteVer);
      _removeBanner();
    });
    close.title = t("btn.close", "Cerrar");

    banner.appendChild(textSpan);
    // Con paquete publicado, se instala desde aquí (con confirmación).
    if (manifest.paquete_url && manifest.paquete_sha256) {
      const install = document.createElement("button");
      install.type = "button";
      install.className = "ota-banner-install";
      install.textContent = t("msg.otaInstallNow", "Instalar ahora");
      install.addEventListener("click", () => {
        _instalador().then((m) => m && m.desdeManifest(manifest));
      });
      banner.appendChild(install);
      hint.textContent = t(
        "msg.otaHowtoInstall",
        "O descárgala y usa «Instalar desde un ZIP» en CONFIGURACIÓN → ACTUALIZAR (OTA).",
      );
    }
    banner.appendChild(link);
    banner.appendChild(hint);
    banner.appendChild(close);
    document.body.appendChild(banner);

    log(`OTA: nueva versión detectada — ${remoteVer} (instalación manual)`, "sys");
  }

  // Solo lectura (no toca la SD). opts.silent = al arrancar: sin toasts, y el
  // banner solo si hay versión nueva que el operario no haya cerrado ya.
  async function check(opts = {}) {
    const silent = !!opts.silent;
    if (_checking) {
      if (!silent) toast(t("msg.otaInProgress", "Comprobación en curso…"), "warn");
      return;
    }
    _checking = true;
    try {
      log("OTA: comprobando actualizaciones…", "sys");

      const localVer = await _readLocalVersion();
      log(`OTA: versión local = ${localVer}`, "sys");

      const result = await _fetchManifest();
      if (silent && result.kind !== "ok") {
        log(`OTA: comprobación al arrancar sin resultado (${result.kind})`, "sys");
        return;
      }
      if (result.kind === "offline") {
        toast(
          t(
            "msg.otaOffline",
            "Sin conexión con el servidor de actualizaciones (si estás en la red RotechOS, este dispositivo no tiene internet). La máquina funciona igual. Para actualizar sin internet, descarga el ZIP desde otro dispositivo y usa «Instalar desde un ZIP».",
          ),
          "warn",
        );
        log("OTA: sin conexión (offline)", "warn");
        return;
      }
      if (result.kind === "no-server") {
        toast(
          t(
            "msg.otaRepoUnavailable",
            "La auto-comprobación de actualizaciones no está disponible en esta versión. Para actualizar, descarga la nueva release desde GitHub y arrastra los archivos sueltos a la zona de subida de CONFIGURACIÓN (OTA).",
          ),
          "warn",
        );
        log(
          "OTA: el repositorio público de updates no está publicado en esta build (HTTP 404) — actualiza a mano",
          "warn",
        );
        return;
      }

      const manifest = result.manifest;
      const remoteVer = manifest.rotechos_version;
      log(`OTA: versión remota = ${remoteVer}`, "sys");

      if (_isNewer(localVer, remoteVer)) {
        if (silent && _getDismissed() === remoteVer) {
          log(`OTA: ${remoteVer} disponible, aviso ya cerrado por el operario`, "sys");
          return;
        }
        _showBanner(manifest, localVer);
      } else if (silent) {
        log(`OTA: estás al día (${localVer} ≥ ${remoteVer})`, "sys");
      } else {
        toast(t("msg.otaUpToDate", "Estás al día") + ` (${localVer})`, "ok");
        log(`OTA: estás al día (${localVer} ≥ ${remoteVer})`, "sys");
      }
    } finally {
      _checking = false;
    }
  }

  // El instalador solo se carga cuando alguien va a instalar.
  function _instalador() {
    if (window.OTAInstall) return Promise.resolve(window.OTAInstall);
    return __lazyLoad("/js/rotechos-ota-install.js")
      .then(() => window.OTAInstall)
      .catch((e) => {
        LOG.warn("lazy OTA-install:", e);
        toast(t("msg.otaInstFallo", "La instalación no se ha completado"), "err");
        return null;
      });
  }

  window.OTA = { check, readLocalVersion: _readLocalVersion, _parseVersion, _isNewer, _versionsBehind };

  $('btnOtaCheck')?.addEventListener('click', () => check());

  const zipInput = $('otaZipInput');
  $('btnOtaZip')?.addEventListener('click', () => zipInput?.click());
  zipInput?.addEventListener('change', (e) => {
    const f = e.target.files && e.target.files[0];
    e.target.value = '';
    if (f) _instalador().then((m) => m && m.desdeFichero(f));
  });

  // Al arrancar, una vez por página. Sale el navegador, no la placa.
  if (typeof navigator === "undefined" || navigator.onLine !== false) {
    if (!window.__otaStartupChecked) {
      window.__otaStartupChecked = true;
      const tm = setTimeout(() => { check({ silent: true }).catch(() => {}); }, STARTUP_DELAY_MS);
      tm?.unref?.(); // en los tests de Node no retiene el proceso
    }
  }

  log("OTA: módulo de notificación de versión cargado (descarga/carga manual)", "sys");
})();
