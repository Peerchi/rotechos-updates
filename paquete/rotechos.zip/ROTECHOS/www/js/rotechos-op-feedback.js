/* ---
 * rotechos-op-feedback.js — Que operacion fallo, y que esta tardando.
 *
 * HUECO-2 y HUECO-3 del acta
 * `docs/dev/hallazgos/2026-09-06_C-robustez-percibida.md` (tarjeta t_e558a603).
 *
 * EL PROBLEMA MEDIDO
 * ------------------
 * HUECO-3 (S3 del acta): con `/rr_gcode` devolviendo HTTP 500, el operario
 * pulsa y NO sale ningun toast de la operacion. Lo unico que ve es el toast
 * generico de «Conexion perdida con la UI», que en ese escenario es MENTIRA:
 * la conexion esta bien, lo que fallo es UNA peticion. Y esa mentira tiene
 * consecuencia — lleva al operario a tirar la sesion con F5 sin necesidad.
 *
 * `RRF.gcode` YA sabe exactamente por que fallo: deja la causa en
 * `RRF._lastFail` con `reason` ∈ {http, firmware, timeout, network, shield}
 * (rotechos.js:1169-1192). Pero de los 70 sitios que hacen `await RRF.gcode`,
 * solo la consola MDI (rotechos.js:3626) lee ese slot. En el resto la causa
 * se mide, se guarda... y se tira.
 *
 * HUECO-2 (S2 del acta): durante los 2,2 s que tarda la operacion, la UI dice
 * «INACTIVO» y no hay ninguna senal de que algo este pasando. Parece colgada.
 *
 * QUE HACE ESTE MODULO
 * ---
 *   opFail(op)  → toast de error que NOMBRA la operacion Y la causa real,
 *                 leida de `RRF._lastFail`. «No se pudo guardar la
 *                 configuracion: el firmware respondio HTTP 500».
 *   opSlow(op)  → devuelve un `cancelar()`. Si la operacion sigue en vuelo
 *                 pasado el umbral, avisa de que SIGUE en curso, nombrandola.
 *                 Si termina antes, no se pinta nada.
 *   opRun(op, fn) → une las dos: envuelve una promesa, avisa si tarda y
 *                 avisa con causa si falla.
 *
 * LO QUE **NO** HACE, a proposito
 * ---
 *  - NO anade esperas fijas «para dar tiempo» a que salga un toast. El aviso
 *    de lentitud se programa con un umbral y se CANCELA si la operacion
 *    responde antes; no retrasa nada.
 *  - NO afirma que la operacion se haya ejecutado o no cuando no se sabe. Un
 *    timeout se reporta como «no se confirmo — pudo haberse ejecutado», que
 *    es la verdad. Esta es la regla de honestidad del proyecto aplicada a un
 *    toast: si no lo sabemos, se dice.
 *  - NO toca la maquina de estados, ni el ciclo del poll, ni la capa RRF.
 *    Solo lee `RRF._lastFail`, que ya existia.
 *
 * Dependencias globales (orden de <script defer> en index.html: DESPUES de
 * rotechos-ui-feedback.js, que publica window.toast):
 *   - window.toast(msg, tipo)  ← rotechos-ui-feedback.js
 *   - t(clave, fallback)       ← rotechos-i18n.js
 *   - RRF._lastFail            ← rotechos.js (solo lectura)
 *   - log(msg, nivel)          ← rotechos.js (opcional)
 *
 * Tests: tests/unit/op-feedback.test.js
 * --- */
(function () {
  'use strict';

  // Umbral por defecto del aviso de lentitud. 1200 ms es la horquilla honesta:
  // por encima del ruido normal de un rr_gcode en WiFi de taller (el acta mide
  // ciclos de sondeo de cientos de ms) y por debajo de los 2 s en que el
  // operario del acta ya se preguntaba si su clic habia llegado.
  const SLOW_MS = 1200;

  function _t(clave, fallback, vars) {
    return (typeof t === `function`) ? t(clave, fallback, vars) : fallback;
  }

  function _toast(msg, tipo) {
    // Guard: en los unitarios no hay DOM ni modulo de toast cargado.
    if (typeof window !== `undefined` && typeof window.toast === `function`) {
      window.toast(msg, tipo);
      return true;
    }
    return false;
  }

  function _log(msg, nivel) {
    if (typeof log === `function`) { try { log(msg, nivel); } catch (_) { /* el toast ya avisó */ } }
  }

  /** Nombre visible de la operacion. `op` puede ser una cadena ya lista o
   *  una clave con traduccion. Nunca devuelve vacio: sin nombre el toast
   *  volveria a ser el generico que este modulo existe para eliminar. */
  function _nombre(op) {
    if (op && typeof op === `object`) {
      return _t(op.clave, op.nombre || `la operación`);
    }
    return (typeof op === `string` && op.trim()) ? op : `la operación`;
  }

  /** Traduce `RRF._lastFail` a una frase que dice QUE paso, sin adornar y sin
   *  afirmar mas de lo que se sabe. Devuelve null si no hay causa registrada
   *  (entonces el llamador no debe inventarse una). */
  function causa(lf) {
    if (!lf || !lf.reason) return null;
    if (lf.reason === `http`) {
      return _t(`msg.opCausaHttp`, `el firmware respondió HTTP ${lf.status}`, { status: lf.status });
    }
    if (lf.reason === `firmware`) {
      return _t(`msg.opCausaFirmware`, `el firmware lo rechazó: ${lf.errMsg}`, { errMsg: lf.errMsg });
    }
    if (lf.reason === `timeout`) {
      // Honestidad: un timeout NO significa que no se ejecutara. Significa
      // que no se confirmo. Decir «no se ejecuto» seria inventar.
      return _t(`msg.opCausaTimeout`, `el firmware no confirmó a tiempo — pudo haberse ejecutado`);
    }
    if (lf.reason === `network`) {
      return _t(`msg.opCausaRed`, `no se pudo llegar a la máquina (${lf.error}) — revisa el WiFi`, { error: lf.error });
    }
    if (lf.reason === `shield`) {
      // El escudo ya tiene su mensaje canonico y honesto; no lo duplicamos.
      if (typeof window !== `undefined` && window.rotechosShieldMsg
          && typeof window.rotechosShieldMsg.get === `function`) {
        return window.rotechosShieldMsg.get(lf);
      }
      return _t(`msg.opCausaEscudo`, `el escudo de seguridad la bloqueó`);
    }
    return null;
  }

  /** HUECO-3: toast de error que NOMBRA la operacion y su causa real.
   *  Devuelve el texto emitido (util para tests y para log). */
  function opFail(op, lf) {
    const fallo = (lf !== undefined)
      ? lf
      : ((typeof RRF !== `undefined` && RRF && RRF._lastFail) || null);
    const nombre = _nombre(op);
    const porQue = causa(fallo);
    // Sin causa registrada NO se inventa una: se dice que fallo y que no se
    // sabe por que. Es peor un motivo falso que un «no se sabe» honesto.
    const msg = porQue
      ? `${_t(`msg.opFalloPrefijo`, `No se pudo`)} ${nombre}: ${porQue}`
      : `${_t(`msg.opFalloPrefijo`, `No se pudo`)} ${nombre} — ${_t(`msg.opFalloSinCausa`, `sin causa registrada; reintenta y revisa la conexión con la máquina`)}`;
    _toast(msg, `err`);
    _log(msg, `err`);
    return msg;
  }

  /** HUECO-2: aviso de que una operacion SIGUE en curso.
   *  Programa el aviso al umbral y devuelve `cancelar()`. Si la operacion
   *  responde antes, `cancelar()` impide que se pinte: no hay espera fija ni
   *  toast tardio sobre algo que ya termino. */
  function opSlow(op, ms) {
    const nombre = _nombre(op);
    const umbral = (typeof ms === `number` && ms >= 0) ? ms : SLOW_MS;
    let pintado = false;
    const id = setTimeout(() => {
      pintado = true;
      _toast(`${nombre} ${_t(`msg.opLentaSufijo`, `está tardando — sigue en curso, no repitas la orden`)}`, `info`);
    }, umbral);
    return function cancelar() {
      clearTimeout(id);
      return pintado;
    };
  }

  /** Une los dos: envuelve una promesa, avisa si tarda, y si el resultado es
   *  un fallo (null/false, que es como `RRF.gcode` reporta fallo) emite el
   *  toast con causa. Devuelve lo que devolviera `fn`, sin alterarlo — quien
   *  llame sigue decidiendo que hacer con el resultado. */
  async function opRun(op, fn, ms) {
    const cancelar = opSlow(op, ms);
    try {
      const r = await fn();
      cancelar();
      // `RRF.gcode` devuelve null en fallo; FM.upload / cfgWrite devuelven
      // false. Ambos son «no salio bien» y ambos dejan (o no) `_lastFail`.
      if (r === null || r === false || r === undefined) opFail(op);
      return r;
    } catch (e) {
      cancelar();
      // Una excepcion no pasa por `_lastFail`; se reporta con lo que se sabe.
      opFail(op, { reason: `network`, error: String((e && (e.message || e.name)) || e) });
      throw e;
    }
  }

  if (typeof window !== `undefined` && typeof window.rotechosOpFeedback === `undefined`) {
    window.rotechosOpFeedback = { opFail, opSlow, opRun, causa, SLOW_MS };
  }
})();
