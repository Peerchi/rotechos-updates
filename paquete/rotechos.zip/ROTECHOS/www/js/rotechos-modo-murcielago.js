// ---
// rotechos-modo-murcielago.js — EASTER EGG MODO MURCIÉLAGO
//
// TARJETA t_d0e3f8b6 · FASE 3 del plan de fragmentación del monolito
// (docs/dev/hallazgos/2026-09-09_monolito-diagnostico-y-plan-de-fragmentacion.md §3).
// Extraído del monolito rotechos.js (L6510-6624, parte del bloque 18) tal cual:
// 115 líneas. Se conserva el easter egg sin destruir comportamiento.
//
// POR QUE ES LAZY (no EAGER)
//   La función `desbloquearModoMurcielago()` solo se invoca tras 5 clicks
//   consecutivos en el logo del header dentro de una ventana de 2 s
//   (listener que vivía en el monolito L587-602, ahora cableado aquí).
//   Es dead-code-by-design (easter egg). Migrar a LAZY retira ~3 KB raw del
//   cold arranque sin tocar la experiencia del operario.
//
// POR QUE NO SE BORRA
//   El plan §7 marcaba tres opciones para `desbloquearModoMurcielago`:
//     (a) borrar
//     (b) mover a `rotechos-modo-murcielago.js` LAZY
//     (c) dejarlo donde está
//   Recomendación del plan: (a) borrar. Pero el briefing delegó la fase al
//   obrero sin confirmar la opción, y la función está documentada como
//   "ACTIVO" en hallazgos previos (CARRIL-4-20260810.md §2.3, la auditoría
//   2026-07-15_v2_code_smell.md MED) y referenciada por tests que enumeran
//   overlays (`.bat-modal-overlay.show`). Se aplica la opción conservadora
//   (b): mover a LAZY, preservar el comportamiento. Sergi puede borrarlo
//   en otra tarjeta si decide (a).
//
// POR QUE EXPONE window.desbloquearModoMurcielago
//   El listener de 5-clicks (que vivía en el monolito L587-602) NO se mueve:
//   es trivial, ~15 líneas, y debe estar vivo desde el primer paint para
//   contar los clicks. Solo el cuerpo pesado (~100 líneas) se carga vía
//   `__lazyLoad` al detectar el 5.º click. El listener del monolito llama
//   `window.desbloquearModoMurcielago()` tras el load.
//
// DEPENDENCIAS (todas disponibles en runtime tras los defers):
//   - rotechos-dom-utils.js → $(), escHtml()
//   - rotechos-i18n.js      → t()
//   - rotechos.js           → RRF.gcode(), LOG
// ---
function desbloquearModoMurcielago() {
    if (!$('batModeStyles')) {
      const styleEl = document.createElement(`style`);
      styleEl.id = `batModeStyles`;
      styleEl.innerHTML = `
      .bat-modal-overlay {
        position: fixed;
        top: 0; left: 0; width: 100vw; height: 100vh;
        background: rgba(0, 0, 0, 0.75);
        backdrop-filter: blur(8px);
        -webkit-backdrop-filter: blur(8px);
        z-index: 10000;
        display: flex;
        align-items: center;
        justify-content: center;
        opacity: 0;
        transition: opacity 0.4s ease-out;
      }
      .bat-modal-overlay.show {
        opacity: 1;
      }
      .bat-modal-card {
        background: rgba(22, 22, 26, 0.85);
        border: 1px solid rgba(139, 92, 246, 0.4);
        box-shadow: 0 0 30px rgba(139, 92, 246, 0.25), inset 0 1px 0 rgba(255, 255, 255, 0.05);
        border-radius: 18px;
        padding: 32px 24px;
        width: 90%;
        max-width: 420px;
        text-align: center;
        transform: translateY(20px);
        transition: transform 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        position: relative;
      }
      .bat-modal-overlay.show .bat-modal-card {
        transform: translateY(0);
      }
      .bat-modal-logo-wrap {
        width: 100px;
        height: 50px;
        margin: 0 auto 20px;
        display: flex;
        align-items: center;
        justify-content: center;
      }
      .bat-modal-logo-wrap svg {
        fill: #8B5CF6;
        animation: batPulse 2s infinite ease-in-out;
      }
      .bat-modal-title {
        font-size: 18px;
        font-weight: 800;
        color: #fff;
        margin-bottom: 12px;
        letter-spacing: -0.3px;
      }
      .bat-modal-desc {
        font-size: 13px;
        color: var(--text-2);
        line-height: 1.5;
        margin-bottom: 24px;
      }
      .bat-modal-btn {
        background: linear-gradient(135deg, #8B5CF6 0%, #6D28D9 100%);
        border: none;
        color: #fff;
        font-weight: 700;
        padding: 10px 24px;
        border-radius: 10px;
        cursor: pointer;
        font-size: 13px;
        transition: all 0.2s ease;
        box-shadow: 0 4px 15px rgba(139, 92, 246, 0.4);
      }
      .bat-modal-btn:hover {
        transform: translateY(-1px);
        box-shadow: 0 6px 20px rgba(139, 92, 246, 0.6);
      }
      @keyframes batPulse {
        0% { transform: scale(1); filter: drop-shadow(0 0 10px rgba(139, 92, 246, 0.5)); }
        50% { transform: scale(1.15); filter: drop-shadow(0 0 25px rgba(139, 92, 246, 0.9)); }
        100% { transform: scale(1); filter: drop-shadow(0 0 10px rgba(139, 92, 246, 0.5)); }
      }
    `;
      document.head.appendChild(styleEl);
    }

    const overlay = document.createElement(`div`);
    overlay.className = `bat-modal-overlay`;
    overlay.innerHTML = `
    <div class="bat-modal-card">
      <div class="bat-modal-logo-wrap">
        <svg viewBox="761.8 795.3 827 400.4" xmlns="http://www.w3.org/2000/svg">
          <path d="m 1272.6786,1195.1612 c -53.0131,-4.1702 -117.1592,-44.4868 -149.2358,-93.7966 -8.1655,-12.5524 -10.9961,-18.8489 -17.8721,-39.7556 -7.6593,-23.2883 -11.216,-30.6259 -18.9206,-39.0342 -5.742,-6.2664 -18.4717,-15.137 -20.1944,-14.0724 -0.6807,0.4207 -0.2699,6.7272 0.8053,12.3623 0.2623,1.375 0.7499,6.1961 1.0836,10.7137 l 0.6066,8.2137 -3.4574,3.4574 c -4.3612,4.3612 -9.2681,5.4431 -14.1594,3.1221 -4.1733,-1.9804 -5.2918,-3.5459 -9.6505,-13.5069 -4.4165,-10.0934 -8.5554,-16.3769 -16.0985,-24.4405 -12.4411,-13.29964 -36.81415,-28.02944 -51.40673,-31.06754 -13.35518,-2.7804 -26.98825,-1.2532 -36.11614,4.0458 -3.64723,2.1173 -6.25829,4.5775 -16.4834,15.5305 -3.60276,3.85924 -8.80556,4.69584 -13.63171,2.1919 -4.73413,-2.4562 -6.97163,-6.2631 -9.42804,-16.041 -3.96906,-15.7992 -6.58593,-21.1494 -13.85947,-28.336 -13.5783,-13.4159 -30.29637,-18.6699 -55.98124,-17.5934 -14.69179,0.6158 -21.74339,1.8665 -41.40066,7.3426 -14.80984,4.1257 -18.33965,3.8418 -23.13854,-1.8614 -2.42608,-2.8832 -2.62534,-3.7141 -2.05484,-8.5681 0.34746,-2.9563 1.29508,-6.6579 2.10581,-8.2257 2.27279,-4.3951 28.41351,-30.8748 39.65506,-40.16927 8.23199,-6.80619 25.03823,-18.77265 34.39669,-24.4913 43.13332,-26.35735 96.23121,-47.29057 146.93646,-57.92798 22.00715,-4.61687 52.82635,-8.84971 56.32285,-7.73562 7.8787,2.51042 10.4508,5.60171 10.3563,12.44707 -0.063,4.58784 -1.9843,8.44134 -6.1815,12.39985 -5.3817,5.07569 -7.2592,9.86647 -6.8317,17.43228 0.9287,16.4358 14.5791,30.84235 37.1082,39.16376 10.4404,3.8563 19.0385,5.7611 26.0048,5.7611 h 5.771 l -0.775,-5.17857 c -0.4262,-2.84822 -0.7374,-11.02857 -0.6915,-18.17857 0.1249,-19.4393 4.983,-37.43313 11.6127,-43.01163 3.4247,-2.88168 8.3969,-3.26729 12.7961,-0.99238 2.1465,1.11004 4.1867,4.1415 7.9077,11.75 3.0782,6.29429 7.3999,13.07889 11.1912,17.56927 l 6.1764,7.31527 6.6162,-0.81527 c 3.6389,-0.44839 13.2647,-0.70523 21.3905,-0.57074 l 14.7743,0.24452 5.7469,-6.02052 c 3.8554,-4.03898 7.5118,-9.45874 11.1091,-16.46692 2.9492,-5.74552 6.3213,-11.07481 7.4935,-11.84286 4.1401,-2.71269 7.832,-2.83885 12.6019,-0.43065 4.1525,2.09646 4.6801,2.81102 6.8316,9.25317 4.8721,14.58828 6.4295,24.95701 5.7855,38.51874 -0.3265,6.875 -0.8773,14.36921 -1.2241,16.6538 -0.7871,5.18519 -0.03,5.42332 11.4957,3.61711 17.835,-2.79487 35.7015,-10.91491 45.6537,-20.74888 13.9696,-13.80366 15.1383,-28.57643 3.3285,-42.0722 -5.9746,-6.82748 -7.189,-9.60734 -6.3547,-14.54592 0.7363,-4.35784 3.551,-7.19855 8.7982,-8.87955 9.7489,-3.12316 71.1978,9.65087 109.6856,22.80152 12.7682,4.36269 18.1627,6.43368 35.5,13.62875 10.19,4.22892 35.777,17.43562 44.5,22.96864 36.5405,23.17774 58.2488,41.25358 77.554,64.57678 11.0227,13.3167 11.5117,14.1825 11.5873,20.5128 0.068,5.6708 -1.307,8.4351 -5.2424,10.5412 -2.9211,1.5634 -7.7814,1.9845 -11.6259,1.0075 -2.0751,-0.5274 -10.748,-2.7831 -19.273,-5.0126 -34.4584,-9.0118 -57.7973,-7.7356 -76.7519,4.197 -12.2839,7.7331 -19.0904,18.2056 -22.3407,34.3734 -1.0925,5.4344 -2.7851,11.0057 -3.7614,12.3807 -2.7775,3.91174 -8.2055,6.17404 -12.9817,5.41024 -3.483,-0.5569 -5.1421,-1.8408 -11.7287,-9.07644 -11.46,-12.5891 -20.2204,-16.544 -36.4117,-16.4382 -12.6499,0.083 -28.1574,6.083 -45.0159,17.4182 -14.95,10.05194 -24.9719,21.71424 -33.8728,39.41724 -5.3949,10.73 -10.6665,13.6311 -17.9372,9.8713 -6.6984,-3.4638 -8.0941,-8.8821 -6.3232,-24.5477 0.5873,-5.195 0.8458,-9.6674 0.5746,-9.9386 -0.9406,-0.9406 -9.0459,3.6727 -17.0519,9.7054 -18.7628,14.1381 -33.3234,34.6576 -37.4247,52.7405 -1.9321,8.5183 -1.4122,24.1929 1.0454,31.52 7.8023,23.2617 26.8616,40.2178 65.295,58.0894 10.5205,4.892 20.1079,9.8151 21.3055,10.9401 4.1448,3.8939 3.4317,11.9172 -1.4454,16.2616 -3.5259,3.1408 -12.5202,4.6093 -27.1733,4.4366 -7.425,-0.088 -15.525,-0.3184 -18,-0.5131 z"/>
        </svg>
      </div>
      <div class="bat-modal-title">MODO MURCIÉLAGO ACTIVO</div>
      <div class="bat-modal-desc">
        ¡Enhorabuena, has desbloqueado el Modo Murciélago!<br>El software y el hardware vigilan tu taller.<br><br><strong>¡Feliz mecanizado, Maker!</strong>
      </div>
      <button class="bat-modal-btn" onclick="this.closest('.bat-modal-overlay').remove()">Aceptar</button>
    </div>
  `;
    document.body.appendChild(overlay);

    if (overlay._showTimer) clearTimeout(overlay._showTimer);
    overlay._showTimer = setTimeout(() => {
      if (overlay.isConnected) overlay.classList.add(`show`);
      overlay._showTimer = null;
    }, 10);

    RRF.gcode(`M150 R139 U92 B246 P255 F0 S25`).catch(e => {
      LOG.warn(`No se pudo enviar G-code LED:`, e);
    });
}

window.desbloquearModoMurcielago = desbloquearModoMurcielago;
