// Invocados desde index.html (window.updateUI, data-act="ZCAL.*",
// oninput/onclick del pendant) o desde módulos extraídos que cargan
// después (rotechos-backup.js → setupDragAndDrop, rotechos-fm.js → sleep)
// — ESLint no ve esos usos:
/* exported updateUI, ZCAL, pendantSetSpTarget, pendantExecMacro, setupDragAndDrop, sleep */
// ---
// APP STATE — Estado centralizado de la aplicación
// Sustituye los window._* dispersos por un objeto estructurado.
// ---
const AppState = {
  macro:  { running:false, paused:false, name:``, row:null, detectCnt:0, cancelPendiente:null, enB:false, lanzadaEn:0 },
  bord:   { active:false, paused:false, cancel:null, pause:null, resume:null },
  limits: { triggers:null, allHomed:undefined, prevHit:{}, alarmActive:false, bootGrace:0, dialogOpen:false },
  tab:    { isLeader:null, id:``, bc:null, warned:false },
  sys:    { _reloadScheduled:false, m999InProgress:false, m999Watcher:null, startupErrShown:false },
  ui:     { mcfgDirtyClear:null, mpgGetCoordMode:null },
  // Estado del ciclo de poll (Sprint 4 f2: el cuerpo vive en rotechos-poll.js).
  // gen: generación del sondeo. La avanzan los cambios de estado de la interfaz
  // (bumpGen) y _pollRun descarta el ciclo que empezó antes.
  poll:   { active:false, cycle:0, latencyMs:0, fails:0, busyTs:0, gen:0,
            bumpGen() { this.gen += 1; return this.gen; } },
  // Caché del object model por ciclo de poll. Guarda el último valor bueno de
  // cada clave para que un ciclo que no la pide (o que falla) siga pintando el
  // dato anterior en vez de vaciar la UI. Sprint 4 f2: vive aquí y no en
  // variables sueltas del monolito, para que el poll pueda salir a su módulo.
  // softLimits/machinePos/softLimitsEnabled: los actualiza el poll cada ciclo;
  // el enforcement del jog (rotechos-jog.js) y el config-modal los leen/escriben
  // por los PUENTES de window declarados justo debajo. endstopCfg lo puebla
  // rotechos-config-modal.js al cargar (mismo objeto, ver su línea ~62).
  cache:  { boards:null, endstops:null, network:null, gpIn:null, spindles:null, probes:null,
            softLimits: { X:{min:null,max:null}, Y:{min:null,max:null}, Z:{min:null,max:null}, A:{min:null,max:null} },
            softLimitsEnabled: true,
            machinePos: { X:0, Y:0, Z:0, A:0 },
            // Offsets del WCS ACTIVO por eje — `workplaceOffsets[move.workplaceNumber]` (27-sep; antes G54 fijo)
            // del object model. Necesarios para el chequeo previo del visor 3D:
            // comparar coordenada_de_fichero + wcsOffset contra los soft limits
            // (que están en MCS). Sin esto, un fichero que va de X0 a X300 con
            // cero en X300 da VERDE cuando debería dar ROJO (llega a X600 fuera
            // del recorrido de 530). Lo puebla el poll en cada ciclo (rotechos-poll.js).
            wcsOffsets: { X:0, Y:0, Z:0, A:0 },
            // global.homingInProgress del firmware. El poll ya lo leía, pero lo
            // dejaba morir dentro del ciclo: ningún handler podía consultarlo.
            // Lo necesita el guard de btnRecover (un RECUPERAR durante un homing
            // rearma triggers que la rutina había suspendido a propósito), y el
            // homing NO es un estado de SM: ocurre estando en IDLE o READY.
            homingInProgress: false,
            endstopCfg: null },
};
window.AppState = AppState;
// ── Puentes de compatibilidad (Sprint 4 f2) ─────────────────────────────
// El clamp del jog (rotechos-jog.js:230-287), el config-modal y sus tests
// (tests/unit/do-jog-step.test.js, que inyectan estos nombres POR NOMBRE)
// siguen usando los identificadores sueltos. Son accessors VIVOS sobre
// AppState.cache — una sola fuente de verdad, cero cambios en el enforcement.
// ⚠️ PENDIENTE BANCO: validar el clamp del jog en máquina real tras esta
// migración (ejes sin homing y M564 S0) antes de darla por buena.
Object.defineProperty(window, `_softLimits`, { get: () => AppState.cache.softLimits });
Object.defineProperty(window, `_machinePos`, { get: () => AppState.cache.machinePos });
// Cero de pieza del WCS activo por eje — `workplaceOffsets[move.workplaceNumber]` (27-sep; antes G54 fijo).
// El chequeo previo del visor 3D lo usa para convertir coordenadas de FICHERO
// (lo que hay en el G-code) a coordenadas de MÁQUINA antes de comparar contra
// los soft limits. Sin este puente el chequeo mide en el sistema equivocado
// (ver CLAUDE.md §4 y t_717c48cc). Read-only a propósito: solo el poll lo
// escribe (rotechos-poll.js:160-169).
Object.defineProperty(window, `_wcsOffsets`, { get: () => AppState.cache.wcsOffsets });
Object.defineProperty(window, `_softLimitsEnabled`, {
  get: () => AppState.cache.softLimitsEnabled,
  set: (v) => { AppState.cache.softLimitsEnabled = v; },
});

// ---
// DOM ALIASES
// ---
const $ = (id) => document.getElementById(id);
const $$ = (sel) => document.querySelectorAll(sel);
// setText / setVal / bindFastTouch / machineMoveBlocked / setupDragAndDrop
// viven ahora en rotechos-dom-helpers.js (extraído del monolito, tarjeta
// kanban t_82625155, ago-2026, bloques 3/4/5 del re-mapeo). El módulo
// se carga ANTES de este script en index.html (entre rotechos-gcode-map.js
// y este), así que cuando el monolito se evalúa los símbolos ya están
// disponibles en el global lexical env. Los puentes locales siguientes
// preservan los nombres como const del closure del monolito, de modo
// que las 31 invocaciones internas (setText en líneas 1156/1162/1423-25/
// 1745/1752-53/1841/3116/3127, machineMoveBlocked en 2998/4105/4138/4152/
// 4169/4192/4448/4520/4658/4662-63/4666-68, bindFastTouch en 4719-20)
// siguen funcionando sin tocarlas.
const setText = window.setText;
const setVal = window.setVal; // eslint-disable-line no-unused-vars -- usado por global desde rotechos-config-modal.js
const bindFastTouch = window.bindFastTouch;
const machineMoveBlocked = window.machineMoveBlocked;
const setupDragAndDrop = window.setupDragAndDrop; // eslint-disable-line no-unused-vars -- usado por rotechos-backup.js:278

window.UI_ACTIONS = {};
// H6 (PESO-6, 2026-08-18): consolida los enganches sueltos de DOMContentLoaded
// y load del monolito en un único boot() llamado desde un solo listener por
// evento. Antes había 5 DOMContentLoaded + 1 load desperdigados (líneas 91,
// 283, 481, 3790, 4220 + 291), en orden de registro accidental. Aquí los
// 6 cuerpos viven en orden explícito dentro de window.boot.init / registerSW
// y se enganchan al final del script (ver bloque "BOOT CONSOLIDADO" más
// abajo). Esta función es la pieza 1/5 (era línea 91): click delegate en
// body + anotación A11Y de modales + role=alert/aria-live en #endstopOverlay.
function __bootStep1_clickDelegateAndA11y() {
  document.body.addEventListener('click', async (e) => {
    const btn = e.target.closest('button[id], a[id]');
    if (!btn || btn.disabled) return;
    if (window.UI_ACTIONS[btn.id]) {
      e.preventDefault();
      try {
        await window.UI_ACTIONS[btn.id](e, btn);
      } catch (err) {
        LOG.error('UI_ACTION error:', err);
      }
    }
  });
  // FIX-A11Y-01 · D-02: añadir role=dialog + aria-modal=true a TODOS los
  // .modal-overlay del shell. El spec e2e-fix-carril-2:74 cuenta 17 elementos
  // exactos con esa clase (los 16 declarados con class=modal-overlay sin
  // comillas + #mobileErrorOverlay con class="modal-overlay" entre comillas;
  // #fwMessageModal usa tc-modal-overlay, otra familia, queda fuera). El
  // MutationObserver cubre también modales inyectados en runtime.
  const annotateModals = () => {
    document.querySelectorAll('.modal-overlay').forEach((el) => {
      if (!el.hasAttribute('role')) el.setAttribute('role', 'dialog');
      if (!el.hasAttribute('aria-modal')) el.setAttribute('aria-modal', 'true');
    });
  };
  annotateModals();
  new MutationObserver(annotateModals).observe(document.body, {
    childList: true,
    subtree: true,
  });
  // FIX-A11Y-01 · D-04: #endstopOverlay anuncia cambios con role=alert +
  // aria-live=assertive (lectores de pantalla lo interrumpen y lo leen ya).
  const _endstopOv = document.getElementById('endstopOverlay');
  if (_endstopOv) {
    _endstopOv.setAttribute('role', 'alert');
    _endstopOv.setAttribute('aria-live', 'assertive');
  }
}

// MACROS y FALLBACK_SEDA se han extraído a ROTECHOS/www/js/rotechos-const.js
// (tarjeta t_4d48a09a, 2026-08-11, bloques #9 y #10 del re-mapeo). El módulo
// se carga con <script defer> ANTES que este monolito y expone `window.MACROS`
// y `window.FALLBACK_SEDA`. Puente local para mantener el contrato interno:
//
//   - `FALLBACK_SEDA`: tests/unit/lint-gcode.test.js:282 verifica literalmente
//     `SOURCE.includes('const FALLBACK_SEDA = ')` sobre el contenido de
//     rotechos.js como red defensiva anti-regresión. El puente `const X =
//     window.X` mantiene ese patrón sin tocar el test.
//
//   - `MACROS`: el monolito NO lo redeclara aquí porque su única línea de
//     exposición histórica (`window.MACROS = MACROS`) también se ha movido al
//     módulo defer. Los 11 call sites internos del monolito (L769, L2282,
//     L2823, L3263, L3816, L3827, L4130, L4163, L4181, L4662, L4663) leen
//     `MACROS.x` directamente del global object — funcionan porque el módulo
//     defer se ejecuta antes que el monolito (mismo script global realm).
// FALLBACK_SEDA vive en rotechos-const.js y se expone en window.FALLBACK_SEDA. NO se puede
// hacer `const FALLBACK_SEDA = window.FALLBACK_SEDA` aqui: los scripts clasicos comparten el
// ambito lexico global, asi que ese puente colisiona con el `const` del
// modulo y lanza "Identifier 'FALLBACK_SEDA' has already been declared" — que
// impide ejecutar el monolito ENTERO (2026-08-12).

// F-02 (post-refactor): selector único para los modales abiertos. Antes cada
// handler (V01 de Escape rotechos.js:~2432, BUG-02 de KBSHORTCUTS:5075) usaba
// `.modal-overlay.show` por separado — divergencia propensa a olvidar tipos de
// modal. La auditoría detectó que 2 modales del shell NO usaban .modal-overlay:
//   - tc-modal-overlay (tool change, index.html:2225, css:806)
//   - rm-macros-center-modal (centro de macros, index.html:1842, css:623)
//   - rm-macros-modal (sheet lateral — usado por V01 en L2452 con su propio
//     selector, lo mantengo en la lista por consistencia)
//   - bat-modal-overlay (batería, css:5318, sin handler de cierre por Escape
//     pero sí candidato a bloqueo de atajos cuando visible)
// Con esta constante, ambas familias cubren los 4 tipos de modal y se evita
// que un nuevo modal abra accidentalmente sin estar en el guard.
/* exported MODAL_OPEN_SELECTOR */
const MODAL_OPEN_SELECTOR =
  '.modal-overlay.show, ' +
  '.tc-modal-overlay.show, ' +
  '.rm-macros-modal.show, ' +
  '.rm-macros-center-modal.show, ' +
  '.bat-modal-overlay.show';

// Defensa de segundo nivel para overlays/modal nuevos que todavía no estén en
// MODAL_OPEN_SELECTOR. Los modales del shell usan .show; los overlays lazy (PIN,
// reboot, error) pueden activarse solo con display/aria y no deben dejar pasar
// Escape hasta KBSHORTCUTS. No se usa este fallback para decidir qué elemento
// cerrar: solo responde si la tecla global debe quedar bloqueada.
function hasVisibleModal() {
  if (document.querySelector(MODAL_OPEN_SELECTOR)) return true;
  return Array.from(
    document.querySelectorAll('[role="dialog"], [aria-modal="true"], [id$="Modal"], [id$="Overlay"]'),
  ).some((el) => {
    if (el.matches(MODAL_OPEN_SELECTOR) || el.getAttribute('aria-hidden') === 'true') return false;
    const style = getComputedStyle(el);
    return style.display !== 'none' && style.visibility !== 'hidden';
  });
}

// H3 (post-refactor): lista de símbolos centinela — UNO por cada módulo defer
// crítico del shell. Cada rotechos-*.js (que NO sea rotechos.js el monolito)
// publica al menos uno de estos en window durante su carga. Si uno falta al
// arranque (SD parcial, error de carga, bug de extracción), _checkShellIntegrity
// emite un banner rojo persistente y deshabilita movimiento.
//
// Metodología: 1 símbolo por archivo. Para detectar `FM`/`CFG_FIELDS`/etc.
// como centinelas válidos, basta con que sean `const`/`let`/`function` top-level
// del módulo (los scripts clásicos con <script defer> comparten el script global
// realm — un binding top-level es visible para el resto de scripts sin necesidad
// de `window.X = X`). Verificado por la auditoría 2ª del cruce (Claude jul-2026):
// `typeof FM` en consola contra el mock devuelve 'object'. Por tanto podemos
// auditar estos símbolos aunque no estén exportados formalmente a `window`.
//
// Si añades un módulo defer nuevo, declara al menos un binding top-level
// y AÑADE su centinela aquí — el test shell-integrity.test.js verifica cada
// uno contra TODOS los rotechos-*.js (regex de const/let/function al inicio de
// línea + window.X).
const SHELL_SENTINELS = [
  'LOG',                // rotechos-logger.js → window.LOG = LOG
  'STORE',              // rotechos-storage.js → window.STORE = {...}
  'FM',                 // rotechos-fm.js → const FM = {...} (file manager)
  'LED',                // rotechos-led.js → window.LED = {...}
  // WIZARD, JOBHIST, OTA → PESO-5 (2026-08-18): carga perezosa via
  // __lazyLoad al activar la pestaña/click. NO entran en el shell inicial.
  'SPINDLE',            // rotechos-spindle.js → window.SPINDLE = {...}
  'I18N',               // rotechos-i18n.js (runtime i18n)
  'ROTECHOS',           // rotechos-version.js → window.ROTECHOS = {...} (VERSION+BUILD+PILLAR)
  'CFG_FIELDS',         // rotechos-config-modal-core.js → window.CFG_FIELDS = {...} (shim EAGER del modal perezoso, t_b8cd40c2) ⚠️ CRÍTICO: ausencia aquí = endstops mueren callados
  // HW_LIMITS y el resto del CFG_FIELDS extendidos viven en
  // rotechos-config-modal.js (LAZY) — fuera del shell inicial.
  // Se quitaron de SHELL_SENTINELS en t_b8cd40c2 para no marcar como
  // "módulo ausente" un símbolo que SOLO existe tras el primer click
  // en CONFIGURACIÓN. La auditoría B1 ya documentó esa trampa.
  'parseRotechPills',   // rotechos-config-modal-core.js → shim EAGER; parser único del SSOT de endstops (`; rotech-pills=`)
  'cfgProbeGuard',      // rotechos-config-modal-core.js → shim EAGER ⚠️ CRÍTICO: es la guarda
                        // de HOME y trabajo-en-marcha de la sonda Z y del cambio de
                        // herramienta. Sus dos consumidores la llaman con
                        // un typeof-y-negacion, patron FAIL-OPEN: si el simbolo falta,
                        // no bloquea nada y la maquina baja la sonda o va a la posicion
                        // de aparcamiento del SAC sin referencia. Su ausencia tiene que
                        // gritar en el arranque, no descubrirse contra la mesa.
  'openMachineConfig',  // rotechos.js:3850 → window.openMachineConfig = proxy perezoso; el modal (LAZY) lo sobrescribe al primer open
  'cfgRead',            // rotechos-config-persist.js → const cfgRead = ...
  'cfgWrite',           // rotechos-config-persist.js → const cfgWrite = ...
  'updateOvBar',        // rotechos-jog.js → function updateOvBar (exportado)
  'updateJogFeedEffective', // rotechos-jog.js → function updateJogFeedEffective (exportado)
  'vizLoadGCode',       // rotechos-viz.js → function vizLoadGCode (exportado)
  'renderMacros',       // rotechos-macros.js → function renderMacros (exportado)
  'macrosRestoreCustom', // rotechos-macros.js → function macrosRestoreCustom (exportado)
  'sendNotif',          // rotechos-notif.js (WIP ajeno: la función se publica al módulo, se conserva el centinela como promesa de SSOT futuro)
  'POLL',               // rotechos-poll.js → const POLL = window.POLL ⚠️ CRÍTICO: sin él no hay telemetría ni vigilancia de endstops
  'TELEMETRY',          // rotechos-telemetry.js → window.TELEMETRY (FASE 6). Si falta, el `try/catch` del IIFE de arranque se come el error y la UI muestra datos viejos sin avisar.
  'WCS',                // rotechos-wcs.js → const WCS = window.WCS (ceros WCS X/Y/Z/ALL)
  'WLC',                // rotechos-welcome.js → window.WLC (wizard de bienvenida)
  'FIRST_CUT',          // rotechos-firstcut.js → const FIRST_CUT = window.FIRST_CUT (checklist primer corte)
  'macroNecesitaConfirmacion', // rotechos-const.js → SSOT de R-02 ⚠️ CRÍTICO: si falta,
                        // las cuatro superficies de macros lanzan M98 SIN preguntar y
                        // sin ruido — el mismo modo de fallo silencioso que CFG_FIELDS.
];

// H3: chequeo de integridad del shell. Llamada desde DOMContentLoaded
// y desde el init de KBSHORTCUTS (redundante, defensa en profundidad).
// Si un símbolo falta: log con la lista + banner rojo en topbar.
// NO aborta el shell — los fallbacks `typeof X === 'function'` siguen
// protegiendo cada call-site individualmente.
// ⚠️ H3-fix (auditor, 2026-07-12): la versión inicial hacía `typeof window[sym]`
// dinámico — pero los centinelas declarados con const/let top-level (FM,
// CFG_FIELDS, HW_LIMITS, cfgRead, cfgWrite…) son bindings LÉXICOS globales que
// NO viven en window: solo `typeof identificador` LITERAL los ve. El lookup
// dinámico los daba SIEMPRE por ausentes → banner rojo en cada arranque
// (cazado por e2e test 1 y K2: el banner interceptaba el click del kinBadge).
// eval/new Function están vetados por lint (con razón), así que la única vía
// es esta tabla de typeof literales — mantener 1:1 con SHELL_SENTINELS.
const SHELL_SENTINEL_CHECKS = {
  LOG: () => typeof LOG,
  STORE: () => typeof STORE,
  FM: () => typeof FM,
  LED: () => typeof LED,
  // WIZARD/JOBHIST/OTA: lazy — PESO-5 (2026-08-18). El check es en frío:
  // durante el startup no existen todavía, eso es correcto.
  SPINDLE: () => typeof SPINDLE,
  I18N: () => typeof I18N,
  ROTECHOS: () => typeof ROTECHOS,
  CFG_FIELDS: () => typeof CFG_FIELDS,
  parseRotechPills: () => typeof parseRotechPills,
  cfgProbeGuard: () => typeof cfgProbeGuard,
  openMachineConfig: () => typeof openMachineConfig,
  macroNecesitaConfirmacion: () => typeof macroNecesitaConfirmacion,
  cfgRead: () => typeof cfgRead,
  cfgWrite: () => typeof cfgWrite,
  updateOvBar: () => typeof updateOvBar,
  updateJogFeedEffective: () => typeof updateJogFeedEffective,
  vizLoadGCode: () => typeof vizLoadGCode,
  renderMacros: () => typeof renderMacros,
  macrosRestoreCustom: () => typeof macrosRestoreCustom,
  sendNotif: () => typeof sendNotif,
  POLL: () => typeof POLL,
  TELEMETRY: () => typeof window.TELEMETRY,
  WCS: () => typeof WCS,
  WLC: () => typeof window.WLC,
  FIRST_CUT: () => typeof FIRST_CUT,
};
function _checkShellIntegrity() {
  if (typeof window === 'undefined') return; // defensivo (tests en Node no tienen window)
  const missing = [];
  for (const sym of SHELL_SENTINELS) {
    const chk = SHELL_SENTINEL_CHECKS[sym];
    // Centinela sin checker = error de mantenimiento de la tabla: se reporta
    // como ausente para que el desalineamiento no pase en silencio.
    if (!chk || chk() === 'undefined') missing.push(sym);
  }
  if (missing.length === 0) return;
  // Log detallado (auditoría post-mortem).
  LOG.error(`SHELL INTEGRITY — módulos ausentes (${missing.length}): ${missing.join(', ')}`);
  // Banner rojo persistente en la topbar (#topbar o fallback body).
  // NO aborta — el shell sigue vivo, pero el operario ve claramente que algo
  // no cargó y puede reportarlo.
  // BUG 2026-09-06: esto era `let bn = $('shellIntegrityBanner'); if (!bn) { crear
  // y rellenar }`. Pero index.html:3244 ya trae un `<span
  // id=shellIntegrityBanner></span>` VACIO, asi que `bn` siempre existia, el
  // bloque nunca se ejecutaba y EL AVISO NO SALIA NUNCA. Un modulo que no
  // cargue dejaba al operario sin enterarse: solo quedaba el LOG.error.
  //
  // Medido en el navegador antes de tocarlo: el elemento existe, innerHTML
  // vacio, offsetParent null (invisible), display inline.
  //
  // Ahora se rellena el que haya y se crea solo si falta. Es una red de
  // seguridad: tiene que poder saltar.
  let bn = $('shellIntegrityBanner');
  if (!bn) {
    bn = document.createElement('div');
    bn.id = 'shellIntegrityBanner';
    document.body.appendChild(bn);
  }
  bn.style.cssText = 'position:fixed;top:0;left:0;right:0;z-index:99992;background:linear-gradient(90deg,#7a1a1a,#a32525);color:#fff;padding:8px 16px;display:flex;align-items:center;justify-content:center;gap:12px;font-weight:700;font-size:12px;letter-spacing:.5px;box-shadow:0 2px 8px rgba(0,0,0,.5)';
  bn.innerHTML = `<span>⚠ Instalación incompleta — ${missing.length} módulo(s) ausente(s): ${missing.join(', ')}</span><button id="shellIntegrityReloadBtn" style="background:#fff;color:#7a1a1a;border:none;border-radius:4px;padding:4px 10px;font-weight:800;cursor:pointer">RECARGAR</button>`;
  $('shellIntegrityReloadBtn')?.addEventListener('click', () => location.reload());
}

// H6 (PESO-6, 2026-08-18): _checkShellIntegrity() se invoca desde boot.init()
// (la pieza 2/5 del BOOT CONSOLIDADO, abajo). El chequeo de integridad se
// ejecuta cuando todos los <script defer> han terminado (DOMContentLoaded
// garantizada). El comentario viejo decía "también desde el init de
// KBSHORTCUTS, redundante pero captura errores tempranos" — eso lo conservó
// KBSHORTCUTS por su cuenta; aquí solo documentamos que ya no enganchamos
// un listener suelto para esto.


// ── Service Worker registration ──────────────────────────────────────────────
// H6 (PESO-6, 2026-08-18): el listener suelto de `load` se ha movido al
// BOOT CONSOLIDADO (abajo). Aquí dejamos solo el cuerpo como función
// invocable. Se llama desde boot.registerSW(), enganchada al único
// window.addEventListener("load", ...) que sobrevive.
function __bootStepSW_register() {
  if (!("serviceWorker" in navigator)) return;
  // updateViaCache:'none' — el navegador NO puede servir /sw.js desde su caché
  // HTTP al comprobar actualizaciones. Sin esto, si el servidor de la Scylla
  // devuelve sw.js cacheable, el cliente actualiza RotechOS y sigue arrancando
  // el Service Worker VIEJO, que sigue sirviendo la interfaz anterior: el
  // síntoma "he actualizado y no ha cambiado nada" (el que más soporte genera).
  // Verificado en la ola 4: con la caché HTTP por medio, reg.update() no
  // llegaba a re-descargar el script y el activate del SW nuevo nunca corría.
  navigator.serviceWorker.register("/sw.js", { scope: "/", updateViaCache: "none" })
    .then((reg) => {
      reg.addEventListener("updatefound", () => {
        const newWorker = reg.installing;
        if (newWorker) {
          newWorker.addEventListener("statechange", () => {
            if (newWorker.state === "installed" && navigator.serviceWorker.controller) {
              // Banner persistente con botón "Recargar" — el toast se desvanecía y el
              // operario podía seguir usando la versión vieja sin enterarse.
              let bn = $("swUpdateBanner");
              if (!bn) {
                bn = document.createElement("div");
                bn.id = "swUpdateBanner";
                bn.style.cssText = "position:fixed;left:0;right:0;bottom:0;z-index:99991;background:linear-gradient(90deg,#0e3a82,#1259c4);color:#fff;padding:10px 16px;display:flex;align-items:center;justify-content:center;gap:14px;font-weight:700;font-size:13px;letter-spacing:.3px;box-shadow:0 -4px 16px rgba(0,0,0,.4);font-family:var(--font,inherit)";
                bn.innerHTML =
                  '<span>' + t("msg.newUpdateReload","Nueva versión instalada.") + '</span>' +
                  '<button id="swUpdateBtn" style="background:#fff;color:#0e3a82;border:none;border-radius:6px;padding:7px 14px;font-weight:800;cursor:pointer;letter-spacing:.5px">' + t("btn.reloadNow","RECARGAR") + '</button>';
                document.body.appendChild(bn);
                $("swUpdateBtn").addEventListener("click", () => location.reload());
              }
            }
          });
        }
      });
    })
    .catch(() => {});
}

// ── Block A: MPG ──────────────────────────────────────────────────────
// --- MPG Mejoras: toggle MCS/WCS, pasos grandes ---
// B2: el handler de pills .x-step (paso inicial = active, click → textContent) se
// ha ELIMINADO de este IIFE porque bindFastTouch() (que usa) registra un 'click'
// con e.stopPropagation() que cancela los handlers enganchados después, incluido
// el del initMPG (que SÍ actualiza correctamente el span
// #mpgStepValue). El initMPG queda como único handler de pills; las
// pills ya vienen con .active en el HTML estático (data-step=1), así que no
// necesitamos lógica de "paso inicial" aquí.
// H-5 IDs retirados en rediseño pendant jul-2026: mpgDroTitle, mpgBtnZeroXY,
// mpgBtnZeroZ, mpgBtnSpindleOn/Off, mpgBtnFiles, mpgBtnConfig, mpgBtnSonda,
// mpgBtnLibre, mpgBtnSoftStop, mpgBtnMacros, mpgFeedOv, mpgFeedOvVal.
// Ver: docs/dev/hallazgos/2026-08-17_busca-el-pendant-movil-como-producto-v1.md §5
(function () {
  // Toggle MCS/WCS
  let mpgCoordMode = "WCS";
  const mpgWCS = $(`mpgWCS`);
  const mpgMCS = $(`mpgMCS`);
  function updateMpgCoordMode() {
    if (mpgCoordMode === "WCS") {
      mpgWCS.classList.add("active");
      mpgMCS.classList.remove("active");
      mpgMCS.style.display = "";
      mpgWCS.style.display = "";
    } else {
      mpgWCS.classList.remove("active");
      mpgMCS.classList.add("active");
      mpgMCS.style.display = "";
      mpgWCS.style.display = "";
    }
  }
  mpgWCS.addEventListener("click", () => {
    mpgCoordMode = "WCS";
    updateMpgCoordMode();
  });
  mpgMCS.addEventListener("click", () => {
    mpgCoordMode = "MCS";
    updateMpgCoordMode();
  });
  updateMpgCoordMode();
  // Exponer modo de coordenadas (consumido por updateMPG en otras secciones)
  AppState.ui.mpgGetCoordMode = () => mpgCoordMode;
})();

// ── Block B: Main App ──────────────────────────────────────────────────
// Generar ID único de tab en tiempo de ejecución (AppState.tab.id inicializado vacío)
AppState.tab.id = Date.now() + "-" + Math.random().toString(36).slice(2);
(function () {
  try {
    const bc = new BroadcastChannel("rotechos-mutex");
    AppState.tab.bc = bc;
    bc.onmessage = (e) => {
      // 16-sep (C§4): señal de vida de la otra pestaña. Si deja de llegar durante 6 s,
      // el intervalo de abajo da por perdida a la que tenía el control y reelige.
      if (e.data?.id && e.data.id !== AppState.tab.id) AppState.tab.lastSeen = Date.now();
      if (e.data?.type === "tab-check" && e.data.id !== AppState.tab.id) {
        bc.postMessage({ type: "tab-active", id: AppState.tab.id });
      }
      // Defense-in-depth multi-pestaña (audit adversarial jul-2026 F2/F8 +
      // Claude — race del mutex auto-bloqueante): cuando arranca una pestaña,
      // envía "tab-check" y se queda como isLeader=null hasta confirmar.
      // ANTES: si AMBAS pestañas arrancaban casi a la vez y la B veía la
      // "tab-active" de A y viceversa, AMBAS quedaban isLeader=false — nadie
      // podía mover la máquina hasta confirmar el confirmDialog manualmente.
      // FIX: cuando recibimos "tab-active" o "tab-check" de OTRA pestaña,
      // rompemos empate por id: el menor lexicográficamente gana liderazgo
      // (Date.now()-random da un id único y ordenable). Si la OTRA pestaña
      // tiene id menor, asumo rol follower y LO GRABO en AppState.tab
      // (.lteIdIsFollower) para que ninguna regla posterior me proclame
      // líder — esto evita que A y B se proclamen líder mutuamente en el
      // race del handshake inicial.
      if ((e.data?.type === "tab-active" || e.data?.type === "tab-check")
          && e.data.id !== AppState.tab.id) {
        if (e.data.id < AppState.tab.id) {
          // La otra pestaña es "mayor" en orden de liderato → yo soy follower.
          if (AppState.tab.isLeader !== false) {
            AppState.tab.isLeader = !1;
            AppState.tab.warned = !0;
            AppState.tab.lteIdIsFollower = !0;
            LOG.info(`Multi-tab: liderazgo cedido a pestaña con id menor (${e.data.id.slice(0, 16)}…).`);
          }
        } else if (e.data.id > AppState.tab.id && !AppState.tab.lteIdIsFollower) {
          // La otra es menor que yo → yo lidero, pero SOLO si no he cedido
          // antes a otro id menor (idempotente: una vez follower, siempre
          // follower hasta que YO emita un "yield-control" manual).
          AppState.tab.isLeader = !0;
          AppState.tab.warned = !1;
        }
      }
      // Defense-in-depth multi-pestaña (audit adversarial jul-2026 F2/F8):
      // cuando una pestaña pide yield de manera no bloqueante (porque está
      // a punto de escribir a config-machine.g), respondemos con yield-ack
      // inmediato si somos el líder actual. Esto cierra el TOCTOU entre
      // pestañas sin requerir interacción del operario.
      if (e.data?.type === "request-yield" && e.data.id !== AppState.tab.id
          && AppState.tab.isLeader === true) {
        AppState.tab.isLeader = !1;
        AppState.tab.warned = !1;
        bc.postMessage({ type: "yield-ack", id: AppState.tab.id });
        return;
      }
      if (
        e.data?.type === "yield-control" &&
        e.data.id !== AppState.tab.id
      ) {
        AppState.tab.isLeader = !1;
        AppState.tab.warned = !1;
        toast(t(`msg.otraPestañaHaTomado`, "Otra pestaña ha tomado el control"), "info");
      }
      // (El handler de tab-active / tab-check con orden por id está arriba
      // en este mismo `bc.onmessage` — NO se duplica aquí.)
      if (e.data?.type === "tab-active" && e.data.id !== AppState.tab.id) {
        // NOTA: la regla de liderazgo por id está antes en este handler.
        // Aquí solo se gestiona el UI feedback (toast + confirmDialog de
        // "tomar control") cuando la OTRA pestaña ya nos marcó como follower.
        // 16-sep (C§4): `warned` dejaba de ofrecer el control PARA SIEMPRE, así que una
        // seguidora que dijo «no» una vez ya no podía tomarlo aunque la otra pestaña se
        // hubiera ido. Se vuelve a ofrecer pasado un minuto.
        const _yaOfrecido = AppState.tab.warned && Date.now() - (AppState.tab.warnedAt || 0) < 60000;
        if (AppState.tab.isLeader === false && !_yaOfrecido) {
          AppState.tab.warned = !0;
          AppState.tab.warnedAt = Date.now();
          log("Multi-tab detectado: modo solo lectura activo", "warn");
          (async () => {
            const _take = await confirmDialog(
              t(`dlg.multiTab.title`, "Otra sesión activa"),
              t(`dlg.multiTab.msg`,
                '<p>Hay otra pestaña de RotechOS activa controlando la máquina.</p>' +
                '<p style="color:var(--yellow);margin-top:8px">Esta pestaña está en <strong>modo solo lectura</strong> — los controles de movimiento están bloqueados.</p>' +
                '<p style="color:var(--text-3);margin-top:6px;font-size:11px">Cierra la otra pestaña o confirma para tomar el control.</p>'),
            );
            if (_take) {
              AppState.tab.isLeader = !0;
              AppState.tab.warned = !1;
              AppState.tab.bc?.postMessage({
                type: "yield-control",
                id: AppState.tab.id,
              });
              toast(t(`msg.controlTaken`, "Control tomado — esta pestaña es ahora la activa"), "ok");
              log("Tomar Control — modo activo", "sys");
            } else {
              toast(t(`msg.readOnly`, "Modo solo lectura activo"), "warn");
            }
          })();
        }
      }
    };
    bc.postMessage({ type: "tab-check", id: AppState.tab.id });
    // 16-sep (C§4): LATIDO Y REELECCIÓN. Antes, si la pestaña con el control se cerraba,
    // la otra se quedaba en solo lectura PARA SIEMPRE: el firmware pausaba el trabajo a
    // los 30 s por falta de latido de interfaz (daemon.g, uiWatchdogSec) y REANUDAR no
    // podía mandar M24. El operario solo salía recargando, y nada se lo decía.
    //
    // Por qué un latido y no un `pagehide`: FLUJO-7 declara a propósito que esta interfaz
    // NO engancha beforeunload/pagehide/unload —cerrar una pestaña no debe interferir con
    // un trabajo en marcha—, un handler de unload rompe el bfcache, y sobre todo solo
    // cubriría el cierre LIMPIO: con el navegador colgado o matado no se emite nada. El
    // latido cubre los tres casos. Es un postMessage entre pestañas: no toca la red ni el
    // firmware ni el DOM.
    AppState.tab.lastSeen = 0;
    setInterval(() => {
      try {
        if (AppState.tab.isLeader === true) {
          bc.postMessage({ type: "tab-active", id: AppState.tab.id });
          return;
        }
        if (AppState.tab.isLeader === false
            && AppState.tab.lastSeen
            && Date.now() - AppState.tab.lastSeen > 6000) {
          AppState.tab.isLeader = !0;
          AppState.tab.warned = !1;
          AppState.tab.lteIdIsFollower = !1;
          toast(t(`msg.controlRecuperado`, "La otra pestaña ya no responde — esta toma el control"), "ok");
          log("Multi-tab: sin señal de la pestaña activa; tomo el control", "sys");
          typeof updateButtonStates === `function` && updateButtonStates();
        }
      } catch {}
    }, 2000);
  } catch {}
})();
const _SVG_PLAY = `<svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor" style="color:var(--green-strong);opacity:.6;flex-shrink:0"><polygon points="5 3 19 12 5 21 5 3"/></svg>`;
const TARGET_IP = window.location.origin;

// MÓDULO EXTRAÍDO (jul-2026, sprint reducción monolito, bloque 7):
// el IIFE de tema (ui.theme → data-theme + icoLuna/icoSol) y la función
// `escHtml` viven ahora en `rotechos-dom-utils.js`.  Carga DESPUÉS de
// rotechos.js y rotechos-storage.js (ver index.html).  El símbolo
// `escHtml` sigue accesible vía `window.escHtml` para los 28 call-sites
// del shell y de los defer modules.

// ---
// MÓDULO: INLINE HANDLER MIGRATION
// Reemplaza onclick/onfocusin/onfocusout inline por addEventListener
// ---
// H6 (PESO-6, 2026-08-18): el listener suelto de DOMContentLoaded se ha
// movido al BOOT CONSOLIDADO (abajo). Aquí dejamos solo el cuerpo como
// función invocable: pieza 3/5 de boot.init().
function __bootStep3_inlineHandlerMigration() {
  // pcMacrosTriggerBtn — abrir modal macros
  const pcMacro = $(`pcMacrosTriggerBtn`);
  pcMacro &&
    pcMacro.addEventListener(`click`, () => {
      window.renderMacrosModal && window.renderMacrosModal();
      $(`macrosModal`).classList.add(`show`);
    });
  // sys-cfg-shortcut buttons — abrir config con tab específico
  $$(`[data-cfg-tab]`).forEach((btn) => {
    btn.addEventListener(`click`, async () => {
      const tab = btn.dataset.cfgTab;
      // Mismo motivo que en APDetector.openConfig(): sin `await`, el bloque que
      // openMachineConfig() ejecuta tras sus cfgRead()/cfgMachineRead() resetea
      // los paneles y activa su initialTab (`motors` con la máquina ya
      // configurada), pisando la pestaña que pide este atajo. Sin esto, los 4
      // botones que no son `motors` aterrizaban siempre en motors.
      // t_b8cd40c2 (5.º intento): openMachineConfig vive en un módulo
      // PEREZOSO. Antes de invocarlo hay que asegurar que el módulo está
      // cargado; __openMachineConfig() hace ese bootstrap y delega.
      await __openMachineConfig();
      document
        .querySelectorAll(`.mcfg-tab`)
        .forEach((t) => t.classList.remove(`active`));
      document
        .querySelectorAll(`.mcfg-panel`)
        .forEach((p) => (p.style.display = `none`));
      const tabBtn = $q(`.mcfg-tab[data-tab=${tab}]`);
      tabBtn && tabBtn.classList.add(`active`);
      const panel = $(`mcfgTab${tab.charAt(0).toUpperCase() + tab.slice(1)}`);
      panel && (panel.style.display = `block`);
    });
  });
  // newMacroFileWrap — focus highlight
  const fwrap = $(`newMacroFileWrap`);
  fwrap &&
    (fwrap.addEventListener(`focusin`, () => {
      fwrap.style.borderColor = `var(--purple)`;
    }),
    fwrap.addEventListener(`focusout`, () => {
      fwrap.style.borderColor = `var(--border-md)`;
    }));
}

// ---
// CONFIGURACIÓN Y CONSTANTES
// ---
// Limpiar ?_ota= de la URL tras recarga (evita caché persistente)
if (location.search.includes("_ota")) {
  history.replaceState(null, "", location.pathname);
}
// CFG se ha extraído a ROTECHOS/www/js/rotechos-const.js (tarjeta t_4d48a09a,
// 2026-08-11, bloque #20 del re-mapeo). El módulo se carga con <script defer>
// ANTES que este monolito y expone `window.CFG` por REFERENCIA (mismo objeto,
// no copia) para que las mutaciones que hace rotechos-config-modal.js sobre
// CFG.maxRPM/CFG.spindleMin/CFG.spindleRamp/CFG.mistEnabled/CFG.coolEnabled/
// CFG.jogFeedX/Y/Z/A se vean al instante en este monolito y en los 8 defers
// consumidores (rotechos-jog, rotechos-bordeador, rotechos-led, rotechos-viz,
// rotechos-gcode-map, rotechos-spindle, rotechos-config-modal). Los 50 call
// sites internos del monolito leen `CFG.xxx` directamente — el puente local
// `const CFG = window.CFG` mantiene ese patrón sin tocar ninguno.
// CFG vive en rotechos-const.js y se expone en window.CFG. NO se puede
// hacer `const CFG = window.CFG` aqui: los scripts clasicos comparten el
// ambito lexico global, asi que ese puente colisiona con el `const` del
// modulo y lanza "Identifier 'CFG' has already been declared" — que
// impide ejecutar el monolito ENTERO (2026-08-12).

// ---
// MÁQUINA DE ESTADOS (SM)
// ---
const STATES = {
    IDLE: `IDLE`,
    READY: `READY`,
    RUNNING: `RUNNING`,
    PAUSED: `PAUSED`,
    ERROR: `ERROR`,
    // C1 (FASE C): SIMULATING — estado durante M37 (simulación sin movimiento
    // físico). Mapeado por _STATE_TO_LETTER con la letra 'M'. Sin esta entrada
    // en el enum, el badge lookup cae al fallback IDLE durante una simulación.
    SIMULATING: `SIMULATING`,
    // H-1 (2026-08-17): HOMING — estado derivado de data.homingInProgress=true.
    // Antes se aplastaba a IDLE (mapping B→IDLE), dejando al operario sin
    // pista visual de que la máquina está homing. El nombre del estado es
    // UPPER_CASE para encajar con el resto del enum y con el fallback de
    // _showBadgeCls; la UI pinta "REFERENCIANDO…" como texto.
    HOMING:    `HOMING`,
  },
  STATE_META = { // eslint-disable-line no-unused-vars -- leido por global desde rotechos-state-ui.js y por tests/unit/simulating-state.test.js
    IDLE:    { key: `state.idle`,    fallback: `INACTIVO`,    cls: `idle` },
    READY:   { key: `state.ready`,   fallback: `LISTO`,       cls: `ready` },
    RUNNING: { key: `state.running`, fallback: `EN MARCHA`,   cls: `running` },
    PAUSED:  { key: `state.paused`,  fallback: `PAUSADO`,     cls: `paused` },
    ERROR:   { key: `state.error`,   fallback: `ERROR`,       cls: `error` },
    // C1 (FASE C): SIMULATING es el estado de RRF durante M37 (simulación
    // sin movimiento físico). El simulador interno de Duet expone
    // state.status === 'simulating' durante unos segundos y deja
    // job.file.simulatedTime con el tiempo total estimado al terminar.
    // Fuente única para leer el resultado: object model, NO reply parsing.
    // Color neutro (no error ni paused) — la simulación es operación segura.
    SIMULATING: { key: `state.simulating`, fallback: `SIMULANDO…`, cls: `simulating` },
    // H-1: badge amarillo-ámbar, no rojo (no es alarma) y no verde (no está
    // en marcha). "homing" en cls para reusar el esquema de colores.
    HOMING:    { key: `state.homing`,    fallback: `REFERENCIANDO…`, cls: `homing` },
  },
  TRANSITIONS = {
    IDLE: [`READY`, `RUNNING`, `PAUSED`, `ERROR`, `SIMULATING`, `HOMING`],
    READY: [`IDLE`, `RUNNING`, `PAUSED`, `ERROR`, `SIMULATING`, `HOMING`],
    RUNNING: [`PAUSED`, `IDLE`, `READY`, `ERROR`],
    PAUSED: [`RUNNING`, `IDLE`, `READY`, `ERROR`],
    ERROR: [`IDLE`, `READY`, `HOMING`],
    // C1: SIMULATING solo se transita desde READY (o IDLE si la máquina
    // no tiene archivo cargado, M37 sin args). Vuelve a READY/IDLE al
    // terminar la simulación. El polling no transita desde SIMULATING
    // a RUNNING directamente — el operario decide si arranca después.
    SIMULATING: [`READY`, `IDLE`],
    // H-1 (2026-08-17): HOMING puede aparecer desde IDLE/READY (homing en frío
    // antes de un trabajo) o desde ERROR (re-homing forzado tras un halt).
    // Sale a IDLE/READY al completar.
    HOMING:    [`IDLE`, `READY`, `ERROR`],
    // C1 (FIX-UI-REV2-H-C-01): SIMULATING NO está en TRANSITIONS.RUNNING
    // a propósito. RUNNING representa una máquina que físicamente está
    // mecanizando; SIMULATING es una simulación pura sin movimiento. Mezclar
    // ambos fue la causa del P1 original (badge "EN MARCHA" durante M37).
  },
  SM = {
    current: STATES.IDLE,
    loadedFile: null,
    jobStartTime: null,
    pauseRequestTime: null,
    totalPausedMs: 0,
    effectiveMs: 0,
    lastTickTime: null,
    busy: !1,
    cancelTime: null,
    resumeTime: null,
    estimatedTotalMs: null,
    estimatedTotalLines: null,
    wasSeenRunning: !1,
    // FIX HALLAZGO-3: true entre el START forzado sin homing (que envía
    // `M564 H0`) y el momento en que ese trabajo termina o no llega a arrancar.
    // Lo consume _restoreM564AfterForcedStart().
    forcedNoHomeStart: !1,
    pollTimer: null,
    connected: !1,
    zPos: 0,
    gcodeLineMap: null,
    gcodeSpindleNoDwell: !1,
    lastLoggedLine: null,
    lastLoggedFilePos: null,
    lastLineLogAt: 0,
    lastVizFilePos: null,
    can(toState) {
      return TRANSITIONS[this.current]?.includes(toState) ?? !1;
    },
    transition(toState, reason = ``) {
      if (!this.can(toState) && toState !== STATES.ERROR)
        return (
          log(`Transición inválida: ${this.current} → ${toState}`, `err`),
          !1
        );
      const prev = this.current;
      if (prev === STATES.RUNNING && document.body.classList.contains(`spindle-manual`))
        toast(t(`msg.spManualStop`, `Husillo manual: sigue girando. Apágalo con su interruptor.`), `warn`);
      if (
        prev === STATES.PAUSED &&
        toState === STATES.RUNNING &&
        this.pauseRequestTime
      ) {
        this.totalPausedMs += Date.now() - this.pauseRequestTime;
        this.pauseRequestTime = null;
      }
      if (prev === STATES.PAUSED && toState === STATES.RUNNING) {
        this.resumeTime = Date.now();
      }
      if (toState === STATES.RUNNING) this.lastTickTime = Date.now();
      // 15-sep (C-8): reanudar invalida los comandos urgentes que sigan reintentándose.
      if (toState === STATES.RUNNING) _urgentGen += 1;
      if (toState === STATES.IDLE) {
        this.effectiveMs = 0;
        this.lastTickTime = null;
      }
      return (
        (this.current = toState),
        // Viñeteado de alarma: alerta en visión periférica mientras dura el ERROR
        document.body.classList.toggle(`ui-alarm`, toState === STATES.ERROR),
        log(
          `Estado: ${prev} → ${toState}${reason ? ` · ` + reason : ``}`,
          `sys`,
        ),
        updateStateUI(),
        updateButtonStates(),
        typeof startPoll === `function` &&
          (toState === STATES.RUNNING ||
            prev === STATES.RUNNING ||
            toState === STATES.PAUSED ||
            prev === STATES.PAUSED) &&
          startPoll(),
        !0
      );
    },
    forceError(reason = ``) {
      const prev = this.current;
      if (prev === STATES.RUNNING && document.body.classList.contains(`spindle-manual`))
        toast(t(`msg.spManualStop`, `Husillo manual: sigue girando. Apágalo con su interruptor.`), `warn`);
      ((this.current = STATES.ERROR),
        log(
          `ERROR forzado desde ${prev}${reason ? `: ` + reason : ``}`,
          `err`,
        ),
        updateStateUI(),
        updateButtonStates());
      if (prev === STATES.RUNNING || prev === STATES.PAUSED) {
        // Apagar el husillo tras un error forzado es la diferencia entre una
        // fresa parada y una girando. Iba con un `.catch(() => {})` MUDO
        // (hallazgo v3 N-2, acta 2026-08-18_busca-flujo-...-operario-v3,
        // abierto desde agosto): el unico catch de esta zona sin rastro.
        // SIN toast propio, y se midio antes de decidirlo: el acta decia «no
        // hay log ni toast» y NO era cierto — `urgentGcode` reintenta 5 veces
        // (~5,5 s) y al agotarlas ya emite «Comando critico perdido» y dos
        // log en rojo. Faltaba el rastro, no el aviso.
        RRF.urgentGcode(`T0\nM5`).catch(_swallowErr(`forceError.T0M5`));
        (async () => {
          try {
            const r = await RRF.gcode(`M98 P"${MACROS.setSilk}"`);
            if (!r) throw new Error("Fallback");
          } catch (e) {
            log(`set_silk.g falló o inalcanzable — aplicando SEDA inline`, `err`);
            RRF.gcode(FALLBACK_SEDA).catch(_swallowErr(`FALLBACK_SEDA`));
          }
        })();
      }
    },
    _cancelInProgress: !1,
  };
((window.SM = SM), (window.STATES = STATES));

// ---
// LAYOUT Y RESPONSIVE
// ---
// Bloque 11 extraído a rotechos-layout.js (ago-2026, ver cabecera de ese
// módulo). El monolito lee `window.currentLayout` desde updateStateUI
// (móvil muestra el overlay de error sólo fuera del layout pc).
// `updateStateUI` vive en rotechos-state-ui.js (módulo extraído, tarjeta
// kanban t_ef89f2c5). El monolito lo consume por nombre en 5 sitios
// (líneas 745, 763, 1256, 3318, 3620) y la IIFE initMobileButtons
// (línea 4241) lo monkey-patchea para añadir el toggle del jog-lock
// pendant (#pendantJogLock). El bridge local mantiene el nombre
// `updateStateUI` en el closure del monolito para no tocar esas 5
// invocaciones; el monkey-patch actúa sobre `window.updateStateUI`
// (el módulo nuevo es el que lo publica primero).
const updateStateUI = window.updateStateUI;
function updateButtonStates() {
  const s = SM.current,
    btnPlayPause = $(`btnPlayPause`);
  let _esBlock = false;
  try {
    _esBlock =
      AppState.limits.prevHit &&
      [`X`, `Y`, `Z`].some((ax) => AppState.limits.prevHit[ax]);
  } catch (e) {}

  if (btnPlayPause) {
    // C§13 (auditoria 15-sep): `bord.active && !bord.paused` estaba AQUI, en la
    // rama de INICIAR. Con el aplanado en marcha el operario buscaba PAUSA y
    // leia «INICIAR TRABAJO» — y encima el boton salia deshabilitado si habia un
    // final de carrera activo, asi que no podia pausar con el. El click, en
    // cambio, SI pausaba. Ahora la condicion vive en la rama de pausa, junto a
    // su gemela de macros, y el boton dice lo que hace.
    if (s === STATES.READY) {
       btnPlayPause.className = `exec-action-btn start school-tip`;
       btnPlayPause.disabled = SM.busy || _esBlock || AppState.tab.isLeader === false;
       $(`btnPlayPauseLabel`).textContent = t(`btn.startJob`, `INICIAR TRABAJO`);
       $(`btnPlayPauseIcon`).innerHTML = `<svg viewbox="0 0 24 24" fill=none height=18 stroke=currentColor stroke-linecap=round stroke-linejoin=round stroke-width=3 width=18><polygon points="5 3 19 12 5 21 5 3"/></svg>`;
       btnPlayPause.title = _esBlock ? `START bloqueado: final de carrera activo.` : `Iniciar trabajo`;
    } else if (s === STATES.RUNNING || (AppState.macro.running && !AppState.macro.paused)
      || (AppState.bord.active && !AppState.bord.paused)) {
       btnPlayPause.className = `exec-action-btn pause school-tip`;
       btnPlayPause.disabled = false;
       $(`btnPlayPauseLabel`).textContent = t(`btn.pause`, `PAUSA`);
       $(`btnPlayPauseIcon`).innerHTML = `<svg viewbox="0 0 24 24" fill=none height=18 stroke=currentColor stroke-linecap=round stroke-linejoin=round stroke-width=3 width=18><rect height=16 width=4 x=6 y=4 /><rect height=16 width=4 x=14 y=4 /></svg>`;
       btnPlayPause.title = `Pausar trabajo en curso`;
    } else if (s === STATES.PAUSED || (AppState.macro.running && AppState.macro.paused) || (AppState.bord.active && AppState.bord.paused)) {
       btnPlayPause.className = `exec-action-btn start school-tip`;
       btnPlayPause.disabled = false;
       $(`btnPlayPauseLabel`).textContent = t(`btn.resume`, `REANUDAR`);
       $(`btnPlayPauseIcon`).innerHTML = `<svg viewbox="0 0 24 24" fill=none height=18 stroke=currentColor stroke-linecap=round stroke-linejoin=round stroke-width=3 width=18><polygon points="5 3 19 12 5 21 5 3"/></svg>`;
       btnPlayPause.title = `Reanudar trabajo pausado`;
    } else {
       btnPlayPause.className = `exec-action-btn start school-tip`;
       btnPlayPause.disabled = true;
       $(`btnPlayPauseLabel`).textContent = t(`btn.startJob`, `INICIAR TRABAJO`);
       $(`btnPlayPauseIcon`).innerHTML = `<svg viewbox="0 0 24 24" fill=none height=18 stroke=currentColor stroke-linecap=round stroke-linejoin=round stroke-width=3 width=18><polygon points="5 3 19 12 5 21 5 3"/></svg>`;
       btnPlayPause.title = `Bloqueado en estado ${s}`;
    }
    // C1 (FASE C): durante SIMULATING (M37), TODO botón de movimiento/ejecución
    // queda deshabilitado. La simulación es segura (no mueve la máquina), pero
    // el operario puede confundir estado y lanzar trabajo por descuido.
    if (s === STATES.SIMULATING) {
      btnPlayPause.disabled = true;
      $(`btnPlayPauseLabel`).textContent = t(`btn.simulating`, `SIMULANDO…`);
      $(`btnPlayPauseIcon`).innerHTML = `<svg viewbox="0 0 24 24" fill=none height=18 stroke=currentColor stroke-linecap=round stroke-linejoin=round stroke-width=3 width=18><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>`;
      btnPlayPause.title = `La fresadora está simulando el trabajo. Espera a que termine.`;
    }
  }

  const btnBord = $(`btnBordeador`);
  btnBord &&
    (btnBord.disabled =
      !SM.loadedFile || s === STATES.RUNNING || s === STATES.PAUSED);

  // H-1-01 (ronda jul-2026, carriles 1/4): deshabilitar visualmente los 6
  // quick-actions (btnQaHomeAll/SondaZ/M6/Goto0/Park/Simulate) durante
  // RUNNING y SIMULATING. Sus handlers ya abortan con el mismo predicado
  // (machineMoveBlocked() o SM.current === RUNNING), pero el botón seguía
  // visible como "clickable" y el operario solo veía un toast inesperado.
  // Misma regla que btnPlayPause (línea 776) y btnBordeador (arriba): si la
  // máquina está ejecutando o simulando, los quick-actions se atenuan.
  // NO replicar validaciones internas (allHomed, archivo cargado, modo
  // IDLE-only de Simulate): la política de habilitación detallada se
  // mantiene en el handler de cada botón para no divergir del guard
  // runtime si Sergi toca máquinas de estado (ver SW-2-hallazgos-menores-js.md:62).
  const _qaBlocked = s === STATES.RUNNING || s === STATES.SIMULATING;
  for (const id of [`btnQaHomeAll`, `btnQaSondaZ`, `btnQaM6`, `btnQaGoto0`, `btnQaPark`, `btnQaSimulate`]) {
    const b = $(id);
    if (b) b.disabled = _qaBlocked;
  }
}
// Carga perezosa de módulos no-críticos (PESO-5, sprint A3 jul-2026).
// Hoisted a nivel de módulo para que tanto el bloque del topbar (bordeador)
// como el listener de tabs (OTA/backup/wizard/jobhistory) lo compartan.
// Idempotente: reentradas devuelven promesas en vuelo distintas, pero
// como el <script> con el mismo src se evalúa una sola vez en el DOM, no
// hay duplicación de efectos colaterales.
const __lazyLoadCache = Object.create(null);
function __lazyLoad(src) {
  if (__lazyLoadCache[src]) return __lazyLoadCache[src];
  __lazyLoadCache[src] = new Promise((resolve, reject) => {
    const s = document.createElement(`script`);
    s.src = src;
    s.onload = () => resolve();
    s.onerror = (e) => { delete __lazyLoadCache[src]; s.remove(); reject(new Error(`${src}: ` + (e?.message || `load failed`))); }; // 15-sep: reintentable
    document.head.appendChild(s);
  });
  return __lazyLoadCache[src];
}
// Aviso de actualizaciones al arrancar (2026-10-04): el módulo OTA sigue
// fuera del arranque en frío; se inyecta unos segundos después, cuando la
// interfaz ya conectó, y él mismo hace la comprobación silenciosa.
const __otaStartupTimer = setTimeout(() => {
  __lazyLoad(`/js/rotechos-ota.js`).catch((e) => LOG?.warn?.(`lazy OTA (arranque):`, e));
}, 6000);
__otaStartupTimer?.unref?.(); // en los tests de Node no retiene el proceso
// Carga perezosa de rotechos-bordeador.js (PESO-5): el botón #btnBordeador
// del topbar cablea su propio click handler dentro del módulo IIFE. Si lo
// cargamos eagerly lo añadimos al cold arranque (~12 KB raw / ~3.8 KB .gz)
// sin contrapartida. Patrón: captura el primer click, previene la acción,
// carga el módulo, y re-dispacha el click. El módulo ya está cargado
// cuando el handler interno se enchufa en el IIFE.
let __bordReady = false, __bordLoading = false;
$('btnBordeador')?.addEventListener('click', function __lazyBord(ev) {
  if (__bordReady) return; // 2º click en adelante: dejar pasar al handler interno
  ev.preventDefault();
  ev.stopImmediatePropagation();
  // 15-sep: los clics mientras carga no re-disparan otro recorrido (eran dos a la vez).
  if (__bordLoading) return;
  __bordLoading = true;
  __lazyLoad('/js/rotechos-bordeador.js')
    .then(() => {
      __bordReady = true;
      $('btnBordeador')?.click();
    })
    .catch((e) => { __bordLoading = false; LOG?.warn?.('lazy bordeador:', e); });
}, { capture: true });

// Carga perezosa de rotechos-endstop-diag.js (FASE 3): el IIFE del panel GPIO
// se monta sobre #btnEndstopDiag, #endstopDiagPanel y #endstopDiagBody. Si lo
// cargamos eagerly añadimos ~3 KB raw al cold arranque sin contrapartida: el
// 99 % de las sesiones nunca pulsa ese botón. Patrón idéntico al bordeador:
// captura el primer click, previene la acción, carga el módulo y re-dispacha
// el click. El IIFE del módulo engancha su listener en cuanto se ejecuta.
let __endstopDiagReady = false;
$('btnEndstopDiag')?.addEventListener('click', function __lazyEndstopDiag(ev) {
  if (__endstopDiagReady) return; // 2.º click en adelante: dejar pasar al handler interno
  ev.preventDefault();
  ev.stopImmediatePropagation();
  __lazyLoad('/js/rotechos-endstop-diag.js')
    .then(() => {
      __endstopDiagReady = true;
      $('btnEndstopDiag')?.click();
    })
    .catch((e) => LOG?.warn?.('lazy endstop-diag:', e));
}, { capture: true });

// Proxy LAZY de window.ZCAL (FASE 4): el asistente de calibración del sensor
// Z (mide z_sensor_to_table) solo se invoca cuando el operario abre
// CONFIGURACIÓN → SONDA/SAC → "Calibrar con asistente". Mueve el cuerpo de
// `var ZCAL` (65 líneas) a `rotechos-zcal.js` (LAZY via __lazyLoad).
//
// Patrón: en lugar de capture-phase listener en cada botón data-act="ZCAL.*",
// se instala un PROXY en window.ZCAL con la misma forma que el objeto real.
// Cada método proxy dispara __lazyLoad la primera vez, espera a que el módulo
// se cargue (que SOBREESCRIBE window.ZCAL con la versión real), y re-invoca
// el método en el objeto nuevo. Llamadas posteriores llegan directas al real.
//
// index.html:3222 define `_ACTIONS.ZCAL.*` como arrow functions que evalúan
// `ZCAL.X()` en cada click; basta con que `window.ZCAL` exista en el momento
// del primer click para que el dispatcher funcione.
window.ZCAL = {
  __loading: null,
  __isProxy: true,
  _ensureLoaded() {
    if (this.__loading) return this.__loading;
    this.__loading = __lazyLoad('/js/rotechos-zcal.js')
      .then(() => { this.__loading = null; })
      .catch((e) => {
        this.__loading = null;
        LOG?.warn?.('lazy zcal:', e);
        throw e;
      });
    return this.__loading;
  },
};
// Cada método del proxy dispara el load y luego delega al real.
const __ZCAL_METHODS = ['close', 'open', 'save', 'paperDrags', 'step2', 'step3', 'up', 'descend', 'go'];
for (const __m of __ZCAL_METHODS) {
  window.ZCAL[__m] = function __zcalProxy(...args) {
    return window.ZCAL._ensureLoaded().then(() => {
      const real = window.ZCAL;
      if (real && typeof real[__m] === 'function') {
        return real[__m].apply(real, args);
      }
      LOG?.warn?.('ZCAL.' + __m + ' no disponible tras lazyLoad');
    });
  };
}

// Carga perezosa de rotechos-modo-murcielago.js (FASE 3): el easter egg del
// logo (5 clicks consecutivos dentro de 2 s) descarga el módulo en el 5.º
// click. El listener del logo vive aquí (15 líneas, debe contar desde el
// primer paint); solo el cuerpo pesado (~115 líneas) se carga vía lazy al
// detectar el umbral. La función exportada `window.desbloquearModoMurcielago`
// se invoca tras el load.
let __logoClicks = 0;
let __logoTimer = null;
$q('header.topbar .brand')?.addEventListener('click', () => {
  __logoClicks++;
  if (__logoTimer) clearTimeout(__logoTimer);
  __logoTimer = setTimeout(() => { __logoClicks = 0; }, 2000);
  if (__logoClicks < 5) return;
  __logoClicks = 0;
  clearTimeout(__logoTimer);
  __lazyLoad('/js/rotechos-modo-murcielago.js')
    .then(() => {
      if (typeof window.desbloquearModoMurcielago === 'function') {
        window.desbloquearModoMurcielago();
      } else {
        LOG?.warn?.('modo-murcielago cargado pero window.desbloquearModoMurcielago ausente');
      }
    })
    .catch((e) => LOG?.warn?.('lazy modo-murcielago:', e));
});
// ---
// M999 watcher — cadencias del watchdog de reconexión tras reboot
// (decisiones H-3/H-N3/H-N6)
//
// TARJETA t_1f6006ac · FASE 2 del plan de fragmentación del monolito
// (docs/dev/hallazgos/2026-09-09_monolito-diagnostico-y-plan-de-fragmentacion.md §3).
// Extraído a `ROTECHOS/www/js/rotechos-m999-watchdog.js` (cargado como `defer`
// antes de rotechos.js). Exporta `window.M999_WATCHDOG = { TICK_FAST_MS,
// TICK_SLOW_MS, tick, start, clear, hasActiveWatcher }`. Los 3 call-sites del
// monolito (RRF.gcode L1149 — `start`, RRF.gcode L1130 — `clear`, btnRecon
// L3792 — `hasActiveWatcher`) consumen el módulo; el monolito ya no toca
// directamente `AppState.sys.m999Watcher` ni las funciones internas. La razón
// de ser EAGER (no lazy): el watcher salta en el primer ciclo tras un M999;
// si se carga tarde, el primer intento de reconexión queda sin escudo
// durante ~100 ms — regla FAIL-OPEN del plan §2.2.
// ---

// ---
// API RRF (RepRapFirmware)
// ---
// Mensaje honesto del escudo de autenticación: vive en
// rotechos-shield-msgs.js (extraído del monolito en t_79518921, sep-2026).
// Los 3 call-sites de este fichero usan `window.rotechosShieldMsg.get(r)`
// directamente — el módulo se carga ANTES de rotechos.js en index.html.
// 15-sep (C-8): generación de comandos urgentes. Los reintentos de urgentGcode viven
// en setTimeout que nadie podía cancelar (hasta 5, hasta ~5,5 s). Si el operario
// reanudaba entre medias, un M410/M5 reintentado aterrizaba sobre el trabajo ya
// reanudado y dejaba la fresa dentro de la pieza sin girar. Reanudar avanza la
// generación y los reintentos pendientes se descartan. M112 queda EXENTO: un paro
// nunca se cancela.
let _urgentGen = 0;
const RRF = {
    async connect() {
      // Autenticación opcional por PIN HTTP (M551). Si rotechos-auth está
      // disponible, `tryConnect` envía el PIN cacheado, gestiona el rechazo
      // (overlay + reintentos) y devuelve el body parseado del handshake
      // exitoso. Sin PIN configurado, el comportamiento es idéntico al previo
      // (fetch con password= vacío).
      if (typeof window !== `undefined` && window.rotechosAuth && typeof window.rotechosAuth.tryConnect === `function`) {
        const r = await window.rotechosAuth.tryConnect(TARGET_IP, ``);
        return r && r.ok ? r.body : null;
      }
      try {
        const r = await fetch(
          `${TARGET_IP}/rr_connect?password=&time=${Date.now()}`,
          { signal: AbortSignal.timeout(8000) },
        );
        return r.ok ? r.json() : null;
      } catch {
        return null;
      }
    },
    async gcode(cmd, opts) {
      // ── Mutex multi-pestaña: bloqueo de escritura en pestaña seguidora ──
      // Una pestaña degradada a "solo lectura" (isLeader === false) NO debe
      // enviar comandos que muevan o cambien la máquina (jog, consola MDI,
      // spindle, homing, inicio de trabajo — todos pasan por aquí). Las
      // lecturas (status/model/polling) usan rutas separadas y siguen activas.
      // El paro de emergencia y la pausa usan urgentGcode() — NO se bloquean
      // aquí a propósito: una pestaña seguidora debe poder frenar la máquina.
      // isLeader === null (indeterminado / pestaña única) NO se bloquea.
      if (AppState.tab.isLeader === false) {
        toast(t(`msg.readOnlyTab`, "Pestaña en solo lectura — otra sesión controla la máquina"), `warn`);
        log(
          `Comando bloqueado (pestaña seguidora): ${String(cmd ?? "").slice(0, 40)}`,
          `warn`,
        );
        return null;
      }
      // FIX H-1 / t_6b0d109b: escudo `tryConnect` solo en lo que escribe o ejecuta (gcode,
      // deleteFile); lecturas y urgentGcode (M112, pausa) van sin él. El escudo se consulta
      // SIEMPRE: con un trabajo en curso un rechazo no abre el overlay (taparía el botón rojo),
      // avisa por toast y aborta solo ese comando. Sin STATES (tests), enTrabajo = false.
      const enTrabajo = (typeof SM !== `undefined` && typeof STATES !== `undefined`
        && (SM.current === STATES.RUNNING || SM.current === STATES.PAUSED));
      if (typeof window !== `undefined` && window.rotechosAuth && typeof window.rotechosAuth.tryConnect === `function`) {
        const r = await window.rotechosAuth.tryConnect(TARGET_IP, ``, undefined, enTrabajo);
        if (!r || !r.ok) {
          // FIX t_2298b619 (H-N1 + H-N1bis): el escudo abortaba silenciosamente
          // (solo log warn). El operario no recibía feedback Y el diagnóstico
          // MDI (línea 3211) leía RRF._lastFail de un comando ANTERIOR y le
          // mostraba un toast engañoso. Ahora: (a) toast visible con motivo,
          // (b) _lastFail con reason='shield' para que el MDI muestre el
          // mensaje correcto (msg.shieldAbort), no uno de timeout/HTTP previo.
          // HUECO-5 (t_6ba62da3, 2026-09-10): si el escudo falla por RED
          // (`motivo === 'network-error'`), NO emitimos el toast del escudo —
          // la culpa no es de seguridad, y el poll YA está diciendo "Sin
          // conexión" en pantalla desde el primer ms. Emitir otro toast
          // cada vez que el LED ring martillea el escudo (cada ~270 ms)
          // satura la cola FIFO sin aportar información nueva. Lo que sí
          // hacemos: dejar RRF._lastFail con reason='network' para que el
          // log y el diagnóstico MDI (si alguien teclea un comando) digan
          // la causa real. El escudo sigue BLOQUEANDO la operación: el
          // LED simplemente no se actualiza mientras la placa esté caída.
          if (r && r.motivo === `network-error`) {
            RRF._lastFail = { reason: `network`, error: `escudo: tryConnect → network-error`, at: Date.now() };
            log(`gcode(${String(cmd ?? "").slice(0, 40)}) abortado: escudo sin red (placa caída)`, `warn`);
            return null;
          }
          RRF._lastFail = { reason: `shield`, at: Date.now(), motivo: r && r.motivo, segundos: r && r.segundos };
          log(`gcode(${String(cmd ?? "").slice(0, 40)}) abortado: escudo auth rechaza`, `warn`);
          toast(window.rotechosShieldMsg.get(r), `warn`);
          return null;
        }
      }
      if (/\bM999\b/i.test(String(cmd ?? ""))) {
        SM._rebootPending = !0;
        // H-C (informe 2026-08-17_busca-el-monolito-rotechosjs-v2): el `finally`
        // de RRF.gcode invoca startPoll() (línea 1063) tras el fetch, lo que
        // re-agenda un poll regular a CFG.pollMs (~250-500ms) en paralelo al
        // M999 watcher (este setInterval a 1000ms). Resultado: DOS timers de
        // polling martilleando la placa durante el reboot. Marcamos un flag
        // que _currentPollInterval() consulta para devolver 10s (efectivamente
        // pausa el poll regular mientras el watcher hace su trabajo). Se
        // limpia abajo cuando el watcher confirma reconexión.
        AppState.sys.m999InProgress = !0;
        if (SM.pollTimer) {
          clearTimeout(SM.pollTimer);
          SM.pollTimer = null;
        }
        setConn(!1, t(`msg.connLost`, "Sin conexión"));
        const pill = $(`connPill`);
        pill && (pill.className = "conn-pill error");
        log("M999 detectado \u2014 esperando reconexión real", "warn");
        (() => {
          const ov = $(`rebootOverlay`);
          if (ov) {
            ov.classList.add("show");
            document
              .getElementById("machineConfigModal")
              ?.classList.remove("show");
            const _t0 = Date.now(),
              _ti = setInterval(() => {
                const el = $(`rebootTimer`);
                if (el)
                  el.textContent = Math.round((Date.now() - _t0) / 1e3) + "s";
              }, 1e3);
            ov._clearTimer = () => clearInterval(_ti);
          }
        })();
        if (AppState.sys.m999Watcher) clearInterval(AppState.sys.m999Watcher);
        // M999 watcher extraido a `ROTECHOS/www/js/rotechos-m999-watchdog.js`
        // (t_1f6006ac FASE 2). Ver ese modulo para los comentarios H-3/H-N3/H-N6
        // que documentan el ciclo de cadencias y la convivencia con `tryConnect`.
        // Aqui solo delegamos: el modulo re-arma el setInterval a TICK_FAST_MS
        // (1 s, latencia minima para detectar reconexion rapida) y delega
        // en `tick()` el backoff a TICK_SLOW_MS (8 s) si el escudo rechaza.
        window.M999_WATCHDOG.start();
      }
      // 27-sep (análisis de la interfaz, A3): `opts.keepPoll` no toca el sondeo. Lo usa la
      // animación de LED: cada envío paraba el poll y lo relanzaba en el finally (una lectura
      // completa extra por fotograma, hasta 4 por segundo).
      const wasPolling = !(opts && opts.keepPoll) && !!SM.pollTimer;
      if (wasPolling) {
        clearTimeout(SM.pollTimer);
        SM.pollTimer = null;
      }
      try {
        // M291 S2/S3, G28, G38, M98 son bloqueantes hasta completarse o hasta confirmación de usuario
        const _isBlocking = /\b(M291\b[^;]*S[23]|G28|G38|M98)\b/i.test(cmd);
        const _tSig = AbortSignal.timeout(_isBlocking ? 300000 : 15000);
        // FIX H-5: el caller puede pasar opts.signal (p.ej. _smBusyAbort.signal
        // para PAUSE/RESUME/START/CANCEL) — componer con el timeout para que el
        // watchdog de 30s pueda matar el fetch. Sin opts.signal, comportamiento
        // idéntico al anterior.
        const _signal = opts && opts.signal ? AbortSignal.any([_tSig, opts.signal]) : _tSig;
        const r = await fetch(
          `${TARGET_IP}/rr_gcode?gcode=${encodeURIComponent(cmd)}`,
          { signal: _signal },
        );
        // FIX (t_970b83e7): RRF distingue entre "no pude contestar" (HTTP no-2xx
        // → r.ok=false) y "me llegó el comando pero el firmware lo rechazó"
        // ({err:1, errMsg:"…"} con HTTP 200). Antes, un {err:1} propagaba el
        // JSON entero y el caller lo trataba como éxito — el botón SONDA Z
        // mostraba "Sonda Z iniciada…" con ondulación verde a pesar de que el
        // palpado había fallado. El operario se quedaba con un cero de pieza
        // falso. Ahora {err:1} cae al mismo camino que un HTTP no-2xx (null),
        // y todos los `r ? probeStarted : probeErr` lo ven como fallo.
        // Defensivo: si el body no trae `err` (algún endpoint legacy, o el
        // firmware responde algo raro), no asumimos error — sólo fallamos
        // cuando `err` está definido y es !== 0.
        if (!r.ok) {
          // FIX H-4 (informe 2026-08-17_busca-el-monolito): distinguir causa
          // de fallo para que sendCmd (MDI) muestre un toast útil. Antes
          // null silencioso indistinguible entre timeout / HTTP-error / {err:1}.
          RRF._lastFail = { reason: `http`, status: r.status, at: Date.now() };
          return null;
        }
        const body = await r.json();
        if (body && typeof body === "object" && body.err !== void 0 && body.err !== 0) {
          RRF._lastFail = { reason: `firmware`, errMsg: body.errMsg || body.err || `firmware rechazó`, at: Date.now() };
          return null;
        }
        // Éxito: limpia cualquier fallo previo
        RRF._lastFail = null;
        return body;
      } catch (e) {
        if (e?.name === `TimeoutError`) {
          log(
            t(`msg.cmdTimeout`, `Timeout en gcode(${cmd.slice(0, 30)}) — el comando pudo haberse ejecutado`),
            `err`,
          );
          RRF._lastFail = { reason: `timeout`, at: Date.now() };
        } else {
          // FIX H-4: antes el catch genérico (red caída, abort, TypeError) era
          // 100% silencioso — ni log, ni razón visible. El operario solo veía
          // el toast genérico de MDI. Ahora dejamos huella en el slot.
          log(`✗ gcode(${cmd.slice(0, 30)}) — ${e?.name || e?.message || e}`, `err`);
          RRF._lastFail = { reason: `network`, error: String(e?.message || e?.name || e), at: Date.now() };
        }
        return null;
      } finally {
        if (wasPolling && !SM._cancelInProgress) startPoll();
      }
    },
    async deleteFile(path) {
      // FIX H-1: escudo tryConnect antes de borrar — borrado destructivo,
      // un atacante en la WiFi podría borrar /gcodes/*.gcode sin autenticar.
      // FIX t_6b0d109b (H-N6 informe 2026-08-18_busca-superficie-de-seguridad-v3):
      // guard que NO muestre overlay durante STATES.RUNNING/PAUSED. Borrar un
      // archivo durante un trabajo en curso es incoherente con la máquina
      // ya en marcha; abortamos silenciosamente (log warn) sin abrir overlay
      // para no robar foco al operario que está cortando. NO contaminamos
      // RRF._lastFail por la misma razón que en RRF.gcode. Defensivo: si
      // STATES no está en el sandbox (tests sin SM completo), saltamos.
      if (typeof SM !== `undefined` && typeof STATES !== `undefined` && (SM.current === STATES.RUNNING || SM.current === STATES.PAUSED)) {
        log(`deleteFile(${path}) abortado: escudo auth suprimido durante trabajo en curso (${SM.current})`, `warn`);
        return false;
      }
      if (typeof window !== `undefined` && window.rotechosAuth && typeof window.rotechosAuth.tryConnect === `function`) {
        const r = await window.rotechosAuth.tryConnect(TARGET_IP, ``);
        if (!r || !r.ok) {
          // FIX t_2298b619 (H-N1 + H-N1bis): mismo motivo que RRF.gcode — el
          // escudo abortaba silenciosamente y dejaba RRF._lastFail stale. El
          // call site en rotechos-fm.js:327 muestra un toast genérico
          // ("No se puede eliminar") que no distingue "escudo abortó" de
          // "firmware rechazó". Con reason='shield' la próxima ruta que
          // distinga causas (futuro o rotechos-fm.js hoy) puede ramificar.
          // HUECO-5 (t_6ba62da3, 2026-09-10): si el escudo falla por RED
          // (`motivo === 'network-error'`), NO emitimos toast del escudo —
          // mismo argumento que en RRF.gcode (la culpa es de red, no de
          // seguridad, y el poll YA avisa). Dejamos RRF._lastFail con
          // reason='network' para diagnóstico. El escudo sigue bloqueando
          // el borrado (un deleteFile sin placa es destructivo).
          if (r && r.motivo === `network-error`) {
            RRF._lastFail = { reason: `network`, error: `escudo: tryConnect → network-error`, at: Date.now() };
            log(`deleteFile(${path}) abortado: escudo sin red (placa caída)`, `warn`);
            return false;
          }
          RRF._lastFail = { reason: `shield`, at: Date.now(), motivo: r && r.motivo, segundos: r && r.segundos };
          log(`deleteFile(${path}) abortado: escudo auth rechaza`, `warn`);
          toast(window.rotechosShieldMsg.get(r), `warn`);
          return false;
        }
      }
      try {
        const r = await _fetchRRF(`${TARGET_IP}/rr_delete?name=${encodeURIComponent(path)}`, { method: `GET` }, 5000);
        // RRF contesta 200 también si no borra, con {"err":1} (HttpResponder.cpp:592-599).
        return r.ok && (await r.json()).err === 0;
      } catch {
        return false;
      }
    },
    // Lee un fichero de la SD del controlador (`rr_download`).
    // TARJETA t_5592037f (FASE 1 del plan del acta 2026-09-09_capa-rrf-…):
    // migración del grupo de menor riesgo. La fachada ya cubre gcode/
    // deleteFile/urgentGcode; faltaba `download`, y por eso los 17 callsites
    // HTTP directos estaban sueltos. Esta firma debe producir la MISMA URL
    // que el callsite original: `name=<encoded>` siempre, `&time=…` solo si
    // `cacheBust !== false` (default true), timeout por defecto 8s (idéntico
    // al de `_fetchRRF`). Devuelve la `Response` cruda de `fetch` (mismo
    // contrato que `_fetchRRF`), para que callers como `rotechos-macros.js`
    // puedan leer `Last-Modified` del header sin perder funcionalidad.
    async download(path, opts = {}) {
      const cacheBust = opts.cacheBust !== false;
      const ts = cacheBust ? `&time=${Date.now()}` : ``;
      const timeoutMs = Number(opts.timeoutMs) || 8000;
      const url = `${TARGET_IP}/rr_download?name=${encodeURIComponent(path)}${ts}`;
      return _fetchRRF(url, undefined, timeoutMs);
    },
    urgentGcode(cmd, retries = 5, delay = 500, opts = {}) {
      // 4-oct: rechazo inmediato si el firmware ya informa changingTool (rama del Mac, R4),
      // sin esperar a la lectura de inputs[2]. Si no, la guarda general de abajo.
      if (/^\s*M25\b/.test(String(cmd)) && !opts.sinGuardaMacro && AppState.cache.rrfRawStatus === `changingTool`) {
        toast(t(`msg.m25EnCambioHerramienta`, `El cambio de herramienta está en marcha: parar ahora se quedaría esperando. Para parar YA, usa PARO o la seta.`), `err`);
        log(`urgentGcode(${String(cmd).slice(0, 20)}) descartado: cambio de herramienta en curso (se quedaría en cola)`, `err`);
        return Promise.reject(Error(`urgentGcode(${cmd}) descartado: cambio de herramienta en curso`));
      }
      // 27-sep (revisión de la integración, R4 / análisis de la interfaz, A2): la guarda contra el
      // M25 que atasca estaba solo en el botón PAUSA. RRF 3.5.4, con el trabajo dentro de una
      // macro no reiniciable (M6.g, start.g, un M98 del programa), aplaza un M25 que llega por HTTP
      // y lo deja «no terminado» hasta que la macro acaba (GCodes2.cpp:1257-1266): el canal HTTP
      // no ejecuta nada más —ni el M0 de STOP ni el M292 del OK de un aviso— y la máquina se
      // atasca. Aquí pasan TODOS los M25 de la interfaz (pausa, ESC, STOP, finales de carrera).
      // Se pregunta al firmware por el canal del fichero (inputs[2], GCodeChannel.h:20: HTTP,
      // Telnet, File…): `inMacro` y `macroRestartable` son justo lo que mira RRF. Si la lectura
      // falla, se manda el M25 como siempre.
      if (/^\s*M25\b/.test(String(cmd)) && !opts.sinGuardaMacro) {
        return (async () => {
          const f = _unwrap(await _fetchModel(`inputs[2]`, 800));   // null si falla: se manda
          if (f && f.inMacro === true && f.macroRestartable === false) {
            log(`M25 NO enviado: trabajo dentro de una macro`, `warn`);
            toast(t(`msg.m25EnMacro`, `Ahora no se puede pausar: hay una macro en curso (p. ej. cambio de herramienta). Espera o usa el PARO.`), `warn`);
            throw Error(`M25 en macro`);
          }
          return RRF.urgentGcode(cmd, retries, delay, { ...opts, sinGuardaMacro: true });
        })();
      }
      const _ug = async () => {
        const isM112 = cmd === 'M112';
        const timeout = isM112 ? 600 : 2000;
        // FIX H-5: reenviar signal del caller (p.ej. _smBusyAbort.signal) a
        // _fetchRRF para que el watchdog de SM.busy pueda matar el fetch.
        const url = `${TARGET_IP}/rr_gcode?gcode=${encodeURIComponent(cmd)}`;
        let r = await _fetchRRF(url, { priority: `high`, signal: opts.signal }, timeout);
        // 5-oct: sesión caducada (401) o búfer lleno ({"err":1}): NO está entregado.
        if (r.status === 401 && await _reauthSilenciosa()) r = await _fetchRRF(url, { priority: `high`, signal: opts.signal }, timeout);
        if (r.ok && !(await r.json().catch(() => ({}))).err) return !0;
        throw Error(`HTTP ${r.status}`);
      };

      // FIX: Devolver promesa para que los callers puedan hacer await
      // H-3 (informe 2026-08-17_busca-el-monolito): para M112, un E-Stop no
      // debería reintentar 5× con backoff sumando ~5.5s mientras la fresa
      // sigue cortando con red caída. Estrategia nueva: 1 reintento corto
      // (cubre blips de red), y si también falla, aviso "use el botón
      // físico" + reject inmediato.
      const _maxRetries = cmd === 'M112' ? 1 : retries;
      return new Promise((resolve, reject) => {
        const _miGen = _urgentGen;
        const attempt = (n, currentDelay) => {
          _ug().then(resolve).catch(() => {
            // 15-sep (C-8): si el trabajo se reanudó mientras esperábamos, este comando
            // ya no describe la máquina de ahora: reintentarlo la pararía en marcha.
            if (cmd !== `M112` && _miGen !== _urgentGen) {
              log(`urgentGcode(${cmd}) descartado: el trabajo se reanudó`, `warn`);
              reject(Error(`urgentGcode(${cmd}) cancelado por reanudación`));
              return;
            }
            if (n > 0) {
              log(`urgentGcode(${cmd}) falló — reintento en ${currentDelay}ms…`, `warn`);
              setTimeout(() => attempt(n - 1, currentDelay + 300), currentDelay);
            } else {
              if (cmd === `M112`) {
                // FIX HALLAZGO-1 (informe 2026-08-17_busca-flujo-de-trabajo):
                // log() ANTES que toast() — si el módulo de toast peta con
                // ERR_FAILED/rotechos-ui-feedback:76 (_lastMsg null), el
                // operario sigue viendo el aviso crítico en #consoleOut.
                // toast() es UX rápida, log() es la verdad durable.
                log(`⚠ ERROR DE RED enviando M112: Use el botón físico de la máquina`, `err`);
                try { toast(t(`msg.estopNetworkError`, `⚠ ERROR DE RED: ¡Use el botón físico de la máquina!`), `err`); } catch (_) { /* toast falló, el log arriba ya avisó */ }
              }
              log(`✗ urgentGcode(${cmd}) FALLÓ DEFINITIVAMENTE`, `err`);
              try { toast(t(`msg.comandoCríticoPerdidoCmd`, `Comando crítico perdido: ${cmd}`, { "cmd": cmd }), `err`); } catch (_) { /* toast falló, el log arriba ya avisó */ }
              reject(Error(`urgentGcode(${cmd}) agotó reintentos`));
            }
          });
        };
        attempt(_maxRetries, delay);
      });
    },
    // (rr_status eliminado: el polling migró 100% a rr_model y el método quedó sin callers)
    /**
     * Soft-start del spindle con rampa configurable.
     * Si CFG.spindleRamp = 0 → arranque directo (M3 S{rpm})
     * Si CFG.spindleRamp > 0 → rampa lineal en N pasos desde spindleMin hasta rpm,
     *                          con G4 entre cada paso para repartir el tiempo total.
     * Devuelve true si todos los comandos llegaron al firmware.
     */
    async startSpindleWithRamp(rpm) {
      const ramp = Number(CFG.spindleRamp) || 0;
      const target = Math.round(rpm);
      // Sin rampa o rampa demasiado corta: arranque directo
      if (ramp < 0.5 || target <= 0) {
        return await this.gcode(`T0\nM3 S${target}`);
      }
      // Rampa: 5 pasos lineales desde spindleMin hasta target
      const minRpm = CFG.spindleMin || 6000;
      const start = Math.max(minRpm, Math.round(target * 0.3));
      if (target <= start) {
        return await this.gcode(`T0\nM3 S${target}`);
      }
      const steps = 5;
      // Rampa proporcional al objetivo: el VFD acelera ~lineal en RPM, así que a
      // media velocidad basta ~la mitad del tiempo configurado (suelo 0.5s).
      const maxRpm = Number(CFG.maxRPM) || 24000;
      const rampScaled = Math.max(0.5, ramp * (target / maxRpm) * 1.05);
      const dwellMs = Math.round((rampScaled * 1000) / steps);
      const cmds = [`T0`];
      for (let i = 1; i <= steps; i++) {
        const rpmStep = Math.round(start + ((target - start) * i) / steps);
        cmds.push(`M3 S${rpmStep}`);
        if (i < steps) cmds.push(`G4 P${dwellMs}`);
      }
      return await this.gcode(cmds.join(`\n`));
    },
  },
  RRF_TO_SM = {
    I: STATES.IDLE,
    B: STATES.IDLE,   // Busy (cmd rápido / daemon.g) — transitorio, no bloquea jog
    C: STATES.RUNNING,
    D: STATES.PAUSED,
    A: STATES.PAUSED,
    F: STATES.ERROR,
    G: STATES.RUNNING,
    H: STATES.ERROR,
    // C1 (FASE C): la letra 'M' representa `simulating` (no "Moving"). El mapeo
    // ya no se hace aquí porque `_uiResolveStateMachine` intercepta
    // `rrfState === 'simulating'` ANTES de consultar RRF_TO_SM. Lo dejamos
    // mapeado a RUNNING solo como fallback de defensa: si por algún motivo
    // legacy alguien pasa la letra cruda 'M' sin pasar por la guarda, NO
    // entra en SIMULATING (causaría el bug original), pero tampoco entra
    // RUNNING explícitamente — se prefiere IDLE para no disparar el
    // _jobFinish espurio (es una máquina APAGADA, no en marcha).
    M: STATES.IDLE,
    // H-3 (2026-08-17): OFF (firmware apagado) ya NO se mapea a ERROR.
    // Antes, el operario veía badge rojo + resetPanel cuando la máquina
    // estaba apagada, igual que en una alarma física. Pulsaba REINICIAR (M999)
    // y la máquina no respondía (obvio: está apagada). Ahora va a IDLE con un
    // banner específico "FIRMWARE APAGADO" para que sepa lo que pasa sin
    // alarma. El banner se activa en _uiResolveStateMachine interceptando
    // la letra 'O' antes del mapping genérico.
    O: STATES.IDLE,
    P: STATES.RUNNING,
    R: STATES.RUNNING,
    S: STATES.IDLE,
    T: STATES.RUNNING,
  };
// TCONF + toast() extraídos a rotechos-ui-feedback.js (ago-2026, ver
// cabecera de ese módulo). Los 50 call-sites del monolito los resuelven
// por el nombre global `toast` y `window.TCONF` que publica ese módulo.
// ---
// CONSOLA Y LOGGING
// ---
// Pinta el estado plegado/desplegado de la consola en su boton: la flecha
// apunta a donde aparecera el registro, y aria-expanded dice la verdad a
// quien navegue con lector de pantalla. Se llama desde el toggle y al arrancar.
function aplicaPlegadoConsola(btn, plegada) {
  if (!btn) return;
  btn.setAttribute(`aria-expanded`, plegada ? `false` : `true`);
  // La rejilla del centro reparte 4fr/auto/2fr: ese 2fr la consola se lo queda
  // este llena o vacia, asi que plegarla no devolvia NI UN PIXEL al visor
  // —medido: visor 552 px antes y despues—. La clase cambia el reparto para
  // que la fila de la consola pase a ocupar solo su contenido.
  document.querySelector(`.col-center`)?.classList.toggle(`consola-plegada`, plegada);
  const etiqueta = plegada
    ? t(`work.consoleUnfoldTitle`, `Desplegar la consola`)
    : t(`work.consoleFoldTitle`, `Plegar la consola`);
  btn.title = etiqueta;
  btn.setAttribute(`aria-label`, etiqueta);
  // Valor EXPLICITO en el path, no innerHTML vacio: el SVG hereda estilos de
  // la clase y dejarlo a medias es como quedo en blanco el boton de tema.
  const svg = btn.querySelector(`svg`);
  if (svg) svg.innerHTML = plegada
    ? `<polyline points="6 9 12 15 18 9"/>`
    : `<polyline points="18 15 12 9 6 15"/>`;
}
function alternaPlegadoConsola(btn = $(`btnConsoleFold`)) {
  const out = $(`consoleOut`);
  if (!out || !btn) return;
  const plegada = out.classList.toggle(`collapsed`);
  aplicaPlegadoConsola(btn, plegada);
  STORE.set(`ui.consolaPlegada`, plegada);
}
// El botón queda autónomo respecto al delegado global. stopPropagation evita
// que ambos caminos conmutasen dos veces si el delegado cambia en el futuro.
$(`btnConsoleFold`)?.addEventListener(`click`, (e) => {
  e.stopPropagation();
  alternaPlegadoConsola(e.currentTarget);
});
function log(msg, tipo = `info`) {
  const out = $(`consoleOut`);
  if (!out) return;
  const ts = new Date().toLocaleTimeString(`es-ES`, {
      hour: `2-digit`,
      minute: `2-digit`,
      second: `2-digit`,
    }),
    row = document.createElement(`div`);
  row.className = `c-row ${tipo}`;
  const tsSpan = document.createElement(`span`);
  ((tsSpan.className = `c-ts`), (tsSpan.textContent = ts));
  const msgSpan = document.createElement(`span`);
  for (
    msgSpan.className = `c-msg`,
      msgSpan.textContent = msg,
      row.appendChild(tsSpan),
      row.appendChild(msgSpan),
      out.appendChild(row),
      out.scrollTop = out.scrollHeight;
    out.children.length > CFG.consoleMaxLines;
  )
    out.removeChild(out.firstChild);
}
function setConn(ok, msg) {
  SM.connected = ok;
  const pill = $(`connPill`);
  pill &&
    ((pill.className = `conn-pill ${ok ? `ok` : `error`}`), (pill.title = msg));
  ok
    ? document.body.classList.remove(`disconnected`)
    : document.body.classList.add(`disconnected`);
  updateStateUI();
}
function resetProgressPanel() {
  (($(`progBar`).style.transform = `scaleX(0)`),
    ($(`progPct`).textContent = `0%`),
    ($(`progPctInner`).textContent = `0%`),
    ($(`progElapsed`).textContent = `00:00:00`),
    ($(`progRemaining`).textContent = `—`),
    ($(`progTotal`).textContent = `—`),
    ($(`progFilename`).textContent = `—`),
    ($(`vizProgBar`).style.transform = `scaleX(0)`),
    ($(`vizProgPct`).textContent = `0%`),
    ($(`vizProgPct`).className = `viz-ov-pct`),
    ($(`vizProgRemaining`).textContent = `--:--:--`));
}
function clearJob() {
  SM.loadedFile = null;
  SM.jobStartTime = null;
  SM.wasSeenRunning = !1;
  SM.totalPausedMs = 0;
  SM.pauseRequestTime = null;
  SM.effectiveMs = 0;
  SM.lastTickTime = null;
  SM.cancelTime = Date.now();
  // FIX HALLAZGO-3: cancelar un trabajo arrancado sin homing también tiene que
  // devolver el enforcement M564 a los globals (si no, el H0 sobrevive al STOP).
  _restoreM564AfterForcedStart(`trabajo cancelado`);
  SM.gcodeLineMap = null;
  SM.gcodeSpindleNoDwell = !1;
  SM.lastLoggedLine = null;
  SM.lastLoggedFilePos = null;
  SM.lastLineLogAt = 0;
  SM._lastPct = 0;
  SM.lastVizFilePos = null;
  if (typeof VIZ !== "undefined") {
    VIZ.paths = [];
    VIZ.bounds = null;
    VIZ.toolX = null;
    VIZ.toolY = null;
    VIZ.dirty = !0;
  }
  SM._prevXYZ = null;
  SM._vizDir = null;
  setText(`vizFileName`, t(`msg.noFile`, `Sin archivo`));
  $(`vizPlaceholder`).classList.remove(`hidden`);
  $(`vizPlaceholder`).style.display = ``;
  $(`vizClearFile`).style.display = `none`;
  document
    .querySelectorAll(`.fm-file-row.active-file`)
    .forEach((r) => r.classList.remove(`active-file`));
  setText(`mTime`, `00:00:00`);
  resetProgressPanel();
}
// buildGCodeLineMap, gcodeLineAtOffset y logRunningGCodeLine viven ahora en
// rotechos-gcode-map.js (extraído del monolito, tarjeta t_409c393c, ago-2026).
// Las firmas de los tres `function X(...)` se conservan AQUÍ como puente
// mínimo que satisface los tests unitarios por regex
// (tests/unit/gcode-line-map.test.js:43-52) y, a la vez, reenvía al
// `window.X` que publica el módulo. Sin el reenvío, las invocaciones
// internas (p.ej. logRunningGCodeLine en línea ~1873) perderían la
// referencia. Mismo patrón que `const updateStateUI = window.updateStateUI`
// usado por rotechos-state-ui.js (rotechos.js:796).
/* exported buildGCodeLineMap */
// eslint-disable-next-line no-unused-vars -- puente mínimo que el test unitario extrae por regex (tests/unit/gcode-line-map.test.js:43-52) y reenvía al window.X publicado por rotechos-gcode-map.js
// buildGCodeLineMap vive en su modulo y se publica en window.buildGCodeLineMap. NO se pone puente aqui:
// una `function buildGCodeLineMap` en ambito global SOBRESCRIBE window.buildGCodeLineMap con el propio
// puente, que entonces se llama a si mismo — "Maximum call stack size
// exceeded" al cargar (2026-08-12). Las llamadas internas resuelven solas
// contra el global publicado por el modulo.
// gcodeLineAtOffset vive en su modulo y se publica en window.gcodeLineAtOffset. NO se pone puente aqui:
// una `function gcodeLineAtOffset` en ambito global SOBRESCRIBE window.gcodeLineAtOffset con el propio
// puente, que entonces se llama a si mismo — "Maximum call stack size
// exceeded" al cargar (2026-08-12). Las llamadas internas resuelven solas
// contra el global publicado por el modulo.
// logRunningGCodeLine vive en su modulo y se publica en window.logRunningGCodeLine. NO se pone puente aqui:
// una `function logRunningGCodeLine` en ambito global SOBRESCRIBE window.logRunningGCodeLine con el propio
// puente, que entonces se llama a si mismo — "Maximum call stack size
// exceeded" al cargar (2026-08-12). Las llamadas internas resuelven solas
// contra el global publicado por el modulo.

function updateProgressPanel(data) {
  // AT-06 (2026-08-31): no pisar el remate del trabajo. Cuando un trabajo
  // termina, rotechos-state-ui.js pinta 100% y arma un auto-hide de 2,5 s;
  // esta funcion arranca con `pct = 0` y solo la calcula `if (isActive)`, y en
  // READY isActive es false. Sin este guard, el siguiente sondeo —a menos de un
  // segundo— repintaba la barra a 0% encima del 100%, y el operario terminaba
  // su pieza viendo un parpadeo a cero. Mientras el remate esta en pantalla, el
  // sondeo no toca la barra; en cuanto el auto-hide la oculta y llama a
  // `resetProgressPanel()`, el guard se levanta solo.
  if (typeof window.progresoRemateActivo === `function` && window.progresoRemateActivo()) return;
  const now = Date.now(),
    isPaused = SM.current === STATES.PAUSED,
    isRunning = SM.current === STATES.RUNNING,
    isError = SM.current === STATES.ERROR;
    
  if (isError && !SM.errorTime) SM.errorTime = now;
  if (!isError) SM.errorTime = null;
  
  const isActive = isRunning || isPaused || (isError && !!SM.loadedFile && !!SM.jobStartTime);

  if (isRunning && SM.lastTickTime) {
    const feedFactor =
      (data?.params?.speedFactor ?? data?.params?.feedFactor ?? 100) / 100;
    SM.effectiveMs += (now - SM.lastTickTime) * Math.max(feedFactor, 0.01);
  }
  if (isRunning) SM.lastTickTime = now;
  let pct = 0;
  if (isActive) {
    if (data?.jobModel?.filePosition > 0 && data?.jobModel?.file?.size > 0)
      pct = Math.min(
        Math.round(
          (data.jobModel.filePosition / data.jobModel.file.size) * 100,
        ),
        99,
      );
    else if (data?.fractionPrinted != null && data.fractionPrinted > 0)
      pct = Math.min(Math.round(data.fractionPrinted), 99);
    else if (SM.estimatedTotalMs && SM.effectiveMs > 0)
      pct = Math.min(
        Math.round((SM.effectiveMs / SM.estimatedTotalMs) * 100),
        99,
      );
    else if (
      data?.job?.file?.percentComplete != null &&
      data.job.file.percentComplete > 0
    )
      pct = Math.min(Math.round(data.job.file.percentComplete), 99);
    // Progreso monotónico: nunca retrocede (filePosition de RRF fluctúa por read-ahead del buffer)
    if (pct < (SM._lastPct || 0)) pct = SM._lastPct;
    else SM._lastPct = pct;
  }
  const refNow = isError && SM.errorTime ? SM.errorTime : now;
  const pauseAdj =
      isPaused && SM.pauseRequestTime ? refNow - SM.pauseRequestTime : 0;
  const elapsed = SM.jobStartTime
      ? refNow - SM.jobStartTime - SM.totalPausedMs - pauseAdj
      : 0;
  const elapsedFmt = isActive ? hms(elapsed) : `00:00:00`;
  let remainFmt = `--:--:--`,
    totalFmt = `—`;
  if (isActive && pct > 0 && elapsed > 0) {
    const totalEstMs = elapsed / (pct / 100);
    ((remainFmt = hms(Math.max(0, totalEstMs - elapsed))),
      (totalFmt = hms(totalEstMs)));
  }
  const pctStr = `${pct}%`;
  (SM.loadedFile &&
    (($(`progBar`).style.transform = `scaleX(${parseFloat(pctStr)/100})`),
    ($(`progPct`).textContent = pctStr),
    ($(`progPctInner`).textContent = pctStr),
    ($(`progFilename`).textContent = _nombreSinRuta(SM.loadedFile)),
    ($(`progFilename`).title = SM.loadedFile),
    ($(`progElapsed`).textContent = elapsedFmt),
    ($(`progRemaining`).textContent =
      remainFmt === `--:--:--` ? `—` : remainFmt),
    ($(`progTotal`).textContent = totalFmt)),
    ($(`vizProgPct`).textContent = isActive ? pctStr : `0%`),
    ($(`vizProgPct`).className = `viz-ov-pct` + (isPaused ? ` paused` : ``)));
  // 2026-08-28: el panel de progreso es position:absolute sobre el visor y
  // estaba SIEMPRE puesto, tambien sin archivo: pintaba "0%" y una leyenda de
  // nada, y a 1024x768 se comia el estado vacio (9426 px2 de solape medidos).
  // Se oculta solo cuando no hay NI trabajo activo NI archivo cargado. Con
  // archivo parado sigue visible, porque su leyenda explica los colores del
  // visor. `isActive` sale del estado de maquina, asi que un trabajo lanzado
  // desde la SD tambien lo enciende.
  $(`vizProgressPanel`)?.classList.toggle(`viz-ov-oculto`, !isActive && !SM.loadedFile);
  const bar = $(`vizProgBar`);
  ((bar.style.transform = isActive ? `scaleX(${parseFloat(pctStr)/100})` : `scaleX(0)`),
    (bar.className = `viz-ov-bar-fill` + (isPaused ? ` paused` : ``)),
    ($(`vizProgRemaining`).textContent = remainFmt));
}
// hms vive ahora en rotechos-gcode-map.js (extraído del monolito, tarjeta
// t_409c393c, ago-2026). Se conserva aquí la firma con su nombre original
// como puente mínimo que el test unitario extrae por regex
// (tests/unit/hms.test.js:41) y que, a la vez, reenvía al `globalThis.hms`
// publicado por el módulo. Sin este puente, las invocaciones internas
// (líneas 1268, 1273, 1274 y 1871) y las externas (rotechos-notif.js:117)
// perderían la referencia.
// hms vive en su modulo y se publica en window.hms. NO se pone puente aqui:
// una `function hms` en ambito global SOBRESCRIBE window.hms con el propio
// puente, que entonces se llama a si mismo — "Maximum call stack size
// exceeded" al cargar (2026-08-12). Las llamadas internas resuelven solas
// contra el global publicado por el modulo.
// ---
// POLLING Y ACTUALIZACIÓN UI
// ---
// El estado del ciclo de poll vive en AppState.poll y su cuerpo en
// rotechos-poll.js (Sprint 4 f2; contrato en tests/unit/poll-core.test.js).
// Los caches de ciclo viven ahora en AppState.cache (ver su declaración arriba).
// eslint-disable-next-line prefer-const -- reasignado por rotechos-config-modal.js (parser de M581), no aquí
let _triggerGpIn = {};
// Soft limits, preferencia M564 S y posición actuales: viven en
// AppState.cache.{softLimits,softLimitsEnabled,machinePos} (los actualiza cada
// ciclo rotechos-poll.js). El enforcement del jog y el config-modal siguen
// usando los nombres sueltos a través de los PUENTES de window declarados
// junto a AppState (una sola fuente de verdad; la red de tests del clamp,
// tests/unit/do-jog-step.test.js, queda intacta). Migración Sprint 4 f2,
// jul-2026 — ⚠️ PENDIENTE BANCO: validar el clamp del jog en máquina real.
// Estado compartido poll ↔ overrides de jog (los sliders viven en
// rotechos-jog.js, defer posterior, que ASIGNA estas variables; updateUI
// las lee/escribe cada ciclo). Declaradas AQUÍ para que existan desde el
// arranque del núcleo (sin ventana TDZ).
let _ovFeedTs = 0,
  _spindleRunning = false,
  _ovFeedTarget = null,
  _ovFeedRetries = 0,
  _ovFeedUnmatchedTs = 0,    // H-2: timestamp del primer ciclo con divergencia
  _ovFeedWarned = !1;        // H-2: ya mostramos el toast; no repetir hasta
                             // que el operario haga otro movimiento.
// eslint-disable-next-line prefer-const -- reasignadas por rotechos-jog.js (sliders de override), no aquí
let _ovSpindleTs = 0, _m220Timer = null, _m221Timer = null;
// El trigLevel de endstops se lee SIEMPRE desde config.g (; rotech-pills=, SSOT
// en la SD) vía parseRotechPills. Ya NO se cachea en localStorage — así la
// configuración es idéntica en cualquier navegador/dispositivo.
let _smBusyTs = 0;
// FIX H-5 (informe 2026-08-17_busca-el-monolito-rotechosjs-v1.md): cuando el
// watchdog de 30s auto-resetea SM.busy, debe cancelar el fetch en vuelo que lo
// retenía — si no, un comando fantasma puede llegar tarde a la placa y/o un
// doble-click del operario puede lanzar 2 ciclos de trabajo en paralelo.
// Cada `SM.busy = !0` crea un controller nuevo y lo guarda aquí; el watchdog
// lo aborta antes de poner busy = false. RRF.gcode/urgentGcode lo honran
// componiéndolo con su propio timeout vía AbortSignal.any.
let _smBusyAbort = null;
// rr_filelist entero: RRF 3.5.4 corta la lista cuando se llena el buffer y
// devuelve "next" con el índice por el que seguir (RepRap.cpp:1980, :2023).
async function _fileList(dir, timeoutMs) {
  const out = { dir, files: [] };
  for (let first = 0, n = 0; n < 50; n++) {
    const r = await _fetchRRF(`${TARGET_IP}/rr_filelist?dir=${encodeURIComponent(dir)}&first=${first}`, {}, timeoutMs);
    if (!r.ok) throw Error(`HTTP ${r.status}`);
    const j = await r.json();
    if (j.err) throw Error(`rr_filelist err ${j.err}`);
    out.files.push(...(j.files || []));
    if (!(j.next > first)) return out;
    first = j.next;
  }
  return out;
}
/**
 * fetch() con AbortSignal.timeout incluido.
 * Usar en lugar de fetch() directo para evitar cuelgues si la máquina
 * se desconecta. timeoutMs por defecto 8s (peticiones RRF típicas).
 * Para uploads grandes pasar timeoutMs más alto (p.ej. 30000).
 *
 * FIX H-5: si el caller pasa opts.signal (p.ej. _smBusyAbort.signal del
 * watchdog de SM.busy), se compone con el timeout vía AbortSignal.any para
 * que cualquiera de los dos pueda abortar el fetch. Sin caller-signal el
 * comportamiento es idéntico al anterior.
 */
function _fetchRRF(url, opts, timeoutMs = 8000) {
  const _t = AbortSignal.timeout(timeoutMs);
  const _external = opts && opts.signal;
  const _signal = _external ? AbortSignal.any([_t, _external]) : _t;
  // 15-sep: la señal va DESPUÉS del spread. Antes el `signal: undefined` de
  // urgentGcode pisaba el timeout y M112/M25/M5 podían colgarse sin límite.
  return fetch(url, { ...opts, signal: _signal });
}
// 5-oct: con PIN la sesión caduca a los 8 s (HttpResponder.h:43): re-autenticar.
let _reauthEnCurso = null;
function _reauthSilenciosa() {
  if (!window.rotechosAuth?.tryConnect) return Promise.resolve(false);
  return (_reauthEnCurso ||= window.rotechosAuth.tryConnect(TARGET_IP, ``, undefined, true)
    .then((r) => !!(r && r.ok), () => false).finally(() => { _reauthEnCurso = null; }));
}
async function _fetchModel(key, ms, flags) {
  const url = `${TARGET_IP}/rr_model?key=${key}${flags ? `&flags=${flags}` : ``}`;
  try {
    let r = await fetch(url, { signal: AbortSignal.timeout(ms || 3500) });
    if (r.status === 401 && await _reauthSilenciosa()) r = await fetch(url, { signal: AbortSignal.timeout(ms || 3500) });
    return r.ok ? await r.json() : null;
  } catch (e) {
    return null;
  }
}
function _unwrap(r) {
  return r == null ? null : r.result !== void 0 ? r.result : r;
}
// El cuerpo del poll (_pollRun) y el fetch inicial de límites viven en
// rotechos-poll.js (Sprint 4 f2). Aquí queda solo la infraestructura de
// timers: startPoll, _schedulePoll, _clearPollTimer, _currentPollInterval.
// ── updateUI hook registry ───────────────────────────────────────
// Sustituye los monkey-patches de updateUI. Cada módulo registra su
// extensión con registerUIHook(nombre, fn). Se ejecutan en orden de
// registro, siempre dentro de try/catch para aislar fallos.
const _uiHooks = [];
function registerUIHook(name, fn) {
  _uiHooks.push({ name, fn });
}
// ── updateUI helpers ────────────────────────────────────────────
// Cada sub-función tiene una única responsabilidad. updateUI las
// orquesta en orden. Ninguna sub-función cambia la lógica original.

/** Watchdog de SM.busy. Devuelve true si el ciclo debe abortarse. */
function _uiBusyGuard(data) {
  if (!SM.busy) { _smBusyTs = 0; return false; }
  if (!_smBusyTs) _smBusyTs = Date.now();
  if (Date.now() - _smBusyTs > 30e3) {
    // FIX H-5 (informe 2026-08-17_busca-el-monolito-rotechosjs-v1.md): no basta
    // con bajar SM.busy — la promesa en vuelo (RRF.gcode/urgentGcode) sigue
    // viva y puede llegar al firmware tarde, o encolar otro comando del
    // operario que ya pulsó START otra vez. Abortamos el controller para que
    // el fetch muera de inmediato. El fetch se completará con AbortError; los
    // call-sites ya tienen try/finally que limpiarán _smBusyAbort al volver.
    _smBusyAbort?.abort();
    _smBusyAbort = null;
    SM.busy = !1;
    _smBusyTs = 0;
    LOG.warn(`SM.busy auto-reset tras 30s (fetch abortado)`);
    toast(t(`msg.comandoSinRespuestaInterfaz`, `Comando sin respuesta — interfaz desbloqueada`), `warn`);
    log(`SM.busy forzado a false tras 30s sin respuesta`, `err`);
    return false; // continuar tras auto-reset
  }
  // updateTelemetry es un método de la fachada TELEMETRY (FASE 6). El
  // centinela de integridad lo declara como módulo EAGER: si TELEMETRY
  // no estuviera cargado, el arranque grita en rojo antes de llegar
  // aquí. Por eso el guard opcional es defensivo, no la vía normal: en
  // la app sana TELEMETRY siempre existe. Mismo patrón que APDetector.
  window.TELEMETRY?.update?.(data);
  updateProgressPanel(data);
  updateButtonStates();
  return true; // abortar ciclo
}

/** H-3 (2026-08-17): banner persistente "FIRMWARE APAGADO".
   Se activa cuando el firmware reporta state.status === 'off' (letra 'O').
   No es una alarma (no usa el rojo de .ui-alarm): es un aviso gris-ámbar
   que dice "no puedo hablar con la máquina porque está apagada".
   Se elimina en cuanto la letra deja de ser 'O' (cualquier poll con otro
   estado). Es independiente del resetPanel (que sí aparece para halted/ERROR
   físico) y no interfiere con el banner de "X no referenciado". */
function _showFirmwareOffBanner(show) {
  let b = document.getElementById(`firmwareOffBanner`);
  if (show) {
    if (b) return;
    b = document.createElement(`div`);
    b.id = `firmwareOffBanner`;
    // Estilo: barra gris-ámbar apagada, no roja. Diferencia visual clara
    // con el rojo de ERROR/alarma y con el rojo de "X no referenciado".
    b.style.cssText = `position:fixed; top:52px; left:0; width:100%; height:28px; background:#6b6b66; color:#fff; display:flex; align-items:center; justify-content:center; font-size:12px; font-weight:800; z-index:9998; letter-spacing:1px; box-shadow:0 2px 5px rgba(0,0,0,0.5); opacity:0.95`;
    b.innerHTML = `FIRMWARE APAGADO — la placa no responde (sin alarma física)`;
    document.body.appendChild(b);
  } else if (b) {
    b.remove();
  }
}

/** Banner rojo "X no referenciado" y bloqueo del badge RAYO. */
function _uiUpdateHomedBanner(data) {
  if (data.xHomed === undefined) return;
  const _homReq = $(`mcfgHomingRequired`)?.checked ?? true;
  let banner = $(`xHomedBanner`);
  const btnKin = $(`kinBadge`);
  if (data.xHomed === false && _homReq) {
    if (!banner) {
      banner = document.createElement("div");
      banner.id = "xHomedBanner";
      banner.style.cssText =
        "position:fixed; top:52px; left:0; width:100%; height:28px; background:var(--red); color:#fff; display:flex; align-items:center; justify-content:center; font-size:12px; font-weight:800; z-index:9999; letter-spacing:1px; box-shadow:0 2px 5px rgba(0,0,0,0.5)";
      banner.innerHTML = "EJE X NO REFERENCIADO — MODO RAYO BLOQUEADO";
      document.body.appendChild(banner);
    }
    if (btnKin) {
      btnKin.style.opacity = "0.4";
      btnKin.style.cursor = "not-allowed";
      btnKin.style.pointerEvents = "none";
    }
  } else {
    if (banner) banner.remove();
    if (btnKin) {
      btnKin.style.opacity = "";
      // kinBadge es solo indicador (no botón): cursor default cuando se
      // libera el bloqueo de "X no referenciado".
      btnKin.style.cursor = "default";
      btnKin.style.pointerEvents = "auto";
    }
  }
}

/** Sincroniza el modo cinemático KIN con el dato del firmware. */
function _uiSyncKinematicMode(data) {
  if (data.kinematicMode === undefined) return;
  const currentMode = data.kinematicMode === 1 ? "pro" : "silk";
  if (typeof KIN !== "undefined" && KIN.getMode && KIN.getMode() !== currentMode)
    KIN.setModeSilent(currentMode);
}

/**
 * Resuelve las transiciones del estado de máquina (SM) a partir del estado RRF.
 * Devuelve true si updateUI debe abortar el ciclo (halt crítico o soft-limit).
 */
/**
 * Cierre común de trabajo (m11/A5): distingue FIN REAL de CAÍDA inesperada (corte de
 * luz / reset del firmware) y de cancelación del usuario. El fractionPrinted del
 * firmware se pone a 0 tras un reboot, así que también se mira el último % conocido
 * por la UI (progPct), que sobrevive a la caída. Resetea los contadores del job.
 * (El rescate PLR se retiró del sistema — decisión 2026-07-04.)
 */
/** Onda verde one-shot sobre una fila del DRO (evento REAL: disparo de palpado). */
function droRipple(id) {
  const el = $(id)?.closest(`.dro-axis-row`) || $(id);
  if (!el) return;
  el.classList.remove(`dro-ripple`);
  void el.offsetWidth; // reinicia la animación si ya estaba aplicada
  el.classList.add(`dro-ripple`);
  el.addEventListener(`animationend`, () => el.classList.remove(`dro-ripple`), { once: true });
}

/** Tarjeta de resumen al COMPLETAR un trabajo — solo datos reales (archivo,
 *  duración de pared, hora). Recompensa honesta, sin confeti. */
function jobSummaryShow(durMs) {
  const m = $(`jobSummaryModal`);
  if (!m) return;
  const fmt = (ms) => {
    if (ms == null) return `--`;
    const s = Math.round(ms / 1e3), h = Math.floor(s / 3600), mi = Math.floor((s % 3600) / 60), se = s % 60;
    return (h ? `${h}h ` : ``) + `${String(mi).padStart(2, `0`)}m ${String(se).padStart(2, `0`)}s`;
  };
  setText(`jobSumFile`, SM.loadedFile || `—`);
  setText(`jobSumDur`, fmt(durMs));
  setText(`jobSumEnd`, new Date().toLocaleTimeString([], { hour: `2-digit`, minute: `2-digit` }));
  m.classList.add(`show`);
}

function _jobFinish(data) {
  const _frac = typeof data.fractionPrinted === `number` ? data.fractionPrinted : 0;
  const _lastPct = parseInt($(`progPct`)?.textContent) || 0;
  const realDone = _frac >= 99.5 || _lastPct >= 99;
  const userCancel = SM.cancelTime && Date.now() - SM.cancelTime < 5e3;
  const durMs = SM.jobStartTime ? Date.now() - SM.jobStartTime : null; // capturar ANTES de resetear
  SM.jobStartTime = null;
  SM.estimatedTotalMs = null;
  SM.estimatedTotalLines = null;
  SM.wasSeenRunning = false;
  _restoreM564AfterForcedStart(`fin de trabajo`);
  return { realDone, userCancel, durMs, reason: realDone ? `trabajo completado` : userCancel ? `trabajo cancelado` : `trabajo interrumpido` };
}

// FIX HALLAZGO-3 (informe 2026-08-17_busca-flujo-de-trabajo-completo-del-operario-v1.md):
// el arranque forzado SIN homing envía `M564 H0 S…` delante del M24. Ese H0
// desactiva el enforcement de homing y NADIE lo restauraba desde la UI: solo
// volvía al valor del user en el siguiente G28 (homeall.g:85). Mientras tanto
// el operario podía mover la máquina sin referencia creyendo que el escudo
// seguía puesto. Restauramos en cuanto el trabajo forzado termina (bien o mal),
// con la MISMA expresión que config.g:127 y homeall.g:85 — los globals son la
// fuente única, la UI no decide el valor.
function _restoreM564AfterForcedStart(motivo) {
  if (!SM.forcedNoHomeStart) return;
  SM.forcedNoHomeStart = false;
  try {
    RRF.gcode(`M564 H{global.requireHoming ? 1 : 0} S{global.softLimitsOn ? 1 : 0}`)
      .then(() => log(`M564 restaurado tras inicio forzado sin homing (${motivo})`, `warn`))
      .catch(_swallowErr(`restoreM564.${motivo}`));
  } catch (e) { _swallowErr(`restoreM564.${motivo}`)(e); }
}

async function _uiResolveStateMachine(data) {
  // 27-sep (R4 de la revisión de la integración): cachear la PALABRA cruda de state.status
  // (antes de reducirla a una letra) para que RRF.urgentGcode() pueda saber, de forma
  // síncrona, si el firmware está en medio de un cambio de herramienta. ANTES de cualquier
  // early return de esta función: tiene que quedar al día en cada ciclo, incluso si luego
  // se sale por ERROR o por el caso especial de flashing.
  AppState.cache.rrfRawStatus = data._rrfRaw;
  // H-7 (2026-08-17): FLASHING (letra 'F') con messageBox de "update"/"flash"/"iap"
  // pinta "ACTUALIZANDO" sin pasar por ERROR. Esta rama se evalúa ANTES
  // de la guarda "if (SM.current === STATES.ERROR) return false;" porque
  // queremos limpiar un ERROR previo cuando el firmware pasa a flashing.
  const _msgEarly = data.messageBox?.message || ``;
  if (data.status === `F` && /update|flash|iap|firmware\s+update/i.test(_msgEarly)) {
    if (SM.current !== STATES.IDLE) {
      // Asignación directa: si pasamos por SM.transition, el hook de KIN
      // intentaría aplicar SEDA/RAYO y dispararía un M98 no deseado.
      // Aquí solo nos importa que updateStateUi pinte ACTUALIZANDO sobre IDLE.
      SM.current = STATES.IDLE;
    }
    if (!AppState.sys.firmwareUpdating) {
      AppState.sys.firmwareUpdating = true;
      log(`Firmware en proceso de actualización`, `warn`);
    }
    // Pintamos el badge manualmente (sin pasar por SM.transition) porque
    // updateStateUi lee AppState.sys.firmwareUpdating como override.
    if (typeof updateStateUI === `function`) updateStateUI();
    return false;
  }
  if (AppState.sys.firmwareUpdating && data.status !== `F`) {
    // El firmware ya no está flasheando (siguiente poll con otra letra).
    // Limpiamos el flag para que updateStateui pinte el estado normal.
    AppState.sys.firmwareUpdating = false;
    if (typeof updateStateUI === `function`) updateStateUI();
  }
  // Antes de la guarda de ERROR: un paro también confirma que la macro paró.
  _confirmarCancelMacro(data.status);
  if (SM.current === STATES.ERROR) return false;
  const rrfState = data.status;
  // H-1 (2026-08-17): cuando la UI ve `homingInProgress=true` en el object
  // model (que el poll ya cachea en AppState.cache.homingInProgress; ver
  // rotechos-poll.js:311), pintamos un badge propio "REFERENCIANDO…" en
  // lugar de IDLE/INACTIVO. RRF_TO_SM['B'] sigue mapeando a IDLE para
  // mantener el contrato del mapping; aquí discriminamos por la bandera
  // del firmware antes de hacer el mapping. El resolver se ejecuta en cada
  // poll (rotechos.js:1833), pero `data.homingInProgress` solo viaja cuando
  // el poll pidió global ese ciclo (cada 6 ciclos en IDLE). Por eso leemos
  // el cache, que conserva el último valor bueno y se preserva entre polls.
  // Si homingInProgress pasa a false, salimos a IDLE/READY.
  const _homingNow = !!AppState.cache.homingInProgress;
  if (_homingNow && (rrfState === `B` || rrfState === `I`)) {
    if (SM.can(STATES.HOMING) && SM.current !== STATES.HOMING)
      SM.transition(STATES.HOMING, `firmware:homing`);
    return false;
  }
  // Salida de HOMING: si veníamos de HOMING y el firmware ya no reporta
  // homingInProgress, transitamos al destino natural (IDLE si no hay archivo,
  // READY si hay archivo cargado).
  if (SM.current === STATES.HOMING && !_homingNow) {
    const _back = SM.loadedFile ? STATES.READY : STATES.IDLE;
    if (SM.can(_back)) SM.transition(_back, `homing terminado`);
    return false;
  }
  // H-3 (2026-08-17): OFF (firmware apagado) entra a IDLE con banner
  // específico. El mapping RRF_TO_SM['O']=IDLE ya lleva el SM a IDLE; aquí
  // solo levantamos el banner "FIRMWARE APAGADO" la primera vez que entramos
  // desde otro estado. Es un banner persistente (no parpadea) hasta que el
  // firmware reporte otra letra distinta de 'O'. El banner se elimina con
  // cualquier otra transición de SM.current.
  if (rrfState === `O` && SM.current !== STATES.IDLE) {
    SM.transition(STATES.IDLE, `firmware:off`);
  }
  if (rrfState === `O`) {
    _showFirmwareOffBanner(true);
  } else if (typeof _showFirmwareOffBanner === `function`) {
    _showFirmwareOffBanner(false);
  }
  // H-7: la rama FLASHING con messageBox se maneja al inicio del resolver
  // (rotechos.js:1434) para poder limpiar un ERROR previo. Aquí ya no hace
  // falta interceptar 'F' — RRF_TO_SM['F']=ERROR solo se ejecuta si el
  // messageBox no indica flashing (caso halted puro).
  // C1 (FASE C): la letra 'M' del object model RRF representa `simulating`
  // (no "Moving"). poll.js:_STATE_TO_LETTER ya emite 'M' para `simulating`,
  // pero RRF_TO_SM['M']=RUNNING haría que el resolver transicione READY→RUNNING
  // ANTES de llegar al bloque SIMULATING — desde RUNNING no se puede ir a
  // SIMULATING (TRANSITIONS.RUNNING = [PAUSED, IDLE, READY, ERROR]).
  // Consecuencia observada: badge muestra "EN MARCHA" durante M37 y al
  // terminar el firmware dispara `_jobFinish` → toast "Trabajo completado"
  // falso. Válvula: interceptar aquí ANTES de hacer el mapping por RRF_TO_SM.
  // NB: data.status ya es la LETRA ('M'), no la palabra ('simulating'); la
  // traducción se hizo en poll.js:_STATE_TO_LETTER. Usamos la letra como
  // discriminador para no duplicar la traducción al revés.
  if (rrfState === `M`) {
    if (SM.can(STATES.SIMULATING) && SM.current !== STATES.SIMULATING)
      SM.transition(STATES.SIMULATING, `firmware:simulating`);
    return false;
  }
  let mappedState = RRF_TO_SM[rrfState] ?? STATES.IDLE;
  if (mappedState === STATES.RUNNING) {
    SM.wasSeenRunning = true;
  }
  // Falso fin a mitad de mecanizado: "B" (Busy) se mapea a IDLE, pero durante un
  // trabajo YA en marcha un "B" es una operación interna transitoria (cambio de
  // herramienta M6/SAC, macro M98, o un tick de daemon.g), NO el fin del trabajo.
  // Sin esto, un único poll en "B" disparaba "_jobFinish" ("trabajo interrumpido")
  // con el corte aún en curso. Lo tratamos como RUNNING para no falsear el fin.
  if (rrfState === `B` && SM.current === STATES.RUNNING && SM.jobStartTime && SM.wasSeenRunning) {
    mappedState = STATES.RUNNING;
  }
  if (
    mappedState === STATES.ERROR &&
    data._rrfRaw === `halted` &&
    (SM.current === STATES.RUNNING || SM.current === STATES.PAUSED) &&
    !AppState.limits.dialogOpen
  ) {
    let _haltReason = `soft_limit`;
    try {
      const _hr = await _fetchModel("state.status", 1500);
      const _hs = _unwrap(_hr);
      if (typeof _hs === `string` && /halted/i.test(_hs)) {
        const _hm = await _fetchModel("state.messageBox", 1500);
        const _hmr = _unwrap(_hm);
        if (_hmr?.message && /temperature|over.?temp|thermal/i.test(_hmr.message))
          _haltReason = `thermal`;
        else if (_hmr?.message && /power|voltage|brownout/i.test(_hmr.message))
          _haltReason = `power`;
      }
    } catch {}
    if (_haltReason === `thermal` || _haltReason === `power`) {
      SM.transition(
        STATES.ERROR,
        `${_haltReason === "thermal" ? t(`msg.overtemperature`, `Sobretemperatura`) : t(`msg.powerFailure`, `Fallo de alimentación`)} — ${t(`msg.requiresM999`, `requiere M999`)}`,
      );
      toast(
        `✕ ${_haltReason === "thermal" ? t(`msg.overtemperatureUpper`, `SOBRETEMPERATURA`) : t(`msg.powerFailureUpper`, `FALLO ALIMENTACIÓN`)} — ${t(`msg.rebootRequired`, `reinicio requerido`)}`,
        `err`,
      );
      log(`✕ Halt por ${_haltReason} — ${t(`msg.requiresM999`, `requiere M999`)}`, `err`);
      typeof sendNotif === `function` && sendNotif(`ALERTA`, `Halt: ${_haltReason}`, `✕`, `notif.halt`);
      return true;
    }
    SM.pauseRequestTime = Date.now();
    SM.transition(STATES.PAUSED, `Soft limit alcanzado`);
    toast(t(`msg.softLimit`, `Soft Limit — Trabajo pausado`), `err`);
    log(`Soft Limit detectado (firmware halted) — trabajo pausado`, `err`);
    typeof sendNotif === `function` && sendNotif(`ALERTA`, `Soft Limit alcanzado`, ``, `notif.softLimit`);
    _showLimitDialog(`Límite de recorrido`, true);
    return true;
  }
  if (mappedState === STATES.IDLE && SM.current === STATES.RUNNING && SM.jobStartTime && !SM.wasSeenRunning && Date.now() - SM.jobStartTime < 15000)
    mappedState = STATES.RUNNING;
  // 15-sep: PAUSED se fuerza solo hasta que el firmware confirma la pausa. Antes no
  // caducaba: si otro dispositivo reanudaba, esta UI seguía en PAUSADO con la máquina cortando.
  if (SM.current === STATES.PAUSED && SM.pauseRequestTime && mappedState !== STATES.ERROR) {
    if (mappedState === STATES.PAUSED) SM._pausaVista = SM.pauseRequestTime;
    else if (SM._pausaVista !== SM.pauseRequestTime) mappedState = STATES.PAUSED;
  }
  if (SM.current === STATES.IDLE && SM.cancelTime && Date.now() - SM.cancelTime < 3e3 && mappedState !== STATES.ERROR)
    mappedState = STATES.IDLE;
  // El estado vacio del visor nace VISIBLE en el marcado, no oculto. Este
  // bloque solo lo esconde cuando el sondeo CONFIRMA que hay fichero.
  // Naciendo oculto, la unica forma de verlo era que el sondeo llegara y
  // trajera `job.file`: con la maquina desconectada, el sondeo lento o la
  // respuesta sin esa clave, el operario se quedaba mirando un visor en
  // blanco sin ninguna indicacion de que puede cargar un G-code. Falla al
  // lado seguro: lo peor que pasa es ver «Cargar G-code» un instante de mas,
  // que ademas es cierto mientras no haya nada cargado.
  const _hasJobFileStatus = data.jobModel && Object.prototype.hasOwnProperty.call(data.jobModel, `file`);
  // 2-oct: en RRF 3.5.4 el campo es job.file.fileName (PrintMonitor.cpp:90); `name` no existe.
  const _jobFileName = data.jobModel?.file?.fileName ?? data.jobModel?.file?.name;
  if (_hasJobFileStatus) {
    const placeholder = $(`vizPlaceholder`);
    if (placeholder) {
      // Cuenta TAMBIEN el fichero que tiene la interfaz, no solo el que
      // reporta la maquina. Sin `|| SM.loadedFile`, cargar un G-code desde el
      // cockpit pintaba la trayectoria y el SIGUIENTE SONDEO la tapaba con
      // «Cargar G-code»: la maquina aun no registra el fichero (M23 puede no
      // haberse reflejado, o el trabajo no haber arrancado) y el estado vacio
      // volvia encima del dibujo. Lo cazo el spec de la silueta.
      const hasLoadedFile = !!_jobFileName || !!SM.loadedFile;
      placeholder.classList.toggle(`hidden`, hasLoadedFile);
      placeholder.style.display = hasLoadedFile ? `none` : ``;
    }
  }
  if (!SM.loadedFile && _jobFileName) {
    SM.loadedFile = _jobFileName;
    const progFilenameEl = $("progFilename");
    if (progFilenameEl) {
      progFilenameEl.textContent = _nombreSinRuta(SM.loadedFile);
      progFilenameEl.title = SM.loadedFile;
    }
  }
  // Trabajo lanzado desde la SD: el visor no tiene archivo; su etiqueta enseña el del trabajo.
  if (_jobFileName && mappedState !== STATES.IDLE) {
    const vfn = $("vizFileName");
    if (vfn && vfn.textContent === t(`msg.noFile`, `Sin archivo`)) vfn.textContent = _nombreSinRuta(_jobFileName);
  }
  if (mappedState === STATES.RUNNING && !SM.jobStartTime) {
    SM.jobStartTime = Date.now();
    SM.totalPausedMs = 0;
    SM.effectiveMs = 0;
    SM.lastTickTime = Date.now();
  }
  // 26-sep: una macro M98 por HTTP pone RRF en `busy` (B), no en `processing`
  // (RepRap.cpp:2412): no se detectaba, y ESC, el jog y la fila la ignoraban.
  const _macroEnB = rrfState === `B` && !!AppState.macro.name && SM.current !== STATES.RUNNING;
  if ((mappedState === STATES.RUNNING && (!SM.loadedFile || !SM.jobStartTime)) || _macroEnB) {
    // Sin enB es un trabajo de SD ajeno: ese sí se pausa con M25.
    AppState.macro.enB = _macroEnB;
    if (AppState.macro.name) {
      AppState.macro.running = !0;
    } else {
      AppState.macro.detectCnt = (AppState.macro.detectCnt || 0) + 1;
      if (AppState.macro.detectCnt >= 3) AppState.macro.running = !0;
    }
    mappedState = SM.current;
  } else {
    AppState.macro.detectCnt = 0;
    // ESTOP-MACRO-LIMP (t_70974bbf, 2026-09-02): cuando el poll ve que
    // la macro ya no está corriendo, el toast debe distinguir entre
    // terminación natural (IDLE → ok, "completada") y terminación por
    // paro (ERROR → warn, "abortada"). Antes emitía siempre "completada"
    // verde, incluso cuando el motivo real había sido un M112 varios
    // segundos antes — mentira textual sobre seguridad.
    // _resetMacroState() se llama SIEMPRE: limpia las cuatro banderas
    // (running, paused, name, row) y la clase .running del highlight.
    if (AppState.macro.running) {
      if (mappedState === STATES.ERROR) {
        // El firmware sigue halted por un paro previo. Avisamos al
        // operario del motivo real; btnEStop ya emitió su propio toast
        // genérico, este es el específico de la macro.
        toast(t(`msg.macroAbortada`, `Macro abortada por paro de emergencia`), `warn`);
        log(`Macro abortada por paro de emergencia (poll)`, `warn`);
      } else {
        toast(t(`msg.macroAppstatemacronameCompletada`, `Macro "${AppState.macro.name || ``}" completada`, { "AppState.macro.name || ``": AppState.macro.name || `` }), `ok`);
        log(`Macro completada: ${AppState.macro.name || `—`}`, `cmd`);
      }
      _resetMacroState();
    } else if (AppState.macro.name && rrfState === `I` && Date.now() - (AppState.macro.lanzadaEn || 0) > 3000) {
      // Acabó antes de que el sondeo la viera ocupada: la fila no puede quedarse en verde.
      _resetMacroState();
    }
  }
  if (SM.current === STATES.RUNNING && SM.resumeTime && Date.now() - SM.resumeTime < 3000 && mappedState !== STATES.RUNNING && mappedState !== STATES.ERROR)
    mappedState = STATES.RUNNING;
  if (mappedState === STATES.IDLE && SM.jobStartTime && SM.wasSeenRunning && Date.now() - SM.jobStartTime > 1500) {
    // m11/A5: fin real vs caída — lógica compartida en _jobFinish (antes duplicada aquí)
    const _f = _jobFinish(data);
    SM.loadedFile
      ? SM.current !== STATES.READY && SM.transition(STATES.READY, _f.reason)
      : SM.current !== STATES.IDLE && SM.transition(STATES.IDLE, _f.reason);
  } else if (mappedState === STATES.IDLE && SM.jobStartTime && !SM.wasSeenRunning) {
    // El trabajo nunca llegó a ejecutarse en el firmware (p. ej. expiró la guarda de 15s)
    SM.jobStartTime = null;
    SM.estimatedTotalMs = null;
    SM.estimatedTotalLines = null;
    SM.wasSeenRunning = false;
    // FIX HALLAZGO-3: éste es el caso del informe — start.g abortó (sin homing,
    // integridad) DESPUÉS de que rr_gcode contestase 200, así que el M564 H0 se
    // aplicó y el trabajo no corrió. Devolvemos el enforcement a los globals.
    _restoreM564AfterForcedStart(`el trabajo no llegó a iniciarse`);
    SM.current !== STATES.READY && SM.transition(STATES.READY, `firmware idle (no se inició)`);
  } else if (mappedState === STATES.IDLE && SM.loadedFile) {
    SM.current !== STATES.READY &&
      (SM.jobStartTime &&
        ((SM.jobStartTime = null),
        (SM.estimatedTotalMs = null),
        (SM.estimatedTotalLines = null)),
      SM.transition(STATES.READY, `firmware idle`));
  } else if (mappedState !== SM.current && !(mappedState === STATES.IDLE && SM.current === STATES.PAUSED)) {
    SM.transition(mappedState, `firmware:${rrfState}`);
  }
  // C1 (FASE C): SIMULATING→READY/IDLE al TERMINAR M37. La entrada la maneja
  // la guarda temprana al inicio de _uiResolveStateMachine (intercepción de
  // rrfState='M'); aquí solo cubrimos la SALIDA cuando M37 termina y el
  // firmware pasa a otra letra ('I'/'C'/'D'/etc.).
  if (SM.current === STATES.SIMULATING && rrfState !== `M`) {
    const _backState = SM.loadedFile ? STATES.READY : STATES.IDLE;
    if (SM.can(_backState)) SM.transition(_backState, `simulacion terminada`);
  }
  if (mappedState === STATES.RUNNING && !SM.jobStartTime) {
    SM.jobStartTime = Date.now();
    SM.totalPausedMs = 0;
    SM.effectiveMs = 0;
    SM.lastTickTime = Date.now();
  }
  if (SM.current === STATES.RUNNING && SM.jobStartTime && SM.wasSeenRunning && Date.now() - SM.jobStartTime > 1500 && (data.fractionPrinted >= 100 || data.status === `I`)) {
    const _f = _jobFinish(data);
    SM.loadedFile
      ? SM.transition(STATES.READY, _f.reason)
      : SM.transition(STATES.IDLE, _f.reason);
    if (_f.realDone) {
      toast(t(`msg.jobDone`, `Trabajo completado`), `ok`);
      typeof jobSummaryShow === `function` && jobSummaryShow(_f.durMs);
    }
  }
  return false;
}

/**
 * Capa de suavizado del DRO. Desacopla los ~2 datos/s de la placa de los 60fps de
 * pantalla: cada poll fija el OBJETIVO (coords reales) y un bucle requestAnimationFrame
 * anima los valores MOSTRADOS hacia él con suavizado exponencial independiente de
 * framerate (k = 1 - e^(-dt/τ)). El bucle se AUTO-DETIENE al asentar, así que no
 * consume batería en reposo. Pinta TODOS los displays de coordenadas (cockpit wX/Y/Z,
 * pendant mpgX/Y/Z, y pantallas pendant2 jog/wcs/run/mcs). Coste de placa: CERO.
 */
const DRO = {
  wcs: [0, 0, 0, 0], mcs: [0, 0, 0, 0],   // mostrado (suavizado)
  tWcs: [0, 0, 0, 0], tMcs: [0, 0, 0, 0], // objetivo (último poll)
  connected: false, raf: 0, tPrev: 0,
  _modeFlashTimer: null,
  TAU: 70,        // ms — menor = más pegado al dato real, mayor = más fluido/retrasado
  EPS: 0.0015,    // mm — por debajo se iguala y para (mata el último decimal nervioso)
  setTarget(xyz, machine, connected) {
    this.connected = connected;
    for (let i = 0; i < 4; i++) this.tWcs[i] = (xyz && xyz[i]) ?? 0;
    for (let i = 0; i < 4; i++) this.tMcs[i] = (machine && machine[i]) ?? (xyz && xyz[i]) ?? 0;
    if (!connected) {                        // sin red: sin animación, render "---" ya
      this.wcs = this.tWcs.slice(); this.mcs = this.tMcs.slice();
      if (this.raf) { cancelAnimationFrame(this.raf); this.raf = 0; }
      this.render(); return;
    }
    if (!this.raf) { this.tPrev = performance.now(); this.raf = requestAnimationFrame((t) => this._loop(t)); }
  },
  _loop(t) {
    // FIX-3: si la pestaña está oculta, no animate — el listener de
    // visibilitychange re-arranca el bucle con la guarda `if (!this.raf) ...`
    // que ya existía en setTarget, así que no se duplica.
    if (document.hidden) { this.raf = 0; return; }
    const dt = Math.min(t - this.tPrev, 100); this.tPrev = t;
    const k = 1 - Math.exp(-dt / this.TAU);
    let moving = false;
    for (let i = 0; i < 4; i++) {
      const d = this.tWcs[i] - this.wcs[i];
      if (Math.abs(d) < this.EPS) this.wcs[i] = this.tWcs[i];
      else { this.wcs[i] += d * k; moving = true; }
    }
    for (let i = 0; i < 4; i++) {
      const d = this.tMcs[i] - this.mcs[i];
      if (Math.abs(d) < this.EPS) this.mcs[i] = this.tMcs[i];
      else { this.mcs[i] += d * k; moving = true; }
    }
    this.render();
    this.raf = moving ? requestAnimationFrame((t2) => this._loop(t2)) : 0;
  },
  render() {
    const conn = this.connected, w = this.wcs, m = this.mcs;
    const fmt = (v) => !conn ? `---` : v.toFixed(3).padStart(7, ` `);
    const fHtml = (v) => {
      if (!conn) return `---`;
      const s = v.toFixed(3).padStart(7, ` `);
      return `${s.slice(0, -4)}<span class="dro-dec">${s.slice(-4)}</span>`;
    };
    const setH = (id, html) => { const el = $(id); if (el) el.innerHTML = html; };
    const setT = (id, txt) => { const el = $(id); if (el) el.textContent = txt; };
    // Cockpit (enteros brillantes + decimales atenuados)
    setH(`wX`, fHtml(w[0])); setH(`wY`, fHtml(w[1])); setH(`wZ`, fHtml(w[2])); setH(`wA`, fHtml(w[3]));
    setT(`zReadout`, !conn ? `---` : w[2].toFixed(3));
    // Pendant principal (respeta el toggle MCS/WCS)
    const mode = (typeof AppState !== "undefined" && typeof AppState.ui.mpgGetCoordMode === "function")
      ? AppState.ui.mpgGetCoordMode() : "WCS";
    const disp = mode === "MCS" ? m : w;
    // V3-003: feedback visual al cambiar de modo MCS/WCS (flash breve en el badge)
    if (this._lastCoordMode !== undefined && this._lastCoordMode !== mode) {
      const badge = $q(`.dro-abs-badge`);
      if (badge) {
        badge.classList.remove(`dro-wcs-changed`);
        void badge.offsetWidth; // forzar reflow para reiniciar la animacion
        badge.classList.add(`dro-wcs-changed`);
        if (this._modeFlashTimer) clearTimeout(this._modeFlashTimer);
        this._modeFlashTimer = setTimeout(() => {
          badge.classList.remove(`dro-wcs-changed`);
          this._modeFlashTimer = null;
        }, 700);
      }
    }
    this._lastCoordMode = mode;
    setT(`mpgX`, fmt(disp[0])); setT(`mpgY`, fmt(disp[1])); setT(`mpgZ`, fmt(disp[2]));
    setT(`mpgZReadout`, fmt(disp[2]));
    // Fila MCS del cockpit (coordenadas máquina absolutas)
    setT(`aX`, fmt(m[0])); setT(`aY`, fmt(m[1])); setT(`aZ`, fmt(m[2])); setT(`aA`, fmt(m[3]));
    for (let i = 0; i < 3; i++) {
      const ax = ["X", "Y", "Z"][i];
      setT(`pendant2Jog` + ax, fmt(w[i]));
      setT(`pendant2Wcs` + ax, fmt(w[i]));
      setT(`pendant2Run` + ax, fmt(w[i]));
      setT(`pendant2WcsMcs` + ax, t(`span.mcs-e56d-ax`, "MÁQ") + " " + fmt(m[i]));
      setT(`pendant2Mcs` + ax, t(`span.mcs-e56d-ax`, "MÁQ") + " " + fmt(m[i]));

      // V3-004: el cero absoluto se evalúa contra el sistema de coordenadas ACTIVO
      // (MCS = cero máquina físico; WCS = cero pieza). Antes solo miraba WCS, así
      // que un cero pieza en X=10 nunca pintaba verde aunque la pieza estuviera en su sitio.
      const activeRef = mode === "MCS" ? m : w;
      // 14-sep: por data-act (el [onclick*=] de antes no casaba nunca).
      const btn = $q(`.pendant2-wcs-zero[data-act="helpers.clickWcsAxis('${ax}')"]`);
      if (btn) {
        if (Math.abs(activeRef[i]) < 0.001) {
          btn.style.color = `var(--ax-${ax.toLowerCase()})`;
          btn.style.borderColor = `var(--ax-${ax.toLowerCase()})`;
        } else {
          btn.style.color = "";
          btn.style.borderColor = "";
        }
      }
    }
  },
};

// Publica DRO como global para que los modulos defer (rotechos-firstcut.js,
// etc.) puedan leerlo. Sin esto, las lecturas cross-script ven el inicial
// {tMcs:[0,0,0,0], tWcs:[0,0,0,0]} porque `const DRO = {...}` vive solo
// en el ambito lexico del monolito. Descubierto en A-02 (t_fc9e9c0a) al
// investigar por que la fila 'origin' del checklist 'Mi primer corte'
// nunca llegaba a marcarse: el modulo extraido hace `DRO.tMcs[i]` y, sin
// este puente, siempre ve ceros. Hay que situarlo DESPUES de la declaracion
// de `const DRO = {...}` (no antes): un `window.DRO = DRO;` previo lanza
// "Cannot access 'DRO' before initialization" por la TDZ de los const.
window.DRO = DRO;

// ---
// TELEMETRÍA — la fachada vive en rotechos-telemetry.js (FASE 6 del
// monolito). El estado compartido (_ovFeedTs, _ovSpindleTs,
// _spindleRunning, _ovFeedTarget, _ovFeedRetries, _ovFeedUnmatchedTs,
// _ovFeedWarned) se queda declarado en este fichero porque rotechos-jog.js
// (defer posterior) lo lee y escribe en sus handlers; declararlo en la
// fachada crearía una ventana TDZ en el arranque del núcleo.
// ---
// _uiSyncKinematicMode sigue aquí: el plan de fragmentación lo dejó
// dentro del monolito porque comparte lógica con KIN y SM, y moverlo
// solo aísla una función que ya está perfectamente encapsulada.
// ── fin helpers updateUI ─────────────────────────────────────────

let _lastUiBeatTs = 0;
// ── Wake Lock: mantener la pantalla viva mientras hay un trabajo activo ──
// CRÍTICO: sin esto, el móvil bloquea la pantalla → el navegador congela los
// timers (setTimeout) → deja de mandarse el latido `uiBeat` → daemon.g pausa el
// trabajo a mitad de corte (M25). El wake lock se libera solo al ocultar la
// página, por eso se re-adquiere en `visibilitychange`.
let _wakeLock = null;
async function _acquireWakeLock() {
  if (_wakeLock || !(`wakeLock` in navigator)) return;
  try {
    _wakeLock = await navigator.wakeLock.request(`screen`);
    _wakeLock.addEventListener(`release`, () => { _wakeLock = null; });
  } catch {}
}
function _releaseWakeLock() {
  if (!_wakeLock) return;
  try { _wakeLock.release(); } catch {}
  _wakeLock = null;
}
// eslint-disable-next-line no-unused-vars -- usado por updateUI fuera de este módulo (rotechos.js:1654 (window.updateUI) + tests/poll-core.test.js)
async function updateUI(data) {
  if (!data) return;
  if (_uiBusyGuard(data)) return;

  // ── Latido de conectividad + wake lock durante el trabajo ──
  // Durante un trabajo avisamos a la placa de que la UI sigue viva (cada ~10 s).
  // Si dejan de llegar latidos > global.uiWatchdogSec, daemon.g pausa el trabajo (M25).
  if (SM.current === STATES.RUNNING || SM.current === STATES.PAUSED) {
    _acquireWakeLock();
    if (SM.current === STATES.RUNNING && Date.now() - _lastUiBeatTs > 10000) {
      _lastUiBeatTs = Date.now();
      RRF.gcode(`set global.uiBeat = state.upTime`).catch(() => {});
    }
  } else {
    _releaseWakeLock();
  }

  // Modo bordeador: solo actualiza telemetría/progreso/botones y sale
  if (AppState.bord.active) {
    try { window.TELEMETRY?.update?.(data); updateProgressPanel(data); updateButtonStates(); } catch {}
    return;
  }

  _uiUpdateHomedBanner(data);
  _uiSyncKinematicMode(data);
  if (await _uiResolveStateMachine(data)) return;
  // HALLAZGO-5 (informe 2026-08-17): distingir "pausa del operario" de "pausa por
  // pérdida de UI". daemon.g deja global.lastWatchdogPause = state.upTime tras
  // un M25 del watchdog; aquí lo cruzamos con el último visto (un trabajo
  // legítimo que sale a IDLE/READY hace que baje a 0 vía start.g/cancel.g y
  // _seenLastWatchdogPause lo sigue sin re-disparar el toast).
  // Solo cuando estamos PAUSED, porque en cualquier otro estado la pausa
  // del watchdog nunca se da (el watchdog solo dispara desde "processing").
  if (AppState.cache.lastWatchdogPause != null &&
      AppState.cache.lastWatchdogPause > (AppState.cache._seenLastWatchdogPause || 0) &&
      SM.current === STATES.PAUSED) {
    AppState.cache._seenLastWatchdogPause = AppState.cache.lastWatchdogPause;
    toast(
      t(`msg.watchdogPause`,
        `Trabajo pausado por pérdida de conexión con la UI. Comprueba la WiFi y pulsa RESUME cuando recuperes el control.`),
      `warn`,
    );
    log(`Trabajo pausado por watchdog UI (upTime=${AppState.cache.lastWatchdogPause}s)`, `warn`);
  }
  window.TELEMETRY?._uiUpdateDRO?.(data);
  window.TELEMETRY?._uiSyncFeedOverride?.(data);
  window.TELEMETRY?._uiSyncSpindleOverride?.(data);
  setText(`mTime`, hms(SM.jobStartTime ? Date.now() - SM.jobStartTime : 0));
  updateProgressPanel(data);
  logRunningGCodeLine(data);
  // El centinela de integridad declara TELEMETRY como EAGER; el guard
  // opcional cubre la ventana TDZ teórica hasta que DOMContentLoaded
  // ejecute el chequeo y grite si falta.
  window.TELEMETRY?.update?.(data);
  typeof updateEndstops == `function` && updateEndstops(data);
  if (data?.state?.startupError?.message && !AppState.sys.startupErrShown) {
    AppState.sys.startupErrShown = !0;
    log(`Error de arranque: ${data.state.startupError.message}`, `err`);
    toast(t(`msg.firmwareErrors`, `Firmware arrancó con errores — ver consola`), `warn`);
  }
  updateButtonStates();

  // Extensiones registradas (spindle, MPG, SAC…)
  for (const { name, fn } of _uiHooks) {
    try { fn(data); } catch(e) { LOG.warn(`UIHook '${name}' error:`, e); }
  }
}
// Limpieza robusta — pollTimer puede ser setTimeout o setInterval según rama,
// llamar a ambos clear es seguro y evita hilos fantasma tras errores de red.
function _clearPollTimer() {
  if (SM.pollTimer) {
    clearTimeout(SM.pollTimer);
    clearInterval(SM.pollTimer);
    SM.pollTimer = null;
  }
  if (SM._pauseTimer) {
    clearTimeout(SM._pauseTimer);
    SM._pauseTimer = null;
  }
}
/** Pausa el polling N ms — evita colisiones con comandos que estresan el bus (spindle, M950…) */
function _pausePollMs(ms) {
  _clearPollTimer();
  SM._pauseTimer = setTimeout(startPoll, ms);
}
function _schedulePoll(ms) {
  _clearPollTimer();
  SM.pollTimer = setTimeout(async () => {
    // FIX-UI-REV2-H-C-02 (P2): sin try/catch aquí, si _pollRun rechaza (p.ej.
    // porque _fetchAxisLimits lanza en el primer ciclo, o porque un path
    // futuro revienta antes del catch envolvente en rotechos-poll.js), la
    // promesa queda sin manejar, el `if` post-await NO se ejecuta y el
    // siguiente ciclo nunca se programa — UI congelada sin telemetría
    // hasta refresh manual. Absorber el rechazo y re-agendar igual.
    try { await _pollRun(); }
    catch (e) { LOG.warn(`_pollRun unexpected:`, e); }
    // Solo re-agendar si no se canceló durante la ejecución
    if (SM.pollTimer !== null) _schedulePoll(_currentPollInterval());
  }, ms);
}
function _currentPollInterval() {
  // Pestaña SECUNDARIA (otra pestaña tomó el control): pollear lento (8s). No la
  // paramos del todo —para que no muestre estado congelado— pero evitamos duplicar
  // la carga del ESP a plena cadencia (eran ~×2 req/s con 2 pestañas abiertas).
  if (AppState.tab.isLeader === false) return 6000;   // 5-oct: < 8 s, la sesión con PIN de RRF
  // H-C (informe 2026-08-17_busca-el-monolito-rotechosjs-v2): durante un M999
  // hay DOS timers de polling en paralelo — el M999 watcher (este setInterval
  // a 1000ms dentro del bloque M999 en RRF.gcode) Y el poll regular
  // re-agendado por `finally → startPoll()` tras el fetch del comando.
  // Devolvemos 10s (efectivamente pausamos el poll regular) mientras el
  // watcher hace su trabajo; cuando detecta reconexión (línea 982) limpia
  // el flag y startPoll() vuelve a programar a la cadencia normal.
  if (AppState.sys.m999InProgress) return 10000;
  // Tab en segundo plano: bajar a 8s salvo que haya trabajo en curso
  if (document.hidden && SM.current !== STATES.RUNNING && SM.current !== STATES.PAUSED)
    return 6000;
    
  // Reconexión agresiva si no hay conexión o fallan los polls
  if (!SM.connected || AppState.poll.fails > 0) {
    // Intentar agresivamente (1s) las primeras 10 veces para un enganche instantáneo.
    // Si sigue sin haber red, relajar a 3s para no saturar.
    return AppState.poll.fails <= 10 ? 1000 : 3000;
  }
  
  const base =
    SM.current === STATES.RUNNING || SM.current === STATES.PAUSED
      ? CFG.pollMs
      : CFG.pollIdleMs;
  return base;
}
// Reanudar polling normal al volver al tab
document.addEventListener(`visibilitychange`, () => {
  if (document.hidden) {
    // H-B (informe 2026-08-17_busca-el-monolito-rotechosjs-v2): si la pestaña
    // queda oculta mientras hay un polling de M37 simulación en curso, lo
    // cancelamos. Motivo: 60 requests cada 30s a `?key=job.file.simulatedTime`
    // gastan batería/CPU del ESP32 sin que el operario los esté mirando. Si
    // vuelve a la pestaña, el resultado se queda en object model y el operario
    // puede re-disparar SIMULAR para verlo.
    if (typeof _cancelSimPolling === `function`) _cancelSimPolling();
    return;
  }
  if (!document.hidden && SM.connected) {
    _schedulePoll(_currentPollInterval());
    // El wake lock se libera al ocultar la página: re-adquirir si sigue el trabajo
    if (SM.current === STATES.RUNNING || SM.current === STATES.PAUSED) _acquireWakeLock();
    // FIX-3: re-arrancar el bucle de suavizado del DRO (que se auto-cancela
    // al ocultarse). La guarda `if (!DRO.raf)` evita duplicados: el _loop
    // solo se re-engancha si el target está desconectado del mostrado.
    if (DRO.connected && !DRO.raf) {
      DRO.tPrev = performance.now();
      DRO.raf = requestAnimationFrame((t) => DRO._loop(t));
    }
  }
});
function startPoll() {
  _clearPollTimer();
  _pollRun();
  _schedulePoll(_currentPollInterval());
}
// ---
// CONTROLES DE EJECUCIÓN (START / PAUSE / ESTOP)
// ---
$(`btnPlayPause`)?.addEventListener(`click`, async () => {
  if (SM.busy) return;
  const s = SM.current;

  // -- LÓGICA DE PAUSA (si estaba RUNNING) --
  if (s === STATES.RUNNING || (AppState.macro.running && !AppState.macro.paused) || (AppState.bord.active && !AppState.bord.paused)) {
    // 26-sep (A7): con un aviso bloqueante abierto (p. ej. «Instala la herramienta» del M6), un
    // M25 por HTTP queda «no terminado» y el OK del diálogo espera detrás: máquina atascada.
    if (typeof SAC !== `undefined` && SAC.active) {
      toast(t(`msg.pausaConDialogo`, `Hay un aviso del firmware esperando respuesta: contéstalo primero. Para parar ya, usa PARO o la seta.`), `warn`);
      return;
    }
    if (AppState.bord.active) {
      if (AppState.bord.pause) {
        AppState.bord.pause();
        toast(t(`msg.bordPaused`, `Contorno pausado`), `warn`);
        log(`Contorno pausado`, `warn`);
        updateButtonStates();
      }
      return;
    }
    if (AppState.macro.running && AppState.macro.enB) {
      toast(t(`msg.macroEnCurso`, `Hay una macro en marcha: espera a que acabe, o párala con PARO o la seta`), `warn`);
      return;
    }
    if (AppState.macro.running && !AppState.macro.paused) {
      RRF.urgentGcode(`M25`).catch(_swallowErr(`esc.M25`));
      AppState.macro.paused = !0;
      toast(t(`msg.macroPausada`, `Macro pausada`), `warn`);
      log(`Macro pausada`, `warn`);
      return;
    }
    if (SM.current !== STATES.RUNNING) return;
    // FIX H-5 (informe 2026-08-17_busca-el-monolito-rotechosjs-v1.md): crear un
    // AbortController para este ciclo SM.busy. Si el watchdog de 30s dispara,
    // abortará el fetch en vuelo (no solo bajará SM.busy). _smBusyAbort se
    // limpia en el finally para no abortar ciclos posteriores.
    const _busyAbort = new AbortController();
    _smBusyAbort = _busyAbort;
    SM.busy = !0;
    // try/finally: si transition()/toast() lanzan, SM.busy NO debe quedar
    // bloqueado (dejaría el botón de PAUSA inerte hasta el watchdog de 5s).
    try {
      SM.pauseRequestTime = Date.now();
      // FIX H-1 (kimi2 2026-08-17): esperar ACK del firmware antes de
      // transicionar a PAUSED. Si urgentGcode rechaza (5 reintentos
      // agotados = red caída o firmware busy), revertir la UI a RUNNING
      // para que la SM nunca diga "PAUSADO" mientras la fresa sigue
      // cortando. urgentGcode ya devuelve Promise (rotechos.js:966).
      // FIX H-5: pasar signal del controller para que el watchdog pueda
      // matar este fetch concreto.
      toast(t(`msg.pausando`, `Pausando…`), `warn`);
      const _pauseOk = await RRF.urgentGcode(`M25`, 5, 500, { signal: _busyAbort.signal }).catch(() => false); // 15-sep: rechaza, no devuelve false
      if (!_pauseOk) {
        // La SM sigue en RUNNING (ya estaba ahí — el M25 fue rechazado por
        // el firmware/red). NO hacemos transition(RUNNING) porque el guard
        // de línea 655 lo rechazaría por "TRANSITIONS inválida". Solo
        // avisamos al operario: la UI ya muestra RUNNING, pero queremos
        // que sepa que intentó pausar y NO PUDO.
        toast(t(`msg.pausaNoAplicada`, `⚠ No se pudo pausar: el firmware no respondió. La fresa SIGUE CORTANDO — no te acerques.`), `err`);
        log(`✗ M25 sin ACK del firmware — la SM permanece en RUNNING`, `err`);
        return;
      }
      SM.transition(STATES.PAUSED, `PAUSA pulsada`);
      log(`M25 — Pausado (urgente)`, `cmd`);
      // Nueva generación: el ciclo en vuelo (que leyó `processing`) se descarta.
      AppState.poll.bumpGen();
    } finally { SM.busy = !1; if (_smBusyAbort === _busyAbort) _smBusyAbort = null; }
    _pollRun();
    return;
  }

  // -- LÓGICA DE START / RESUME --
  if (typeof _anyEndstopTriggered === `function` && _anyEndstopTriggered()) {
    toast(t(`msg.endstopBlock`, `✕ Acción bloqueada: final de carrera activo`), `err`);
    log(`Acción rechazada — endstop triggered`, `warn`);
    return;
  }
  if (AppState.bord.active && AppState.bord.paused && AppState.bord.resume) {
    AppState.bord.resume();
    toast(t(`msg.bordResumed`, `Contorno reanudado`), `ok`);
    log(`Contorno reanudado`, `cmd`);
    updateButtonStates();
    return;
  }
  if (AppState.macro.running && !AppState.macro.paused) {
    toast(t(`msg.macroEnCurso`, `Hay una macro en marcha: espera a que acabe, o párala con PARO o la seta`), `warn`);
    return;
  }
  if (AppState.macro.paused) {
    RRF.gcode(`M24`);
    AppState.macro.paused = !1;
    toast(t(`msg.macroReanudada`, `Macro reanudada`), `ok`);
    log(`Macro reanudada`, `cmd`);
    return;
  }
  if (s === STATES.PAUSED) {
    // 5-oct: la pausa pide apagar el Makita y resume.g no puede encenderlo: sin esto la fresa
    // bajaba a cortar parada.
    if (document.body.classList.contains(`spindle-manual`) && !(await confirmDashboard(t(`dlg.spManual.title`, `ENCIENDE EL HUSILLO`),
      t(`dlg.spManual.msgResume`, `Husillo manual: enciéndelo con su interruptor y espera a que coja velocidad antes de reanudar. RotechOS no puede encenderlo.`)))) return;
    // FIX H-5 (informe 2026-08-17_busca-el-monolito-rotechosjs-v1.md): crear un
    // AbortController para este ciclo SM.busy. Si el watchdog de 30s dispara,
    // abortará el fetch en vuelo del M24.
    const _busyAbort = new AbortController();
    _smBusyAbort = _busyAbort;
    SM.busy = !0;
    let ok;
    // try/finally: garantizar SM.busy = false aunque la red/transición fallen.
    try {
      // 26-sep (C1): si resume.g aborta (sin homing, o X/Y sin corriente tras una caída), RRF
      // reanuda IGUAL, con el husillo parado (GCodes2.cpp:1152-1157). Se mira antes del M24; solo
      // se bloquea con evidencia: si la lectura falla, el M24 fallaría igual sin red.
      const _ejes = _unwrap(await _fetchModel(`move.axes`, 2000));
      const _motivoNoReanudar = !Array.isArray(_ejes) ? ``
        : _ejes.slice(0, 3).some((a) => a && a.homed === false) ? `un eje ha perdido la referencia`
        : _ejes.slice(0, 2).some((a) => a && typeof a.percentCurrent === `number` && a.percentCurrent < 100) ? `X/Y siguen sin corriente completa (caída de tensión)`
        : ``;
      if (_motivoNoReanudar) {
        toast(t(`msg.noReanudar`, `NO se reanuda: ${_motivoNoReanudar}. Cancela el trabajo con STOP y vuelve a hacer HOME.`, { motivo: _motivoNoReanudar }), `err`);
        log(`Reanudar rechazado: ${_motivoNoReanudar}`, `err`);
        return;
      }
      SM.lastTickTime = Date.now();
      SM.transition(STATES.RUNNING, `Reanudando`);
      // Nueva generación: el ciclo en vuelo (que leyó `paused`) se descarta.
      AppState.poll.bumpGen();
      ok = await RRF.gcode(`M24`, { signal: _busyAbort.signal });
    } finally { SM.busy = !1; if (_smBusyAbort === _busyAbort) _smBusyAbort = null; }
    ok
      ? (toast(t(`msg.reanudandoTrabajo`, `Reanudando trabajo`), `ok`), log(`M24 — Trabajo reanudado`, `cmd`))
      : (SM.transition(STATES.PAUSED, `Error al reanudar`), toast(t(`msg.errorAlReanudar`, `Error al reanudar`), `err`));
    return;
  }
  if (s !== STATES.READY) {
    toast(t(`msg.notReady`, `Acción bloqueada: la máquina no está en estado LISTO (no acepta cortes). Espera a que termine el trabajo actual o pulsa STOP en la barra superior. Si la máquina lleva varios minutos quieta y sigue en PAUSADA, pulsa REANUDAR.`), `warn`);
    return;
  }

  if (AppState.sys.postEmergencyReset) {
    toast(t(`msg.noHomedEstop`, `Has pulsado el botón rojo de emergencia — antes de empezar otro trabajo tienes que volver a hacer HOME en los 3 ejes (botón HOME de la barra superior o menú COCKPIT). Si intentas cortar sin HOME, la pieza saldrá desviada.`), `err`);
    log(`START rechazado — homing obligatorio post-emergencia`, `warn`);
    return;
  }
  if (!AppState.limits.allHomed) {
    const proceed = await confirmDashboard(
      t(`dlg.noHomed.title`, `MÁQUINA NO REFERENCIADA`),
      t(`dlg.noHomed.msg`, `<p style="color:var(--red)">¡ATENCIÓN! No has hecho HOME de los ejes. Con «Requerir HOME» activado (lo normal) la máquina <strong>rechazará el trabajo</strong>. Solo en modo mantenimiento arrancará, y entonces no sabe dónde está y los límites de seguridad <strong>no funcionarán</strong>: la fresa puede salirse del material o golpear la sujeción.</p><p>Solución: cancela este diálogo y pulsa <strong>HOME</strong> (G28) en la barra superior. La máquina referenciará los 3 ejes y entonces sí podrás iniciar con seguridad.</p><p>¿Iniciar igualmente? (NO recomendado)</p>`),
    );
    if (!proceed) return;
    log(`Inicio forzado sin homing por el usuario`, `warn`);
  }

  // ── Guarda de ORIGEN SIN FIJAR (la trampa nº1 del novato) ──
  // Offsets del WCS a cero en los tres ejes = nadie fijó el cero de pieza:
  // el trabajo arrancaría referido a la ESQUINA de la máquina, no al material.
  // Detección: WCS == MCS en todos los ejes (offset = diferencia entre ambos).
  if ([0, 1, 2].every((i) => Math.abs((DRO.tMcs[i] ?? 0) - (DRO.tWcs[i] ?? 0)) < 0.001)) {
    const _goOn = await confirmDashboard(
      t(`dlg.noOrigin.title`, `ORIGEN DE PIEZA SIN FIJAR`),
      t(`dlg.noOrigin.msg`, `<p style="color:var(--yellow)">No has fijado el cero de la pieza (X0 Y0 Z0): si pulsas Iniciar, el corte empezará en la <strong>esquina de la MÁQUINA</strong>, no donde está tu material — arruinarás la pieza y la fresa puede golpear la sujeción.</p><p><strong>Cómo fijar el origen antes de iniciar:</strong></p><ol style="text-align:left;line-height:1.7;margin:6px 0 10px 18px"><li>Posiciona la fresa sobre la esquina de la pieza que quieras como X0 Y0 (canto superior izquierdo, por convención).</li><li>Pulsa <strong>Zero XY</strong> en el panel DERECHO (icono de diana).</li><li>Baja la fresa hasta tocar la superficie de la pieza (papel entre fresa y mesa) y pulsa <strong>Zero Z</strong>.</li><li>Como alternativa más fiable, usa <strong>Sonda Z</strong> (icono de antena) en la barra superior — la sonda mide la altura automáticamente.</li></ol><p>Si tu G-code ya viene en coordenadas absolutas de máquina y sabes lo que haces, puedes continuar. Si no, cancela y fija el origen primero.</p><p>¿Iniciar igualmente?</p>`),
    );
    if (!_goOn) return;
    log(`START con offsets de pieza a cero — confirmado por el usuario`, `warn`);
  }

  // ── Guarda de HUSILLO SIN DWELL de spin-up (G-code de post ajeno) ──
  // vizLoadGCode marca SM.gcodeSpindleNoDwell si el archivo enciende el husillo (M3)
  // sin ninguna pausa G4. El postprocesador propio ya inyecta G4 S3; esto cubre G-code
  // de OTROS CAM. Aviso descartable, mismo patrón que los gates de homing/origen.
  // 4-oct: con husillo manual la espera no importa; lo que rompe la fresa es empezar con el Makita apagado.
  if (document.body.classList.contains(`spindle-manual`)) {
    if (!(await confirmDashboard(t(`dlg.spManual.title`, `ENCIENDE EL HUSILLO`),
      t(`dlg.spManual.msg`, `Husillo manual: enciéndelo con su interruptor y espera a que coja velocidad antes de iniciar. RotechOS no puede encenderlo.`)))) return;
  } else if (SM.gcodeSpindleNoDwell) {
    const _spinOk = await confirmDashboard(
      t(`dlg.noSpinUp.title`, `HUSILLO SIN ESPERA DE ARRANQUE`),
      t(`dlg.noSpinUp.msg`, `<p style="color:var(--yellow)">El G-code enciende el husillo (M3) pero NO espera a que alcance las RPM objetivo antes de empezar a cortar (falta G4): el primer corte arrancará con el husillo aún acelerando, con riesgo de <strong>rotura de fresa</strong> y mal acabado.</p><p><strong>Cómo arreglarlo:</strong></p><ul style="text-align:left;line-height:1.7;margin:6px 0 10px 18px"><li>Si generas el G-code con el postprocesador de RotechOS, este problema NO debería aparecer — regenera el archivo desde tu CAM.</li><li>Si viene de otro CAM (Fusion, VCarve, EstlCAM…): abre el archivo en CONFIGURACIÓN → Macros o en el editor de texto, busca la línea <code>M3 S…</code> y añade justo después <code>G4 S3</code> (pausa de 3 segundos).</li><li>Si tu husillo es Makita manual y ya está a tope antes de empezar, puedes continuar.</li></ul><p>¿Iniciar igualmente?</p>`),
    );
    if (!_spinOk) return;
    log(`START con M3 sin dwell de spin-up — confirmado por el usuario`, `warn`);
  }

  // ── Checklist pre-vuelo (solo en Modo Escuela) ──
  if (document.body.classList.contains(`school-mode`)) {
    const _checkOk = await confirmDashboard(
      t(`dlg.checklist.title`, `Checklist pre-mecanizado`),
      t(`dlg.checklist.msg`,
        `<div style="text-align:left;line-height:2;font-size:13px">` +
        `<div>☐ <strong>Fresa apretada</strong> — ¿La tuerca de la pinza está bien firme?</div>` +
        `<div>☐ <strong>Pieza fijada</strong> — ¿El material está bien sujeto a la mesa?</div>` +
        `<div>☐ <strong>Origen Z correcto</strong> — ¿Has hecho sonda Z o Zero Z manual?</div>` +
        `<div>☐ <strong>Origen XY correcto</strong> — ¿La fresa está sobre la esquina correcta?</div>` +
        `<div>☐ <strong>Área despejada</strong> — ¿No hay cables, pinzas o herramientas en la zona de trabajo?</div>` +
        `</div><p style="color:var(--yellow);font-size:11px;margin-top:10px">Confirma solo si todos los puntos están verificados.</p>`),
    );
    if (!_checkOk) return;
  }

  const _cXyz = SM._prevXYZ ?? [0, 0, 0],
    _cF = (v) => (v ?? 0).toFixed(3);
  // 27-sep (revisión de la integración): decía «Origen G54» fuera cual fuera el WCS activo, y
  // las cifras son la posición actual en ese WCS. move.workplaceNumber es base 0 (Move.cpp:139).
  const _wiStart = AppState.cache.workplaceNumber ?? 0;
  const _wcsName = _wiStart <= 5 ? `G${54 + _wiStart}` : `G59.${_wiStart - 5}`;
  if (
    !(await confirmDashboard(
      t(`dlg.startJob.title`, `Iniciar mecanizado`),
      `<p>${t(`dlg.startJob.file`, `Archivo`)}: <strong>${escHtml(SM.loadedFile || "—")}</strong></p>` +
      `<p style="margin-top:4px">${t(`dlg.startJob.posWcs`, `Posición en ${_wcsName}`, { wcs: _wcsName })}: X${_cF(_cXyz[0])} Y${_cF(_cXyz[1])} Z${_cF(_cXyz[2])}</p>` +
      `<p style="color:var(--yellow);margin-top:4px">${t(`dlg.startJob.check`, `Verifica que la fresa está sobre la pieza.`)}</p>`,
    ))
  )
    return;
  // C§15 (auditoria 15-sep): entre el `if (s !== STATES.READY)` de arriba y este
  // punto hay hasta CINCO dialogos con `await`, y en modo escuela el operario
  // tarda. La maquina puede haber cambiado de estado por su cuenta mientras
  // tanto —un PARO desde el movil, un reset, otro fichero cargado— y el M24
  // salia igual, sobre un estado que ya no es el que se evaluo. Se revalida
  // todo lo que se comprobo al entrar, no solo el estado: `postEmergencyReset`
  // se enciende justo en ese caso y es el que no deja arrancar sin homing.
  if (SM.current !== STATES.READY || SM.busy || AppState.sys.postEmergencyReset) {
    toast(t(`msg.startEstadoCambio`,
      `La máquina ha cambiado de estado mientras confirmabas, así que NO se ha iniciado nada. Comprueba en qué estado está y vuelve a pulsar INICIAR si sigue siendo lo que quieres.`), `warn`);
    log(`START cancelado — el estado cambio durante los dialogos (${SM.current}${SM.busy ? `, ocupada` : ``}${AppState.sys.postEmergencyReset ? `, tras paro` : ``})`, `warn`);
    return;
  }
  // FIX H-5 (informe 2026-08-17_busca-el-monolito-rotechosjs-v1.md): crear un
  // AbortController para este ciclo SM.busy. Si el watchdog de 30s dispara,
  // abortará el fetch en vuelo del startCmd (M24 o M564+G92+M24).
  const _busyAbort = new AbortController();
  _smBusyAbort = _busyAbort;
  SM.busy = !0;
  try {
    try { await _pollRun(); } catch {}
    SM.jobStartTime = Date.now();
    SM.wasSeenRunning = false;
    SM.totalPausedMs = 0;
    SM.effectiveMs = 0;
    SM.lastTickTime = Date.now();
    SM.transition(STATES.RUNNING, `START pulsado`);
    // Nueva generación: el ciclo en vuelo (que leyó `idle`) se descarta.
    AppState.poll.bumpGen();
    if (typeof KIN !== "undefined" && KIN.waitReady) await KIN.waitReady();
    // Sin homing, H0. Sin G92 (26-sep): en RRF marca los ejes como referenciados
    // (GCodes3.cpp:143), se saltaba la guarda de start.g y dejaba una referencia
    // falsa para el M6/Sonda Z siguiente. No M18 para deshacerlo: Z cae. La S del
    // M564 RESPETA la preferencia del user (_softLimitsEnabled). Antes era S1
    // forzado, lo que ANULABA el setting del user durante el trabajo y dejaba
    // la máquina en S1 tras terminar.
    const _slS = _softLimitsEnabled ? 1 : 0;
    const _forcedNoHome = !AppState.limits.allHomed; // el arranque llevará M564 H0
    const startCmd = AppState.limits.allHomed
      ? `M24`
      : `M564 H0 S${_slS}\nM24`;
    // FIX HALLAZGO-3: marca para que el poll pueda restaurar el M564 si el
    // trabajo nunca llega a correr (start.g aborta ASÍNCRONAMENTE, después de
    // que rr_gcode ya haya contestado 200). Se consume en _uiResolveStateMachine.
    if (_forcedNoHome) SM.forcedNoHomeStart = true;
    let okS = false;
    try {
      okS = await RRF.gcode(startCmd, { signal: _busyAbort.signal });
    } finally {
      // FIX HALLAZGO-3 (informe 2026-08-17_busca-flujo-de-trabajo-completo-del-operario-v1.md):
      // si el arranque forzado sin homing NO llega a salir (timeout, watchdog,
      // red caída, {err:1} del firmware), RRF puede haber aplicado ya el
      // `M564 H0` de la cadena y la máquina se queda SIN enforcement de homing
      // hasta el siguiente G28 (homeall.g:85). Restauramos aquí con la misma
      // expresión que usan config.g:127 y homeall.g:85 (fuente única: los globals).
      // NO se restaura cuando el trabajo sí arrancó: un M564 H1 con los ejes sin
      // referenciar abortaría el corte en curso.
      if (_forcedNoHome && !okS) {
        SM.forcedNoHomeStart = false;
        try {
          await RRF.gcode(`M564 H{global.requireHoming ? 1 : 0} S{global.softLimitsOn ? 1 : 0}`);
          log(`M564 restaurado (el inicio forzado sin homing no llegó a arrancar)`, `warn`);
        } catch (e) { _swallowErr(`startCmd.M564restore`)(e); }
      }
    }
    okS
      ? (toast(t(`msg.iniciandoSmloadedfile`, `Iniciando: ${SM.loadedFile || "—"}`, { "SM.loadedFile || \"—\"": SM.loadedFile || "—" }), `ok`),
        log(`Iniciado (Homed:${AppState.limits.allHomed}): ${SM.loadedFile || "—"}`, `cmd`),
        $(`jogPanel`)?.classList.add(`hidden`))
      : (SM.transition(STATES.READY, `Error al iniciar`), toast(t(`msg.jobStartErr`, `Error al iniciar trabajo`), `err`));
  } finally { SM.busy = !1; if (_smBusyAbort === _busyAbort) _smBusyAbort = null; }
});
// eslint-disable-next-line no-unused-vars -- usado por sleep fuera de este módulo (rotechos-fm.js:276 + rotechos-pendant.js:313 + rotechos-viz.js:469 + rotechos-tft.js:313)
function sleep(ms) {
  return new Promise((res) => setTimeout(res, ms));
}
// H-03: helper para silenciar promesas con log. Antes había 20+ .catch(()=>{})
// en operaciones críticas (E-Stop, M25 de cancelación, fallback SEDA) que
// tragaban errores en silencio. Si urgentGcode('M112') falla (WiFi caído),
// el operario pulsa E-Stop y la UI no muestra nada. Ahora registramos
// en consola + estado para diagnóstico, y devolvemos el error al caller.
function _swallowErr(name) {
  return (e) => {
    try { LOG.warn(`async '${name}' rejected:`, e); } catch {}
    if (typeof SM !== 'undefined' && SM && name) SM.lastAsyncError = { name, err: String(e), at: Date.now() };
  };
}
// Ventana anti-rebote del paro de emergencia. OJO-4 (t_df206ae8) midio que un
// doble clic en el PARO del cockpit envia DOS M112, y que el pendant no lo hace:
// una asimetria real entre las dos vistas.
//
// El criterio aqui es delicado y conviene dejarlo escrito: un boton de
// emergencia **no puede dejar de responder nunca**. Por eso la ventana es
// CORTA — 400 ms — y esta calibrada para absorber el rebote de un dedo o de un
// raton, no para ignorar una segunda pulsacion deliberada. Si el operario
// vuelve a pulsar medio segundo despues porque no las tiene todas consigo, el
// M112 sale. Lo unico que se descarta es el duplicado inmediato, que no aporta
// nada y ademas re-arma los triggers de seguridad dos veces seguidas.
let _ultimoEStop = 0;
const _ESTOP_REBOTE_MS = 400;

// ESTOP-MACRO-LIMP (t_70974bbf, 2026-09-02): helper ÚNICO para limpiar el
// estado de macro de usuario. Antes, cada salida de macro (paro de
// emergencia, cancelacion manual, fin natural reportado por el poll)
// DUPLICABA las cuatro asignaciones, y un E-Stop se olvidaba de la fila
// verde `running` en el sidebar. Tres llamadores, una sola definicion.
//   - btnEStop (este handler)
//   - cancelMacro (rotechos.js canceladora manual)
//   - _uiResolveStateMachine (poll handler, fin natural o por error)
// NO toca `AppState.macro.detectCnt` — eso lo gobierna el poll cuando
// confirma arranque, y resetearlo aquí robaría detecciones en vuelo.
function _resetMacroState() {
  if (AppState.macro.row) {
    AppState.macro.row.classList.remove(`running`);
    AppState.macro.row = null;
  }
  AppState.macro.running = !1;
  AppState.macro.paused = !1;
  AppState.macro.name = ``;
  AppState.macro.enB = !1;
}

($(`btnEStop`)?.addEventListener(`click`, async () => {
  const _ahora = Date.now();
  if (_ahora - _ultimoEStop < _ESTOP_REBOTE_MS) {
    LOG.warn(`E-Stop: segundo M112 descartado a ${_ahora - _ultimoEStop}ms del anterior (rebote)`);
    return;
  }
  _ultimoEStop = _ahora;
  // 15-sep: el paro corta también lo que se mueve desde JS (bordeador, aplanado).
  AppState.bord.cancel?.();
  // ESTOP-MACRO-LIMP (t_70974bbf, 2026-09-02): si había una macro de
  // usuario en curso, el operador la ve abortada por el paro, no terminada
  // con éxito. Limpiamos ANTES del SM.transition a ERROR para que el
  // siguiente poll (cuando llegue tras M999) ya no encuentre banderas
  // sucias y NO pueda emitir el toast mentiroso "Macro completada".
  // El toast "abortada por paro" sale DESPUÉS del toast genérico de
  // E-Stop, en orden temporal y sin pisarlo (los toasts se encolan, no
  // se sobreescriben: rotechos.js:_toastPush).
  const _hadMacroRunning = AppState.macro.running;
  _resetMacroState();
  // Parada de hardware inmediata e incondicional
  // FIX HALLAZGO-1 (informe 2026-08-17_busca-flujo-de-trabajo): si el
  //   urgentGcode de M112 rechaza (WiFi caída), el operario necesita
  //   ver el aviso en #consoleOut, no solo en LOG.warn y SM.lastAsyncError
  //   (slots opacos). Mantenemos _swallowErr para diagnóstico y añadimos
  //   un log() UI con el mismo literal que urgentGcode emite en su
  //   camino de error (rotechos.js:1106) — defensa en profundidad.
  //   Compatible con H-2 (t_8b105d57): ese fix re-arma triggers con
  //   RRF.gcode y también usa _swallowErr; ningún comportamiento cambia.
  // 26-sep (revision adversaria): el boton decia «M112 ENVIADO» aunque no hubiera
  // salido. Ahora lleva su estado, y si falla, el sondeo lo reenvia al volver la red.
  SM._estopM112 = `enviando`;
  RRF.urgentGcode(`M112`).then(() => { SM._estopM112 = `ok`; window.updateStateUI?.(); }).catch((e) => {
    _swallowErr(`btnEStop.M112`)(e);
    SM._estopM112 = `fallo`;
    SM._estopFalloTs = Date.now();
    window.updateStateUI?.();
    log(`⚠ btnEStop: M112 NO enviado (red caída): use el botón físico de la máquina`, `err`);
  });
  // H-2 (2026-08-17/18 — tarjeta t_8b105d57): tras M112, re-armar los
  // triggers de seguridad con la MISMA secuencia que btnRecover. Antes,
  // un E-Stop dejaba el escudo M581 desarmado hasta el siguiente homing
  // o un RECUPERAR manual — exactamente el momento en el que el operario
  // más lo necesita. RRF.gcode (no urgentGcode) para espejar el patrón de
  // btnRecover (:4747-4749). El catch silencioso encaja con la política
  // de _swallowErr del módulo: si la red cae AQUÍ, el escudo físico del
  // chasis sigue siendo defensa; el operario ya recibió el toast M112.
  RRF.gcode(`set global.homingInProgress = false\nM98 P"0:/sys/recover_triggers.g"`).catch(_swallowErr(`btnEStop.recoverTriggers`));
  // ESTOP-3 (2026-08-30): la bandera va ANTES de la transicion, no despues.
  // `SM.transition()` re-arma el poll cuando `prev === RUNNING` (rotechos.js:715-721)
  // y ese ciclo arranca YA, dentro de la misma vuelta del bucle de eventos. Si la
  // bandera se pusiera despues, el ciclo en vuelo podria llegar al guard de
  // rotechos-poll.js:492 con `_rebootPending` todavia en false y devolver el badge
  // a INACTIVO con la maquina recien parada de emergencia. Ese era el rojo
  // determinista de tests/e2e-paro-emergencia.spec.js:214.
  SM._rebootPending = !0;
  // Nueva generación: un ciclo en vuelo no puede repintar RUNNING tras el paro.
  AppState.poll.bumpGen();
  SM.transition(STATES.ERROR, `PARADA DE EMERGENCIA`);
  toast(t(`msg.estopActivated`, `✕ PARADA DE EMERGENCIA ACTIVADA`), `err`);
  log(`✕ M112 — Parada de emergencia (Hardware Halting)`, `err`);
  // ESTOP-MACRO-LIMP (t_70974bbf, 2026-09-02): si abortamos una macro de
  // usuario, el operario DEBE ver por qué desapareció — no un "Macro
  // completada" verde al siguiente poll. Sale después del toast genérico
  // del paro (el push es FIFO: ver `_toastPush`); severidad `warn` para
  // distinguir el motivo de la macro del "PARADA DE EMERGENCIA" del paro.
  // Solo se emite si había una macro en curso (S4 del spec exige silencio
  // cuando no la hay).
  if (_hadMacroRunning) {
    toast(t(`msg.macroAbortada`, `Macro abortada por paro de emergencia`), `warn`);
    log(`Macro abortada por paro de emergencia`, `warn`);
  }
  // 15-sep (C-10): el sondeo NO se para del todo. Antes moría aquí y solo volvía con
  // RESET, M999 o al cambiar de pestaña: si la placa se reiniciaba desde otro sitio,
  // esta pantalla se quedaba en ERROR con el DRO congelado y el operario podía mandar
  // un reset a una máquina que ya estaba referenciando. Cadencia de reposo (3 s).
  // SM._rebootPending impide que un ciclo devuelva el badge a INACTIVO tras el paro.
  _clearPollTimer();
  _schedulePoll(CFG.pollIdleMs);
}),
  document.addEventListener(`keydown`, (e) => {
    if (e.key !== ` `) return;
    const tag = document.activeElement?.tagName;
    if (tag === `INPUT` || tag === `TEXTAREA` || tag === `SELECT`) return;
    // D-03 FIXE2E-02 (2026-08-04): si hay un modal abierto, el Space pertenece al
    // modal (cerrar, click sintético del botón con foco, scroll, etc.). El
    // patrón BUG-02 ya está en KBSHORTCUTS (rotechos.js:4902) pero NO se
    // extendió a este handler; sin el guard, Space con foco en <button> dentro
    // del modal disparaba M24/M25/M112 y "atravesaba" el modal.
    // Re-aplicado tras 7d43ad7 que lo borró accidentalmente al tocar el mapping M→IDLE para SIMULATING.
    if (hasVisibleModal()) return;
    e.preventDefault();
    if (AppState.bord.active) {
      if (AppState.bord.paused) {
        $(`btnPlayPause`)?.click();
      }
      return;
    }
    // 26-sep: el M25 espera detrás de una macro de la lista («Macro pausada» era
    // falso), y en READY Espacio pulsaba INICIAR con la macro en marcha.
    if (AppState.macro.running && AppState.macro.enB) {
      toast(t(`msg.macroEnCurso`, `Hay una macro en marcha: espera a que acabe, o párala con PARO o la seta`), `warn`);
      log(`Espacio con macro en marcha: no se pausa (el M25 esperaría detrás de la macro)`, `warn`);
    } else if (SM.current === STATES.RUNNING) {
      $(`btnPlayPause`)?.click();
    } else if (SM.current === STATES.PAUSED || SM.current === STATES.READY) {
      $(`btnPlayPause`)?.click();
    } else if (AppState.macro.running && !AppState.macro.paused) {
      RRF.urgentGcode(`M25`).catch(_swallowErr(`esc.M25`));
      AppState.macro.paused = !0;
      toast(t(`msg.macroPausada`, `Macro pausada`), `warn`);
      log(`Macro pausada (Espacio)`, `warn`);
    } else if (AppState.macro.paused) {
      // 16-sep (C§11): reanudar una MACRO es M24 y nada más. Antes, sin homing, mandaba
      // `M564 H0 + G92 X0 Y0 Z0`: fijaba la posición actual como cero y (en RRF) daba los
      // ejes por referenciados, así que los soft limits quedaban con el origen equivocado
      // y sin que nadie lo dijera. El botón de reanudar nunca hizo eso; esto lo iguala.
      RRF.urgentGcode(`M24`).catch(_swallowErr(`macro.reanudar`));
      AppState.macro.paused = !1;
      toast(t(`msg.macroReanudada`, `Macro reanudada`), `ok`);
      log(`Macro reanudada (Espacio)`, `cmd`);
    }
  }),
  document.addEventListener(`keydown`, async (e) => {
      // UI-2 fix Gemini validación cruzada 2026-07-07: focus trap en modales.
      // Interceptar Tab y Shift+Tab cuando hay modal abierto para confinar el foco.
      // (Debe ir ANTES del filtro de Escape para que Tab funcione aunque el foco esté en un input.)
      if (e.key === `Tab`) {
        const openModalsForTab = $$(MODAL_OPEN_SELECTOR);
        if (openModalsForTab.length) {
          const modal = openModalsForTab[openModalsForTab.length - 1];
          const focusable = modal.querySelectorAll(
            `a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])`
          );
          if (focusable.length > 0) {
            const first = focusable[0];
            const last = focusable[focusable.length - 1];
            if (e.shiftKey && document.activeElement === first) {
              e.preventDefault();
              last.focus();
              return;
            } else if (!e.shiftKey && document.activeElement === last) {
              e.preventDefault();
              first.focus();
              return;
            }
          }
        }
      }
      if (e.key !== `Escape`) return;
      const _ae = document.activeElement;
      const _tag = _ae?.tagName;
      const openModals = $$(MODAL_OPEN_SELECTOR);
      const modalVisible = hasVisibleModal();
      if (_tag === `INPUT` || _tag === `TEXTAREA` || _tag === `SELECT`) {
        // FIX H-6-2 (revisado 2026-07-28): con un modal abierto, blurear y seguir
        // para que Escape lo cierre (antes el return dejaba al operario sin poder
        // cerrarlo si tenía el foco en un campo).
        // SIN modal abierto hay que MANTENER el return: el resto de este handler
        // es la ruta de cancelación (bordeador, macro y, si SM.current != IDLE,
        // urgentGcode("M25\nM0\nT0\nM5") + clearJob). Sin este return, pulsar
        // Escape mientras se escribe en cualquier campo ABORTA EL TRABAJO EN CURSO.
        if (!openModals.length) return;
        _ae.blur();
      }

    if (modalVisible) {
      e.preventDefault();
      // BUG-V01 fix Gemini validación cruzada 2026-07-07: stopPropagation obligatorio
      // para evitar que Escape cierre el modal Y EJECUTE M112 (E-STOP físico).
      // El handler de Escape → M112 vive en KBSHORTCUTS (handler keyup/keydown
      // sobre window). Sin stopPropagation, cerrar modal = paro emergencia,
      // porque la fase document→window propagaría Escape al handler.
      e.stopPropagation();
      const closedModal = openModals[openModals.length - 1];
      if (!closedModal) return;
      // CONFIGURACION tiene una guarda de «tienes cambios sin guardar» colgada
      // de su boton de cerrar (rotechos-ui-feedback.js:248). Quitarle la clase
      // aqui se la saltaba: con Escape se perdian los cambios de CUALQUIERA de
      // sus 27 pestañas sin preguntar nada. Medido el 21-sep.
      // `stopImmediatePropagation` corta ademas el handler de Escape del propio
      // modal (rotechos-config-modal.js), que si no abriria un SEGUNDO dialogo.
      // Solo se desvia cuando HAY algo que perder. Si no hay ninguna pestaña
      // sucia, Escape cierra por el camino de siempre: desviarlo igualmente
      // rompia los dos e2e que abren este modal a las bravas
      // (`classList.add('show')`, sin cargar su modulo), donde el boton existe
      // en el HTML pero su listener no, asi que el click no cerraba nada.
      // ...y SOLO con la maquina quieta. ESC es la tecla del paro: con un
      // trabajo, una macro o un aplanado en marcha, meter por delante un
      // dialogo de «tienes cambios sin guardar» retrasa la parada. Lo destapo
      // `e2e-paro-husillo-facing-escuela FC-3`, que aplana con la pestaña
      // sucia y pulsa ESC para parar: con la guarda incondicional, el primer
      // ESC abria el dialogo en vez de cerrar, y el paro no llegaba.
      // Perder unos campos de configuracion es barato; retrasar un paro no.
      const _quieta = !(AppState?.bord?.active) && !(AppState?.macro?.running)
        && SM?.current !== STATES.RUNNING && SM?.current !== STATES.PAUSED;
      if (closedModal.id === `machineConfigModal` && _quieta
        && $q(`#machineConfigModal .mcfg-tab.dirty`)) {
        const _x = $(`btnMcfgClose`);
        if (_x) { e.stopImmediatePropagation(); _x.click(); return; }
      }
      closedModal.classList.remove(`show`);
      // UI-2 fix Gemini validación cruzada 2026-07-07: devolver foco al elemento
      // que abrió el modal (evita foco perdido tras cierre).
      if (window.__rotechosModalLastFocus) {
        try { window.__rotechosModalLastFocus.focus(); } catch {}
        window.__rotechosModalLastFocus = null;
      }
      return;
    }

    const openSheet = $q(`.rm-macros-modal.show`);

    if (openSheet) {
      e.preventDefault();
      e.stopPropagation();
      openSheet.classList.remove(`show`);
      return;
    }

    // 15-sep: con algo que cancelar, si ESC es la tecla del paro, manda el paro por
    // #btnEStop y una sola vez. Antes esta rama cancelaba y, tras un await, seguía
    // mandando Z+50 y SEDA mientras KBSHORTCUTS mandaba M112 con la misma pulsación.
    if ((AppState.bord.cancel || AppState.macro.running || SM.current !== STATES.IDLE) &&
        window.KBSHORTCUTS?.stopKey?.() === e.key) {
      e.preventDefault();
      e.stopPropagation();
      $(`btnEStop`)?.click();
      return;
    }
    if (AppState.bord.cancel) {
      e.preventDefault();
      AppState.bord.cancel();
      _clearPollTimer();
      SM._cancelInProgress = true;
      try {
        await RRF.urgentGcode(`M25\nM0\nT0\nM5`);
      } finally { SM._cancelInProgress = false; startPoll(); } // 15-sep: el poll quedaba parado; _restoreSilk no existía
      toast(t(`msg.contornoCancelado`, `Contorno cancelado`), `warn`);
      log(`Contorno cancelado por ESC`, `warn`);
      return;
    }
    if (AppState.macro.running) {
      e.preventDefault();
      await cancelMacro();
      return;
    }
    if (SM.current === STATES.IDLE) return;
    if (SM._cancelInProgress) return;
    e.preventDefault();
    SM._cancelInProgress = !0;
    const estopBtn = $(`btnEStop`);
    if (estopBtn) {
      estopBtn.style.transition = `transform .06s`;
      estopBtn.style.transform = `scale(.96)`;
      if (estopBtn._feedbackTimer) clearTimeout(estopBtn._feedbackTimer);
      estopBtn._feedbackTimer = setTimeout(() => {
        estopBtn.style.transform = ``;
        estopBtn._feedbackTimer = null;
      }, 120);
    }
    _clearPollTimer();
    // FIX H-5 (informe 2026-08-17_busca-el-monolito-rotechosjs-v1.md): crear un
    // AbortController para este ciclo SM.busy. Si el watchdog de 30s dispara
    // (poco probable aquí porque ESC es interactivo, pero el patrón es el
    // mismo que PAUSE/RESUME/START), abortará el fetch en vuelo del M25+M0+T0+M5.
    const _busyAbort = new AbortController();
    _smBusyAbort = _busyAbort;
    SM.busy = !0;
    // FIX: try/finally garantiza SM.busy = false incluso si falla la red
    try {
      try { await RRF.urgentGcode(`M25\nM0\nT0\nM5`, 5, 500, { signal: _busyAbort.signal }); } catch {}
      clearJob();
      SM.transition(STATES.IDLE, `cancelado por ESC`);
      toast(t(`msg.jobCancelled`, `Trabajo cancelado (ESC)`), `warn`);
      log(`ESC — M25+M0+T0+M5+Z↑+SEDA (urgente)`, `warn`);
      await RRF.gcode(`G91\nG1 Z${CFG.safeZClear ?? 50} F1000\nG90`).catch(_swallowErr(`cancel.zSafe`));
      // Restaurar modo SEDA tras cancelar
      try {
        const r = await RRF.gcode(`M98 P"${MACROS.setSilk}"`);
        if (!r) throw new Error(`Fallback`);
      } catch {
        RRF.gcode(FALLBACK_SEDA).catch(_swallowErr(`FALLBACK_SEDA`));
      }
    } finally {
      SM.busy = !1;
      SM._cancelInProgress = !1;
      if (_smBusyAbort === _busyAbort) _smBusyAbort = null;
      startPoll();
    }
  }));
// Arrow, NO referencia por valor: doReset vive ahora en rotechos-file-ops.js,
// que es un defer module y carga DESPUÉS de este shell. Pasar `doReset` aquí
// engancharía `undefined` y los botones de reset quedarían muertos.
($(`btnResetEstop`)?.addEventListener(`click`, () => doReset()),
  $(`btnResetEstopMobile`)?.addEventListener(`click`, () => doReset()),
  // ---
  // MÓDULO: GESTOR OTA UNIFICADO (multi-archivo con progreso XHR)
  // ---
  (function () {
    const dropZone = $(`otaDropZone`),
      fileInput = $(`otaFileInput`),
      queueEl = $(`otaQueue`),
      btnUpload = $(`btnOtaUpload`),
      btnClear = $(`btnOtaClear`),
      statusEl = $(`otaUploadStatus`),
      destSel = $(`otaUploadDest`),
      progressW = $(`otaProgressWrap`),
      progressB = $(`otaProgressBar`),
      progressP = $(`otaProgressPct`),
      progressL = $(`otaProgressLabel`);
    let _queue = [];

    // Detectar versión instalada
    (function initOtaVersion() {
      const footerEl = $q(`.app-footer .info-row`);
      if (footerEl) {
        const m = footerEl.textContent.match(/RotechOS\s+v([\d.]+)/i);
        m && ($(`otaCurrentVersion`).textContent = `v` + m[1]);
      }
    })();
    // Cargar historial de localStorage
    (function initOtaLog() {
      const el = $(`otaLogList`);
      if (!el) return;
      const logs = STORE.get(`ota.log`, []);
      if (!logs.length) return;
      el.innerHTML = logs.map(l => {
        // Fase 4.11: badge de impacto por entrada. Los registros
        // anteriores a esta fase no traen `impact` (undefined) — se
        // tratan como 'none' para no romper el render retroactivo.
        const _imp = l.impact || `none`;
        const _badge = _imp === `reboot-duet`
          ? ` <span title="${escHtml(t(`badge.ota.impact.reboot`, `Requiere reinicio del Duet`))}" style="background:var(--red);color:#fff;font-size:10px;font-weight:800;padding:0 4px;border-radius:6px;margin-left:4px">REBOOT</span>`
          : _imp === `reload-ui`
          ? ` <span title="${escHtml(t(`badge.ota.impact.reload`, `Recarga la UI en 3s`))}" style="background:var(--yellow);color:#000;font-size:10px;font-weight:800;padding:0 4px;border-radius:6px;margin-left:4px">RELOAD</span>`
          : ``;
        return `<div style="display:flex;justify-content:space-between;border-bottom:1px solid var(--border);padding:3px 0">` +
          `<span style="color:var(--text-2)">${escHtml(l.date)}</span>` +
          `<span style="color:var(--teal);font-weight:700">${escHtml(l.files || l.file || `?`)}${_badge}</span>` +
          `<span style="color:var(--text-3)">${escHtml(l.size)}</span></div>`;
      }).join(``);
    })();


    function renderQueue() {
      if (!_queue.length) {
        queueEl.style.display = `none`;
        btnUpload.disabled = !0;
        btnUpload.style.opacity = `.4`;
        btnClear.style.display = `none`;
        return;
      }
      queueEl.style.display = `block`;
      btnUpload.disabled = !1;
      btnUpload.style.opacity = `1`;
      btnClear.style.display = ``;
      queueEl.innerHTML = _queue.map((f, i) => {
        // Fase 4.11: getDestInfo enriquece con type + impact (rotechos-file-ops.js)
        // para que la cola muestre el destino Y el tipo Y el badge de impacto.
        // type se pinta en gris; impact en color según blast-radius.
        const info = (typeof getDestInfo === `function`)
          ? getDestInfo(f.name)
          : { path: getDestForFile(f.name), type: `?`, impact: `none` };
        const dest = info.path;
        const type = info.type;
        const impact = info.impact;
        const typeColor = type === `ui`        ? `var(--blue)`
                       : type === `firmware`  ? `var(--warn-strong)`
                       : type === `config`    ? `var(--warn-strong)`
                       : type === `macro`     ? `var(--purple)`
                       : type === `gcode`     ? `var(--text-3)`
                       : type === `unknown`   ? `var(--yellow)`
                       :                        `var(--text-3)`;
        // impactBadge: solo se pinta para los impactos >0 (no `none`); rojo
        // si el operario debe hacer reboot del Duet, amarillo si solo recarga
        // la UI del navegador, gris para el resto. Vacío si no hay impacto.
        const impactBadge = impact === `reboot-duet`
          ? `<span data-i18n="badge.ota.impact.reboot" title="${escHtml(t(`badge.ota.impact.reboot`, `Requiere reinicio del Duet`))}" style="background:var(--red);color:#fff;font-size:10px;font-weight:800;padding:1px 5px;border-radius:8px;letter-spacing:.3px;flex-shrink:0">REBOOT</span>`
          : impact === `reload-ui`
          ? `<span data-i18n="badge.ota.impact.reload" title="${escHtml(t(`badge.ota.impact.reload`, `Recarga la UI en 3s`))}" style="background:var(--yellow);color:#000;font-size:10px;font-weight:800;padding:1px 5px;border-radius:8px;letter-spacing:.3px;flex-shrink:0">RELOAD</span>`
          : ``;
        return `<div style="display:flex;align-items:center;gap:6px;padding:5px 8px;border-bottom:1px solid var(--border);font-size:11px">` +
          `<span style="color:${typeColor};font-weight:700;flex-shrink:0;font-family:var(--mono);font-size:10px">${escHtml(type)}</span>` +
          `<span style="color:var(--teal);font-weight:700;flex-shrink:0;font-family:var(--mono);font-size:10px">${escHtml(dest)}/</span>` +
          `<span style="color:var(--text-1);flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${escHtml(f.name)}</span>` +
          impactBadge +
          `<span style="color:var(--text-3);font-family:var(--mono);font-size:10px;flex-shrink:0">${(f.size / 1024).toFixed(1)} KB</span>` +
          `<span style="color:var(--red);cursor:pointer;font-size:14px;line-height:1;padding:0 4px" data-rm="${i}" title="Quitar">✕</span></div>`;
      }).join(``);
      queueEl.querySelectorAll(`[data-rm]`).forEach(btn => {
        btn.addEventListener(`click`, () => { _queue.splice(+btn.dataset.rm, 1); renderQueue(); });
      });
    }

    // FIX-NV-3a (2026-08-06) + LAZY-OTA-ZIP-RACE H2 v3 (2026-08-18):
        // `rotechos-ota-zip.js` quedó en carga perezosa (PESO-5), y este IIFE
        // cablea el dropZone ANTES de que el operario abra el tab OTA. Sin un
        // await, la ventana entre el click de tab y el `load` del <script>
        // (~50 ms de red en una SD lenta) permitía arrastrar un .zip y colarlo
        // en la cola — exactamente lo que FIX-NV-3a cerró en su día. Solución:
        // `addFiles` espera a la resolución de `__lazyLoad(...)` antes de la
        // primera evaluación de `_isArchive(name)`. `__lazyLoadCache` (definido
        // en rotechos.js:~850) hace el await idempotente y barato en arranques
        // siguientes (cache hit de la inyección previa).
        const _otaProtegido = (name) => /^(config-machine|config-override|wifi-passwords)\.g$/i.test(name);
        const _isArchive = (name) => (typeof isOtaArchive === `function` ? isOtaArchive(name) : false);
        function _ensureOtaZipReady() {
          if (typeof isOtaArchive === `function`) return Promise.resolve();
          // __lazyLoadCache garantiza que solo se inyecta una vez; si falla,
          // dejamos pasar y `addFiles` mostrará un toast explicativo (la lambda
          // devolverá false y el archivo seguirá, peor que antes, pero el SW
          // mock :3099 lo entrega igual; el caso real mantiene el rechazo por
          // client-cache después del primer intento).
          return __lazyLoad(`/js/rotechos-ota-zip.js`).catch((e) => LOG?.warn?.(`lazy OTA-zip (dropZone):`, e));
        }
        // CORREGIDO 2026-08-27: se PRECARGA aqui, al cablear la UI de OTA, en
        // vez de esperarla dentro de `addFiles`. Ver el comentario de addFiles.
        _ensureOtaZipReady();

        // FIX-NV-3a (2026-08-06): el gestor OTA NO parsea ZIPs — la OTA es solo
        // notificación (rotechos-ota.js), la descarga la hace el usuario y sube
        // ARCHIVOS SUELTOS a la SD vía rr_upload. Arrastrar el `.zip` literal hoy
        // acaba en 0:/sys/release.zip (interfaz deception, ver C-rot-03 + acta
        // docs/dev/hallazgos/2026-08-06_FIX-NV-3a_deception_removed.md).
        // Esta función es el ÚNICO filtro cliente; sin ella, getDestForFile
        // enrutaría el zip a 0:/sys por extensión desconocida.
        // LAZY-OTA-ZIP-RACE H2 v3: `addFiles` se vuelve async para garantizar
        // que el predicado `isOtaArchive` está cargado antes de evaluar cada
        // archivo. El await es por-módulo (cacheado, no por-archivo).
        // CORREGIDO 2026-08-27: vuelve a ser SINCRONA. La version async de
        // 54284c1 ponia `await _ensureOtaZipReady()` como primera linea, y con
        // eso la cola de OTA dejo de pintarse: `renderQueue()` vive despues del
        // await y el operario se quedaba con #otaQueue vacio y oculto — es
        // decir, sin poder subir NADA por OTA. Lo cazo e2e-ota-completo:214.
        // La intencion original (que `isOtaArchive` este cargado antes de
        // evaluar el primer fichero, para que un .zip no se cuele en la ventana
        // de ~50 ms entre abrir la pestana y cargar el modulo) se conserva
        // precargando el modulo arriba, al cablear la UI, en vez de bloquear
        // aqui. La ventana de carrera se cierra igual y la cola sigue viva.
        function addFiles(fileList) {
          for (const f of fileList) {
        // Ficheros de ESTA maquina (calibracion, overrides, WiFi): la release
        // no los trae y una OTA no los pisa. Uno suelto con ese nombre venia
        // de otra SD y se subia a 0:/sys sin barrera (auditoria 25-sep).
        if (_otaProtegido(f.name)) {
          toast(t(`msg.otaProtegido`, `Archivo ignorado: ${f.name}. Es un fichero propio de cada máquina (calibración o credenciales WiFi) y la OTA no lo sustituye. Para recuperar una calibración usa CONFIGURACIÓN → RESPALDO → Restaurar.`, { name: f.name }), `err`);
          continue;
        }
        // config.g lleva el mapeo de motores de ESTA maquina (M584, M569, M574):
        // deploy.sh lo conserva por defecto. Aqui se pregunta, con Descartar por
        // defecto: una version puede traer cambios reales en config.g (26-sep).
        if (/^config\.g$/i.test(f.name)) {
          confirmDialog({
            title: t(`dlg.otaConfigG.title`, `¿Sustituir config.g?`),
            body: t(`dlg.otaConfigG.body`, `<p><strong>config.g</strong> lleva el mapeo de motores de ESTA máquina: qué driver mueve cada eje, el sentido de giro y los finales de carrera. Si los cambiaste en CONFIGURACIÓN, se perderán y un eje puede moverse al revés.</p><p>Súbelo solo si las notas de versión lo piden. Después, antes de mover nada, revisa MOTORES y FINALES DE CARRERA y prueba cada eje con la mano en el paro.</p>`),
            confirmText: t(`dlg.otaConfigG.yes`, `Sustituir config.g`),
            cancelText: t(`dlg.otaConfigG.no`, `Descartar`),
            danger: true,
          }).then((ok) => { if (ok && !_queue.some((q) => q.name === f.name)) { _queue.push(f); renderQueue(); } });
          continue;
        }
        if (_isArchive(f.name)) {
          toast(t(`msg.otaZipRejected`,
            `Archivo ignorado: ${f.name}. La OTA no procesa ZIPs — descomprímelo en tu PC (doble clic), abre la carpeta que se haya creado y arrastra los archivos sueltos (.html, .js, .css, .gz, etc.) a esta misma zona OTA. Los .gz se suben tal cual: la placa los sirve comprimidos.`), `err`);
          LOG.warn(`OTA: archivo rechazado por ser comprimido`, f.name);
          continue;
        }
        // Fase 4.11: NO adivinar destino para extensiones desconocidas.
        // Si la extensión no está en AUTO_ROUTES y el operario no ha forzado
        // un destino con el select global, preguntamos antes de encolar.
        // Antes (Sprint 6 fase 2) estos archivos caían a 0:/sys silenciosa-
        // mente — eso es `interfaz deception` (C-rot-03) para extensiones que
        // el operario no espera que sean firmware. Ahora el confirmDialog
        // muestra la ruta por defecto y permite descartar el archivo.
        if (typeof isUnknownExt === `function` && isUnknownExt(f.name)) {
          const destSelVal = destSel?.value;
          if (!destSel || destSelVal === `auto` || destSelVal === `` || destSelVal == null) {
            const fallbackDest = `0:/sys`;
            confirmDialog(
              t(`dlg.otaUnknownExt.title`, `Destino no claro`),
              `<p>${t(`dlg.otaUnknownExt.body`, `El archivo`)} <strong>${escHtml(f.name)}</strong> ${t(`dlg.otaUnknownExt.extUnknown`, `tiene una extensión que RotechOS no reconoce`)}.</p>` +
              `<p>${t(`dlg.otaUnknownExt.default`, `Por defecto se subiría a`)} <code>${escHtml(fallbackDest)}</code>${t(`dlg.otaUnknownExt.defSfx`, ` (carpeta de firmware). Si quieres otra ruta, usa el selector Destino de arriba antes de arrastrar.`)}</p>` +
              `<p style="color:var(--yellow);font-size:11px;margin-top:8px">${t(`dlg.otaUnknownExt.warn`, `¿Subir igualmente a`)} <code>${escHtml(fallbackDest)}</code>?</p>`,
              {
                confirmText: t(`dlg.otaUnknownExt.yes`, `Subir a ${fallbackDest}`),
                cancelText:  t(`dlg.otaUnknownExt.no`,  `Descartar`),
              },
            ).then((ok) => {
              if (ok) {
                if (!_queue.some(q => q.name === f.name)) _queue.push(f);
                renderQueue();
              } else {
                toast(t(`msg.otaUnknownSkipped`, `${f.name} descartado por destino desconocido`), `warn`);
                LOG.warn(`OTA: archivo con extensión desconocida descartado por el operario`, f.name);
              }
            });
            continue;
          }
        }
        if (!_queue.some(q => q.name === f.name)) _queue.push(f);
      }
      renderQueue();
      // Detección de versión si alguno es index.html
      _queue.forEach(f => {
        if (f.name === `index.html`) {
          f.text().then(txt => {
            const m = txt.match(/RotechOS\s+v([\d.]+)/i);
            if (m) f._otaVer = m[1];
          }).catch(() => {});
        }
      });
    }

    /** Sube un archivo con XHR (progreso real) y devuelve Promise<void>. */
    function uploadWithProgress(file, fullPath, onProgress) {
      return new Promise((resolve, reject) => {
        const xhr = new XMLHttpRequest();
        const url = `${TARGET_IP}/rr_upload?name=${encodeURIComponent(fullPath)}&time=${Date.now()}`;
        xhr.open(`POST`, url);
        xhr.timeout = Math.max(30000, file.size * 0.5);  // ~2 KB/s mínimo
        xhr.upload.onprogress = (e) => {
          if (e.lengthComputable && onProgress) onProgress(Math.round(e.loaded / e.total * 100));
        };
        xhr.onload = () => xhr.status === 200 ? resolve() : reject(new Error(`HTTP ${xhr.status}`));
        xhr.onerror = () => reject(new Error(`Error de red`));
        xhr.ontimeout = () => reject(new Error(`Timeout`));
        xhr.send(file);
      });
    }
    /**
     * Variante con escudo auth previo: sube un archivo pidiendo tryConnect antes.
     * FIX H-N2 (informe 2026-08-18_busca-superficie-de-seguridad-api-rrf-y-pin-v3.md):
     * la OTA drag&drop aceptaba subir (incluso index.html, .js) sin autenticar;
     * sin el escudo, un atacante en la WiFi puede machacar la UI con un index.html
     * malicioso que elimine el propio escudo del cliente.
     */
    function uploadWithProgressAuthed(file, fullPath, onProgress) {
      return (async () => {
        if (typeof window !== `undefined` && window.rotechosAuth && typeof window.rotechosAuth.tryConnect === `function`) {
          const _auth = await window.rotechosAuth.tryConnect(TARGET_IP, ``);
          if (!_auth || !_auth.ok) {
            throw new Error(`OTA upload abortado: escudo auth rechaza`);
          }
        }
        await uploadWithProgress(file, fullPath, onProgress);
      })();
    }

    // Drag & drop multi-archivo
    if (dropZone && fileInput) {
      dropZone.addEventListener(`click`, () => fileInput.click());
      dropZone.addEventListener(`dragover`, (e) => {
        e.preventDefault();
        dropZone.style.borderColor = `var(--teal)`;
        dropZone.style.background = `rgba(0,200,200,.03)`;
      });
      dropZone.addEventListener(`dragleave`, () => {
        dropZone.style.borderColor = ``;
        dropZone.style.background = ``;
      });
      dropZone.addEventListener(`drop`, (e) => {
        e.preventDefault();
        dropZone.style.borderColor = ``;
        dropZone.style.background = ``;
        if (e.dataTransfer?.files?.length) addFiles(e.dataTransfer.files);
      });
      fileInput.addEventListener(`change`, (e) => {
        if (e.target.files?.length) addFiles(e.target.files);
        fileInput.value = ``;
      });
    }

    btnClear && btnClear.addEventListener(`click`, () => {
      _queue = [];
      renderQueue();
      statusEl.style.display = `none`;
      progressW.style.display = `none`;
    });

    destSel && destSel.addEventListener(`change`, renderQueue);

    btnUpload && btnUpload.addEventListener(`click`, async () => {
      if (!_queue.length) return;
      // FIX-NV-3a (2026-08-06): defensa en profundidad — si por lo que sea la
      // cola contiene un archivo comprimido (inyectado por DevTools, refactor
      // futuro, bypass del filtro de addFiles), bloqueamos aquí. La cola ya
      // debería estar limpia por addFiles, pero el upload es el ÚNICO punto
      // que toca la SD y NO queremos un release.zip en 0:/sys/.
      for (const f of _queue) {
        if (_otaProtegido(f.name)) {
          toast(t(`msg.otaProtegido`, `Archivo ignorado: ${f.name}. Es un fichero propio de cada máquina (calibración o credenciales WiFi) y la OTA no lo sustituye. Para recuperar una calibración usa CONFIGURACIÓN → RESPALDO → Restaurar.`, { name: f.name }), `err`);
          return;
        }
        if (_isArchive(f.name)) {
          toast(t(`msg.otaZipRejected`,
            `Archivo ignorado: ${f.name}. La OTA no procesa ZIPs — descomprímelo en tu PC (doble clic), abre la carpeta y arrastra los archivos sueltos a esta misma zona OTA. Los .gz se suben tal cual: la placa los sirve comprimidos.`), `err`);
          LOG.warn(`OTA: upload abortado, archivo comprimido en cola`, f.name);
          return;
        }
      }
      if (SM.current === STATES.RUNNING || SM.current === STATES.PAUSED) {
        toast(t(`msg.uploadActive`, `No se puede subir archivos con un trabajo activo`), `err`);
        return;
      }
      const total = _queue.length;
      const totalBytes = _queue.reduce((s, f) => s + f.size, 0);
      // Fase 4.11: clasificación por tipo + impacto agregado. Mostramos
      // cada archivo con su tipo (ui/firmware/config/macro/gcode/unknown)
      // y, en el resumen, el efecto GLOBAL del batch: si hay archivos
      // .html/.js/.css, "se recargará la UI en 3s"; si hay firmware/
      // config, "se necesitará reiniciar el Duet (M999) tras subir".
      // getDestInfo viene de rotechos-file-ops.js; getDestForFile se
      // mantiene para el render del path (consumido por el handler de
      // upload línea abajo).
      const _infos = _queue.map(f => (typeof getDestInfo === `function`)
        ? getDestInfo(f.name)
        : { path: getDestForFile(f.name), type: `?`, impact: `none` });
      const _countReload  = _infos.filter(i => i.impact === `reload-ui`).length;
      const _countReboot  = _infos.filter(i => i.impact === `reboot-duet`).length;
      const _countUnknown = _infos.filter(i => i.type   === `unknown`).length;
      const _impactSummary = _countReboot > 0
        ? `<p style="color:var(--red);font-size:11px;margin-top:6px"><b>${t(`dlg.upload.impactReboot`, `Tras subir, ${_countReboot} archivo(s) requieren reiniciar el Duet (M999 o ciclo de potencia) para aplicarse.`)}</b></p>`
        : _countReload > 0
        ? `<p style="color:var(--yellow);font-size:11px;margin-top:6px">${t(`dlg.upload.impactReload`, `Tras subir, la UI se recargará automáticamente en 3s (${_countReload} archivo(s) web).`)}</p>`
        : ``;
      const _unknownNote = _countUnknown > 0
        ? `<p style="color:var(--yellow);font-size:11px;margin-top:4px">${t(`dlg.upload.unknownNote`, `${_countUnknown} archivo(s) con extensión no reconocida se subirán a 0:/sys — confírmalo solo si sabes que son firmware.`)}</p>`
        : ``;
      if (!(await confirmDialog(
        `${t(`dlg.upload.title`, `Subir`)} ${total} ${t(`dlg.upload.fileSfx`, `archivo`)}${total > 1 ? t(`dlg.upload.pluralSfx`, `s`) : ``}`,
        `<p>${t(`dlg.upload.msg`, `Se subirán a la SD de la máquina`)} (${(totalBytes / 1024).toFixed(0)} KB total):</p>` +
        `<div style="max-height:140px;overflow-y:auto;margin:8px 0;font-family:var(--mono);font-size:10px;line-height:1.8">` +
        _queue.map((f, i) => {
          const info = _infos[i];
          const typeColor = info.type === `ui`        ? `var(--blue)`
                          : info.type === `firmware`  ? `var(--warn-strong)`
                          : info.type === `config`    ? `var(--warn-strong)`
                          : info.type === `macro`     ? `var(--purple)`
                          : info.type === `gcode`     ? `var(--text-3)`
                          : info.type === `unknown`   ? `var(--yellow)`
                          :                              `var(--text-3)`;
          const impactTag = info.impact === `reboot-duet`
            ? ` <span style="background:var(--red);color:#fff;font-size:10px;padding:0 4px;border-radius:6px">REBOOT</span>`
            : info.impact === `reload-ui`
            ? ` <span style="background:var(--yellow);color:#000;font-size:10px;padding:0 4px;border-radius:6px">RELOAD</span>`
            : ``;
          return `<div><span style="color:${typeColor}">[${escHtml(info.type)}]</span> ` +
            `${escHtml(info.path)}/<strong>${escHtml(f.name)}</strong>` +
            (f._otaVer ? ` <span style="color:var(--teal)">v${escHtml(f._otaVer)}</span>` : ``) +
            impactTag +
            `</div>`;
        }).join(``) +
        `</div>` +
        _impactSummary +
        _unknownNote +
        `<p style="color:var(--yellow);font-size:11px;margin-top:6px">${t(`dlg.upload.overwrite`, `Los archivos existentes se sobrescribirán.`)}</p>`,
      ))) return;

      // Pausar polling durante el upload batch
      _pausePollMs(total * 8000);
      btnUpload.disabled = !0;
      btnClear.style.display = `none`;

      statusEl.style.display = `block`;
      statusEl.style.background = `var(--bg-raised)`;
      statusEl.style.border = `1px solid var(--border)`;
      statusEl.style.color = `var(--text-2)`;
      statusEl.innerHTML = ``;
      progressW.style.display = `block`;
      progressB.style.transform = `scaleX(0)`;
      progressB.style.background = ``;
      progressP.textContent = `0%`;
      progressL.textContent = `Preparando…`;

      let ok = 0, fail = 0, needsReload = !1, uploadedBytes = 0;
      for (let i = 0; i < _queue.length; i++) {
        const f = _queue[i];
        const dest = getDestForFile(f.name);
        const fullPath = `${dest}/${f.name}`;
        const line = document.createElement(`div`);
        line.style.cssText = `padding:2px 0`;
        line.textContent = `[${i + 1}/${total}] ${fullPath} …`;
        statusEl.appendChild(line);
        statusEl.scrollTop = statusEl.scrollHeight;
        progressL.textContent = `[${i + 1}/${total}] ${f.name}`;

        try {
          // FIX H-N2 (informe 2026-08-18_busca-superficie-de-seguridad-api-rrf-y-pin-v3.md):
          // la OTA drag&drop aceptaba subir (incluso index.html, .js) sin autenticar;
          // usamos la variante con escudo para que un atacante en la WiFi no pueda
          // machacar la UI con un index.html malicioso que elimine el propio escudo.
          await uploadWithProgressAuthed(f, fullPath, (pct) => {
            const globalPct = Math.round(((uploadedBytes + f.size * pct / 100) / totalBytes) * 100);
            progressB.style.transform = `scaleX(${globalPct / 100})`;
            progressP.textContent = globalPct + `%`;
          });
          uploadedBytes += f.size;
          line.textContent = `[${i + 1}/${total}] ${fullPath} — OK`;
          line.style.color = `var(--green)`;
          ok++;
          if (fullPath.startsWith(`0:/www/`)) needsReload = !0;
          log(`Subido: ${fullPath} (${(f.size / 1024).toFixed(1)} KB)`, `sys`);
        } catch (e) {
          uploadedBytes += f.size;
          line.textContent = `[${i + 1}/${total}] ${fullPath} — ERROR: ${e.message}`;
          line.style.color = `var(--red)`;
          fail++;
        }
      }

      // C-rot-04: si hay errores, NO recargar (la SD puede quedar con versiones
      // mezcladas de JS/HTML/CSS/macros). El operario debe decidir qué hacer
      // (reintentar, restaurar desde backup, o aceptar la SD parcial).
      needsReload = needsReload && fail === 0;

      // Progreso al 100%
      progressB.style.transform = `scaleX(1)`;
      progressP.textContent = `100%`;
      if (fail) {
        progressL.textContent = `SD PARCIAL: ${ok}/${total} subidos, ${fail} errores`;
        progressB.style.background = `var(--red)`;
        statusEl.innerHTML += `<div style="color:var(--red);font-weight:700;margin-top:8px;padding:6px;background:var(--bg-raised);border:1px solid var(--red);border-radius:3px">⚠ SD en estado PARCIAL — no se recarga. Revisa los archivos fallidos y reintenta o restaura desde backup.</div>`;
      } else {
        progressL.textContent = `Completado`;
      }

      let summary = `${ok}/${total} subidos correctamente`;
      if (fail) summary += ` · ${fail} errores`;
      toast(summary, fail ? `warn` : `ok`);
      log(`OTA batch: ${summary} (${(totalBytes / 1024).toFixed(0)} KB)`, fail ? `warn` : `ok`);

      // Registrar en historial
      const _l = STORE.get(`ota.log`, []);
      const otaVer = _queue.find(f => f._otaVer)?._otaVer;
      // Fase 4.11: registrar el impacto agregado (peor caso) para que el
      // operario vea de un vistazo si el último batch recargó la UI o
      // requiere reboot del Duet. Si la cola estaba vacía (caso edge
      // post-fallo), usar 'none' como fallback explícito.
      const _impactAgg = _countReboot > 0
        ? `reboot-duet`
        : _countReload > 0
        ? `reload-ui`
        : `none`;
      _l.unshift({
        date: new Date().toLocaleString(`es-ES`, { day: `2-digit`, month: `2-digit`, year: `numeric`, hour: `2-digit`, minute: `2-digit` }),
        files: ok === 1 ? _queue[0]?.name : `${ok} archivos`,
        ver: otaVer || ``,
        size: (totalBytes / 1024).toFixed(1) + ` KB`,
        impact: _impactAgg,
      });
      if (_l.length > CFG.otaLogMax) _l.length = CFG.otaLogMax;
      STORE.set(`ota.log`, _l);

      _queue = [];
      renderQueue();
      btnUpload.disabled = !1;
      startPoll();

      if (needsReload) {
        statusEl.innerHTML += `<div style="color:var(--teal);font-weight:700;margin-top:4px">Archivos web actualizados — recargando en 3s…</div>`;
        setTimeout(() => {
          location.href = location.pathname + `?_ota=` + Date.now();
        }, CFG.otaReloadMs);
      }
    });
  })());
// `confirmDialog` se extrajo a ROTECHOS/www/js/rotechos-confirm.js (cargado
// antes de este módulo, expone `window.confirmDialog`). Los call sites bare
// (`confirmDialog(...)` sin prefijo) resuelven al global que ese módulo ya
// dejó asignado. NO se re-declara aquí como `function confirmDialog(...)`
// porque eso reescribiría `window.confirmDialog` y rompería el shim — y un
// shim, además, llamaría recursivamente. El historial del guard de
// re-entrada, BUG-01 (Escape) y FIX-A11Y-01 (foco) vive en
// rotechos-confirm.js; ver el header comment de ese módulo.
// El cockpit usa un único selector nativo para la distancia. Las pills del
  // pendant siguen siendo independientes y las maneja initMPG.
  ($(`jogStepSelector`) && $(`jogStepSelector`).addEventListener(`change`, (e) => {
    const s = e.currentTarget.value;
    (SM.step = parseFloat(s)),
      document
        .querySelectorAll(`#mpgStepDisplay`)
        .forEach((el) => (el.textContent = `paso: ` + s + ` mm`));
    // updateJogFeedEffective vive en rotechos-jog.js (defer #18). Guard B-13.
    typeof updateJogFeedEffective === `function` && updateJogFeedEffective();
  })),
  (SM.step = 1);

let consoleFocusTimer = null;
($$(`.center-tab`).forEach((tab) => {
    tab.addEventListener(`click`, () => {
      (document
        .querySelectorAll(`.center-tab`)
        .forEach((t) => t.classList.remove(`active`)),
        document
          .querySelectorAll(`.center-tab-pane`)
          .forEach((p) => p.classList.remove(`active`)),
        tab.classList.add(`active`));
      const targetId = tab.dataset.target;
      $(targetId)?.classList.add(`active`);
      if (consoleFocusTimer) {
        clearTimeout(consoleFocusTimer);
        consoleFocusTimer = null;
      }
      if (targetId === `consoleTab`) {
        consoleFocusTimer = setTimeout(() => {
          $(`consoleIn`)?.focus();
          consoleFocusTimer = null;
        }, 50);
      }
    });
  }));
async function sendCmd() {
  const inp = $(`consoleIn`),
    cmd = inp.value.trim();
  if (!cmd) return;
  // P0-03 fix auditoría escritorio 2026-07-07: historial navegable ↑/↓
  if (window.__rotechosConsoleHistory) {
    const h = window.__rotechosConsoleHistory;
    if (h[h.length - 1] !== cmd) {
      h.push(cmd);
      if (h.length > 50) h.shift();
      try { localStorage.setItem('rotech_cmd_history', JSON.stringify(h)); } catch {}
    }
    window.__rotechosConsoleHistIdx = h.length;
  }
  if (/^\s*(M777|\/bat)\s*$/i.test(cmd)) {
    inp.value = ``;
    log(`► ${cmd}`, `cmd`);
    log(` `, `info`);
    log(`       /\\                 /\\`, `info`);
    log(`      /  \\_______________/  \\`, `info`);
    log(`     /                       \\`, `info`);
    log(`    /   _             _     \\`, `info`);
    log(`   |   (0)           (0)   |`, `info`);
    log(`    \\                     /`, `info`);
    log(`     \\   \\___________/   /`, `info`);
    log(`      \\                 /`, `info`);
    log(`       \\_______________/`, `info`);
    log(` `, `info`);
    log(`  [Modo Murciélago Desbloqueado]`, `info`);
    log(`  El software y el hardware vigilan tu taller.`, `info`);
    await RRF.gcode(`M150 R139 U92 B246 P255 F0 S25`);
    return;
  }
  // 15-sep: fuera de reposo, confirmar lo que mueve ejes, el husillo, lanza una
  // macro o cambia herramienta. No se bloquea: la consola sirve en marcha y tras un paro.
  if (typeof SM !== `undefined` && SM.current !== STATES.IDLE && SM.current !== STATES.READY &&
      /\b(G0*[0-3]|G10|G2[89]|G30|G38|G53|M0*[346]|M98|T\d)(?!\d)/i.test(cmd) &&
      !(await confirmDialog(t(`dlg.busyCmd.title`, `Máquina ocupada`),
        `<strong>${SM.current}</strong>: ${t(`dlg.busyCmd.msg`, `este comando mueve ejes, el husillo o lanza una macro. ¿Enviar de todas formas?`)}`)))
    return;
  if (/\b(M552\s+S0|M587|M588|M999)\b/i.test(cmd)) {
    if (
      // SIEMPRE, tambien fuera del modo escuela. Esto no es un boton del
      // panel cuyo proposito se ve: es texto ESCRITO en la consola, y quien
      // copia un M999 o un M552 S0 de un foro puede no saber que el primero
      // reinicia el firmware y el segundo corta su propia conexion con la
      // maquina. De eso no se vuelve desde la interfaz.
      !(await confirmDialog(
        t(`dlg.dangerCmd.title`, `Comando peligroso`),
        `<strong>${cmd}</strong> ${t(`dlg.dangerCmd.msg`, `puede desconectar la máquina o cambiar la configuración de red.<br>¿Enviar de todas formas?`)}`,
      ))
    )
      return;
  }
  (log(`► ${cmd}`, `cmd`), (inp.value = ``));
  const r = await RRF.gcode(cmd);
  if (!r) {
    // FIX H-4 (informe 2026-08-17_busca-el-monolito): distinguir la causa de
    // fallo en el toast MDI. Antes TODO era "Error al enviar comando" — el
    // operario no sabía si fue (a) timeout, (b) HTTP no-2xx, (c) firmware
    // rechazó con {err:1, errMsg:...}, o (d) red caída antes de pedir.
    const lf = RRF._lastFail;
    let msg = t(`msg.cmdErr`, `Error al enviar comando`);
    if (lf) {
      if (lf.reason === `timeout`) {
        msg = t(`msg.cmdTimeout`, `Timeout: el firmware no confirmó a tiempo — el comando pudo haberse ejecutado`);
      } else if (lf.reason === `http`) {
        msg = t(`msg.cmdHttpErr`, `Firmware devolvió HTTP ${lf.status} — reintenta o revisa la red`);
      } else if (lf.reason === `firmware`) {
        msg = t(`msg.cmdFirmwareErr`, `Firmware rechazó: ${lf.errMsg}`);
      } else if (lf.reason === `network`) {
        msg = t(`msg.cmdNetworkErr`, `No se pudo enviar (${lf.error}) — revisa la conexión`);
      } else if (lf.reason === `shield`) {
        // Mismo criterio que el toast: el diagnostico del MDI tambien tiene que
        // decir CUAL de los tres motivos fue, no el generico (2026-08-31).
        msg = window.rotechosShieldMsg.get(lf);
      }
    }
    toast(msg, `err`);
  }
  else {
    let c = 0;
    const iv = setInterval(async () => {
      try {
        const q = await _fetchRRF(`${TARGET_IP}/rr_reply`);
        if (q.ok) {
          const txt = await q.text();
          if (txt.trim()) {
            log(`  ${txt.trim()}`, `info`);
            clearInterval(iv);
            return;
          }
        }
      } catch {}
      if (++c > 4) clearInterval(iv);
    }, 300);
  }
}
(
  (window.UI_ACTIONS[`btnSend`] = sendCmd),
  // P0-03 fix auditoría escritorio 2026-07-07: historial navegable ↑/↓ + datalist comandos RRF
  (() => {
    try {
      window.__rotechosConsoleHistory = JSON.parse(localStorage.getItem('rotech_cmd_history') || '[]');
    } catch { window.__rotechosConsoleHistory = []; }
    window.__rotechosConsoleHistIdx = window.__rotechosConsoleHistory.length;
    const inp = $(`consoleIn`);
    if (!inp) return;
    inp.addEventListener(`keydown`, (e) => {
      const h = window.__rotechosConsoleHistory || [];
      if (e.key === `ArrowUp`) {
        e.preventDefault();
        if (!h.length) return;
        // BUG-FIX-03 Gemini validación cruzada 2026-07-07: preservar buffer del usuario
        // al navegar al historial para que ArrowDown pueda restaurarlo
        if (window.__rotechosConsoleHistIdx === h.length) {
          window.__rotechosConsoleTempInput = inp.value;
        }
        window.__rotechosConsoleHistIdx = Math.max(0, window.__rotechosConsoleHistIdx - 1);
        inp.value = h[window.__rotechosConsoleHistIdx] || '';
      } else if (e.key === `ArrowDown`) {
        e.preventDefault();
        if (!h.length) return;
        window.__rotechosConsoleHistIdx = Math.min(h.length, window.__rotechosConsoleHistIdx + 1);
        if (window.__rotechosConsoleHistIdx === h.length) {
          inp.value = window.__rotechosConsoleTempInput || '';
        } else {
          inp.value = h[window.__rotechosConsoleHistIdx] || '';
        }
      }
    });
    // Datalist con comandos RRF 3.5.x frecuentes (autocompletado)
    const cmds = ['M0','M1','M3','M4','M5','M30','M82','M83','M84','M104','M105','M106','M107','M109','M112','M114','M119','M120','M122','M140','M190','M500','M501','M502','M503','M999','G0','G1','G2','G3','G4','G28','G29','G32','G90','G91','G92'];
    if (!document.getElementById('rotechos-console-datalist')) {
      const dl = document.createElement('datalist');
      dl.id = 'rotechos-console-datalist';
      cmds.forEach(c => { const o = document.createElement('option'); o.value = c; dl.appendChild(o); });
      document.body.appendChild(dl);
      inp.setAttribute('list', 'rotechos-console-datalist');
      inp.setAttribute('autocomplete', 'off');
      inp.setAttribute('autocapitalize', 'off');
      inp.setAttribute('spellcheck', 'false');
    }
  })(),
  $(`consoleIn`)?.addEventListener(`keydown`, (e) => {
    e.key === `Enter` && sendCmd();
  }),
  (window.UI_ACTIONS[`btnClearConsole`] = () => {
    const out = $(`consoleOut`);
    out && (out.innerHTML = ``);
  }),
  // ── Plegar la consola ────────────────────────────────────────────────────
  // El CSS ya traia `.console-out.collapsed{display:none}` (rotechos.css:296)
  // pero NADA anadia nunca esa clase: regla muerta desde que se escribio. Aqui
  // se conecta. El motivo de producto: la consola G-code ocupa 260-276 px del
  // centro y a un operario novato no le dice nada; plegarla se los devuelve al
  // visor 3D, que es lo que si mira. La linea de comandos NO se pliega, para
  // que el que la usa siga pudiendo escribir.
  (window.UI_ACTIONS[`btnConsoleFold`] = (e, btn) => {
    alternaPlegadoConsola(btn);
  }),
  (window.UI_ACTIONS[`btnTheme`] = () => {
    const newTheme = document.documentElement.dataset.theme === `dark` ? `light` : `dark`;
    document.documentElement.dataset.theme = newTheme;
    // 2026-08-29: valor EXPLICITO, no cadena vacia. #icoLuna nace con la clase
    // `telem-value` (rotechos.css:3390, display:none) que le puso la migracion
    // de estilos inline, y vaciar el display en linea deja mandar a la clase:
    // en tema CLARO no se veia NI la luna ni el sol y el boton de cambiar tema
    // quedaba EN BLANCO. Es el mismo fallo que dejo invisible dos veces la
    // tarjeta de primer corte (ver rotechos-firstcut.js:31); tercera victima de
    // la misma migracion. Lo caza el gate de visibilidad solo si se mide en
    // tema claro, y no se medía.
    $(`icoLuna`).style.display = newTheme === `light` ? `block` : `none`;
    $(`icoSol`).style.display = newTheme === `dark` ? `block` : `none`;
    /* A-4 (audit 2026-07-20): sincronizar <meta name=theme-color> con el tema
       activo para que Android/Chrome pinten la barra de sistema del color
       correcto (#121215 dark, #f0ede4 light). Sin esto, el meta siempre
       vale #121215 y en light la barra queda oscura. */
    document.querySelector(`meta[name="theme-color"]`)?.setAttribute(`content`,
      newTheme === `light` ? `#f0ede4` : `#121215`);
    STORE.set(`ui.theme`, newTheme);
    typeof VIZ !== "undefined" && (VIZ.dirty = !0);
  }),
  (window.UI_ACTIONS[`btnFullscreen`] = () => {
    if (!document.fullscreenElement) {
      const p = document.documentElement.requestFullscreen?.();
      p && p.catch && p.catch(() => toast(t(`msg.fullscreenErr`, `El navegador no permitió pantalla completa`), `warn`));
    } else {
      document.exitFullscreen?.();
    }
  }),
  (document.addEventListener(`fullscreenchange`, () => {
    const fs = !!document.fullscreenElement;
    // Valor EXPLICITO en los dos, no cadena vacia. #icoCompress nace con la
    // clase `telem-value` (display:none) que le puso la migracion de estilos
    // inline, asi que vaciarle el display en linea deja mandar a la clase: al
    // ENTRAR en pantalla completa se ocultaban LOS DOS y el boton se quedaba en
    // blanco; al salir reaparecia, porque #icoExpand no lleva esa clase.
    // Tercera victima de la misma migracion, despues del boton de tema
    // (rotechos.js:3434) y la tarjeta de primer corte
    // (rotechos-firstcut.js:31). `block` es el display real que ya tienen
    // servidos, medido en el navegador — no un valor inventado.
    $(`icoExpand`) && ($(`icoExpand`).style.display = fs ? `none` : `block`);
    $(`icoCompress`) && ($(`icoCompress`).style.display = fs ? `block` : `none`);
  })),
  (window.UI_ACTIONS[`btnRecon`] = async () => {
    // H-6 (busca-el-monolito 2026-08-17): si el watcher M999 (rotechos.js:873-906)
    // sigue activo, o si ya hay un reload programado (por este mismo handler o
    // por el watcher), evitar programar un segundo `setTimeout(reload, 1500)`.
    // Dos reloads casi simultáneos — el primero gana y el segundo se
    // desperdicia (visible como parpadeo de la UI cuando la red parpadea).
    if (window.M999_WATCHDOG.hasActiveWatcher() || AppState.sys._reloadScheduled) {
      // M999 watcher extraido (t_1f6006ac FASE 2): el primer termino del
      // OR pregunta al modulo si el watcher sigue activo (equivalente al
      // antiguo `AppState.sys.m999Watcher`). El modulo gestiona el
      // setInterval internamente; preguntar el campo directo seguiria
      // funcionando pero acopla el monolito al estado interno del modulo.
      toast(t(`msg.reconAlreadyInProgress`, `Reconexión ya en curso…`), `info`);
      return;
    }
    setConn(!1, `Conectando…`);
    $(`connPill`).className = `conn-pill busy`;
    if (await RRF.connect()) {
      setConn(!0, `Conectado`);
      toast(t(`msg.reconnected`, `Reconectado — recargando…`), `ok`);
      startPoll();
      AppState.sys._reloadScheduled = !0;
      setTimeout(() => location.reload(), 1500);
    } else {
      setConn(!1, `Sin conexión`);
      toast(t(`msg.connFailed`, `No se pudo conectar`), `err`);
    }
  }),
  (window.UI_ACTIONS[`vizViewTop`] = () => applyVizView(`top`)),
  (window.UI_ACTIONS[`vizViewFront`] = () => applyVizView(`front`)),
  (window.UI_ACTIONS[`vizViewIso`] = () => applyVizView(`iso`)),
  (window.UI_ACTIONS[`vizView3d`] = () => applyVizView(`3d`))
);
function applyVizView(view) {
  (document
    .querySelectorAll(`.viz-view-pill`)
    .forEach((b) => b.classList.remove(`active`)),
    document
      .getElementById(`vizView${view.charAt(0).toUpperCase() + view.slice(1)}`)
      .classList.add(`active`),
    typeof VIZ !== "undefined" &&
      ((VIZ.viewMode = view), (VIZ.dirty = !0), VIZ.bounds && VIZ.fitView()));
}
// 26-sep: `rr_gcode` contesta al ENCOLAR el M25/M0, que espera detrás de la
// macro (mismo canal HTTP); antes se anunciaba «cancelada» siempre. Solo se da
// por buena si el sondeo ve I/H/F; a los 6 s ocupada, aviso de usar el PARO.
const _CANCEL_MACRO_CONFIRMA_MS = 6000;
function _confirmarCancelMacro(letra) {
  const p = AppState.macro.cancelPendiente;
  if (!p || !(letra === `I` || letra === `H` || letra === `F`)) return;
  clearTimeout(p.timer);
  AppState.macro.cancelPendiente = null;
  // Si el sondeo la había vuelto a detectar, que no la dé por «completada».
  _resetMacroState();
  toast(t(`msg.macroDetenida`, `Macro "${p.name}" detenida`, { name: p.name }), `warn`);
  log(`Macro detenida (confirmado por el firmware): ${p.name}`, `warn`);
}
function _avisoMacroSigue(name, motivo) {
  toast(t(`msg.macroSigue`, `La macro "${name}" puede seguir en marcha: pulsa PARO o usa la seta`, { name }), `err`);
  log(`⚠ Macro ${name}: ${motivo} — puede seguir en marcha, usa PARO o la seta`, `err`);
}
async function cancelMacro() {
  const name = AppState.macro.name || AppState.macro.cancelPendiente?.name || `—`;
  if (AppState.macro.cancelPendiente) {
    // Reenviar no adelanta nada: el primer M25/M0 ya está en la cola.
    _avisoMacroSigue(name, `la cancelación ya está enviada y sin confirmar`);
    return;
  }
  // ESTOP-MACRO-LIMP (t_70974bbf, 2026-09-02): mismo helper que btnEStop
  // y _uiResolveStateMachine — una sola limpieza, no tres duplicadas.
  _resetMacroState();
  // Nueva generación: el ciclo en vuelo (que leyó `processing`) se descarta.
  AppState.poll.bumpGen();
  // FIX: Pausar polling + M25 antes de M0 + restaurar SILK
  _clearPollTimer();
  SM._cancelInProgress = !0;
  const entregado = await RRF.urgentGcode(`M25\nM0\nT0\nM5`).then(() => !0, () => !1);
  // Restaurar SEDA tras cancelar macro
  if (entregado) {
    try {
      const r = await RRF.gcode(`M98 P"${MACROS.setSilk}"`);
      if (!r) throw new Error(`Fallback`);
    } catch {
      RRF.gcode(FALLBACK_SEDA).catch(_swallowErr(`FALLBACK_SEDA`));
    }
  }
  SM._cancelInProgress = !1;
  if (entregado) {
    const p = { name, timer: 0 };
    p.timer = setTimeout(() => {
      if (AppState.macro.cancelPendiente !== p) return;
      _avisoMacroSigue(name, `el firmware sigue ocupado ${_CANCEL_MACRO_CONFIRMA_MS / 1000} s después de cancelar`);
    }, _CANCEL_MACRO_CONFIRMA_MS);
    AppState.macro.cancelPendiente = p;
    toast(t(`msg.macroCancelEnviada`, `Cancelación de "${name}" enviada — comprobando que se detiene…`, { name }), `info`);
    log(`Cancelación de macro enviada: ${name} — M25+M0+T0+M5+SEDA (urgente)`, `warn`);
  } else {
    _avisoMacroSigue(name, `la cancelación no llegó al firmware`);
  }
  startPoll();
  updateButtonStates();
}
// (Editor "Cambio de Fresa"/toolchange.g eliminado — el SAC se gestiona desde
//  Configuración → Spindle y se ejecuta vía sys/M6.g)
// t_b8cd40c2 (5.º intento de extracción): rotechos-config-modal.js pasó a
// perezoso — ya no está en el HEAD de index.html, lo carga __loadConfigModal
// al primer click en CONFIGURACIÓN (#btnSysManager) o F3. Sin este wrapper,
// la primera vez que el operario abre el modal, `openMachineConfig` es
// `undefined` y el click del botón se ejecuta pero no hace nada. El patrón
// es el mismo que ya usan los módulos perezosos INTERNOS del modal
// (`__loadAccelCurve`, `__loadPinesUi`, `__loadCfgSearch`, etc.).
const __loadConfigModal = () => __lazyLoad(`/js/rotechos-config-modal.js`);
// t_b8cd40c2: `const` NO llega a `window`, asi que los modulos perezosos que
// necesiten funciones del modal (rotechos-modules.js usa _applyM208Instant y
// _applyM92Instant en los pasos 8 y 9 del asistente) no tienen forma de
// pedir la carga. Se expone explicitamente. Sin esto, el asistente de primera
// puesta en marcha —el primer contacto del novato— fallaba con «Funcion de
// limites no disponible» a menos que el operario hubiera abierto
// CONFIGURACION antes en esa misma sesion, que es justo lo que un novato no
// ha hecho todavia. Devuelve la promesa de carga: hay que esperarla.
window.__ensureConfigModal = __loadConfigModal;
// Proxy en window: si algún consumidor (test e2e, código viejo) hace
// `typeof openMachineConfig === 'function'` ANTES del primer open, este
// proxy dispara la carga. Cuando rotechos-config-modal.js carga, su
// `function openMachineConfig() {}` top-level SOBREESCRIBE
// window.openMachineConfig con la versión real (los function decl en
// scripts clásicos crean window.<name>). Las llamadas tras la primera
// carga llegan directas — el proxy nunca se vuelve a llamar.
window.openMachineConfig = function __openMachineConfigProxy() {
  return __openMachineConfig();
};
function __openMachineConfig() {
  return __loadConfigModal().then(() => {
    if (typeof openMachineConfig !== `function`) {
      // Modal cargado pero la función sigue sin existir — bug de carga.
      toast(t(`msg.configModalLoadFail`, `No se pudo cargar el módulo de CONFIGURACIÓN — vuelve a abrirlo. Si falla repetidamente, recarga la página.`), `err`);
      LOG?.warn?.(`__openMachineConfig: openMachineConfig undefined tras lazyLoad`);
      return;
    }
    return openMachineConfig();
  });
}
($(`btnSysManager`).addEventListener(`click`, () => {
  // t_b8cd40c2: rotechos-config-modal.js es PEREZOSO. __openMachineConfig()
  // hace el bootstrap del módulo y delega en openMachineConfig (que ya está
  // en window tras la primera carga — el proxy cachea en window).
  __openMachineConfig();
}),
    $$(`.mcfg-tab[data-tab]`).forEach((tab) => {
    tab.addEventListener(`click`, () => {
      // t_c2dce523: al salir de la pestaña MESH, para el polling del
      // progreso para no malgastar ciclos. El módulo también para solo
      // al detectar ok/fail, pero cerrar pestañas rápido debe cortar ya.
      const prev = document.querySelector(`.mcfg-tab[data-tab].active`)?.dataset.tab;
      if (prev === `mesh` && window.__onMeshTabClose) {
        try { window.__onMeshTabClose(); } catch (_) {}
      }
      (document
        .querySelectorAll(`.mcfg-tab`)
        .forEach((t) => t.classList.remove(`active`)),
        document
          .querySelectorAll(`.mcfg-panel`)
          .forEach((p) => (p.style.display = `none`)),
        tab.classList.add(`active`));
      const key = tab.dataset.tab,
        panel = $(`mcfgTab` + key.charAt(0).toUpperCase() + key.slice(1));
      // P9 (2026-09-03): entra `glossary`. Era la unica pestana de consulta que
      // faltaba: WIKI CNC tiene 0 controles que persistan y ofrecia Guardar,
      // mientras GUIA MECANIZADO —tambien con 0— si lo ocultaba.
      // El aviso "SIN CALIBRAR" solo se pinta donde hay algo que calibrar: en
      // ARCHIVOS, VISUALIZADOR o IDENTIDAD no es accionable y ademas empuja la
      // vista al scroll en los viewports apretados.
      // `speeds` queda FUERA a proposito, y no por gusto: a 1280x720 con modo
      // escuela esa pestana va al suelo de fit 0.78 sin holgura (la v228 la
      // apreto hasta que cupiera justa) y los 33 px del aviso la ponian en rojo
      // en el gate de sin-scroll. Se acepta perder el aviso ahi porque lo que
      // tiene consecuencia fisica —pasos/mm, corrientes, area— se calibra en
      // MOTORES y LIMITES, donde el aviso SI aparece; VELOCIDADES es dinamica
      // SEDA/RAYO. Si algun dia speeds gana alto, vuelve a entrar.
      const _CALIB_TABS = [`motors`,`endstops`,`homing`,`softlimits`,`backlash`,`spindle`,`probe`,`wizard`];
      // REGLA: una pestaña está en _LOCAL_TABS si y solo si NO tiene nada que
      // el Guardar global pueda persistir. Tres categorías:
      //   (a) PESTAÑAS DE CONSULTA: about, guide, glossary, jobhistory.
      //       Sin estado editable.
      //   (b) PESTAÑAS CON ACCIÓN PROPIA: backup, pines, macros, wizard, mesh.
      //       Tienen su propio botón Guardar interno (Exportar/Restaurar, Guardar
      //       pines, guardar macro, ejecutar wizard, ejecutar malla). El Guardar
      //       global sería ruido.
      //   (c) PESTAÑAS CON AUTO-PERSISTENCIA: ota, viz3d, keyboard.
      //       Cambios persistidos en cada change event (STORE.set('viz3d.prefs'),
      //       etc.) o en la propia acción (subir archivo en OTA). No necesitan
      //       un botón Guardar que se pulse aparte.
      // Excepción documentada: `network` tiene 0 inputs VISIBLES (los toggles
      // FTP/Telnet son switches CSS con el <input> real invisible), pero al
      // pulsar Guardar global sí persiste su estado (rotechos-config-modal.js
      // branch `activeTab === 'network'` genera M586 P1/P2). Por eso network
      // queda FUERA de _LOCAL_TABS aunque el conteo bruto de inputs visibles
      // sea 0. Si en el futuro esos toggles pasan a auto-persistir en change,
      // `network` debe entrar a _LOCAL_TABS.
      const _LOCAL_TABS = [`about`,`macros`,`guide`,`glossary`,`pines`,`ota`,`viz3d`,`wizard`,`jobhistory`,`keyboard`,`mesh`,`backup`];
      (panel && (panel.style.display = `block`),
        ($(`btnMcfgApply`).style.display =
          _LOCAL_TABS.includes(key) ? `none` : ``));
      window.mcfgSyncCalibWarn = () => {
        const w = $(`mcfgCalibWarn`); if (!w) return;
        const activa = document.querySelector(`.mcfg-tab[data-tab].active`)?.dataset.tab;
        const ver = w.dataset.sinCalibrar === `1` && _CALIB_TABS.includes(activa);
        w.style.display = ver ? `block` : `none`;
        w.style.visibility = ver ? `visible` : `hidden`;
        w.setAttribute(`aria-hidden`, ver ? `false` : `true`);
      };
      window.mcfgSyncCalibWarn();
      const _applyBtn = $(`btnMcfgApply`);
      _applyBtn.disabled = false;
      _applyBtn.title = ``;
      _applyBtn.style.opacity = ``;
      _applyBtn.style.cursor = ``;
      // Carga perezosa de módulos no-críticos (PESO-5, sprint A3 jul-2026).
      // Los módulos de flujo opcional (OTA, backup, wizard, jobhistory) NO
      // entran en el defer inicial; se inyectan al activar la pestaña, igual
      // que rotechos-config-accel-curve.js (rotechos-config-modal.js:3004).
      // La función __lazyLoad vive a nivel de módulo (rotechos.js:~810).
      // Notificar a los módulos de las nuevas pestañas que se ha activado su panel
      if (key === `ota`) {
        // OTA: ota-zip es lo que usa el dropZone (rotechos.js:2632 _isArchive);
        // ota.js es lo que cablea #btnOtaCheck (módulo GitHub-release-check).
        __lazyLoad(`/js/rotechos-ota-zip.js`).catch((e) => LOG?.warn?.(`lazy OTA-zip:`, e));
        __lazyLoad(`/js/rotechos-ota.js`).catch((e) => LOG?.warn?.(`lazy OTA:`, e));
      } else if (key === `backup`) {
        // backup: cablea loadBackupTab al click del tab y los botones
        // btnBackupExport/btnRestoreBackup. Sin cargar el módulo, el tab sale
        // en blanco y los botones no responden.
        __lazyLoad(`/js/rotechos-backup.js`).catch((e) => LOG?.warn?.(`lazy backup:`, e));
      } else if (key === `wizard` || key === `jobhistory`) {
        // modules.js expone window.WIZARD/window.JOBHIST con su onShow().
        // Cargamos y luego invocamos onShow manualmente para preservar la UX.
        __lazyLoad(`/js/rotechos-modules.js`)
          .then(() => {
            if (key === `wizard` && window.WIZARD?.onShow) window.WIZARD.onShow();
            else if (key === `jobhistory` && window.JOBHIST?.onShow) window.JOBHIST.onShow();
          })
          .catch((e) => LOG?.warn?.(`lazy modules:`, e));
        return;  // salimos; el .then() se encarga del onShow equivalente
      } else if (key === `viz3d` && window.VIZ3D) window.VIZ3D.onShow();
      else if (key === `keyboard` && window.KBSHORTCUTS) window.KBSHORTCUTS.onShow();
      else if (key === `mesh`) {
        // t_c2dce523 (sep-2026): carga perezosa del módulo de malla. El
        // módulo se inyecta por document.createElement('script') en
        // rotechos-config-modal.js (__loadMeshUi) y expone window.MESH_PROBE
        // con open() / close(). open() rellena defaults y refresca la lista
        // de mapas guardados; close() para el polling del progreso.
        __lazyLoad(`/js/rotechos-mesh-probe.js`)
          .then(() => {
            if (window.MESH_PROBE && typeof window.MESH_PROBE.open === `function`) {
              window.MESH_PROBE.open();
            }
            // banner HOME: si la máquina está sin referenciar, avisa al
            // operario. La defensa dura está en el módulo (startProbe
            // aborta si !allHomed); este banner es solo el aviso visual.
            const banner = document.getElementById(`meshHomeBanner`);
            const homed = !!(window.AppState && window.AppState.limits && window.AppState.limits.allHomed);
            if (banner) banner.style.display = homed ? `none` : ``;
          })
          .catch((e) => LOG?.warn?.(`lazy mesh:`, e));
        return; // salimos; el .then() se encarga del open equivalente
      }
    });
  }));
function updateSpindleModeCards() {
  const val = $q(`input[name="spindleMode"]:checked`)?.value,
    map = {
      pwm: `spindleModePWM`,
      relay: `spindleModeRelay`,
      modbus: `spindleModeModbus`,
      laser: `spindleModeLaser`,
      manual: `spindleModeManual`,
    },
    colors = {
      pwm: `var(--purple)`,
      relay: `var(--red)`,
      modbus: `var(--blue)`,
      laser: `var(--purple, #a855f7)`,
      manual: `var(--teal)`,
    };
  Object.entries(map).forEach(([v, id]) => {
    const el = $(id);
    if (!el) return;
    const active = v === val;
    const tintRgb = v === `pwm` ? `139,106,255`
      : v === `relay` ? `255,59,59`
      : v === `modbus` ? `59,142,243`
      : v === `manual` ? `0,200,200`
      : `168,85,247`;                       // laser — púrpura
    ((el.style.borderColor = active ? colors[v] : `var(--border)`),
      (el.style.background = active
        ? `rgba(${tintRgb},.1)`
        : `var(--bg-raised)`),
      (el.querySelector(`svg`).style.stroke = active
        ? colors[v]
        : `var(--text-3)`),
      (el.querySelector(`span`).style.color = active
        ? colors[v]
        : `var(--text-1)`));
  });
  // ── Modo LÁSER (t_028bceef): swap de bloques en la pestaña SPINDLE ──
  // Cuando el radio "laser" está activo, los inputs RPM (mcfgSpindleMin/Max) y su
  // título se ocultan; aparecen los inputs de potencia (mcfgLaserMin/Max), el
  // banner PENDIENTE BANCO y el hint M950. En cualquier otro modo se revierte.
  const isLaser = val === `laser`;
  const elsRpm = document.querySelectorAll(`.mcfg-spindle-range-rpm`);
  const elsLaser = document.querySelectorAll(`.mcfg-spindle-range-laser`);
  elsRpm.forEach((e) => { e.style.display = isLaser ? `none` : ``; });
  elsLaser.forEach((e) => { e.style.display = isLaser ? `` : `none`; });
  const titleEl = $(`mcfgSpindleRangeTitle`);
  if (titleEl) {
    if (isLaser) {
      titleEl.textContent = t(`cfg.spindle.laser.title`, `Potencia del láser (%)`);
      titleEl.dataset.i18n = `cfg.spindle.laser.title`;
    } else {
      titleEl.textContent = t(`cfg.spindle.rpm.title`, `Velocidades (RPM)`);
      titleEl.dataset.i18n = `cfg.spindle.rpm.title`;
    }
  }
  const hint = document.querySelector(`[data-i18n-html="cfg.spindle.laser.hint"]`);
  if (hint) hint.style.display = isLaser ? `` : `none`;
  const laserWarn = $(`laserWarn`);
  if (laserWarn) laserWarn.style.display = isLaser ? `` : `none`;
  // DECISION 2026-09-04: la Scylla tiene UN puerto serie auxiliar y lo ocupa
  // RotechOS Touch (board.txt: serial.aux.rxTxPins={D.9,D.8}). Modbus lo
  // necesita para el RS485, asi que variador-con-RPM-reales y pantalla fisica
  // son excluyentes. No se bloquea la opcion: se avisa y decide el operario.
  const modbusWarn = $(`modbusWarn`);
  if (modbusWarn) modbusWarn.style.display = val === `modbus` ? `` : `none`;
  // Persistir el modo en CFG para que el cockpit/pendant puedan leerlo sin
  // re-parsear config.g.
  if (typeof CFG !== `undefined`) CFG.spindleMode = val;
  // Avisar al resto de la UI (cockpit, pendant) para que refresque textos.
  syncSpindleLabelsToMode();
}
(document
  .querySelectorAll(`input[name="spindleMode"]`)
  .forEach((r) => r.addEventListener(`change`, updateSpindleModeCards)),
  updateSpindleModeCards(),
  document
    .getElementById(`btnRestoreDefaults`)
    .addEventListener(`click`, async () => {
      if (SM.current === STATES.RUNNING || SM.current === STATES.PAUSED) {
        toast(t(`msg.restoreActiveBusy`, `No se puede restaurar con un trabajo activo`), `err`);
        return;
      }
      if (
        !(await confirmDialog(
          t(`dlg.restoreFactory.title`, `Restaurar configuración de fábrica`),
          t(`dlg.restoreFactory.msg`,
            `¿Cargar <strong>0:/sys/config.g.bak</strong> como configuración activa?<br><br>` +
            `Esto sobreescribirá los ajustes actuales de <code>config.g</code>: ` +
            `<strong>pasos/mm, área de trabajo, offsets de sonda y corrientes de motor</strong>.<br>` +
            `<strong style="color:var(--warn-strong)">La máquina se reiniciará automáticamente.</strong><br><br>` +
            `<span style="color:var(--text-3);font-size:11px">No se puede deshacer desde la UI. Si necesitas otra calibración, edita <code>sys/config.g</code> en la SD con un editor de texto, o vuelve a CONFIGURACIÓN → MOTORES para reaplicar los valores.</span>`),
        ))
      )
        return;
      const btn = $(`btnRestoreDefaults`);
      ((btn.textContent = `Restaurando…`), (btn.disabled = !0));
      try {
        const r = await RRF.download('0:/sys/config.g.bak', { cacheBust: false });
        if (!r.ok) throw Error(`No se encontró config.g.bak en la SD`);
        const bakContent = await r.text();
        if (!bakContent.trim()) throw Error(`config.g.bak está vacío`);
        if (!(await cfgWrite(bakContent)))
          throw Error(`Error al escribir config.g`);
        // H-A (informe 2026-08-17_busca-el-monolito-rotechosjs-v2): invertir el
        // orden — primero enviar M999 (que arma el watcher de reboot en la
        // rama 923-948) y SOLO después repoblar la UI con el .bak. Si la red
        // está caída y M999 falla, NO repoblamos: el operario vería la UI
        // diciendo "config.g restaurado" mientras el firmware sigue con la
        // config vieja, sin causa visible. Antes: setTimeout sin await + UI
        // repoblada antes de que el M999 siquiera saliera — race clásica.
        // cfgWrite ya actualizó _cfgRaw (rotechos-config-persist.js:153) si
        // tuvo éxito, así que el populate consume la versión en SD.
        const m999Res = await RRF.gcode(`M999`);
        if (m999Res === null) {
          // FIX H-A: el fetch de M999 falló (red caída, 5xx, escudo auth,
          // firmware ocupado). Dejamos la UI INTACTA — sólo cfgWrite en la SD
          // se hizo, pero el firmware no la ha cargado. El operario verá su
          // config.g actual (post-cfgWrite local = bak en _cfgRaw) hasta que
          // un reboot natural o un M999 manual surtan efecto. Como cfgWrite
          // YA actualizó _cfgRaw, sí hacemos populate para que la UI no
          // muestre valores fantasma; el toast deja claro que el reinicio es
          // pendiente.
          await cfgPopulate(bakContent);
          toast(t(`msg.restoreM999Failed`, `config.g escrito en la SD pero el reinicio (M999) falló — reinicia la máquina a mano para aplicar los cambios`), `warn`);
          log(t(`msg.restoreFactoryM999FailLog`, `Restaurar de fábrica → config.g escrito, M999 falló (no se aplicó en firmware)`), `err`);
          (btn.disabled = !1);
          return;
        }
        await cfgPopulate(bakContent);
        toast(t(`msg.configgRestauradoDeFábrica`, `config.g restaurado de fábrica ✓ — reiniciando…`), `ok`);
        log(t(`msg.restoreFactoryLog`, `Restaurar de fábrica → config.g.bak aplicado`), `sys`);
      } catch (e) {
        (toast(e.message || t(`msg.restoreErr`, `Error al restaurar`), `err`), (btn.disabled = !1));
      } finally {
        btn.innerHTML = `<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/></svg> Restaurar de fábrica`;
      }
    }));
const GPL3_TEXT = `GNU GENERAL PUBLIC LICENSE



Version 3, 29 June 2007



Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>



Everyone is permitted to copy and distribute verbatim copies of this license document, but changing it is not allowed.



PREAMBLE



The GNU General Public License is a free, copyleft license for software and other kinds of works.



When we speak of free software, we are referring to freedom, not price. Our General Public Licenses are designed to make sure that you have the freedom to distribute copies of free software (and charge for them if you wish), that you receive source code or can get it if you want it, that you can change the software or use pieces of it in new free programs, and that you know you can do these things.



To protect your rights, we need to prevent others from denying you these rights or asking you to surrender the rights. Therefore, you have certain responsibilities if you distribute copies of the software, or if you modify it: responsibilities to respect the freedom of others.



For example, if you distribute copies of such a program, whether gratis or for a fee, you must pass on to the recipients the same freedoms that you received. You must make sure that they, too, receive or can get the source code. And you must show them these terms so they know their rights.



Full license text available at: https://www.gnu.org/licenses/gpl-3.0.txt`;
(document
  .getElementById(`btnViewLicense`)
  .addEventListener(`click`, async () => {
    const modal = $(`licenseModal`),
      content = $(`licenseContent`);
    ((content.innerHTML = `<span style="color:var(--text-3);font-style:italic">Cargando licencia…</span>`),
      modal.classList.add(`show`));
    try {
      const r = await RRF.download('0:/licenses/gpl-v3.txt', { cacheBust: false });
      if (!r.ok) throw Error(`HTTP ${r.status}`);
      content.textContent = await r.text();
    } catch {
      content.textContent = GPL3_TEXT;
    }
  }),
  $(`btnLicenseClose`).addEventListener(`click`, () => {
    $(`licenseModal`).classList.remove(`show`);
  }),
  $(`licenseModal`).addEventListener(`click`, (e) => {
    e.target === e.currentTarget && e.currentTarget.classList.remove(`show`);
  }));
// Botones de Mantenimiento / Diagnóstico (pestaña INFO)
$(`btnSpindleWarmup`)?.addEventListener(`click`, async () => {
  if (machineMoveBlocked()) return;
  if (
    !(await confirmDashboard(
      t(`dlg.spindleWarmup.title`, `Calentar husillo`),
      t(`dlg.spindleWarmup.msg`, `Esto ARRANCA el husillo y sube de 8.000 a 24.000 RPM en rampa (~1 min) para calentar los rodamientos. La fresa va a GIRAR un minuto a alta velocidad. Antes de empezar, aléjate de la fresa, mantén la zona despejada y NO acerques las manos hasta que la rampa haya terminado y el husillo se detenga. ¿Empezar?`),
    ))
  )
    return;
  const r = await RRF.gcode(`M98 P"0:/macros/spindle_warmup.g"`);
  toast(r ? t(`msg.warmupStarted`, `Calentamiento iniciado…`) : t(`msg.warmupErr`, `Error al lanzar spindle_warmup.g`), r ? `info` : `err`);
});
$(`btnHealthCheck`)?.addEventListener(`click`, async () => {
  const r = await RRF.gcode(`M98 P"0:/sys/health_check.g"`);
  // El diagnóstico se muestra como un aviso M291 desde el firmware.
  if (!r) toast(t(`msg.errorAlLanzarHealth_checkg`, `Error al lanzar health_check.g`), `err`);
});
// EXPORTAR DIAGNÓSTICO (2026-08-31) — el paquete que el beta-tester manda a
// soporte cuando algo le falla. Va PEREZOSO con el mismo `__lazyLoad` que usan
// ya 6 módulos: el arranque en frío está 138 KB por encima de su objetivo y no
// admite otro fichero en la cadena de 37 `defer`. El anillo de incidencias que
// el paquete incluye NO está en ese módulo perezoso, sino en
// rotechos-error-trap.js (eager), porque tiene que grabar desde el arranque:
// para cuando el operario pulsa este botón, el fallo ya ha ocurrido.
$(`btnDiagExport`)?.addEventListener(`click`, async () => {
  try {
    await __lazyLoad(`/js/rotechos-diag.js`);
    await window.ROTECHOS_DIAG.exportar();
  } catch (e) {
    LOG?.warn?.(`lazy diag:`, e);
    toast(t(`msg.diagErr`, `No se pudo generar el diagnóstico`), `err`);
  }
});
// ---
// TELEMETRÍA — la fachada updateTelemetry vive en rotechos-telemetry.js
// (FASE 6 del monolito). El monolito solo conserva el banner divisor y
// deja el cuerpo en el módulo nuevo.
// ---

const EDITOR = {
  filename: null,
  closeTimer: null,
  open(filename, content) {
    if (this.closeTimer) {
      clearTimeout(this.closeTimer);
      this.closeTimer = null;
    }
    ((this.filename = filename),
      ($(`editorFilename`).textContent = filename),
      ($(`editorStatus`).textContent =
        `${content.split(`\n`).length} líneas`),
      ($(`fileEditorArea`).value = content),
      $(`fileEditorModal`).classList.add(`show`));
  },
  close() {
    if (this.closeTimer) {
      clearTimeout(this.closeTimer);
      this.closeTimer = null;
    }
    $(`fileEditorModal`).classList.remove(`show`);
  },
};
window.EDITOR = EDITOR; // H-4-02: expone para test e2e del lint del editor
// ── Lint de firmware .g previo al guardado del editor ──────────────────
// La función `_lintGcode` vive en `rotechos-lint-gcode.js` (módulo extraído
// del monolito, tarjeta kanban t_6621e986, lote/2026-09-05, monolito-bloque-2).
// Valida archivos .g antes de subirlos a la SD: línea >256 car, sangría con
// TAB, bloques de control sin cuerpo indentado. Es función PURA (sin estado,
// sin DOM, sin acceso a RRF/SM/AppState) — la única dependencia desde este
// listener es leer el contenido del editor y llamar al validador.
// El módulo se carga ANTES del monolito (rotechos-lint-gcode.js está antes
// que rotechos.js en index.html), así `_lintGcode` ya está en globalThis
// cuando este listener se ejecuta. Test: tests/unit/lint-gcode.test.js.
(document
  .getElementById(`btnEditorClose`)
  .addEventListener(`click`, () => EDITOR.close()),
  document
    .getElementById(`btnEditorSave`)
    .addEventListener(`click`, async () => {
      const filename = editingFileName || EDITOR.filename;
      if (!filename) return;
      const content = $(`fileEditorArea`).value;
      // Validación pre-guardado de .g: evita subir firmware roto a la SD del Duet.
      const _lint = _lintGcode(content, filename);
      if (_lint.errors.length) {
        setText(`editorStatus`, `✗ ${_lint.errors.length} error(es) RRF — no guardado`);
        toast(`${filename}: ${_lint.errors[0]}${_lint.errors.length > 1 ? ` (+${_lint.errors.length - 1})` : ``}`, `err`);
        _lint.errors.forEach((e) => log(`Editor lint: ${e}`, `err`));
        return;
      }
      if (_lint.warnings.length) {
        _lint.warnings.forEach((w) => log(`Editor lint: ${w}`, `warn`));
        toast(`${filename}: ${_lint.warnings.length} aviso(s) — revisa consola. Guardando…`, `warn`);
      }
      const blob = new Blob([content], { type: `text/plain` }),
        file = new File([blob], filename);
      setText(`editorStatus`, `Guardando…`);
      const origDir = FM.dir;
      editingFileDir && (FM.dir = editingFileDir);
      const ok = await FM.upload(file, () => {});
      ((FM.dir = origDir),
        ok
          ? (($(`editorStatus`).textContent =
              `✓ Guardado`),
            toast(t(`msg.filenameGuardadoEnSd`, `${filename} guardado en SD`, { "filename": filename }), `ok`),
            log(`Editor: ${filename} guardado`, `cmd`),
            (EDITOR.closeTimer = setTimeout(() => {
              EDITOR.closeTimer = null;
              EDITOR.close();
            }, 800)))
          : (($(`editorStatus`).textContent =
              `✗ Error al guardar`),
            toast(t(`msg.errorAlGuardarFilename`, `Error al guardar ${filename}`, { "filename": filename }), `err`)));
    })
);

// BOOT CONSOLIDADO (H6 / PESO-6, 2026-08-18)
// Antes: 5 enganches sueltos de DOMContentLoaded + 1 de load desperdigados por
// el monolito, en orden de registro accidental:
//   - línea  91 — click delegate en body + A11Y modal/endstopOverlay
//   - línea 283 — _checkShellIntegrity() (H3)
//   - línea 291 — window.addEventListener("load", SW register)
//   - línea 481 — inline handler migration (pcMacros/pcSd/sys-cfg/newMacro/easter-egg)
//   - línea 3790 — macrosRestore/renderMacros/fmLoadList/initLayout/SAC/CoordMode + i18n-change
//   - línea 4220 — KIN.init() delayed 900ms
// Síntoma de fragmentación post-extracciones del monolito (sprint reducción
// jul-ago-2026): cada `addEventListener('DOMContentLoaded', ...)` que se
// añadía durante una extracción quedaba suelto. Hoy son 5 enganches que se
// ejecutan en orden de registro, pero el navegador NO garantiza ese orden
// respecto a enganches añadidos por otros `<script defer>` posteriores: un
// futuro módulo defer que se enganche a DOMContentLoaded puede correr antes
// que KIN.init() (que ya lleva su propio setTimeout(900)) y romper la
// inicialización silenciosamente.
//
// Ahora: una sola API `window.boot = { init, registerSW }` con el orden
// explícito y documentado. Un único listener por evento:
//   - `document.addEventListener('DOMContentLoaded', () => window.boot.init())`
//   - `window.addEventListener('load', () => window.boot.registerSW())`
//
// Las 5 piezas de init viven como `__bootStepN_*` justo donde antes estaban
// los enganches (con hoisting de declaración de función son accesibles desde
// aquí). El orden es EXACTAMENTE el orden de registro anterior: si algo
// dependía de ese orden accidental, se preserva.
window.boot = {
  init: async () => {
    // Pieza 1/5 — click delegate + A11Y modal/endstop overlay.
    __bootStep1_clickDelegateAndA11y();
    // Pieza 2/5 — chequeo de integridad del shell (H3).
    // Los <script defer> ya terminaron (DOMContentLoaded garantizada),
    // así que todos los centinelas deberían estar en window.
    _checkShellIntegrity();
    // Pieza 3/5 — migración de handlers inline a addEventListener
    // (pcMacros, pcSd, sys-cfg-shortcut, newMacroFileWrap, easter-egg Murciélago).
    __bootStep3_inlineHandlerMigration();
    // Pieza 4/5 — init final de los defer modules: macrosRestore, renderMacros,
    // fmLoadList, initLayout, SAC.init, CoordMode.init, i18n-change listener.
    __bootStep4_finalInit();
    // Pieza 5/5 — kinematic manager init (DELIBERADAMENTE diferido 900ms
    // para dar tiempo a KBSHORTCUTS a inicializar sus atajos de teclado).
    __bootStep5_kinematicInit();
  },
  registerSW: () => {
    // Pieza 6 (load event) — Service Worker register con updateViaCache:'none'.
    __bootStepSW_register();
  },
};
document.addEventListener('DOMContentLoaded', () => window.boot.init());
window.addEventListener('load', () => window.boot.registerSW());

// IIFE DE ARRANQUE — bootstrap temprano (no espera a DOMContentLoaded)
// Conecta RRF, configura el polling, dispara el wizard de primer arranque.
// Sigue haciendo su propio intento best-effort de renderMacros/fmLoadList
// (guard por la carrera del boot); boot.init() reintenta en DOMContentLoaded
// cuando todos los defer han cargado, así no perdemos la inicialización si
// RRF.connect() gana a los defers.
(async () => {
    (log(`RotechOS v7 — iniciando…`, `sys`),
      log(`Conectando a ${TARGET_IP}`, `sys`),
      updateStateUI(),
      updateButtonStates(),
      // renderMacros vive en rotechos-macros.js (defer posterior): en este
      // prólogo síncrono aún no existe. El DOMContentLoaded de más abajo
      // ya lo llama con el mismo guard cuando todos los módulos han cargado.
      typeof renderMacros == `function` && renderMacros(),
      (await RRF.connect())
        ? (setConn(!0, `Conectado`),
          toast(t(`msg.conectadoARotechos`, `Conectado a RotechOS`), `ok`),
          log(`Conexión establecida con RepRapFirmware`, `sys`),
          (AppState.limits.bootGrace = Date.now() + 3000),
          // loadPersistentUiConfig vive en rotechos-config-modal.js (defer #15).
          // Mismo patrón que 3345 (renderMacros): guard por si la carrera del
          // boot (await RRF.connect + respuesta < 1 ms en localhost) gana a
          // los defers pendientes. Sin el guard, ReferenceError mata la IIFE
          // antes de startPoll() — app arrancada pero muerta.
          //
          // t_b04be87e: la hidratación EAGER de `_endstopCfg` (la consume el
          // poll y el diagnóstico GPIO desde el primer tick) vive en el shim
          // core (`window.ensureConfigGEager`). La llamamos ANTES del
          // loadPersistentUiConfig perezoso para que el boot no dependa de
          // abrir CONFIGURACIÓN. Si la descarga falla, no rompe nada:
          // `_endstopCfg` queda con sus defaults y el modal la re-hidrata al
          // cargar.
          await (typeof window.ensureConfigGEager === `function`
            ? window.ensureConfigGEager()
            : Promise.resolve()).catch(() => {}),
          await (typeof loadPersistentUiConfig === `function`
            ? loadPersistentUiConfig()
            : Promise.resolve()),
          (async () => {
            try {
              const _bg = await _fetchModel("state.status", 3000);
              if (_bg) AppState.limits.bootGrace = Date.now() + 500;
              else AppState.limits.bootGrace = Date.now() + 5000;
            } catch {
              AppState.limits.bootGrace = Date.now() + 5000;
            }
          })(),
          startPoll(),
          _maybeShowFirstBootWizard())
        : (setConn(!1, `Sin conexión`),
          toast(t(`msg.sinConexionBuscando`, `Sin conexión — buscando máquina...`), `warn`),
          log(`Sin conexión al firmware — iniciando polling de reconexión`, `warn`),
          SM.transition(STATES.IDLE, `buscando red`),
          window.TELEMETRY?.update?.({}),
          startPoll()),
      // fmLoadList vive en rotechos-fm.js (defer #14). Mismo patrón que 3345/3351
      // (guard por la carrera del boot). La cabecera de fm.js documenta que vive
      // en DOMContentLoaded — eso era el plan original; se quedó en el IIFE async.
      (typeof fmLoadList === `function` && fmLoadList()));
})();

function _anyEndstopTriggered() {
  return (
    AppState.limits.prevHit &&
    [`X`, `Y`, `Z`].some((ax) => AppState.limits.prevHit[ax])
  );
}
async function _showLimitDialog(sensor, isSoftLimit) {
  if (AppState.limits.dialogOpen) return;
  AppState.limits.dialogOpen = true;
  const typeLabel = isSoftLimit ? t(`msg.softLimit`, `Soft Limit`) : t(`msg.limitSwitch`, `Final de carrera`);
  const sensorLabel = isSoftLimit ? sensor : `${t(`msg.axis`, `Eje`)} ${sensor}`;
  const msg =
    `<div style="text-align:center">` +
    `<div style="margin-bottom:12px"><svg width="44" height="44" viewBox="0 0 24 24" fill="none" stroke="var(--red)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg></div>` +
    `<div style="color:var(--red);font-size:16px;font-weight:800;margin-bottom:8px">${typeLabel}: ${sensorLabel}</div>` +
    `<div style="color:var(--text-2);font-size:13px;margin-bottom:16px">` +
    (isSoftLimit
      ? t(`msg.softLimitBody`, `La máquina ha alcanzado un límite de software y se ha pausado automáticamente.<br>Revisa que las coordenadas no excedan el área de trabajo.`)
      : `${t(`msg.limitSwitchPre`, `El final de carrera del eje`)} <strong style="color:var(--red)">${sensor}</strong> ${t(`msg.limitSwitchPost`, `se ha activado durante la ejecución.<br>La máquina se ha pausado automáticamente. Comprueba que no haya colisión.`)}`) +
    `</div>` +
    `<div style="color:var(--text-3);font-size:11px">${t(`msg.limitSwitchAction`, `Pulsa <strong>Reanudar</strong> para continuar el trabajo o <strong>Cancelar</strong> para detenerlo.`)}</div>` +
    `</div>`;
  try {
    const _ldPollId = setInterval(() => {
      if (SM.current === STATES.RUNNING && AppState.limits.dialogOpen) {
        log(
          `Estado cambió a RUNNING externamente — cerrando diálogo de límite`,
          `warn`,
        );
        AppState.limits.dialogOpen = false;
        AppState.limits.alarmActive = false;
        clearInterval(_ldPollId);
        startPoll();
        // 16-sep (C§12): cerrar por el camino del propio diálogo. Antes se le quitaba la
        // clase al modal y ya: los escuchadores de Aceptar/Cancelar y el de Escape seguían
        // vivos con la promesa colgada, así que un Enter dado HORAS después resolvía aquel
        // diálogo y mandaba M24 — un trabajo arrancado sin las guardas de START.
        $(`btnConfirmCancel`)?.click();
        const cm = $(`confirmModal`);
        cm && cm.classList.remove(`show`);
      }
    }, 500);
    // 15-sep: otra confirmación abierta (p.ej. la de la consola) se cierra como cancelada.
    // Antes confirmDialog devolvía false por re-entrada y eso CANCELABA el trabajo.
    if ($(`confirmModal`)?.classList.contains(`show`)) { $(`btnConfirmCancel`)?.click(); await new Promise((r) => setTimeout(r, 60)); }
    const resume = await confirmDialog(`${typeLabel} — ${sensorLabel}`, msg);
    clearInterval(_ldPollId);
    if (SM.current === STATES.RUNNING) {
      log(
        `Máquina ya reanudada externamente — ignorando acción de diálogo`,
        `warn`,
      );
      return;
    }
    if (resume) {
      if (isSoftLimit) {
        // Sin M999: reiniciaba el firmware (mata el job y dispara el watcher de M999
        // → overlay + reload de la página), así que el M24 posterior nunca reanudaba
        // nada. La pausa por soft limit es un M25 normal → M24 basta.
        log(`Reanudando tras soft limit — enviando M24`, `cmd`);
        await RRF.gcode(`M24`);
        SM.transition(STATES.RUNNING, `reanudado tras soft limit`);
        toast(t(`msg.trabajoReanudado`, `Trabajo reanudado`), `ok`);
      } else {
        log(`Reanudando tras endstop ${sensor} — enviando M24`, `cmd`);
        await RRF.gcode(`M24`);
        SM.transition(STATES.RUNNING, `reanudado tras endstop ${sensor}`);
        toast(t(`msg.trabajoReanudado`, `Trabajo reanudado`), `ok`);
      }
    } else {
      log(`Trabajo cancelado por usuario tras ${typeLabel}`, `warn`);
      // FIX: Pausar polling + M25 antes de M0 + restaurar SILK
      _clearPollTimer();
      SM._cancelInProgress = !0;
      try { await RRF.urgentGcode(`M25\nM0\nT0\nM5`); } catch {}
      if (isSoftLimit) {
        await RRF.gcode(`M999`);
        await new Promise((r) => setTimeout(r, 500));
      }
      // Restaurar SEDA tras cancelar
      try {
        const r = await RRF.gcode(`M98 P"${MACROS.setSilk}"`);
        if (!r) throw new Error(`Fallback`);
      } catch {
        RRF.gcode(FALLBACK_SEDA).catch(_swallowErr(`FALLBACK_SEDA`));
      }
      SM._cancelInProgress = !1;
      clearJob();
      SM.transition(STATES.IDLE, `cancelado tras ${typeLabel.toLowerCase()}`);
      toast(t(`msg.trabajoCancelado`, `Trabajo cancelado`), `warn`);
    }
  } catch (e) {
    LOG.error(`Limit dialog error:`, e);
  } finally {
    AppState.limits.dialogOpen = false;
    AppState.limits.alarmActive = false;
    startPoll();
  }
}
function updateEndstops(data) {
  // Usar cachés cuando no vienen datos frescos (ciclos sin needB)
  const es = data?.endstops ?? AppState.cache.endstops ?? [];
  const gpIn = data?.gpIn ?? AppState.cache.gpIn ?? [];
  const inGrace = Date.now() < AppState.limits.bootGrace;
  let anyHitNow = false;
  // ── Pill de la SONDA Z (M558) ──
  // Verde si libre (value=0), rojo si activada (value=1). Permite verificar
  // de un vistazo si el sensor invertido/pull-up está leyendo bien antes de
  // lanzar un palpado. data.probes lo trae el poll a través del Object Model.
  const probePill = $(`esProbe`);
  if (probePill) {
    let pv = data?.probes?.[0]?.value;
    if (Array.isArray(pv)) pv = pv[0];          // forma del Object Model: value=[n]
    // Las sondas RRF reportan distintos rangos según tipo: touch plate digital
    // usa 0/1; las inductivas en modo "modulated" (M558 P5) dan 0 libre y un
    // entero >0 al disparar (típico 1000). El guard de las macros usa `> 0`,
    // así que la pill replica esa semántica para coincidir con la realidad
    // (antes comparaba con === 1 → quedaba gris al disparar con value=1000).
    let probeCls, probeTitle;
    if (typeof pv !== `number`) { probeCls = ``;           probeTitle = t(`probe.noData`, `Sonda Z: sin datos`); }
    else if (pv > 0)            { probeCls = ` triggered`; probeTitle = t(`probe.active`, `Sonda Z: ACTIVADA (value=${pv})`); }
    else                        { probeCls = ` ok`;        probeTitle = t(`probe.free`, `Sonda Z: LIBRE (value=0)`); }
    probePill.className = `endstop-pill` + probeCls;
    probePill.title = probeTitle;
    // (mpgEsProbe eliminado del HTML al rediseñar el pendant)
  }
  [`X`, `Y`, `Z`].forEach((ax, i) => {
    const entry = es[i],
      trigIds = _triggerGpIn[ax],        // { min?: number, max?: number }
      hasTrigger = trigIds && (trigIds.min !== undefined || trigIds.max !== undefined),
      configured = !_endstopCfg[ax].off,
      trigLevel = _endstopCfg[ax].trigLevel ?? 1,
      // hit: solo evalúa los lados que el usuario ha habilitado (minOn/maxOn)
      // Evita falsos positivos por pull-up flotante en pines sin sensor conectado
      hit =
        configured &&
        !inGrace &&
        (hasTrigger && gpIn.length
          ? (_endstopCfg[ax].minOn && trigIds.min !== undefined && gpIn[trigIds.min]?.value === trigLevel) ||
            (_endstopCfg[ax].maxOn && trigIds.max !== undefined && gpIn[trigIds.max]?.value === trigLevel)
          : entry?.triggered === !0),
      // Durante el homing los pines se LIBERAN (M950 J C"nil") y gpIn[j] queda null:
      // sin dato no hay flanco. Evita la falsa alarma "sensor activado" al restaurar
      // el pin con el sensor aún pisado (fin del homing / máquina aparcada en home).
      pinsPresent = hasTrigger && gpIn.length
        ? (trigIds.min !== undefined && gpIn[trigIds.min] != null) ||
          (trigIds.max !== undefined && gpIn[trigIds.max] != null)
        : entry != null,
      cls = configured ? (hit ? ` triggered` : ` ok`) : ``,
      rawVals = hasTrigger
        ? [trigIds.min, trigIds.max].filter(j => j !== undefined).map(j => gpIn[j]?.value ?? `?`).join(`,`)
        : `n/a`,
      title = configured
        ? `${ax}: ${hit ? `ACTIVADO` : `Libre`} · GPIO=${rawVals} · trigger@${trigLevel}`
        : `${ax}: No configurado`,
      pcPill = $(`es${ax}`);
    pcPill &&
      ((pcPill.className = `endstop-pill` + cls), (pcPill.title = title));
    const mpgPill = $(`mpgEs${ax}`);
    mpgPill &&
      ((mpgPill.className = `endstop-pill` + cls), (mpgPill.title = title));
    const droRow = $(`w${ax}`)?.closest(`.dro-axis-row`);
    droRow &&
      droRow.classList.toggle(`dro-endstop-alert`, !!(hit && configured));
    // Actualizar LEDs per-endpoint en el panel de configuración
    // t_7edbf98d: la celda "Lectura" muestra estado separado de config
    // (icono + texto + timestamp). Sin esto, el operario no distingue
    // "ON + libre" de "OFF" sin pasar el ratón por encima del tooltip.
    const _pollNowTs = Date.now();
    // Guard defensivo: el sandbox de tests (tests/unit/endstop-dialog-guard.test.js)
    // no inyecta `window`, así que typeof window puede tirar ReferenceError
    // en lugar de devolver "undefined". Capturamos la ausencia de window
    // de forma que el código de pintado funcione en el sandbox sin ella.
    const _hasWindow = (typeof window !== `undefined`);
    const _ageFn = (typeof formatReadAge === `function`) ? formatReadAge
                 : (_hasWindow && typeof window.formatReadAge === `function`) ? window.formatReadAge
                 : null;
    [`Min`, `Max`].forEach((side) => {
      const sideActive = side === `Min` ? _endstopCfg[ax].minOn : _endstopCfg[ax].maxOn;
      const sideGpIdx = trigIds ? (side === `Min` ? trigIds.min : trigIds.max) : undefined;
      const sideHit = sideActive && (sideGpIdx !== undefined && gpIn.length ? gpIn[sideGpIdx]?.value === trigLevel : hit);
      const cfgLed = $(`ledEnd${ax}${side}`);
      cfgLed &&
        (cfgLed.classList.toggle(`triggered`, sideHit),
        cfgLed.classList.toggle(`ok`, sideActive && !sideHit),
        (cfgLed.title = sideActive
          ? sideHit ? `${ax} ${side}: ✕ ACTIVO` : `${ax} ${side}: libre`
          : `${ax} ${side}: No configurado`));
      // Actualizar también el contenedor .mcfg-endread (icono + texto + ts).
      if (cfgLed) {
        const _cont = cfgLed.closest(`.mcfg-endread`);
        if (_cont) {
          const readState = sideActive ? (sideHit ? `active` : `free`) : `off`;
          _cont.dataset.readState = readState;
          _cont.dataset.readTs = String(_pollNowTs);
          const _icon = _cont.querySelector(`.mcfg-endread-icon`);
          const _text = _cont.querySelector(`.mcfg-endread-text`);
          const _age  = _cont.querySelector(`.mcfg-endread-age`);
          if (_icon) _icon.textContent = ({free:`✓`, active:`✕`, off:`—`, unknown:`?`})[readState];
          if (_text) {
            _text.dataset.i18n = `cfg.endstops.read.${readState}`;
            _text.textContent = t(`cfg.endstops.read.${readState}`,
              ({free:`LIBRE`, active:`ACTIVADO`, off:`NO CONFIG.`, unknown:`NO LEÍDO`})[readState]);
          }
          if (_age && _ageFn) _age.textContent = _ageFn(_pollNowTs);
        }
      }
    });
    if (hit) anyHitNow = true;
    if (hit && AppState.limits.prevHit[ax] === false && !AppState.limits.alarmActive) {
      AppState.limits.alarmActive = true;
      if (LED.cfg.on && !LED._overlay) {
        LED.stop();
        LED._sendSolid(Math.round(LED.cfg.brightness * 0.65), 0, 0);
        setTimeout(() => LED.onStateChange(SM.current), 600);
      }
      if (data._rrfRaw === "busy" || data.homingInProgress) {
        // Ignorar alarmas de endstop durante homing u operaciones internas: los
        // sensores actúan como endstops (no como emergencia) y se tocan por
        // diseño. Sin log — durante el homing saltaba muchas veces y saturaba
        // la consola; la indicación visual sigue en los LED/panel de finales.
        AppState.limits.alarmActive = false;
        return;
      }
      
      // Detener movimiento en CUALQUIER estado — jog manual, trabajo, macro
      // Sin M410: RRF 3.5.4 no lo implementa (26-sep). Lo que para un trabajo es el M25 de abajo;
      // un jog en curso solo lo corta el M112 (PARO). trigger2.g tampoco: sin trabajo no hay nada
      // que pausar (27-sep, revisión de la integración R8; C4 del informe del 26-sep).
      RRF.urgentGcode(`T0\nM5`).catch(_swallowErr(`endstop.M5`));
      if (SM.current === STATES.RUNNING || SM.current === STATES.PAUSED) {
        RRF.urgentGcode(`M25`).catch(_swallowErr(`esc.M25`));
        SM.pauseRequestTime = Date.now();
        SM.transition(STATES.PAUSED, `Final de carrera ${ax}`);
        toast(t(`msg.endstopJobPaused`, `Final de carrera ${ax} — Trabajo pausado`, { "ax": ax }), `err`);
        log(`Final de carrera ${ax} activado — trabajo pausado`, `err`);
        typeof sendNotif === `function` &&
          sendNotif(`ALERTA`, `Final de carrera ${ax} activado`, `✕`, `notif.endstop`);
        (() => {
          const _ov = $(`endstopOverlay`);
          if (_ov) {
            _ov.style.display = "flex";
            const _oax = $(`endstopOverlayAxis`);
            if (_oax) _oax.textContent = `EJE ${ax}`;
          }
        })();
        _showLimitDialog(ax, false);
      } else {
        // IDLE: jog manual u otro movimiento
        log(`Final de carrera ${ax} activado — movimiento abortado`, `err`);
        toast(t(`msg.endstopMoveStopped`, `Tope físico ${ax} tocado — movimiento detenido. NO apagues la máquina. Para alejarte del tope, pulsa el botón de jog que va en sentido contrario (si no sabes cuál es, prueba −X, +Y, −Y, +Z, −Z por este orden, un paso a la vez). Si el tope salta repetidamente, revisa que la pieza no sobresalga del área de trabajo.`, { "ax": ax }), `err`);
        (() => {
          const _ov = $(`endstopOverlay`);
          if (_ov) {
            _ov.style.display = "flex";
            const _oax = $(`endstopOverlayAxis`);
            if (_oax) _oax.textContent = `EJE ${ax}`;
          }
        })();
      }
    }
    AppState.limits.prevHit[ax] = pinsPresent ? hit : null; // pin liberado (homing) = sin dato, no es flanco
  });
  if (
    AppState.limits.alarmActive &&
    !anyHitNow &&
    SM.current !== STATES.ERROR &&
    SM.current !== STATES.PAUSED
  ) {
    AppState.limits.alarmActive = false;
    log(`Alarma endstop limpiada — sensores libres`, `sys`);
    (() => {
      const _ov = $(`endstopOverlay`);
      if (_ov) _ov.style.display = "none";
    })();
  }
}
$(`btnEndstopReset`)?.addEventListener("click", () => {
  const _ov = $(`endstopOverlay`);
  if (_ov) _ov.style.display = "none";
});
registerUIHook(`mpg`, (data) => {
  if (typeof window.updateMPG != `function`) return;
  const isPaused = SM.current === STATES.PAUSED;
  // Extraemos la información del panel de progreso principal para que sean espejos perfectos
  const pctStr = $(`progPct`)?.textContent || `0%`;
  const pct = parseFloat(pctStr) || 0;
  const elapsedFmt = $(`progElapsed`)?.textContent || `00:00:00`;
  const remainFmt = $(`progRemaining`)?.textContent || `--:--:--`;
  window.updateMPG(data, SM.current, pct, elapsedFmt, remainFmt, isPaused);
});


// H6 (PESO-6, 2026-08-18): el listener suelto de DOMContentLoaded se ha
// movido al BOOT CONSOLIDADO (abajo). Aquí dejamos solo el cuerpo como
// función invocable: pieza 4/5 de boot.init().
function __bootStep4_finalInit() {
  (typeof macrosRestoreCustom == `function` && macrosRestoreCustom(),
    typeof renderMacros == `function` && renderMacros(),
    typeof fmLoadList == `function` && fmLoadList(),
    typeof initLayout == `function` && initLayout(),
    typeof SAC !== "undefined" && SAC.init(),
    typeof CoordMode !== "undefined" && CoordMode.init(),
    // UI-7 (t_18afd7a2): inicializa el observer de disabled-hints.
    // Cubre los 18 botones del inventario §4.2 sin tocar el HTML uno a uno.
    typeof wireDisabledHints == `function` && wireDisabledHints(),
    // FASE 5 (t_f92d87da): el banner AP y el redirect al wizard paso 4 (WiFi).
    // El módulo rotechos-apdetector.js publica `window.APDetector = { init,
    // _check, openConfig }` al cargarse `defer` ANTES de rotechos.js; init()
    // engancha el hook al POLL, programa el chequeo inicial a 3s y enlaza
    // el listener de #btnApConfigWifi. Si el módulo fallara al cargar, el
    // `typeof` degrada sin romper el boot (el banner AP es importante pero
    // no centinela — un cliente sin red local no lo vería de todos modos).
    window.APDetector && typeof window.APDetector.init === `function` && window.APDetector.init(),
    window.addEventListener(`i18n-change`, () => {
      updateStateUI();
    }),
    log(`RotechOS Iniciado`, `sys`));
}

// ---
// NAVEGACIÓN — Cambio de vistas y gestión de layout
// ---
//
// TARJETA t_d0e3f8b6 · FASE 4 del plan de fragmentación del monolito
// (docs/dev/hallazgos/2026-09-09_monolito-diagnostico-y-plan-de-fragmentacion.md §3).
// La función `nav(view)` ya no existe en este fichero (cabecera histórica
// de un sprint previo que la movió fuera). El asistente ZCAL (var ZCAL
// con 8 métodos) sale a `rotechos-zcal.js` (LAZY via __lazyLoad).
//
// El monolito conserva un PROXY en `window.ZCAL` (mismo patrón que el
// proxy `window.openMachineConfig`): cada método (`open`, `close`,
// `step2`, `step3`, `paperDrags`, `save`, `up`, `descend`, `go`) dispara
// `__lazyLoad('/js/rotechos-zcal.js')` la primera vez y delega al real.
// index.html:3222 define `_ACTIONS.ZCAL.*` que consume `ZCAL.X()` por
// nombre; basta con que el proxy exista para que el dispatcher funcione.
// Tras la primera carga, `rotechos-zcal.js` SOBREESCRIBE `window.ZCAL`
// con la versión real y las llamadas posteriores llegan directas.
//
// tests de referencia: tests/e2e-asistentes-guardas-paridad.spec.js (guardas del
// asistente). tests/jerga-DRO-WCS-MCS no toca ZCAL.
// scripts/build_posts_table.mjs:46 lee `ZCAL` directamente (no via el
// dispatcher) — el proxy expone la misma forma que el real, así que sirve.

// eslint-disable-next-line no-var -- var deliberado: se usa antes de esta declaración (hoisting, mismo patrón que KIN)
var SAC = {
  // Default true; el valor real se carga desde config.g (; rotech-sac=) en
  // loadPersistentUiConfig — la SD es la única fuente de la verdad (SSOT).
  enabled: true,

  active: false,

  lastSeq: -1,

  init: function () {
    const btnOk = $(`btnFwMessageOk`);

    const btnCancel = $(`btnFwMessageCancel`);

    if (btnOk)
      btnOk.onclick = async () => {
        await RRF.gcode("M292");

        $(`fwMessageModal`).classList.remove("show");

        this.active = false;
      };

    if (btnCancel)
      btnCancel.onclick = async () => {
        await RRF.gcode("M292 P1");

        $(`fwMessageModal`).classList.remove("show");

        this.active = false;
      };
  },

  show: function (msgBox) {
    if (!msgBox) return;

    const titleEl = $(`fwMessageTitle`);

    const contentEl = $(`fwMessageContent`);

    const btnCancel = $(`btnFwMessageCancel`);

    const btnOk = $(`btnFwMessageOk`);

    const title = msgBox.title || "MENSAJE DEL SISTEMA";

    const msg = msgBox.message || "";

    titleEl.textContent = title;

    // Si es un cambio de herramienta, resaltamos el nombre (con escape)

    let safeMsg = escHtml(msg)
      .replace(/&lt;br\s*\/?&gt;/gi, "<br>")
      .replace(/&lt;b&gt;/gi, "<b>")
      .replace(/&lt;\/b&gt;/gi, "</b>")
      .replace(/&lt;strong&gt;/gi, "<strong>")
      .replace(/&lt;\/strong&gt;/gi, "</strong>")
      .replace(/(Cero Z debe estar[^<.]+)/gi, '<span style="color:var(--warn-strong);font-weight:800;border-bottom:1px dashed var(--warn-strong);">$1</span>');

    if (
      safeMsg.toUpperCase().includes("TOOL") ||
      title.toUpperCase().includes("HERRAMIENTA")
    ) {
      const tn = safeMsg.match(/TOOL\s*([^,]*)/i) || safeMsg.match(/T(\d+)/i);

      if (tn)
        safeMsg = safeMsg.replace(
          tn[0],
          `<span class="tc-tool-name" style="color:var(--green-strong);font-weight:800;font-size:1.2em">${tn[0]}</span>`,
        );
    }

    contentEl.innerHTML = safeMsg;

    // 26-sep (auditoría contra RRF 3.5.4): el Cancelar salía en el modo 2, que es «solo OK», y
    // no en el 3. RRF acepta un M292 P1 en cualquier aviso bloqueante y, dentro de una macro,
    // solo sale de ella: la que la llamó sigue (GCodes.cpp:465-485). Solo si el firmware lo ofrece.
    if (msgBox.cancelButton === true || (msgBox.cancelButton === undefined && msgBox.mode === 3)) {
      if (btnCancel) btnCancel.style.display = "block";

      if (btnOk) btnOk.textContent = "ACEPTAR";
    } else {
      if (btnCancel) btnCancel.style.display = "none";

      if (btnOk) btnOk.textContent = "CONTINUAR";
    }

    $(`fwMessageModal`).classList.add("show");

    this.active = true;

    this.lastSeq = msgBox.seq || 0;
// eslint-disable-next-line no-var

  },
};

// eslint-disable-next-line no-var -- var deliberado: se usa antes de esta declaración (hoisting, mismo patrón que KIN)
var CoordMode = {
  // Default WCS; el valor real se carga desde config.g (; rotech-coordmode=)
  // en loadPersistentUiConfig — la SD es la única fuente de la verdad (SSOT).
  current: "WCS",

  init: function () {
    const btnW = $(`btnToggleWCS`);

    const btnM = $(`btnToggleMCS`);

    const card = $(`mainDROCard`);

    if (!btnW || !btnM || !card) return;

    const upd = () => {
      const lblWcsBadge = $(`mWCS2`);

      const dot = $(`coordDot`);

      if (this.current === "WCS") {
        btnW.classList.add("active");

        btnM.classList.remove("active");

        card.classList.remove("mcs-view");

        if (lblWcsBadge) lblWcsBadge.textContent = t(`span.g54-e11d`, `PIEZA`);

        if (dot) dot.style.setProperty("--cdot", "var(--blue)", "important");
      } else {
        btnW.classList.remove("active");

        btnM.classList.add("active");

        card.classList.add("mcs-view");

        if (lblWcsBadge) lblWcsBadge.textContent = t(`span.mcs-e56d`, `MÁQUINA`);

        if (dot) dot.style.setProperty("--cdot", "var(--warn-strong)", "important");
      }
    };

    // Exponer el render para que loadPersistentUiConfig reaplique tras cargar
    // el valor desde config.g sin re-escribir el archivo (solo visual).
    this.render = upd;

    btnW.onclick = () => {
      this.current = "WCS";
      upd();
      cfgPersistComment("rotech-coordmode", "WCS");
    };

    btnM.onclick = () => {
      this.current = "MCS";
      upd();
      cfgPersistComment("rotech-coordmode", "MCS");
    };

    upd();
  },
};

// 27-sep (revisión de la integración, R3): el microajuste Z (M290) queda puesto en RRF hasta un
// reinicio o un PARO (GCodes.cpp:261) y nada lo enseñaba: el trabajo siguiente salía más hondo (o
// al aire) sin que nadie lo supiera. start.g lo pone a 0; aquí se enseña mientras no sea 0.
registerUIHook(`babystep`, (d) => {
  const v = d && d.babystepZ;
  if (typeof v !== `number`) return;
  for (const id of [`bsZ`, `bsZmpg`]) {
    const el = $(id);
    if (!el) continue;
    el.hidden = Math.abs(v) < 0.0005;
    el.textContent = el.hidden ? `` : ` µZ ${v > 0 ? `+` : ``}${v.toFixed(3)}`;
  }
});
registerUIHook(`sac`, (d) => {
  if (d && d.messageBox) {
    // FIX CRÍTICO: M291 S2/S3 SIEMPRE deben mostrarse — bloquean el firmware.
    // Si no se muestran, la máquina se congela indefinidamente esperando respuesta.
    // SAC.enabled solo controla si se usa el panel SAC (tool change) como UI,
    // pero los diálogos del firmware son universales y obligatorios.
    if (d.messageBox.mode === 2 || d.messageBox.mode === 3) {
      const newSeq = d.messageBox.seq !== undefined ? d.messageBox.seq : 0;
      if (!SAC.active || SAC.lastSeq !== newSeq) {
        SAC.show(d.messageBox);
        SAC.lastSeq = newSeq;
      }
    // M291 S1: Transient
    } else if (d.messageBox.mode === 1 && (!SAC.active || SAC.lastSeq !== d.messageBox.seq)) {
      toast(d.messageBox.message, `info`);
      SAC.lastSeq = d.messageBox.seq !== undefined ? d.messageBox.seq : 0;
    }
  } else if (SAC.active && (!d || !d.messageBox)) {
    // Placa ya no reporta mensaje — cerrar modal local
    const modal = $(`fwMessageModal`);
    if (modal) modal.classList.remove(`show`);
    SAC.active = false;
  }
});


// eslint-disable-next-line no-var

/* ===== KINEMATIC MANAGER — Perfiles Dinámicos de Movimiento =====
   Controla la física de la máquina (firmware) y la interfaz visual.
   `var` (no `const`): _uiSyncKinematicMode() lo referencia con `typeof KIN`
   en L1412, antes de esta declaración. Hoy un early-return lo protege en
   arranque, pero `var` elimina el riesgo de TDZ de raíz. */
// eslint-disable-next-line no-var -- var deliberado (TDZ, ver comentario de arriba)
var KIN = (function () {
  let mode = "silk";
  let _pendingMode = null;

  return {
    init() {
      // Hook de transición: cuando SM cambia de estado, se evalúa SEDA↔RAYO automáticamente.
      this._hookTransition();
      // kinBadge es SOLO INDICADOR (contrato documentado en sw.js v101 y en
      // tests/e2e-baseline-rojos.txt:84-85). NO se añade click, role, tabindex
      // ni cursor:pointer. El operario alterna SEDA↔RAYO por los atajos 'r'/'s'
      // (línea ~4675) o por carga/paro de trabajo (vía _hookTransition).
      const pill = $(`kinBadge`);
      if (pill) {
        pill.style.cursor = `default`;
      }
      this._renderUI();
    },

    /** H-4: alterna SEDA↔RAYO desde la UI con guarda de estado.
       Bloquea durante RUNNING/PAUSED/ERROR/HOMING/SIMULATING (un cambio de
       perfil cinemático a mitad de trabajo es peligroso). En IDLE/READY
       deja aplicar el toggle y refresca el badge. */
    _toggleFromUi() {
      if ([STATES.RUNNING, STATES.PAUSED, STATES.ERROR, STATES.HOMING, STATES.SIMULATING].includes(SM.current)) {
        toast(t(`msg.kinToggleBlocked`, `No puedes cambiar SEDA/RAYO con la máquina en ${SM.current}. Detén el trabajo primero.`, { state: SM.current }), `warn`);
        return;
      }
      const _mode = this.getMode();
      _pendingMode = (_mode === `pro`) ? this._applySilk() : this._applyPro();
    },

    async waitReady() {
      if (_pendingMode) {
        await _pendingMode;
        _pendingMode = null;
      }
    },

    _hookTransition() {
      if (this._hooked) return;
      this._hooked = true;
      const orig = SM.transition.bind(SM);
      SM.transition = (toState, reason) => {
        const prev = SM.current;
        const ok = orig(toState, reason);
        if (!ok) return ok;

        // ── Cambio automático SEDA ↔ RAYO (sin intervención del operario) ──
        // Reglas (t_42f09bed):
        //   1. IDLE → READY (carga de G-code) → RAYO anticipado (pre-mecanizado)
        //   2. READY/IDLE → RUNNING → RAYO (rendimiento de mecanizado)
        //   3. RUNNING → PAUSED → NO TOCAR PERFIL (Sergi 2026-09-02:
        //      pausar mantiene RAYO para que al reanudar ya esté listo;
        //      nota de producto: el jog durante la inspección es ahora
        //      más brusco — Sergi lo sabe y lo asume — ver acta del carril)
        //   4. PAUSED → RUNNING → RAYO (volver al corte; red de seguridad
        //      por si por cualquier vía el perfil acabó en SEDA estando
        //      en PAUSED, al reanudar siempre queda RAYO)
        //   5. RUNNING/PAUSED → IDLE/READY/ERROR → SEDA (reposo, protege
        //      el jog posterior tras paro/cancelación/error)
        // Solo bloquear RAYO si "Requerir HOME" está activado Y los ejes no están referenciados.

        const _homReq = $(`mcfgHomingRequired`)?.checked ?? true;
        const canPro = !_homReq || AppState.limits.allHomed !== false;

        // R1: carga de archivo → RAYO anticipado
        if (toState === "READY" && prev === "IDLE" && canPro) {
          _pendingMode = this._applyPro();
        }
        // R1b: DESCARGA del archivo sin haber llegado a ejecutar → SEDA.
        // Es el inverso de R1 y faltaba. R5 solo devuelve a SEDA si se venia
        // de RUNNING o PAUSED, asi que cargar un archivo y descargarlo sin
        // arrancar dejaba RAYO activo: la maquina se quedaba con las
        // aceleraciones y el jerk de mecanizado para el JOG MANUAL, que es
        // exactamente lo que SEDA existe para evitar. Reportado por Sergi
        // 2026-08-29; el bordeador ya arrastraba esta misma clase de fallo
        // (ver rotechos-bordeador.js:216).
        else if (toState === "IDLE" && prev === "READY") {
          _pendingMode = this._applySilk();
        }
        // R2: arranque → RAYO (cualquier prev que NO sea RUNNING/PAUSED).
        // Conserva la semántica original (antes de t_42f09bed el operador era
        // `prev !== "RUNNING" && prev !== "PAUSED"`) cubriendo IDLE/READY y
        // también cualquier estado no-pausa desde el que SM pueda saltar a
        // RUNNING (defensa frente a transiciones inesperadas). R4 abajo
        // captura explícitamente el caso PAUSED → RUNNING.
        else if (toState === "RUNNING" && prev !== "RUNNING" && prev !== "PAUSED" && canPro) {
          _pendingMode = this._applyPro();
        }
        // R4: reanudación desde pausa → RAYO (red de seguridad t_42f09bed).
        // Por diseño, R3 ya NO fuerza SEDA al pausar (Sergi pidió mantener
        // RAYO durante la pausa), pero si por cualquier vía (toggle manual,
        // orden SM, reentrada al script, etc.) el perfil quedó en SEDA
        // mientras la máquina estaba PAUSED, al reanudar siempre debe
        // volver a RAYO. Esto deja explícita la regla 4 que estaba
        // documentada pero no implementada en el código previo.
        else if (toState === "RUNNING" && prev === "PAUSED" && canPro) {
          _pendingMode = this._applyPro();
        }
        // R5: fin de trabajo / cancelación / error → SEDA
        else if (prev === "RUNNING" || prev === "PAUSED") {
          if (
            toState === "IDLE" ||
            toState === "READY" ||
            toState === "ERROR"
          ) {
            this._applySilk();
          }
        }
        return ok;
      };
    },

    async _applyPro() {
      if (mode === "pro") return;
      // Solo bloquear RAYO si "Requerir HOME" está activado Y los ejes no están referenciados.
      const _homReq = $(`mcfgHomingRequired`)?.checked ?? true;
      if (_homReq && AppState.limits.allHomed === false) {
        toast(t(`msg.referenciaLosEjesAntes`, "Referencia los ejes antes de activar el modo RAYO"), "warn");
        return;
      }
      mode = "pro";
      this._renderUI();   // feedback inmediato: el badge no espera a la rampa (~600ms)
      try {
        await RRF.gcode(`M98 P"${MACROS.setPro}"`);
      } catch {
        LOG.error("KIN: Error aplicando ramp_to_pro.g");
      }
    },

    async _applySilk() {
      if (mode === "silk") return;
      mode = "silk";
      this._renderUI();   // feedback inmediato: el badge no espera al gcode
      try {
        await RRF.gcode(`M98 P"${MACROS.setSilk}"`);
      } catch {
        LOG.error("KIN: Error aplicando set_silk.g");
      }
    },

    _renderUI() {
      const pill = $(`kinBadge`);
      if (!pill) return;
      const isPro = mode === "pro";

      pill.className = "kin-pill " + (isPro ? "pro" : "silk") + " school-tip";
      pill.title = isPro ? "MODO RAYO (trabajo)" : "MODO SEDA (manual)";

      const svg = $(`kinIcon`);
      if (svg) {
        svg.innerHTML = isPro
          ? '<polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>'
          : '<path d="M20.24 12.24a6 6 0 0 0-8.49-8.49L5 10.5V19h8.5z"/><line x1="16" y1="8" x2="2" y2="22"/><line x1="17.5" y1="15" x2="9" y2="15"/>';
      }
    },

    getMode() {
      return mode;
    },

    setModeSilent(m) {
      if (mode === m) return;
      mode = m;
      this._renderUI();
    },
  };
})();
// ---
// H-B (informe 2026-08-17_busca-el-monolito-rotechosjs-v2): handle y
// helper de cancelación del polling de M37 simulación a TOP-LEVEL
// (no dentro de un IIFE) para que el listener de visibilitychange
// (rotechos.js:2245, dentro del IIFE principal 388-4429) y el click
// handler de #btnQaSimulate (rotechos.js:4756, dentro del IIFE 4669-4902)
// puedan compartir el mismo ciclo de vida. Antes vivían como
// `const _pollResult = …` dentro del callback, así que solo se podían
// limpiar en 3 paths internos.
// ---
let _simPollingHandle = null;
function _cancelSimPolling() {
  if (_simPollingHandle !== null) {
    clearInterval(_simPollingHandle);
    _simPollingHandle = null;
  }
}

// Inicialización del manager
// H6 (PESO-6, 2026-08-18): el listener suelto de DOMContentLoaded se ha
// movido al BOOT CONSOLIDADO (abajo). Aquí dejamos solo el cuerpo como
// función invocable: pieza 5/5 de boot.init().
function __bootStep5_kinematicInit() {
  // El setTimeout(900) es DELIBERADO: da tiempo a KBSHORTCUTS (el último
  // módulo crítico defer) a inicializarse. Sin él, KIN.init() corre antes
  // de que los atajos de teclado estén enganchados y el primer toggle
  // SEDA↔RAYO desde teclado se pierde. Verificado en la ola 5.
  setTimeout(() => KIN.init(), 900);
}
window.KIN = KIN;

// BIENVENIDA — wizard de primer arranque (idioma + esencial + checklist).
// El objeto `WLC` y la IIFE `initWelcome` viven en rotechos-welcome.js (defer
// module, sprint 6 f2 del programa de reducción del monolito). Aquí solo queda
// _maybeShowFirstBootWizard, que depende de SM/_fetchModel/_unwrap/LOG y se
// invoca desde el IIFE de arranque del monolito (rotechos.js:3324).
// ---

// ---
// APDetector (banner de modo AP) vive en rotechos-apdetector.js; aqui solo
// queda la fachada que bootStep4 arranca con init(). Historia: t_f92d87da.
// ---

// G2: dispara el wizard de bienvenida si firstBootCompleted === false (==>
// primer arranque real, no mock). Diseñado para invocarse DESPUÉS del await
// RRF.connect() en la IIFE de inicio — fuera del prólogo síncrono. Válvulas:
// (a) === false explícito; undefined / 'false' en string / null = NO dispara
//     (mock no devuelve el global, e2e no dispara), (b) STORE.wizard.welcomed
//     aún no seteado (initWelcome ya filtra por STORE), (c) SM no está
//     corriendo un trabajo (RUNNING/PAUSED = operación en curso = no molestar).
//
// B2-BIS (Claude 2ª verificación): caso inverso — fb.value === true significa
// que la máquina YA está configurada. Para evitar el nag persistente en móviles
// nuevos contra esa máquina, persistimos welcomed=true en STORE. Y re-comprobamos
// STORE DESPUÉS del await (carrera: el usuario pudo descartar el modal mientras
// se resolvía el fetch — no se lo re-abrimos).
async function _maybeShowFirstBootWizard() {
  try {
    if (SM.current === `RUNNING` || SM.current === `PAUSED`) return;
    if (STORE.get(`wizard.welcomed`)) return;
    const r = await _fetchModel(`global.firstBootCompleted`, 2000);
    // B2-BIS: race — el usuario pudo descartar el modal durante los ~2s del fetch.
    if (STORE.get(`wizard.welcomed`)) return;
    const g = r && _unwrap(r);
    // La respuesta es un array de globals de RRF 3.5: buscar firstBootCompleted
    const fb = Array.isArray(g)
      ? g.find((x) => x && x.key === `firstBootCompleted`)
      : null;
    if (!fb) return;
    if (fb.value === false) {
      WLC.show(1);
      $(`welcomeModal`)?.classList.add(`show`);
      log(`G2: auto-wizard first-boot disparado (firstBootCompleted=false)`, `sys`);
    } else if (fb.value === true) {
      // B2-BIS: máquina ya configurada. Persistir welcomed y cerrar el modal
      // si quedó abierto por la carrera con initWelcome.
      STORE.set(`wizard.welcomed`, true);
      const modal = $(`welcomeModal`);
      if (modal?.classList.contains(`show`) && modal.getAttribute(`data-user-interacted`) !== `true`) {
        modal.classList.remove(`show`);
        log(`G2: welcomeModal cerrado automáticamente (firstBootCompleted=true en máquina preconfigurada)`, `sys`);
      }
    }
  } catch (e) {
    LOG.warn(`G2 _maybeShowFirstBootWizard:`, e);
  }
}

// ---
// MI PRIMER CORTE — checklist guiado para usuarios nuevos (cockpit).
// Migrado a rotechos-firstcut.js (MON-FIRSTCUT, jul-2026). El bloque
// vivía aquí y solo LEÍA estado (AppState.limits, SM.loadedFile,
// DRO.tMcs/tWcs, SM.current) — verificado extraíble-limpio. El módulo
// nuevo monta su propio setInterval de 1000 ms; NO queda interval
// duplicado porque este era el único initFirstcut del shell.
// El shell conserva la cabecera como nota histórica para los grep
// que busquen 'MI PRIMER CORTE'.
// ---


// ---
// VISTA MÓVIL — botones del pendant (la app en el teléfono)
// ---
(function initMobileButtons() {
  // ── Visor de trayectoria del pendant: colapsado por defecto, toggle persistente.
  //    El espejo (mpgVizMirror) ya se auto-apaga con display:none (offsetParent null),
  //    así que colapsado no cuesta batería. ──
  const vizToggle = $(`mpgVizToggle`), vizWrapEl = $(`mpgVizWrap`);
  if (vizToggle && vizWrapEl) {
    const vizApply = (show) => {
      vizWrapEl.style.display = show ? `` : `none`;
      const ch = $(`mpgVizChevron`);
      if (ch) ch.textContent = show ? `\u2212` : `+`;
    };
    const vizSaved = STORE.get(`mpg.showViz`);
    vizApply(vizSaved);
    vizToggle.addEventListener(`click`, () => {
      const show = vizWrapEl.style.display === `none`;
      vizApply(show);
      STORE.set(`mpg.showViz`, show);
    });
  }

  // Consola plegada: se restaura lo que el usuario dejo. En una instalacion
  // nueva parte PLEGADA para priorizar el visor; la entrada queda disponible.
  {
    const outConsola = $(`consoleOut`);
    const btnPlegar = $(`btnConsoleFold`);
    if (outConsola && btnPlegar) {
      const plegada = STORE.get(`ui.consolaPlegada`) === true;
      outConsola.classList.toggle(`collapsed`, plegada);
      aplicaPlegadoConsola(btnPlegar, plegada);
    }
  }


  // H-5: 7 listeners para botones pendant antiguos ELIMINADOS (ver Block A §5).

  // ── Estado del jog-lock en vista PENDANT ─────────────────────────
  const _origUpdateStateUI = window.updateStateUI || function () {};
  window.updateStateUI = function () {
    _origUpdateStateUI();
    // A2 fix (2026-07-21): el toggle apuntaba a .mpg-jog-section (0 usos en DOM) y
    // nadie ponía display:flex a #pendantJogLock → el banner "JOG BLOQUEADO" nunca se
    // veía (el bloqueo funcional sí opera vía _b7IsJogLocked). Se actúa directo sobre el div.
    const jogLocked = SM.current === STATES.RUNNING || SM.current === STATES.PAUSED;
    const pendantJogLock = $q("#pendantJogLock");
    pendantJogLock && (pendantJogLock.style.display = jogLocked ? "flex" : "none");
  };

})();

/* ===== END KINEMATIC MANAGER ===== */

/* ===== CLICK-OUTSIDE MODAL CLOSE ===== */
// Extraído a ROTECHOS/www/js/rotechos-modal-backdrop.js (t_391f0813, ago-2026).
// El bloque original vivía aquí (líneas 4036-4047 del monolito previo) y
// fue trasladado tal cual al nuevo módulo, que ejecuta la misma IIFE
// $('.modal-overlay' + addEventListener click que retira 'show' SOLO cuando
// el target es el propio overlay). NO usar bindFastTouch aquí; ver cabecera
// de rotechos-modal-backdrop.js para la razón.

/* ===== QUICK ACTIONS ===== */
(function () {
  let el;
  el = $(`btnQaHomeAll`);
  if (el)
    el.addEventListener("click", async function () {
      if (machineMoveBlocked()) return;
      if (
        !(await confirmDashboard(
          t(`dlg.homeAll.title`, "Home All"),
          t(`dlg.homeAll.msg`, "¿Referenciar todos los ejes? Cada eje irá hasta su final de carrera."),
        ))
      )
        return;
      const r = await RRF.gcode("G28");
      toast(r ? t(`msg.homingStarted`, "Homing iniciado…") : t(`msg.homingErr`, "Error: G28"), r ? "info" : "err");
    });
  el = $(`btnQaSondaZ`);
  if (el)
    el.addEventListener("click", async function () {
      // §4.8 (t_014cd150) — el botón ahora exige HOME válido (vía
      // window.cfgProbeGuard), no solo "no RUNNING". Si la máquina NO está
      // referenciada, el guard emite el toast y aborta. La lógica de
      // RUNNING queda dentro del guard (machineMoveBlocked).
      if (typeof cfgProbeGuard === `function` && !cfgProbeGuard(`probe`)) return;
      if (
        !(await confirmDashboard(
          t(`dlg.probeZ.title`, "Sonda Z"),
          t(`dlg.probeZ.msg`, "SONDA Z: la máquina irá al pulsador fijo (en X máximo), lo palpará y pondrá Z=0 en la mesa más el grosor de material configurado en CONFIGURACIÓN → SONDA Z. Antes: recorrido libre hasta el pulsador, fresa montada y manos fuera. Si el grosor no es el de tu material, el cero quedará mal. Se ejecutará la macro sonda_Z.g. ¿Continuar?"),
        ))
      )
        return;
      // HUECO-2 y HUECO-3 (t_e558a603, acta 2026-09-06_C-robustez-percibida.md):
      // palpar es lento por naturaleza (baja hasta tocar, doble pasada) y el
      // toast de fallo era «Error: sonda_Z.g» — nombra el fichero de macro, no
      // lo que le pasa al operario ni por que. Ahora: aviso si tarda (cancelado
      // en cuanto responde, sin espera anadida) y, si falla, la causa real que
      // `RRF.gcode` ya dejaba en `RRF._lastFail` y nadie leia aqui.
      const _of = (typeof window !== `undefined` && window.rotechosOpFeedback) || null;
      const _opPalpar = t(`msg.opPalparZ`, `palpar la Z`);
      const _lento = _of ? _of.opSlow(_opPalpar) : null;
      const r = await RRF.gcode(`M98 P"${MACROS.sondaZ}"`);
      if (_lento) _lento();
      if (r) {
        toast(t(`msg.probeStarted`, "Sonda Z iniciada…"), "info");
        log("M98 sonda_Z.g — Sonda Z iniciada", "cmd");
        droRipple(`wZ`); // onda verde: el palpado fijó el Z (evento real)
      } else if (_of) {
        _of.opFail(_opPalpar);
      } else {
        toast(t(`msg.probeErr`, "Error: sonda_Z.g"), "err");
      }
    });
  el = $(`btnQaM6`);
  if (el)
    el.addEventListener("click", async function () {
      // §4.8 (t_014cd150) — el SAC (M6) ahora exige HOME válido igual que
      // btnQaSondaZ. El aparcamiento va a una coordenada G53 (X/Y del
      // sensor) — sin HOME, la máquina va a esa posición A CIEGAS, y si
      // el operario tiene mordazas o la pieza sobresaliendo, se estampa.
      // El aviso de husillo (H-2 fix 2026-08-15) se mantiene en el
      // confirmDialog de abajo.
      if (typeof cfgProbeGuard === `function` && !cfgProbeGuard(`m6`)) return;
      if (
        !(await confirmDashboard(
          t(`dlg.toolChange.title`, "Cambio de herramienta"),
          // FIX H-2 (t_ee4732e3, 2026-08-15): el confirm advertía de retirar la
          // fresa y pulsar LISTO, pero NO decía nada del husillo. La UI no
          // manda M5 explícito (delega en M6.g) y con husillo VFD a 18.000 rpm
          // el operario puede pensar "listo, ya está parado" sin haberlo
          // hecho. Se añade el aviso de detener el husillo al inicio, en
          // negrita para que se lea antes del "resto de la historia".
          t(`dlg.toolChange.msg`, "Cambio de herramienta (M6): antes de continuar, <b>detén el husillo</b> y espera a que la fresa se detenga por completo. Si tienes una fresa puesta, aflójala y quítala primero. La máquina levantará Z, irá a la zona de cambio y esperará. Tras cambiar la fresa, apriétala y pulsa LISTO para continuar en el punto donde iba. ¿Continuar?"),
        ))
      )
        return;
      const r = await RRF.gcode("M6");
      toast(r ? t(`msg.m6Sent`, "M6 enviado…") : t(`msg.m6Err`, "Error: M6"), r ? "info" : "err");
    });
  el = $(`btnQaGoto0`);
  if (el)
    el.addEventListener("click", async function () {
      if (machineMoveBlocked()) return;
      if (!AppState.limits.allHomed) {
        toast(t(`msg.noHomed`, "La máquina no sabe dónde está todavía: pulsa el botón HOME de la barra superior (o HOME TODOS en COCKPIT). Hasta que no esté en Home, se niega a moverse a una coordenada por seguridad."), "warn");
        return;
      }
      // Confirmación: mueve la máquina (antes era el ÚNICO quick-action sin confirm)
      if (!(await confirmDashboard(
        t(`dlg.goto0.title`, "Ir a 0"),
        t(`dlg.goto0.msg`, "La máquina irá a (X0, Y0) del origen de pieza actual (WCS) — no al origen de máquina. Antes de Ir a 0, asegúrate de que ya has fijado el origen de pieza con ZERO XY. Si dudas, cancela y ve a CEROS → FIJAR origen. ¿Continuar?"),
      )))
        return;
      const r = await RRF.gcode(`M98 P"${MACROS.goto0}"`);
      toast(r ? t(`msg.goto0`, "Yendo a 0…") : t(`msg.goto0Err`, "Error: goto0.g"), r ? "info" : "err");
    });
  el = $(`btnQaPark`);
  if (el)
    el.addEventListener("click", async function () {
      if (machineMoveBlocked()) return;
      if (!AppState.limits.allHomed) {
        toast(t(`msg.noHomed`, "La máquina no sabe dónde está todavía: pulsa el botón HOME de la barra superior (o HOME TODOS en COCKPIT). Hasta que no esté en Home, se niega a moverse a una coordenada por seguridad."), "warn");
        return;
      }
      if (
        !(await confirmDashboard(
          t(`dlg.park.title`, "Aparcar"),
          t(`dlg.park.msg`, "La máquina se moverá a la zona de aparcamiento (al fondo y arriba) y desactivará los motores X/Y para que puedas mover el puente a mano. La posición de la pieza NO se pierde. Para reanudar, pulsa HOME en la barra superior. ¿Continuar?"),
        ))
      )
        return;
      const r = await RRF.gcode(`M98 P"${MACROS.park}"`);
      toast(r ? t(`msg.parking`, "Aparcando…") : t(`msg.parkErr`, "Error: park.g"), r ? "info" : "err");
    });
  // C1 (FASE C): SIMULAR (M37) — botón de la quick-actions-bar.
  // NO mueve la máquina: el simulador interno de RRF 3.5 calcula el tiempo
  // estimado y lo deja en job.file.simulatedTime del object model. Leemos
  // el resultado al volver al estado READY/IDLE (no parsing de replies).
  // Válvulas: solo habilitado en IDLE/READY con archivo cargado.
  //
  // H-B (informe 2026-08-17_busca-el-monolito-rotechosjs-v2): el setInterval
  // era local al click handler, así que NO se podía limpiar desde fuera
  // (visibilitychange, nuevo click, etc.). Solo se cancelaba en 3 paths
  // internos (timeout 30s, resultado OK × 2, error en M37). El handle está
  // declarado a top-level (rotechos.js:4430) para que el listener de
  // visibilitychange (rotechos.js:2245, dentro del IIFE principal) pueda
  // cancelarlo al ocultar la pestaña.
  el = $(`btnQaSimulate`);
  if (el)
    el.addEventListener("click", async function () {
      if (machineMoveBlocked()) return;
      if (SM.current !== STATES.IDLE && SM.current !== STATES.READY) {
        toast(t(`msg.simulateBusy`, "Solo se puede simular con la máquina en LISTO/INACTIVO"), "warn");
        return;
      }
      if (!SM.loadedFile) {
        toast(t(`msg.simulateNoFile`, "Carga un archivo .gcode antes de simular"), "warn");
        return;
      }
      // Si ya había un polling en marcha (re-click del operario, hot-reload,
      // o M37 ya enviado y nunca получил respuesta), lo cancelamos antes de
      // empezar otro — sin esto, dos ciclos de 30s podrían acumularse.
      _cancelSimPolling();
      // M37 en RRF 3.5: simula el archivo cargado. Devuelve OK; el resultado
      // queda en /rr_model?key=job.file.simulatedTime (object model).
      const r = await RRF.gcode(`M37`);
      if (!r) {
        toast(t(`msg.simulateErr`, "Error al lanzar simulación"), "err");
        return;
      }
      toast(t(`msg.simulatingStarted`, "Simulando…"), "info");
      log(`M37 — Simulación iniciada`, `cmd`);
      // Poll del resultado con timeout de 30s. Cuando rrfState deja de ser
      // 'simulating' Y job.file.simulatedTime es > 0, mostramos el tiempo.
      let _ticks = 0;
      _simPollingHandle = setInterval(async () => {
        _ticks++;
        if (_ticks > 60) { // 30s @ 500ms
          _cancelSimPolling();
          toast(t(`msg.simulateTimeout`, "Simulación sin resultado tras 30s"), "warn");
          log(`M37 — timeout esperando simulatedTime`, `warn`);
          return;
        }
        const _t = await _fetchModel(`job.file.simulatedTime`, 1000).catch(() => null);
        const _v = _t && _unwrap(_t);
        if (_v && typeof _v === `number` && _v > 0 && SM.current !== STATES.SIMULATING) {
          _cancelSimPolling();
          const _ms = Math.round(_v * 1000);
          const _human = `${Math.floor(_ms / 3600000)}:${String(Math.floor(_ms / 60000) % 60).padStart(2, `0`)}:${String(Math.floor(_ms / 1000) % 60).padStart(2, `0`)}`;
          toast(t(`msg.simulateDone`, `Simulación completa: ${_human}`, { "_human": _human }), "ok");
          log(`M37 — Simulación completa: ${_human}`, "ok");
        } else if (_v && typeof _v === `object` && _v.value && SM.current !== STATES.SIMULATING) {
          // Caso alternativo: job.file.simulatedTime viene como { value: <num>, ... }
          _cancelSimPolling();
          const _ms = Math.round(_v.value * 1000);
          const _human = `${Math.floor(_ms / 3600000)}:${String(Math.floor(_ms / 60000) % 60).padStart(2, `0`)}:${String(Math.floor(_ms / 1000) % 60).padStart(2, `0`)}`;
          toast(t(`msg.simulateDone`, `Simulación completa: ${_human}`, { "_human": _human }), "ok");
          log(`M37 — Simulación completa: ${_human}`, "ok");
        }
      }, 500);
    });
  // Paro de emergencia flotante (solo visible en móvil): delega en el
  // botón DETENER real para reusar exactamente su lógica M112 / urgentGcode.
  el = $(`btnEStopFloat`);
  if (el)
    el.addEventListener("click", function () {
      $(`btnEStop`)?.click();
    });
  // Fix móvil #6 — los campos numéricos ya son type=number (teclado numérico
  // en móvil); añadir inputmode="decimal" mejora la entrada de decimales en iOS
  // sin tocar las ~100 etiquetas <input> a mano.
  $$(`input[type=number]`).forEach((inp) => {
    if (!inp.getAttribute(`inputmode`)) inp.setAttribute(`inputmode`, `decimal`);
  });
  // PARAR — parada limpia SIN reinicio: M25(pausa)+M0(cancela)+T0+M5 dispara
  // cancel.g, que sube Z, apaga husillo y re-arma triggers (recover_triggers.g).
  // No bloquea la máquina como M112. (Para cortar un homing en curso usar M112.)
  el = $(`btnSoftStop`);
  if (el)
    el.addEventListener("click", async function () {
      // 27-sep (análisis de la interfaz, M3; decisión de Sergi): pedía nada y está pegado al PARO:
      // un toque corto cancelaba el trabajo. confirmDialog (no confirmDashboard): pregunta siempre.
      if (typeof confirmDialog === `function` && !(await confirmDialog(
        t(`dlg.softStop.title`, `Abortar trabajo`),
        t(`dlg.softStop.msg`, `Se cancela el trabajo: la máquina para, sube Z y apaga el husillo. El archivo sigue en la SD. Para parar un momento, usa PAUSA; en una emergencia, el PARO.`),
        { confirmText: t(`dlg.softStop.title`, `Abortar trabajo`), cancelText: t(`dlg.softStop.cancel`, `Cancelar`) },
      ))) return;
      log(`PARAR — M25+M0+T0+M5 (parada limpia, sin reinicio)`, `warn`);
      try {
        await RRF.urgentGcode(`M25\nM0\nT0\nM5`);
        toast(t(`msg.softStopDone`, `Parada limpia ejecutada`), `info`);
      } catch {
        toast(t(`msg.softStopErr`, `Error al ejecutar la parada`), `err`);
      }
    });
  // RECUPERAR — re-arma los triggers/endstops de seguridad y limpia el flag de
  // homing huérfano, todo SIN M999. Útil tras una parada por sensor (trigger2.g)
  // o una macro abortada que dejó los sensores desactivados.
  el = $(`btnRecover`);
  if (el)
    el.addEventListener("click", async function () {
      // Guard de estado. Hasta ahora la ÚNICA protección era la frase "No lo uses
      // durante un homing en marcha" del propio diálogo: un texto, no código.
      //
      // Los dos casos NO son el mismo y por eso van separados:
      //  (a) Homing en curso — el escenario peligroso de verdad. RECUPERAR manda
      //      `set global.homingInProgress = false` + recover_triggers.g, así que
      //      rearma los triggers que homeall.g había suspendido A PROPÓSITO
      //      (M581 P0 T-1) y borra la señal de que hay un homing corriendo.
      //      OJO: el homing NO es un estado de SM — pasa estando en IDLE o READY,
      //      así que un guard que solo mire SM.current lo deja pasar entero.
      //  (b) RUNNING / PAUSED / SIMULATING — rearmar sensores con un trabajo vivo
      //      no es el bug que motivó esto, pero tampoco tiene sentido.
      if (AppState.cache.homingInProgress) {
        toast(t(`msg.recoverDuringHoming`, `Homing en marcha: espera a que termine antes de re-armar sensores`), `warn`);
        log(`REARMAR bloqueado — homing en marcha (global.homingInProgress)`, `warn`);
        return;
      }
      if (SM.current === STATES.RUNNING || SM.current === STATES.PAUSED || SM.current === STATES.SIMULATING) {
        toast(t(`msg.notReady`, `Acción bloqueada: la máquina no está en estado LISTO (no acepta comandos). Espera a que termine el trabajo actual o pulsa STOP en la barra superior. Si la máquina lleva varios minutos quieta y sigue en PAUSADA, pulsa REANUDAR.`), `warn`);
        log(`REARMAR bloqueado — estado ${SM.current}`, `warn`);
        return;
      }
      if (
        !(await confirmDashboard(
          t(`dlg.recoverSensors.title`, `Re-armar sensores`),
          t(`dlg.recoverSensors.msg`, `Re-armar los sensores de seguridad y limpiar el estado de homing. NO reinicia el firmware (no es M999). Solo pulsa esto si acabas de pulsar STOP durante un homing o un trigger2 (emergencia) te dejó los sensores desactivados. NO lo pulses durante un homing en marcha — desactivaría la protección a mitad del movimiento.`),
        ))
      )
        return;
      log(`REARMAR — recover_triggers.g + limpiar homingInProgress`, `cmd`);
      const ok = await RRF.gcode(
        `set global.homingInProgress = false\nM98 P"0:/sys/recover_triggers.g"`,
      );
      toast(
        ok ? t(`msg.sensorsRearmed`, `Sensores de seguridad re-armados (no M999)`) : t(`msg.sensorsErr`, `Error al re-armar sensores`),
        ok ? `ok` : `err`,
      );
    });
})();

// ── PARO flotante (móvil): Unificado de forma universal. Se mantiene
//    permanentemente visible y fijo abajo a la izquierda para garantizar la
//    máxima seguridad física del operario, evitando ocultamientos tácticos
//    o saltos de posición durante la navegación. ──
(function () {
  const float = $("btnEStopFloat");
  if (!float) return;
  // El botón permanece visible y en su posición fija abajo a la izquierda de forma universal.
  // Nos aseguramos de quitar cualquier clase residual que pudiera haber sido inyectada.
  float.classList.remove("float-hidden", "float-left");
})();

// En pantalla, el nombre sin la ruta de la SD; la ruta entera va en el title.
function _nombreSinRuta(p) {
  return String(p || ``).replace(/^.*[\\/]/, ``);
}

// ── PENDANT Screen Router ────────────────────────────────────────────
window.PENDANT = {
  current: "dash",
  history: [],
  go(id, push) {
    // N-2: un id sin pantalla las apagaba todas (UI en blanco).
    if (!document.querySelector(`#mpgView [data-pendant-screen="${id}"]`)) return;
    if (push !== false) this.history.push(this.current);
    document
      .querySelectorAll("#mpgView .pendant-screen")
      .forEach((s) =>
        s.classList.toggle("pendant-screen-active", s.dataset.pendantScreen === id),
      );
    // Sincronizar la barra de navegación inferior con la pantalla activa
    document
      .querySelectorAll(".main-nav-bar .nav-item")
      .forEach((el) => el.classList.toggle("active", el.dataset.nav === id));
    this.current = id;
    // Cargar lista de archivos al entrar en pantalla files
    if (id === "files") window["pendantLoadFiles"] && window["pendantLoadFiles"]();
    // Cargar macros al entrar en pantalla macros
    if (id === "macros") window["pendantLoadMacros"] && window["pendantLoadMacros"]();
  },
  back() {
    const prev = this.history.pop() || "dash";
    this.go(prev, false);
  },
};

// ── PENDANT Screen Functions ─────────────────────────────────────────

// Spindle target en pantalla spindle
let _pendantSpTarget = 12000;
// eslint-disable-next-line no-unused-vars -- usado por pendantSetSpTarget fuera de este módulo (index.html:2155-2158,2163,2492 (oninput + data-act + dispatcher))
function pendantSetSpTarget(rpm) {
  // Acotado al rango REAL del husillo. Sin esto, un preset de 24 000 en una
  // maquina con husillo de 12 000 dejaba el slider y la cifra objetivo en
  // 24 000: el firmware lo recortaria al arrancar, pero la pantalla mentia.
  const lo = Number.isFinite(CFG.spindleMin) ? CFG.spindleMin : 0;
  const hi = Number.isFinite(CFG.maxRPM) ? CFG.maxRPM : rpm;
  _pendantSpTarget = Math.min(Math.max(rpm, lo), hi);
  const el = $(`pendant2SpTarget`);
  const sl = $(`pendant2SpSlider`);
  if (el) el.textContent = String(_pendantSpTarget); // sin separador, como el resto de RPM
  if (sl) sl.value = _pendantSpTarget;
}

/** Adapta los textos de "RPM" del cockpit y del pendant al modo de cabezal
 *  activo. En modo "laser" la cifra deja de ser RPM y pasa a ser porcentaje
 *  de potencia del diodo láser (0–100). El slider del pendant pasa a step=1
 *  y max=100 para que los presets tengan sentido (los presets RPM de fábrica
 *  se distribuyen dentro del rango; con láser se reescalan 0/25/50/75/100).
 *  Invocado desde updateSpindleModeCards (al cambiar el radio) y desde
 *  cfgPopulate cuando se re-puebla tras un cambio persistido. (t_028bceef) */
function syncSpindleLabelsToMode() {
  const mode = (typeof CFG !== `undefined` && CFG.spindleMode) || `pwm`;
  const isLaser = mode === `laser`;
  const unit = isLaser ? `%` : `RPM`;
  // Cockpit — etiqueta principal y unidad del máximo
  const cockpitLbl = $(`cockpitSpindleLabel`);
  if (cockpitLbl) {
    cockpitLbl.innerHTML = isLaser
      ? `<svg viewbox="0 0 24 24" fill=none height=11 stroke=currentColor stroke-linecap=round stroke-linejoin=round stroke-width=2.5 width=11 aria-hidden="true" focusable="false"><path d="M3 3h7v7H3zM14 3h7v7h-7zM14 14h7v7h-7zM3 14h7v7H3z"/></svg> ${t(`div.spindle-power`, `Potencia del láser`)}`
      : `<svg viewbox="0 0 24 24" fill=none height=11 stroke=currentColor stroke-linecap=round stroke-linejoin=round stroke-width=2.5 width=11 aria-hidden="true" focusable="false"><circle cx=12 cy=12 r=3 /><path d="M19.07 4.93a10 10 0 0 1 0 14.14"/><path d="M4.93 4.93a10 10 0 0 0 0 14.14"/></svg> ${t(`div.spindle-rpm-c6a7`, `RPM del husillo`)}`;
  }
  const sMax = $(`sMax`);
  if (sMax) {
    // En láser, el "max" siempre es 100% (no CFG.maxRPM del laser=100).
    // El render del poll ya actualiza sMax con la cifra correcta en cada
    // vuelta; aquí solo forzamos el caso láser para que la primera vuelta
    // no muestre "— RPM · máx." en cockpit.
    const _isConn = typeof SM !== `undefined` && SM.connected;
    if (_isConn && isLaser) sMax.textContent = `100 % · ${t(`work.maxAbbr`, `máx.`)}`;
    // Si no es láser, deja que el render del poll lo reescriba en su próxima vuelta.
  }
  // Pendant — etiqueta grande + unidad del objetivo
  const pendantLbl = $(`pendant2SpBigLbl`);
  if (pendantLbl) pendantLbl.textContent = isLaser
    ? t(`pendant.sp.power.lbl`, `POTENCIA ACTUAL`)
    : t(`pendant.sp.rpm.lbl`, `RPM ACTUALES`);
  const pendantUnit = $(`pendant2SpUnit`);
  if (pendantUnit) pendantUnit.textContent = unit;
  // Slider pendant — límites 0-100 step=1 si es láser; si no, el rango real del husillo (lo gestiona syncSpindleRangeUI)
  if (isLaser) {
    const sl = $(`pendant2SpSlider`);
    if (sl) {
      sl.min = 0; sl.max = 100; sl.step = 1;
      const lbls = document.querySelectorAll(`.pendant2-sp-range-lbl`);
      if (lbls.length === 2) { lbls[0].textContent = `0`; lbls[1].textContent = `100`; }
      // Presets láser 0/25/50/75/100
      const presets = document.querySelectorAll(`.pendant2-sp-preset`);
      presets.forEach((btn, i) => {
        const v = [0, 25, 50, 75, 100][i] ?? 0;
        btn.textContent = `${v}%`;
        btn.disabled = false;
        btn.dataset.act = `helpers.pendantSetSpTarget(${v})`;
      });
    }
  } else {
    // Cualquier modo no-láser: que syncSpindleRangeUI repueble con el rango real.
    syncSpindleRangeUI();
  }
}

/** Pone en la UI del pendant el rango de husillo que publica el firmware.
 *  El HTML traia 6 000 y 24 000 escritos a mano en el slider, en sus dos
 *  etiquetas y en los cuatro presets: cifras de ESTA maquina presentadas como
 *  si valieran para cualquiera. Se llama desde el render, que es donde CFG se
 *  actualiza con lo que dice `spindles[]`. */
function syncSpindleRangeUI() {
  const lo = Number.isFinite(CFG.spindleMin) ? CFG.spindleMin : 0;
  const hi = Number.isFinite(CFG.maxRPM) ? CFG.maxRPM : 0;
  if (!(hi > lo)) return;
  // SIN separador, a proposito: `toLocaleString('es-ES')` NO agrupa a cuatro
  // digitos (`minimumGroupingDigits:2` del idioma) y la fila salia mezclada
  // —6000 / 12.000 / 18.000 / 24.000—, reproducido en navegador. Se quita la
  // agrupacion en vez de forzarla: asi ningun boton se ensancha (el texto mas
  // largo baja de 47,1 a 43,5 px) y es como se teclea en CONFIGURACION.
  const fmt = (v) => String(Math.round(v));
  const sl = $(`pendant2SpSlider`);
  if (sl && (+sl.min !== lo || +sl.max !== hi)) {
    sl.min = lo; sl.max = hi;
    sl.step = Math.max(100, Math.round((hi - lo) / 36 / 100) * 100);
    if (+sl.value < lo || +sl.value > hi) pendantSetSpTarget((lo + hi) / 2);
  }
  if (sl) {
    sl.disabled = false;
    const rango = `${fmt(lo)}-${fmt(hi)} RPM`;
    sl.setAttribute(`aria-label`, `${t(`aria.pendant.spindle.rpm`, `RPM objetivo del husillo en el pendant`)} (${rango})`);
    sl.setAttribute(`title`, `${t(`title.pendant.spindle.rpm`, `RPM objetivo del husillo en el pendant`)} (${rango})`);
  }
  const lbls = document.querySelectorAll(`.pendant2-sp-range-lbl`);
  if (lbls.length === 2) { lbls[0].textContent = fmt(lo); lbls[1].textContent = fmt(hi); }
  // Presets repartidos dentro del rango real, no cifras fijas.
  const presets = document.querySelectorAll(`.pendant2-sp-preset`);
  if (presets.length) {
    const n = presets.length;
    presets.forEach((btn, i) => {
      const v = Math.round((lo + ((hi - lo) * i) / (n - 1)) / 100) * 100;
      const txt = fmt(v);
      btn.disabled = false;
      if (btn.textContent.trim() !== txt) {
        btn.textContent = txt;
        btn.setAttribute(`data-act`, `helpers.pendantSetSpTarget(${v})`);
      }
    });
  }
  const on = document.querySelector(`.pendant2-sp-on`);
  if (on) on.disabled = false;
}

/** Sincroniza el area visible del visor con los limites reales de los ejes. */
// eslint-disable-next-line no-unused-vars -- lo usa rotechos-telemetry.js
function syncMachineLimitsUI() {
  const span = (axis) => {
    const min = Number(_softLimits?.[axis]?.min);
    const max = Number(_softLimits?.[axis]?.max);
    return Number.isFinite(min) && Number.isFinite(max) && max > min ? max - min : null;
  };
  const x = span(`X`), y = span(`Y`);
  if (!(x > 0 && y > 0)) return;
  if (window.VIZ) window.VIZ.workLimits = { x, y };
  const label = $(`viz3dGridLabel`);
  if (label) {
    const fmt = (v) => Math.round(v).toLocaleString(`es-ES`);
    label.textContent = `${t(`cfg.viz3d.show.grid`, `Rejilla del área de la máquina`)} (${fmt(x)}×${fmt(y)} mm)`;
  }
}

// Cargar lista de archivos para pantalla files
// UI-3 fix Codex validación cruzada 2026-07-07: input búsqueda + sort columnas
window.__pendant2Files = [];
window.__pendant2FilesHandler = null;
window.pendantLoadFiles = async function () {
  const listEl = $(`pendant2FileList`);
  const countEl = $(`pendant2FilesCount`);
  if (!listEl) return;
  listEl.innerHTML = "<div class=pendant2-file-empty>Cargando…</div>";
  try {
    // D-03: sin escudo, un 401 de RRF salia como «Error al leer archivos» y el
    // PIN no se pedia nunca por esta ruta. El toast del guard dice el motivo.
    if (!await window.rotechosShieldMsg.guard(TARGET_IP, `pendantLoadFiles`)) throw new Error(`escudo`);
    const data = await _fileList(`0:/gcodes`, 5000);
    const files = (data.files || []).filter(
      (f) => f.type === "f" && /\.(gcode|g|nc|cnc|tap)$/i.test(f.name),
    );
    window.__pendant2Files = files;
    if (countEl) countEl.textContent = `${files.length} ${t(`pendant2.filesCount`, `archivos`)}`;
    if (!files.length) {
      listEl.innerHTML =
        `<div class="pendant2-file-empty">${t('pendant2.noGcode', 'Sin archivos G-code en la SD')}</div>`;
      return;
    }
    // Filtro/sort en tiempo real. Llamamos al handler centralizado para que
    // input búsqueda y select sort lo invoquen tras cambios.
    window.pendantFilterFiles();
    // Inicializar listeners de filtro y sort la primera vez
    if (!window.__pendant2FilesHandler) {
      window.__pendant2FilesHandler = true;
      const searchEl = $(`pendant2FileSearch`);
      const sortEl = $(`pendant2FileSort`);
      if (searchEl) searchEl.addEventListener(`input`, () => window.pendantFilterFiles());
      if (sortEl) sortEl.addEventListener(`change`, () => window.pendantFilterFiles());
    }
  } catch (e) {
    listEl.innerHTML =
      "<div class=\"pendant2-file-empty error-alert\"><svg viewBox=\"0 0 24 24\" fill=\"none\" height=\"16\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-width=\"2.5\" width=\"16\"><circle cx=\"12\" cy=\"12\" r=\"10\"/><line x1=\"12\" x2=\"12\" y1=\"8\" y2=\"12\"/><line x1=\"12\" x2=\"12.01\" y1=\"16\" y2=\"16\"/></svg> Error al leer archivos</div>";
  }
};

// Renderiza la lista aplicando filtro + sort actuales
window.pendantFilterFiles = function () {
  const listEl = $(`pendant2FileList`);
  const countEl = $(`pendant2FilesCount`);
  if (!listEl) return;
  let files = window.__pendant2Files || [];
  const q = ($(`pendant2FileSearch`)?.value || ``).trim().toLowerCase();
  if (q) files = files.filter(f => f.name.toLowerCase().includes(q));
  const sortVal = $(`pendant2FileSort`)?.value || `name-asc`;
  files = [...files].sort((a, b) => {
    switch (sortVal) {
      case `name-desc`: return b.name.localeCompare(a.name);
      case `size-desc`: return (b.size||0) - (a.size||0);
      case `size-asc`:  return (a.size||0) - (b.size||0);
      default:          return a.name.localeCompare(b.name);
    }
  });
  if (countEl) countEl.textContent = `${files.length} ${t(`pendant2.filesCount`, `archivos`)}`;
  if (!files.length) {
    listEl.innerHTML = `<div class="pendant2-file-empty">${q ? t(`pendant2.noResults`, `Sin resultados`) : t(`pendant2.noGcode`, `Sin archivos G-code en la SD`)}</div>`;
    return;
  }
  listEl.innerHTML = "";
  files.forEach((f) => {
    const row = document.createElement("div");
    row.className = "pendant2-file-row";
    row.innerHTML =
      `<svg viewbox="0 0 24 24" fill=none height=18 stroke=currentColor stroke-linecap=round stroke-linejoin=round stroke-width=2 width=18><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>` +
      `<div class=pendant2-file-info>` +
      `<span class=pendant2-file-name title="${escHtml(f.name)}">${escHtml(f.name)}</span>` +
      `<span class=pendant2-file-size>${f.size ? (f.size / 1024 / 1024).toFixed(1) + " MB" : ""}</span>` +
      `</div>` +
      `<button class="pendant2-file-load-btn">&#9654; CARGAR</button>`;
    const load = () => pendantLoadFile(f.name);
    row.addEventListener("click", load);
    row.querySelector(".pendant2-file-load-btn").addEventListener("click", (e) => {
      e.stopPropagation();
      load();
    });
    listEl.appendChild(row);
  });
};

async function pendantLoadFile(filename) {
  if (machineMoveBlocked(true)) return;
  toast(t(`msg.cargandoFilename`, "Cargando " + filename + "…"), "info");
  let gcode = null;
  try {
    gcode = await FM.download(filename);
  } catch {}
  await loadFile(filename, gcode);
  window.PENDANT && PENDANT.go("run");
}

// Cargar lista de macros
let _pendantMacros = [];
window.pendantLoadMacros = async function () {
  const listEl = $(`pendant2MacroList`);
  if (!listEl) return;
  try {
    // D-03: mismo escudo que pendantLoadFiles — ver el comentario de alli.
    if (!await window.rotechosShieldMsg.guard(TARGET_IP, `pendantLoadMacros`)) throw new Error(`escudo`);
    const data = await _fileList(`0:/macros`, 5000);
    // Ocultar macros de SISTEMA: el firmware decide el modo cinemático (SEDA/RAYO) y
    // el anti-chatter; el usuario NO debe ejecutarlos a mano (rompería el estado
    // auto-gestionado). Se siguen llamando internamente desde el firmware/daemon.
    // RegExp robusta: acepta nombre simple ("vssc.g") o con prefijo path tipo
    // "0:/macros/vssc.g" — ancla ^ y $ siguen activas.
    // NOTA: set_silk.g / set_pro.g ya NO están en 0:/macros/ (shims retirados
    // 2026-08-17, F2 del informe busca-firmware-g-y-macros-de-sys-v1) — viven
    // SOLO en 0:/sys/. Se conservan en la regex como defensa por si alguien
    // los vuelve a copiar.
    const HIDDEN_MACROS = /^(?:.*\/)?(?:set_silk|set_pro|vssc|spindle_warmup)\.g$/i;
    _pendantMacros = (data.files || [])
      .filter((f) => f.type === "f" && /\.g$/i.test(f.name) && !HIDDEN_MACROS.test(f.name))
      .map((f) => f.name);
    pendantRenderMacros();
  } catch {
    listEl.innerHTML =
      "<div class=\"pendant2-macro-empty error-alert\"><svg viewBox=\"0 0 24 24\" fill=\"none\" height=\"16\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-width=\"2.5\" width=\"16\"><circle cx=\"12\" cy=\"12\" r=\"10\"/><line x1=\"12\" x2=\"12\" y1=\"8\" y2=\"12\"/><line x1=\"12\" x2=\"12.01\" y1=\"16\" y2=\"16\"/></svg> Error al leer macros</div>";
  }
};
function pendantRenderMacros() {
  const listEl = $(`pendant2MacroList`);
  if (!listEl) return;
  // Lista deslizable: se renderizan TODAS las macros y .pendant2-macro-list
  // (flex:1 + overflow-y:auto) se desliza en vertical. Sin paginación ANT/SIG.
  if (!_pendantMacros.length) {
    listEl.innerHTML = `<div class=pendant2-macro-empty>${t(`pendant.macros.empty`, `Sin macros`)}</div>`;
    return;
  }
  // Auditoría UI 2026-07-18 (FIX XSS-1): event delegation en el contenedor.
  // Antes había `onclick="pendantExecMacro('${escHtml(m)}')"` inline: aunque
  // escHtml() escapa `'` como &#39;, el navegador DECODIFICA entidades antes
  // de evaluar el onclick → una macro con nombre malicioso (test'-alert(1)-')
  // rompía el string y ejecutaba JS arbitrario. Ahora el handler se ata UNA
  // vez al contenedor y lee data-macro (que sigue escapado, pero ya no se
  // interpreta como código).
  if (!listEl.dataset.macroWired) {
    listEl.dataset.macroWired = "1";
    listEl.addEventListener(`click`, (ev) => {
      const row = ev.target.closest(`.pendant2-macro-row[data-macro]`);
      if (!row || !listEl.contains(row)) return;
      pendantExecMacro(row.dataset.macro);
    });
  }
  // R-02 (2026-08-30): el icono ⚠ de esta lista usaba su PROPIA lista blanca,
  // la mas corta de las cuatro — omitia `park`, `coreografia` y `spindle_warmup`.
  // Resultado: filas que mueven la maquina (o arrancan el husillo) se pintaban
  // sin aviso mientras `pendantExecMacro` si las confirmaba. El icono mentia
  // por omision. Ahora usa el mismo SSOT que la confirmacion, asi que aviso y
  // pregunta dicen lo mismo: todo mueve la maquina salvo vssc.g, que es la
  // unica pensada para usarse EN MARCHA y se queda sin marca a proposito.
  const dangerous = { test: (n) => macroNecesitaConfirmacion(n) };
  listEl.innerHTML = _pendantMacros
    .map(
      (m) => `
    <div class=pendant2-macro-row data-macro="${escHtml(m)}">
      <svg viewbox="0 0 24 24" fill=none height=14 stroke=currentColor stroke-linecap=round stroke-linejoin=round stroke-width=2.5 width=14><polygon points="5 3 19 12 5 21 5 3"/></svg>
      <span class=pendant2-macro-name title="${escHtml(m)}">${escHtml(m)}</span>
      ${dangerous.test(m) ? '<svg class=pendant2-macro-warn viewbox="0 0 24 24" fill=none height=13 width=13 stroke=currentColor stroke-width=2.5 stroke-linecap=round stroke-linejoin=round><path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1=12 y1=9 x2=12 y2=13/><line x1=12 y1=17 x2=12.01 y2=17/></svg>' : ""}
    </div>`,
    )
    .join("");
}
async function pendantExecMacro(name) {
  // En RUNNING solo vssc (anti-chatter en marcha); el resto, pausa primero
  if (!/vssc/i.test(name) && machineMoveBlocked()) return;
  // K-COB-01 (t_752b8b07, 2026-08-12): la lista "TODAS LAS MACROS (0:/macros/)"
  // del pendant2 (index.html:2239-2242 "#pendant2MacroList") ejecutaba cada
  // M98 sin pedir confirmacion, EXCEPTO si el nombre casuaba con una whitelist
  // (bordeador|sonda|probe|goto|home|park|coreografia). Cualquier otra macro
  // (p.ej. "coreografia" si no se ajustase la regex, o macros del usuario que
  // el operario no reconoce) entraba a la maquina en frio. El briefing pide
  // el MISMO patron que ya usa el cockpit (rotechos-macros.js:155) y el modal
  // del pendant (rotechos-pendant.js:55): confirmDialog SIEMPRE, sin whitelist
  // — la lista solo conoce nombres de archivo, no lo que hace la macro. El
  // texto dice QUE va a pasar (moverá la máquina) y el nombre del archivo,
  // no solo "¿estás seguro?".
  const ok = await confirmDialog(
    t(`dlg.macroPendant.title`, "Ejecutar macro"),
    `<strong>${escHtml(name)}</strong><br>` +
      t(`dlg.macroRun.will`, "Moverá la máquina") +
      `.<br>${t(`dlg.macroRun.cont`, "¿Continuar?")}`,
  );
  if (!ok) return;
  RRF.gcode(`M98 P"0:/macros/${name}"`);
  toast(t(`msg.executingMacro`, "Ejecutando ") + name, "ok");
}
// Paginación ANT/SIG retirada: la lista de macros ahora se desliza en vertical.

// MÓDULO: SPINDLE OVERRIDE PENDANT2 → extraído a rotechos-spindle.js (PR #4)

// ---
// MÓDULO 1 — VISUALIZADOR G-CODE 3D (parser + estadísticas + avisos)
// ---
const VIZ3D = (function () {
  const DEFAULT_PREFS = { opG0: 30, opG1: 100, showTool: true, showBBox: true, showGrid: true, cG1: "#10b981", cG0: "#f59e0b", cArc: "#0088cc" };
  let prefs = { ...DEFAULT_PREFS };
  let initialized = false;
  function loadPrefs() {
    const saved = STORE.get(`viz3d.prefs`);
    if (saved && typeof saved === "object") prefs = { ...DEFAULT_PREFS, ...saved };
  }
  function savePrefs() {
    if (!$(`viz3dOpG0`)) return;
    prefs = {
      opG0: Number($(`viz3dOpG0`).value), opG1: Number($(`viz3dOpG1`).value),
      showTool: $(`viz3dShowTool`).checked, showBBox: $(`viz3dShowBBox`).checked, showGrid: $(`viz3dShowGrid`).checked,
      cG1: $(`viz3dColorG1`).value, cG0: $(`viz3dColorG0`).value, cArc: $(`viz3dColorArc`).value,
    };
    STORE.set(`viz3d.prefs`, prefs);
  }
  function restorePrefs() {
    if (!($("viz3dOpG0"))) return;
    $("viz3dOpG0").value = prefs.opG0; $("viz3dOpG1").value = prefs.opG1;
    // UI-6: sincroniza la lectura visible del slider con el valor restaurado
    // desde localStorage. Sin esto, el numero a la derecha del track se
    // queda en "30" / "100" hardcodeados en el HTML aunque las prefs digan
    // otra cosa.
    const og = $("viz3dOpG0Val"); if (og) og.textContent = String(prefs.opG0);
    const og1 = $("viz3dOpG1Val"); if (og1) og1.textContent = String(prefs.opG1);
    $("viz3dShowTool").checked = prefs.showTool; $("viz3dShowBBox").checked = prefs.showBBox; $("viz3dShowGrid").checked = prefs.showGrid;
    $("viz3dColorG1").value = prefs.cG1; $("viz3dColorG0").value = prefs.cG0; $("viz3dColorArc").value = prefs.cArc;
  }
  function fmtTime(seconds) {
    if (!isFinite(seconds) || seconds <= 0) return "—";
    const h = Math.floor(seconds / 3600), m = Math.floor((seconds % 3600) / 60), s = Math.floor(seconds % 60);
    return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
  }
  // Parser asíncrono por chunks — no congela la UI con archivos grandes.
  // Procesa CHUNK_SIZE líneas síncronamente, luego cede al event loop con setTimeout(0).
  async function parseGcode(text, onProgress) {
    const lines = text.split(/\r?\n/);
    const total = lines.length;
    const CHUNK_SIZE = 5000;
    let x = 0, y = 0, z = 0, distG0 = 0, distG1 = 0, timeEst = 0;
    let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity, minZ = Infinity, maxZ = -Infinity;
    let zPositive = false, lineCount = 0, lastF = 1000;
    for (let start = 0; start < total; start += CHUNK_SIZE) {
      const end = Math.min(start + CHUNK_SIZE, total);
      for (let i = start; i < end; i++) {
        const raw = lines[i];
        lineCount++;
        const l = raw.split(";")[0].trim().toUpperCase();
        if (!l) continue;
        const isG0 = /^G0\b|^G00\b/.test(l), isG1 = /^G1\b|^G01\b/.test(l);
        if (!isG0 && !isG1) continue;
        const mF = l.match(/F([-\d.]+)/); if (mF) lastF = parseFloat(mF[1]) || lastF;
        const mX = l.match(/X([-\d.]+)/), mY = l.match(/Y([-\d.]+)/), mZ = l.match(/Z([-\d.]+)/);
        const nx = mX ? parseFloat(mX[1]) : x, ny = mY ? parseFloat(mY[1]) : y, nz = mZ ? parseFloat(mZ[1]) : z;
        const dx = nx - x, dy = ny - y, dz = nz - z, d = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (d > 0 && lastF > 0) { isG0 ? (distG0 += d) : (distG1 += d); timeEst += (d / lastF) * 60; }
        x = nx; y = ny; z = nz;
        if (mX) { minX = Math.min(minX, x); maxX = Math.max(maxX, x); }
        if (mY) { minY = Math.min(minY, y); maxY = Math.max(maxY, y); }
        if (mZ) { minZ = Math.min(minZ, z); maxZ = Math.max(maxZ, z); if (z > 0.001) zPositive = true; }
      }
      // Cede al event loop para que la UI siga respondiendo
      if (typeof onProgress === "function") onProgress(end, total);
      if (end < total) await new Promise(r => setTimeout(r, 0));
    }
    return { distG0, distG1, timeEst, minX, maxX, minY, maxY, minZ, maxZ, zPositive, lineCount };
  }
  function renderStats(s) {
    if (!$("viz3dStatLen")) return;
    // UI-6 (t_f94b5645): al renderizar estadisticas reales, oculta el placeholder
    // "Carga un archivo para ver las estadisticas" (#viz3dStatEmpty). Antes el
    // guion largo "—" se mostraba SIEMPRE encima de los valores nuevos, lo que
    // llevaba al operario a pensar que la app no habia reaccionado.
    const empty = $("viz3dStatEmpty");
    if (empty) empty.style.display = "none";
    $("viz3dStatLen").textContent = (s.distG1 / 1000).toFixed(2) + " m";
    $("viz3dStatRapid").textContent = (s.distG0 / 1000).toFixed(2) + " m";
    $("viz3dStatZ").textContent = isFinite(s.minZ) ? `${s.minZ.toFixed(2)} / ${s.maxZ.toFixed(2)} mm` : "—";
    $("viz3dStatArea").textContent = isFinite(s.minX) ? `${(s.maxX - s.minX).toFixed(1)} × ${(s.maxY - s.minY).toFixed(1)} mm` : "—";
    $("viz3dStatTime").textContent = fmtTime(s.timeEst);
    $("viz3dStatLines").textContent = s.lineCount.toLocaleString();
    const w = $("viz3dWarnings"); w.innerHTML = "";
    const warn = (msg, color) => `<div style="padding:8px 12px;border-radius:6px;border:1px solid ${color};background:${color}22;color:${color};font-size:11px;font-weight:700;margin-top:6px">${msg}</div>`;
    if (s.zPositive) {
      // Mantenido como aviso separado: cubre movimientos a Z>0 intermedios
      // (p.ej. un G0 de retirada) aunque el bounding box no los incluya.
      // El chequeo del bounding box (mZmax > Z.max) está más abajo y usa
      // coord_maquina = coord_fichero + wcsOffset como el resto.
      w.innerHTML += warn(t(`viz3d.warn.zPositive`, `PELIGRO: el archivo contiene movimientos a Z positivo. Z máximo seguro = 0. (Z0 es el punto más alto — por encima el cabezal entra en el husillo.) Abre el G-code y elimina cualquier Z > 0 antes de mecanizar.`), "var(--red)");
    }
    if (isFinite(s.minX)) {
      // ── Chequeo previo CON OFFSET DE PIEZA (t_717c48cc, jul-2026) ──
      // Los soft limits vienen en MCS (move.axes[n].max/min, M208) y el
      // fichero está en WCS (coordenadas que vio el CAM). Si el operario
      // puso el cero de pieza en X=300, un fichero que va de X0 a X300
      // termina en X600 en la máquina — el chequeo viejo lo daba VERDE.
      // Convertir SIEMPRE: coord_maquina = coord_fichero + wcsOffset.
      // _wcsOffsets viene de `workplaceOffsets[move.workplaceNumber]` (rotechos-poll.js, WCS activo),
      // mismo dato que usa el DRO para mostrar la posición en WCS.
      // Límites DINÁMICOS desde el área real (M208 vía _softLimits), no hardcodeados.
      // Sin limites del object model no inventamos el recorrido de otra maquina.
      // El chequeo se activa en cuanto el primer sondeo aporta min/max reales.
      const limX = _softLimits?.X?.max, limY = _softLimits?.Y?.max, limZ = _softLimits?.Z?.min;
      const oX = _wcsOffsets?.X ?? 0, oY = _wcsOffsets?.Y ?? 0, oZ = _wcsOffsets?.Z ?? 0;
      const mXmin = s.minX + oX, mXmax = s.maxX + oX;
      const mYmin = s.minY + oY, mYmax = s.maxY + oY;
      const mZmin = s.minZ + oZ, mZmax = s.maxZ + oZ;
      // No-origin: si el operario NO ha fijado cero de pieza, los offsets
      // están a 0 y el fichero se ejecuta contra el cero de MÁQUINA. La
      // trampa clásica de quien empieza (dlg.noOrigin, rotechos.js:2214-2219)
      // avisa al pulsar START, pero el chequeo previo al cargar debe mostrar
      // AMBOS números también en este caso — "el fichero va de X0 a X300,
      // sin cero de pieza eso es la esquina de la máquina" — para que el
      // operario vea de dónde sale el número antes de pulsar START.
      const noOrigin = (Math.abs(oX) < 0.001 && Math.abs(oY) < 0.001 && Math.abs(oZ) < 0.001);
      const oXLbl = noOrigin ? "0 (sin cero de pieza)" : oX.toFixed(1);
      const oYLbl = noOrigin ? "0 (sin cero de pieza)" : oY.toFixed(1);
      const oZLbl = noOrigin ? "0 (sin cero de pieza)" : oZ.toFixed(1);
      if (s.minX < 0 || s.minY < 0) {
        // En coords de fichero X<0 ya es raro (un CAM asume origen en la
        // esquina de la pieza). Mostrar el aviso en máquina para coherencia.
        const parts = [];
        if (s.minX < 0) parts.push(`X=${s.minX.toFixed(0)} (máquina ${mXmin.toFixed(0)})`);
        if (s.minY < 0) parts.push(`Y=${s.minY.toFixed(0)} (máquina ${mYmin.toFixed(0)})`);
        w.innerHTML += warn(`El trabajo tiene coordenadas negativas: ${parts.join(", ")}. Sin cero de pieza se ejecuta contra la esquina de la máquina.`, "var(--warn-strong)");
      }
      if ((Number.isFinite(limX) && mXmax > limX) || (Number.isFinite(limY) && mYmax > limY)) {
        const parts = [];
        if (mXmax > limX) parts.push(`X=${mXmax.toFixed(0)} mm (fichero ${s.maxX.toFixed(0)} + cero en X=${oXLbl}; recorrido ${limX.toFixed(0)})`);
        if (mYmax > limY) parts.push(`Y=${mYmax.toFixed(0)} mm (fichero ${s.maxY.toFixed(0)} + cero en Y=${oYLbl}; recorrido ${limY.toFixed(0)})`);
        w.innerHTML += warn(`El trabajo excede el área: ${parts.join("; ")}.`, "var(--red)");
      }
      if (Number.isFinite(limZ) && mZmin < limZ) {
        w.innerHTML += warn(`Z mínimo en máquina = ${mZmin.toFixed(2)} mm (fichero ${s.minZ.toFixed(2)} + cero en Z=${oZLbl}); tu recorrido es ${limZ.toFixed(0)} mm.`, "var(--red)");
      }
      if (Number.isFinite(_softLimits?.Z?.max) && mZmax > _softLimits.Z.max) {
        w.innerHTML += warn(`Z positivo en máquina = ${mZmax.toFixed(2)} mm (fichero ${s.maxZ.toFixed(2)} + cero en Z=${oZLbl}); Z seguro = 0.`, "var(--red)");
      }
    }
  }
  function bindEvents() {
    // UI-6 (t_f94b5645): el antiguo boton "Elegir archivo…" desaparecio.
    // Ahora el dropzone (#viz3dDrop) es el disparador visual — al hacer clic
    // (o al pulsar Enter/Espacio por teclado, como cualquier role=button)
    // abre el file picker nativo, y arrastrar un fichero sobre la zona
    // tambien lo carga. Patron reutilizado de OTA (#otaDropZone) sin
    // reinventarlo.
    const drop = $("viz3dDrop");
    if (drop) {
      drop.addEventListener("click", (e) => {
        if (e.target.closest("input[type=file]")) return; // por si el drop se solapa con el input
        $("viz3dFile")?.click();
      });
      drop.addEventListener("keydown", (e) => {
        if (e.key === "Enter" || e.key === " ") { e.preventDefault(); $("viz3dFile")?.click(); }
      });
    }
    $("viz3dFile")?.addEventListener("change", (e) => {
      const file = e.target.files?.[0];
      if (!file) return;
      $("viz3dFileName").textContent = `${file.name} — ${(file.size / 1024).toFixed(1)} KB`;
      const reader = new FileReader();
      reader.onload = async (ev) => {
        try {
          const nameEl = $(`viz3dFileName`);
          if (nameEl) nameEl.textContent = `${file.name} — analizando…`;
          const stats = await parseGcode(String(ev.target.result), (done, total) => {
            if (nameEl) nameEl.textContent = `${file.name} — ${Math.round((done / total) * 100)}%`;
          });
          if (nameEl) nameEl.textContent = `${file.name} — ${(file.size / 1024).toFixed(1)} KB`;
          renderStats(stats);
          log(`G-code analizado: ${file.name} — ${(stats.distG1 / 1000).toFixed(1)}m corte, ${fmtTime(stats.timeEst)}`, "info");
          toast(t(`msg.análisisCompletado`, `Análisis completado`), "ok");
        }
        catch (err) { LOG.error(err); toast(t(`msg.errorAlAnalizarGcode`, `Error al analizar G-code`), "err"); }
      };
      reader.readAsText(file);
    });
    // UI-6: muestra el valor del slider en vivo a la derecha del track.
    // Sin esto el operario no sabe qué número está mandando al render.
    const syncSlider = (id, valId) => {
      const el = $(id), v = $(valId);
      if (!el || !v) return;
      v.textContent = el.value;
      el.addEventListener("input", () => { v.textContent = el.value; savePrefs(); });
    };
    syncSlider("viz3dOpG0", "viz3dOpG0Val");
    syncSlider("viz3dOpG1", "viz3dOpG1Val");
    ["viz3dShowTool", "viz3dShowBBox", "viz3dShowGrid", "viz3dColorG1", "viz3dColorG0", "viz3dColorArc"].forEach((id) => $(id)?.addEventListener("change", savePrefs));
  }
  return {
    onShow() { if (!initialized) { loadPrefs(); bindEvents(); restorePrefs(); initialized = true; } },
  };
})();
window.VIZ3D = VIZ3D;


// ---
// MÓDULO 4 — TECLADO Y ATAJOS (reasignación + persistencia localStorage)
// ---
const KBSHORTCUTS = (function () {
  // Las flechas y PageUp/PageDown son RESERVADAS (jog ya las maneja en el handler existente)
  const RESERVED = ["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight", "PageUp", "PageDown"];
  const DEFAULTS = {
    // 14-sep (criterio de Sergi para el movil, «las mismas guardas que el
    // escritorio», aplicado a los atajos): cada atajo delega en el MISMO boton o
    // funcion que usa el raton, conservando su machineMoveBlocked. Antes mandaban
    // el G-code directo: HOME sin el dialogo que el boton muestra en modo escuela,
    // RAYO sin la comprobacion de homing de KIN._applyPro, y los ceros sin la
    // confirmacion que .wcs-btn pide siempre.
    home: { label: "Home All (G28)", key: "h", action: () => { if (!machineMoveBlocked()) $(`btnQaHomeAll`)?.click(); } },
    // 15-sep: por #btnEStop (antirrebote, ERROR y corte del bordeador/aplanado), como
    // el resto de atajos con su botón. Antes mandaba M112 sin pasar a ERROR.
    stop: { label: "Parada de emergencia", key: "Escape", action: () => { const b = $(`btnEStop`); b ? b.click() : RRF.urgentGcode("M112"); } },
    spindle: { label: "Husillo ON / OFF", key: "F2", action: () => $(`btnSpindle`)?.click() },
    // Cinemática: bloqueada en RUNNING (cambiar accel/jerk a mitad de corte).
    modeSilk: { label: "Modo SEDA (manual)", key: "s", action: () => { if (!machineMoveBlocked()) KIN._applySilk(); } },
    modePro: { label: "Modo RAYO (producción)", key: "r", action: () => { if (!machineMoveBlocked()) KIN._applyPro(); } },
    // Ceros: bloqueados TAMBIÉN en PAUSED — re-cerar a mano desplaza el resto
    // del trabajo al reanudar (una pulsación accidental de Shift+X arruinaba la pieza).
    zeroX: { label: "Cero X (G10 L20 X0)", key: "X", action: () => { if (!machineMoveBlocked(true)) $q(`.wcs-btn[data-axis="X"]`)?.click(); } },
    zeroY: { label: "Cero Y", key: "Y", action: () => { if (!machineMoveBlocked(true)) $q(`.wcs-btn[data-axis="Y"]`)?.click(); } },
    zeroZ: { label: "Cero Z", key: "Z", action: () => { if (!machineMoveBlocked(true)) $q(`.wcs-btn[data-axis="Z"]`)?.click(); } },
    console: { label: "Abrir consola", key: "F4", action: () => $q('.center-tab[data-target="consoleTab"]')?.click() },
    // t_b8cd40c2: __openMachineConfig() carga perezosamente rotechos-config-modal.js
    // antes de invocar openMachineConfig(). El fallback al click del botón
    // (que dispara __openMachineConfig vía su listener) se mantiene por si la
    // carga falla.
    config: { label: "Abrir configuración", key: "F3", action: () => __openMachineConfig()?.catch(() => $(`btnSysManager`)?.click()) },
  };
  let bindings = {};
  const L = (id) => t(`kb.${id}`, DEFAULTS[id].label);
  let initialized = false;
  let capturing = null;
  function loadBindings() {
    bindings = {};
    Object.keys(DEFAULTS).forEach((id) => { bindings[id] = { ...DEFAULTS[id] }; });
    const saved = STORE.get(`kb.bindings`);
    if (saved && typeof saved === "object") {
      Object.keys(saved).forEach((id) => { if (bindings[id] && typeof saved[id]?.key === "string") bindings[id].key = saved[id].key; });
    }
  }
  function saveBindings() {
    const out = {};
    Object.keys(bindings).forEach((id) => { out[id] = { key: bindings[id].key }; });
    STORE.set(`kb.bindings`, out);
  }
  function fmtKey(k) {
    if (k === " ") return "Espacio";
    if (k === "Escape") return "Esc";
    if (k === "ArrowUp") return "↑"; if (k === "ArrowDown") return "↓"; if (k === "ArrowLeft") return "←"; if (k === "ArrowRight") return "→";
    return k;
  }
  function render() {
    const tb = $(`kbTbody`);
    if (!tb) return;
    const rows = [];
    // Filas de jog reservadas (informativas)
    const jogInfo = [
      { l: "Jog X +", k: "ArrowRight" },
      { l: "Jog X −", k: "ArrowLeft" },
      { l: "Jog Y +", k: "ArrowUp" },
      { l: "Jog Y −", k: "ArrowDown" },
      { l: "Jog Z +", k: "PageUp" },
      { l: "Jog Z −", k: "PageDown" },
    ].map((r) => ({ ...r, l: `${r.l} (${t(`kb.reserved`, `reservado`)})` }));
    jogInfo.forEach((r) => {
      rows.push(`<tr style="border-bottom:1px solid var(--border);background:var(--bg-input)"><td style="padding:8px 12px;color:var(--text-3);font-size:12px">${r.l}</td><td style="padding:8px 12px;text-align:center"><span style="background:var(--bg-raised);border:1px solid var(--border);border-radius:6px;padding:3px 8px;font-family:var(--mono);font-size:11px;color:var(--text-3)">${fmtKey(r.k)}</span></td><td style="padding:8px 12px;text-align:right;color:var(--text-3);font-size:11px;font-style:italic">${t(`kb.notRemappable`, `No reasignable`)}</td></tr>`);
    });
    Object.keys(bindings).forEach((id) => {
      const b = bindings[id];
      const isCap = capturing === id;
      const badge = isCap
        ? `<span style="background:var(--yellow);color:#000;border-radius:6px;padding:3px 10px;font-family:var(--mono);font-size:11px;font-weight:700;animation:pulse 1s infinite">Pulsa una tecla…</span>`
        : `<span style="background:var(--bg-raised);border:1px solid var(--border);border-radius:6px;padding:3px 8px;font-family:var(--mono);font-size:11px;color:var(--text-1)">${fmtKey(b.key)}</span>`;
      rows.push(`<tr style="border-bottom:1px solid var(--border)"><td style="padding:8px 12px;color:var(--text-1);font-size:12px">${L(id)}</td><td style="padding:8px 12px;text-align:center">${badge}</td><td style="padding:8px 12px;text-align:right"><button class=btn-cancel data-kb-change="${id}" style="font-size:10px;padding:3px 8px">${t(`kb.change`, `Cambiar`)}</button> <button class=btn-cancel data-kb-reset="${id}" style="font-size:10px;padding:3px 8px;margin-left:4px" title="${t(`kb.resetTitle`, `Restaurar tecla por defecto`)}">↺</button></td></tr>`);
    });
    tb.innerHTML = rows.join("");
    tb.querySelectorAll("[data-kb-change]").forEach((btn) => bindFastTouch(btn, () => { capturing = btn.dataset.kbChange; render(); }));
    tb.querySelectorAll("[data-kb-reset]").forEach((btn) => bindFastTouch(btn, () => { const id = btn.dataset.kbReset; bindings[id].key = DEFAULTS[id].key; saveBindings(); render(); toast(`${L(id)} → ${fmtKey(bindings[id].key)}`, "ok"); }));
  }
  function handleKeyDown(e) {
    // Modo captura: asignar la tecla pulsada
    if (capturing) {
      e.preventDefault(); e.stopPropagation();
      const k = e.key;
      if (k === "Tab" || k === "F1" || k === "F5" || k === "F11" || k === "F12") { toast(t(`msg.teclaReservadaDelNavegador`, "Tecla reservada del navegador"), "err"); capturing = null; render(); return; }
      if (RESERVED.includes(k)) { toast(t(`msg.estaTeclaEstáReservada`, "Esta tecla está reservada para jog"), "err"); capturing = null; render(); return; }
      const conflict = Object.entries(bindings).find(([id, b]) => id !== capturing && b.key === k);
      if (conflict) { toast(t(`msg.conflictoConConflict1label`, `Conflicto con: ${L(conflict[0])}`, { "conflict[1].label": L(conflict[0]) }), "err"); capturing = null; render(); return; }
      bindings[capturing].key = k; saveBindings(); const lbl = L(capturing); capturing = null; render();
      toast(t(`msg.lblFmtkeyk`, `${lbl} → ${fmtKey(k)}`, { "lbl": lbl, "fmtKey(k)": fmtKey(k) }), "ok");
      return;
    }
    // Ignorar si el foco está en un input/textarea
    const tag = e.target?.tagName;
    if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return;
    // BUG-02 (Gemini UI review): no ejecutar atajos si hay un modal abierto.
    // Antes el filtro era solo por foco en input — un modal con botones tenía
    // foco en un <button>, y F3 ejecutaba la acción igualmente. Ahora: si
    // hay cualquier modal visible, no se ejecuta el atajo.
    // F-02: cualquier modal abierto del shell bloquea los atajos. Selector
    // compartido (rotechos.js top-of-file) — incluye .modal-overlay (genérico),
    // .tc-modal-overlay (tool change), .rm-macros-modal y .rm-macros-center-modal
    // (macros), .bat-modal-overlay (batería).
    if (hasVisibleModal()) return;
    // Buscar atajo coincidente
    const match = Object.entries(bindings).find(([_, b]) => b.key === e.key);
    if (match) { e.preventDefault(); try { match[1].action(); } catch (err) { LOG.error("KB action error:", err); } }
  }
  function exportProfile() {
    const blob = new Blob([JSON.stringify({ bindings: Object.fromEntries(Object.entries(bindings).map(([id, b]) => [id, { key: b.key }])) }, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href = url; a.download = "rotechos-keybindings.json"; a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    toast(t(`msg.perfilDeTecladoExportado`, "Perfil de teclado exportado"), "ok");
  }
  function importProfile(file) {
    const reader = new FileReader();
    reader.onload = (ev) => {
      try {
        const j = JSON.parse(String(ev.target.result));
        if (j && j.bindings && typeof j.bindings === "object") {
          Object.keys(j.bindings).forEach((id) => { if (bindings[id] && typeof j.bindings[id]?.key === "string") bindings[id].key = j.bindings[id].key; });
          saveBindings(); render(); toast(t(`msg.perfilImportado`, "Perfil importado"), "ok");
        } else toast(t(`msg.archivoNoVálido`, "Archivo no válido"), "err");
      } catch (e) { toast(t(`msg.errorAlLeerEl`, "Error al leer el archivo"), "err"); }
    };
    reader.readAsText(file);
  }
  function bindOnce() {
    $(`kbBtnReset`)?.addEventListener("click", () => {
      Object.keys(bindings).forEach((id) => { bindings[id].key = DEFAULTS[id].key; });
      saveBindings(); render(); toast(t(`msg.atajosRestauradosAValores`, "Atajos restaurados a valores por defecto"), "ok");
    });
    $(`kbBtnExport`)?.addEventListener("click", exportProfile);
    $(`kbImport`)?.addEventListener("change", (e) => { const f = e.target.files?.[0]; if (f) importProfile(f); e.target.value = ""; });
    // Listener global (en fase de captura para tener prioridad sobre listeners burbujeo, pero solo actúa si la tecla NO es reservada)
    window.addEventListener("keydown", handleKeyDown, false);
    // Cancelar captura activa si el operario cierra el modal o cambia de pestaña
    function cancelCapture() {
      if (capturing !== null) {
        capturing = null;
        render();
        toast(t(`msg.capturaDeTeclaCancelada`, "Captura de tecla cancelada"), "info");
      }
    }
    $(`btnMcfgClose`)?.addEventListener(`click`, cancelCapture);
    $(`machineConfigModal`)?.addEventListener(`click`, (e) => {
      // Click en el backdrop (fuera del contenido) — cancela captura también
      if (e.target.id === `machineConfigModal`) cancelCapture();
    });
    // Al cambiar de pestaña dentro del modal, cancelar captura
    $$(`.mcfg-tab`).forEach((t) => {
      t.addEventListener(`click`, () => { if (t.dataset.tab !== `keyboard`) cancelCapture(); });
    });
  }
  // Inicialización pasiva: cargar bindings y registrar listener global desde el arranque
  loadBindings();
  setTimeout(() => { bindOnce(); }, 1500);
  return {
    onShow() { if (!initialized) initialized = true; render(); },
    stopKey: () => (bindings.stop || DEFAULTS.stop).key,
  };
})();
window.KBSHORTCUTS = KBSHORTCUTS;

// Bloque 53 extraído a rotechos-ui-feedback.js (ago-2026, ver cabecera
// de ese módulo). El enganche AppState.ui.mcfgDirtyClear vive ahora allí.

// Añadir hint visual de atajos al footer del modal de configuración
(function () {
  const acts = $q(`#machineConfigModal .modal-acts`);
  if (acts && !$(`mcfgShortcutHint`)) {
    const hint = document.createElement(`div`);
    hint.id = `mcfgShortcutHint`;
    hint.className = `mcfg-shortcut-hint`;
    hint.style.cssText = `flex:1;text-align:left`;
    hint.innerHTML = `<kbd>Esc</kbd> cerrar · <kbd>Ctrl</kbd>+<kbd>S</kbd> guardar`;
    acts.insertBefore(hint, acts.firstChild);
  }
})();

// ---
// PARO SIEMPRE VISIBLE CON EL TECLADO ABIERTO  (decision 2026-09-04)
//
// TARJETA t_1f6006ac · FASE 1 del plan de fragmentacion del monolito
// (docs/dev/hallazgos/2026-09-09_monolito-diagnostico-y-plan-de-fragmentacion.md §3).
// Extraido a `ROTECHOS/www/js/rotechos-paro-teclado.js` (cargado como `defer`
// antes de rotechos.js). El IIFE es autocontenido — solo lee
// `window.visualViewport` y escribe la variable CSS `--vv-shift` que el
// `.estop-compact` consume (rotechos.css:343, con fallback a 0px). El bug
// original era iOS pegando el sticky PARO en una zona no visible al abrirse
// el teclado; este modulo compensa con un translateY del mismo tamano. Si
// desaparece, el PARO del movil vuelve al bug del 2026-09-04.
// ---
