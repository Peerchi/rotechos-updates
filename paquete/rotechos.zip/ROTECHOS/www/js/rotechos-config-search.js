// ---
// rotechos-config-search.js — Buscador de ajustes del modal de Configuracion
// ---
// Modulo perezoso (t_e783de96, 2026-09-05). Antes vivia inline en
// rotechos-config-modal.js dentro de la IIFE `_mcfgSearchInit` (~365
// lineas, lineas 3143-3507). Se carga con `__loadCfgSearch()` (definido
// en rotechos-config-modal.js) al abrir el modal CONFIGURACION, con el
// mismo patron que `__loadAccelCurve` (pestana VELOCIDADES) y
// `__loadPinesUi` (pestana CONTROLADORA).
//
//   1. El campo #cfgSearchInput es la cabecera del modal — siempre esta
//      en el DOM.
//   2. La primera vez que el operario ABRE el modal (openMachineConfig),
//      rotechos-config-modal.js invoca `__loadCfgSearch()` y el modulo
//      se inyecta via createElement('script').
//   3. En cuanto resuelve, expone `window.MCFG_SEARCH = { search, go,
//      close }` y los handlers se conectan al DOM.
//   4. Navegacion: al elegir resultado, este modulo reusa la conmutacion
//      existente (`.mcfg-tab[data-tab=X].click()` en rotechos.js:3385) —
//      no duplicamos logica ni introducimos un camino paralelo.
//
// POR QUE SE EXTRAE (criterio de la tarjeta t_e783de96):
//   - Es el bloque cohesionado MAS grande del modal (365 lineas) que
//     NO escribe en config.g / config-machine.g ni envia M-codes.
//   - Solo lee del DOM (index.html:484 #cfgSearchInput, #cfgSearchResults)
//     y dispara clicks en la barra lateral de pestanas del modal.
//   - El PIN y la Identidad (escriben SD) y el CFG_FIELDS/cfgPopulate
//     (capa que habla con RRF) estan CONGELADOS hasta despues del
//     primer banco, por decision de la direccion.
//
// Dependencias globales (cargadas antes por orden de defer):
//   - rotechos-dom.js          → $()
//   - rotechos-i18n.js         → t()
//   - rotechos.js              → escHtml (de su IIFE)
//   - window.I18N              → para detectar ES/EN
// ---
'use strict';

(function _mcfgSearchInit() {
  // Indice: {tab, group, labelEs, labelEn, synEs[], synEn[], gcode[]}.
  // El label ES se queda en la declaracion para usar la fuente canonica del HTML
  // cuando el idioma activo sea ES; el EN se consulta via window.t().
  // G-code y sinonimos se mantienen a mano: cada sinonimo adicional es barato
  // y aporta recall (p.ej. "pasos" / "steps" llevan a MOTORES via M92).
  const INDEX = [
    { tab: `motors`,     group: `machine`,
      labelEs: `MOTORES`,
      synEs: [`motores`, `motor`, `eje`, `ejes`, `driver`, `tmc`, `tmc2160`, `pasos`, `corriente`, `direccion`, `inversion`, `eje a`],
      synEn: [`motors`, `motor`, `axis`, `axes`, `driver`, `tmc`, `tmc2160`, `steps`, `current`, `direction`, `reverse`, `a axis`],
      gcode: [`M92`, `M906`, `M569`, `M584`] },
    // t_c2d89697 (2026-09-07) E1: la pestaña FINALES DE CARRERA se
    // renombra a FINAL DE CARRERA en la sidebar para caber en 136 px.
    // El panel sigue titulado «FINALES DE CARRERA», los sinónimos
    // («finales», «final de carrera», «endstop») siguen siendo ES
    // válidos, y el G-code M574 también. Quien busca «final de
    // carrera» sigue llegando; quien busca «FINAL DE CARRERA» también.
    { tab: `endstops`,   group: `machine`,
      labelEs: `FINAL DE CARRERA`,
      synEs: [`finales`, `final de carrera`, `sensores`, `sensor inductivo`, `nc`, `no`, `normalmente cerrado`, `normalmente abierto`, `pin`, `m119`],
      synEn: [`endstops`, `endstop`, `sensor`, `inductive`, `nc`, `no`, `normally closed`, `normally open`, `pin`, `m119`],
      gcode: [`M574`, `M119`] },
    { tab: `homing`,     group: `machine`,
      labelEs: `REFERENCIAR`,
      synEs: [`homing`, `home`, `homming`, `g28`, `referenciar`, `referencia`, `buscar`, `afinar`, `seek`, `back`],
      synEn: [`homing`, `home`, `g28`, `seek`, `back`],
      gcode: [`G28`, `M584`] },
    // t_c2d89697 (2026-09-07) E1: la pestaña LÍMITES DE RECORRIDO se
    // renombra a LÍMITES en la sidebar para caber en 136 px. Sinónimos
    // ES que siguen llevando aquí: «limites», «recorrido», «soft limits»,
    // «m208», «tope», «rango». El G-code M208 también.
    { tab: `softlimits`, group: `machine`,
      labelEs: `LÍMITES`,
      synEs: [`limites`, `recorrido`, `soft limits`, `m208`, `rango`, `tope`, `topes`],
      synEn: [`soft limits`, `travel`, `limits`, `m208`, `range`],
      gcode: [`M208`, `M564`] },
    { tab: `speeds`,     group: `machine`,
      labelEs: `VELOCIDADES`,
      synEs: [`velocidad`, `velocidades`, `aceleracion`, `jerk`, `seda`, `rayo`, `m201`, `m203`, `m566`, `feedrate`, `avance`],
      synEn: [`speed`, `speeds`, `acceleration`, `jerk`, `silk`, `rayo`, `m201`, `m203`, `m566`, `feedrate`],
      gcode: [`M201`, `M203`, `M566`] },
    { tab: `backlash`,   group: `machine`,
      labelEs: `BACKLASH`,
      synEs: [`backlash`, `juego`, `holgura`, `compensacion`, `m425`, `reversibilidad`],
      synEn: [`backlash`, `play`, `compensation`, `m425`, `reversibility`],
      gcode: [`M425`] },
    { tab: `spindle`,    group: `machine`,
      labelEs: `SPINDLE`,
      synEs: [`spindle`, `husillo`, `makita`, `vfd`, `pwm`, `rele`, `modbus`, `rpm`, `refrigeracion`, `coolant`, `m3`, `m4`, `m7`, `m8`],
      synEn: [`spindle`, `makita`, `vfd`, `pwm`, `relay`, `modbus`, `rpm`, `coolant`, `m3`, `m4`, `m7`, `m8`],
      gcode: [`M3`, `M4`, `M5`, `M7`, `M8`, `M9`] },
    { tab: `probe`,      group: `machine`,
      labelEs: `SONDA Z`,
      synEs: [`sonda`, `sondeo`, `palpador`, `probe z`, `z probe`, `g31`, `g32`],
      synEn: [`probe`, `z probe`, `touch probe`, `g31`, `g32`],
      gcode: [`G31`, `G32`, `G30`] },
    { tab: `wizard`,     group: `ceremony`,
      labelEs: `PRIMER ARRANQUE`,
      synEs: [`wizard`, `primer arranque`, `puesta en marcha`, `asistente`, `configuracion inicial`],
      synEn: [`wizard`, `first setup`, `setup`, `first run`],
      gcode: [] },
    { tab: `backup`,     group: `ceremony`,
      labelEs: `BACKUP`,
      synEs: [`backup`, `copia de seguridad`, `restaurar`, `exportar`, `zip`],
      synEn: [`backup`, `restore`, `export`, `zip`],
      gcode: [] },
    { tab: `ota`,        group: `ceremony`,
      labelEs: `ACTUALIZAR (OTA)`,
      synEs: [`ota`, `actualizar`, `actualizacion`, `firmware`, `upgrade`],
      synEn: [`ota`, `update`, `upgrade`, `firmware`],
      gcode: [] },
    { tab: `macros`,     group: `ceremony`,
      labelEs: `MACROS`,
      synEs: [`macros`, `macro`, `m98`],
      synEn: [`macros`, `macro`, `m98`],
      gcode: [`M98`] },
    { tab: `ledrgb`,     group: `ceremony`,
      labelEs: `LED RGB`,
      synEs: [`led`, `rgb`, `neopixel`, `tira led`, `iluminacion`, `brillo`],
      synEn: [`led`, `rgb`, `neopixel`, `led strip`, `brightness`],
      gcode: [] },
    { tab: `pines`,      group: `ceremony`,
      labelEs: `CONTROLADORA`,
      synEs: [`controladora`, `pinout`, `scylla`, `btt`, `pines`, `conectores`, `mapa de pines`],
      synEn: [`controller`, `pinout`, `scylla`, `btt`, `pins`, `connectors`],
      gcode: [] },
    { tab: `keyboard`,   group: `ceremony`,
      labelEs: `TECLADO`,
      synEs: [`teclado`, `atajos`, `shortcuts`, `hotkeys`, `bind`],
      synEn: [`keyboard`, `shortcuts`, `hotkeys`, `bindings`],
      gcode: [] },
    { tab: `guide`,      group: `read`,
      labelEs: `GUIA MECANIZADO`,
      synEs: [`guia`, `mecanizado`, `manual`, `tutorial`, `paso a paso`],
      synEn: [`guide`, `machining`, `manual`, `tutorial`, `how to`],
      gcode: [] },
    { tab: `viz3d`,      group: `read`,
      labelEs: `VISUALIZADOR 3D`,
      synEs: [`visualizador`, `3d`, `gcode`, `vista previa`, `simulacion`],
      synEn: [`viewer`, `3d`, `gcode`, `preview`, `simulation`],
      gcode: [] },
    { tab: `jobhistory`, group: `read`,
      labelEs: `HISTORIAL`,
      synEs: [`historial`, `trabajos`, `jobs`, `estadisticas`],
      synEn: [`history`, `jobs`, `statistics`],
      gcode: [] },
    { tab: `glossary`,   group: `read`,
      labelEs: `WIKI CNC`,
      synEs: [`wiki`, `glosario`, `terminos`, `diccionario`],
      synEn: [`wiki`, `glossary`, `terms`, `dictionary`],
      gcode: [] },
    { tab: `pin`,        group: `system`,
      labelEs: `PIN HTTP (M551)`,
      synEs: [`pin`, `m551`, `contrasena`, `password`, `http`, `login`, `autenticacion`],
      synEn: [`pin`, `m551`, `password`, `http`, `login`, `auth`],
      gcode: [`M551`] },
    { tab: `about`,      group: `system`,
      labelEs: `IDENTIDAD`,
      synEs: [`identidad`, `nombre`, `maquina`, `m550`, `acerca de`, `version`],
      synEn: [`identity`, `name`, `machine`, `m550`, `about`, `version`],
      gcode: [`M550`] },
    // t_ec990fc0 (2026-09-05): estas tres entradas SOLO existian en la copia
    // inline del buscador que vivia en rotechos-config-modal.js. La copia no
    // era un duplicado: era un SUPERCONJUNTO de 25 entradas frente a las 22 de
    // aqui. Al extraer el modulo se borro la copia y con ella la unica via de
    // encontrar INPUT SHAPING, TIMEOUT MOTORES y PROTOCOLOS DE RED buscando.
    // t_f8b27b80 (2026-09-05) — 3 pestañas AVANZADO nuevas
    { tab: `motortimeout`, group: `advanced`,
      labelEs: `TIMEOUT MOTORES`,
      synEs: [`timeout`, `motores`, `desenergizar`, `soltar motores`, `m84`, `z siempre energizado`, `gravedad`],
      synEn: [`timeout`, `motors`, `idle`, `release`, `m84`, `z always energised`, `gravity`],
      gcode: [`M84`] },
    // t_c2d89697 (2026-09-07) E1: PROTOCOLOS DE RED → RED (M586) en
    // la sidebar. Sinónimos ES que siguen llevando aquí: «red»,
    // «protocolos», «m586», «ftp», «telnet», «http», «autenticacion».
    { tab: `network`,      group: `advanced`,
      labelEs: `RED (M586)`,
      synEs: [`red`, `protocolos`, `ftp`, `telnet`, `http`, `m586`, `autenticacion`, `sin contraseña`],
      synEn: [`network`, `protocols`, `ftp`, `telnet`, `http`, `m586`, `auth`, `no password`],
      gcode: [`M586`] },
    { tab: `fans`, group: `advanced`,
      labelEs: `VENTILADORES`,
      synEs: [`ventiladores`, `ventilador`, `temperatura`, `refrigeracion`, `aux1`, `m106`],
      synEn: [`fans`, `fan`, `temperature`, `cooling`, `aux1`, `m106`],
      gcode: [`M106`] },
    { tab: `inputshaping`, group: `advanced`,
      labelEs: `INPUT SHAPING`,
      synEs: [`input shaping`, `shaper`, `vibracion`, `ringing`, `m593`, `zvd`, `zvdd`, `acelerometro`, `m956`, `frecuencia`],
      synEn: [`input shaping`, `shaper`, `vibration`, `ringing`, `m593`, `zvd`, `zvdd`, `accelerometer`, `m956`, `frequency`],
      gcode: [`M593`] },
  ];
  // Normaliza: minusculas + sin diacriticos + colapsa espacios.
  function _norm(s) {
    return String(s || ``)
      .toLowerCase()
      .normalize(`NFD`).replace(/[\u0300-\u036f]/g, ``)
      .replace(/\s+/g, ` `)
      .trim();
  }
  // Indice pre-calculado (label ES/EN normalizado, sinos, gcode) para que cada
  // busqueda sea O(n*sinonimos) sin realocar el array de entradas.
  const _INDEX_NORM = INDEX.map((it) => ({
    tab: it.tab, group: it.group, labelEs: it.labelEs,
    synEs: it.synEs.map(_norm), synEn: it.synEn.map(_norm), gcode: it.gcode,
    labelEsN: _norm(it.labelEs),
  }));
  function _esIndex() {
    try { return (window.I18N && window.I18N.lang) === `en` ? 1 : 0; }
    catch { return 0; }
  }
  function _score(it, q, esEn) {
    const sinos = esEn ? it.synEn : it.synEs;
    // G-code: match exacto case-insensitive vale 90.
    for (const g of it.gcode) if (g.toLowerCase() === q) return [90, g];
    // Sinonimo exacto: 80 (prioridad maxima entre sinonimos).
    for (let i = 0; i < sinos.length; i++) if (sinos[i] === q) return [80, sinos[i]];
    // Empieza por: 70.
    for (const s of sinos) if (s.startsWith(q)) return [70, s];
    // Label (ES o EN) empieza por: 65.
    if (it.labelEsN.startsWith(q)) return [65, it.labelEsN];
    // Contiene en sinonimos: 40 + bonus por longitud (mas largo = mas cerca).
    let best = -1, bestLen = 0;
    for (const s of sinos) {
      const idx = s.indexOf(q);
      if (idx >= 0 && (best < 0 || idx < best || (idx === best && s.length > bestLen))) {
        best = idx; bestLen = s.length;
      }
    }
    if (best >= 0) return [40 - best + Math.max(0, 8 - bestLen / 4), `s@${best}`];
    return null;
  }
  function _mcfgSearch(q) {
    const nq = _norm(q);
    if (!nq) return [];
    const esEn = _esIndex();
    const out = [];
    for (const it of _INDEX_NORM) {
      const sc = _score(it, nq, esEn);
      if (sc) out.push({ it, score: sc[0], hit: sc[1] });
    }
    out.sort((a, b) =>
      b.score - a.score ||
      a.it.labelEsN.localeCompare(b.it.labelEsN)
    );
    return out;
  }
  // Activa la pestana `tab` reutilizando la conmutacion existente: el delegate
  // .mcfg-tab[data-tab] en rotechos.js:3385 oculta paneles y marca active. Asi
  // no duplicamos logica ni introducimos un camino paralelo.
  function _mcfgSearchGo(tab) {
    const btn = document.querySelector(`.mcfg-tab[data-tab=${tab}]`);
    if (btn) btn.click();
  }
  function _mcfgSearchClose() {
    const inp = $(`cfgSearchInput`);
    if (inp) { inp.value = ``; inp.setAttribute(`aria-expanded`, `false`); }
    const box = $(`cfgSearchResults`);
    if (box) { box.hidden = true; box.innerHTML = ``; }
  }
  function _mcfgSearchRender(results) {
    const box = $(`cfgSearchResults`);
    const inp = $(`cfgSearchInput`);
    if (!box || !inp) return;
    inp.setAttribute(`aria-expanded`, results.length ? `true` : `false`);
    if (!inp.value.trim()) { box.hidden = true; box.innerHTML = ``; return; }
    if (!results.length) {
      box.hidden = false;
      box.innerHTML =
        `<div class="mcfg-search-empty">${escHtml(t(`cfg.search.noResults`, `Sin coincidencias`))}</div>` +
        `<div class="mcfg-search-hint">${escHtml(t(`cfg.search.hint`, `Escribe para filtrar · Enter para abrir · Esc para limpiar`))}</div>`;
      return;
    }
    const rows = results.slice(0, 12).map((r, i) => {
      const label = r.it.labelEs;
      const groupLabel = r.it.group.toUpperCase();
      // Resalta el match dentro de la etiqueta cuando aplique.
      return `<button type="button" class="mcfg-search-row${i === 0 ? ` active` : ``}" data-tab="${r.it.tab}" data-idx="${i}" role="option">` +
        `<span>${escHtml(label)}</span>` +
        `<span class="mcfg-search-sub">${escHtml(groupLabel)} · <code>${escHtml(r.hit)}</code></span>` +
        `</button>`;
    }).join(``);
    box.hidden = false;
    box.innerHTML = rows +
      `<div class="mcfg-search-hint">${escHtml(t(`cfg.search.hint`, `Escribe para filtrar · Enter para abrir · Esc para limpiar`))}</div>`;
    // Click handler (delegado, evita reasignar N listeners).
    box.querySelectorAll(`.mcfg-search-row`).forEach((row) => {
      row.addEventListener(`click`, () => {
        const t = row.dataset.tab;
        _mcfgSearchGo(t);
        _mcfgSearchClose();
      });
    });
  }
  function _mcfgSearchMove(delta) {
    const rows = Array.from(document.querySelectorAll(`#cfgSearchResults .mcfg-search-row`));
    if (!rows.length) return;
    const cur = rows.findIndex((r) => r.classList.contains(`active`));
    let next = cur + delta;
    if (cur < 0) next = delta > 0 ? 0 : rows.length - 1;
    if (next < 0) next = rows.length - 1;
    if (next >= rows.length) next = 0;
    rows.forEach((r, i) => r.classList.toggle(`active`, i === next));
    rows[next].scrollIntoView({ block: `nearest` });
  }
  function _mcfgSearchConfirm() {
    const rows = Array.from(document.querySelectorAll(`#cfgSearchResults .mcfg-search-row`));
    const cur = rows.findIndex((r) => r.classList.contains(`active`));
    const target = cur >= 0 ? rows[cur] : rows[0];
    if (target) { _mcfgSearchGo(target.dataset.tab); }
    _mcfgSearchClose();
  }
  function _wire() {
    const inp = $(`cfgSearchInput`);
    if (!inp) return;  // modal no presente (build sin index.html todavia)
    inp.addEventListener(`input`, () => {
      _mcfgSearchRender(_mcfgSearch(inp.value));
    });
    inp.addEventListener(`keydown`, (e) => {
      if (e.key === `Escape`) {
        // Si hay texto o el dropdown esta abierto, vaciamos y cerramos. NO
        // cerramos el modal: eso lo hace el siguiente Esc (delegado global).
        if (inp.value || !$(`cfgSearchResults`).hidden) {
          e.preventDefault();
          e.stopPropagation();
          _mcfgSearchClose();
          inp.focus();
        }
      } else if (e.key === `Enter`) {
        if (!$(`cfgSearchResults`).hidden) {
          e.preventDefault();
          e.stopPropagation();
          _mcfgSearchConfirm();
        }
      } else if (e.key === `ArrowDown`) {
        if (!$(`cfgSearchResults`).hidden) {
          e.preventDefault();
          e.stopPropagation();
          _mcfgSearchMove(+1);
        }
      } else if (e.key === `ArrowUp`) {
        if (!$(`cfgSearchResults`).hidden) {
          e.preventDefault();
          e.stopPropagation();
          _mcfgSearchMove(-1);
        }
      }
    });
    // Click fuera cierra el dropdown (UX). Sin esto el dropdown se queda
    // pegado al input aunque el usuario cambie de pestana con el raton.
    document.addEventListener(`click`, (e) => {
      const box = $(`cfgSearchResults`);
      if (!box || box.hidden) return;
      if (e.target === inp) return;
      if (!box.contains(e.target)) _mcfgSearchClose();
    });
    // Cuando el modal se cierra por cualquier via, limpiamos el campo. Sin
    // esto, reabrir el modal mostraria resultados fantasma del estado previo.
    const modal = $(`machineConfigModal`);
    if (modal) {
      const obs = new MutationObserver(() => {
        if (!modal.classList.contains(`show`)) _mcfgSearchClose();
      });
      obs.observe(modal, { attributes: true, attributeFilter: [`class`] });
    }
    // Cambio de idioma: re-render del dropdown para reflejar etiqueta EN cuando
    // proceda (las labels vienen del HTML i18n, no del indice, pero el
    // placeholder y mensajes si). Para mantener simple: re-aplicamos i18n.
    window.addEventListener(`i18n-change`, () => {
      if (inp.value) _mcfgSearchRender(_mcfgSearch(inp.value));
      else _mcfgSearchClose();
    });
  }
  // Esperar DOM (este modulo se inyecta via createElement('script') al abrir
  // el modal, asi que el input ya esta presente; pero defendemos por si el
  // script se embebe en test sin DOM).
  if (document.readyState === `loading`) {
    document.addEventListener(`DOMContentLoaded`, _wire);
  } else {
    _wire();
  }
  // API expuesta para que el cargador y los tests tengan un handle estable.
  // search() es la primitiva pura (sin tocar el DOM) — util para unit-tests.
  window.MCFG_SEARCH = { search: _mcfgSearch, go: _mcfgSearchGo, close: _mcfgSearchClose };
})();
