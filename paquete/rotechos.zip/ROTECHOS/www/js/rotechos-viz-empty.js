/* ---
 * rotechos-viz-empty.js — Estado vacío útil del visor G-code del cockpit.
 *
 * TAREA KANBAN: t_914db8a1 (sustituir el contenido inactivo de #vizCard por
 * un estado vacío útil sin alterar tamaño del panel, columnas laterales ni
 * rejilla del cockpit).
 *
 * QUE HACE
 * ---------
 * Sobre #vizPlaceholder (DOM ya creado en index.html:128):
 *   1. Botón principal #vizEmptyOpenFiles — es el punto único de entrada al
 *      gestor G-code: abre #tvFilesModal y carga su lista real de archivos.
 *   2. Zona de drop #vizEmptyDrop + input #vizEmptyFileInput — usa el helper
 *      setupDragAndDrop (rotechos-dom-helpers.js:131) ya existente. El drop
 *      se monta SOLO si rr_upload está disponible (FM y FM.upload existen),
 *      porque el flujo es: subir a 0:/gcodes/<name> vía FM.upload, luego
 *      FILE_OPS.load(name) para que la máquina arme el archivo con M23.
 *      Si rr_upload no existe (mock mínimo sin FM), no inventamos flujo.
 *   3. Lista #vizEmptyRecent de últimos trabajos — se rellena SOLO si
 *      window.JOBHIST existe, su load() no lanza y data.jobs.length > 0
 *      tras el load. En otro caso, la sección queda oculta (lo exige el
 *      briefing — no inventar datos).
 *   4. Persistencia del estado vacío: vizLoadGCode (rotechos-viz.js:747) ya
 *      pone display:none a #vizPlaceholder cuando carga un archivo.
 *      FILE_OPS.load (rotechos-file-ops.js:49) confirma el ciclo
 *      correctamente, así que no necesitamos escuchar más eventos.
 *
 * QUE NO HACE (POR DISEÑO)
 * ---
 *   - No se aplica a móvil/pendant. CSS @media (max-width:767px) en
 *     rotechos.css ya oculta .viz-empty en <=767.
 *   - No añade un overlay nuevo sobre el visor: REUTILIZA el placeholder
 *     existente (#vizPlaceholder) que ocupa todo el wrap vía
 *     position:absolute;inset:0 (rotechos.css:208). Así no toca tamaño del
 *     panel ni rejilla.
 *   - No inventa el flujo de subida: si FM.upload no existe, el drop se
 *     DESHABILITA y se muestra un toast informativo al intentar dropar.
 *
 * DEPENDENCIAS (todas disponibles via window.* en boot gracias al orden de
 * <script defer> en index.html línea 3):
 *   - window.$                  (rotechos-dom.js)
 *   - window.toast / log        (rotechos-ui-feedback.js / rotechos-logger.js)
 *   - window.t                  (rotechos-i18n.js)
 *   - window.FM                 (rotechos-fm.js:212)
 *   - window.FILE_OPS           (rotechos-file-ops.js:183)
 *   - window.JOBHIST            (rotechos-modules.js:741)
 *   - window.setupDragAndDrop   (rotechos-dom-helpers.js:131)
 *
 * PUERTO DEL NOMBRE: prefijo rotechos- (mismo namespace que el resto). Es un
 * módulo cordenado en IIFE; expone window.VIZ_EMPTY para tests externos.
 * --- */
(function () {
  'use strict';
  if (window.VIZ_EMPTY) return;
  const $ = (id) => document.getElementById(id);

  // ---
  // Utilidades
  // ---
  function escHtml(s) {
    if (typeof s !== 'string') return '';
    return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }
  function fmtDur(secs) {
    secs = Math.max(0, Number(secs) || 0);
    if (secs < 60) return `${secs}s`;
    if (secs < 3600) return `${Math.floor(secs / 60)}m ${secs % 60}s`;
    return `${Math.floor(secs / 3600)}h ${Math.floor((secs % 3600) / 60)}m`;
  }
  function isValidGcodeName(name) {
    return /\.(gcode|g|nc|cnc|tap|txt)$/i.test(name || '');
  }
  // Booleano: ¿rr_upload está disponible vía FM.atomicUpload o FM.upload?
  function rrUploadAvailable() {
    const FM = window.FM;
    return !!(FM && typeof FM.atomicUpload === 'function' && typeof FM.upload === 'function');
  }

  // ---
  // Acciones
  // ---
  // Botón principal: único acceso del cockpit al gestor G-code.
  function openFiles() {
    const modal = $('tvFilesModal');
    if (!modal || typeof window.tvLoadFilesModal !== 'function') {
      console.warn('VIZ_EMPTY: gestor G-code no disponible todavía.');
      return;
    }
    modal.classList.add('show');
    window.tvLoadFilesModal();
  }

  // Drop: sube a 0:/gcodes/<name> vía FM.atomicUpload (raíz rr_upload que ya
  // confirman rotechos-fm.js:114, 162) y luego FILE_OPS.load(name) para que el
  // visor reciba el gcode y la máquina arme M23. Si rr_upload no existe,
  // abortamos con toast (no inventamos upload).
  async function handleDroppedFile(file) {
    if (!file || !isValidGcodeName(file.name)) {
      toast(window.t ? window.t('msg.vizEmptyBadType', 'Solo se admiten .gcode / .g / .nc / .cnc / .tap / .txt') : 'Solo se admiten archivos .gcode / .g', 'warn');
      return;
    }
    // Guardia de seguridad: si la máquina está RUNNING/PAUSED, dejar que
    // FILE_OPS.load muestre su diálogo de confirmación (rotechos-file-ops.js:50).
    if (window.SM && (window.SM.current === 'running' || window.SM.current === 'paused')) {
      log(`viz-empty: drop mientras la máquina trabaja (${file.name}) — se delega la confirmación a FILE_OPS.load`, 'warn');
    }
    if (!rrUploadAvailable()) {
      toast(window.t ? window.t('msg.vizEmptyNoUpload', 'Subida no disponible en este momento — usa CARGAR G-CODE') : 'Subida no disponible — usa CARGAR G-CODE', 'err');
      return;
    }
    try {
      const ok = await window.FM.atomicUpload(file);
      if (!ok) {
        log(`viz-empty: rr_upload falló para ${file.name}`, 'err');
        return;
      }
      log(`viz-empty: rr_upload OK para ${file.name}`, 'ok');
      if (window.FILE_OPS && typeof window.FILE_OPS.load === 'function') {
        // El TEXTO va con la llamada. FILE_OPS.load(filename, gcode = null)
        // solo dibuja la trayectoria si recibe el segundo argumento
        // (rotechos-file-ops.js:121); sin el se limita a mandar M23, poner el
        // nombre y dejar el estado en READY. Aqui se llamaba con uno solo, asi
        // que al cargar un G-code desde el cockpit el archivo entraba en la
        // maquina pero el visor seguia con «Cargar G-code» y sin silueta.
        // Medido: 0 pixeles pintados y #vizPlaceholder en `flex`.
        // El fichero ya esta en memoria —acabamos de subirlo— asi que leerlo
        // no cuesta una descarga de mas.
        let texto = null;
        try { texto = await file.text(); }
        catch (e) { log(`viz-empty: no se pudo leer ${file.name} para dibujarlo: ${e?.message || e}`, 'warn'); }
        await window.FILE_OPS.load(file.name, texto);
        // Con el texto, vizLoadGCode (rotechos-viz.js) oculta #vizPlaceholder
        // y pinta la trayectoria.
      } else {
        toast(window.t ? window.t('msg.vizEmptyLoadFail', 'Subido, pero no se pudo cargar automáticamente') : 'Subido, pero no se pudo cargar automáticamente', 'err');
      }
    } catch (e) {
      log(`viz-empty: drop error (${file.name}): ${e?.message || e}`, 'err');
    }
  }

  // ---
  // Últimos trabajos — SOLO si JOBHIST existe y tiene datos reales
  // ---
  function statusColor(status) {
    if (status === 'completed') return 'var(--green)';
    if (status === 'canceled') return 'var(--text-3)';
    return 'var(--red)';
  }
  async function paintRecent() {
    const recent = $('vizEmptyRecent');
    const list = $('vizEmptyRecentList');
    if (!recent || !list) return;
    if (!window.JOBHIST || typeof window.JOBHIST.load !== 'function') {
      recent.hidden = true;
      return;
    }
    try {
      await window.JOBHIST.load();
    } catch (e) {
      log(`viz-empty: JOBHIST.load() lanzó: ${e?.message || e}`, 'warn');
      recent.hidden = true;
      return;
    }
    const jobs = (window.JOBHIST.data && Array.isArray(window.JOBHIST.data.jobs))
      ? window.JOBHIST.data.jobs
      : [];
    if (jobs.length === 0) {
      recent.hidden = true;
      return;
    }
    // Top 3 más recientes. El historial ya está unshifted (rotechos-modules.js:693)
    // — jobs[0] es el más reciente.
    list.innerHTML = jobs.slice(0, 3).map((j) => {
      const color = statusColor(j.status);
      const name = escHtml(j.file || '—');
      const dur = fmtDur(j.duration || 0);
      return `<li class="viz-empty-recent-row" role=button tabindex=0 data-file="${escHtml(j.file || '')}" data-testid="vizEmptyRecentRow" title="${name}">
<span class="viz-empty-recent-status" style="background:${color}" aria-hidden=true></span>
<span class="viz-empty-recent-name">${name}</span>
<span class="viz-empty-recent-dur">${dur}</span>
</li>`;
    }).join('');
    recent.hidden = false;

    // Click sobre una fila → abrir el gestor G-code (la carga de un archivo
    // antiguo exigiría un flujo de re-selección + M23 explícito que se sale
    // del scope de esta tarjeta; el atajo "VER TODO EL HISTORIAL" sigue
    // dando el camino completo al operario).
    list.querySelectorAll('.viz-empty-recent-row').forEach((row) => {
      row.addEventListener('click', openFiles);
      row.addEventListener('keydown', (ev) => {
        if (ev.key === 'Enter' || ev.key === ' ') { ev.preventDefault(); openFiles(); }
      });
    });
  }

  function openConfigJobhistoryTab() {
    // Atajo al historial completo (mismo flujo que abrir Config → Historial).
    const btn = document.querySelector('[data-cfg-tab="jobhistory"]');
    if (btn) btn.click();
    else if (typeof document.querySelector('[data-tab=jobhistory]')?.click === 'function') {
      document.querySelector('[data-tab=jobhistory]').click();
    }
  }

  // ---
  // Instalación
  // ---
  function install() {
    const placeholder = $('vizPlaceholder');
    const btn = $('vizEmptyOpenFiles');
    const drop = $('vizEmptyDrop');
    const fileInput = $('vizEmptyFileInput');
    const recentAll = $('vizEmptyRecentAll');
    if (!placeholder || !btn) return;

    // Botón principal — punto único de acceso al gestor G-code.
    btn.addEventListener('click', openFiles);

    // Drop zone — solo si rr_upload está disponible.
    if (rrUploadAvailable() && drop && fileInput && typeof window.setupDragAndDrop === 'function') {
      window.setupDragAndDrop(
        drop,
        fileInput,
        handleDroppedFile,
        'var(--blue)',
        'rgba(59,130,246,.08)'
      );
    } else if (drop) {
      // Sin rr_upload: el drop sigue como elemento de UI pero no hace nada
      // funcional. Lo dejamos como pista de UX para el operario.
      drop.addEventListener('click', (ev) => {
        ev.preventDefault();
        toast(window.t ? window.t('msg.vizEmptyNoUpload', 'Subida no disponible en este momento — usa CARGAR G-CODE') : 'Subida no disponible — usa CARGAR G-CODE', 'warn');
      });
    }

    // Acceso al historial completo.
    if (recentAll) recentAll.addEventListener('click', openConfigJobhistoryTab);

    // Últimos trabajos (condicional a JOBHIST real).
    paintRecent();
  }

  // El módulo ya existe antes que el defer; DOM puede no estar listo. El
  // bootstrap del shell (rotechos.js) está al final del orden defer. Usamos
  // DOMContentLoaded como ancla segura — no toca el flujo del boot.init()
  // del monolito y garantiza que los selectores #vizEmpty* ya estén en el DOM.
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', install, { once: true });
  } else {
    // DOM ya listo (script cargado tarde) — instalar en el siguiente tick.
    setTimeout(install, 0);
  }

  window.VIZ_EMPTY = {
    openFiles,
    handleDroppedFile,
    paintRecent,
    install,
    rrUploadAvailable,
    isValidGcodeName,
  };
})();
