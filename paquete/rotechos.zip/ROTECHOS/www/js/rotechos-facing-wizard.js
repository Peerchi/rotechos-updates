/* ---
   ROTECHOS — Asistente de aplanado de la mesa de sacrificio.

   PEREZOSO: se carga al abrir la pestaña APLANADO. Calcula el zigzag, lo
   dibuja en el visor y lo ejecuta línea a línea tras confirmar.

   Reglas: HOME antes de ejecutar; no se ejecuta si el área se sale de M208;
   la profundidad es por pasada, no total. En marcha usa los ganchos del
   bordeador (AppState.bord: pausa, ESC), comprueba estado y homing en cada
   línea y termina siempre con M5.

   Cálculo puro en window.FACING (tests/unit/facing-wizard.test.js); UI en
   window.ROTECHOS_FACING_WIZARD. Tests e2e: e2e-facing-wizard y
   e2e-paro-husillo-facing-escuela.
   ═══════════════════════════════════════════════════════════════════════════ */
(function () {
  'use strict';

  // ---
  // Cálculo puro (testable sin DOM)
  // ---
  //
  // convenciones:
  //   · El zigzag va por filas en X, alternando el sentido (S-shaped).
  //   · Cada fila está separada de la anterior por (1 - overlapPct)·D.
  //   · El solape entre filas es overlapPct (0..1). Por defecto 0.40.
  //   · La pasada termina en X = xMax (línea horizontal completa).
  //   · Z NO entra aquí: el control de profundidad lo lleva el bucle
  //     de ejecución (una pasada por nivel de Z, o varias filas por
  //     nivel si el operario lo prefiere — el wizard hace UNA fila
  //     de profundidad de pasada por nivel, que es lo conservador).
  //
  // devuelve:
  //   {
  //     passCount: number,           // pasadas en Y (filas)
  //     stepMm:    number,           // distancia real entre pasadas = D·(1-overlap)
  //     rows: Array<{               // cada fila del zigzag
  //       y: number,
  //       points: Array<{x:number, y:number}>   // incluye primer y último punto
  //     }>,
  //     bounds: {minX, maxX, minY, maxY},
  //     summary: {totalLengthMm, approxAreaMm2}
  //   }
  function computeFacingPath(input) {
    const err = validateFacingInput(input);
    if (err) throw new Error(err);

    const xMin = +input.xMin;
    const xMax = +input.xMax;
    const yMin = +input.yMin;
    const yMax = +input.yMax;
    const D = +input.toolDiameter;
    const overlap = clamp(+input.overlapPct, 0, 0.95);  // solape 0..0.95 (95%)
    const depthMm = +input.depthMm;                     // profundidad de pasada

    // Paso entre filas: distancia entre centros de pasada.
    // Para solapar el 40 % entre pasadas, la distancia entre líneas
    // contiguas es D·(1 - 0.40) = 0.6·D.
    const stepMm = D * (1 - overlap);
    const height = yMax - yMin;
    // Número de pasadas: lo necesario para cubrir la altura con paso `stepMm`.
    // Si stepMm es 0 (solape 100 %, físicamente imposible) tratamos como 1 fila.
    let passCount = 1;
    if (stepMm > 0 && height > 0) {
      passCount = Math.max(1, Math.ceil(height / stepMm) + 1);
      // +1: la primera fila se posiciona en yMin y la última en yMin + (n-1)·step.
      // Si height=0 -> una sola fila. Si height=2·step -> 3 filas.
    }

    const rows = [];
    let totalLen = 0;
    for (let i = 0; i < passCount; i++) {
      const y = yMin + i * stepMm;
      // Si nos pasamos de yMax, esa fila queda fuera: la última
      // válida es la primera cuya y > yMax; paramos antes.
      if (y > yMax + 1e-6) break;
      // Alternamos sentido: filas pares Xmin→Xmax, impares Xmax→Xmin.
      const dir = (i % 2 === 0) ? 1 : -1;
      const points = (dir === 1)
        ? [{ x: xMin, y }, { x: xMax, y }]
        : [{ x: xMax, y }, { x: xMin, y }];
      totalLen += xMax - xMin;
      rows.push({ y, points });
    }
    const passCountFinal = rows.length;

    return {
      passCount: passCountFinal,
      stepMm,
      rows,
      bounds: { minX: xMin, maxX: xMax, minY: yMin, maxY: yMax },
      depthMm,
      summary: {
        totalLengthMm: totalLen,
        approxAreaMm2: (xMax - xMin) * (yMax - yMin),
      },
    };
  }

  function validateFacingInput(input) {
    if (!input || typeof input !== 'object') return 'Entradas vacías';
    const num = (k) => +input[k];
    for (const k of ['xMin', 'xMax', 'yMin', 'yMax']) {
      if (!isFinite(num(k))) return `Coordenada inválida: ${k}`;
    }
    if (num('xMax') <= num('xMin')) return 'xMax debe ser mayor que xMin';
    if (num('yMax') < num('yMin')) return 'yMax debe ser mayor o igual que yMin';
    if (!isFinite(num('toolDiameter')) || num('toolDiameter') <= 0)
      return 'Diámetro de fresa debe ser > 0 mm';
    if (!isFinite(num('overlapPct')) || num('overlapPct') < 0 || num('overlapPct') >= 1)
      return 'Solape debe estar entre 0 y 0.99 (0–99 %)';
    if (!isFinite(num('depthMm')) || num('depthMm') <= 0)
      return 'Profundidad de pasada debe ser > 0 mm';
    return null;
  }

  function clamp(v, lo, hi) { return Math.max(lo, Math.min(hi, v)); }

  // ---
  // Estado UI (la "miga": lo que el operario está componiendo)
  // ---
  // RRF es un const global de rotechos.js y no cuelga de window: con window.RRF
  // Ejecutar no se habilitaba nunca y el HOME previo se saltaba (medido 14-sep).
  function RRF_() { return typeof RRF !== 'undefined' ? RRF : undefined; }

  const UI_STATE = {
    inputs: {
      xMin: 0, xMax: 530,
      yMin: 0, yMax: 830,
      toolDiameter: 25,
      overlapPct: 0.40,
      depthMm: 0.2,
      feed: 1500,
      rpm: 12000,
      marginMm: 5,    // margen por defecto sobre M208
    },
    path: null,       // última salida de computeFacingPath
    warnings: [],
    outOfBounds: false,
  };

  // ---
  // UI: refrescar dibujo, leer/enviar campos, validar
  // ---
  function $(id) { return document.getElementById(id); }

  function readInputsFromUI() {
    const num = (id) => parseFloat($(id).value);
    const margin = isFinite(num('facingMargin')) ? num('facingMargin') : 5;
    return {
      xMin: isFinite(num('facingXMin')) ? num('facingXMin') : 0,
      xMax: isFinite(num('facingXMax')) ? num('facingXMax') : 530,
      yMin: isFinite(num('facingYMin')) ? num('facingYMin') : 0,
      yMax: isFinite(num('facingYMax')) ? num('facingYMax') : 830,
      toolDiameter: isFinite(num('facingTool')) ? num('facingTool') : 25,
      overlapPct: isFinite(num('facingOverlap')) ? num('facingOverlap') / 100 : 0.40,
      depthMm: isFinite(num('facingDepth')) ? num('facingDepth') : 0.2,
      feed: isFinite(num('facingFeed')) ? num('facingFeed') : 1500,
      rpm: isFinite(num('facingRpm')) ? num('facingRpm') : 12000,
      marginMm: margin,
    };
  }

  function writeInputsToUI() {
    const i = UI_STATE.inputs;
    if ($('facingXMin')) $(`facingXMin`).value = i.xMin;
    if ($('facingXMax')) $(`facingXMax`).value = i.xMax;
    if ($('facingYMin')) $(`facingYMin`).value = i.yMin;
    if ($('facingYMax')) $(`facingYMax`).value = i.yMax;
    if ($('facingTool')) $(`facingTool`).value = i.toolDiameter;
    if ($('facingOverlap')) $(`facingOverlap`).value = Math.round(i.overlapPct * 100);
    if ($('facingDepth')) $(`facingDepth`).value = i.depthMm;
    if ($('facingFeed')) $(`facingFeed`).value = i.feed;
    if ($('facingRpm')) $(`facingRpm`).value = i.rpm;
    if ($('facingMargin')) $(`facingMargin`).value = i.marginMm;
  }

  // Detección de fuera-de-M208 (coincide con la lógica del visor, regla H).
  // Lee la fuente canónica: si `window.AppState.cache.softLimits` está
  // poblada (la usa el propio RotechOS para `window._softLimits`), usamos
  // esa; si no, recurrimos al getter que expone `window._softLimits`.
  function readSoftLimits() {
    const fromCache = (typeof window !== 'undefined'
      && window.AppState
      && window.AppState.cache
      && window.AppState.cache.softLimits) || null;
    if (fromCache && (fromCache.X || fromCache.Y || fromCache.Z)) return fromCache;
    return (typeof window !== 'undefined' && window._softLimits) || {};
  }
  function checkAgainstSoftLimits(inp) {
    const sl = readSoftLimits();
    const xMin = sl.X && sl.X.min != null ? sl.X.min : null;
    const xMax = sl.X && sl.X.max != null ? sl.X.max : null;
    const yMin = sl.Y && sl.Y.min != null ? sl.Y.min : null;
    const yMax = sl.Y && sl.Y.max != null ? sl.Y.max : null;
    if (xMin == null || xMax == null || yMin == null || yMax == null) {
      return { checked: false, outOfBounds: false };
    }
    const m = +inp.marginMm || 0;
    // El margen se aplica hacia el INTERIOR del área M208.
    const axMin = xMin + m, axMax = xMax - m;
    const ayMin = yMin + m, ayMax = yMax - m;
    const oob =
      +inp.xMin < axMin - 1e-6 || +inp.xMax > axMax + 1e-6 ||
      +inp.yMin < ayMin - 1e-6 || +inp.yMax > ayMax + 1e-6;
    return { checked: true, outOfBounds: oob, area: { xMin, xMax, yMin, yMax } };
  }

  // ---
  // Dibujo en el visor
  // ---
  function drawPathInViz(path) {
    if (typeof window.VIZ === 'undefined' || !window.VIZ || !path) return false;
    const VIZ = window.VIZ;
    // coords Float32Array [x,y,z,x,y,z,...]
    const coords = [];
    // pathMeta Int32Array [type, start, length, ...]   type 1 = cut
    const meta = [];
    let idx = 0;
    const Z_DOWN = 0;   // plano de corte
    const Z_RAISE = 5;  // desplazamiento visual entre pasadas (no real)
    for (const row of path.rows) {
      const start = idx;
      // Para cada pasada añadimos una Z ficticia para que se vea en 3D
      // y al pasar de fila "salta" un pelín arriba (Z_RAISE) y vuelve.
      // En 2D/iso/top se ve igual que una línea.
      coords.push(row.points[0].x, row.points[0].y, Z_RAISE);
      idx++;
      for (let i = 1; i < row.points.length; i++) {
        coords.push(row.points[i].x, row.points[i].y, Z_DOWN);
        idx++;
      }
      meta.push(1, start, row.points.length);
    }
    VIZ.coords = new Float32Array(coords);
    VIZ.pathMeta = new Int32Array(meta);
    VIZ.paths = [{ pts: [1] }];   // dummy — sólo necesitamos length > 0
    VIZ.bounds = {
      minX: path.bounds.minX, maxX: path.bounds.maxX,
      minY: path.bounds.minY, maxY: path.bounds.maxY,
      minZ: 0, maxZ: Z_RAISE,
    };
    VIZ._cachedPaths = null;
    VIZ._cachedViewHash = null;
    VIZ.dirty = true;
    try { VIZ.resize(); } catch (_) {}
    try { VIZ.fitView(); } catch (_) {}
    try { VIZ.draw(); } catch (_) {}
    return true;
  }

  function clearVizIfEmpty() {
    if (typeof window.VIZ === 'undefined' || !window.VIZ) return;
    const VIZ = window.VIZ;
    VIZ.coords = null;
    VIZ.pathMeta = null;
    VIZ.paths = [];
    VIZ.bounds = null;
    VIZ._cachedPaths = null;
    VIZ._cachedViewHash = null;
    VIZ.dirty = true;
  }

  // ---
  // Acciones del operario
  // ---
  function recompute() {
    const inp = readInputsFromUI();
    UI_STATE.inputs = inp;
    UI_STATE.warnings = [];
    UI_STATE.outOfBounds = false;

    const oob = checkAgainstSoftLimits(inp);
    if (oob.checked && oob.outOfBounds) {
      UI_STATE.outOfBounds = true;
      UI_STATE.warnings.push(`Área fuera de M208 (X[${oob.area.xMin}..${oob.area.xMax}], Y[${oob.area.yMin}..${oob.area.yMax}]) — recorta o sube el margen`);
    }

    let path = null;
    try {
      path = computeFacingPath(inp);
    } catch (e) {
      UI_STATE.warnings.push(e.message || String(e));
      UI_STATE.path = null;
      renderSummary();
      renderWarnings();
      updateExecuteButton();
      return null;
    }
    UI_STATE.path = path;
    renderSummary();
    renderWarnings();
    drawPathInViz(path);
    updateExecuteButton();
    return path;
  }

  // ---
  // Generación de G-code (conservador: G91 no se usa; G90 absoluto)
  // ---
  function buildGcode(path, opts) {
    const feed = opts.feed || 1500;
    const safeZ = opts.safeZ != null ? opts.safeZ : 10;
    const zCut = -Math.abs(path.depthMm || 0.2);
    const lines = [];
    lines.push('; --- Generado por el asistente de aplanado (rotechos-facing-wizard.js) ---');
    lines.push('G90                ; absoluto');
    lines.push(`G1 Z${safeZ.toFixed(3)} F${Math.min(feed, 600)}      ; subir a Z segura`);
    for (const row of path.rows) {
      const first = row.points[0];
      // posicionar al inicio de la fila en Z segura
      lines.push(`G0 X${first.x.toFixed(3)} Y${first.y.toFixed(3)} F${(feed * 1.5) | 0}`);
      // bajar a la profundidad de pasada
      lines.push(`G1 Z${zCut.toFixed(3)} F${Math.min(feed, 400)}`);
      // recorrer la fila
      for (let i = 1; i < row.points.length; i++) {
        const p = row.points[i];
        lines.push(`G1 X${p.x.toFixed(3)} Y${p.y.toFixed(3)} F${feed}`);
      }
    }
    lines.push(`G1 Z${safeZ.toFixed(3)} F${Math.min(feed, 600)}      ; subir al final`);
    lines.push('; --- fin aplanado ---');
    return lines.join('\n');
  }

  // ---
  // Ejecución: segura (HOME + máquina conectada + área válida)
  // ---
  async function execute() {
    const path = UI_STATE.path;
    if (!path) { (window.toast || console.log)('Calcula la trayectoria antes de ejecutar', 'warn'); return; }
    if (UI_STATE.outOfBounds) {
      (window.toast || console.log)('El área se sale de M208 — no se ejecuta', 'err'); return;
    }
    // Comprobar que la máquina está conectada.
    if (!window.SM) { (window.toast || console.log)('Máquina no conectada', 'err'); return; }
    // A1-FIX (HUECO-2, t_34354573): antes solo se cortaba en ERROR; el
    // RUNNING/PAUSED podía lanzar el aplanado intercalado en la cola de un
    // trabajo en curso (50+ G1 + M3 al final pisando RPM del corte). El
    // aplanado SIEMPRE redefine la pieza (el operario ajusta Z por pasada),
    // así que blockPaused=true corta también en PAUSED — al reanudar el
    // G-code en curso, la trayectoria saldría impredecible.
    if (window.machineMoveBlocked && window.machineMoveBlocked(true)) return;
    // Exigir HOME.
    const allHomed = (window.AppState && window.AppState.limits && window.AppState.limits.allHomed) === true;
    if (!allHomed) {
      const ok = await (window.confirmDialog || ((t, m) => Promise.resolve(window.confirm(m))))(
        'HOME no ejecutado',
        'La máquina NO está referenciada. Sin HOME previo, la fresa puede estamparse contra la mesa al ejecutar el aplanado.\n\n¿Hacer HOME ahora y continuar?',
      );
      if (!ok) return;
      try {
        if (RRF_() && typeof RRF_().gcode === 'function') {
          const r = await RRF_().gcode('G28');
          if (!r) throw new Error('HOME falló');
        }
      } catch (e) {
        (window.toast || console.log)('HOME no completado — abortando aplanado', 'err'); return;
      }
    }
    // Pedir confirmación final con aviso explícito de bajada a la mesa.
    const ok2 = await (window.confirmDialog || ((t, m) => Promise.resolve(window.confirm(m))))(
      'Confirmar aplanado',
      `La fresa VA A BAJAR a la mesa (Z ${(-Math.abs(path.depthMm)).toFixed(2)} mm) y recorrer el área definida.\n\n` +
      `Pasadas: ${path.passCount}\n` +
      `Recorrido total: ${path.summary.totalLengthMm.toFixed(0)} mm\n` +
      `Avance: ${UI_STATE.inputs.feed} mm/min\n\n` +
      `Asegúrate de que el área está despejada.`,
    );
    if (!ok2) return;

    const gcode = buildGcode(path, { feed: UI_STATE.inputs.feed, depthMm: path.depthMm });
    // 15-sep: pausa, reanudación y ESC con los mismos ganchos que el bordeador
    // (AppState.bord: Play/Pausa, Espacio y ESC ya los atienden) y, en cada línea,
    // la guarda de estado y el homing. Al terminar, de cualquier forma, M5: el
    // G-code del aplanado no lo lleva y el husillo seguía girando.
    const B = window.AppState.bord;
    let abort = false, pausa = false;
    Object.assign(B, {
      active: true, paused: false,
      cancel: () => { abort = true; pausa = B.paused = false; },
      pause: () => { pausa = B.paused = true; },
      resume: () => { pausa = B.paused = false; },
    });
    if (typeof updateButtonStates === 'function') updateButtonStates();
    const aviso = (m, k) => (window.toast || console.log)(m, k);
    try {
      try {
        const rpm = UI_STATE.inputs.rpm;
        // 15-sep: con rampa y T0, como el resto de encendidos del husillo.
        if (RRF_() && rpm > 0) await (RRF_().startSpindleWithRamp ? RRF_().startSpindleWithRamp(rpm) : RRF_().gcode(`T0\nM3 S${Math.round(rpm)}`));
      } catch (e) { aviso('No se pudo encender el husillo', 'warn'); }
      const lines = gcode.split('\n');
      for (let i = 0; i < lines.length; i++) {
        const ln = lines[i];
        if (!ln || ln.startsWith(';')) continue;
        while (pausa && !abort) await new Promise((r) => setTimeout(r, 250));
        if (abort) { aviso('Aplanado cancelado', 'warn'); return; }
        if ((window.machineMoveBlocked && window.machineMoveBlocked(true)) || !window.AppState.limits.allHomed) {
          aviso('Aplanado abortado: la máquina ya no está lista (estado u homing)', 'err'); return;
        }
        if (!RRF_() || typeof RRF_().gcode !== 'function') { aviso('Máquina no conectada — abortando', 'err'); return; }
        try {
          if (!(await RRF_().gcode(ln))) { aviso('Aplanado abortado por error de firmware', 'err'); return; }
        } catch (e) {
          aviso('Aplanado abortado: ' + (e && e.message ? e.message : e), 'err'); return;
        }
      }
      aviso(`Aplanado finalizado (${path.passCount} pasadas)`, 'ok');
    } finally {
      Object.assign(B, { active: false, paused: false, cancel: null, pause: null, resume: null });
      if (typeof updateButtonStates === 'function') updateButtonStates();
      const r = RRF_();
      if (r) Promise.resolve(r.urgentGcode ? r.urgentGcode('M5') : r.gcode('M5')).catch(() => {});
    }
  }

  // ---
  // Render
  // ---
  function renderSummary() {
    const el = $('facingSummary');
    if (!el) return;
    const p = UI_STATE.path;
    // 3-oct: el resumen salia en castellano con la interfaz en ingles.
    const tt = (k, es) => (typeof window.t === 'function' ? window.t(k, es) : es);
    if (!p) { el.textContent = tt('facing.summary.empty', '— Ajusta los valores y pulsa Calcular —'); el.style.color = 'var(--text-3)'; return; }
    el.style.color = 'var(--text-1)';
    el.innerHTML =
      `${tt('facing.summary.passes', 'Pasadas')}: <strong>${p.passCount}</strong> ` +
      `&middot; ${tt('facing.summary.step', 'paso entre filas')}: <strong>${p.stepMm.toFixed(1)} mm</strong> ` +
      `&middot; ${tt('facing.summary.depth', 'profundidad')}: <strong>${p.depthMm} mm</strong> ` +
      `<br>${tt('facing.summary.total', 'Recorrido total')}: <strong>${p.summary.totalLengthMm.toFixed(0)} mm</strong> ` +
      `&middot; ${tt('facing.summary.area', 'área')}: <strong>${p.summary.approxAreaMm2.toFixed(0)} mm²</strong>`;
  }

  function renderWarnings() {
    const el = $('facingWarnings');
    if (!el) return;
    if (!UI_STATE.warnings.length) { el.innerHTML = ''; el.style.display = 'none'; return; }
    el.style.display = 'block';
    el.innerHTML = UI_STATE.warnings.map((w) =>
      `<div style="padding:6px 9px;margin-bottom:6px;border:1px solid var(--warn-strong);background:var(--warn-strong-soft);border-radius:var(--r-sm);font-size:12px;color:var(--text-1)"><strong style="color:var(--warn-strong)">Aviso:</strong> ${escHtml(w)}</div>`,
    ).join('');
  }

  function escHtml(s) {
    return String(s).replace(/[&<>"']/g, (c) => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
    }[c]));
  }

  function updateExecuteButton() {
    const btn = $('btnFacingExecute');
    if (!btn) return;
    const canRun =
      !!UI_STATE.path &&
      !UI_STATE.outOfBounds &&
      !!RRF_() &&
      typeof RRF_().gcode === 'function';
    btn.disabled = !canRun;
    btn.title = canRun ? 'Ejecutar el aplanado en la máquina' : 'Calcula una trayectoria válida con la máquina conectada para habilitar';
  }

  // ---
  // Hooks
  // ---
  function open() {
    if (!$('facingXMin')) return false;  // panel no presente
    writeInputsToUI();
    // Pre-rellenar desde M208 (área por defecto menos margen) si está disponible.
    const sl = window._softLimits || {};
    if (sl.X && sl.X.min != null && sl.X.max != null) {
      const m = UI_STATE.inputs.marginMm || 0;
      UI_STATE.inputs.xMin = sl.X.min + m;
      UI_STATE.inputs.xMax = sl.X.max - m;
    }
    if (sl.Y && sl.Y.min != null && sl.Y.max != null) {
      const m = UI_STATE.inputs.marginMm || 0;
      UI_STATE.inputs.yMin = sl.Y.min + m;
      UI_STATE.inputs.yMax = sl.Y.max - m;
    }
    writeInputsToUI();
    recompute();
    return true;
  }

  function bindOnce() {
    if (window.ROTECHOS_FACING_WIZARD && window.ROTECHOS_FACING_WIZARD.__bound) return;
    const ids = [
      'facingXMin', 'facingXMax', 'facingYMin', 'facingYMax',
      'facingTool', 'facingOverlap', 'facingDepth', 'facingFeed', 'facingRpm', 'facingMargin',
    ];
    for (const id of ids) {
      const el = $(id); if (!el) continue;
      el.addEventListener('change', () => recompute());
    }
    const btnC = $('btnFacingCalc'); if (btnC) btnC.addEventListener('click', () => recompute());
    const btnE = $('btnFacingExecute'); if (btnE) btnE.addEventListener('click', () => execute());
    // Marcamos el módulo como binded para que llamadas posteriores a bindOnce
    // sean no-op (idempotente al re-abrir la pestaña).
    window.ROTECHOS_FACING_WIZARD.__bound = true;
  }

  // ---
  // Exportación
  // ---
  window.FACING = {
    compute: computeFacingPath,
    validate: validateFacingInput,
    checkSoftLimits: checkAgainstSoftLimits,
    buildGcode,
  };
  window.ROTECHOS_FACING_WIZARD = {
    open,
    recompute,
    execute,
    draw: drawPathInViz,
    clearViz: clearVizIfEmpty,
    bindOnce,
    __bound: false,
  };
})();
