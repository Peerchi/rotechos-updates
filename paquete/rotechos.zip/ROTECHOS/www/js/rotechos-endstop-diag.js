// ---
// rotechos-endstop-diag.js — DIAGNÓSTICO ENDSTOP/GPIO EN VIVO
//
// TARJETA t_d0e3f8b6 · FASE 3 del plan de fragmentación del monolito
// (docs/dev/hallazgos/2026-09-09_monolito-diagnostico-y-plan-de-fragmentacion.md §3).
// Extraído del monolito rotechos.js (L6412-6508, bloque 18) tal cual: 97 líneas,
// IIFE autocontenido. Carga LAZY vía `__lazyLoad('/js/rotechos-endstop-diag.js')`
// al primer click en `#btnEndstopDiag` (cableado en el monolito con captura).
//
// Botón de inspección junto a los pills X/Y/Z. Muestra el valor crudo de gpIn[0..5]
// (Y Min, Y Max, Z Min, Z Max, X Max, X Min) actualizándose en cada ciclo.
// Permite diagnosticar problemas de wiring/polaridad sin abrir la consola RRF.
//
// POR QUE ES LAZY (no EAGER)
//   Solo se invoca al pulsar `#btnEndstopDiag`. El botón existe en el DOM desde
//   el primer paint pero NO se renderiza contenido hasta el primer click. Cargar
//   el módulo eagerly añade ~3 KB raw al cold arranque sin contrapartida: el
//   99% de las sesiones NUNCA pulsa ese botón. Migrado a LAZY siguiendo la
//   misma regla del plan §2.2 sobre centinelas — esta ruta NO es FAIL-OPEN
//   (un fallo aquí se ve: el panel no aparece y el click es silencioso), así
//   que se admite el riesgo del primer-tick-latency (~50-100 ms).
//
// POR QUE NO EXPONE NADA EN window.*
//   El panel es autocontenido: lee `_fetchRRF` (monolito), `_endstopCfg`
//   (rotechos-config-modal-core.js, cargado por defer después del monolito),
//   `t(...)` (rotechos-i18n.js) y `escHtml(...)` (rotechos-dom-utils.js).
//   Ningún consumidor externo lo referencia: un fallo de carga degrada al
//   caso sin panel, sin tocar la superficie pública del monolito.
//
// DEPENDENCIAS (todas disponibles en el primer click por orden de defer):
//   - rotechos-dom-utils.js   → $()
//   - rotechos-i18n.js        → t()
//   - rotechos-config-modal-core.js → window._endstopCfg
//   - rotechos.js             → _fetchRRF, TARGET_IP
// ---
(function () {
  const btn = $(`btnEndstopDiag`);
  const panel = $(`endstopDiagPanel`);
  const body = $(`endstopDiagBody`);
  if (!btn || !panel || !body) return;
  let visible = false;
  let iv = null;
  // Mapeo GPIO → axis/side — BTT Scylla V1.0 pinout verificado
  const GPIO_LABELS = [
    { idx: 0, name: `J0 · Y Min · A.8  (PA_8)`,  ax: `Y`, side: `Min` },
    { idx: 1, name: `J1 · Y Max · D.14 (PD_14)`, ax: `Y`, side: `Max` },
    { idx: 2, name: `J2 · Z Min · C.7  (PC_7)`,  ax: `Z`, side: `Min` },
    { idx: 3, name: `J3 · Z Max · D.12 (PD_12)`, ax: `Z`, side: `Max` },
    { idx: 4, name: `J4 · X Max · C.6  (PC_6)`,  ax: `X`, side: `Max` },
    { idx: 5, name: `J5 · X Min · D.11 (PD_11)`, ax: `X`, side: `Min` },
  ];
  async function refresh() {
    try {
      // Pedimos sensors completo (gpIn + probes) en una sola petición para no
      // duplicar tráfico. El panel mostrará ambos: endstops GPIO y la sonda Z.
      const r = await _fetchRRF(`${TARGET_IP}/rr_model?key=sensors&flags=d99`, {}, 2000);
      if (!r.ok) {
        body.textContent = `${t('jog.diag.errHttp', 'Error HTTP')} ${r.status}`;
        body.style.color = `var(--red)`;
        return;
      }
      const data = await r.json();
      const gpIn = data?.result?.gpIn || [];
      const probes = data?.result?.probes || [];
      const rows = GPIO_LABELS.map(({ idx, name, ax, side }) => {
        const v = gpIn[idx]?.value;
        const hasSensor = side === `Min` ? _endstopCfg[ax].minOn : _endstopCfg[ax].maxOn;
        const trigLevel = _endstopCfg[ax].trigLevel ?? 1;

        let display = "";
        if (v === undefined || v === null) {
          display = `<span style="color:var(--text-3)">— (${t('jog.diag.noSignal', 'sin señal')})</span>`;
        } else {
          const rawText = v === 0 ? "0 (LOW)" : "1 (HIGH)";
          if (!hasSensor) {
            display = `<span style="color:var(--text-3)">${rawText} (${t('jog.diag.noConfig', 'sin config')})</span>`;
          } else {
            const isTriggered = v === trigLevel;
            if (isTriggered) {
              display = `<span>${rawText} <strong style="color:var(--red)">[${t('jog.diag.activated', 'ACTIVADO')}]</strong></span>`;
            } else {
              display = `<span>${rawText} <strong style="color:var(--green-strong)">[${t('jog.diag.free', 'LIBRE')}]</strong></span>`;
            }
          }
        }
        return `<div>${name}: ${display}</div>`;
      }).join(``);

      // Fila extra para la sonda Z (M558). value[0] = 0 libre, 1 activada.
      // Útil para verificar que la lógica !/^ del M558 está correcta antes de palpar.
      let probeRow = ``;
      if (probes.length) {
        const pv = Array.isArray(probes[0]?.value) ? probes[0].value[0] : probes[0]?.value;
        // Mismo criterio que el guard de las macros (value > 0). Las sondas
        // inductivas (M558 P5 modulated) reportan un entero (típico 1000) al
        // disparar, no 1. Mostramos el valor crudo para diagnóstico.
        const probeDisplay = typeof pv !== `number`
          ? `<span style="color:var(--text-3)">— (${t('jog.diag.noSignal', 'sin señal')})</span>`
          : pv > 0
          // FIX B-03 (2026-07-05): escHtml por defense-in-depth (pv es número, pero
          // un firmware comprometido podría inyectar HTML vía este campo).
          ? `<span style="color:var(--red)">${escHtml(pv)} (${t('jog.diag.probeActivated', 'ACTIVADA')})</span>`
          : `<span style="color:var(--green-strong)">0 (${t('jog.diag.free', 'LIBRE')})</span>`;
        probeRow = `<div style="margin-top:4px;border-top:1px solid var(--border);padding-top:4px"><strong>${t('jog.diag.probeZ', 'Sonda Z (M558)')}</strong>: ${probeDisplay}</div>`;
      }
      body.innerHTML = rows + probeRow +
        `<div style="color:var(--text-3);margin-top:4px;font-size:10px">gpIn: ${gpIn.length} · probes: ${probes.length}</div>`;
    } catch (e) {
      body.textContent = e.message || t('jog.diag.networkErr', 'error de red');
      body.style.color = `var(--red)`;
    }
  }
  btn.addEventListener(`click`, () => {
    visible = !visible;
    panel.style.display = visible ? `block` : `none`;
    btn.style.background = visible ? `var(--blue)` : `transparent`;
    btn.style.color = visible ? `#fff` : `var(--text-3)`;
    if (visible) {
      refresh();
      iv = setInterval(refresh, 500);
    } else if (iv) {
      clearInterval(iv);
      iv = null;
    }
  });
})();
