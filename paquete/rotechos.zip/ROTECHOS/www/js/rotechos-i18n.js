// rotechos-i18n.js — i18n runtime ligero, SIN build step (se sirve desde la SD).
// ES = idioma fuente: el texto original ya vive en el HTML/JS; aquí solo se
// definen los OVERRIDES en inglés. Mecanismo:
//   · HTML estático: añade data-i18n="clave" al elemento. El motor reemplaza
//     SOLO los nodos de texto directos (preserva los <svg> internos).
//   · JS dinámico:   usa window.t("clave","texto ES por defecto").
// El idioma persiste en localStorage y se conmuta con el <select id=langSelect>
// de CONFIGURACIÓN. Ampliar la cobertura = añadir claves a DICT.en + data-i18n.
(function () {
  const DICT = {
    en: {
      // ── Controles operativos (cockpit) ──
      "qa.homeall": "HOME ALL",
      "qa.probez": "PROBE Z",
      "qa.tool": "TOOL / M6",
      // (t_73119cd8) "RAPID ZERO" era ambiguo: cero de pieza o de máquina. El
      // botón va al WCS X0,Y0 (origen de trabajo); el sufijo "PART" lo aclara.
      "qa.goto0": "GO PART 0",
      // (t_df203d89) "PARK Z" enganaba: park.g mueve los TRES ejes
      // (X0, Y max y Z arriba, todo en G53), no solo Z. La tarjeta
      // t_73119cd8 lo habia puesto asi para "indicar el destino", pero
      // partia de una premisa falsa. No revertir sin leer park.g.
      "qa.park": "PARK",
      "ctl.recover": "RE-ARM",
      "ctl.reArmSensors": "RE-ARM SENSORS",
      "ctl.reset": "RESTART MACHINE",
      // (t_73119cd8) "CANCEL" junto al botón de PARO confundía: ¿cancela qué?
      // Es la parada limpia de TRABAJO (M25+M0). Mantenemos la lógica de
      // soft-stop (conserva WCS, sin reboot), pero la etiqueta lo dice.
      "ctl.stop": "ABORT JOB",
      "state.title": "STATUS",
      // ── Wizard de bienvenida ──
      "wlc.title": "Welcome to RotechOS",
      "wlc.sub1": "CNC control panel · step 1 of 3",
      "wlc.langQ": "Interface language / Idioma de la interfaz:",
      "wlc.skip": "Skip introduction",
      "wlc.t2": "The essentials in 20 seconds",
      "wlc.sub2": "step 2 of 3",
      "wlc.b1.lbl": "E-STOP (emergency)",
      "wlc.b1": "— a large red octagonal button: it stops EVERYTHING instantly. It stays on screen at all times, on every view. Before touching the machine, locate it.",
      "wlc.b2.lbl": "JOG (manual moves)",
      "wlc.b2": "— nudge the X, Y and Z axes step by step with buttons, without running a program. The first time, the machine will ask for Home (seek the endstops) before letting you move anything.",
      "wlc.b3.lbl": "ZERO (workpiece origin)",
      "wlc.b3": "— the point X=0, Y=0, Z=0 from where the machine understands your workpiece starts. It is set before every job.",
      "wlc.b4l": "SETTINGS",
      "wlc.b4": "— machine parameters, safety limits and a glossary. The 'WIKI CNC' tab translates terms like G28 or Z probe.",
      "wlc.school": "Enable School Mode (hover explanations — recommended for beginners)",
      "wlc.back": "Back",
      "wlc.next": "Next",
      "wlc.t3": "First start-up",
      "wlc.sub3": "step 3 of 3 · at the machine",
      "wlc.c1": "Test the physical E-STOP: press it and watch everything stop. Then Re-arm (twist the mushroom button to release it).",
      "wlc.c2": "Push each endstop by hand (the sensor that detects when an axis reaches its limit). Watch the X, Y and Z indicators light up in SETTINGS → ENDSTOPS.",
      "wlc.c3": "Press the HOME button: the machine drives every axis to its limit so it knows where it is. The first time, keep your hand near the E-STOP in case the machine trips.",
      "wlc.c4": "Set the Z height zero with the Z probe (a tab that touches the bit). Then validate with the paper test: lower the bit until a sheet of paper drags with a slight friction.",
      "wlc.go": "Start",
      // ── MI PRIMER CORTE ──
      "fc.title": "MY FIRST CUT",
      "fc.close": "Don't show again",
      "fc.s1": "1. Home the machine",
      "fc.a1": "HOME",
      "fc.s2": "2. Clamp the material",
      "fc.a2": "DONE",
      "fc.s3": "3. Load the G-code",
      "fc.a3": "VIEW",
      "fc.s4": "4. Set workpiece zero",
      "fc.a4": "PROBE Z",
      "fc.s5": "5. Start the cut",
      "fc.a5": "START",
      "fc.hint": "Steps tick themselves as you complete them. Order: machine, material, file, zero, cut.",
      "fc.congrats": "First cut running. The checklist will not appear again.",
      "dlg.noOrigin.title": "WORKPIECE ORIGIN NOT SET",
    },
  };

  // NOTA (deuda técnica documentada 2026-07-05): este módulo escribe/lee
  // localStorage CRUDO a propósito (líneas 72 y 140). Es un módulo BOOTSTRAP
  // STANDALONE, cargado antes que rotechos-storage.js, y debe ser testeable
  // sin depender de STORE (ver tests/unit/i18n.test.js). La clave
  // "rotechos_lang" también aparece en el KEY_MAP de STORE como "i18n.lang"
  // (escritor paralelo): ambos conviven sin pisarse porque el esquema de
  // STORE valida 'es'|'en' y este módulo solo escribe valores válidos.
  // PROHIBIDO migrar este módulo a STORE: rompería el aislamiento y su test.
  let lang = localStorage.getItem("rotechos_lang") || "es";

  // Una traduccion con ${x} recibe el valor en `vars`. Si quedara un ${x} sin
  // valor se devuelve el fallback ya interpolado: nunca un marcador literal
  // (hasta el 25-sep, 56 avisos en ingles salian asi, «Endstop ${ax}…»).
  function t(key, fallback, vars) {
    if (lang === "es") return fallback != null ? fallback : key;
    const d = DICT[lang];
    let s = d && d[key] != null ? d[key] : fallback != null ? fallback : key;
    if (vars) s = s.replace(/\$\{([^}]+)\}/g, (m, k) => (k in vars ? vars[k] : m));
    return s.includes("${") && fallback != null ? fallback : s;
  }

  // Reemplaza solo el primer nodo de texto no vacío; preserva hijos (SVG, spans).
  function setNodeText(el, str) {
    let done = false;
    el.childNodes.forEach((n) => {
      if (n.nodeType === 3 && n.textContent.trim()) {
        n.textContent = done ? "" : str;
        done = true;
      }
    });
    if (!done) el.appendChild(document.createTextNode(str));
  }

  function applyOne(el) {
    const key = el.getAttribute("data-i18n");
    // Contenido con formato inline mezclado (texto <b>…</b> texto): setNodeText
    // vaciaría todo nodo de texto posterior al primero, mutilando la frase
    // (bug jul-2026: 39 elementos afectados, p.ej. los pasos de GUÍA MECANIZADO).
    // Estos se tratan como html: ES restaura el innerHTML original íntegro;
    // EN usa el texto del diccionario (pierde negritas, nunca contenido).
    // El caché i18nHtmlEs va PRIMERO en la condición: tras pasar a EN el DOM ya
    // no tiene <b> y el selector solo no bastaría para reconocerlo en la vuelta.
    if (el.dataset.i18nHtmlEs != null ||
        el.querySelector(":scope > b, :scope > code, :scope > strong, :scope > i, :scope > em")) {
      if (el.dataset.i18nHtmlEs == null) el.dataset.i18nHtmlEs = el.innerHTML;
      el.innerHTML = lang === "es" ? el.dataset.i18nHtmlEs : t(key, el.dataset.i18nHtmlEs);
      return;
    }
    if (el.dataset.i18nEs == null) {
      let orig = "";
      el.childNodes.forEach((n) => {
        if (!orig && n.nodeType === 3 && n.textContent.trim())
          orig = n.textContent.trim();
      });
      el.dataset.i18nEs = orig;
    }
    setNodeText(el, lang === "es" ? el.dataset.i18nEs : t(key, el.dataset.i18nEs));
  }

  // Traducción de ATRIBUTOS (title, data-school de MODO ESCUELA…). Se marca con
  // data-i18n-title / data-i18n-school = "clave" y el motor cambia ese atributo.
  function applyAttr(attrName, keyAttr, esStore) {
    Array.from(document.querySelectorAll("[" + keyAttr + "]")).forEach((el) => {
      const key = el.getAttribute(keyAttr);
      if (el.dataset[esStore] == null)
        el.dataset[esStore] = el.getAttribute(attrName) || "";
      el.setAttribute(
        attrName,
        lang === "es" ? el.dataset[esStore] : t(key, el.dataset[esStore]),
      );
    });
  }

  // Traducción de HTML interno completo (para .mcfg-info-box con <br>, <strong>, etc.)
  function applyHtml(el) {
    const key = el.getAttribute("data-i18n-html");
    if (el.dataset.i18nHtmlEs == null) {
      el.dataset.i18nHtmlEs = el.innerHTML;
    }
    el.innerHTML = lang === "es" ? el.dataset.i18nHtmlEs : t(key, el.dataset.i18nHtmlEs);
  }

  function applyI18n(root) {
    (root || document).querySelectorAll("[data-i18n]").forEach(applyOne);
    (root || document).querySelectorAll("[data-i18n-html]").forEach(applyHtml);
    applyAttr("title", "data-i18n-title", "i18nTitleEs");
    applyAttr("data-school", "data-i18n-school", "i18nSchoolEs");
    applyAttr("placeholder", "data-i18n-placeholder", "i18nPlaceholderEs");
    applyAttr("aria-label", "data-i18n-aria-label", "i18nAriaEs");
    document.documentElement.setAttribute("lang", lang);
  }

  function setLang(l) {
    lang = l === "en" ? "en" : "es";
    localStorage.setItem("rotechos_lang", lang);
    applyI18n();
    window.dispatchEvent(new Event("i18n-change"));
  }

  // Registrar un fragmento de diccionario (cada equipo/área aporta el suyo en un
  // archivo aparte → varios agentes pueden ampliar la cobertura SIN colisionar
  // en este archivo ni en un único objeto DICT).
  function add(obj, l) {
    l = l || "en";
    DICT[l] = Object.assign(DICT[l] || {}, obj);
    if (document.readyState !== "loading") applyI18n();
  }

  window.I18N = { t, applyI18n, setLang, add, DICT, get lang() { return lang; } };
  window.t = t; // atajo para strings dinámicos en el resto del JS

  function init() {
    const sel = document.getElementById("langSelect");
    if (sel) {
      sel.value = lang;
      sel.addEventListener("change", (e) => setLang(e.target.value));
    }
    applyI18n();
  }
  if (document.readyState === "loading")
    document.addEventListener("DOMContentLoaded", init);
  else init();
})();
