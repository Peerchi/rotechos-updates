/* ---
 * rotechos-gcode-viejos.js — Propone borrar los G-code de más de un mes.
 *
 * Petición de Sergi (8-nov-2026): «si hay gcodes de más de un mes, que la
 * interfaz pregunte si quiero borrarlos, y que aparezcan ya seleccionados
 * listos para darle OK».
 *
 * Qué hace
 *   Cuando la lista de 0:/gcodes se carga (fmLoadList, al arrancar y tras
 *   cada subida/borrado) mira la fecha de cada archivo. Si hay alguno con más
 *   de 30 días, abre el diálogo de confirmación con la lista y TODOS
 *   marcados. El operario desmarca lo que quiera conservar y pulsa
 *   «Borrar marcados». «Ahora no» cierra sin tocar nada.
 *
 * Lo que NUNCA hace (y por qué)
 *   - Borrar sin que el operario pulse el botón: el diálogo es la única vía.
 *   - Preguntar con un trabajo en marcha, en pausa, con una macro corriendo o
 *     sin haber leído aún el estado de la placa: al arrancar, SM.current vale
 *     IDLE antes del primer sondeo aunque la máquina esté cortando. Por eso
 *     exige un sondeo bueno (AppState.poll.lastSuccessAt) con la placa en
 *     `idle`. Si no se cumple, lo reintenta más tarde.
 *   - Proponer el archivo cargado (SM.loadedFile): podría ser el siguiente
 *     trabajo. Y antes de borrar vuelve a comprobar todo, por si el estado
 *     cambió con el diálogo abierto.
 *   - Fiarse de una fecha imposible: si el reloj de la placa no estaba en
 *     hora, RRF fecha los archivos en 1980 o en el futuro. Esos se ignoran
 *     (proponerlos sería ofrecer borrar trabajos recientes).
 *   - Tapar otro diálogo: si hay un modal abierto, espera.
 *   - Insistir: pregunta como mucho una vez por sesión del navegador. «Ahora
 *     no» lo calla 7 días. Lo que el operario desmarca se recuerda y no se
 *     le vuelve a proponer (si el archivo se re-sube, cambia la fecha y vale
 *     de nuevo).
 *
 * Estado per-navegador en localStorage (`rotechos-gcode-viejos`): no es
 * estado de máquina, solo la preferencia de quien mira esta pantalla.
 *
 * Dependencias en runtime (globales): confirmDialog, escHtml, t, toast, log,
 * FM, RRF, SM, STATES, AppState, fmLoadList. Todas se consultan con typeof
 * para que el módulo no rompa si falta alguna (tests, layout parcial).
 * --- */
(function () {
  'use strict';

  const DIA_MS = 86400000;
  const DIAS_VIEJO = 30;
  const DIAS_POSPONER = 7;
  const CLAVE = `rotechos-gcode-viejos`;
  const EXT_GCODE = /\.(gcode|g|nc|cnc|tap|txt)\s*$/i;
  // Primer año que tomamos por fecha real. RRF sin reloj fecha en 1980.
  const ANIO_MINIMO = 2020;
  const REINTENTO_MS = 8000;
  const REINTENTOS_MAX = 75; // ~10 min esperando a que la máquina quede libre

  let preguntadoEnSesion = false;
  let reintentoTimer = null;
  let reintentos = 0;
  let enCurso = false;

  // RRF 3.5.4 da `date` como "2026-10-01T12:34:56" (hora local de la placa).
  function fechaDe(f) {
    if (!f || typeof f.date !== `string` || !f.date) return null;
    const d = new Date(f.date);
    const ms = d.getTime();
    if (!Number.isFinite(ms) || d.getFullYear() < ANIO_MINIMO) return null;
    return ms;
  }

  function claveArchivo(f) {
    return `${f.name}|${f.date}`;
  }

  function leerPrefs() {
    try {
      const raw = localStorage.getItem(CLAVE);
      const p = raw ? JSON.parse(raw) : null;
      if (p && typeof p === `object`) {
        return {
          posponerHasta: Number(p.posponerHasta) || 0,
          conservar: Array.isArray(p.conservar) ? p.conservar.filter((s) => typeof s === `string`) : [],
        };
      }
    } catch {}
    return { posponerHasta: 0, conservar: [] };
  }

  function guardarPrefs(p) {
    try {
      localStorage.setItem(CLAVE, JSON.stringify(p));
    } catch {}
  }

  /** Función pura (la usan los tests): qué archivos proponer para borrar. */
  function candidatos(files, ahora, opts) {
    const o = opts || {};
    const cargado = o.cargado || null;
    const conservar = new Set(o.conservar || []);
    const out = [];
    for (const f of files || []) {
      if (!f || f.type !== `f` || typeof f.name !== `string` || !EXT_GCODE.test(f.name)) continue;
      if (cargado && f.name === cargado) continue;
      if (conservar.has(claveArchivo(f))) continue;
      const ms = fechaDe(f);
      if (ms == null || ms > ahora) continue; // sin fecha fiable o en el futuro
      const dias = Math.floor((ahora - ms) / DIA_MS);
      if (dias < DIAS_VIEJO) continue;
      out.push({ name: f.name, size: Number(f.size) || 0, date: f.date, dias });
    }
    // Los más viejos primero.
    out.sort((a, b) => b.dias - a.dias || a.name.localeCompare(b.name));
    return out;
  }

  function hayModalAbierto() {
    return !!document.querySelector(
      `.modal-overlay.show, .tc-modal-overlay.show, .rm-macros-modal.show, .rm-macros-center-modal.show, .bat-modal-overlay.show, #rebootOverlay.show`,
    );
  }

  /** ¿Es seguro preguntar/borrar AHORA? Devuelve null si sí, o el motivo. */
  function motivoParaEsperar() {
    if (typeof SM === `undefined` || typeof STATES === `undefined`) return `sin estado`;
    if (!SM.connected) return `sin conexión`;
    const poll = typeof AppState !== `undefined` ? AppState.poll : null;
    if (!poll || !poll.lastSuccessAt) return `sin sondeo todavía`;
    if (poll.boardStatus && poll.boardStatus !== `idle`) return `placa ocupada (${poll.boardStatus})`;
    if (SM.current !== STATES.IDLE && SM.current !== STATES.READY) return `estado ${SM.current}`;
    if (SM.busy) return `ocupada`;
    if (AppState.macro && (AppState.macro.running || AppState.macro.launching)) return `macro en marcha`;
    if (typeof document !== `undefined` && document.visibilityState === `hidden`) return `pestaña oculta`;
    if (hayModalAbierto()) return `otro diálogo abierto`;
    return null;
  }

  function programarReintento() {
    if (reintentoTimer || reintentos >= REINTENTOS_MAX) return;
    reintentos++;
    reintentoTimer = setTimeout(() => {
      reintentoTimer = null;
      revisar();
    }, REINTENTO_MS);
  }

  function _t(key, es, vars) {
    return typeof t === `function` ? t(key, es, vars) : es;
  }

  function fmtTam(b) {
    return typeof FM !== `undefined` && FM.fmtSize ? FM.fmtSize(b) : `${b} B`;
  }

  function fmtEdad(dias) {
    if (dias >= 60) {
      const meses = Math.floor(dias / 30);
      return _t(`fmOld.edadMeses`, `hace ${meses} meses`, { n: meses });
    }
    return _t(`fmOld.edadDias`, `hace ${dias} días`, { n: dias });
  }

  function textoBoton(n) {
    if (n === 0) return _t(`fmOld.btnNinguno`, `Conservar todos`);
    return n === 1
      ? _t(`fmOld.btnBorrarUno`, `Borrar 1 archivo`)
      : _t(`fmOld.btnBorrarN`, `Borrar ${n} archivos`, { n });
  }

  function cuerpoHtml(lista) {
    const esc = typeof escHtml === `function` ? escHtml : (s) => String(s);
    const filas = lista
      .map(
        (c, i) => `<label class="fmold-item"><input type="checkbox" class="fmold-chk" data-i="${i}" checked>`
          + `<span class="fmold-nombre">${esc(c.name)}</span>`
          + `<span class="fmold-meta">${esc(fmtEdad(c.dias))} · ${esc(fmtTam(c.size))}</span></label>`,
      )
      .join(``);
    const intro = lista.length === 1
      ? _t(`fmOld.introUno`, `Este archivo G-code lleva más de un mes en la máquina. Está marcado para borrarlo; si quieres conservarlo, desmárcalo.`)
      : _t(`fmOld.introN`, `Estos ${lista.length} archivos G-code llevan más de un mes en la máquina. Están todos marcados para borrarlos; desmarca los que quieras conservar.`, { n: lista.length });
    return `<span class="fmold-intro">${esc(intro)}</span>`
      + `<span class="fmold-todos"><button type="button" class="fmold-sel" data-sel="1">${esc(_t(`fmOld.marcarTodos`, `Marcar todos`))}</button>`
      + `<button type="button" class="fmold-sel" data-sel="0">${esc(_t(`fmOld.desmarcarTodos`, `Desmarcar todos`))}</button></span>`
      + `<span class="fmold-lista" role="group" aria-label="${esc(_t(`fmOld.listaAria`, `Archivos de más de un mes`))}">${filas}</span>`
      + `<span class="fmold-nota">${esc(_t(`fmOld.nota`, `Borrar no se puede deshacer. «Ahora no» no borra nada y no vuelve a preguntar en 7 días.`))}</span>`;
  }

  async function preguntar(lista) {
    const msg = typeof document !== `undefined` ? document.getElementById(`confirmMsg`) : null;
    const okBtn = typeof document !== `undefined` ? document.getElementById(`btnConfirmOk`) : null;
    const promesa = confirmDialog(
      _t(`fmOld.titulo`, `Archivos G-code antiguos`),
      cuerpoHtml(lista),
      { confirmText: textoBoton(lista.length), cancelText: _t(`fmOld.ahoraNo`, `Ahora no`) },
    );
    // confirmDialog ya ha pintado el cuerpo (es síncrono hasta el await).
    const chks = () => (msg ? Array.from(msg.querySelectorAll(`.fmold-chk`)) : []);
    const refrescar = () => {
      if (okBtn) okBtn.textContent = textoBoton(chks().filter((c) => c.checked).length);
    };
    if (msg) {
      msg.classList.add(`fmold-msg`);
      msg.addEventListener(`change`, refrescar);
      msg.querySelectorAll(`.fmold-sel`).forEach((b) => b.addEventListener(`click`, (e) => {
        e.preventDefault();
        chks().forEach((c) => { c.checked = b.dataset.sel === `1`; });
        refrescar();
      }));
    }
    const ok = await promesa;
    const marcados = new Set(chks().filter((c) => c.checked).map((c) => Number(c.dataset.i)));
    if (msg) {
      msg.removeEventListener(`change`, refrescar);
      msg.classList.remove(`fmold-msg`);
    }
    return { ok, marcados };
  }

  async function borrar(lista) {
    let bien = 0;
    const fallos = [];
    for (const c of lista) {
      // Re-comprobar ANTES de cada borrado: el estado pudo cambiar con el
      // diálogo abierto (un trabajo lanzado desde otro dispositivo).
      const motivo = motivoParaEsperar();
      if (motivo || (SM.loadedFile && SM.loadedFile === c.name)) {
        fallos.push(c.name);
        typeof log === `function` && log(`gcode-viejos: no borro ${c.name} (${motivo || `archivo cargado`})`, `warn`);
        continue;
      }
      const path = `${(typeof FM !== `undefined` && FM.dir) || `0:/gcodes`}/${c.name}`;
      let r = false;
      try {
        r = await RRF.deleteFile(path);
      } catch {}
      typeof log === `function` && log(`rr_delete (antiguos): ${path} → ${r ? `ok` : `fallo`}`, r ? `cmd` : `err`);
      if (r) bien++;
      else fallos.push(c.name);
    }
    return { bien, fallos };
  }

  async function revisar(files) {
    if (preguntadoEnSesion || enCurso) return;
    const prefs = leerPrefs();
    const ahora = Date.now();
    if (prefs.posponerHasta > ahora) return;
    if (typeof confirmDialog !== `function` || typeof RRF === `undefined` || !RRF.deleteFile) return;

    if (motivoParaEsperar()) {
      programarReintento();
      return;
    }
    enCurso = true;
    try {
      let lista = files;
      if (!Array.isArray(lista)) {
        const data = typeof FM !== `undefined` ? await FM.list() : null;
        lista = (data && data.files) || [];
      }
      const props = candidatos(lista, ahora, { cargado: SM.loadedFile, conservar: prefs.conservar });
      if (!props.length) return;
      // La lista pudo tardar: volver a mirar antes de abrir el diálogo.
      if (motivoParaEsperar()) {
        programarReintento();
        return;
      }
      preguntadoEnSesion = true;
      const { ok, marcados } = await preguntar(props);
      const conservar = new Set(prefs.conservar);
      if (!ok) {
        guardarPrefs({ posponerHasta: Date.now() + DIAS_POSPONER * DIA_MS, conservar: [...conservar] });
        return;
      }
      const aBorrar = props.filter((_, i) => marcados.has(i));
      props.forEach((c, i) => {
        if (!marcados.has(i)) conservar.add(claveArchivo(c));
      });
      // Olvidar los «conservar» de archivos que ya no existen, para que la
      // lista no crezca sin fin.
      const existentes = new Set((lista || []).map((f) => f && claveArchivo(f)));
      guardarPrefs({ posponerHasta: 0, conservar: [...conservar].filter((k) => existentes.has(k)) });
      if (!aBorrar.length) return;
      const { bien, fallos } = await borrar(aBorrar);
      if (typeof toast === `function`) {
        if (!fallos.length) {
          toast(bien === 1
            ? _t(`fmOld.okUno`, `1 archivo antiguo borrado`)
            : _t(`fmOld.okN`, `${bien} archivos antiguos borrados`, { n: bien }), `ok`);
        } else {
          toast(_t(`fmOld.parcial`, `Borrados ${bien}. No se pudieron borrar ${fallos.length}: ${fallos.join(`, `)}`, { n: bien, f: fallos.length, lista: fallos.join(`, `) }), `warn`);
        }
      }
      if (bien && typeof fmLoadList === `function`) fmLoadList();
      if (bien && typeof tvLoadFilesModal === `function` && document.getElementById(`tvFilesModal`)?.classList.contains(`show`)) {
        tvLoadFilesModal();
      }
    } catch (e) {
      typeof log === `function` && log(`gcode-viejos: ${e?.message || e}`, `warn`);
    } finally {
      enCurso = false;
    }
  }

  window.rotechosGcodeViejos = {
    revisar,
    candidatos,
    // Solo para tests: reinicia el estado de sesión.
    _reset() {
      preguntadoEnSesion = false;
      reintentos = 0;
      enCurso = false;
      if (reintentoTimer) clearTimeout(reintentoTimer);
      reintentoTimer = null;
    },
    DIAS_VIEJO,
    DIAS_POSPONER,
  };
})();
