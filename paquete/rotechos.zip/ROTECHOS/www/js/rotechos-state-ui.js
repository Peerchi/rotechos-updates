/* ---
 * rotechos-state-ui.js — Pintado de la UI reactiva al estado de la máquina.
 *
 * Extraído del monolito (rotechos.js:813-921) en la tarjeta kanban
 * t_ef89f2c5 (bloque 12 del mapa de monolito de Kimi2, jul-2026).
 *
 * QUÉ HACE: lee `SM.current` y `currentLayout`, y repinta los badges de
 * estado de máquina (#machineStatus / #stateTxt / #stateIcon), la barra
 * de progreso (#progressCard / #progBar / #vizProgBar), el panel de
 * reset (#resetPanel), el overlay de error en móvil (#mobileErrorOverlay),
 * el bloqueo del jog en RUNNING (.tv-jog-card / .mpg-jog-section) y las
 * pistas del Modo Escuela (#schoolHint / #schoolHintText).
 *
 * SÍMBOLOS EXTERNOS QUE NECESITA (definidos en el monolito o en módulos
 * cargados antes):
 *   - `SM` (window.SM)        objeto con .connected, .current, .loadedFile
 *   - `STATES` (window.STATES) enum { IDLE, READY, RUNNING, PAUSED, ERROR, ... }
 *   - `STATE_META`            mapa de { key, fallback, cls } por estado (NO exportado
 *                              al global; se lee del closure del monolito vía window
 *                              cuando este módulo se carga después). Aquí lo leemos
 *                              vía `window.STATE_META` si existe; si no, caemos al
 *                              comportamiento del monolito (ver §CARGA).
 *   - `currentLayout`         `'pc'` o `'mobile'` (let en el monolito)
 *   - `$`, `setText`, `t`     helpers DOM/i18n
 *   - `resetProgressPanel`    función del monolito que resetea la barra
 *
 * CARGA: este módulo debe ir ANTES del monolito en index.html. Motivo: el
 * monolito define un bridge local `const updateStateUI = window.updateStateUI`
 * justo después de cargar, y luego una IIFE (línea 4241 del monolito) hace
 * `window.updateStateUI = function () { _origUpdateStateUI(); ... }`. Si el
 * módulo nuevo no se ha cargado antes, _origUpdateStateUI es `function(){}`
 * y el toggle del jog-lock pendant (#pendantJogLock) deja de funcionar.
 *
 * RED DE SEGURIDAD (motivo por el que este bloque ya era extraíble):
 *   - tests/unit/simulating-state.test.js — STATE_META + SIMULATING (extrae
 *     el literal directamente del monolito con regex; mientras STATE_META
 *     siga en rotechos.js este test pasa sin tocarlo).
 *   - tests/e2e-seguridad-avisos.spec.js — 16 verde con mutaciones (S1-S13).
 *     Estos tests verifican el DOM (#machineStatus, overlay, dro-row, etc.),
 *     no llaman a updateStateUI; la extracción no los afecta.
 *   - tests/e2e-simulating-m37-badge.spec.js — verifica #machineStatus y
 *     #stateTxt tras M37; depende del DOM pintado por esta función.
 *
 * NOTA OPERATIVA (PENDIENTE DE BANCO): el comportamiento real en emergencia
 * (pintar PELIGRO / Final de carrera / Soft Limit) solo se confirma con la
 * máquina. Los tests e2e ejercitan el DOM con mock, pero la reacción ante
 * una entrada física de trigger es REQUIERE BANCO.
 * --- */
'use strict';

(function () {
  // Timer privado al módulo (antes era `let progressHideTimer` en el monolito).
  let progressHideTimer = null;

  // t_26b35adb: helper para formatear la duración del último trabajo
  // en algo legible sin recargar el ojo. Acepta segundos (entero) o
  // null/NaN y devuelve '—' si no es usable. Estilo corto: "1h 23m"
  // cuando llega a hora, "12m 04s" cuando es sub-horario.
  function formatDuration(s) {
    if (s === null || s === undefined || !isFinite(s) || s < 0) return `—`;
    s = Math.round(s);
    const h = Math.floor(s / 3600);
    const m = Math.floor((s % 3600) / 60);
    const sec = s % 60;
    if (h > 0) return `${h}h ${String(m).padStart(2, `0`)}m`;
    if (m > 0) return `${m}m ${String(sec).padStart(2, `0`)}s`;
    return `${sec}s`;
  }

  function updateStateUI() {
    // 16-sep: ERROR gana sobre DESCONECTADO. Un paro de emergencia no puede desaparecer
    // del badge porque se caiga la red: con el sondeo vivo tras el PARO (C-10) bastan 3
    // ciclos fallidos para declarar desconexión, y el badge pasaba a «DESCONECTADO» con
    // la máquina parada de emergencia (medido en STATUS-BADGE-2). La caída de red se
    // sigue viendo donde le toca: #connPill y body.disconnected.
    const state = SM.connected || SM.current === STATES.ERROR ? SM.current : "DISCONNECTED",
      // BUG-04 (Gemini UI review): disconnected usa clase propia (gris + blink),
      // NO error (rojo). Mismo motivo: evitar que un microcorte WiFi parezca
      // una alarma física de la fresadora. La traducción i18n cae al fallback
      // "DESCONECTADO" si no hay clave.
      // H-7 (2026-08-17): cuando AppState.sys.firmwareUpdating está activo,
      // el firmware está flasheando. Pintamos badge "ACTUALIZANDO" sobre
      // el estado SM normal (sin alarma, sin resetPanel). El flag es
      // transitorio — el siguiente poll sin 'F' lo desactiva.
      meta = !SM.connected && SM.current !== STATES.ERROR
        ? { key: `state.disconnected`, fallback: `DESCONECTADO`, cls: `disconnected` }
        : (AppState?.sys?.firmwareUpdating
          ? { key: `state.flashing`, fallback: `ACTUALIZANDO…`, cls: `flashing` }
          : STATE_META[state]),
      badge = $(`machineStatus`);
    if (badge) {
      badge.className = `machine-state-badge status-badge status-${meta.cls}`;
      setText(`stateTxt`, t(meta.key, meta.fallback));
      const svg = $(`stateIcon`);
      if (svg) {
        const svgPaths = {
          IDLE: `<path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/>`,
          READY: `<path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/>`,
          RUNNING: `<polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/>`,
          PAUSED: `<circle cx="12" cy="12" r="10"/><line x1="10" y1="15" x2="10" y2="9"/><line x1="14" y1="15" x2="14" y2="9"/>`,
          ERROR: `<polygon points="7.86 2 16.14 2 22 7.86 22 16.14 16.14 22 7.86 22 2 16.14 2 7.86 7.86 2"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/>`,
          // BUG-04 (Gemini UI review): icono distinto del tick de check para
          // que el operario identifique visualmente la desconexión WiFi.
          DISCONNECTED: `<line x1="2" y1="2" x2="22" y2="22"/><path d="M8.5 16.5a5 5 0 0 1 7 0"/><line x1="2" y1="8.5" x2="5.5" y2="12"/><line x1="22" y1="8.5" x2="18.5" y2="12"/><line x1="12" y1="20" x2="12.01" y2="20"/>`,
          // C1 (FASE C): icono SIMULATING — reloj de arena (la máquina piensa,
          // la pieza no se mueve).
          SIMULATING: `<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>`,
          // H-1 (2026-08-17): icono HOMING — casa con flecha hacia abajo
          // (la máquina vuelve a su origen). Diferente del check de IDLE.
          HOMING:    `<path d="M3 9.5L12 3l9 6.5V21H14v-7h-4v7H3z"/>`,
          // H-7 (2026-08-17): icono FLASHING — flecha circular de update
          // (no es el aspa de ERROR).
          FLASHING:  `<path d="M21 12a9 9 0 1 1-3-6.7"/><polyline points="21 4 21 10 15 10"/>`,
        };
        // H-7: cuando el firmware está flasheando, el icono gana prioridad
        // sobre el estado SM (que sigue siendo IDLE/READY en realidad).
        const _iconKey = (AppState?.sys?.firmwareUpdating && `FLASHING`) || state;
        svg.innerHTML = svgPaths[_iconKey] || svgPaths.IDLE;
      }
    }
    // ── Tarjeta del último trabajo (t_26b35adb) ──
    // Se muestra solo en IDLE (en RUNNING/PAUSED/READY gana #progressCard,
    // que vive en el mismo orden 4 por la regla @media 1025px). En ERROR
    // gana #resetPanel — la atención no debe competir con la alarma.
    // El dato vive en STORE (clave jobhistory.last, tipo json) y se escribe
    // al cerrar un trabajo en rotechos-modules.js:779; aqui no hace falta
    // cargar el modulo perezoso del historial.
    const lastJobCard = $(`lastJobCard`);
    if (lastJobCard) {
      if (state === STATES.IDLE) {
        let last = null;
        try { last = STORE && typeof STORE.get === `function` ? STORE.get(`jobhistory.last`) : null; } catch (_) {}
        if (last && (last.file || last.date || typeof last.duration === `number`)) {
          // Etiqueta: el nombre del fichero. Sin barra: el operario quiere ver
          // QUE trabajo fue, no su porcentaje (la barra queda reservada para
          // el trabajo en curso en #progressCard).
          const fileEl = $(`lastJobFile`);
          if (fileEl) fileEl.textContent = last.file || `—`;
          // Fecha compacta: el campo ya viene en es-ES (toLocaleString del
          // cierre del trabajo en rotechos-modules.js:772). Si no se puede
          // leer, queda como guion.
          const dateEl = $(`lastJobDate`);
          if (dateEl) dateEl.textContent = last.date || `—`;
          // Duracion: viene en segundos. Formato corto: 1h 23m o 12m 04s.
          const durEl = $(`lastJobDuration`);
          if (durEl) durEl.textContent = formatDuration(typeof last.duration === `number` ? last.duration : null);
          // Etiqueta de estado a la derecha: solo color del badge, sin
          // contenido variable (los literales son cortos y ya estan en
          // espanol en el codigo de cierre).
          const tagEl = $(`lastJobStatus`);
          if (tagEl) {
            const s = last.status || `unknown`;
            tagEl.dataset.status = s;
            tagEl.textContent = ({
              completed: `OK`,
              error: `ERROR`,
              canceled: `CANCELADO`
            })[s] || s.toUpperCase();
          }
          lastJobCard.classList.add(`visible`);
        } else {
          // Sin historial todavia: el hueco bajo el rail NO se llena con un
          // placeholder (Sergi lo quiere util, no decorativo). La tarjeta
          // queda oculta y el rail respira el aire que ya tenia.
          lastJobCard.classList.remove(`visible`);
        }
      } else {
        // Fuera de IDLE: nunca se muestra. La barra de progreso (#progressCard)
        // o el panel de reset (#resetPanel) ocupan ese rol en su caso.
        lastJobCard.classList.remove(`visible`);
      }
    }
    const stateFileRow = $(`stateFileRow`);
    stateFileRow.style.display = `none`;
    const progCard = $(`progressCard`);
    if (
      state === STATES.READY &&
      SM.loadedFile &&
      $(`progBar`).style.transform !== `scaleX(0)`
    ) {
      $(`progBar`).style.transform = `scaleX(1)`;
      setText(`progPct`, `100%`);
      setText(`progPctInner`, `100%`);
      $(`vizProgBar`).style.transform = `scaleX(1)`;
      setText(`vizProgPct`, `100%`);
      progCard.classList.add(`visible`);
      if (progressHideTimer) clearTimeout(progressHideTimer);
      progressHideTimer = setTimeout(() => {
        progCard.classList.remove(`visible`);
        resetProgressPanel();
        progressHideTimer = null;
      }, 2500);
    } else if (state === STATES.RUNNING || state === STATES.PAUSED) {
      if (progressHideTimer) {
        clearTimeout(progressHideTimer);
        progressHideTimer = null;
      }
      progCard.classList.add(`visible`);
    } else {
      if (progressHideTimer) {
        clearTimeout(progressHideTimer);
        progressHideTimer = null;
      }
      progCard.classList.remove(`visible`);
      (state === STATES.IDLE || state === STATES.ERROR) && resetProgressPanel();
    }
    const resetPanel = $(`resetPanel`);
    resetPanel && resetPanel.classList.toggle(`visible`, state === STATES.ERROR);
    const mobileError = $(`mobileErrorOverlay`);
    if (mobileError) {
      mobileError.classList.toggle(`show`, state === STATES.ERROR && currentLayout !== `pc`);
    }
    // t_da03dda6: el botón de PARO debe distinguir ACCION de ESTADO. En
    // reposo describe la acción que se va a ejecutar ("PARO EMERGENCIA");
    // con el paro activo (SM=ERROR) describe el estado de la máquina
    // ("PARO ACTIVO / M112 ENVIADO"). El operario, a dos metros, distingue
    // el rojo en pulso del rojo plano sin tener que leer. El cambio se
    // sincroniza con la transición del SM: no se queda enganchado si el
    // SM pasa a IDLE/READY sin pasar antes por la rama de cleanup.
    const estopBtn = $(`btnEStop`);
    if (estopBtn) {
      // 16-sep: `state` ya respeta el paro por encima de la desconexión (arriba), así que
      // botón y badge comparten UN solo criterio. Antes el botón volvía a decir «PARO /
      // EMERGENCIA» con la máquina parada de emergencia (medido en ESTOP-VISUAL-3).
      const _estopActive = state === STATES.ERROR;
      estopBtn.classList.toggle(`estop-active`, _estopActive);
      const _estopText = estopBtn.querySelector(`.estop-text-compact`);
      const _estopSub = estopBtn.querySelector(`.estop-sub-compact`);
      if (_estopText) {
        _estopText.textContent = _estopActive
          ? t(`work.estopActiveLabel`, `PARO ACTIVO`)
          : t(`work.estopLabel`, `PARO`);
      }
      if (_estopSub) {
        _estopSub.textContent = !_estopActive ? t(`work.estopSub`, `EMERGENCIA`)
          : SM._estopM112 === `fallo` ? t(`work.estopNoEntregado`, `M112 NO ENTREGADO: USA LA SETA`)
            : SM._estopM112 === `enviando` ? t(`work.estopEnviando`, `ENVIANDO M112…`)
              : t(`work.estopActiveSub`, `M112 ENVIADO`);
      }
    }
    const jogCard = $(`jogCard`);
    state === STATES.RUNNING
      ? (jogCard.classList.add(`jog-locked`),
        $(`jogPanel`).classList.add(`hidden`))
      : (jogCard.classList.remove(`jog-locked`),
        $(`jogPanel`).classList.remove(`hidden`));
    const isRunning = state === STATES.RUNNING;
    (document
      .querySelector(`.tv-jog-card`)
      ?.classList.toggle(`jog-locked-tv`, isRunning),
      document
        .querySelector(`.mpg-jog-section`)
        ?.classList.toggle(`jog-locked-mpg`, isRunning));
    // ── Pistas contextuales (solo en Modo Escuela) ──
    const _hintEl = $(`schoolHint`), _hintTxt = $(`schoolHintText`);
    if (_hintEl && _hintTxt) {
      if (!document.body.classList.contains(`school-mode`)) {
        _hintEl.style.display = `none`;
      } else {
        let _hint = ``;
        if (state === STATES.IDLE && !SM.loadedFile)
          _hint = t(`school.hintIdleNoFile`, `Carga un archivo G-code desde el panel ARCHIVOS para empezar.`);
        else if (state === STATES.IDLE && SM.loadedFile)
          _hint = t(`school.hintIdleFile`, `Archivo cargado. Haz Home All (G28) si aún no lo has hecho, luego pulsa INICIAR TRABAJO.`);
        else if (state === STATES.READY)
          _hint = t(`school.hintReady`, `Verifica que el origen XYZ está sobre la pieza y pulsa INICIAR TRABAJO.`);
        else if (state === STATES.RUNNING)
          _hint = t(`school.hintRunning`, `Trabajo en curso. Puedes ajustar el avance y el husillo con los overrides. Pulsa PAUSA si necesitas intervenir.`);
        else if (state === STATES.PAUSED)
          _hint = t(`school.hintPaused`, `Trabajo pausado. Pulsa REANUDAR para continuar o ESC / QUITAR para cancelar.`);
        else if (state === STATES.ERROR)
          _hint = t(`school.hintError`, `Error detectado. Pulsa REINICIAR para resetear el firmware, luego haz Home All (G28) obligatoriamente.`);
        _hintEl.style.display = _hint ? `block` : `none`;
        _hintTxt.textContent = _hint;
      }
    }
  }

  // Publica en window. El monolito hace `const updateStateUI = window.updateStateUI`
  // justo después para que las 5 invocaciones internas (`updateStateUI()` en líneas
  // 745, 763, 1256, 3318, 3620) sigan funcionando, y luego la IIFE initMobileButtons
  // (monolito:4241-4250) hace `window.updateStateUI = function () { _origUpdateStateUI(); ... }`.
  // Sin la exportación previa a `window.updateStateUI`, el monkey-patch perdería
  // la referencia al original y el jog-lock pendant (#pendantJogLock) dejaría de
  // togglear.
  // ── AT-06 (2026-08-31): el 100% del final de trabajo duraba un sondeo ──
  // Al terminar un trabajo, este modulo pinta 100% y arma un auto-hide de
  // 2,5 s. Pero `updateProgressPanel` (rotechos.js:1484) arranca con `pct = 0`
  // y solo la calcula `if (isActive)` — y en READY isActive es false. Asi que
  // el siguiente ciclo de sondeo, a menos de un segundo, repintaba la barra a
  // 0% ENCIMA del 100% recien puesto. El operario terminaba su pieza y veia un
  // parpadeo a cero en vez del 100%.
  //
  // Medido en navegador el 2026-08-31: con el sondeo vivo, transform acababa
  // en `scaleX(0)` y el texto en `0%`; matando el sondeo justo antes de la
  // transicion, `scaleX(1)` y `100%`, y se mantenia. Lo cazaba
  // `tests/e2e-area-trabajo-principal.spec.js:528` (AT-06), rojo determinista
  // 5/5 y anterior a esta sesion.
  //
  // El timer es privado del modulo a proposito, asi que en vez de exponerlo se
  // expone la PREGUNTA: "¿estoy enseñando el remate del trabajo?". El monolito
  // solo necesita saber eso para no pisar la barra.
  window.progresoRemateActivo = function () { return progressHideTimer !== null; };

  window.updateStateUI = updateStateUI;

  // t_080e0a9d (Fase 4.4 resto, 2026-09-02): refresca el badge HOME de la
  // pestaña Soft Limits y el SVG del volumen en cada poll. Es un noop si la
  // pestaña no está en DOM (modal cerrado). Guard explícito: este módulo se
  // carga ANTES que rotechos-config-modal.js en algunos órdenes de carga
  // (los IIFEs se evalúan en orden de <script>), así que protegemos la
  // llamada con `typeof` para no lanzar si refreshSoftLimitsUI aún no existe.
  // Se ejecuta AL FINAL del updateStateUI: si el badge está pintado con
  // allHomed anterior, lo refresca. Coste: 1 lookup + una asignación por
  // poll (250 ms de cadencia) → despreciable.
  try {
    if (typeof refreshSoftLimitsUI === `function`) refreshSoftLimitsUI();
  } catch (_e) { /* DOM no listo o modal cerrado — noop silencioso */ }
})();
