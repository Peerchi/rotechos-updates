/* ---
 * rotechos-state-ui.js — Pintado de la UI reactiva al estado de la máquina.
 *
 * QUÉ HACE: lee `SM.current` y `currentLayout` y repinta los badges de
 * estado (#machineStatus / #stateTxt / #stateIcon), la barra de progreso
 * central del visor, el panel de reset, el overlay de error en móvil, el
 * bloqueo del jog en RUNNING (.tv-jog-card / .mpg-jog-section) y las pistas
 * del Modo Escuela (#schoolHint / #schoolHintText).
 *
 * SÍMBOLOS EXTERNOS: `SM`, `STATES`, `STATE_META`, `currentLayout`, `$`,
 * `setText`, `t` y `resetProgressPanel` (definidos en el monolito o en
 * módulos cargados antes).
 *
 * CARGA: debe ir ANTES del monolito en index.html. El monolito captura
 * `window.updateStateUI` al cargar y luego lo envuelve; si este módulo no
 * se cargó antes, el toggle del jog-lock pendant (#pendantJogLock) deja de
 * funcionar.
 *
 * NOTA OPERATIVA (PENDIENTE DE BANCO): el comportamiento real en emergencia
 * (PELIGRO / Final de carrera / Soft Limit) solo se confirma con la máquina.
 * Los tests e2e usan mock; la reacción a un trigger físico es REQUIERE BANCO.
 * --- */
'use strict';

(function () {
  function renderStartPreparation() {
    if (typeof AppState === `undefined` || !AppState.ui) return;
    const readout = AppState.ui.startReadout || {};
    const known = SM.connected;
    const home = known ? AppState.limits.allHomed : undefined;
    const wi = known ? readout.workplaceNumber : undefined;
    const noFile = t(`work.noFile`, `Sin archivo`);
    const fileName = String(readout.fileName || SM.loadedFile || ``).replace(/^.*[\\/]/, ``);
    const homeText = home === true ? t(`pendant.home.ok`, `HOME OK`) : home === false ? t(`pendant.home.notHomed`, `SIN HOME`) : t(`work.prepHomeUnknown`, `HOME —`);
    const wcsText = Number.isInteger(wi) && wi >= 0 ? `G${54 + wi}` : t(`work.prepWcsUnknown`, `WCS —`);
    // En el botón INICIAR TRABAJO solo va el estado de preparación (HOME/WCS y
    // overrides); el nombre del G-code vive en la cabecera del visor.
    const prepParts = [homeText, wcsText];
    for (const [value, key, label] of [[known ? readout.feedPct : undefined, `work.prepFeed`, `Avance`],
      [AppState.ui.spindleOverridePct, `work.prepSpindle`, `Husillo`]]) {
      if (Number.isFinite(value) && Math.round(value) !== 100) prepParts.push(`${t(key, label)} ${Math.round(value)}%`);
    }
    const prepText = prepParts.join(` · `);
    // El pendant y su botón sí conservan el nombre junto a la preparación.
    const fullText = [fileName || noFile, ...prepParts].join(` · `);
    // Misma preparación que escritorio; CSS solo muestra el motivo si está deshabilitado.
    const reason = $(`mpgStartReason`);
    if (reason) writeText(reason, !fileName ? noFile : home !== true ? homeText : fullText);
    const startPreparation = $(`startPreparation`);
    if (startPreparation) { writeText(startPreparation, prepText); startPreparation.title = prepText; }
    const pendantFname = $(`pendant2RunFname`);
    if (pendantFname) { writeText(pendantFname, fullText); pendantFname.title = fullText; }
    $(`btnPlayPause`)?.setAttribute(`aria-describedby`, `schoolTipBubble startPreparation`);
    for (const id of [`mpgBtnStart`, `pendant2RunBtnStart`]) {
      const btn = $(id);
      if (btn) { btn.title = fullText; btn.setAttribute(`aria-describedby`, id === `mpgBtnStart` ? `mpgStartReason pendant2RunFname` : `pendant2RunFname`); }
    }
  }
  // Copia de presentación del sondeo existente; no consulta ni ordena a la máquina.
  function registerStartPreparation() {
    registerUIHook(`start-preparation`, (data) => {
      AppState.ui.startReadout = { fileName: data?.jobModel?.file?.fileName,
        workplaceNumber: data?.move?.workplaceNumber, feedPct: data?.params?.speedFactor };
      renderStartPreparation();
    });
  }
  if (typeof registerUIHook === `function`) registerStartPreparation();
  else window.addEventListener?.(`DOMContentLoaded`, registerStartPreparation);
  window.addEventListener?.(`i18n-change`, renderStartPreparation);

  let progressHideTimer = null;

  // t_26b35adb: helper para formatear la duración del último trabajo
  // en algo legible sin recargar el ojo. Acepta segundos (entero) o
  // null/NaN y devuelve '—' si no es usable. Estilo corto: "1h 23m"
  // cuando llega a hora, "12m 04s" cuando es sub-horario.
  function formatDuration(s) {
    if (s === null || s === undefined || !isFinite(s) || s < 0) return `—`;
    s = Math.round(s);
    const h = Math.floor(s / 3600);
    const m = Math.floor((s % 3600) / 60);
    const sec = s % 60;
    if (h > 0) return `${h}h ${String(m).padStart(2, `0`)}m`;
    if (m > 0) return `${m}m ${String(sec).padStart(2, `0`)}s`;
    return `${sec}s`;
  }

  // Persistencia visual: si el sondeo ya repuso SM.loadedFile desde job.file,
  // cualquier repintado de estado debe conservar la cabecera del visor y el
  // botón QUITAR. Solo rellena cuando están vacíos: no pisa «Procesando…», un
  // error del visor ni un archivo que la UI tenga cargado por su cuenta.
  function syncLoadedFileView() {
    if (!SM.loadedFile) return;
    const name = String(SM.loadedFile).replace(/^.*[\\/]/, ``);
    const vfn = $(`vizFileName`);
    if (vfn && (!String(vfn.textContent || ``).trim() || vfn.textContent === t(`msg.noFile`, `Sin archivo`)))
      vfn.textContent = name;
    const clearBtn = $(`vizClearFile`);
    if (clearBtn && clearBtn.style.display === `none`) clearBtn.style.display = `flex`;
  }

  function updateStateUI() {
    renderStartPreparation();
    syncLoadedFileView();
    // 16-sep: ERROR gana sobre DESCONECTADO. Un paro de emergencia no puede desaparecer
    // del badge porque se caiga la red: con el sondeo vivo tras el PARO (C-10) bastan 3
    // ciclos fallidos para declarar desconexión, y el badge pasaba a «DESCONECTADO» con
    // la máquina parada de emergencia (medido en STATUS-BADGE-2). La caída de red se
    // sigue viendo donde le toca: #connPill y body.disconnected.
    const state = SM.connected || SM.current === STATES.ERROR ? SM.current : "DISCONNECTED",
      // BUG-04 (Gemini UI review): disconnected usa clase propia (gris + blink),
      // NO error (rojo). Mismo motivo: evitar que un microcorte WiFi parezca
      // una alarma física de la fresadora. La traducción i18n cae al fallback
      // "DESCONECTADO" si no hay clave.
      // H-7 (2026-08-17): cuando AppState.sys.firmwareUpdating está activo,
      // el firmware está flasheando. Pintamos badge "ACTUALIZANDO" sobre
      // el estado SM normal (sin alarma, sin resetPanel). El flag es
      // transitorio — el siguiente poll sin 'F' lo desactiva.
      meta = !SM.connected && SM.current !== STATES.ERROR
        ? { key: `state.disconnected`, fallback: `DESCONECTADO`, cls: `disconnected` }
        : (AppState?.sys?.firmwareUpdating
          ? { key: `state.flashing`, fallback: `ACTUALIZANDO…`, cls: `flashing` }
          : STATE_META[state]),
      badge = $(`machineStatus`);
    if (badge) {
      badge.className = `machine-state-badge status-badge status-${meta.cls}`;
      setText(`stateTxt`, t(meta.key, meta.fallback));
      const svg = $(`stateIcon`);
      if (svg) {
        const svgPaths = {
          IDLE: `<path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/>`,
          READY: `<path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/>`,
          RUNNING: `<polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/>`,
          PAUSED: `<circle cx="12" cy="12" r="10"/><line x1="10" y1="15" x2="10" y2="9"/><line x1="14" y1="15" x2="14" y2="9"/>`,
          TRANSITIONING: `<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>`,
          ERROR: `<polygon points="7.86 2 16.14 2 22 7.86 22 16.14 16.14 22 7.86 22 2 16.14 2 7.86 7.86 2"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/>`,
          // Icono de desconexión distinto al estado sano para reconocer pérdida de red.
          DISCONNECTED: `<line x1="2" y1="2" x2="22" y2="22"/><path d="M8.5 16.5a5 5 0 0 1 7 0"/><line x1="2" y1="8.5" x2="5.5" y2="12"/><line x1="22" y1="8.5" x2="18.5" y2="12"/><line x1="12" y1="20" x2="12.01" y2="20"/>`,
          SIMULATING: `<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>`,
          HOMING:    `<path d="M3 9.5L12 3l9 6.5V21H14v-7h-4v7H3z"/>`,
          FLASHING:  `<path d="M21 12a9 9 0 1 1-3-6.7"/><polyline points="21 4 21 10 15 10"/>`,
        };
        const _iconKey = (AppState?.sys?.firmwareUpdating && `FLASHING`) || state;
        svg.innerHTML = svgPaths[_iconKey] || svgPaths.IDLE;
      }
    }
    // El pendant no recibe un ciclo de telemetría cuando la red cae: sin este
    // repintado conservaba IDLE/RUNNING y sus coordenadas antiguas, aunque el
    // aviso global ya decía «SIN CONEXIÓN · ESTADO NO FIABLE». El mismo estado
    // resuelto que ve el badge de cabecera debe ganar también en la pantalla
    // que el operario puede tener abierta a pie de máquina.
    const pendantStatePill = $(`mpgStatePill`);
    if (pendantStatePill) {
      pendantStatePill.dataset.state = state;
      setText(`mpgStateTxt`, t(meta.key, meta.fallback));
    }
    // ── Tarjeta del último trabajo (t_26b35adb) ── [NOTAS_JS N028]
    const lastJobCard = $(`lastJobCard`);
    if (lastJobCard) {
      if (state === STATES.IDLE) {
        let last = null;
        try { last = STORE && typeof STORE.get === `function` ? STORE.get(`jobhistory.last`) : null; } catch (_) {}
        if (last && (last.file || last.date || typeof last.duration === `number`)) {
          const fileEl = $(`lastJobFile`);
          if (fileEl) fileEl.textContent = last.file || `—`;
          // Fecha compacta: el campo ya viene en es-ES (toLocaleString del
          // cierre del trabajo en rotechos-modules.js:772). Si no se puede
          // leer, queda como guion.
          const dateEl = $(`lastJobDate`);
          if (dateEl) dateEl.textContent = last.date || `—`;
          const durEl = $(`lastJobDuration`);
          if (durEl) durEl.textContent = formatDuration(typeof last.duration === `number` ? last.duration : null);
          const tagEl = $(`lastJobStatus`);
          if (tagEl) {
            const s = last.status || `unknown`;
            tagEl.dataset.status = s;
            tagEl.textContent = ({
              completed: `OK`,
              error: `ERROR`,
              canceled: `CANCELADO`
            })[s] || s.toUpperCase();
          }
          lastJobCard.classList.add(`visible`);
        } else {
          // Sin historial no se rellena el espacio con un marcador decorativo (decisión de Sergi).
          lastJobCard.classList.remove(`visible`);
        }
      } else {
        lastJobCard.classList.remove(`visible`);
      }
    }
    const stateFileRow = $(`stateFileRow`);
    stateFileRow.style.display = `none`;
    if (
      state === STATES.READY &&
      SM.loadedFile &&
      (SM._lastPct || 0) >= 99
    ) {
      // Remate SOLO si el progreso real llegó al tope: nunca un 100% inventado.
      $(`vizProgBar`).style.transform = `scaleX(1)`;
      setText(`vizProgPct`, `100%`);
      $(`vizProgressPanel`)?.classList.remove(`viz-ov-oculto`);
      if (progressHideTimer) clearTimeout(progressHideTimer);
      progressHideTimer = setTimeout(() => {
        resetProgressPanel();
        progressHideTimer = null;
      }, 2500);
    } else if (state === STATES.RUNNING || state === STATES.PAUSED || state === STATES.TRANSITIONING) {
      if (progressHideTimer) {
        clearTimeout(progressHideTimer);
        progressHideTimer = null;
      }
    } else {
      if (progressHideTimer) {
        clearTimeout(progressHideTimer);
        progressHideTimer = null;
      }
      (state === STATES.IDLE || state === STATES.ERROR) && resetProgressPanel();
    }
    const resetPanel = $(`resetPanel`);
    resetPanel && resetPanel.classList.toggle(`visible`, state === STATES.ERROR);
    const mobileError = $(`mobileErrorOverlay`);
    if (mobileError) {
      mobileError.classList.toggle(`show`, state === STATES.ERROR && currentLayout !== `pc`);
    }
    // t_da03dda6: el botón de PARO debe distinguir ACCION de ESTADO. En
    // reposo describe la acción que se va a ejecutar ("PARO EMERGENCIA");
    // con el paro activo (SM=ERROR) describe el estado de la máquina
    // ("PARO ACTIVO / M112 ENVIADO"). El operario, a dos metros, distingue
    // el rojo en pulso del rojo plano sin tener que leer. El cambio se
    // sincroniza con la transición del SM: no se queda enganchado si el
    // SM pasa a IDLE/READY sin pasar antes por la rama de cleanup.
    const estopBtn = $(`btnEStop`);
    const estopFloat = $(`btnEStopFloat`);
    if (estopBtn || estopFloat) {
      const _estopActive = state === STATES.ERROR;
      [estopBtn, estopFloat].filter(Boolean).forEach((btn) => {
        btn.classList.toggle(`estop-active`, _estopActive);
        btn.dataset.estopState = _estopActive ? `active` : `ready`;
        btn.setAttribute(`aria-label`, _estopActive
          ? t(`work.estopActiveLabel`, `PARO ACTIVO`)
          : t(`aria-label.paro-de-emergencia-3105`, `Paro de emergencia`));
      });
      const _estopText = estopBtn?.querySelector(`.estop-text-compact`);
      const _floatText = estopFloat?.querySelector(`.estop-float-label`);
      const _estopSub = estopBtn?.querySelector(`.estop-sub-compact`);
      if (_estopText) {
        _estopText.textContent = _estopActive
          ? t(`work.estopActiveLabel`, `PARO ACTIVO`)
          : t(`work.estopLabel`, `PARO`);
      }
      if (_floatText) {
        _floatText.textContent = _estopActive
          ? t(`work.estopActiveLabel`, `PARO ACTIVO`)
          : t(`work.estopLabel`, `PARO`);
      }
      if (_estopSub) {
        _estopSub.textContent = !_estopActive ? t(`work.estopSub`, `EMERGENCIA`)
          : SM._estopM112 === `fallo` ? t(`work.estopNoEntregado`, `M112 NO ENTREGADO: USA LA SETA`)
            : SM._estopM112 === `enviando` ? t(`work.estopEnviando`, `ENVIANDO M112…`)
              : t(`work.estopActiveSub`, `M112 ENVIADO`);
      }
    }
    const jogCard = $(`jogCard`);
    state === STATES.RUNNING
      ? (jogCard.classList.add(`jog-locked`),
        $(`jogPanel`).classList.add(`hidden`))
      : (jogCard.classList.remove(`jog-locked`),
        $(`jogPanel`).classList.remove(`hidden`));
    const isRunning = state === STATES.RUNNING;
    (document
      .querySelector(`.tv-jog-card`)
      ?.classList.toggle(`jog-locked-tv`, isRunning),
      document
        .querySelector(`.mpg-jog-section`)
        ?.classList.toggle(`jog-locked-mpg`, isRunning));
    const _hintEl = $(`schoolHint`), _hintTxt = $(`schoolHintText`);
    if (_hintEl && _hintTxt) {
      if (!document.body.classList.contains(`school-mode`)) {
        _hintEl.style.display = `none`;
      } else {
        let _hint = ``;
        if (state === STATES.IDLE && !SM.loadedFile)
          _hint = t(`school.hintIdleNoFile`, `Carga un archivo G-code desde el panel ARCHIVOS para empezar.`);
        else if (state === STATES.IDLE && SM.loadedFile)
          _hint = t(`school.hintIdleFile`, `Archivo cargado. Haz Home All (G28) si aún no lo has hecho, luego pulsa INICIAR TRABAJO.`);
        else if (state === STATES.READY)
          _hint = t(`school.hintReady`, `Verifica que el origen XYZ está sobre la pieza y pulsa INICIAR TRABAJO.`);
        else if (state === STATES.RUNNING)
          _hint = t(`school.hintRunning`, `Trabajo en curso. Puedes ajustar el avance y el husillo con los overrides. Pulsa PAUSA si necesitas intervenir.`);
        else if (state === STATES.PAUSED)
          _hint = t(`school.hintPaused`, `Trabajo pausado. Pulsa REANUDAR para continuar o ESC / QUITAR para cancelar.`);
        else if (state === STATES.ERROR)
          _hint = t(`school.hintError`, `Error detectado. Pulsa REINICIAR para resetear el firmware, luego haz Home All (G28) obligatoriamente.`);
        _hintEl.style.display = _hint ? `block` : `none`;
        _hintTxt.textContent = _hint;
      }
    }
  }

  // Publica en window antes de que el monolito capture `const updateStateUI =
  // window.updateStateUI`; sin esto, el monkey-patch de initMobileButtons
  // pierde el original y el jog-lock pendant (#pendantJogLock) deja de togglear.
  // ── AT-06 (2026-08-31): el 100% del final de trabajo duraba un sondeo ──
  // updateProgressPanel arranca en 0% y en READY no calcula pct, así que el
  // siguiente poll pisaba el 100% recién pintado. El timer es privado; se
  // expone la pregunta para que el monolito no pise la barra durante el remate
  // (tests/e2e-area-trabajo-principal.spec.js:528).
  window.progresoRemateActivo = function () { return progressHideTimer !== null; };

  window.updateStateUI = updateStateUI;

  // t_080e0a9d (Fase 4.4 resto, 2026-09-02): refresca el badge HOME de la
  // pestaña Soft Limits y el SVG del volumen en cada poll. Es un noop si la
  // pestaña no está en DOM (modal cerrado). Guard explícito: este módulo se
  // carga ANTES que rotechos-config-modal.js en algunos órdenes de carga
  // (los IIFEs se evalúan en orden de <script>), así que protegemos la
  // llamada con `typeof` para no lanzar si refreshSoftLimitsUI aún no existe.
  // Se ejecuta AL FINAL del updateStateUI: si el badge está pintado con
  // allHomed anterior, lo refresca. Coste: 1 lookup + una asignación por
  // poll (250 ms de cadencia) → despreciable.
  try {
    if (typeof refreshSoftLimitsUI === `function`) refreshSoftLimitsUI();
  } catch (_e) {  }
})();
