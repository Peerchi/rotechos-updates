// rotechos-apdetector.js — banner de modo AP y salto a CONFIGURACIÓN → Red (WiFi).
// Fachada del bloque que vivía en rotechos.js: publica window.APDetector con la
// misma firma, y los efectos de arranque van en init(), que llama bootStep4.
// EAGER a propósito: con la máquina en modo AP el banner tiene que verse en el
// primer arranque, que es cuando el operario no sabe cómo conectarse.
// Razones e historia: docs/dev/hallazgos/2026-09-09_monolito-diagnostico-y-plan-de-fragmentacion.md §3.
const APDetector = (function () {
  // 18-oct (E1): alfabeto legible para la etiqueta; excluye 0/o/1/l.
  const AP_KEY_ALPHABET = `abcdefghijkmnpqrstuvwxyz23456789`;
  const AP_KEY_LENGTH = 12;
  function validKey(value) {
    return typeof value === `string` && /^[a-z2-9]{8,63}$/.test(value) &&
      [...value].every((ch) => AP_KEY_ALPHABET.includes(ch));
  }
  function generateKey() {
    if (!globalThis.crypto?.getRandomValues) return null;
    const out = [];
    const limit = 256 - (256 % AP_KEY_ALPHABET.length);
    const buf = new Uint8Array(16);
    while (out.length < AP_KEY_LENGTH) {
      globalThis.crypto.getRandomValues(buf);
      for (const n of buf) {
        if (n >= limit) continue;
        out.push(AP_KEY_ALPHABET[n % AP_KEY_ALPHABET.length]);
        if (out.length === AP_KEY_LENGTH) break;
      }
    }
    return out.join(``);
  }
  let _lastCheck = 0;
  let _lastState = null;        // 'ap' | 'client' | 'unknown'
  // 6-oct: global.netApOnly — el operario eligió trabajar con la red propia. Entonces
  // la red RotechOS no es un aviso sino su modo normal, y el banner no sale.
  let _apOnly = false;
  const CACHE_MS = 30000;
  function _render(state, force) {
    if (state === _lastState && !force) return;
    _lastState = state;
    const banner = $(`apModeBanner`);
    if (!banner) return;
    banner.style.display = state === `ap` && !_apOnly ? `flex` : `none`;
    if (state === `ap`) log(`APDetector: UI conectada al AP RotechOS (banner mostrado)`, `sys`);
  }
  async function _check(force = false) {
    if (!force && Date.now() - _lastCheck < CACHE_MS) return _lastState;
    _lastCheck = Date.now();
    try {
      // network.interfaces[0] devuelve {state, actualIP, ssid, ...}
      const r = await _fetchModel(`network.interfaces[0]`, 3000);
      const nw = r && _unwrap(r);
      if (!nw) return _lastState;
      // El indicador de la cabecera dice por dónde está conectada (cable directo,
      // WiFi, red propia) desde el arranque, sin esperar al poll de `network`.
      if (typeof setConnLink === `function`) { try { setConnLink({ interfaces: [nw] }); } catch (e) {} }
      // SSID del AP por defecto = "RotechOS" (wifi-passwords.g:16).
      // Si la UI corre sobre 192.168.1.1 y el ssid es ese, es AP mode.
      const ssid = (nw.ssid || ``).toString();
      const ip = (nw.actualIP || ``).toString();
      const isAp = ssid === `RotechOS` || (ip.startsWith(`192.168.1.`) && ssid === `RotechOS`);
      _render(isAp ? `ap` : `client`);
      return _lastState;
    } catch (e) {
      // Si el fetch falla, no tocamos el estado (caché del último conocido).
      return _lastState;
    }
  }
  // «Seguir con esta red» del banner: la máquina se queda en su red propia y arranca
  // así a partir de ahora. net_ap.g pone global.netApOnly en caliente (ya está en el
  // AP, no cambia nada más); config-machine.g lo guarda para los arranques.
  async function _stay() {
    _apOnly = true;
    _render(_lastState, true);
    try {
      await RRF.gcode(`M98 P"0:/sys/net_ap.g"`);
      const ok = typeof cfgPersistGlobalLine === `function`
        ? await cfgPersistGlobalLine(`netApOnly`, `global netApOnly = true`) : false;
      toast(ok
        ? t(`msg.wifiApStay`, `La máquina trabajará siempre con su red RotechOS. Puedes cambiarlo en CONFIGURACIÓN → Red.`)
        : t(`msg.wifiApStayNoGuardado`, `Sigues en la red RotechOS, pero no se pudo guardar para los próximos arranques. Repítelo desde CONFIGURACIÓN → Red.`),
      ok ? `ok` : `warn`);
      log(`APDetector: red propia elegida (netApOnly=true${ok ? `` : `, sin persistir`})`, `sys`);
    } catch (e) {
      LOG?.warn?.(`APDetector _stay:`, e);
    }
  }
  async function openConfig() {
    // El await evita que openMachineConfig() entierre la pestaña; el click real carga rotechos-modules.js.
    try {
      await __openMachineConfig();
      if (typeof openMachineConfig !== `function`) throw new Error(`__openMachineConfig no produjo función`);
    } catch (_) {
      $(`btnSysManager`)?.click();
    }
    const netTab = document.querySelector(`.mcfg-tab[data-tab=network]`);
    if (netTab && !netTab.classList.contains(`active`)) {
      netTab.click();
    }
    log(`APDetector: usuario redirigido a CONFIGURACIÓN → Red (WiFi)`, `sys`);
  }
  // Enganchado al ciclo de sondeo: el poll ya trae network.interfaces[0] (o la
  // sirve desde caché), así que no hace falta un temporizador propio.
  // La condición de modo AP es la misma que en _check().
  function _observeNetwork(data) {
    if (data && typeof data.netApOnly === `boolean` && data.netApOnly !== _apOnly) {
      _apOnly = data.netApOnly;
      _render(_lastState, true);
    }
    const nw = data?.network?.interfaces?.[0];
    if (!nw) return;
    window.WifiCard?.observe(nw);
    const ssid = (nw.ssid || ``).toString();
    const ip = (nw.actualIP || ``).toString();
    _render(ssid === `RotechOS` || (ip.startsWith(`192.168.1.`) && ssid === `RotechOS`) ? `ap` : `client`);
  }
  // init(): efectos de arranque; lo llama bootStep4 cuando registerUIHook ya
  // existe. El botón del banner enlaza por id y no por data-act: APDetector no
  // está en el registro _ACTIONS y el dispatcher daría un error en cada clic.
  function init() {
    if (typeof registerUIHook === `function`) registerUIHook(`ap-detector`, _observeNetwork);
    // Chequeo inicial tras 3s (da tiempo a RRF a responder en frío).
    setTimeout(() => { _check().catch(() => {}); }, 3000);
    setTimeout(() => {
      // 6-oct: «Poner mi WiFi» abre el diálogo WiFi, también en el móvil (que no
      // tiene CONFIGURACIÓN). Sin el diálogo, cae a CONFIGURACIÓN → Red.
      const btn = document.querySelector(`#btnApConfigWifi`);
      if (btn) btn.addEventListener(`click`, () => { if (!window.WifiCard?.open()) openConfig(); });
      const stay = document.querySelector(`#btnApStay`);
      if (stay) stay.addEventListener(`click`, () => { _stay(); });
    }, 0);
  }
  return { init, _check, openConfig, generateKey, validKey };
})();
window.APDetector = APDetector;

// ── WiFi de la máquina, 6-oct ────────────────────────────────────────────────
// Unir la máquina a la WiFi del taller, o quedarse para siempre con su red propia
// «RotechOS», desde la interfaz y sin USB. Lo usan el diálogo #wifiModal (desde el
// aviso naranja, en escritorio y en el móvil) y la tarjeta de CONFIGURACIÓN → Red.
// El cambio lo hace la máquina: sys/net_join.g y sys/net_ap.g, y el vigilante de
// red de daemon_tick.g, que vuelve a levantar la red RotechOS si la WiFi no
// conecta. Que arranque en la red propia lo guarda config-machine.g
// (set global.netApOnly). PENDIENTE BANCO: tiempos reales del módulo ESP32.
const WifiCard = (function () {
  let bound = false;
  let apOnlyNow = null;          // global.netApOnly leído de la máquina (null = no leído)
  let enRedPropia = false;       // la UI está entrando por la red RotechOS ahora mismo
  let apKeyNow = null;
  let enEthernet = false;

  const textoEthernet = () => enEthernet ? t(`cfg.wifi.ethernetStop`, `Dejar de usar Ethernet`) : t(`cfg.wifi.ethernetUse`, `Probar Ethernet`);

  function pintarClave(key) {
    const value = $(`mcfgWifiApKey`), note = $(`mcfgWifiApKeyNote`);
    const propia = APDetector.validKey(key);
    apKeyNow = propia ? key : null;
    if (value) value.textContent = propia ? key : `rotechos`;
    if (note) note.innerHTML = propia
      ? t(`cfg.wifi.apKeyReady`, `Clave propia de esta máquina. También está en <code>sys/ap-key.g</code> de la SD.`)
      : t(`cfg.wifi.apKeyFallback`, `Aún no hay una clave propia en la máquina: se usa temporalmente <code>rotechos</code>. Genera una clave y vuelve a imprimir la etiqueta.`);
  }

  async function subirClave(key) {
    const body = new Blob([`set global.apKey = "${key}"\n`], { type: `text/plain` });
    const url = `${TARGET_IP}/rr_upload?name=${encodeURIComponent(`0:/sys/ap-key.g`)}&time=${Date.now()}`;
    const res = await fetch(url, { method: `POST`, body });
    if (!res.ok) throw new Error(`rr_upload HTTP ${res.status}`);
    const resultado = typeof res.json === `function` ? await res.json() : null;
    if (resultado && resultado.err !== undefined && Number(resultado.err) !== 0) {
      throw new Error(`rr_upload rechazó la clave AP (err=${resultado.err})`);
    }
    // 18-oct (E1): cargar la clave solo después de que la SD confirme el fichero. NO se
    // llama a net_ap.g: eso sacaría la máquina de la WiFi del taller y dejaría a esta
    // pantalla sin conexión. La clave nueva vale la próxima vez que se levante la red
    // RotechOS (arranque sin WiFi o «Trabajar con la red propia»).
    const aplicado = await RRF.gcode(`M98 P"0:/sys/ap-key.g"`);
    if (!aplicado) throw new Error(`RRF no confirmó la nueva clave AP`);
  }

  async function generarOtraClave() {
    const ok = await confirmDialog(
      t(`dlg.wifiApKey.title`, `Generar otra clave AP`),
      t(`dlg.wifiApKey.msg`, `La clave actual dejará de funcionar la próxima vez que la máquina levante su red RotechOS. Imprime la etiqueta nueva antes de desconectar. ¿Continuar?`));
    if (!ok) return;
    const key = APDetector.generateKey();
    if (!key) { toast(t(`msg.wifiApKeyUnavailable`, `Este navegador no puede generar una clave segura.`), `err`); return; }
    try {
      await subirClave(key);
      pintarClave(key);
      toast(t(`msg.wifiApKeyChanged`, `Clave cambiada. Reimprime la etiqueta y vuelve a conectar los dispositivos.`), `ok`);
    } catch (e) {
      LOG?.warn?.(`WifiCard: no se pudo cambiar la clave AP:`, e);
      toast(t(`msg.wifiApKeyChangeFailed`, `No se pudo cambiar la clave AP; la clave anterior sigue activa.`), `err`);
    }
  }

  function imprimirClave() {
    const key = apKeyNow || `rotechos`;
    const w = window.open(``, `_blank`);
    if (!w) { toast(t(`msg.wifiApKeyPrintBlocked`, `El navegador bloqueó la ventana de impresión.`), `warn`); return; }
    w.document.write(`<!doctype html><title>${t(`cfg.wifi.apLabelTitle`, `Etiqueta de red RotechOS`)}</title><style>body{font:20px sans-serif;padding:24px}code{font-size:28px;letter-spacing:2px}</style><h1>RotechOS</h1><p>${t(`cfg.wifi.apLabelSsid`, `Nombre de red`)}: <strong>RotechOS</strong></p><p>${t(`cfg.wifi.apLabelKey`, `Clave`)}: <code>${key}</code></p><p>${t(`cfg.wifi.apLabelIp`, `Dirección`)}: <strong>192.168.1.1</strong></p><p>${t(`cfg.wifi.apLabelNote`, `Guarda esta etiqueta junto a la máquina. La clave también está en sys/ap-key.g de la SD.`)}</p>`);
    w.document.close();
    w.focus();
    w.print();
  }

  // Una frase de taller: por dónde está conectada y qué IP teclear. Antes salía
  // «SSID: — · IP: 0.0.0.0 · Estado: idle», que es el object model en crudo.
  function tipoRed(nw) {
    if (!nw) return null;
    const ssid = String(nw.ssid || ``), ip = String(nw.actualIP || ``);
    if (ip === `192.168.1.1` || ssid === `RotechOS`) return `ap`;
    if (nw.type === `ethernet` || ssid === `ethernet`) return `ethernet`;
    return `wifi`;
  }
  function describir(nw) {
    if (!nw) return t(`cfg.wifi.st.unknown`, `No se pudo leer el estado de la red.`);
    const ssid = String(nw.ssid || ``), ip = String(nw.actualIP || ``);
    const activa = String(nw.state || ``) === `active` && ip && ip !== `0.0.0.0`;
    if (!activa) return t(`cfg.wifi.summary.none`, `Ahora: sin red (${nw.state || `?`})`, { state: nw.state || `?` });
    const tipo = tipoRed(nw);
    if (tipo === `ap`) return t(`cfg.wifi.summary.ap2`, `Ahora: red propia RotechOS · IP ${ip}`, { ip });
    if (tipo === `ethernet`) return ip.startsWith(`192.168.50.`)
      ? t(`cfg.wifi.summary.ethDirect`, `Ahora: cable directo al PC · IP ${ip}`, { ip })
      : t(`cfg.wifi.summary.eth`, `Ahora: cable de red (Ethernet) · IP ${ip}`, { ip });
    return t(`cfg.wifi.summary.client2`, `Ahora: WiFi del taller «${ssid || `—`}» · IP ${ip}`, { ssid: ssid || `—`, ip });
  }

  // Marca la tarjeta del modo en uso y enseña la guía del PC solo en «directo».
  function pintarModos(nw) {
    const activo = nw && String(nw.state || ``) === `active` ? tipoRed(nw) : null;
    const cards = typeof document.querySelectorAll === `function` ? document.querySelectorAll(`#mcfgTabNetwork .mcfg-net-mode`) : [];
    for (const c of cards) c.dataset.active = c.dataset.netMode === activo ? `true` : `false`;
    pintarGuiaDirecto();
  }
  function pintarGuiaDirecto() {
    const help = $(`mcfgNetDirectHelp`);
    if (help) help.hidden = $(`mcfgEthernetMode`)?.value === `dhcp`;
  }

  let ethernetFailed = false;

  function observe(nw) {
    const panel = $(`mcfgTabNetwork`);
    if (!$(`machineConfigModal`)?.classList.contains(`show`) || panel?.style.display !== `block`) return;
    const st = $(`mcfgWifiStatus`);
    if (st) st.textContent = describir(nw) + (ethernetFailed ? ` ` + t(`cfg.wifi.st.ethernetFailed`, `Ethernet no consiguió IP.`) : ``);
    pintarModos(nw);
  }

  async function refresh() {
    bind();
    const st = $(`mcfgWifiStatus`), tg = $(`mcfgWifiApOnly`), em = $(`mcfgEthernetMode`);
    try {
      const nw = _unwrap(await _fetchModel(`network.interfaces[0]`, 3000));
      enRedPropia = !!nw && (String(nw.actualIP || ``) === `192.168.1.1` || nw.ssid === `RotechOS`);
      enEthernet = !!nw && nw.state === `active` && nw.ssid === `ethernet`;
      if (st) st.textContent = describir(nw);
      pintarModos(nw);
    } catch (e) {
      if (st) st.textContent = describir(null);
    }
    const be = $(`btnMcfgEthernet`);
    if (be) be.textContent = textoEthernet();
    try {
      const fallo = _unwrap(await _fetchModel(`global.netEthFailed`, 3000));
      ethernetFailed = fallo === true;
      if (ethernetFailed && st) st.textContent += ` ` + t(`cfg.wifi.st.ethernetFailed`, `Ethernet no consiguió IP.`);
    } catch (e) { LOG?.warn?.(`WifiCard: global.netEthFailed ilegible:`, e); }
    try {
      const directo = _unwrap(await _fetchModel(`global.netEthernetDirect`, 3000));
      // El modo guardado solo manda si ya está por cable o si es «directo»;
      // si no, se propone el directo, que es el que no necesita router.
      if (typeof directo === `boolean` && em && (directo || enEthernet)) em.value = directo ? `direct` : `dhcp`;
      pintarGuiaDirecto();
    } catch (e) { LOG?.warn?.(`WifiCard: global.netEthernetDirect ilegible:`, e); }
    try {
      const v = _unwrap(await _fetchModel(`global.netApOnly`, 3000));
      if (typeof v === `boolean`) {
        apOnlyNow = v;
        if (tg) tg.checked = v;
      }
    } catch (e) { LOG?.warn?.(`WifiCard: global.netApOnly ilegible:`, e); }
    pintarClave(null);
    try {
      const key = _unwrap(await _fetchModel(`global.apKey`, 3000));
      pintarClave(key);
      // 18-oct (E1): la clave propia NO se genera sola. Solo con el botón y su
      // confirmación, para que nadie se quede fuera sin haberla apuntado.
    } catch (e) {
      LOG?.warn?.(`WifiCard: global.apKey ilegible:`, e);
      pintarClave(null);
    }
  }

  // Guarda netApOnly para los arranques. Sin esto la máquina volvería al modo
  // anterior en el siguiente encendido, y el operario no sabría por qué.
  async function guardarModo(on) {
    const ok = typeof cfgPersistGlobalLine === `function`
      ? await cfgPersistGlobalLine(`netApOnly`, `global netApOnly = ${on}`) : false;
    if (ok) apOnlyNow = on;
    return ok;
  }

  async function cambiarModo(ev) {
    const tg = ev.target, on = !!tg.checked;
    if (on && !enRedPropia) {
      const ok = await confirmDialog(
        t(`dlg.wifiApOnly.title`, `Trabajar con la red propia`),
        t(`dlg.wifiApOnly.msg`,
          `La máquina dejará tu WiFi y creará su red <strong>RotechOS</strong>. Esta pantalla perderá la conexión.<br><br>` +
          `1. Conecta este dispositivo a la red RotechOS. Consulta la clave en CONFIGURACIÓN → Red o en la etiqueta de la máquina.<br>` +
          `2. Abre <code>http://192.168.1.1</code>.<br><br>A partir de ahora arrancará siempre así.`));
      if (!ok) { tg.checked = false; return; }
    }
    if (!(await guardarModo(on))) {
      tg.checked = !on;
      toast(t(`msg.wifiModoNoGuardado`, `No se pudo guardar el cambio de red. No se ha cambiado nada.`), `err`);
      return;
    }
    if (on) {
      await RRF.gcode(`M98 P"0:/sys/net_ap.g"`);
      toast(t(`msg.wifiApOnlyOn`, `La máquina trabajará siempre con su red RotechOS (http://192.168.1.1).`), `ok`);
    } else {
      await RRF.gcode(`set global.netApOnly = false`);
      toast(t(`msg.wifiApOnlyOff`, `Desde el próximo arranque la máquina buscará primero tu WiFi. Para cambiar ya, pulsa «Poner mi WiFi».`), `ok`);
    }
    log(`WiFi: red propia siempre = ${on}`, `sys`);
  }

  // ethernet.g prepara el perfil en daemon_tick.g (M587/M588 en idle); el
  // daemon persiste el modo solo cuando Ethernet consigue IP.
  async function cambiarEthernet() {
    const modo = $(`mcfgEthernetMode`)?.value === `direct` ? `direct` : `dhcp`;
    const ok = await confirmDialog(textoEthernet(),
      enEthernet
        ? t(`dlg.ethernetStop.msg`, `Volverá a tu WiFi o a la red RotechOS y esta pantalla perderá la conexión.`)
        : modo === `direct`
          ? t(`dlg.ethernetDirect.msg`, `Conecta la CNC al PC por Ethernet. La CNC usará 192.168.50.1 y el PC debe tener 192.168.50.2 con máscara 255.255.255.0, sin puerta de enlace ni DNS. El móvil no podrá unirse al AP RotechOS mientras el módulo esté en Ethernet; para usar el MPG móvil a la vez, ambos equipos deben compartir una LAN con Wi‑Fi.`)
          : t(`dlg.ethernet.msg`, `Conecta la CNC a un router o switch con DHCP. Al conectarse, el PC y el móvil podrán acceder desde la misma LAN/Wi‑Fi. Sin IP en 60 s, vuelve sola a esta red.`));
    if (ok) await RRF.gcode(`M98 P"0:/sys/ethernet.g"${enEthernet ? ` S0` : ` D${modo === `direct` ? 1 : 0}`}`);
  }

  async function unirse() {
    const ssid = ($(`wifiSsid`)?.value || ``).trim(), pwd = $(`wifiPwd`)?.value || ``;
    if (!ssid) { toast(t(`msg.wifiSsidVacio`, `Escribe el nombre de tu red WiFi.`), `err`); return; }
    // WPA2 pide 8-63 caracteres; RRF rechaza el M587 y rr_gcode no lo dice.
    if (pwd.length < 8 || pwd.length > 63) {
      toast(t(`msg.wifiPwdLen`, `La contraseña WiFi debe tener entre 8 y 63 caracteres.`), `err`);
      return;
    }
    if ([...ssid + pwd].some((c) => c < ` ` || c === `\x7F`)) {
      toast(t(`msg.wifiCredsSaneadas`,
        `El SSID o la contraseña llevan caracteres de control; se han quitado para poder enviarlos. Si la red no asocia, es por eso.`), `warn`);
    }
    // Si estaba en «siempre red propia», se quita antes: si no, el siguiente
    // arranque la devolvería a la red RotechOS aunque la WiFi funcione.
    if (apOnlyNow !== false && !(await guardarModo(false))) {
      toast(t(`msg.wifiModoNoGuardado`, `No se pudo guardar el cambio de red. No se ha cambiado nada.`), `err`);
      return;
    }
    const tg = $(`mcfgWifiApOnly`);
    if (tg) tg.checked = false;
    await RRF.gcode(`M98 P"0:/sys/net_join.g" S"${window.escGcodeArg(ssid)}" K"${window.escGcodeArg(pwd)}"`);
    const pw = $(`wifiPwd`);
    if (pw) pw.value = ``;
    $(`wifiModal`)?.classList.remove(`show`);
    toast(t(`msg.wifiJoinEnviado`, `Uniéndose a «${ssid}». Conecta este dispositivo a esa red.`, { ssid }), `ok`);
    log(`WiFi: net_join.g a ${ssid}`, `sys`);
  }

  // Abre el diálogo WiFi. Devuelve false si no está en la página.
  function open() {
    bind();
    const m = $(`wifiModal`);
    if (!m) return false;
    m.classList.add(`show`);
    // Lee si la máquina estaba en «siempre red propia» (unirse lo quita).
    _fetchModel(`global.netApOnly`, 3000).then((r) => {
      const v = _unwrap(r);
      if (typeof v === `boolean`) apOnlyNow = v;
    }).catch(() => {});
    $(`wifiSsid`)?.focus?.();
    return true;
  }

  function bind() {
    if (bound) return;
    const join = $(`btnWifiJoin`);
    if (!join) return;
    join.addEventListener(`click`, () => { unirse().catch((e) => LOG?.warn?.(`WifiCard unirse:`, e)); });
    $(`btnWifiCancel`)?.addEventListener(`click`, () => $(`wifiModal`)?.classList.remove(`show`));
    $(`btnMcfgWifiOpen`)?.addEventListener(`click`, () => open());
    $(`mcfgWifiApOnly`)?.addEventListener(`change`, (ev) => { cambiarModo(ev).catch((e) => LOG?.warn?.(`WifiCard modo:`, e)); });
    $(`mcfgEthernetMode`)?.addEventListener(`change`, pintarGuiaDirecto);
    $(`btnMcfgEthernet`)?.addEventListener(`click`, () => { cambiarEthernet().catch((e) => LOG?.warn?.(`WifiCard Ethernet:`, e)); });
    $(`btnMcfgWifiPrint`)?.addEventListener(`click`, imprimirClave);
    $(`btnMcfgWifiGenerate`)?.addEventListener(`click`, () => { generarOtraClave().catch((e) => LOG?.warn?.(`WifiCard clave:`, e)); });
    bound = true;
  }

  return { refresh, observe, open, generarOtraClave, imprimirClave };
})();
window.WifiCard = WifiCard;
