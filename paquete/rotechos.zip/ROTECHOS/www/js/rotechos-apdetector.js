// rotechos-apdetector.js — banner de modo AP y salto a CONFIGURACIÓN → Red (WiFi).
// Fachada del bloque que vivía en rotechos.js: publica window.APDetector con la
// misma firma, y los efectos de arranque van en init(), que llama bootStep4.
// EAGER a propósito: con la máquina en modo AP el banner tiene que verse en el
// primer arranque, que es cuando el operario no sabe cómo conectarse.
// Razones e historia: docs/dev/hallazgos/2026-09-09_monolito-diagnostico-y-plan-de-fragmentacion.md §3.
const APDetector = (function () {
  // 18-oct (E1): alfabeto legible para la etiqueta; excluye 0/o/1/l.
  const AP_KEY_ALPHABET = `abcdefghijkmnpqrstuvwxyz23456789`;
  const AP_KEY_LENGTH = 12;
  function validKey(value) {
    return typeof value === `string` && /^[a-z2-9]{8,63}$/.test(value) &&
      [...value].every((ch) => AP_KEY_ALPHABET.includes(ch));
  }
  function generateKey() {
    if (!globalThis.crypto?.getRandomValues) return null;
    const out = [];
    const limit = 256 - (256 % AP_KEY_ALPHABET.length);
    const buf = new Uint8Array(16);
    while (out.length < AP_KEY_LENGTH) {
      globalThis.crypto.getRandomValues(buf);
      for (const n of buf) {
        if (n >= limit) continue;
        out.push(AP_KEY_ALPHABET[n % AP_KEY_ALPHABET.length]);
        if (out.length === AP_KEY_LENGTH) break;
      }
    }
    return out.join(``);
  }
  let _lastCheck = 0;
  let _lastState = null;        // 'ap' | 'client' | 'unknown'
  // 6-oct: global.netApOnly — el operario eligió trabajar con la red propia. Entonces
  // la red RotechOS no es un aviso sino su modo normal, y el banner no sale.
  let _apOnly = false;
  const CACHE_MS = 30000;
  function _render(state, force) {
    if (state === _lastState && !force) return;
    _lastState = state;
    const banner = $(`apModeBanner`);
    if (!banner) return;
    banner.style.display = state === `ap` && !_apOnly ? `flex` : `none`;
    if (state === `ap`) log(`APDetector: UI conectada al AP RotechOS (banner mostrado)`, `sys`);
  }
  async function _check() {
    if (Date.now() - _lastCheck < CACHE_MS) return _lastState;
    _lastCheck = Date.now();
    try {
      // network.interfaces[0] devuelve {state, actualIP, ssid, ...}
      const r = await _fetchModel(`network.interfaces[0]`, 3000);
      const nw = r && _unwrap(r);
      if (!nw) return _lastState;
      // SSID del AP por defecto = "RotechOS" (wifi-passwords.g:16).
      // Si la UI corre sobre 192.168.1.1 y el ssid es ese, es AP mode.
      const ssid = (nw.ssid || ``).toString();
      const ip = (nw.actualIP || ``).toString();
      const isAp = ssid === `RotechOS` || (ip.startsWith(`192.168.1.`) && ssid === `RotechOS`);
      _render(isAp ? `ap` : `client`);
      return _lastState;
    } catch (e) {
      // Si el fetch falla, no tocamos el estado (caché del último conocido).
      return _lastState;
    }
  }
  // «Seguir con esta red» del banner: la máquina se queda en su red propia y arranca
  // así a partir de ahora. net_ap.g pone global.netApOnly en caliente (ya está en el
  // AP, no cambia nada más); config-machine.g lo guarda para los arranques.
  async function _stay() {
    _apOnly = true;
    _render(_lastState, true);
    try {
      await RRF.gcode(`M98 P"0:/sys/net_ap.g"`);
      const ok = typeof cfgPersistGlobalLine === `function`
        ? await cfgPersistGlobalLine(`netApOnly`, `global netApOnly = true`) : false;
      toast(ok
        ? t(`msg.wifiApStay`, `La máquina trabajará siempre con su red RotechOS. Puedes cambiarlo en CONFIGURACIÓN → Red.`)
        : t(`msg.wifiApStayNoGuardado`, `Sigues en la red RotechOS, pero no se pudo guardar para los próximos arranques. Repítelo desde CONFIGURACIÓN → Red.`),
      ok ? `ok` : `warn`);
      log(`APDetector: red propia elegida (netApOnly=true${ok ? `` : `, sin persistir`})`, `sys`);
    } catch (e) {
      LOG?.warn?.(`APDetector _stay:`, e);
    }
  }
  async function openConfig() {
    // 6-oct: abre CONFIGURACIÓN → Red, donde está la tarjeta WiFi (antes, el paso 4
    // del asistente; el asistente sigue teniendo su paso WiFi).
    // El await NO es opcional: al reanudar, openMachineConfig() resetea los
    // paneles y enterraría la pestaña del asistente que se abre debajo.
    // La pestaña se abre con un CLICK real porque es su listener el que carga
    // rotechos-modules.js (__lazyLoad); cambiar solo la clase la dejaba vacía.
    // Si falla la carga perezosa del modal, se recurre al botón del sistema.
    try {
      await __openMachineConfig();
      if (typeof openMachineConfig !== `function`) throw new Error(`__openMachineConfig no produjo función`);
    } catch (_) {
      $(`btnSysManager`)?.click();
    }
    const netTab = document.querySelector(`.mcfg-tab[data-tab=network]`);
    if (netTab && !netTab.classList.contains(`active`)) {
      netTab.click();
    }
    log(`APDetector: usuario redirigido a CONFIGURACIÓN → Red (WiFi)`, `sys`);
  }
  // Enganchado al ciclo de sondeo: el poll ya trae network.interfaces[0] (o la
  // sirve desde caché), así que no hace falta un temporizador propio.
  // La condición de modo AP es la misma que en _check().
  function _observeNetwork(data) {
    if (data && typeof data.netApOnly === `boolean` && data.netApOnly !== _apOnly) {
      _apOnly = data.netApOnly;
      _render(_lastState, true);
    }
    const nw = data?.network?.interfaces?.[0];
    if (!nw) return;
    const ssid = (nw.ssid || ``).toString();
    const ip = (nw.actualIP || ``).toString();
    _render(ssid === `RotechOS` || (ip.startsWith(`192.168.1.`) && ssid === `RotechOS`) ? `ap` : `client`);
  }
  // init(): efectos de arranque; lo llama bootStep4 cuando registerUIHook ya
  // existe. El botón del banner enlaza por id y no por data-act: APDetector no
  // está en el registro _ACTIONS y el dispatcher daría un error en cada clic.
  function init() {
    if (typeof registerUIHook === `function`) registerUIHook(`ap-detector`, _observeNetwork);
    // Chequeo inicial tras 3s (da tiempo a RRF a responder en frío).
    setTimeout(() => { _check().catch(() => {}); }, 3000);
    setTimeout(() => {
      // 6-oct: «Poner mi WiFi» abre el diálogo WiFi, también en el móvil (que no
      // tiene CONFIGURACIÓN). Sin el diálogo, cae a CONFIGURACIÓN → Red.
      const btn = document.querySelector(`#btnApConfigWifi`);
      if (btn) btn.addEventListener(`click`, () => { if (!window.WifiCard?.open()) openConfig(); });
      const stay = document.querySelector(`#btnApStay`);
      if (stay) stay.addEventListener(`click`, () => { _stay(); });
    }, 0);
  }
  return { init, _check, openConfig, generateKey, validKey };
})();
window.APDetector = APDetector;

// ── WiFi de la máquina, 6-oct ────────────────────────────────────────────────
// Unir la máquina a la WiFi del taller, o quedarse para siempre con su red propia
// «RotechOS», desde la interfaz y sin USB. Lo usan el diálogo #wifiModal (desde el
// aviso naranja, en escritorio y en el móvil) y la tarjeta de CONFIGURACIÓN → Red.
// El cambio lo hace la máquina: sys/net_join.g y sys/net_ap.g, y el vigilante de
// red de daemon_tick.g, que vuelve a levantar la red RotechOS si la WiFi no
// conecta. Que arranque en la red propia lo guarda config-machine.g
// (set global.netApOnly). PENDIENTE BANCO: tiempos reales del módulo ESP32.
const WifiCard = (function () {
  let bound = false;
  let apOnlyNow = null;          // global.netApOnly leído de la máquina (null = no leído)
  let enRedPropia = false;       // la UI está entrando por la red RotechOS ahora mismo
  let apKeyNow = null;

  function pintarClave(key) {
    const value = $(`mcfgWifiApKey`), note = $(`mcfgWifiApKeyNote`);
    const propia = APDetector.validKey(key);
    apKeyNow = propia ? key : null;
    if (value) value.textContent = propia ? key : `rotechos`;
    if (note) note.innerHTML = propia
      ? t(`cfg.wifi.apKeyReady`, `Clave propia de esta máquina. También está en <code>sys/ap-key.g</code> de la SD.`)
      : t(`cfg.wifi.apKeyFallback`, `Aún no hay una clave propia en la máquina: se usa temporalmente <code>rotechos</code>. Genera una clave y vuelve a imprimir la etiqueta.`);
  }

  async function subirClave(key) {
    const body = new Blob([`set global.apKey = "${key}"\n`], { type: `text/plain` });
    const url = `${TARGET_IP}/rr_upload?name=${encodeURIComponent(`0:/sys/ap-key.g`)}&time=${Date.now()}`;
    const res = await fetch(url, { method: `POST`, body });
    if (!res.ok) throw new Error(`rr_upload HTTP ${res.status}`);
    const resultado = typeof res.json === `function` ? await res.json() : null;
    if (resultado && resultado.err !== undefined && Number(resultado.err) !== 0) {
      throw new Error(`rr_upload rechazó la clave AP (err=${resultado.err})`);
    }
    // 18-oct (E1): cargar la clave solo después de que la SD confirme el fichero. NO se
    // llama a net_ap.g: eso sacaría la máquina de la WiFi del taller y dejaría a esta
    // pantalla sin conexión. La clave nueva vale la próxima vez que se levante la red
    // RotechOS (arranque sin WiFi o «Trabajar con la red propia»).
    const aplicado = await RRF.gcode(`M98 P"0:/sys/ap-key.g"`);
    if (!aplicado) throw new Error(`RRF no confirmó la nueva clave AP`);
  }

  async function generarOtraClave() {
    const ok = await confirmDialog(
      t(`dlg.wifiApKey.title`, `Generar otra clave AP`),
      t(`dlg.wifiApKey.msg`, `La clave actual dejará de funcionar la próxima vez que la máquina levante su red RotechOS. Imprime la etiqueta nueva antes de desconectar. ¿Continuar?`));
    if (!ok) return;
    const key = APDetector.generateKey();
    if (!key) { toast(t(`msg.wifiApKeyUnavailable`, `Este navegador no puede generar una clave segura.`), `err`); return; }
    try {
      await subirClave(key);
      pintarClave(key);
      toast(t(`msg.wifiApKeyChanged`, `Clave cambiada. Reimprime la etiqueta y vuelve a conectar los dispositivos.`), `ok`);
    } catch (e) {
      LOG?.warn?.(`WifiCard: no se pudo cambiar la clave AP:`, e);
      toast(t(`msg.wifiApKeyChangeFailed`, `No se pudo cambiar la clave AP; la clave anterior sigue activa.`), `err`);
    }
  }

  function imprimirClave() {
    const key = apKeyNow || `rotechos`;
    const w = window.open(``, `_blank`);
    if (!w) { toast(t(`msg.wifiApKeyPrintBlocked`, `El navegador bloqueó la ventana de impresión.`), `warn`); return; }
    w.document.write(`<!doctype html><title>${t(`cfg.wifi.apLabelTitle`, `Etiqueta de red RotechOS`)}</title><style>body{font:20px sans-serif;padding:24px}code{font-size:28px;letter-spacing:2px}</style><h1>RotechOS</h1><p>${t(`cfg.wifi.apLabelSsid`, `Nombre de red`)}: <strong>RotechOS</strong></p><p>${t(`cfg.wifi.apLabelKey`, `Clave`)}: <code>${key}</code></p><p>${t(`cfg.wifi.apLabelIp`, `Dirección`)}: <strong>192.168.1.1</strong></p><p>${t(`cfg.wifi.apLabelNote`, `Guarda esta etiqueta junto a la máquina. La clave también está en sys/ap-key.g de la SD.`)}</p>`);
    w.document.close();
    w.focus();
    w.print();
  }

  function describir(nw) {
    if (!nw) return t(`cfg.wifi.st.unknown`, `No se pudo leer el estado de la red.`);
    const ssid = String(nw.ssid || ``), ip = String(nw.actualIP || ``);
    if (ip === `192.168.1.1` || ssid === `RotechOS`)
      return t(`cfg.wifi.st.ap`, `Ahora: red propia RotechOS (http://192.168.1.1).`);
    if (nw.state === `active` && ssid)
      return t(`cfg.wifi.st.client`, `Ahora: conectada a «${ssid}», IP ${ip}.`, { ssid, ip });
    return t(`cfg.wifi.st.none`, `Ahora: sin red (${String(nw.state || `?`)}).`, { state: String(nw.state || `?`) });
  }

  async function refresh() {
    bind();
    const st = $(`mcfgWifiStatus`), tg = $(`mcfgWifiApOnly`);
    try {
      const nw = _unwrap(await _fetchModel(`network.interfaces[0]`, 3000));
      enRedPropia = !!nw && (String(nw.actualIP || ``) === `192.168.1.1` || nw.ssid === `RotechOS`);
      if (st) st.textContent = describir(nw);
    } catch (e) {
      if (st) st.textContent = describir(null);
    }
    try {
      const v = _unwrap(await _fetchModel(`global.netApOnly`, 3000));
      if (typeof v === `boolean`) {
        apOnlyNow = v;
        if (tg) tg.checked = v;
      }
    } catch (e) { LOG?.warn?.(`WifiCard: global.netApOnly ilegible:`, e); }
    pintarClave(null);
    try {
      const key = _unwrap(await _fetchModel(`global.apKey`, 3000));
      pintarClave(key);
      // 18-oct (E1): la clave propia NO se genera sola. Solo con el botón y su
      // confirmación, para que nadie se quede fuera sin haberla apuntado.
    } catch (e) {
      LOG?.warn?.(`WifiCard: global.apKey ilegible:`, e);
      pintarClave(null);
    }
  }

  // Guarda netApOnly para los arranques. Sin esto la máquina volvería al modo
  // anterior en el siguiente encendido, y el operario no sabría por qué.
  async function guardarModo(on) {
    const ok = typeof cfgPersistGlobalLine === `function`
      ? await cfgPersistGlobalLine(`netApOnly`, `global netApOnly = ${on}`) : false;
    if (ok) apOnlyNow = on;
    return ok;
  }

  async function cambiarModo(ev) {
    const tg = ev.target, on = !!tg.checked;
    if (on && !enRedPropia) {
      const ok = await confirmDialog(
        t(`dlg.wifiApOnly.title`, `Trabajar con la red propia`),
        t(`dlg.wifiApOnly.msg`,
          `La máquina dejará tu WiFi y creará su red <strong>RotechOS</strong>. Esta pantalla perderá la conexión.<br><br>` +
          `1. Conecta este dispositivo a la red RotechOS. Consulta la clave en CONFIGURACIÓN → Red o en la etiqueta de la máquina.<br>` +
          `2. Abre <code>http://192.168.1.1</code>.<br><br>A partir de ahora arrancará siempre así.`));
      if (!ok) { tg.checked = false; return; }
    }
    if (!(await guardarModo(on))) {
      tg.checked = !on;
      toast(t(`msg.wifiModoNoGuardado`, `No se pudo guardar el cambio de red. No se ha cambiado nada.`), `err`);
      return;
    }
    if (on) {
      await RRF.gcode(`M98 P"0:/sys/net_ap.g"`);
      toast(t(`msg.wifiApOnlyOn`, `La máquina trabajará siempre con su red RotechOS (http://192.168.1.1).`), `ok`);
    } else {
      await RRF.gcode(`set global.netApOnly = false`);
      toast(t(`msg.wifiApOnlyOff`, `Desde el próximo arranque la máquina buscará primero tu WiFi. Para cambiar ya, pulsa «Poner mi WiFi».`), `ok`);
    }
    log(`WiFi: red propia siempre = ${on}`, `sys`);
  }

  async function unirse() {
    const ssid = ($(`wifiSsid`)?.value || ``).trim(), pwd = $(`wifiPwd`)?.value || ``;
    if (!ssid) { toast(t(`msg.wifiSsidVacio`, `Escribe el nombre de tu red WiFi.`), `err`); return; }
    // WPA2 pide 8-63 caracteres; RRF rechaza el M587 y rr_gcode no lo dice.
    if (pwd.length < 8 || pwd.length > 63) {
      toast(t(`msg.wifiPwdLen`, `La contraseña WiFi debe tener entre 8 y 63 caracteres.`), `err`);
      return;
    }
    if ([...ssid + pwd].some((c) => c < ` ` || c === `\x7F`)) {
      toast(t(`msg.wifiCredsSaneadas`,
        `El SSID o la contraseña llevan caracteres de control; se han quitado para poder enviarlos. Si la red no asocia, es por eso.`), `warn`);
    }
    // Si estaba en «siempre red propia», se quita antes: si no, el siguiente
    // arranque la devolvería a la red RotechOS aunque la WiFi funcione.
    if (apOnlyNow !== false && !(await guardarModo(false))) {
      toast(t(`msg.wifiModoNoGuardado`, `No se pudo guardar el cambio de red. No se ha cambiado nada.`), `err`);
      return;
    }
    const tg = $(`mcfgWifiApOnly`);
    if (tg) tg.checked = false;
    await RRF.gcode(`M98 P"0:/sys/net_join.g" S"${window.escGcodeArg(ssid)}" K"${window.escGcodeArg(pwd)}"`);
    const pw = $(`wifiPwd`);
    if (pw) pw.value = ``;
    $(`wifiModal`)?.classList.remove(`show`);
    toast(t(`msg.wifiJoinEnviado`, `Uniéndose a «${ssid}». Conecta este dispositivo a esa red.`, { ssid }), `ok`);
    log(`WiFi: net_join.g a ${ssid}`, `sys`);
  }

  // Abre el diálogo WiFi. Devuelve false si no está en la página.
  function open() {
    bind();
    const m = $(`wifiModal`);
    if (!m) return false;
    m.classList.add(`show`);
    // Lee si la máquina estaba en «siempre red propia» (unirse lo quita).
    _fetchModel(`global.netApOnly`, 3000).then((r) => {
      const v = _unwrap(r);
      if (typeof v === `boolean`) apOnlyNow = v;
    }).catch(() => {});
    $(`wifiSsid`)?.focus?.();
    return true;
  }

  function bind() {
    if (bound) return;
    const join = $(`btnWifiJoin`);
    if (!join) return;
    join.addEventListener(`click`, () => { unirse().catch((e) => LOG?.warn?.(`WifiCard unirse:`, e)); });
    $(`btnWifiCancel`)?.addEventListener(`click`, () => $(`wifiModal`)?.classList.remove(`show`));
    $(`btnMcfgWifiOpen`)?.addEventListener(`click`, () => open());
    $(`mcfgWifiApOnly`)?.addEventListener(`change`, (ev) => { cambiarModo(ev).catch((e) => LOG?.warn?.(`WifiCard modo:`, e)); });
    $(`btnMcfgWifiPrint`)?.addEventListener(`click`, imprimirClave);
    $(`btnMcfgWifiGenerate`)?.addEventListener(`click`, () => { generarOtraClave().catch((e) => LOG?.warn?.(`WifiCard clave:`, e)); });
    bound = true;
  }

  return { refresh, open, generarOtraClave, imprimirClave };
})();
window.WifiCard = WifiCard;
