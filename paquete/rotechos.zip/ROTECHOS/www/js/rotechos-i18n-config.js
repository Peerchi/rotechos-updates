// Fragmento i18n — CONFIGURACIÓN (16 pestañas) + tooltips MODO ESCUELA.  (Agente B)
// Claves EN de los textos de los paneles de configuración y los data-school.
// Formato: "clave": "English text". Clave sugerida con prefijo cfg./school.
window.I18N && window.I18N.add({

  // ── Modal header ─────────────────────────────────────────────────────────
  "cfg.modal.title":        "Machine Configuration",
  "cfg.modal.subtitle":     "RepRapFirmware 3 · config.g",
  "cfg.modal.restore":      "Restore factory defaults",

  // ── Search box inside the CONFIGURATION modal (t_1b6401d6, 2026-08-26) ─
  // Buscador accesible en la cabecera. El placeholder ES ya vive en el HTML;
  // aqui solo registramos las traducciones EN de las claves i18n-placeholder /
  // i18n-aria-label / mensajes del dropdown.
  "cfg.search.placeholder": "Search setting (steps, M92, current, …)",
  "cfg.search.ariaLabel":   "Search setting (steps, M92, current, …)",
  "cfg.search.noResults":   "No matches",
  "cfg.search.hint":        "Type to filter · Enter to open · Esc to clear",

  // ── Tab group labels ──────────────────────────────────────────────────────
  "cfg.group.machine":      "MACHINE",
  "cfg.group.help":         "HELP",
  "cfg.group.ceremony":     "SYSTEM",
  "info.tools.m563": "<strong style=\"color:var(--blue)\">What is M563?</strong> It is the <em>standard RRF G-code</em> that defines each tool of the machine (name, associated spindle and length offset). What you enter here becomes a line <code>M563 P&lt;n&gt; S\"<em>name</em>\" R&lt;0|1&gt; [Z&lt;offset&gt;] [D&lt;Ø&gt;] [F&lt;flutes&gt;]</code> in <code>config-machine.g</code>.<br><br><strong>Tool 0 (Spindle) is protected.</strong> It is the tool the firmware uses for <code>T0</code>+<code>M5</code> (stop the spindle), when loading G-code and on cancel. Its row is shown but has no delete button — regenerating the file always writes it back even if you delete it.<br><br><strong>Sign of the length offset (Z):</strong> <em>negative</em> = tool longer than the calibrated one, <em>positive</em> = shorter. Getting it wrong drives the cutter into the table: measure it with the probe when available, or leave 0.00 until then.<br><br><strong>Persistence:</strong> it is saved in <code>config-machine.g</code> (per-machine calibration). An OTA update that rewrites the whole <code>config.g</code> does NOT overwrite your table.",
  "info.modbus.warn": "<strong style=\"color:var(--warn-strong)\">Modbus takes the display's port.</strong> The Scylla has a single auxiliary serial port which is reserved for the RotechOS Touch physical display, still in development and not included in this version (<code>board.txt</code>: <code>serial.aux.rxTxPins={D.9,D.8}</code>). Choosing Modbus gives you real RPM readback from the VFD, but no physical display. If you want both, use 0-10 V PWM.",
  "cfg.spindle.mode.restart": "The mode applies after restarting the controller. It does not switch hot on purpose: changing mode with the laser armed should not be easy.",
  // t_c2d89697 (2026-09-07) E1: el grupo duplicado SISTEMA (el de los 7:
  // wizard/backup/ota/macros/ledrgb/pines/facing/keyboard — clave 'ceremony')
  // y el de los 2 (pin/about — clave 'system') se llamaban ambos «SISTEMA»
  // en ES y ambos «SYSTEM» en EN. El de los 2 ahora es «SEGURIDAD E
  // IDENTIDAD» / «SECURITY & IDENTITY» porque eso es lo que contiene (PIN
  // HTTP + IDENTIDAD de la máquina). El de los 7 mantiene «SISTEMA» / «SYSTEM».
  "cfg.group.system":       "SECURITY & IDENTITY",
  "cfg.group.machineHint":  "Calibration you touch often",
  "cfg.group.ceremonyHint": "Setup, backups and hardware",
  "cfg.group.readHint":     "Documentation, no settings change",
  "cfg.group.systemHint":   "Machine identity and security",
  "cfg.flag.reboot":        "Requires board reboot",
  "aria.cfg.sidebar":       "Configuration tabs",

  // ── Tab labels ────────────────────────────────────────────────────────────
  "cfg.tab.motors":         "MOTORS",
  // t_c2d89697 (2026-09-07) E1: en ES la pestaña se acorta a
  //   «FINAL DE CARRERA» (146→136 px) para caber en 136 px. El
  //   plural sin «DE» es agramatical; el singular con «DE» cabe igual.
  // En EN se mantiene «ENDSTOPS» (8 chars, ya cabía).
  "cfg.tab.endstops":       "ENDSTOPS",
  "cfg.tab.homing":         "HOMING",
  // UI-8 (2026-09-08): títulos de pestaña que faltaban en algunas
  // (consistencia visual con las que ya tienen). Sin cambios en
  // copy largo; solo el encabezado del panel.
  "cfg.endstops.tabTitle":  "Endstops — sensor configuration",
  "cfg.homing.title":       "Homing (G28) — referencing axes",
  "cfg.softlimits.title":   "Travel limits (software barrier) — M208",
  "cfg.spindle.title":      "Spindle",
  "cfg.macros.title":       "Macros (M98)",
  "cfg.jobhistory.tabTitle":"Job history",
  "cfg.wizard.tabTitle":    "First setup wizard",
  "cfg.about.tabTitle":     "Identity and license",
  "cfg.pin.tabTitle":       "Web UI PIN (M551)",
  "cfg.pines.tabTitle":     "BTT Scylla board pin map",
  "cfg.facing.tabTitle":    "Facing wizard",
  // t_c2d89697 (2026-09-07) E1: la pestaña pasaba de «TRAVEL LIMITS
  // (SOFT LIMITS)» (26 chars, se cortaba en EN) a «SOFT LIMITS» (11
  // chars). En ES pasa de «LÍMITES DE RECORRIDO» (19 chars) a «LÍMITES»
  // (7 chars). El panel mantiene la explicación completa (info-box y
  // title); solo cambia la etiqueta de la pestaña.
  "cfg.tab.softlimits":     "SOFT LIMITS",
  "cfg.tab.speeds":         "SPEEDS",
  "cfg.tab.backlash":       "BACKLASH",
  "cfg.tab.spindle":             "SPINDLE",
  "cfg.tab.probe":               "Z PROBE",
  "cfg.tab.mesh":                "HEIGHT MAP",
  "cfg.tab.macros":              "MACROS",
  "cfg.tab.ledrgb":         "LED RGB",
  "cfg.tab.backup":         "BACKUP",
  "cfg.tab.ota":            "UPDATE (OTA)",
  "cfg.tab.wizard":         "FIRST SETUP",
  "cfg.tab.guide":          "MACHINING GUIDE",
  "cfg.tab.viz3d":          "3D VIEWER",
  "cfg.tab.jobhistory":     "HISTORY",
  "cfg.tab.pines":          "CONTROLLER",
  "cfg.tab.keyboard":       "KEYBOARD",
  "cfg.tab.glossary":       "WIKI CNC",
  // Pestana IDENTIDAD (grupo SISTEMA, index.html:538 — literal ES "IDENTIDAD").
  // No es un "acerca de": es la identidad de la maquina (M550). Ver info.about.tab.
  "cfg.tab.about":          "IDENTITY",
  "cfg.tab.tools":              "TOOLS",

  // ── Tab MAPA DE ALTURA (t_c2dce523, sep-2026) ──────────────────────────
  // Específico de la pestaña mesh (la sonda Z vive en su propia pestaña).
  // Claves aquí; textos largos en `info.mesh` más abajo.
  "cfg.mesh.title":          "Material Height Map",
  "cfg.mesh.banner.home":    "HOME is required before probing — run G28 from the cockpit.",
  "cfg.mesh.area.title":     "Probing area (MCS)",
  "cfg.mesh.area.desc":      "Absolute machine coordinates (G53). Defaults are derived from the M208 envelope minus a defensive margin.",
  "cfg.mesh.btn.defaults":   "Fill from M208",
  "cfg.mesh.lbl.xmin":       "X min (mm)",
  "cfg.mesh.lbl.xmax":       "X max (mm)",
  "cfg.mesh.lbl.ymin":       "Y min (mm)",
  "cfg.mesh.lbl.ymax":       "Y max (mm)",
  "cfg.mesh.lbl.nx":         "X points (2–50)",
  "cfg.mesh.lbl.ny":         "Y points (2–50)",
  "cfg.mesh.lbl.speedFast":  "Probe speed (mm/min)",
  "cfg.mesh.lbl.speedSlow":  "Slow pass speed (mm/min)",
  "cfg.mesh.lbl.safeZ":      "Safe Z height (mm)",
  "cfg.mesh.estimate":       "Set area and points — the estimated time will appear here.",
  "cfg.mesh.material":       "Current material (note only, saved with the JSON):",
  "cfg.mesh.material.ph":    "e.g. plywood 9mm",
  "cfg.mesh.btn.probe":      "PROBE",
  "cfg.mesh.btn.cancel":     "Cancel",
  "cfg.mesh.progress.idle":  "No probing in progress.",
  "cfg.mesh.map.title":      "Height map",
  "cfg.mesh.map.desc":       "Red = high · Green = flat · Blue = low. Centred on the mean of the map itself. The number in each cell is the deviation in tenths of mm.",
  "cfg.mesh.comp.inactive":  "Compensation inactive. The cutter works at the nominal Z of the G-code.",
  "cfg.mesh.comp.active":    "COMPENSATION ACTIVE — running with a map from another material may plunge the cutter.",
  "cfg.mesh.btn.activate":   "Activate compensation",
  "cfg.mesh.btn.deactivate": "Deactivate",
  "cfg.mesh.saved.title":    "Saved maps (0:/macros/mesh-*.json)",
  "cfg.mesh.saved.desc":     "The height map is operational data, NOT calibration. You can load and delete saved maps; viewing a saved map does not require the machine to be connected, but probing and activating does.",
  "cfg.mesh.btn.load":       "Load",
  "cfg.mesh.btn.delete":     "Delete",
  "cfg.mesh.btn.save":       "Save current map",
  "cfg.mesh.saveName.ph":    "map name (no mesh- prefix, no .json suffix)",
  // toasts y progress (consumidos por rotechos-mesh-probe.js)
  "cfg.mesh.progress.active":      "probing…",
  "cfg.mesh.progress.completed":   "Map complete. Review the distribution and save it if you want to keep it.",
  "cfg.mesh.progress.failed":      "FAILED at point",
  "cfg.mesh.progress.failedHint":  "The map is NOT valid. Fix the issue and probe again.",
  "cfg.mesh.estimateTemplate":     "Estimated time: {time} for {total} points.",
  // (cfg.mesh.comp.active / .inactive estaban repetidas aqui, identicas a las de arriba)
  "cfg.mesh.toast.invalidGrid":    "Invalid grid:",
  "cfg.mesh.toast.needHome":       "HOME is required before probing.",
  "cfg.mesh.toast.started":        "Mesh started…",
  "cfg.mesh.toast.startErr":       "Failed to start:",
  "cfg.mesh.toast.cancelled":      "Probing cancelled by the operator.",
  "cfg.mesh.toast.saveIncomplete": "Map incomplete — cannot save.",
  "cfg.mesh.toast.saveBadName":    "Invalid name (letters, digits, _ and -, max 32).",
  "cfg.mesh.toast.saved":          "Saved:",
  "cfg.mesh.toast.saveErr":        "Save failed:",
  "cfg.mesh.toast.loaded":         "Loaded:",
  "cfg.mesh.toast.loadErr":        "Load failed:",
  "cfg.mesh.toast.deleted":        "Deleted:",
  "cfg.mesh.toast.delErr":         "Delete failed:",
  "cfg.mesh.toast.activateWip":    "Compensation activation:",
  "cfg.mesh.toast.activateWipHint": "G29 S1 integration requires mapping the JSON to the native RRF heightmap.csv — pending bank validation.",
  "cfg.mesh.toast.deactivate":     "Compensation deactivated.",
  "cfg.mesh.toast.confirmDelete":  "Delete {name}?",

  // t_f8b27b80 (2026-09-05) — 3 pestañas AVANZADO nuevas (index.html grupo AVANZADO)
  "cfg.tab.motortimeout":   "MOTOR TIMEOUT",
  "cfg.tab.fans":           "FANS",
  // t_c2d89697 (2026-09-07) E1: ES «PROTOCOLOS DE RED» (17 chars, se
  // cortaba) → «RED (M586)». EN «NETWORK PROTOCOLS» (17 chars, también
  // se cortaba) → «NETWORK (M586)». M586 es el código RRF que activa
  // HTTP/FTP/Telnet; los usuarios de RRF lo conocen, y el panel ya se
  // titula «Protocolos de red — M586» (HTML:1703) y «Network protocols
  // (M586)» en EN.
  "cfg.tab.network":        "NETWORK (M586)",
  "cfg.tab.inputshaping":   "INPUT SHAPING",
  "cfg.group.advanced":     "ADVANCED",
  "cfg.group.advancedHint": "Settings you touch once",

  // ── Tab school tooltips ───────────────────────────────────────────────────
  "school.motors":
    "<strong>Motors</strong> Core stepper parameters: which driver each axis uses (M584), rotation direction (M569), working current in mA (M906) and steps per mm (M92). Configure this BEFORE homing or limits.",
  "school.endstops":
    "<strong>Endstops</strong> Sensors at the end of each axis. Define them BEFORE configuring homing — homing needs to know which pin each sensor is on and whether it is NC or NO.",
  "school.homing":
    "<strong>Homing</strong> Sequence for finding the mechanical origin. Configure seek speeds (fast) and fine-adjustment speed (slow), axis order and whether homing is required before moving.",
  "school.softlimits":
    "<strong>Travel limits (soft limits)</strong> Virtual work area: software barriers that prevent moving axes beyond M208 limits. Set them up after homing so you know the real machine travel.",
  "school.speeds":
    "<strong>Speeds</strong> Acceleration (M201), maximum speed (M203), jerk (M566) and manual jog speed table per step. Adjust the SEDA profile (smooth jog) and RAYO profile (machining).",
  "school.backlash":
    "<strong>Backlash</strong> Compensation for mechanical play in the leadscrew or belt. RRF automatically applies an extra pulse when reversing direction. Typical value: 0.05–0.3 mm.",
  "school.spindle":
    "<strong>Spindle</strong> Cutting motor: minimum and maximum RPM (L{min}:{max}), control mode (PWM / relay / Modbus), ramp-up and coolant (note: mist/cool options require configuring additional GPIO outputs on the Scylla board). The correct cutting speed depends on material and tooling.",
  "school.macros":
    "<strong>Macros</strong> Manage custom .g macro files. Create, edit and execute G-code sequences from the interface.",
  "school.ledrgb":
    "<strong>LED RGB</strong> Color and mode of the NeoPixel status LED: indicates the operating mode (SEDA=blue, RAYO=cyan, alarm=red). Applied automatically based on machine state.",
  "school.backup":
    "<strong>Backup & Restore</strong> Download a copy of config.g to your computer or restore from a previous backup. Do this before any important changes.",
  "school.ota":
    "<strong>OTA — Firmware update</strong> Update RRF firmware or web interface files directly from the browser without removing the SD card.",
  "school.wizard":
    "<strong>First-boot assistant</strong> Step-by-step guide to configure the machine for the first time: network, motors, endstops, homing, probe and spindle.",
  "school.guide":
    "<strong>My first machining job</strong> Practical step-by-step guide to run your first cutting job: preparation, work origin, file loading and monitoring.",
  "school.viz3d":
    "<strong>3D G-code Viewer</strong> Load a G-code file and analyse toolpaths, estimated time, depths and area overflows before machining.",
  "school.jobhistory":
    "<strong>Job History</strong> Log of each machining run: duration, status, file. Accumulates spindle hours and travel distance to schedule maintenance.",
  "school.pines":
    "<strong>Controller — BTT Scylla V1.0 Pinout</strong> Complete pin map of the controller board: driver connectors, endstops, spindle, probe and GPIO. Quick reference for checking wiring.",
  "school.mesh":
    "<strong>Height map — material warp compensation</strong> Probe an N×M grid over the workpiece so the next job follows the real surface instead of a flat plane. Required for engraving thin reliefs and PCB milling on boards that are not perfectly flat. The map is tied to the material currently on the bed.",
  "school.keyboard":
    "<strong>Keyboard shortcuts</strong> List of system keyboard shortcuts with the ability to reassign keys. Persisted in the browser.",
  "school.glossary":
    "<strong>CNC Wiki</strong> Visual dictionary of technical terms: G-code, axes, spindle, homing and more. Designed for beginners.",
  // Tooltip MODO ESCUELA de la pestana IDENTIDAD (index.html:538). Traduccion
  // del unico texto ES que la interfaz muestra hoy para esa pestana, el
  // info-box info.about.tab (index.html:1066); su EN aprobado vive mas abajo
  // en este mismo fichero (clave "info.about.tab"), y aqui se reutiliza
  // resumido al formato de los demas school.*.
  "school.about":
    "<strong>Identity</strong> Machine identity, not an \"about this application\" page. Here you set the name this Scylla advertises on the network (M550), see the RotechOS version, the GPLv3 license, and open the system diagnostic. It does NOT touch calibration: the calibration controls live in the tabs on the left (MOTORS, ENDSTOPS, HOMING…).",

  // t_f8b27b80 (2026-09-05) — 3 escuelas nuevas para AVANZADO. Una frase,
  // un verbo. Operario en MODO ESCUELA ve esto al pasar el ratón por el
  // botón de la pestaña. Formato corto a propósito (no párrafos).
  "school.motortimeout":
    "<strong>Motor timeout (M84 S)</strong> How many seconds the controller waits without movement before releasing the motors. Default 86400 s (one day, Z stays energised) so the spindle weight does not drop Z by gravity when the leadscrew is not self-locking.",
  "school.fans":
    "<strong>Electronics fans (AUX1)</strong> They switch on by themselves when the board processor reaches this temperature, or when a motor driver warns that it is overheating.",
  "school.network":
    "<strong>Network protocols (M586)</strong> FTP (P1) and Telnet (P2) are off by default because they have no authentication. HTTP (P0) is not exposed here — disabling it would break the current web session.",
  "school.inputshaping":
    "<strong>Input shaping (M593)</strong> Cancels the micro-vibration that shows up as ringing on the workpiece finish. The default is the ZVD shaper at 40 Hz as a starting point; refine the frequency with an accelerometer (M956). If your RRF-STM32 build does not support M593 it is ignored without harm.",

  // ── MOTORS panel ─────────────────────────────────────────────────────────
  "cfg.motors.axisA.title":       "A Axis (4th Motor)",
  "cfg.motors.microsteps.title":  "Microstepping — M350",
  "cfg.motors.microsteps.interpolate": "Interpolate to 256× (I1) — smoother + quieter",
  "cfg.motors.steps.title":       "Steps per mm — M92",
  "cfg.motors.current.title":     "Motor Current — M906 (mA)",
  "cfg.motors.dir.title":         "Direction Inversion — M569",
  "cfg.motors.psu.title":         "Power Supply",
  "cfg.spindle.warmup.hdr":       "Spindle Maintenance",
  "cfg.probe.title":              "Z Probe — declaration and offset",
  "cfg.motors.dir.normal":        "NORMAL",
  "cfg.motors.dir.inv":           "INVERTED",
  "cfg.motors.extdrv.title":      "Drivers Externos — M569 D2",
  "cfg.motors.extdrv.note":       "STEP/DIR externo",

  // ── HOMING panel ─────────────────────────────────────────────────────────
  "cfg.homing.require.title":     "Require HOME (G28) before moving",
  "cfg.homing.require.desc":      "Blocks movement until HOME (G28) is complete. Disable for testing without endstops.",
  "cfg.homing.dir.title":         "Homing Direction per Axis",
  "cfg.homing.dir.tomax":         "TOWARD +MAX",
  "cfg.homing.dir.tomin":         "TOWARD −MIN",
  "cfg.homing.speeds.title":      "Homing Speeds",
  "cfg.homing.seek.hdr":          "Seek (mm/min)",
  "cfg.homing.back.hdr":          "Fine (mm/min)",
  "cfg.homing.order.title":       "Homing Order",
  "cfg.homing.order.first":       "First:",
  "cfg.homing.order.zfirst":      "Z first",
  "cfg.homing.order.xyfirst":     "X/Y first",

  // ── ENDSTOPS panel ───────────────────────────────────────────────────────
  "cfg.endstops.title":           "Configuration & Status",
  "cfg.endstops.col.axis":        "Axis",
  "cfg.endstops.col.end":         "End",
  "cfg.endstops.col.onoff":       "ON/OFF",
  "cfg.endstops.col.pin":         "Pin",
  "cfg.endstops.col.type":        "Type",
  "cfg.endstops.col.read":        "Reading",
  // Estados de la celda LECTURA (t_7edbf98d). Codificación redundante
  // (icono + texto + color) para daltónicos: la palabra sola distingue
  // los 4 estados sin depender del color.
  "cfg.endstops.read.free":       "Free",
  "cfg.endstops.read.active":     "Triggered",
  "cfg.endstops.read.off":        "Disabled",
  "cfg.endstops.read.unknown":    "Not read",

  // ── SOFT LIMITS panel ────────────────────────────────────────────────────
  "cfg.softlimits.toggle.title":  "Travel limits (soft limits)",
  "cfg.softlimits.toggle.desc":   "Software barriers that prevent axes from exceeding M208 limits. Disable temporarily only when you need to move outside the configured area.",
  "cfg.softlimits.min.hdr":       "Minimum (mm)",
  "cfg.softlimits.max.hdr":       "Maximum (mm)",
  "cfg.softlimits.clearance.title": "Safe Z clearance (mm)",
  "cfg.softlimits.clearance.desc":  "Z height the spindle rises to for fast moves without collision (park, go to 0, 3D probe). Increase for thick material or tall clamps.",

  // ── SPINDLE panel ────────────────────────────────────────────────────────
  "cfg.spindle.mode.title":       "Control Mode",
  "cfg.spindle.rpm.title":        "Speed (RPM)",
  "cfg.spindle.rpm.min":          "Minimum speed",
  "cfg.spindle.rpm.max":          "Maximum speed",
  "cfg.spindle.laser.title":      "Laser power (%)",
  "cfg.spindle.laser.min":        "Minimum power (%)",
  "cfg.spindle.laser.max":        "Maximum power (%)",
  "cfg.spindle.laser.hint":       "M950 emitted in laser mode: <code>M950 R0 C\"B.1+C.5\" Q10000 L{pmin}:100</code> — <code>B.1</code>=SPD (PWM/TTL), <code>C.5</code>=SP-EN (safety enable, disables the laser on M5). Fixed 0–100 range = power percentage (not RPM).",
  "cfg.spindle.ramp.title":       "Ramp Time (Spin-up)",
  "cfg.spindle.ramp.wait":        "Wait (seconds)",
  "cfg.spindle.sac.title":        "SAC — Assisted Tool Change",
  "cfg.spindle.sac.desc":         "Enables guided mode for tool change (M6). The machine will pause and wait for confirmation before continuing.",
  "cfg.spindle.tc.pos.title":     "Tool Change Positions (MCS)",
  "cfg.spindle.tc.pos.desc":      "Absolute machine coordinates (G53): where the spindle positions, where the sensor is and how it probes.",
  "cfg.spindle.sensor.x":         "X (mm) — derived from travel limits",
  "cfg.spindle.sensor.y":         "Y (mm) — physical sensor position",

  "cfg.spindle.probe.title":      "Probing parameters",
  "cfg.spindle.probe.fast":       "Probe speed (mm/min)",
  "cfg.spindle.probe.slow":       "Precision pass speed (mm/min)",
  "cfg.spindle.probe.accel":      "Probe Z acceleration (mm/s²)",
  "cfg.spindle.probe.timeout":    "Probe timeout (ms) — abort if no contact within this time",
  "cfg.spindle.probe.timeout.warn": "TIMEOUT · NOT IN EFFECT",

  // t_e234f3be (sep-2026): aspiración que sigue al husillo. Interruptor +
  // retardo de apagado. El módulo rotechos-aspiracion-follow.js observa el
  // estado del husillo desde el poll existente y emite M42 P{n} S0/S1.
  // Persistencia en config-machine.g (comentarios `; rotech-aspir-follow=`
  // y `; rotech-aspir-delay=`). Si la función `aspiracion` (o fallback
  // `aspiracion_potencia`) no tiene pin en CONTROLADORA, el interruptor
  // se renderiza deshabilitado con motivo (info.aspirFollow.noPin).
  "cfg.spindle.aspirFollow.hdr":   "Dust extraction synced with spindle",
  "cfg.spindle.aspirFollow.label": "Dust extraction follows the spindle",
  "cfg.spindle.aspirFollow.desc":
    "When the spindle starts, the dust extraction switches on. When it stops, the extraction waits this long before switching off — so the duct finishes sucking the chips that were already in flight.",
  "cfg.spindle.aspirFollow.delay":  "Switch-off delay (seconds)",
  "aria.tgl.aspirFollow":           "Dust extraction follows the spindle",
  "info.aspirFollow.noPin":
    "<strong style=color:var(--warn-strong)>No pin assigned.</strong> The function <code>aspiracion</code> (or <code>aspiracion_potencia</code>) has no pin in CONTROLADORA. Assign it a pin (D.5/A.5 or whichever you prefer) and come back to this tab.",

  // t_c7ffb7f0 (sep-2026, Fase 4.8-bis): summaries de los details plegables
  // en la pestaña PROBE. El cuerpo está en info.sac.signos / info.sac.flujoM6
  // / info.sac.sensorX / info.sonda.recorridoMax — estos son solo el rótulo
  // del <summary>.
  "cfg.sonda.signos.summary":     "The 4 signs (G53, Z=0 at top, sensor→table, material thickness) — click to expand",
  "cfg.sonda.flujoM6.summary":    "M6 flow (7 steps: stop → lift Z → park → change → confirm → probe → validate) — click to expand",
  "cfg.sonda.sensorX.summary":    "Why is X greyed out and Y not? — click to expand",
  "cfg.sonda.recorridoMax.summary": "What is the max travel to contact? — click to expand",
  // El cuerpo del details plegado — vive plegado cuando el operario no lo ha
  // abierto (información de referencia, no de operación).
  "info.sonda.recorridoMax":
    "<strong style=color:var(--blue)>Derived reading, NOT editable.</strong> Computed as |<strong>Z current</strong> − <strong>Z min</strong>| − <em>sensor → table distance</em>. It is the theoretical distance the spindle will travel from its current position until it touches the sacrificial board.<br><br><strong>What is it for?</strong> Lets you know in advance <em>how far the spindle will descend</em> during the probe. If the value is 0 or negative, the probe will not reach the table: check touchplate thickness, sensor→table distance and the firmware Z min.<br><br><strong>When it updates</strong>: on opening the tab and from the RRF poll. If the firmware has not yet reported <code>move.axes[2].min</code>, the field shows <em>— mm</em>.",
  "cfg.spindle.sac.ztable":       "Sensor → table distance (mm)",
  "cfg.spindle.sac.touchplate":   "Material thickness (mm)",

  // ── SONDA/SAC §4.8 — info-box sobre signos y flujo M6 (t_014cd150) ─────
  // Plan v2 §4.8 puntos 3 y 5: explicar en lenguaje de taller qué significa
  // G53, el signo del cero Z, la distancia sensor→mesa, el grosor de la
  // pastilla, y guiar el M6 (parar husillo → elevar Z → aparcar → cambio →
  // confirmar → palpar → validar). NO duplicar la macro firmware: la
  // máquina hace los pasos físicamente; aquí solo el contexto para el
  // operario que va a pulsar el botón.
  "info.sac.signos":
    "<strong style=color:var(--blue)>The four signs to keep straight (confusing one breaks the cutter against the table).</strong><br><br>" +
    "<strong style=color:var(--green)>G53 — machine coordinates.</strong> G53 switches to absolute <em>machine</em> coordinates (independent of any workpiece zero). The sensor X/Y you set here are G53 positions: they mean the same thing whether you have set a part-zero or not. <strong>Without G53, the firmware would move relative to the workpiece zero and the probe would land somewhere arbitrary on the table.</strong><br><br>" +
    "<strong style=color:var(--green)>Z zero is at the top.</strong> RRF has Z=0 at the top of travel and Z goes <em>negative</em> as the spindle descends (this machine: Z0 → Z−115). So when the firmware reports Z=−12 after a probe, the cutter is 12 mm below the top, not 12 mm above.<br><br>" +
    "<strong style=color:var(--green)>Sensor → table distance (z_sensor_to_table) is the height where the probe triggers ABOVE the table.</strong> Positive number if the probe fires when the spindle is still above the sacrificial board (typical: 5–20 mm). The sign is decided by the physical geometry: if your probe is recessed BELOW the table surface (atypical), the value goes negative. The code accepts both, but the firmware assumes the value matches your hardware.<br><br>" +
    "<strong style=color:var(--green)>Material thickness is ADDED to the table height.</strong> PROBE Z touches the fixed button, not the workpiece: zero lands on the table plus this value. Enter your real material thickness, measured with calipers, so Z=0 is on its surface; with 0 it stays on the table. If it does not match the material, the tool will go too deep or too shallow.",
  "info.sac.flujoM6":
    "<strong style=color:var(--blue)>M6 — guided tool change (what you do, what the machine does).</strong><br><br>" +
    "<strong>1. STOP the spindle</strong> (M5 or button). The UI shows the warning because VFD spindles at 18.000 rpm keep spinning briefly after the stop signal.<br>" +
    "<strong>2. ELEVATE Z</strong> the machine raises Z to a safe height above clamps and the workpiece — you do NOT need to do this manually.<br>" +
    "<strong>3. PARK</strong> the machine moves to the SAC X/Y (sensor position) and waits for you.<br>" +
    "<strong>4. MANUAL tool change</strong>: loosen, remove the old cutter, insert the new one, tighten. The machine does NOT touch the spindle.<br>" +
    "<strong>5. CONFIRM</strong> (LISTO button in the firmware prompt): the machine resumes the original program at the point where it was.<br>" +
    "<strong>6. PROBE the new tool</strong> (if the program needs it): re-measure Z zero for the new tool length. The machine lowers the spindle until the probe trips and sets the new Z.<br>" +
    "<strong>7. VALIDATE</strong>: if the probe fails (timeout, no contact), the machine does NOT resume — recheck the probe connection, the material thickness, and Z clearance before pressing LISTO again.",

  // ── BACKLASH panel ───────────────────────────────────────────────────────
  "cfg.backlash.title":           "Backlash Compensation — M425",
  "cfg.backlash.speed.title":     "Compensation speed — S (mm/min)",
  "cfg.backlash.speed.label":     "S — Speed",
  "cfg.backlash.howto.title":     "How to measure backlash",
  "cfg.backlash.z.info":          "Play on the Z axis. On trapezoidal screws without preload it can be significant (0.05–0.3 mm). Ball screws are usually minimal. Especially affects roughing and finishing passes with direction changes.",

  // ── SPEEDS panel ─────────────────────────────────────────────────────────
  "cfg.speeds.maxspeed.title":    "Maximum Speeds — M203 (mm/min)",
  "cfg.speeds.overview":          "<strong>Two profiles, one clear decision.</strong> <b>SEDA</b> controls manual motion; <b>RAYO</b> controls machining. M203 limits are always global.",
  "cfg.speeds.jerk.help":         "What is Jerk?",
  "cfg.speeds.silk.accel.title":  "Acceleration — Manual motion (SEDA) — M201 (mm/s²)",
  "cfg.speeds.silk.jerk.title":   "Jerk — Manual motion (SEDA) — M566 (mm/min)",
  "cfg.speeds.rayo.title":        "Work Acceleration & Jerk (RAYO)",
  "cfg.speeds.rayo.accel.title":  "Acceleration — Work execution (RAYO) (mm/s²)",
  "cfg.speeds.rayo.jerk.title":   "Jerk — Work execution (RAYO) (mm/min)",
  // Tooltips del eje A rotativo (oculto por defecto; se activa en MOTORES).
  // La jerga interna RAYO/SEDA se mantiene; las unidades y el comportamiento
  // del campo se explican al usuario inglés de forma neutral.
  "cfg.speeds.rayo.accel.a.title":
    "RAYO acceleration for axis A in degrees/second² (deg/s²). Only if you have a 4th rotational axis enabled in MOTORS; units switch from mm to degrees.",
  "cfg.speeds.rayo.jerk.a.title":
    "RAYO jerk for axis A in degrees/minute (deg/min). Only if you have a 4th rotational axis enabled in MOTORS; units switch from mm to degrees.",
  "cfg.speeds.jog.title":         "Incremental Jog Speeds",
  "cfg.speeds.jog.step.hdr":      "Step (mm)",
  "cfg.speeds.jog.xy.hdr":        "XY (mm/min)",
  "cfg.speeds.jog.z.hdr":         "Z (mm/min)",

  // ── MACROS panel ─────────────────────────────────────────────────────────

  // ── BACKUP panel ─────────────────────────────────────────────────────────
  "cfg.backup.title":             "Configuration backup",
  "cfg.backup.export.hdr":        "Export",
  "cfg.backup.restore.hdr":       "Restore",
  "cfg.backup.drop.label":        "Drag backup.zip or click",
  "cfg.backup.btn.export":        "Download backup.zip",
  // t_b68324ca (sep-2026): etiqueta del botón "Descargar backup" cuando
  // /sys y /macros no devuelven archivos. Antes salía "Descargar backup.zip"
  // con aspecto normal y el ZIP resultante contenía SOLO metadata.json —
  // confuso y peor que ningún backup porque parecía válido.
  "cfg.backup.btn.export.empty":  "No files to back up",
  "cfg.backup.btn.restore":       "Restore and restart firmware",
  // Fase 4.10 (t_c56fb349): resumen del backup que se muestra ANTES de que
  // el operario pulse Descargar. Lo que el ZIP va a contener —y lo que NO va
  // a contener—: credenciales WiFi excluidas, subcarpetas excluidas.
  "cfg.backup.manifest.hdr":      "Backup summary (what the ZIP will contain)",
  "cfg.backup.manifest.machine":  "Machine",
  "cfg.backup.manifest.date":     "Date",
  "cfg.backup.manifest.files":    "Files",
  "cfg.backup.manifest.uiVersion": "UI version",
  "cfg.backup.manifest.noCredentials": "<span style=\"color:var(--green)\">✓ This backup does NOT include your WiFi credentials (<code>sys/wifi-passwords.g</code>). You can share it without leaking your network.</span>",
  "cfg.backup.manifest.noSubdirs":     "<span style=\"color:var(--yellow)\">⚠ Only files at the root of <code>0:/sys</code> and <code>0:/macros</code> are exported. Files in subfolders and the items listed below are NOT in the ZIP:</span>",

  // ── OTA panel ────────────────────────────────────────────────────────────
  "cfg.ota.title":                "OTA File Manager",
  "cfg.ota.desc":                 "Upload files to the CNC SD card without removing it. The destination path is detected automatically by extension or you can select it manually.",
  "cfg.ota.dest.label":           "Destination",
  "cfg.ota.dest.auto":            "Auto (extension)",
  "cfg.ota.drop.title":           "Drag files here",
  "cfg.ota.drop.hint":            "index.html, config.g, rotechos.js, macros, G-code…",
  "cfg.ota.btn.clear":            "Clear",
  "cfg.ota.log.title":            "Upload history",
  "cfg.ota.log.empty":            "No records",

  // ── OTA Fase 4.11: clasificación por tipo + impacto ──────────────────
  // type: ui | firmware | config | macro | gcode | unknown
  // impact: reload-ui | reboot-duet | next-invoke | none
  // El badge en la cola visual y el confirmDialog de subida los
  // consumen. Los textos largos viven como fallback en el call-site con
  // t(`clave`, `ES`); aquí solo los cortos y los badges. ES embebido.
  "badge.ota.impact.reboot":      "Requires Duet restart",
  "badge.ota.impact.reload":      "UI reloads in 3s",
  "dlg.otaUnknownExt.title":      "Unclear destination",
  "dlg.otaUnknownExt.body":       "The file",
  "dlg.otaUnknownExt.extUnknown": "has an extension RotechOS does not recognise",
  "dlg.otaUnknownExt.default":    "By default it would go to",
  "dlg.otaUnknownExt.defSfx":     " (firmware folder). If you want a different path, set the Destination selector above before dragging.",
  "dlg.otaUnknownExt.warn":       "Upload anyway to",
  "dlg.otaUnknownExt.yes":        "Upload",
  "dlg.otaUnknownExt.no":         "Discard",
  "msg.otaUnknownSkipped":        "Discarded: unknown destination",
  "dlg.upload.impactReboot":      "After upload, file(s) require restarting the Duet (M999 or power-cycle) to take effect.",
  "dlg.upload.impactReload":      "After upload, the UI will auto-reload in 3s (web file(s)).",
  "dlg.upload.unknownNote":       "file(s) with an unrecognised extension will go to 0:/sys — only confirm if you know they are firmware.",

  // ── LED RGB panel ────────────────────────────────────────────────────────
  "cfg.led.title":                "LED RGB Control (NeoPixel WS2812b)",
  "cfg.led.brightness":           "Overall brightness",
  "cfg.led.power":                "Power",
  "cfg.led.states.title":         "State → Animation Map",
  "cfg.led.preview.title":        "Preview",
  "cfg.led.hud.state":            "Active state",
  "cfg.led.hud.pattern":          "Active pattern",
  "cfg.led.disabled.banner.title":"LED strip disabled",
  "cfg.led.disabled.banner":      "The physical LED strip is OFF. The machine state shown on screen (top bar badge) still works, but the physical light signal is NOT being emitted. If you work in dim light and need the visual redundancy, turn the strip back on above.",
  "cfg.led.test.idle":            "Test IDLE",
  "cfg.led.test.ready":           "Test READY",
  "cfg.led.test.running":         "Test RUNNING",
  "cfg.led.test.paused":          "Test PAUSED",
  "cfg.led.test.error":           "Test ERROR",
  "cfg.led.anim.title":           "Animation meanings",

  // ── ABOUT (INFO) panel ───────────────────────────────────────────────────
  "cfg.about.license.btn":        "View license",

  // ── ABOUT (INFO) → sub-panel "Para soporte tecnico" (Fase 4.19) ────────
  // Bloque que expone el identificador estable de la unidad y un boton
  // para copiar todo el bloque a un correo. El ES se conserva embebido
  // en el HTML; aqui solo el EN paralelo (mecanismo data-i18n del proyecto).
  "cfg.homing.maintTitle": "TEMPORARY MAINTENANCE — mandatory homing is disabled",
  "cfg.homing.maintBody": "Mandatory homing has been disabled since <strong>${dateStr}</strong> (${age}). While it stays this way, running anything without referencing first can crash an axis into the frame. Turn the toggle back on when you finish the test.",
  "cfg.homing.maintReactivate": "Re-enable mandatory homing",
  "cfg.homing.order.realLbl": "REAL order persisted in homeall.g:",
  "cfg.homing.order.realXY": "X \u2192 Y \u2192 Z (X/Y first — the tool goes down last)",
  "cfg.homing.order.realZ": "Z \u2192 X \u2192 Y (Z first — the tool lifts before moving XY)",
  "cfg.homing.order.realUnknown": "Order not detectable (homeall.g has no \u00abOrder: \u2026\u00bb comment — older version)",
  "cfg.homing.speedHint": "Recommended: ${recommended} mm/min",
  "cfg.about.soporte.title":      "For technical support",
  // t_b89ce390 (sep-2026): pista visible junto al summary del <details>
  // plegable, dice que es informacion de consulta y como abrirla.
  "cfg.about.soporte.summaryHint":"(point-of-need info — click to expand)",
  "cfg.about.soporte.info":
    "<strong style=\"color:#a855f7\">What is this?</strong> It's the <strong>stable identity of the unit</strong>: what does not change when you rename the machine or switch browsers. If you call support, this is what they will ask for — copy it with the button below and paste it in the email.",
  "cfg.about.soporte.lbl.name":   "Machine name",
  "cfg.about.soporte.lbl.idPlaca":"Board identifier",
  "cfg.about.soporte.lbl.mcu":    "MCU",
  "cfg.about.soporte.lbl.rrf":    "RRF version",
  "cfg.about.soporte.lbl.uuid":   "Installation UUID",
  "cfg.about.soporte.lbl.versions":"RotechOS versions",
  "cfg.about.soporte.lbl.env":    "Environment",
  "cfg.about.soporte.pending":    "(waiting for firmware)",
  "cfg.about.soporte.copyBtn":    "COPY SUPPORT BLOCK",
  "cfg.about.soporte.honor":
    "<strong style=\"color:var(--warn-strong)\">What does the UUID identify?</strong> It does <em>NOT</em> identify the physical board: if you reload the SD or switch browsers, a different UUID appears. It only helps support distinguish two different sessions on the same machine. <strong>The real unit identifier</strong> is the board one (above), which comes from the firmware.",

  // ── GUIDE panel ──────────────────────────────────────────────────────────
  "cfg.guide.title":              "My First Machining Job",

  // ── VIZ3D panel ──────────────────────────────────────────────────────────
  "cfg.viz3d.file.label":         "Load G-code file",
  "cfg.viz3d.drop.title":         "Drop a G-code file here",
  "cfg.viz3d.drop.hint":          "or click to pick one (.gcode, .nc, .tap, .ngc)",
  "cfg.viz3d.file.none":          "No file loaded",
  "cfg.viz3d.stats.label":        "Job statistics",
  "cfg.viz3d.stats.cut":          "Cut length (G1)",
  "cfg.viz3d.stats.rapid":        "Rapid length (G0)",
  "cfg.viz3d.stats.z":            "Z min / max",
  "cfg.viz3d.stats.area":         "X·Y area",
  "cfg.viz3d.stats.time":         "Estimated time",
  "cfg.viz3d.stats.lines":        "Lines",
  "cfg.viz3d.stats.empty":        "Load a file to see the statistics",
  "cfg.viz3d.prefs.label":        "Visual preferences",
  "cfg.viz3d.g0.opacity":         "G0 opacity (rapids)",
  "cfg.viz3d.g1.opacity":         "G1 opacity (cut)",
  "cfg.viz3d.show.tool":          "Show current tool",
  "cfg.viz3d.show.bbox":          "Job bounding box",
  "cfg.viz3d.show.grid":          "Machine area grid",
  "cfg.viz3d.legend.title":       "Color legend",
  "cfg.viz3d.legend.cut":         "Cut",
  "cfg.viz3d.legend.rapid":       "Rapid",
  "cfg.viz3d.legend.arc":         "Arcs",

  // ── WIZARD panel ─────────────────────────────────────────────────────────
  "cfg.wizard.prev":              "← BACK",
  "cfg.wizard.skip":              "Skip step",
  "cfg.wizard.next":              "Next →",

  // ── JOB HISTORY panel ────────────────────────────────────────────────────
  "cfg.hist.stat.jobs":           "Jobs",
  "cfg.hist.stat.spindle":        "Spindle hours",
  "cfg.hist.stat.dist":           "Distance",
  "cfg.hist.btn.export":          "Export CSV",
  "cfg.hist.btn.clear":           "Clear history",
  "cfg.hist.btn.resetmaint":      "Reset counters",
  "cfg.hist.col.date":            "Date",
  "cfg.hist.col.file":            "File",
  "cfg.hist.col.dur":             "Duration",
  "cfg.hist.col.state":           "Status",
  // ── JOB HISTORY — sub-tabs (Fase 4.17, t_f6dc18a8) ─────────────────────
  "cfg.hist.subtab.jobs":         "Jobs",
  "cfg.hist.subtab.maint":        "Maintenance",
  "cfg.hist.subtab.audit":        "Audit log",
  // ── JOB HISTORY — audit table columns ───────────────────────────────────
  "cfg.hist.audit.col.when":      "When",
  "cfg.hist.audit.col.event":     "Event",
  "cfg.hist.audit.col.who":       "Source",
  "cfg.hist.audit.col.prev":      "Previous value",
  // ── JOB HISTORY — per-task maintenance counters (t_a5ea80e4) ───────────
  // Each task has a {id, labelEn} in MAINT_TASKS (rotechos-modules.js) and
  // an editable threshold in jobhistory.json::taskThresholds. The labels
  // here are what the operario reads; the IDs are the canonical keys.
  "cfg.hist.task.cleanAndLubeGuides": "Clean and lube guides",
  "cfg.hist.task.inspectCollet":      "Inspect collet",
  "cfg.hist.task.inspectBelts":       "Inspect belts / ball screws",
  "cfg.hist.task.cleanElectronics":   "Clean electronics",
  "cfg.hist.task.col.task":           "Task",
  "cfg.hist.task.col.lastReset":      "Last serviced",
  "cfg.hist.task.col.hoursSince":     "Hours since",
  "cfg.hist.task.col.threshold":      "Threshold",
  "cfg.hist.task.col.progress":       "Progress",
  "cfg.hist.task.col.action":         "Action",
  "cfg.hist.task.btn.markDone":       "Mark serviced",
  "cfg.hist.task.never":              "Never",
  "cfg.hist.task.overdue":            "Overdue",
  "cfg.hist.task.neverReset":         "Never serviced",
  "cfg.hist.task.dlg.title":          "Mark maintenance done",
  "cfg.hist.task.dlg.msg":            "The previous \"last serviced\" timestamp for this task will be lost. Only the audit log keeps a record of it. Do this after performing the actual maintenance. Continue?",
  // Toast que dispara el handler de "Marcar revisado" por tarea. Sigue el
  // patron del modulo: clave i18n con fallback visible si la traduccion no
  // existe (es la misma curva que "msg.histCounters" en el reset global).
  "msg.histTaskDone":                 "Task marked as serviced",
  // ── JOB HISTORY — info boxes (panel-level) ──────────────────────────────
  "info.jobhistory.maint":        "Counters since last service. The <em>Reset counters</em> button zeroes them and leaves a record in the Audit log tab. The jobs history is not touched.",
  "info.jobhistory.audit":        "Append-only record of every history clear and maintenance counter reset. Entries cannot be erased from the UI.",

  // ── PINES (Controller) panel ─────────────────────────────────────────────
  "cfg.pines.title":              "Pin Map — BTT Scylla",
  "cfg.pinesFn.title":    "8. Free pins — Assignable functions",
  "cfg.pinesFn.intro":    "Assign a free pin to an operating function. Saved to <code>config-machine.g</code>; <strong>RESTART</strong> the board afterwards so the new M950 P/J take effect.",
  "cfg.pinesFn.vmos":     "<strong style=\"color:var(--warn-strong)\">PENDING BENCH TEST · V-MOS vs logic</strong><br><strong>A.4, A.5, A.6, A.7, C.4</strong> are POWER OUTPUTS that emit V-MOS (24/36/48 V). <strong>NEVER</strong> connect 5 V loads to them. <strong>B.7</strong> is a 5 V input: for push buttons or logic accessories.",
  "cfg.pinesFn.paroSw":   "<strong style=\"color:var(--red)\">STOP BUTTON READ BY SOFTWARE — this is NOT an emergency stop</strong><br>A button wired to a pin and read by the firmware does <strong>NOT</strong> cut the power: if the firmware hangs, this button does <strong>NOTHING</strong>. It is a convenient, quick stop button, and it does <strong>NOT replace the red mushroom E-stop wired in series with the power supply</strong>. That physical E-stop is the only thing that guarantees the machine loses power whatever happens.",
  "cfg.pinesFn.cols":     "<td class=\"pad-4-8\">Function</td><td class=\"pad-4-8\">Type</td><td class=\"pad-4-8\">Pin</td><td class=\"pad-4-8\">Mechanics / State</td><td class=\"pad-4-8\">Cockpit button</td><td class=\"pad-4-8\">Warning</td>",
  "cfg.pinesFn.enUsoMax": "Axis {a} homes to MAX; pin {p} is in use.",
  "cfg.pinesFn.noEntrada": "Pin {p} is not an assignable input.",
  "cfg.pinesFn.tipoDesc": "Unknown type \"{t}\" in {f}",
  "cfg.pinesFn.tipoNo":   "Pin {p} does not accept type {t} (function {f})",
  "cfg.pinesFn.duplicado": "Pin assigned to more than one function: ",
  "cfg.pines.s1.title":           "1. Endstops / Limits",
  "cfg.pines.s2.title":           "2. Probe & Tooling",
  "cfg.pines.s3.title":           "3. Spindle & Relay Control",
  "cfg.pines.s4.title":           "4. Accessories & Cooling (V-MOS PWM outputs)",
  "cfg.pines.s5.title":           "5. Lighting & Extras",
  "cfg.pines.s6.title":           "6. Stepper Motor Drivers (TMC2160)",
  "cfg.pines.s7.title":           "7. Communications",
  "cfg.pines.readonly":           "BTT Scylla pin reference — Read only",
  // ── Pines asignables a funciones (t_fa32b4d7, sep-2026) ──
  // Los ES ya viven en el HTML; aquí solo registramos las claves que el JS
  // pide por t() para evitar "missing translation" en consola y para que el
  // EN sea consistente con el resto del modal.
  "msg.pinesFuncionesSaved":
    "Pin assignment saved to config-machine.g. Remember to restart the Scylla for the new M950 P/J to take effect permanently.",

  // ── KEYBOARD panel ───────────────────────────────────────────────────────
  "cfg.kb.tabTitle":              "Keyboard shortcuts",
  "cfg.kb.btn.reset":             "Reset to defaults",
  "cfg.kb.btn.export":            "Export profile",
  "cfg.kb.btn.import":            "Import profile",

  // ── GLOSSARY (Wiki CNC) panel ────────────────────────────────────────────
  "cfg.glossary.title":           "CNC Wiki — Terms & Codes",

  // ── Footer action buttons (shared) ───────────────────────────────────────
  "cfg.btn.close":                "Close",
  "cfg.btn.apply":                "Apply",
  "cfg.btn.save":                 "Save",

  // ── Info boxes (mcfg-info-box) ───────────────────────────────────────────
  "info.macros_box":
    "Manage your macro files (M98). You can create new ones, edit their G-code, or delete them.",
  // FASE 4.7 (t_8759e5e7): la "rampa" del husillo no es la aceleración física
  // del VFD, sino un SOFTWARE wait (G4 dwell) en RRF. Mantener este texto
  // coherente con `startSpindleWithRamp` (rotechos.js:1299-1325) y con
  // `POSTPROCESADORES/FUSION 360/rotechosultimate.cps:357-361` y
  // `sys/spindle_ramp_wait.g`. La fórmula real y el SSOT del cálculo están
  // documentados en el JSDoc de cabecera de `rotechos-spindle.js`. La versión
  // ES en index.html (fallback inline) NO puede moverse desde esta tarjeta
  // porque index.html es un archivo prohibido del carril.
  "info.spindleDelay":
    "Time the firmware waits after <code>M3 S</code> before allowing cutting movements. Allows the spindle to reach the programmed speed. Inserted as <code>G4 P{ms}</code> in the post-processor.",
  "info.steps":
    "Number of motor steps equivalent to 1 mm of travel. <strong style=color:var(--text-1)>Formula:</strong><code style=color:var(--blue)>steps/mm = (steps/rev × microstepping) ÷ (leadscrew pitch mm)</code>. Example: 5 mm pitch leadscrew, 200 step motor, 16× microstepping → <code style=color:var(--blue)>200 × 16 ÷ 5 = 640</code>. For belt-driven axes: <code style=color:var(--blue)>(200 × 16) ÷ (pulley teeth × belt pitch mm)</code>.",
  "info.microsteps":
    "Driver resolution: how many microsteps the TMC2160 divides each full motor step into. <strong style=color:var(--text-1)>Allowed values:</strong> 1, 2, 4, 8, 16, 32, 64, 128, 256. <strong style=color:var(--text-1)>Recommended on this board: x16</strong> (enough for most applications without overheating the driver). x32 fine-tunes positioning further but doubles STEP frequency — verify your firmware supports it before raising.<br><br><strong style=color:var(--text-1)>Interpolation (I1)</strong>: the TMC2160 interpolates position to 256× between real steps without changing the STEP frequency. It adds smoothness and quieter motion without changing resolution. Enable only if your driver supports it.<br><br><strong style=color:var(--warn-strong)>Beware of steps/mm.</strong> Changing microstepping <strong>rescales the M92 calibration</strong>: moving from x16 to x32 doubles the steps/mm so the machine still moves the same distance. The UI recalculates M92 automatically and shows you the before/after before saving.<br><br><strong style=color:var(--warn-strong)>Requires a board restart.</strong> M350 changes the TMC2160 driver configuration and cannot be applied live.",
  "info.current":
    "RMS current supplied to each motor in milliamps. <strong style=color:var(--text-1)>Rule:</strong> use 70–85% of the motor's rated current to balance torque and temperature. Too high → the motor overheats and the driver protects itself. Too low → step loss under load. <strong style=color:var(--text-1)>Idle %</strong> reduces current when the motor is stopped for more than 30s; 20–40% is standard.<br><br><strong style=color:var(--text-1)>Where do I get the motor's rated current?</strong> It is on the NEMA 23 label on your machine or on the manufacturer's datasheet (a typical value for NEMA 23 is 2.0–2.8 A = 2000–2800 mA; at 70–85% → 1400–2380 mA). The placeholders (1200 mA) suit NEMA 23 motors in the 2.0–2.5 A range. If your motor has a different rated current, set this field to 70–85% of that value.",
  "info.dir":
    "Reverses motor rotation direction without changing wiring. Use it if an axis moves in the opposite direction than expected after homing. <strong style=color:var(--text-1)>S1</strong> = normal direction · <strong style=color:var(--text-1)>S0</strong> = inverted. Tap a card to toggle. Save and restart the machine afterwards to apply the change.",
  "info.extdrv":
    "Enable per axis when using an <strong style=color:var(--text-1)>external STEP/DIR driver</strong> instead of the onboard TMC2160. With an external driver, current is managed by the driver itself — M906 is ignored for that axis. Generates <code style=color:var(--purple)>M569 P{n} D2</code> (RRF 3.5+). Requires a board restart after saving.",
  // (t_85bdd371, 2026-09-07) Aviso de riesgos del driver externo — caja naranja
  // que precede al bloque info.extdrv. Antes en ES puro: traducía EN el EN del
  // título del bloque siguiente pero NO este, dejando al operario anglófono con
  // un cartel de "DRIVERS EXTERNOS — FIRMWARE SIN VALIDAR EN BANCO" y el texto
  // del riesgo que viene después en español. Sin él, la advertencia era
  // invisible para el usuario EN. NO tocar M906/M569 — eso es de la pestaña
  // MOTORES, y ese panel tiene su propia rama i18n (info.motors.*).
  "info.extdrv.warnbox":
    "<strong>EXTERNAL DRIVERS — FIRMWARE NOT VALIDATED ON A REAL MACHINE</strong><br>Per-axis controls are available again. Generating <code>M569 P{n} D2</code> and skipping M906 is implemented, but still <strong>requires physical validation on the machine before production use</strong>.<br><br><strong style=color:var(--warn-strong)>Before activating an external driver, understand the risk:</strong> the RRF firmware manages the current of the board's built-in drivers (TMC2160) via <code>M906</code>. Activating an external driver (Leadshine DM542, DM860, CL57T closed-loop, HBS57 closed-loop, CW5045…) means the firmware will NOT send <code>M906</code> (current) and will NOT supervise the driver. <strong>If the external driver's current is misconfigured (on its own hardware dial), the motor can burn</strong> or lose steps without RRF noticing. <em>Recommended only if you have experience with that specific driver and have validated its response at slow speeds.</em><br><br><strong style=color:var(--warn-strong)>About closed-loop drivers (CL57T, HBS57…):</strong> RRF 3.5.4 sees them as external STEP/DIR — the encoder and ALARM are handled inside the driver and <strong>the firmware does not read them</strong>. Position correction by encoder happens inside the driver, not in RRF. If the driver loses steps without triggering ALARM, RRF does not know: it still believes the axis is where it commanded. The driver's hardware dial still rules the current.",
  "info.maxspeed":
    "Absolute maximum speed for each axis. The firmware <strong style=color:var(--text-1)>will never exceed it</strong> even if the G-code requests more. Start conservatively (X/Y 3000, Z 600 mm/min) and increase progressively while checking for step loss or excessive noise.",
  "info.accelseda":
    "Acceleration in <strong style=color:var(--purple)>manual mode (SEDA)</strong>. Low values = smooth movements for positioning. Activates automatically when jogging.",
  "info.jerkseda":
    "Jerk in <strong style=color:var(--purple)>manual mode (SEDA)</strong>. Low jerk = ultra-smooth transitions when positioning. Activates automatically when jogging.",
  "info.rayo":
    "These values activate <strong style=color:var(--text-1)>automatically when running a job (G-code)</strong> and determine how the machine follows complex toolpaths. <strong style=color:var(--yellow)>Low Acceleration and Jerk = a thoroughbred in shackles</strong> on circles and curves. On toolpaths with thousands of tiny segments (circles, arcs), the machine will slow down at every junction if these values are too conservative.<br><br><strong style=color:var(--text-1)>Golden rule:</strong> If the machine never reaches the programmed speed on curves, increase Acceleration and Jerk. If it vibrates or loses steps, lower them.",
  "info.jogspeed":
    "Speed at which the axes move for each manual jog step. Adjusted so that <strong>short steps are slow</strong> (precision) and <strong>long steps are fast</strong> (positioning). The Z axis is limited to a maximum of 10mm for safety.",
  "info.backlashX":
    "Measured play on the X axis. Move the axis several times in both directions with a dial indicator resting on the table to measure the difference. Typical values: 0.02–0.15 mm for ball screws, more for trapezoidal screws.",
  "info.backlashY":
    "Measured play on the Y axis. Same procedure as X. If using a Gantry configuration (two Y motors), both motors share the same backlash value.",
  "info.backlashA":
    "Play on the 4th axis (A/rotary). Only relevant if you have an additional axis. On rotary axes, play is measured in degrees, but RRF uses standard axis units.",
  "info.viz":
    "Load a local G-code to analyze toolpaths, estimated times, and area overflows before machining. Critical warnings (positive Z, out of bounds) appear automatically.",
  "info.jobhistory":
    "Persistent log of every machining job. Statistics accumulate spindle hours and travel distance for maintenance alerts.",
  // NOTA (19-sep): aqui habia 17 claves EN ESPAÑOL repitiendo las del bloque EN
  // de arriba. En un objeto literal gana la ultima, asi que el operario en
  // ingles veia la tarjeta de mantenimiento en español y las 17 inglesas
  // estaban muertas. Lo cantaba `no-dupe-keys` desde el primer dia: nadie lo
  // veia porque el lint NO era un gate. Retirado.
  "info.shortcuts":
    "List of system keyboard shortcuts. Press CHANGE to reassign a key. Shortcuts are saved in the browser (localStorage). Jog keys (arrows/PageUp/PageDown) are reserved and cannot be reassigned.",
  "info.wiki":
    "Quick reference for the G-code terms and commands appearing in the interface. If you are a beginner, consult it when you see a code you don't understand.",
  "info.guide_box":
    "This guide walks you step-by-step from having your G-code ready to removing the finished part.",


  // ── AUDIT ADDITIONS: Missing translations for Configuration Panels & Wiki ──

  // ── Missing Power Supply Configuration ──
  "label.psu-volt": "Power Supply Voltage (V)",
  "info.psu-volt": "Power loss detection (M911) and telemetry diagnostics derive their voltage thresholds from this value. Change it if your machine uses a different power source (24V, 36V, etc.).",

  // ── Action Buttons Mapped to HTML Autogenerated Keys ──
  "button.crear-nueva-macro-63a5": "CREATE NEW MACRO",
  "button.subir-archivos-9802": "Upload files",
  "span.subiendo-7a26": "Uploading... 0%",

  // ── Machining Guide (Wizard & Manual steps) ──
  "div.1-conectar-ea3a": "1. Connect",
  "div.accede-a-b0e9": "Navigate to 192.168.1.1 in your browser by connecting to the machine's local network (wired Ethernet or workshop WiFi). Verify that the connection indicator in the top bar is green.",
  "div.2-home-referenciar-e-687b": "2. Home (Reference axes)",
  "div.ejecuta-654f": "Run Home All (G28) so the machine references all axes. This is mandatory every time the machine is powered on. Coordinates in the DRO will be updated.",
  "div.3-subir-el-archivo-g-a6e6": "3. Upload G-code file",
  "div.ve-a-f496": "Go to",
  "div.4-montar-pieza-y-fre-c941": "4. Mount workpiece and bit",
  "div.fija-el-material-de--dd3f": "Secure the raw material onto the CNC table. Insert the appropriate milling tool/bit into the spindle and tighten it securely using the collet wrench.",
  "div.5-establecer-el-orig-2f6a": "5. Set workpiece origin",
  "div.usa-los-botones-de-ebe8": "Use the JOG controls to position the cutting tool at the corner or center of the workpiece:",
  "li.mueve-hasta-el-punto-6266": "X and Y: Jog to the reference corner and press X 0 / Y 0.",
  "li.baja-hasta-tocar-la--d22a": "Z: Lower until the tool tip touches the material surface (or use the Z probe), then press Z 0. This establishes the workpiece origin (0,0,0).",
  "div.6-verificar-opcional-7b11": "6. Verify (optional)",
  "div.revisa-la-trayectori-3ce8": "Review the toolpath in the G-code 3D viewer to confirm everything is correct. Check that feed and spindle overrides are set to 100%.",
  "div.7-ejecutar-3e6a": "7. Run",
  "div.selecciona-el-archiv-7b90": "Select the file in",
  "div.8-durante-el-trabajo-381f": "8. During operation",
  "li.monitoriza-el-progre-c214": "Monitor the path progress in the 3D visualizer.",
  "li.usa-ecf8": "Use PAUSE (orange) if you need to inspect the cutter or clean chips.",
  "li.ajusta-los-685f": "Adjust feed/spindle speed overrides in real time if necessary.",
  "li.rojo-solo-en-caso-de-e440": "STOP (red) only in case of emergency — halts all movements instantly.",
  "div.9-al-terminar-2c4e": "9. Upon completion",
  "div.el-spindle-se-detend-c483": "The spindle stops automatically. The gantry moves to a safe clearance height (if included in post-processed G-code). Remove the finished part.",
  "div.cambio-de-herramient-3ec7": "Tool change (Assisted Tool Change / SAC)",
  "div.si-tu-g-code-incluye-4eda": "If the G-code contains a tool change command (M6), the machine will pause and guide you through swapping the bit, re-measuring the Z height, and resuming automatically.",

  // ── Controller Pinout Legend ──
  "p.pines-de-los-8-puert-5ff2": "Optocoupled inputs for limit switches and endstops:",
  "p.pines-dedicados-a-la-9723": "Dedicated pins for tool probing and measurement:",
  "td.probe-sonda-z-a00d": "Z Probe (physical tool setter button, Tool connector)",
  "p.pines-para-controlar-45c4": "Pins to control the cutting spindle and auxiliary power circuits:",
  "td.rel-mec-nico-220v-664b": "Mechanical Relay (220V spindle power)",
  "td.velocidad-pwm-0-10v-26e9": "Spindle PWM Speed Control (0-10V)",
  "td.direcci-n-m3-m4-31ef": "Spindle Direction (M3/M4)",
  "p.salidas-de-potencia--036a": "High-current MOSFET outputs for pumps, mist cooling, and 24V fans:",
  "td.mist-neblina-m7-25f1": "Mist Coolant (M7 air/oil pump)",
  "td.cool-refrigerante-m8-42b9": "Flood Coolant (M8 water pump)",
  "td.aux-0-ventilador-1-0413": "AUX 0 (Chassis Fan 1)",
  "td.aux-1-ventilador-2-f083": "AUX 1 (Electronics fans, F1)",
  "td.aux-2-ventilador-3-8d20": "AUX 2 (Spindle Fan 3)",
  "td.led-rgb-neopixel-ws2-75e0": "RGB LED Strip (NeoPixel WS2812b status lights)",
  "td.io-in-entrada-digita-b65a": "Auxiliary IO-IN (5V Digital input)",
  "p.referencia-de-pines--ade3": "Internal driver step/direction pins (read-only reference):",
  "td.rs485-vfd-7b4e": "RS485 Modbus (Serial VFD Control)",
  "td.uart-gen-rico-c446": "Generic Auxiliary UART",
  "p.para-conectar-invers-7af7": "RS485 / CAN Bus expansions and VFD serial lines:",

  // ── A-Axis Mode & Status Mismatches ──
  "span.desactivado-ff37": "Disabled",
  "span.esclavo-y-31a3": "Y Slave",
  "span.gantry-b535": "(gantry)",
  "span.eje-rotativo-cc16": "Rotary Axis",
  "span.a-independiente-d1de": "(independent A)",
  "label.idle-f2b6": "Idle %",
  "div.posici-n-del-sensor--2866": "Sensor Position (MCS)",
  "div.cero-z-cara-de-la-me-4e2f": "Z Zero (spoilerboard surface)",
  "title.nc-normalmente-cerra-6177": "NC = Normally Closed · NO = Normally Open",
  "title.pin-fijo-del-m-dulo--6391": "Fixed hardware pin (BTT Scylla V1.0) — read-only",
  "title.x-del-sensor-soft-li-5104": "Sensor X location = maximum X travel limit. Set under Travel limits.",
  "title.altura-a-la-que-el-s-dbd4": "Distance from the touch plate trigger height to the spoilerboard surface. Run the calibration assistant to measure automatically.",
  "title.solo-si-usas-una-pas-09bf": "PROBE Z touches the fixed button and sets Z=0 at the table PLUS this value. Enter your (measured) material thickness so zero lands on its surface. 0 = zero on the table.",
  "title.velocidad-del-primer-8e0b": "Initial fast probing speed (spindle search pass).",
  "title.velocidad-de-la-segu-b1e9": "Secondary slow probing speed (precision origin trigger).",
  "title.aceleraci-n-z-durant-7718": "Z-axis deceleration rate during probing cycles. Higher values reduce overtravel risk.",

  // ── Park Editor ──
  "h3.aparcar-editor-1047": "Parking Position Editor",
  "p.define-la-posici-n-d-2985": "Define parking coordinate coordinates and post-parking actions.",
  "div.posici-n-de-aparcado-73a0": "Parking Coordinates (G53 MCS)",
  "div.coords-m-quina-4030": "Machine coords",
  "div.0-m-ximo-e1f6": "0 = mechanical max",
  "div.velocidad-de-desplaz-1094": "Parking Feedrates",
  "label.velocidad-xy-mm-min-0a82": "XY Travel Speed (mm/min)",
  "label.velocidad-z-mm-min-a79f": "Z Lift Speed (mm/min)",
  "div.acciones-al-aparcar-179d": "Post-Parking Routines",
  "button.guardar-park-g-5082": "Save",

  // ── Height Probe Editor ──
  "h3.sonda-de-altura-edit-0deb": "Z probe — Probing settings",
  "p.los-valores-se-tradu-4d67": "Settings are automatically compiled to G-code commands inside probe.g.",
  "span.sonda-z-fija-de-supe-0da2": "Tool Port · Pin E.7 — Z-Probe (Normally Closed switch)",
  "div.aproximaci-n-r-pida-0a67": "Rapid Spindle Approach",
  "label.velocidad-b-squeda-m-f08c": "Fast Seek Speed (mm/min)",
  "div.retracci-n-tras-cont-1b94": "Tool Back-off / Retract",
  "label.distancia-retracci-n-54b6": "Back-off distance (mm)",
  "div.palpado-de-precisi-n-8413": "Precision Probing Pass",
  "label.dist-afinado-mm-dd3a": "Precision Search Distance (mm)",
  "label.velocidad-afinado-mm-b761": "Precision Probing Speed (mm/min)",
  "div.offset-z-espesor-blo-8a22": "Z-Offset Configuration",
  "label.espesor-bloque-mm-0--f6dc": "Mobile Touch Plate Thickness (mm) — 0 if none",
  "label.subida-final-segura--e0cd": "Safe Post-Probing Z Lift (mm)",
  "button.guardar-probe-g-671a": "Save",

  // ── Macro Editor & New Macro ──
  "h3.editar-macro-7053": "Edit Macro Script",
  "placeholder.ej-auto-center-ee56": "E.g., Auto Center Tool",
  "placeholder.g28-g0-x0-y0-bc4a": "G28 ; Home axes\nG0 X0 Y0 ; Rapid to origin",
  "h3.crear-macro-7297": "Create Custom Macro Script",
  "placeholder.ej-limpiar-mesa-c7b6": "E.g., Clear Spoilboard",
  "label.archivo-en-sd-34af": "SD Card Target Path",
  "span.0-macros-042c": "0:/macros/",
  "placeholder.nombre-g-ba20": "script_name.g",
  "div.la-extensi-n-g-se-a--4f68": "The .g file extension is appended automatically if omitted.",
  "placeholder.escribe-el-g-code-aq-fc95": "; Write your G-code lines here\nG28\nG0 X0 Y0",

  // ── 3D Probe setup modal ──
  "h3.palpador-3d-configur-20a3": "3D Touch Probe Settings",
  "p.busca-el-centro-y-la-0601": "Locates workpiece edges, holes, and top surface using an active touch probe on X, Y, and Z axes.",
  "span.palpador-z-manual-to-670a": "Tool Port · Pin E.7 — Manual Z Probe / Tool Setter",
  "div.dimensiones-del-palp-d26c": "Physical Stylus Dimensions",
  "label.di-metro-bola-mm-c2bd": "Stylus Ball Diameter (mm)",
  "div.de-la-esfera-de-cont-36d6": "Stylus tip ball diameter (Ø)",
  "label.longitud-v-stago-mm-3a33": "Stylus Stem Length (mm)",
  "div.distancia-porta-bola-8e8b": "Distance from toolholder face to ball center",
  "label.n-mero-de-sonda-9637": "Hardware Probe Channel",
  "div.sensors-probes-n-c3a1": "sensors.probes[N]  0=Z-Probe (E.7) · 1=Manual Z probe (E.7)",
  "span.0-probe-e15-1-tool-e-8a48": "0=Z-Probe (E.7) · 1=Manual probe (E.7)",
  "div.ejes-a-palpar-6e79": "Target Axes for Probing Cycle",
  "p.selecciona-qu-superf-aeac": "Select which directions to probe. Enabling 'Center' will probe opposing sides along X and Y to find the workpiece midpoint.",
  "div.velocidades-de-palpa-a9e4": "Probing Feedrate Stages",
  "span.b-squeda-r-pida-dff4": "Fast Edge Seek",
  "span.afinado-doble-toque-ab15": "Precision Double-touch Pass",
  "label.distancia-retroceso--ce93": "Back-off Distance (mm)",
  "p.el-palpador-realiza--5186": "Probing cycles perform a two-step touch: a fast feed to find the edge, followed by a slow retract and crawl pass for maximum accuracy.",
  "div.offset-del-palpador--4d88": "Active Probe Offsets relative to Spindle Centerline",
  "label.offset-x-mm-023c": "X Offset (mm)",
  "div.palpador-a-la-derech-68b3": "+ = Probe is shifted to the right of spindle",
  "label.offset-y-mm-199e": "Y Offset (mm)",
  "div.palpador-adelante-2522": "+ = Probe is shifted forward of spindle",
  "label.offset-z-mm-0dad": "Z Offset (mm)",
  "div.palpador-m-s-abajo-eb7e": "+ = Probe tip is lower than spindle face",
  "div.sistema-de-coordenad-de1a": "Target Work Coordinate System (WCS)",
  "p.wcs-al-que-se-aplica-d7ff": "The coordinate offset calculated during probing is written to the selected WCS using G10 L2.",
  "div.movimientos-de-segur-36f1": "Travel & Safety Clearance Settings",
  "label.altura-segura-z-mm-48a3": "Safe Clearance Z (mm)",
  "div.subida-antes-de-move-589a": "Z height lift before executing XY travel movements",
  "label.subida-final-mm-cb28": "Cycle Completion Z Lift (mm)",
  "div.posici-n-z-al-termin-d62a": "Absolute Z clearance height when probing completes",
  "label.velocidad-desplazami-b5d7": "Safety Travel Speed (mm/min)",
  "div.movimientos-en-vac-o-dc1e": "Feedrate for non-contact clearance travel",
  "label.ventana-desde-posici-b47d": "Maximum Probing Window (mm)",
  "div.distancia-hasta-la-p-9d44": "Maximum distance the axis will travel searching for contact",
  "div.opciones-post-palpad-4c42": "Post-Probing Routine Options",
  "div.palpado-autom-tico-d-e287": "Automated XY Corner Probing Cycle",
  "span.experimental-7e49": "· experimental",
  "div.la-m-quina-sondea-x--3ca1": "The machine automatically probes X and Y edges from a single starting coordinate (probe_xy_auto.g). Perform an air-test first. Clearance sizes are set in config.g.",
  "button.palpado-autom-tico-x-5a0b": "START AUTO XY PROBING",
  "button.guardar-probe3d-g-6f8f": "Save",

  // ── Confirm Actions & System Reboot ──
  "h3.confirmar-acci-n-69dd": "Confirm Action",
  "p.est-s-seguro-0e5e": "Are you sure you want to proceed?",
  "div.reiniciando-firmware-c63f": "REBOOTING FIRMWARE",
  "div.esperando-reconexi-n-db01": "Waiting to reconnect with controller board...",
  "div.0s-bb61": "0s",
  "div.macros-430d": "Macros",

  // ── CNC Wiki Glossary Entries ──
  "span.home-all-mueve-todos-e4b2": "Home All — Moves all axes to their limit switches (endstops) to establish the machine's zero reference position. Required upon power-up.",
  "span.sistema-de-coordenad-99f6": "Work Coordinate System (WCS). This is the 'workpiece zero' that you define using X 0 / Y 0 / Z 0. Distinct from the machine coordinate system (G53).",
  "span.enciende-el-spindle--32c1": "Turns on the spindle (cutting motor) clockwise at the specified RPM. Example: M3 S12000 = 12,000 RPM.",
  "span.apaga-el-spindle-la--b916": "Turns off the spindle. The cutting tool stops rotating.",
  "span.cambio-de-herramient-3d26": "Tool Change / Assisted Tool Change. The machine pauses, raises Z, and prompts you to change the bit. Afterwards, it automatically re-measures the Z height.",
  "span.parada-programada-de-a789": "Programmed Stop. Pauses the current job in a controlled manner.",
  "span.parada-de-emergencia-dcd6": "Emergency Stop (E-Stop). Immediately stops all movement and output (motors + spindle). Requires a full system reset afterwards.",
  "span.m24-reanudar-trabajo-275e": "M24 = Resume job. M25 = Pause job. These are triggered by the PAUSE/RESUME buttons in the UI.",
  "span.proceso-de-referenci-ddb0": "Axis referencing process. The machine moves until it triggers the limit switches to establish its position. Without homing, coordinates are not reliable.",
  "span.el-motor-que-hace-gi-e7a4": "The spindle motor that rotates the cutting bit. On this machine it may be a VFD (variable-frequency drive) controlled by firmware (6000–24000 RPM) or a Makita RT0701C with a manual dial. Speed is measured in RPM (revolutions per minute).",
  "span.sensor-de-final-de-c-3d67": "Limit switch / Endstop. Detects when an axis reaches the physical boundary of the machine to protect against mechanical crashes.",
  "span.ajuste-en-tiempo-rea-0520": "Real-time adjustment of feed rate or spindle speed. 100% = programmed speed. Decrease if chatter/vibration occurs, increase if performance is optimal.",
  "span.velocidad-de-avance--a5db": "The speed at which the tool moves along the material, measured in mm/min. Faster feeds reduce surface finish quality. Slower feeds improve quality but increase machining time.",
  "span.movimiento-manual-de-9e34": "Manual movement of the axes using directional controls. Used to position the tool relative to the workpiece prior to starting a job.",
  "span.work-coordinate-syst-20db": "Work Coordinate System. Defines the (0,0,0) origin of your workpiece. G54 is the default WCS.",
  "span.sensor-para-medir-au-5a43": "Probe / Touch plate. A sensor used to automatically measure workpiece Z-axis height. It is placed under the tool, and the machine feeds down until contact is detected.",
  "span.perfiles-cinem-ticos-52a8": "Machine motion profiles. SEDA = smooth and quiet movements optimized for manual jogging. RAYO = high precision and acceleration configured for cutting paths.",
  "span.lenguaje-de-instrucc-9a1c": "The programming language containing instructions read line-by-line by the controller to move and cut (each line is a command). Generated by CAM software based on your CAD design.",
  "span.machine-coordinate-s-eb73": "Machine Coordinate System. The absolute position relative to the physical machine origin established during homing. Used internally by the firmware; operations are performed in WCS (G54).",
  "span.cu-nto-puede-cambiar-0c95": "The instantaneous change in axis velocity (during acceleration changes and cornering). Limited by the firmware (M566) to keep movement smooth and prevent step loss.",
  "span.holgura-mec-nica-de--3537": "Mechanical play or backlash in leadscrews or belts, which causes lost motion when reversing directions. Can be compensated so physical position matches target coordinates.",
  "span.el-proceso-de-cortar-62a8": "Milling. The cutting process: the tool (end mill) rotates via the spindle while the machine moves the axes across the workpiece, removing material layer by layer.",

  // ── AUDIT ADDITIONS PART 2: Remaining missing keys and standard labels ──
  "td.enable-2fae": "Enable",
  "td.eje-7e4d": "Axis",
  "td.step-48c7": "Step",
  "td.dir-3c4e": "Dir",
  "div.bienvenida-a268": "Welcome",
  "button.cancelar-8476": "Cancel",
  "label.distancia-m-x-mm-88ce": "Max distance (mm)",
  "label.nombre-4777": "Name",
  "label.g-code-39da": "G-code",
  "span.cargando-licencia-116d": "Loading license...",
  "button.crear-macro-7297": "Create macro",
  "button.geometr-a-1ccd": "GEOMETRY",
  "button.velocidades-5807": "Speeds",
  "button.offsets-d552": "Offsets",
  "button.operaci-n-e97c": "Operation",
  "label.velocidad-mm-min-8319": "Speed (mm/min)",
  "button.confirmar-8487": "Confirm",
  "div.parado-f831": "STOPPED — 0% 00:00:00 --:--:--",
  "span.paro-2948": "E-STOP",
  "ap.banner.title": "You are connected to the machine's Access Point",
  "ap.banner.body": "You can work on this network or connect the machine to your WiFi.",
  "ap.banner.cta": "Use my WiFi",
  "ap.banner.stay": "Stay on this network",
  // 6-oct: tarjeta WiFi de CONFIGURACIÓN → Red (red propia sin USB).
  "cfg.wifi.title": "Machine WiFi",
  "cfg.wifi.apOnly": "Always work on the machine's own RotechOS network",
  "aria.cfg.wifi.apOnly": "Always work on the machine's own RotechOS network",
  "cfg.wifi.apOnlyHint": "For workshops without WiFi. The machine creates its own <strong>RotechOS</strong> network (factory password <code>rotechos</code>) and starts that way straight away. Connect your phone or computer to that network and open <code>http://192.168.1.1</code>.",
  "cfg.wifi.ssid": "Your WiFi network name",
  "cfg.wifi.pwd": "Your WiFi password",
  "cfg.wifi.join": "Connect to this network",
  "cfg.wifi.joinHint": "This screen will lose the connection for a moment. Connect this device to your WiFi and open http://rotechcnc.local or the IP your router gives it. If the machine has not joined within a couple of minutes, it creates the RotechOS network again and you can retry, without a USB cable.",
  "cfg.wifi.openHint": "Joins the machine to your workshop WiFi. If it does not connect, it goes back to the RotechOS network by itself.",
  "msg.wifiApFail": "Could not connect to ${ssid} after 12s — check the SSID and password are correct and the router is close; the 'RotechOS' network remains available as a fallback. Come back to this step once it's fixed (do NOT click Next).",
  "msg.wifiApOk": "WiFi connected",
  "msg.connLostIdle": "Connection to the machine lost. There was no job running when it dropped. Wait a few seconds: the interface will reconnect on its own. If it does not come back, reload the page (F5).",
  "msg.startEstadoCambio": "The machine changed state while you were confirming, so NOTHING has been started. Check what state it is in and press START again if that is still what you want.",
  "msg.configCambioDetras": "Another change was saved on the machine while you were editing, so this save was CANCELLED so as not to erase it. Nothing has been lost: close CONFIGURATION, open it again and repeat your change.",
  "msg.m584SinDriverLibre": "No free driver (P0-P3) left for the A axis: X, Y and Z already use the ones available on this board. The Scylla V1.0 has no P4 driver. Free an axis or check '; rotech-banned-drivers=' in config-machine.g.",
  "msg.wifiCredsSaneadas": "The SSID or password contains control characters; they have been stripped so the command could be sent. If the network does not associate, that is why.",
  "msg.wifiPwdLen": "The WiFi password must be 8 to 63 characters long.",
  "cfg.speeds.curve.title": "Acceleration & Deceleration Curve",
  "cfg.speeds.curve.axis": "Axis",
  "info.accelcurve": "Simulated velocity profile for a <strong>100 mm</strong> move using the current values in this tab: jerk start, constant-acceleration ramp up to max speed, cruise and symmetric braking. Compare <strong style='color:var(--purple)'>SEDA</strong> (smooth, manual) vs <strong style='color:var(--teal)'>RAYO</strong> (production). The chart updates instantly as you edit any field — nothing is sent to the machine.",
  "cfg.curve.peak": "peak",
  "cfg.curve.noreach": "does not reach max within",
  "cfg.curve.in": "in",
  "cfg.curve.total": "total",
  "cfg.curve.axis": "Axis",
  "dlg.wifiAp.title": "Credentials saved",
  "dlg.wifiAp.msg": "The machine will now reboot to join your WiFi network.<br><br>1. Wait about 40 seconds.<br>2. Connect this device to your WiFi network.<br>3. Open <code>http://rotechcnc.local</code> (or the IP address assigned by your router).",
  "title.spindle-mode-pwm": "PWM (0–10 V signal): the VFD receives a voltage proportional to RPM. The firmware generates the signal; you set the speed on the screen.",
  "title.spindle-mode-relay": "Relay (ON/OFF): turns the spindle on or off at a fixed speed you set manually on the VFD. No software RPM control.",
  "title.spindle-mode-modbus": "Modbus/RS485 (serial): the firmware talks to the VFD over a digital serial cable — sets RPM and reads status. Requires a Modbus-compatible VFD.",

  // ── Nombres accesibles (aria-label) de inputs sin <label> propio ─────────
  // M-1 (auditoria a11y jul-2026): 31 inputs del modal no tenian nombre
  // accesible. Los otros 63 se resolvieron con for= o con <label> envolvente.
  "aria.tgl.end.xmax": "X MAX endstop enabled",
  "aria.tgl.end.xmin": "X MIN endstop enabled",
  "aria.tgl.end.ymax": "Y MAX endstop enabled",
  "aria.tgl.end.ymin": "Y MIN endstop enabled",
  "aria.tgl.end.zmax": "Z MAX endstop enabled",
  "aria.tgl.end.zmin": "Z MIN endstop enabled",
  "aria.tgl.homingreq": "Require HOME (G28) before moving",
  "aria.tgl.sac": "ATC — Automatic Tool Change",
  "aria.tgl.softlimits": "Travel limits (software barrier)",
  "aria.endpin.xmax": "Endstop pin X Max",
  "aria.endpin.xmin": "Endstop pin X Min",
  "aria.endpin.ymax": "Endstop pin Y Max",
  "aria.endpin.ymin": "Endstop pin Y Min",
  "aria.endpin.zmax": "Endstop pin Z Max",
  "aria.endpin.zmin": "Endstop pin Z Min",
  "aria.hom.back.x": "X Fine (mm/min)",
  "aria.hom.back.y": "Y Fine (mm/min)",
  "aria.hom.back.z": "Z Fine (mm/min)",
  "aria.hom.seek.x": "X Seek (mm/min)",
  "aria.hom.seek.y": "Y Seek (mm/min)",
  "aria.hom.seek.z": "Z Seek (mm/min)",
  "aria.jog.0_1.xy": "Jog feed step 0.1 mm — XY (mm/min)",
  "aria.jog.0_1.z": "Jog feed step 0.1 mm — Z (mm/min)",
  "aria.jog.1.xy": "Jog feed step 1 mm — XY (mm/min)",
  "aria.jog.1.z": "Jog feed step 1 mm — Z (mm/min)",
  "aria.jog.10.xy": "Jog feed step 10 mm — XY (mm/min)",
  "aria.jog.10.z": "Jog feed step 10 mm — Z (mm/min)",
  "aria.jog.100.xy": "Jog feed step 100 mm — XY (mm/min)",
  "aria.jog.200.xy": "Jog feed step 200 mm — XY (mm/min)",
  "aria.jog.5.xy": "Jog feed step 5 mm — XY (mm/min)",
  "aria.jog.5.z": "Jog feed step 5 mm — Z (mm/min)",
  "aria.jog.50.xy": "Jog feed step 50 mm — XY (mm/min)",
  "aria.jog.500.xy": "Jog feed step 500 mm — XY (mm/min)",
  "aria.safeclearance": "Safe Z height (mm)",
  "aria.sl.max.x": "X Maximum (mm)",
  "aria.sl.max.y": "Y Maximum (mm)",
  "aria.sl.max.z": "Z Maximum (mm)",
  "aria.sl.min.x": "X Minimum (mm)",
  "aria.sl.min.y": "Y Minimum (mm)",
  "aria.sl.min.z": "Z Minimum (mm)",
  // t_080e0a9d (Fase 4.4 resto, 2026-09-02): aria-label del SVG del
  // volumen (rotechos-config-modal.js:renderSoftLimitsVolume).
  "aria.sl.volumeBox": "Work-volume visual: X/Y/Z range bars with the current head position dot.",

  // ── I18N REPASO t_5b7bce4f (12-ago-2026) ─────────────────────────────────────
  // Claves usadas en el HTML pero SIN entrada EN en HEAD HOY. La app, con idioma=en,
  // mostraba el literal ES como fallback (modelo ES-dominante). Se anaden las
  // traducciones faltantes para que la conmutacion ES↔EN cubra toda la UI.

  // Modal CONFIGURACION — subtitulo / ayuda
  "cfg.modal.subtitleHelp":
    "The RepRapFirmware (RRF) runs on the BTT Scylla V1.0 board and stores its settings on the controller's SD card. This panel sends each value to the firmware, which persists the changes through a safety write into the appropriate config file.",

  // Tab PIN HTTP (M551) — titulo de la pestana
  "cfg.tab.pin": "PIN HTTP (M551)",

  // Subpanel PIN HTTP — cabecera y campos
  "cfg.pin.title": "PIN HTTP (M551)",
  "cfg.pin.honesty":
    "<strong style=color:var(--warn-strong)>Important:</strong> the PIN travels unencrypted over HTTP — it deters casual access (a neighbour, a guest, a technician on your local network) but NOT someone sniffing traffic. For real protection, segment the workshop network (a VLAN or isolated subnet for the machine). The physical emergency stop (firmware shield or hardwired mushroom button) is always available, PIN or no PIN.",
  "cfg.pin.statusNone": "Status: (no PIN set)",
  "cfg.pin.label": "New PIN (optional)",
  "cfg.pin.inputPh": "No change",
  "cfg.pin.inputCfmPh":           "Repeat PIN",
  "cfg.pin.charset":
    "Allowed: letters, digits and the symbols <code>-_.@#!?,:</code> · max 24 characters.",
  "cfg.pin.btnSet": "Set / change PIN",
  "cfg.pin.btnRemove": "Remove PIN",
  "cfg.pin.warning": "<strong style=color:var(--warn-strong)>Before enabling the PIN, bear in mind:</strong><br>1. <strong>The browser-triggered emergency stop moves behind the login session.</strong> If you log out, the network drops, or the browser loses connection, the red button on the panel will NOT be able to stop the machine.<br>2. <strong>We recommend a physical hardwired mushroom button</strong> wired to a Duet GPIO (M581 shield, already active). Without it, in an emergency the operator has to reach the workshop's main isolator switch.<br>3. <strong>If you forget the PIN, recover it via SD</strong>: power the machine off, edit <code>sys/config-machine.g</code> and remove the <code>M551 P\\\"…\\\"</code> line. Your calibration is NOT lost. Full procedure in <em>SOPORTE_CAMPO §5</em>.<br>4. <strong>If anyone has write access to the SD or to <code>rr_upload</code></strong>, they can erase or change the PIN by overwriting <code>config-machine.g</code> and rebooting. The UI cannot prevent it (the RRF HTTP API only checks M551 on <code>/rr_connect</code>). Defense: isolated workshop network or HTTPS.",

  // School-mode tooltip de la tab PIN
  "school.pin":
    "<strong>PIN HTTP (M551)</strong>Optional password to deter casual access to the UI. It is NOT encryption: the PIN travels over HTTP in plain text, so anyone on the same network can read it. Use a strong workshop network (VLAN or isolated subnet) for real protection. The physical E-STOP mushroom button keeps working with or without PIN.",

  // t_f8b27b80 (2026-09-05) — info-boxes EN para los 3 huecos AVANZADO.
  // El EN sigue el patrón azul "¿Qué hace?" + bloque naranja de peligro físico.
  // Si tu build RRF-STM32 no soporta M593, el fichero lo avisa (config.g:104);
  // el texto EN lo refleja para que el operario en inglés también lo vea.
  "info.motortimeout.tab":
    "<strong style=color:var(--warn-strong)>Z keeps the spindle weight by gravity.</strong> The Z leadscrew is not self-locking: if Z de-energises, the cutter drops. The factory default is one day precisely so Z never releases. Lowering this has a real physical consequence. <code>M84 S</code> = seconds without movement before releasing the motors.",
  "info.fans.tab":
    "They switch on by themselves when the board processor reaches this temperature, or when a motor driver warns that it is getting hot, and switch off when it drops. The board warns at 55 °C: set a lower value. <strong>AUX1 outputs the power supply voltage (24 or 48 V): the fans must be rated for it.</strong>",
  "info.network.warn":
    "<strong style=color:var(--warn-strong)>FTP and Telnet have no authentication.</strong> Turning them on exposes the machine to anyone on the local network who knows the IP. Do not turn them on unless your workshop network is segmented. <strong>HTTP (P0) cannot be disabled from here — only by restarting the board.</strong>",
  "info.inputshaping.tab":
    "<strong style=color:var(--blue)>Input shaper (M593):</strong> pre-corrects the move to cancel the ringing left on the finish. <strong style=color:var(--warn-strong)>Starting point, not a tuned value.</strong> The file warns: <code>F40</code> with <code>zvd</code> is an initial estimate; the right thing is to measure your machine's resonance (accelerometer, <code>M956</code>) and adjust <code>F</code>. If your RRF-STM32 build does not support <code>M593</code>, it is ignored without harm.",

  // Info-box husillo — selector de variante VFD vs Makita (t_028bceef: + Láser)
  "info.spindle.variant":
    "<strong style=color:var(--blue)>What type of head do you have?</strong> The options in this tab <strong>only apply</strong> to a head driven by firmware. <strong>PWM/Relay/Modbus</strong> are for a spindle (VFD); <strong>Laser</strong> is for a laser diode via the SPIN interface.<br><br>If your head is a <strong>Makita RT0701C (manual dial)</strong>: this panel <strong>does not affect</strong> its speed — the dial drives the motor directly. Use this tab only for the <strong>Spindle warm-up</strong> button (thermal holding ramp). The Mode, PWM/Relay/Modbus/Laser, Minimum/Maximum and Cooling fields can be ignored.",

  // Aviso modo LÁSER — PENDIENTE BANCO (t_028bceef)
  "info.laser.warn":
    "<strong style=color:var(--warn-strong)>Laser mode — NOT VALIDATED in bench yet.</strong> The laser-diode control via <code>SPD</code> (B.1, TTL/PWM with the Speed-OUT jumper set to DO) and <code>SP-EN</code> (C.5) has NOT been validated on hardware. <strong>Do NOT claim it works until a bench session.</strong> <code>S{1–100}</code> is <strong>power percentage</strong>, NOT RPM — the UI adapts the labels but the value is the laser duty-cycle. <strong>MOSFET outputs AUX0/AUX1/AUX2 are NOT offered</strong>: they switch the <code>V-MOS</code> rail voltage and would destroy the TTL controller.",

  // Tooltip del 4.º modo de cabezal (t_028bceef)
  "title.spindle-mode-laser":
    "Laser (TTL/PWM via SPD): the SPD output on the SPIN connector emits PWM when the Speed-OUT jumper is set to DO. SP-EN (C.5) acts as a safety enable, lets firmware turn the laser off. Range 0–100 % power — NOT RPM.",

  // ── I18N REPASO t_5b7bce4f — 2 claves huérfanas reales detectadas en HEAD ──
  // (a) Aviso del 4.º eje A (div.aviso-eje-a-hardware): info-box naranja que
  //     aparece siempre que el eje A está habilitado. Sin EN, en idioma=en se
  //     quedaba como fallback ES.
  "div.aviso-eje-a-hardware":
    "<strong style=color:var(--warn-strong)>Only if you have extra hardware.</strong> This machine ships with X/Y/Z. Changing this dial requires <strong>a motor wired to whichever driver is left free</strong> (this board has P0 to P3, and X/Y/Z already take three) and re-wiring. If your machine does not have one, leave it <strong>Disabled</strong> — on the next restart, the firmware will look for a motor that is not there and show errors until you come back to this tab.",

  // (b) Title del botón PIN en el modal CONFIG (tooltip nativo del navegador,
  //     data-i18n-title). El botón ya tiene un tooltip rico via data-school
  //     (school.pin, traducido más arriba); este title= es el fallback nativo
  //     que ven usuarios sin hover. El bug detectado: el HTML tenía
  //     title="title.pin-http-del-panel-de-control-7c44" (la clave literal
  //     como texto) — el motor i18n no podía traducir lo que no existía en ES.
  //     El parche de la tarjeta t_5b7bce4f restaura el title= correcto en el
  //     HTML (ver index.html:489) y añade esta entrada EN.
  "title.pin-http-del-panel-de-control-7c44":
    "Open the PIN HTTP (M551) tab — set or change the access password",

  // ── I18N REPASO t_f38e1b87 (config-novato2) — 5 info-boxes nuevos ──
  // (1) Pestaña INFO/ABOUT — aclarar que es "Identidad de la máquina", no "acerca de"
  "info.about.tab":
    "<strong style=color:var(--blue)>What does this tab do?</strong> This is the <strong>Machine Identity</strong> panel (not an \"about this application\" page). Here you set the name this Scylla advertises on the network (M550), see the RotechOS version, the GPLv3 license, and open the system diagnostic. <strong>It does NOT touch calibration</strong>: the calibration controls live in the tabs on the left (MOTORS, ENDSTOPS, HOMING…).",

  // (2) Pestaña WIZARD — explicar el salto automático en máquinas vírgenes
  "info.wizard.intro":
    "<strong style=color:var(--blue)>Why am I here?</strong> If your Scylla is brand new or has never been calibrated, this is the panel that opens when you press <strong>Settings</strong> (instead of the main configuration screen). It guides you through 12 steps covering network, motors, endstops, homing, probe and spindle. <br><br>Once you complete the wizard (or if the machine was already calibrated), pressing Settings opens the <strong>MOTORS</strong> tab. You can return to this wizard any time from the <strong>FIRST SETUP</strong> tab under the HELP group.",

  // (3) Pestaña PIN HTTP — explicar M551 y diferencia con "PIN de seguridad"
  "info.pin.m551":
    "<strong style=color:var(--blue)>What is M551?</strong> It is the <em>standard RRF G-code</em> that defines the web UI password (<strong>M</strong>-code <strong>551</strong>). What you type here becomes the <code>M551 P\"your_pin\"</code> line in <code>config-machine.g</code>.<br><br><strong>Is it the same as the machine PIN?</strong> <strong>No</strong>: this is a password for the <em>web interface</em> (it keeps guests out of the panel). It is NOT a firmware security PIN, it does NOT block G-code movements from a session that's already open, it does NOT encrypt anything (see the orange block below). If you need physical safety, use a <strong>hardwired mushroom button</strong> (M581) or a main isolator switch.",

  // (t_85bdd371, 2026-09-07) Tres avisos físicos de la pestaña PINES / CONTROLLER
  // sobre cómo alimentar y cablear la placa sin romperla. Antes en ES puro:
  // el operario con la UI en inglés veía el título "Tres avisos…" y los 3
  // textos en español, anulando la protección. Cada uno en su propio bloque
  // data-i18n-html porque cada uno protege contra un error físico distinto
  // y unirlos los haría ilegibles (cajas separadas = escaneo visual rápido).
  "info.power.header": "<strong>Three warnings that keep the board alive</strong>",
  "info.power.usb":
    "<strong>Powering via USB.</strong> If you are going to power the controller through USB-C for desk setup, <strong>V-Motor, V-MCU and V-MOS must be disconnected</strong>. Powering both sides at once can take down the computer's USB port.",
  "info.power.digital5v":
    "<strong>The digital input is 5 V.</strong> Only 5 V. Feeding more voltage damages the microcontroller irreversibly, and that is not repaired: the board is replaced.",
  "info.power.jumpers":
    "<strong>The probe and tool-setter jumpers.</strong> Do NOT place the jumper in the <code>VMOS</code> position of <code>Vprobe</code> or <code>Vtool</code> if your V-MOS passes 24 V: the optocoupler of that input is low-voltage and will be destroyed.",


  // (4) Pestaña ENDSTOPS — por qué los pines son readonly
  "info.endstops.pins":
    "<strong style=color:var(--blue)>Why is the Pin field greyed out (not editable)?</strong> On this board (<strong>BTT Scylla V1.0</strong>) the inductive sensors of each axis are wired to <strong>fixed inputs</strong> on the controller: <code>D.11</code> (X MIN), <code>C.6</code> (X MAX), <code>A.8</code> (Y MIN), <code>D.14</code> (Y MAX), <code>C.7</code> (Z MIN), <code>D.12</code> (Z MAX). That is a hardware decision by the manufacturer, not something that can be changed in software.<br><br><strong>What if my sensor is wired to a different pin?</strong> This board does not support that: you would need to physically re-wire to the factory pin, or use a different mapping shim. <strong>What you CAN edit here</strong> is the ON/OFF toggle (to disable a specific endstop) and the NC/NO type (sensor logic).",

  // (5) Pestaña SPEEDS — banner ámbar que distingue SEDA vs RAYO

  // (6) BACKLASH — el campo YA está en 0 por defecto, ampliar el info-box
  //     principal para que un usuario sin comparador de reloj sepa que puede
  //     dejarlo en 0 sin problemas. Ver hallazgo A-16 del acta origen.
  "info.backlash":
    "<strong style=color:var(--text-1)>Backlash</strong> (mechanical play) is the slack present in leadscrews, gears, and belts: when the motor reverses direction, the tool does not move immediately until that slack is taken up. It causes positioning errors during direction changes. <strong style=color:var(--text-1)>M425</strong> tells the firmware how many extra mm to advance when reversing to compensate for it.<br><br><strong style=color:var(--text-1)>Don't have a dial indicator?</strong> No problem: leave the fields at <strong>0</strong> and the machine will work. Compensation is a fine-tuning for advanced users; without measurement, an invented value is WORSE than zero (it can amplify the problem instead of fixing it). If you notice visible steps on finishing passes, ask your dealer to measure the backlash for you.",

  // (7) BACKLASH S=0 — cuándo SÍ tocarlo (ver hallazgo A-17 del acta origen).
  "info.backlashSpeed":
    "Speed at which the extra compensation movement is applied when reversing direction. <strong style=color:var(--text-1)>0 = use the current movement speed</strong>. A specific value allows applying the compensation more slowly to avoid stressing the mechanics. Recommended: leave at 0 unless experiencing specific issues.<br><br><strong style=color:var(--warn-strong)>When SHOULD you change S?</strong> Only if when reversing direction you hear <em>thumps</em> or see <em>vibration</em> on the axis (the extra backlash pulse is being applied too fast). In that case try values between 300–800 mm/min. <strong>If you don't notice those symptoms, leave S=0</strong>: the firmware already picks a sensible speed.",

  // ── I18N REPASO t_f38e1b87 (config-novato2) — 8 info-boxes nuevos ──
  // (1) SOFT LIMITS — los placeholders vienen del área real de la máquina.
  //     Peligro: el operario teclea el área del cliente pensando que es la
  //     predeterminada y se estampa. Ver hallazgo A-12 del acta origen.
  "info.softlimits":
    "<strong style=color:var(--blue)>Where do the placeholders (X 530 · Y 830 · Z −115) come from?</strong> They are the <strong>factory-calibrated values for this specific machine</strong>: X width 530 mm, Y depth 830 mm, Z from 0 (top) to −115 (bottom).<br><br><strong>Are they right for your machine?</strong> <strong>Only if it is the standard configuration</strong>. If your machine has a different area (different leadscrews, smaller table, less Z travel), the soft limits do NOT replace endstops: if you enter values larger than the real area, the firmware will allow moves that hit the frame without the endstop stopping them. <strong>Measure before changing anything</strong>: with the endstops active, drive each axis to its real mechanical stop and read the coordinate on the DRO.<br><br><strong>Safe editing sequence:</strong> always start with <em>Endstops</em> (verify they trigger) and <em>Homing</em> (verify it ends with axes at coordinate 0); then set the soft limits to a VERY conservative value (5–10 mm less than the real area) and gradually open up until the largest workpiece you use fits.",

  // (t_c2dce523, sep-2026) info.mesh — caja informativa larga de la pestaña
  // MAPA DE ALTURA. La prosa explica QUÉ es la malla y por qué se ata al
  // material — la cita "trabajar con una compensación vieja de otro material
  // es peor que no tenerla" viene del briefing, así que va literal.
  "info.mesh":
    "<strong style=color:var(--blue)>Why an N×M grid?</strong> A board is never flat. Without compensation, an engraving that should be 0.3 mm deep disappears at one corner and plunges at the opposite. The grid lets the firmware adjust Z to the real surface during the job.<br><br><strong style=color:var(--blue)>This map belongs to the MATERIAL currently on the bed.</strong> If you swap the workpiece, re-probe — using a map from another board is worse than having no map at all. The <em>Current material</em> note is saved with the JSON so you remember what it was measured on.<br><br><strong style=color:var(--blue)>Single point ≠ mesh.</strong> The Z Probe tab sets Z=0 at a single point (the zero of the workpiece). The Height Map adjusts Z across the whole bed following the warp of THIS board. They are different operations — use both, in this order: Z=0 first, then mesh.<br><br><strong style=color:var(--blue)>Bank pending.</strong> Activation of compensation in this release is a placeholder: the JSON is mapped onto the RRF native heightmap.csv before sending G29 S1/S0, and that mapping has not been validated against the Scylla yet. The probe, save/load and visualisation are real; activate is documented but does not yet drive G29.",


  // t_080e0a9d (Fase 4.4 resto, 2026-09-02): explicación del signo de Z en
  // su propio bloque amarillo, separada del info-box azul genérico para no
  // perderse. Razón: confundir el signo Z baja la fresa contra la mesa, es
  // el error más caro de esta pantalla.
  "info.softlimits.zSemantics":
    "<strong style=color:var(--warn-strong)>The Z sign (the most expensive thing on this tab).</strong> <strong>Z goes from 0 (top, free) to −115 (bottom, cutter into material)</strong>. The <strong>MINUS</strong> sign means the cutter is <em>going down</em> into the workpiece — <code>Z−10</code> = 10 mm into the material. If you flip the sign (manual tweak or a confused macro), the next <code>Z+</code> order drives the cutter into the table. <strong>Edit this axis only with the machine in IDLE and after a Home All</strong>.",

  // t_080e0a9d: badge HOME de la pestaña Soft Limits (estado actual pintado
  // desde AppState.limits.allHomed por renderSoftLimitsBadge en
  // rotechos-config-modal.js).
  "cfg.softlimits.homeBadge.homed":
    "HOME: done · soft limits DO protect the axis",
  "cfg.softlimits.homeBadge.notHomed":
    "HOME: pending · soft limits do NOT protect until you Home All (G28)",
  "cfg.softlimits.homeBadge.unknown":
    "HOME: unknown (waiting for first poll)",

  // (2) SONDA Z/SAC — el campo X está deshabilitado y viene de los soft limits.
  //     Ver hallazgo A-10 del acta origen.
  "info.sac.sensorX":
    "<strong style=color:var(--blue)>Why is X greyed out and Y is not?</strong> The <strong>sensor X</strong> field is derived from the <strong>X Max limit</strong> in the <em>Travel limits</em> tab: the Z probe must be aligned with the edge of the area so it does not move off the table. You edit it ONCE in <em>Travel limits</em> and on reload this tab shows the result.<br><br><strong>Sensor Y</strong> you do define here: it is the <em>physical position of the probe</em> on your table (you can measure it with a tape from the table edge to the probe tip). Typically 5–30 mm before the usable edge.<br><br><strong>To change sensor X</strong>: open <em>Travel limits</em>, change X Max (or X Min if your machine is inverted), save and come back here. The X field will fill in automatically with the correct derived value.",

  // (3) EJE A — aclarar las 3 opciones operativas (Off/Slave/Rotary).
  //     Peligro: cambiar de Off a Slave/Rotary sin hardware provoca error.
  //     Ver hallazgo A-11 del acta origen.
  "info.motors.axisA":
    "<strong style=color:var(--blue)>What does each option do?</strong> This panel generates the <code>M584</code> line in <code>config.g</code> that says how many axes the machine has and which driver each is assigned to:<br><br><strong>Off</strong> (factory default): the line stays <code>M584 X… Y… Z…</code>, with no A axis. The machine stays X/Y/Z. <strong>No extra hardware needed</strong>.<br><br><strong style=color:var(--warn-strong)>First of all:</strong> this board (BTT Scylla V1.0) has <strong>four drivers, P0 to P3</strong>. There is no P4. X, Y and Z already take three, so the A axis can only use <strong>whichever one is left</strong>; if that one is marked as faulty in <code>config-machine.g</code>, there is no room for an A axis on this board.<br><br><strong>Y Slave (gantry)</strong>: the A motor moves synchronised with Y, as a second belt of the Y axis. Adds the A motor to your <code>M584</code> line as <code>Y{primary}:4</code>, where <code>{primary}</code> is the current Y driver in your <code>config.g</code> (the UI keeps the X, Y and Z mapping as-is). Used in Gantry machines with two horizontal motors. <strong>Requires a motor wired to whichever driver is left free</strong> and re-wiring of the Y2 motor.<br><br><strong>Rotary</strong>: the A motor becomes an <em>independent 4th axis</em> (rotary table, ATC, rotating spindle). Adds <code>A{free}</code> to your <code>M584</code> line, where <code>{free}</code> is the driver from P0 to P3 that X, Y and Z do not use (the UI keeps the X, Y and Z mapping as-is). The A steps/mm are interpreted as <strong>steps/degree</strong>. <strong>Requires a motor on the free driver and the rotary hardware mounted</strong>.<br><br><strong style=color:var(--warn-strong)>Danger:</strong> if your machine does NOT have that hardware and you save with <em>Y Slave</em> or <em>Rotary</em>, on next boot the firmware will look for a motor that is not there and the machine may end up in an error state. If you hit that, come back to this panel, set <em>Off</em>, save and reboot.",

  // (4) Cómo se aplica cada cambio — Guardar y listo vs Guardar+reinicio vs Auto.
  //     Ver hallazgos D-2 y D-4 del acta origen.
  "info.cfg.saveSemantics":
    "<strong style=color:var(--warn-strong)>How each change is applied (important).</strong> The tabs behave in <strong>three different ways</strong>, not one:<br><br><strong>1. Save and DONE</strong> (most): press <em>Save</em> and the change is applied on press. Tip: <em>Speeds</em>, <em>Backlash</em>, <em>Spindle</em>, <em>Z sensor</em>.<br><br><strong>2. Save + REBOOT the board</strong>: the change requires a full Scylla reboot (refreshing the page is not enough). If you don't reboot, the firmware keeps the previous value. Tip: <em>Motors</em> (M92, M906, M569, M584), <em>External drivers</em>, <em>Direction inversion</em>.<br><br><strong>3. AUTO save on-the-fly</strong>: the change is applied the moment you make it, without going through <em>Save</em>. Tip: <em>Soft limits</em> (M208), <em>Homing required</em>, <em>LED RGB</em>. Pressing <em>Save</em> afterward is harmless and only serves as confirmation.",

  // (5) HOMING — qué pasa con Buscar y Afinar, valores razonables.
  //     Ver hallazgo C-5 del acta origen.
  "info.homing":
    "<strong style=color:var(--blue)>Search (fast) and fine-tune (slow) values.</strong> Homing does <strong>two passes</strong> per axis: a first fast one to detect the endstop, and a second slow one to refine the exact point.<br><br><strong>Search</strong> (fast, typical 1000–3000 mm/min): must be fast enough so homing does not take forever, but slow enough that the firmware detects the sensor before the axis slams. Rule of thumb: 50–70 % of the <em>Max speed</em> in the <em>Speeds</em> tab.<br><br><strong>Fine-tune</strong> (slow, typical 100–300 mm/min): runs <strong>in the opposite direction</strong> to re-enter with precision and define the zero. <strong>Reasonable factory values:</strong> X/Y 200 mm/min · Z 100 mm/min (Z is slower because the Z inductive sensor is usually more sensitive).<br><br><strong>If after homing the axes end at a coordinate other than 0:</strong> it may indicate the slow pass was not firm enough to stop the axis before re-entry. Raise <em>Fine-tune</em> to 450–500 mm/min and repeat.",

  // (6) FINALES DE CARRERA — NC vs NO según tipo de sensor.
  //     Ver hallazgo C-4 del acta origen.
  "info.endstops.ncno":
    "<strong style=color:var(--purple)>NC or NO? Depends on the sensor type.</strong> The <em>Type</em> selector of each endstop tells the firmware how to read the sensor:<br><br><strong>NC — Normally Closed</strong>: the sensor keeps the line connected when NOT near the target. On detecting the endstop, the line OPENS. This is the factory setting (safer: if the cable breaks, the firmware thinks the sensor triggered and blocks homing).<br><br><strong>NO — Normally Open</strong>: the line is loose when NOT detecting, and closes when detecting. Useful for some PNP inductive sensors or older electromechanical endstops.<br><br><strong>How to know which one to use?</strong> Check the <em>manufacturer's datasheet</em> of the sensor. The <strong>NPN inductive sensors</strong> shipped with RotechOS Cnc are usually <strong>NC</strong>. If homing fails with &quot;trigger not found&quot; right after touching the endstop, try the opposite option.<br><br><strong>Important:</strong> endstops <strong>have NO universal polarity</strong>. If flipping NC↔NO makes the sensor's green LED change from on to off without touching anything, or flicker randomly, check the wiring before continuing.",

  // (7) SPEEDS — qué es el JERK en abstracto (aparece 4 veces en esta pestaña).
  //     Ver hallazgo A-14 del acta origen.
  "info.speeds.jerk":
    "<strong style=color:var(--blue)>What is JERK?</strong> It is the <strong>maximum rate of change of acceleration</strong> in mm/min (or deg/min for rotary axes). In other words: how abrupt the change of acceleration can be when the G-code transitions from straight to curved motion.<br><br><strong>Low jerk</strong> = acceleration changes slowly. The machine makes smooth transitions, no jerks. Good for delicate parts and slow curves.<br><strong>High jerk</strong> = acceleration can change abruptly. The machine makes more accurate arcs and keeps speed on trajectories with many curves. Good for production, but projects more vibration to the mechanics.<br><br><strong>How it goes wrong:</strong> if circles come out with visible &quot;corners&quot; between segments, raise jerk. If the machine buzzes or loses steps near curves, lower jerk. <strong>There is no universal value</strong>: start with the placeholders (SEDA 60, RAYO 120 mm/min) and adjust by ear + measurement.",

  // (8) LED RGB — pestañas de 5×4 + 14 filas abruma. Explicar de entrada que
  //     es solo un indicador visual, no afecta al mecanizado.
  //     Ver hallazgo A-17 del acta origen.
  "info.ledrgb":
    "<strong style=color:var(--blue)>What is this tab for?</strong> The RGB LED (WS2812b) on the board is a <em>status indicator</em>, <strong>it does not affect machining</strong>. It changes colour and animation depending on what the machine is doing:<br><br><strong>Colour</strong> = state (IDLE, READY, RUNNING, PAUSED, ERROR).<br><strong>Animation</strong> = moment (endstop triggered, homing in progress, macro running, probing…).<br><br><strong>Why is it in Settings?</strong> So you can <em>adjust brightness</em> and visually test the patterns. If you work in a dark environment and the LED distracts you, lower the general brightness. If you work under industrial light and cannot see it, raise it. Modes are tied to the machine state and <strong>cannot be edited</strong> (the firmware fixes them to keep visual coherence).<br><br><strong>What you CAN adjust:</strong> brightness (1–255) and on/off. <strong>What you CANNOT:</strong> change colour per state, or animation per event. It is an industrial design decision: an operator should never doubt what a colour means.<br><br><strong>Only care about machining?</strong> You can ignore this tab without affecting anything. Only configure it if the LED bothers you or you cannot see it.",

  // ── External drivers — T timing selector (t_cbd5e981, 2026-08-12) ──
  // Visible solo cuando el toggle "externo" del eje está ON. Determina qué
  // string T{...} emite el M569 al guardar el modal de Motores.
  "select.tmc2160":              "Onboard TMC2160 (no T parameter)",
  "select.leadshine-dm542":      "Leadshine DM542 (conservative T)",
  "select.leadshine-dm860":      "Leadshine DM860 (conservative T)",
  "select.extdrv-custom":        "Other external driver (manual T, µs)",
  "msg.extdrvCustomRange":       "Driver ${ax}: invalid T value (range 1.5–50 µs)",

  // ── Closed-loop external drivers (t_d62ddcd7, 2026-09-04) ──
  // Misma ruta de M569 D2 que DM542/DM860 (RRF 3.5.4 no tiene modo nativo
  // closed-loop — el encoder/ALARM los gestiona el driver internamente, RRF
  // sólo ve STEP/DIR). La diferencia es INFORMATIVA para el operario: este
  // driver tiene encoder y corrige posición por su cuenta. El firmware no
  // lee el encoder: si el driver pierde pasos y NO dispara ALARM, RRF NO se
  // entera. El dial hardware sigue rigiendo la corriente.
  "select.leadshine-cl57t":      "Leadshine CL57T — closed-loop (conservative T)",
  "select.closedloop-hbs57":     "HBS57 / generic CL57 — closed-loop (conservative T)",

  // ── ARIA-LABEL — Modal Configuración (mcfg*) — M-M02 a11y ─────────────────
  // H-CFG-11 auditoría UI 2026-08-14: 24 inputs sin programmatic name.
  // Añadidos aria-label + data-i18n-aria-label en index.html; aquí solo las
  // traducciones EN que el data-i18n-aria-label resuelve cuando I18N.locale='en'.
  "aria.cfg.endstops.typeXMin":  "X min endstop type (NC normally closed, NO normally open)",
  "aria.cfg.endstops.typeXMax":  "X max endstop type (NC normally closed, NO normally open)",
  "aria.cfg.endstops.typeYMin":  "Y min endstop type (NC normally closed, NO normally open)",
  "aria.cfg.endstops.typeYMax":  "Y max endstop type (NC normally closed, NO normally open)",
  "aria.cfg.endstops.typeZMin":  "Z min endstop type (NC normally closed, NO normally open)",
  "aria.cfg.endstops.typeZMax":  "Z max endstop type (NC normally closed, NO normally open)",
  "aria.cfg.pin.input":          "New HTTP interface PIN (M551)",
  "aria.cfg.pin.inputConfirm":   "Repeat HTTP PIN to confirm",
  "aria.cfg.about.machineName":  "This machine's identifying name (M550)",
  "aria.cfg.led.brightness":     "Overall NeoPixel LED strip brightness (1 min, 255 max)",
  "title.cfg.led.brightness":    "Overall NeoPixel LED strip brightness (1 min, 255 max)",
  "aria.cfg.ota.uploadDest":     "SD card destination for the uploaded file (auto by extension or fixed path)",

  // ── SR-ONLY HEADING (landmark main) — A11Y-7 cierre v2 2026-08-26 ─────────
  // WCAG 2.4.6 (Headings and Labels) + 2.4.1 (Bypass Blocks): un h1 de app
  // accesible a screen readers para que NVDA/JAWS/VoiceOver anuncen el
  // nombre del producto al pulsar 1 o M tras cargar la SPA. ES vive en el
  // HTML inline (index.html); EN aqui. NO traducir la palabra "RotechOS".
  "h1.appTitle":                  "RotechOS — CNC control interface",

  // ── SONDA/SAC §4.8 — avisos de seguridad (t_014cd150) ───────────────────
  // t.* (toasts de operación, errores, bloqueos). Estos son los mensajes que
  // muestran los guards nuevos de `btnQaSondaZ` y `btnQaM6` cuando la máquina
  // NO está en HOME. La política del gate i18n dice que cualquier msg.* sin
  // EN = agujero funcional (el operario ve el aviso en español bajo carga).
  // Por eso cada clave lleva su traducción al lado.
  "msg.sondaHomeRequerido":       "Home the machine (G28) before probing — without it the probe could slam the cutter into the table.",
  "msg.m6HomeRequerido":          "Home the machine (G28) before tool change (M6) — the SAC parking position is a G53 coordinate and needs a valid reference.",
  "msg.sondaRecorridoMax":        "Max travel to contact: ${mm} mm — derived from current Z (${zPos}) and Z min (${zMin}).",
  "msg.sondaRecorridoMaxNoData":  "Max travel to contact: not available until the firmware reports move.axes[2].min (poll running).",
  "msg.sondaBannerHomeRequired":  "HOME REQUIRED before probing — the buttons in this tab are blocked until G28 runs.",
  "msg.sondaBannerHomeOk":        "HOME OK — probing and tool change are enabled.",
  "msg.sondaBannerMaintTmp":      "Maintenance window: HOME requirement temporarily OFF. Probe buttons enabled; revert in Homing tab once maintenance finishes.",
  "label.sondaRecorridoMax":      "Max travel to contact (mm) — derived",
  "title.timeout-del-palpado":    "Maximum probe time (ms). If the probe does not trigger within this time, abort. 1000–30000 ms. Typical: 10000 (10 s).",
  "title.recorrido-max-hasta-c-c2d8": "Derived readout — NOT editable. Computed as |Z current − Z min| − sensor→table. Useful to know how far the probe will travel before touching the table. Refreshes on tab open and from the RRF poll.",
  "aria.cfg.sonda.bannerHome":    "Banner showing whether the machine is homed (probing/tool-change enabled) or needs homing first.",

  // ── Tools tab (t_33991c62) ─────────────────────────────────────────────────
  "school.tools":
    "<strong>Tools</strong> (M563) is the per-machine tool table: number, name, diameter, flutes, Z length offset and optional material. Persisted in <code>config-machine.g</code>, so an OTA rewriting <code>config.g</code> won't wipe it. Tool 0 (Spindle) is protected and always present — every code path that stops the spindle (T0+M5) assumes it exists.",

  "cfg.tools.title":            "Tools (M563)",
  "cfg.tools.tool0":            "Tool 0 (Spindle) — protected",
  "cfg.tools.countNone":        "No extra tools (Tool 0 / Spindle only)",
  "cfg.tools.col.num":          "#",
  "cfg.tools.col.name":         "Name",
  "cfg.tools.col.diam":         "Diameter (mm)",
  "cfg.tools.col.flutes":       "Flutes",
  "cfg.tools.col.z":            "Z offset (mm)",
  "cfg.tools.col.mat":          "Material",
  "cfg.tools.col.spindle":      "Spindle",
  "cfg.tools.col.actions":      "Actions",
  "cfg.tools.spindleYes":       "Yes",
  "cfg.tools.spindleNo":        "No",
  "cfg.tools.add":              "Add tool",
  "cfg.tools.namePh":           "End mill 6mm",
  "cfg.tools.matPh":            "Wood, aluminium…",
  "cfg.tools.save":             "Save",
  "cfg.tools.cancel":           "Cancel",
  "cfg.tools.edit":             "Edit",
  "cfg.tools.remove":           "Delete",
  "cfg.tools.zHint":            "Z: negative = longer tool (subtracts from calibration). Positive = shorter. Default 0.00 until the probe measures it.",

  "aria.cfg.tools.add":         "Add new tool",
  "aria.cfg.tools.pnum":        "Tool number (auto-assigned)",
  "aria.cfg.tools.name":        "Tool name",
  "aria.cfg.tools.diam":        "Diameter in millimetres",
  "aria.cfg.tools.flutes":      "Number of flutes",
  "aria.cfg.tools.z":           "Z length offset in millimetres (negative = longer)",
  "aria.cfg.tools.mat":         "Material this tool is intended for",
  "aria.cfg.tools.spindle":     "Associate with the spindle (R0 = no, R1 = yes)",

  "msg.toolsCountNone":         "No additional tools (only Tool 0 / Spindle)",
  "msg.toolsCountN":            "{n} additional tool(s) · Tool 0 (Spindle) protected",
  "msg.toolsInvalidP":          "Invalid tool number (1-99).",
  "msg.toolsInvalidName":       "Invalid name. Quotes, newlines and ';' are not allowed; the field cannot be empty.",
  "msg.toolsInvalidDiam":       "Diameter out of range (0-99 mm).",
  "msg.toolsInvalidFlutes":     "Flutes must be an integer 1-99.",
  "msg.toolsInvalidZ":          "Invalid Z offset.",
  "msg.toolsSaved":             "Tools saved to config-machine.g.",
  "msg.toolsSaveFailed":        "Could not save the tools table.",
  "msg.toolsRemoved":           "Tool {p} deleted.",
  "msg.toolsRemoveFailed":      "Could not delete the tool.",
  "msg.toolsRemoveTitle":       "Delete tool",
  "msg.toolsRemoveBody":        "You are about to delete tool P{p} (\"{name}\") from config-machine.g. Existing G-codes that select T{p} will fail until you define a new tool with that number or change the program.",
  "msg.toolsCannotDeleteP0":    "Tool 0 (Spindle) is protected and cannot be deleted.",
  "msg.guardarToolsUsarBoton":  "Tools: use the table-specific Add / Save / Delete buttons, not the generic Save.",
  // t_fdbab53f (sep-2026): Asistente de aplanado de la mesa de sacrificio.
  // El wizard genera el zigzag con el solape y la profundidad que el
  // operario indique, lo dibuja en el visor y SOLO ENTONCES lo ejecuta.
  // Carga perezosa (rotechos-facing-wizard.js) y HOME obligatorio.
  "cfg.tab.facing":              "FACING",
  "info.facing.tab":
    "<strong style=\"color:var(--blue)\">Sacrificial-table facing.</strong> The wizard generates a zigzag sweep with the tool diameter, overlap and pass depth you enter, draws it in the central viewer and only THEN runs it on the machine. <strong>HOME is mandatory</strong> before running.",
  "cfg.facing.title":            "Facing wizard",
  "cfg.facing.area":             "Area to flatten (mm)",
  "cfg.facing.min.hdr":          "Minimum",
  "cfg.facing.max.hdr":          "Maximum",
  "cfg.facing.margin":           "Margin from M208 (mm)",
  "cfg.facing.tool":             "Facing tool diameter (mm)",
  "cfg.facing.overlap":          "Overlap between passes (%)",
  "cfg.facing.depth":            "Pass depth (mm)",
  "cfg.facing.feed":             "Feed rate (mm/min)",
  "cfg.facing.rpm":              "Spindle RPM",
  "cfg.facing.btn.calc":         "Calculate and draw",
  "cfg.facing.btn.execute":      "Execute on the machine",
  "cfg.facing.hint":
    "Execution requires HOME and an active connection to the board. Calculate and review the viewer before running.",
  "school.facing":
    "<strong>Facing</strong> Wizard for flattening the sacrificial table. Enter your facing tool, the desired overlap and pass depth, plus the area (defaulted from M208 minus a margin). The wizard draws the zigzag in the viewer before running it. HOME is mandatory.",
  "aria.cfg.facing.xMin":        "Minimum X of the area to flatten",
  "aria.cfg.facing.xMax":        "Maximum X of the area to flatten",
  "aria.cfg.facing.yMin":        "Minimum Y of the area to flatten",
  "aria.cfg.facing.yMax":        "Maximum Y of the area to flatten",
  "aria.cfg.facing.margin":      "Margin inset from M208",
  "aria.cfg.facing.tool":        "Facing tool diameter",
  "aria.cfg.facing.overlap":     "Overlap between passes, in percent",
  "aria.cfg.facing.depth":       "Pass depth in mm",
  "aria.cfg.facing.feed":        "Feed rate in mm/min",
  "aria.cfg.facing.rpm":         "Spindle RPM (0 = do not turn on)",
  // t_f8b27b80 (2026-09-05) — textos EN del panel AVANZADO (i18n mínimo viable).
  // Los textos largos viven en el HTML inline (ES) y como info-box EN arriba
  // (info.motortimeout.tab, info.network.warn, info.inputshaping.tab); aquí
  // solo los labels de inputs y los mensajes dinámicos cortos.
  "cfg.motortimeout.title":      "Motor timeout — M84",
  "cfg.motortimeout.label":      "Seconds without movement before releasing the motors (86400 = 1 day, safe default)",
  "cfg.fans.title":              "Electronics fans — AUX1",
  "cfg.fans.label":              "Switch-on temperature (°C, 30 to 50; factory 45)",
  "cfg.network.title":           "Network protocols — M586",
  "cfg.network.ftp":             "FTP (P1)",
  "cfg.network.telnet":          "Telnet (P2)",
  "cfg.inputshaping.title":      "Input shaping — M593",
  "cfg.inputshaping.type":       "Shaper type (M593 P)",
  "cfg.inputshaping.freq":       "Frequency Hz (M593 F)",
  "aria.cfg.motortimeout.input": "Timeout in seconds before motors de-energise (M84 S)",
  "aria.cfg.network.ftp":        "Enable FTP (M586 P1)",
  "aria.cfg.network.telnet":     "Enable Telnet (M586 P2)",
  "aria.cfg.inputshaping.type":  "Shaper type (M593 P)",
  "aria.cfg.inputshaping.freq":  "Shaper frequency in Hz (M593 F)",

  // Mensajes dinámicos. Solo validación y advertencia (las barreras de
  // confirmación se han convertido en toasts para ahorrar bytes).
  "msg.motortimeoutInvalido":    "Invalid timeout — must be an integer >= 0 seconds",
  "msg.motortimeoutCorto":       "Timeout muy corto ({secs} s): si la fresa está cerca, Z puede caer.",
  "msg.fansTempInvalida":        "Invalid temperature — between 30 and 50 °C",
  "msg.networkAbierto":          "FTP/Telnet sin autenticación — solo con red segmentada",
  "msg.inputshapingFreqInvalida":"Invalid frequency — must be between 5 and 200 Hz",
  "msg.inputshapingTypeInvalido":"Invalid shaper type: {type}",
  // ── PROBE / Sonda — declaración M558 y offset G31 (t_9b49c0a4, sep-2026) ───
  // Antes la declaración y el offset vivían hardcoded en config.g — un cliente
  // con un sensor distinto del pulsador de Sergi tenía que editar texto. Ahora
  // son editables desde la pestaña SONDA Z, persisten en config-machine.g.
  // Las claves siguen el patrón "cfg.probe.*" / "label.*" / "title.*" / "msg.*"
  // que ya usa el resto del modal.
  "cfg.probe.decl.title":         "Probe declaration (M558) and offset (G31)",
  "cfg.probe.decl.desc":          "Sensor type, pin, pull-up/invert modifiers, dive height, probe speed, and XYZ offset of the probe relative to the spindle. Persists in <code>config-machine.g</code>.",
  "cfg.sonda.m558.summary":       "What the ^ and ! pin modifiers do — click to expand",
  "info.probe.m558":
    "<strong style=\"color:var(--blue)\">M558 pin modifiers (by what they do, not by their symbol).</strong><br><br>" +
    "<strong style=\"color:var(--green)\">^ (at the start) = activate the microcontroller's internal pull-up resistor.</strong> Use it when your sensor leaves the pin floating at rest (open contact = no signal). The pull-up forces the pin HIGH and contact closure pulls it LOW. It's redundant with the board's pull-up, but harmless.<br><br>" +
    "<strong style=\"color:var(--green)\">! (before the pin name) = invert the reading.</strong> Use it when your sensor triggers with the pin LOW — the typical case in this machine (contact closes to GND). Without the !, the firmware would interpret HIGH as triggered — and the probe would think it's in contact all the time.<br><br>" +
    "<strong>How to combine them</strong>: <code>^!E.7</code> = pull-up + invert (this machine). <code>!E.7</code> = invert without pull-up (sensor with external pull-up). <code>^E.7</code> = pull-up without invert (PNP sensor that triggers HIGH). <code>E.7</code> = no modifiers (sensor that already delivers correct logic).",
  "label.tipo-de-sonda-probe-2ddd":     "Probe type",
  "label.pin-pin-con-modifi-2d0c":      "Pin (with ^ and ! modifiers)",
  "label.dive-height-mm-h-32b6":        "Dive height (mm) — H",
  "label.velocidad-de-sondeo--9d8a":    "Probe speed (mm/min) — F",
  "label.timeout-de-sondeo-ms-9d8":     "Probe timeout (ms) — T",
  "label.valor-de-disparo-p-4bb":       "Trigger value — P",
  "label.offset-x-mm-08ed":             "X offset (mm)",
  "label.offset-y-mm-e6c5":             "Y offset (mm)",
  "label.offset-z-mm-critico":          "Z offset (mm) —",
  "option.probe-type-none":             "0 — no probe (disabled)",
  "option.probe-type-1":                "1 — unfiltered contact probe",
  "option.probe-type-2":                "2 — NPN inductive probe (requires filtering)",
  "option.probe-type-3":                "3 — improved-filter inductive probe",
  "option.probe-type-4":                "4 — modulated filtered inductive probe",
  "option.probe-type-5":                "5 — contact probe (E.7 in this machine)",
  "option.probe-type-6":                "6 — unfiltered probe with fixed threshold",
  "option.probe-type-7":                "7 — filtered probe with fixed threshold",
  "option.probe-type-8":                "8 — analog-voltage probe (continuous reading)",
  "option.probe-type-9":                "9 — resistive probe (typical in 3D printers)",
  "div.declaraci-n-m558-21b6":          "Probe declaration (M558)",
  "div.offset-de-la-sonda-g31-f3f9":    "Probe offset (G31) — sensor displacement relative to the spindle",
  "info.probe.zOffset":
    "<strong style=\"color:var(--warn-strong)\">An inverted sign in Z drives the cutter into the table.</strong> Leave 0 if the probe coincides with the tool tip, negative if the probe sits higher. Verify on the bench by jogging the spindle down by hand with the probe connected before saving.",
  "span.critico-91ad":                  "CRITICAL",
  "title.nombre-del-pin-con-mo-b3ea":   "Microcontroller pin where the probe is wired. Accepts the modifiers ^ (internal pull-up) and ! (invert reading). Examples: E.7, ^E.7, !E.7, ^!E.7.",
  "title.altura-de-aproximaci-6746":    "Distance (mm) the spindle moves DOWN from its current position to start searching for contact. Typical: 3–10 mm. Raise this if the probe is further away.",
  "title.velocidad-de-sondeo--d8a0":    "Speed of the first probe towards contact (mm/min). Conservative: a contact probe can bounce if you go down too fast.",
  "title.timeout-de-sondeo-ms-19d8":    "Maximum time (ms) the firmware waits for the probe to trigger before aborting. 1000–30000 ms. Typical: 6000 (6 s).",
  "title.valor-de-disparo-de-la-44bb":  "Numeric value the firmware compares with the probe reading to consider it 'triggered'. For a digital contact probe (P5) the actual value is 0/1 and this parameter is ignored. For analog probes (P8), thresholds of 100–1000 are typical.",
  "title.offset-x-del-palpador-08ed":   "X displacement of the probe relative to the spindle (mm). Positive if the sensor is to the RIGHT of the tool axis. 0 if coaxial.",
  "title.offset-y-del-palpador-e6c5":   "Y displacement of the probe relative to the spindle (mm). Positive if the sensor is BEHIND the tool axis. 0 if coaxial.",
  "title.offset-z-del-palpador-critico": "Z displacement of the probe relative to the spindle (mm). CRITICAL: an inverted sign drives the cutter into the table. Typical: 0 if the probe is at tool-tip height, negative if it sits higher.",
  "msg.probeDeclDomMissing":     "Probe fields missing from the UI",
  "msg.probeTipoInvalido":       "Invalid probe type (P): must be 0–9",
  "msg.probePinFormato":         "Invalid probe pin. Format: [modifiers]LETTER.NUMBER — e.g. ^!E.7, !D.11. No # or commas.",
  "msg.probeG31PInvalido":       "G31 P (trigger value) must be between 0 and 10000",
  "msg.probeG31XYZInvalido":     "G31 X/Y/Z must be numeric",
  "msg.probeG31ZFuera":          "Probe Z offset out of range (${z} mm). Z rarely exceeds ±10 mm: |Z|>50 mm is almost certainly an inverted sign, not a real calibration. DO NOT save without checking.",
  "msg.probePinConflicto":       "Pin ${pin} is already used by ${conflict}. Pick a different pin or disable that function in its tab.",
  // 3-oct (interfaz-acabado): cadenas que salian en castellano con la interfaz en ingles.
  "kb.reserved":                  "reserved",
  "kb.notRemappable":             "Not reassignable",
  "facing.summary.empty":         "— Adjust the values and press Calculate —",
  "facing.summary.passes":        "Passes",
  "facing.summary.step":          "row step",
  "facing.summary.depth":         "depth",
  "facing.summary.total":         "Total travel",
  "facing.summary.area":          "area",
  "cfg.readAge.now":              "now",
  "cfg.readAge.ago":              "${n} ago",
  "pins.type.outDigital":         "On/off output",
  "pins.type.outPwm":             "PWM output",
  "pins.type.inDigital":          "Digital input",
  "pins.nc.safe":                 "NC (fail-safe)",
  "park.stopSpindle":             "Turn the spindle off",
  "park.useMachine":              "Use machine coordinates",
  "p3d.spindleOff":               "Turn the spindle off before probing",
  "p3d.axisX":                    "X axis",
  "p3d.axisY":                    "Y axis",
  "p3d.axisZ":                    "Z axis",
  "p3d.center":                   "Center",
  "p3d.enable":                   "Enable",
  "mesh.emptyList":               "— empty —",
  "mesh.canvasEmpty":             "No map yet. Set the area and points, then press PROBE.",
  "mesh.canvasProbing":           "Probing…",
});
