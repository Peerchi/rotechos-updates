// Asistente de banco: registro del operario, sin ejecutar órdenes de máquina.
// Catálogo transcrito de docs/banco/GUION_BANCO_2026-11.md; IDs estables.
(function (root) {
  'use strict';
  const PROTOCOL = 'GUION_BANCO_2026-11';
  const SD_PATH = '0:/sys/rotechos-banco-resultados.json';
  const TESTS = [
    {"id": "S01", "block": "1. Antes de encender motores: seta, retención de Z y PARO", "action": "Sin fresa, sostener mecánicamente Z y comprobar qué alimentación y señal corta la seta en VFD y en Makita, según el montaje.", "expected": "Registrar por separado potencia VFD, señal RUN, potencia Makita y alimentación de motores; no atribuir a M5 el paro de la Makita.", "evidence": "Tensiones, cableado y tiempo de parada: ", "sources": "Plan §5, H3.2", "checklist": []},
    {"id": "S02", "block": "1. Antes de encender motores: seta, retención de Z y PARO", "action": "Con Z sujeto y sin herramienta, quitar corriente de motores de forma controlada.", "expected": "Determinar si Z cae y cuántos mm; no retirar el soporte sin una solución si cae.", "evidence": "Caída mm y retención: ", "sources": "Plan §5", "checklist": []},
    {"id": "S03", "block": "1. Antes de encender motores: seta, retención de Z y PARO", "action": "Con motores inmóviles y husillo sin fresa, verificar PARO de pantalla en FFF, ESC una vez durante trabajo en aire y PARO externo.", "expected": "Husillo VFD para; no se añade subida Z tras M112; interfaz muestra PARADA DE EMERGENCIA; el paro externo actúa sin M410. Makita: registrar corte físico real.", "evidence": "Latencia ms, RPM y movimiento Z: ", "sources": "C165, §0 C4 / FFF", "checklist": [165]},
    {"id": "S04", "block": "1. Antes de encender motores: seta, retención de Z y PARO", "action": "Tras PARO, intentar ENCENDER HUSILLO en escritorio y móvil; probar APAGAR y solo después RESET/REARMAR.", "expected": "ENCENDER no actúa; APAGAR sí; el rearme es explícito.", "evidence": "Comandos / estado: ", "sources": "C163, acta", "checklist": [163]},
    {"id": "B01", "block": "2. Copia completa de SD y foto de arranque", "action": "Apagar de forma segura; copiar TODA la SD a otro soporte y verificar que puede leerse antes de instalar o alterar pruebas.", "expected": "Copia fechada disponible, incluidos config-machine.g y config-override.g; custodiar credenciales, sin pegarlas al acta.", "evidence": "Ruta privada y hashes de copia: ", "sources": "Plan §5, acta", "checklist": []},
    {"id": "B02", "block": "2. Copia completa de SD y foto de arranque", "action": "Reiniciar y ejecutar diagnostico.g; registrar M115, M122 e identidad de soporte.", "expected": "Firmware/SD coinciden con lo desplegado; integrityOk existe y es true con configuración válida; guardar MCU ID si lo expone la placa, sin inventarlo.", "evidence": "Versión, build, Vin, MCU, ID: ", "sources": "C123, §3.1", "checklist": [123]},
    {"id": "B03", "block": "2. Copia completa de SD y foto de arranque", "action": "En una copia de SD de banco, arrancar sin config-machine.g y luego con una línea deliberadamente rota; recuperar desde copia.", "expected": "INICIAR se niega; diagnóstico conserva el error; no ejecutar un reset de fábrica que borre calibración. Restaurar y comprobar arranque.", "evidence": "Error literal, integrityOk: ", "sources": "§Banco, B6, C260", "checklist": [260]},
    {"id": "B04", "block": "2. Copia completa de SD y foto de arranque", "action": "Con soporte térmico seguro, observar un arranque con MCU ya caliente; no forzar sobretemperatura.", "expected": "La temperatura avisa sin impedir por sí sola mecanizar; registrar también límites reales de refrigeración.", "evidence": "Temperatura y aviso: ", "sources": "§Banco", "checklist": []},
    {"id": "H01", "block": "3. Endstops, HOME por eje y completo", "action": "Con la SD de banco sin set global.shieldMask, instalar/reiniciar e intentar INICIAR un trabajo vacío. Guardar solo los sensores instalados en CONFIGURACIÓN > Endstops y reiniciar.", "expected": "Antes: shieldMask=-1, SIN GUARDAR y trabajo rechazado. Después: máscara guardada, sin inventar sensores ausentes; INICIAR permitido solo si las demás guardas pasan.", "evidence": "Máscara antes/después y mensaje: ", "sources": "§PENDIENTE BANCO, §3", "checklist": []},
    {"id": "H02", "block": "3. Endstops, HOME por eje y completo", "action": "Accionar cada sensor con metal, comparar gpIn 0–5 y endstops en diagnostico.g; consultar M581 T2.", "expected": "Cada lado instalado cambia y T2 lista solo esos lados; registrar shieldNoMask y polaridad, incluidos MIN/MAX configurados.", "evidence": "Tabla sensor/pin/valor reposo-activo: ", "sources": "§3, H1 / M581", "checklist": []},
    {"id": "H03", "block": "3. Endstops, HOME por eje y completo", "action": "G28 Z, luego G28 X, G28 Y y finalmente G28; repetir los lados MIN/MAX que estén instalados. Partir también en G91 y con Z baja segura.", "expected": "Z sube a buscar; X/Y exigen Z referenciada y elevan antes del XY; homing completo Z→X→Y, dos toques y sin golpe. Confirmar orden/sentido que muestra la UI.", "evidence": "Posiciones, orden, recorrido y avance: ", "sources": "C171, C172, Protocolo 3.1, §prueba por eje", "checklist": [171, 172]},
    {"id": "H04", "block": "3. Endstops, HOME por eje y completo", "action": "En cada eje por separado y en HOME completo, probar sensor desconectado, pegado, inicialmente activo y sin segundo contacto; preparar antes el recorrido libre y la seta.", "expected": "Desconectado, pegado o sin segundo contacto: falla sin éxito falso ni eje referenciado. Inicialmente activo: libera y solo termina si hay dos detecciones válidas. Escudo restaurado y corriente repuesta.", "evidence": "Mensaje, homed, percentCurrent y contactos: ", "sources": "§PENDIENTE BANCO, §3, H1.1", "checklist": []},
    {"id": "H05", "block": "3. Endstops, HOME por eje y completo", "action": "Durante el segundo toque de Z, medir retención y posición al reaplicar M350; leer microstepping/interpolación y pasos/mm antes/después.", "expected": "Z no cae ni se suelta; las lecturas de calibración no cambian; la referencia solo llega con segundo contacto válido.", "evidence": "Caída mm, corriente, microsteps, M92: ", "sources": "§PENDIENTE BANCO", "checklist": []},
    {"id": "H06", "block": "3. Endstops, HOME por eje y completo", "action": "Sin fresa, husillo VFD girando a 6000, pedir G28 X; parar con M5 y comprobar stopped. Con sonda E.7 pulsada pedir G28 Y.", "expected": "Ambos HOME abortan por guardas sin movimiento; el aborto de HOME no sustituye el M5.", "evidence": "Mensajes y posición: ", "sources": "C173, C174, Protocolo 3.1", "checklist": [173, 174]},
    {"id": "H07", "block": "3. Endstops, HOME por eje y completo", "action": "Durante HOME, disparar un final de otro eje, también en retroceso lento y después del primer contacto. Después repetir HOME normal.", "expected": "Se detiene la secuencia, no busca otro eje; aviso y LED de seguridad, escudo armado. Registrar si conserva la referencia del primer contacto (limitación documentada); no queda petición vieja.", "evidence": "Latencia, mm, homed y T2: ", "sources": "§Banco, §PENDIENTE BANCO", "checklist": []},
    {"id": "H08", "block": "3. Endstops, HOME por eje y completo", "action": "Con un final habilitado forzado, intentar INICIAR, park, goto0 y Sonda Z. Retirar el obstáculo con jog seguro y repetir; comprobar un lado sin sensor desactivado.", "expected": "Se niegan al inicio con aviso; funcionan tras despejar. Un lado ausente desactivado no bloquea por pin flotante. HOME puede liberar su sensor según H04.", "evidence": "Avisos y máscara: ", "sources": "§3, §Banco", "checklist": []},
    {"id": "H09", "block": "3. Endstops, HOME por eje y completo", "action": "Apagar, desplazar X manualmente con alimentación desconectada y volver a arrancar.", "expected": "Ningún eje queda homeado por una posición vieja; se conserva cero de pieza, pero INICIAR exige HOME.", "evidence": "homed y offsets antes/después: ", "sources": "C5, H4.2", "checklist": []},
    {"id": "F01", "block": "4. Escudo durante trabajo en vacío y malla", "action": "Con recorrido libre y trabajo de SD en aire, accionar por separado cada final habilitado.", "expected": "Husillo VFD para y trabajo pausa; medir el movimiento que sigue por cola/macro. Sergi decide con esos datos si la parada T2 es aceptable.", "evidence": "Distancia mm, latencia ms y estado: ", "sources": "H5.1, §Banco", "checklist": []},
    {"id": "F02", "block": "4. Escudo durante trabajo en vacío y malla", "action": "Lanzar spindle_warmup.g sin fresa y accionar un final.", "expected": "El husillo para y no vuelve a arrancar en otra fase del calentamiento.", "evidence": "Tiempo y RPM: ", "sources": "§Banco", "checklist": []},
    {"id": "F03", "block": "4. Escudo durante trabajo en vacío y malla", "action": "En una malla en aire, disparar T2 durante palpado, retirada y viaje, en puntos 1, 4, 8 y después del 9; repetir cancelando desde UI.", "expected": "No pasa al siguiente punto, no valida ni guarda malla incompleta, restaura escudo y retira Z según limpieza. La UI confirma cancelado solo tras respuesta.", "evidence": "Último punto, Z, mm/ms y T2: ", "sources": "§PENDIENTE BANCO, A3, B4", "checklist": []},
    {"id": "F04", "block": "4. Escudo durante trabajo en vacío y malla", "action": "Probar PARO sin red durante trabajo en aire; usar la seta y restaurar red.", "expected": "La UI avisa que M112 no fue entregado y pide seta; al reconectar no reanuda sola y refleja el estado físico.", "evidence": "Aviso, latencia y reenvío: ", "sources": "C4, acta", "checklist": []},
    {"id": "K01", "block": "5. Dinámica, calibración, sonda, daemon y refrigeración", "action": "Ejecutar START→PAUSE→RESUME→STOP/CANCEL en aire, tres ciclos; comparar modo, LED y posición.", "expected": "START/RESUME a RAYO, PAUSE/STOP a SEDA con Z/husillo controlados y LED coherente; sin clac/zumbido; sin drift medible.", "evidence": "Duración rampa, ruido y drift mm: ", "sources": "C180, C182, C183, C184, C185, Protocolo 3.2, B-07 M150", "checklist": [180, 182, 183, 184, 185]},
    {"id": "K02", "block": "5. Dinámica, calibración, sonda, daemon y refrigeración", "action": "Comprobar M425 S10 leyendo la configuración activa tras guardar backlash y reiniciar.", "expected": "Compensación aplicada al eje previsto; no se deduce de la casilla de la UI.", "evidence": "Respuesta M425 / configuración: ", "sources": "Plan §5", "checklist": []},
    {"id": "K03", "block": "5. Dinámica, calibración, sonda, daemon y refrigeración", "action": "Jog X/Y 200 mm en Lenta, Normal y Rápida; medir un desplazamiento de 100 mm con regla y registrar Vin.", "expected": "Un toque da un solo desplazamiento, sin atasco. Comparar avances con configuración activa (referencia actual 2250 mm/min); no subir techos sin margen medido.", "evidence": "mm reales, mm/min, Vin: ", "sources": "C175, C177, acta", "checklist": [175, 177]},
    {"id": "K04", "block": "5. Dinámica, calibración, sonda, daemon y refrigeración", "action": "Comprobar jog por paso y continuo en escritorio, Pendant y asistente, con/sin HOME y cerca de cada límite habilitado; soltar el mando.", "expected": "Sin HOME las acciones protegidas se niegan; un toque no se duplica; límites frenan dentro del recorrido y soltar detiene. No probar desactivando límites junto al bastidor.", "evidence": "mm/paso, sobrepaso y latencia al soltar: ", "sources": "clamp, §límites, B-01", "checklist": []},
    {"id": "K05", "block": "5. Dinámica, calibración, sonda, daemon y refrigeración", "action": "Medir/calibrar Z, G31, touchplate_thickness, z_sensor_to_table y tool_sensor_y reales; guardar Sonda y reiniciar.", "expected": "Valores medidos en config-machine.g y efectivos al usar SAC/M6; no se usa un valor provisional para pasar integridad. Validar el rango físico de sensor Z de esta máquina.", "evidence": "Medidas mm y lectura tras reboot: ", "sources": "§1.1–1.2, BANCO-01/05", "checklist": []},
    {"id": "K06", "block": "5. Dinámica, calibración, sonda, daemon y refrigeración", "action": "En aire, preparar una búsqueda corta sin contacto con la sonda; repetir sonda desconectada, activa y normal.", "expected": "G38.2 sin contacto da error, sin inventar cero ni seguir con éxito; se restauran WCS/escudo/cinemática. Sonda normal hace rápida y fina con límite M558 real.", "evidence": "result, mm, F, offset y T2: ", "sources": "H2.1–H2.3, acta", "checklist": []},
    {"id": "K07", "block": "5. Dinámica, calibración, sonda, daemon y refrigeración", "action": "Guardar velocidad SONDA Z, ejecutar palpado y consultar M558/probeSpeedCap; repetir en SEDA y leer M201/M566 al terminar.", "expected": "Velocidad efectiva coincide sin reboot; aceleraciones/jerk vuelven al modo anterior y no queda dinámica de palpado.", "evidence": "F, M201, M566: ", "sources": "B13, H2.2", "checklist": []},
    {"id": "K08", "block": "5. Dinámica, calibración, sonda, daemon y refrigeración", "action": "Sonda Z y M6 de calibración en G55; contrastar G54 antes/después. Probar palpado XY/3D y malla 3×3 en aire, accionando el pulsador manualmente.", "expected": "Cero solo en WCS activo; XY busca desde la posición actual y 3D termina Z/X/Y. Malla usa altura segura efectiva y válida, nunca sobre el tope Z. Comparar macro de SD con editor sin sobrescribirla.", "evidence": "WCS, coordenadas, altura y puntos: ", "sources": "B7, N-MS1, BANCO-02", "checklist": []},
    {"id": "K09", "block": "5. Dinámica, calibración, sonda, daemon y refrigeración", "action": "Aplicar microajuste Z en pausa, leer M290; acabar el trabajo e iniciar el siguiente vacío.", "expected": "Cada paso cambia lo pedido; start.g limpia el ajuste anterior y desaparece µZ.", "evidence": "Valor de M290 antes/después: ", "sources": "§Banco", "checklist": []},
    {"id": "K10", "block": "5. Dinámica, calibración, sonda, daemon y refrigeración", "action": "Consultar echo ledStrips[0].stopMovement y observar un trabajo largo junto al LED y daemon; medir intervalos por telemetría sin editar daemon_tick.g.", "expected": "Si stopMovement=true, registrar tirones coincidentes; daemon cercano a 1 s en reposo, no asumirlo del simulador. Sin errores de línea larga.", "evidence": "stopMovement, intervalos y tirones: ", "sources": "§3, §Banco", "checklist": []},
    {"id": "K11", "block": "5. Dinámica, calibración, sonda, daemon y refrigeración", "action": "Tras reiniciar, ejecutar diagnostico.g y ventiladores_prueba.g; después probar umbral 30 °C y restaurar 45 °C en configuración.", "expected": "AUX1 existe, prueba gira 15 s y LED se enciende; con MCU por encima del umbral arranca y por debajo de 42 °C para con ajuste 45. Si LED sí/ventilador no, medir V-MOS.", "evidence": "Temp, tensión, tiempo y estado AUX1: ", "sources": "C191, C192, C193", "checklist": [191, 192, 193]},
    {"id": "K12", "block": "5. Dinámica, calibración, sonda, daemon y refrigeración", "action": "Probar preview LED y primer/último LED; mirar color a 3 m durante transiciones.", "expected": "Tira responde completa, color distinguible y sin cola de M150 que retrase control.", "evidence": "Nº LEDs, color y latencia: ", "sources": "§Banco, B-07", "checklist": []},
    {"id": "K13", "block": "5. Dinámica, calibración, sonda, daemon y refrigeración", "action": "En montaje que lleve A rotativo, activar, guardar, reiniciar y reabrir Motores; leer config.g sin ejecutar M569.", "expected": "Solo driver libre P0–P3, jamás P4; dirección guardada, fila A visible y toggles restaurados. Si A no está montado, dejar sin ejecutar y justificar.", "evidence": "Driver, fila y valores: ", "sources": "§segunda ronda, BANCO-02", "checklist": []},
    {"id": "K14", "block": "5. Dinámica, calibración, sonda, daemon y refrigeración", "action": "Cambiar un ajuste inocuo de soft limits/LED, guardar y reiniciar; repetir con pérdida de red al guardar, preservando copia.", "expected": "Persistencia coincide con lo confirmado, un fallo se muestra y no vacía config-machine.g; no aparecen pendientes falsos en otras pestañas. Comparar curva visual de velocidad con unidades reales.", "evidence": "Lectura SD, mensaje y unidades: ", "sources": "ROT-BANCO-01/02, BANCO-01/03/04, BANCO-06", "checklist": []},
    {"id": "R01", "block": "6. Red AP, cliente, Ethernet y carga en placa real", "action": "Con copia custodiada de credenciales, arrancar sin wifi-passwords.g; repetir con fichero válido.", "expected": "Arranque sin error en ambos casos; sin credenciales aparece AP RotechOS tras timeout de arranque (~35 s si netApOnly=false).", "evidence": "Tiempo y log de boot: ", "sources": "C122, C133, C134, Protocolo 1.1", "checklist": [122, 133, 134]},
    {"id": "R02", "block": "6. Red AP, cliente, Ethernet y carga en placa real", "action": "Desde AP guardar SSID/clave correctos y reiniciar; repetir con clave incorrecta y probar Conectar a esta red sin reboot.", "expected": "Se asocia con clave válida; clave mala recupera AP según flujo (boot ~35 s, conexión desde UI ~2 min). Confirmar 2.4 GHz y no perder acceso de forma permanente.", "evidence": "SSID sin clave, IP y tiempos: ", "sources": "C124, C125, C128, Protocolo 1.2–1.3, §3", "checklist": [124, 125, 128]},
    {"id": "R03", "block": "6. Red AP, cliente, Ethernet y carga en placa real", "action": "Cambiar la contraseña AP de fábrica y reconectar con la nueva, sin anotarla en el acta.", "expected": "La anterior ya no autentica; nueva funciona tras reinicio y no se entrega una credencial de fábrica.", "evidence": "Resultado de ambas conexiones: ", "sources": "C127", "checklist": [127]},
    {"id": "R04", "block": "6. Red AP, cliente, Ethernet y carga en placa real", "action": "Activar Trabajar siempre con la red propia y reiniciar; después probar el aviso Seguir con esta red.", "expected": "AP inmediato, netApOnly persiste y el aviso desaparece; siguiente arranque no espera el timeout cliente.", "evidence": "Tiempo, flag y aviso: ", "sources": "C129, C130", "checklist": [129, 130]},
    {"id": "R05", "block": "6. Red AP, cliente, Ethernet y carga en placa real", "action": "Trabajo de SD en aire: cortar router 5 s y restaurar; luego perder conexión >40 s, también antes del primer latido; comprobar heartbeat configurado.", "expected": "Corte corto no levanta AP ni pausa falsa; pérdida prolongada pausa según watchdog activo, sube Z y para VFD. Medir umbral real, sin convertir cifras históricas 30/40 s en garantía.", "evidence": "Latidos, ms, Z, RPM y AP: ", "sources": "C126, Protocolo 2.1, vigilante", "checklist": [126]},
    {"id": "R06", "block": "6. Red AP, cliente, Ethernet y carga en placa real", "action": "ESC en reposo, esperar 1 min; apagar WiFi del dispositivo 10 s, restaurar y pulsar RESET/REARMAR.", "expected": "Conexión sigue/recupera verde, estado sigue PARO hasta rearme explícito; sin UI zombi ni cambio a IDLE ficticio.", "evidence": "Tiempo de reconexión y estados: ", "sources": "C141, §Banco, §Banco", "checklist": [141]},
    {"id": "R07", "block": "6. Red AP, cliente, Ethernet y carga en placa real", "action": "Abrir UI de SD en escritorio, móvil y dos pestañas; revisar consola, STORE, IDLE y CONFIGURACIÓN. Tapar temporalmente rr_model en el navegador y restaurarlo.", "expected": "Sin ReferenceError/TypeError, pestañas configurables y sin corrupción; polling vuelve tras error y no quedan controles con estado viejo.", "evidence": "Errores, claves y frecuencia: ", "sources": "C137, C138, C139, C140, C142, Protocolo 1.3, D2-01/02", "checklist": [137, 138, 139, 140, 142]},
    {"id": "R08", "block": "6. Red AP, cliente, Ethernet y carga en placa real", "action": "En reposo, trabajo en aire y dos pestañas medir rr_model, bytes y latencias; minimizar navegador 7 min y bloquear pantalla móvil según política actual.", "expected": "Registrar carga real de ESP32; desktop minimizado no provoca pausa falsa mientras llegan latidos, móvil sin latidos pausa según política. No elevar presupuesto sin medición.", "evidence": "req/s, B/s, p95 y lastWatchdogPause: ", "sources": "Plan §4 3.1, §3", "checklist": []},
    {"id": "R09", "block": "6. Red AP, cliente, Ethernet y carga en placa real", "action": "Inspeccionar Network desde SD: JS/CSS/HTML/manifest/iconos/sw.js y gzip, sin SW para la primera carga; repetir con SD 8/32 GB disponibles.", "expected": "MIME correcto, Content-Encoding coherente, caché de SW actualizable y CORS rr_* registrado. No suponer tiempos del modelo como medidos.", "evidence": "Cabeceras, tamaño y TTFB: ", "sources": "H-7-02 §3", "checklist": []},
    {"id": "R10", "block": "6. Red AP, cliente, Ethernet y carga en placa real", "action": "Con copia y adaptador compatible, configurar wifi.moduleType=esp32eth y grabar M997 S1 según guía; leer M122.", "expected": "Firmware Ethernet arranca; sin cambiar board.txt de otra máquina.", "evidence": "Versiones módulo/placa: ", "sources": "C200, Ethernet", "checklist": [200]},
    {"id": "R11", "block": "6. Red AP, cliente, Ethernet y carga en placa real", "action": "Ethernet conectado a router DHCP; esperar enlace y abrir rotechcnc.local.", "expected": "IP antes de 60 s, sys/net-ethernet.g y ssid=ethernet; persiste tras reinicio con cable.", "evidence": "IP, tiempo y perfil: ", "sources": "C201, C207", "checklist": [201, 207]},
    {"id": "R12", "block": "6. Red AP, cliente, Ethernet y carga en placa real", "action": "Directo al PC: CNC 192.168.50.1/24 y PC 192.168.50.2/24, sin gateway/DNS; reiniciar.", "expected": "UI accesible y perfil persistente.", "evidence": "IP y resultado tras reboot: ", "sources": "C202", "checklist": [202]},
    {"id": "R13", "block": "6. Red AP, cliente, Ethernet y carga en placa real", "action": "PC por cable y Pendant móvil mediante router/AP en la misma LAN.", "expected": "Ambos controlan sin corrupción, NetFlex no levanta AP propio al tener Ethernet.", "evidence": "IPs, sesiones y AP: ", "sources": "C203", "checklist": [203]},
    {"id": "R14", "block": "6. Red AP, cliente, Ethernet y carga en placa real", "action": "Probar Ethernet sin cable y luego arrancar con perfil Ethernet guardado sin cable.", "expected": "Intento nuevo vuelve a WiFi/AP a los 60 s sin crear perfil falso; con perfil guardado recupera AP y acceso móvil.", "evidence": "Tiempo, fichero y acceso móvil: ", "sources": "C204, C205, C207", "checklist": [204, 205, 207]},
    {"id": "R15", "block": "6. Red AP, cliente, Ethernet y carga en placa real", "action": "Soltar cable en caliente, reenchufar y volver a conectar.", "expected": "Registrar ausencia de fallback inmediato (limitación del módulo); al reenchufar responde sin reboot.", "evidence": "Tiempo de recuperación: ", "sources": "C206", "checklist": [206]},
    {"id": "R16", "block": "6. Red AP, cliente, Ethernet y carga en placa real", "action": "Activar PIN desde UI y reiniciar; probar PIN incorrecto, dos pestañas y operaciones protegidas. Revisar Network de rr_connect.", "expected": "PIN persiste, acceso incorrecto rechazado; sesión y mensajes coherentes entre pestañas; SW no cachea rr_* ni permite acceso con credencial vieja.", "evidence": "HTTP/body sin secretos y tiempos: ", "sources": "§6, S-V7-1", "checklist": []},
    {"id": "O01", "block": "7. OTA: firma, reinstalación, fusión y recuperación", "action": "Desde una UI de confianza instalar ZIP firmado válido local y mediante manifest remoto; probar copias manipuladas, ausentes y clave desconocida.", "expected": "Firma inválida siempre rechazada antes de escribir; sin firma solo en transición y con aviso actualización sin firmar; con clave real fijada, rechazo obligatorio.", "evidence": "Firma/política, mensaje y escrituras: ", "sources": "Firma OTA, plan §3", "checklist": []},
    {"id": "O02", "block": "7. OTA: firma, reinstalación, fusión y recuperación", "action": "Instalar el mismo paquete dos veces y comparar config-machine.g, config-override.g, config.g, sentido, mapeo y endstops tras cada instalación.", "expected": "Per-máquina idénticos byte a byte; fusión config.g idéntica tras primera/segunda; config.g.antes-ota verificable. No ejecutar M569 en runtime.", "evidence": "Hashes antes/1ª/2ª y copia: ", "sources": "§Banco, plan 2.3", "checklist": []},
    {"id": "O03", "block": "7. OTA: firma, reinstalación, fusión y recuperación", "action": "Con SD duplicada y copia externa completa, cortar una subida OTA a mitad y reiniciar solo esa SD de banco.", "expected": "Marca sys/rotechos-ota-in-progress persiste, integrityOk=false, aviso OTA INTERRUMPIDA propone restaurar SD e INICIAR se bloquea. La primera migración desde un integrity_check antiguo exige comprobar que ya recibió este detector.", "evidence": "Fichero cortado, marca y mensaje: ", "sources": "§3, plan 2.2", "checklist": []},
    {"id": "O04", "block": "7. OTA: firma, reinstalación, fusión y recuperación", "action": "Restaurar la copia completa fuera de la OTA interrumpida; verificar contenido y arranque. Probar también restore normal desde backup en la SD duplicada.", "expected": "La recuperación deja calibración y macros utilizables; no borrar la marca a ciegas ni repetir OTA sobre transacción pendiente. Retirarla solo después de recuperar/verificar. No hay rollback automático de toda la SD.", "evidence": "Hashes, log y arranque: ", "sources": "H-8-01, rollback", "checklist": []},
    {"id": "O05", "block": "7. OTA: firma, reinstalación, fusión y recuperación", "action": "Tras OTA completa y reboot, recargar ambos clientes desde la SD y comprobar VERSION, script y SW efectivamente servidos.", "expected": "Código de versión nueva, marca eliminada y reinicio confirmado; sin caché antigua ni doble instalación accidental. Bump de sw.js pendiente del hilo dueño antes del despliegue.", "evidence": "VERSION, CACHE_NAME, URL/hash: ", "sources": "C143, §3", "checklist": [143]},
    {"id": "O06", "block": "7. OTA: firma, reinstalación, fusión y recuperación", "action": "Examinar contenido del backup en privado antes de compartirlo.", "expected": "Credenciales WiFi/AP no se publican ni se pegan al acta; si la copia completa las contiene se custodia como secreto.", "evidence": "Lista de exclusiones sin valores: ", "sources": "H-8-02", "checklist": []},
    {"id": "V01", "block": "8. Subtensión y M911 con trabajo de SD", "action": "Leer psu_voltage y umbrales activos; medir Vin en arranque de husillo y rápidos. No ejecutar la antigua receta M911 P como simulación.", "expected": "Protección configurada para tensión real; psu_voltage=0 significa vigilancia desactivada. Evaluar vinLowCycles con caídas medidas, no umbrales históricos de 48 V.", "evidence": "Vin mínimo, flags, ciclos y umbrales: ", "sources": "C159, V13-A/B", "checklist": [159]},
    {"id": "V02", "block": "8. Subtensión y M911 con trabajo de SD", "action": "Con fuente regulable y sin fresa, comprobar banda sana 24 V y arranque con 48 V degradada; no falsear valores en software.", "expected": "24 V sana arranca; sistema configurado 48 V por debajo de umbral activo bloquea integridad. Registrar build si Vin no existe.", "evidence": "Vin medida y veredicto: ", "sources": "C161", "checklist": [161]},
    {"id": "V03", "block": "8. Subtensión y M911 con trabajo de SD", "action": "Durante trabajo SD en aire, bajar tensión de forma controlada sobre umbral de aviso y luego de error del daemon.", "expected": "Aviso primero; persistencia bajo error pausa con M25, Z arriba y VFD parado en tiempo acorde al ciclo real (~2 s si configurado así), sin pausas falsas.", "evidence": "V, duración y respuesta: ", "sources": "C160, §3", "checklist": [160]},
    {"id": "V04", "block": "8. Subtensión y M911 con trabajo de SD", "action": "Con M911 activo y condensadores/montaje revisados, cortar alimentación en trabajo de SD en aire; después restituirla. Makita apagada físicamente.", "expected": "VFD para y Z sube según acción configurada (referencia actual 5 mm); no cae sobre mesa; al volver, arranque limpio y jamás reanudación automática. M911 no protege jog ni macros manuales.", "evidence": "Vin, subida mm, tiempo y arranque: ", "sources": "C153, C155, Protocolo 2.2", "checklist": [153, 155]},
    {"id": "V05", "block": "8. Subtensión y M911 con trabajo de SD", "action": "Con fuente regulable, provocar subtensión que no apague placa; inspeccionar percentCurrent. Sin potencia de husillo, probar reanudación UI y consola tras M913 X50 en pausa.", "expected": "Con corriente/referencia insuficiente no reanuda ni baja Z; guard hace PARO. HOME posterior restaura posición/corriente. Reponer estado antes de seguir.", "evidence": "Corrientes, homed, XY y mensaje: ", "sources": "B2, §3", "checklist": []},
    {"id": "V06", "block": "8. Subtensión y M911 con trabajo de SD", "action": "Tras recuperar tensión, enviar M916 en vacío.", "expected": "Aborta sin movimiento; no existe reanudación PLR.", "evidence": "Respuesta y posición: ", "sources": "C156, Protocolo 2.2", "checklist": [156]},
    {"id": "T01", "block": "9. M6 real, aspiración y aplanado en aire", "action": "Con SAC calibrado y sin pieza, M6 completo; observar rampa antes de XY, PARK, IR A 0 y coreografía. Partir también con Z en HOME.", "expected": "No baja Z antes de viajar XY; movimientos sin atasco a travel_feed/aceleración activos; rampa de M6 termina antes del XY. Comparar editor de park con macro real sin reemplazarla.", "evidence": "Z, XY, mm/min y rampa ms: ", "sources": "C176, C181, Protocolo 3.3, N-Z1, BANCO-03/04", "checklist": [176, 181]},
    {"id": "T02", "block": "9. M6 real, aspiración y aplanado en aire", "action": "Durante M6 probar PAUSA y ABORTAR, cancelar en Instala la herramienta y SISTEMA LISTO; después PAUSA fuera del M6.", "expected": "No encola M25 durante changingTool, no queda interfaz atascada; cancelar detiene cambio; PAUSA normal vuelve a funcionar fuera. M5 antes de guardas.", "evidence": "Estado, mensaje y comandos: ", "sources": "§Banco, C2/C3", "checklist": []},
    {"id": "T03", "block": "9. M6 real, aspiración y aplanado en aire", "action": "Durante viaje SAC y después del aviso final disparar T2; luego intentar HOME y SAC normales.", "expected": "No muestra aviso de cambio ni palpa tras T2; husillo no arranca después del aviso; limpia la petición y funcionan las siguientes operaciones.", "evidence": "Última fase y estado T2: ", "sources": "§Banco", "checklist": []},
    {"id": "T04", "block": "9. M6 real, aspiración y aplanado en aire", "action": "En reposo con husillo manual encendido, comprobar aspiración; repetir encendido/apagado según modo instalado.", "expected": "Aspiración sigue al husillo sin interferencias del sondeo cada ~3 s. Comprobar relé D.5 si está cableado; MODBUS solo con pin/puerto resueltos, sin conflicto Touch.", "evidence": "Retardo, tensión y pin: ", "sources": "§Banco, §Banco", "checklist": []},
    {"id": "T05", "block": "9. M6 real, aspiración y aplanado en aire", "action": "Aplanado en aire y BORDEADOR desde HOME; probar PAUSA y ESC, también dos ESC con CONFIGURACIÓN abierta. Repetir modo manual.", "expected": "Z no baja antes del XY; PAUSA/ESC detienen; VFD se apaga al terminar. Manual pide encender, aviso completo y apagar al final; Cancelar detiene.", "evidence": "Trayectoria, Z, RPM y avisos: ", "sources": "C162, §Banco, aplanado", "checklist": [162]},
    {"id": "T06", "block": "9. M6 real, aspiración y aplanado en aire", "action": "Pausa con husillo inicialmente parado y luego girando; reanudar en cada caso. Quitar/cancelar trabajo desde visor en RUNNING y PAUSED con A OFF.", "expected": "Solo rearranca el que giraba; cancelación limpia trabajo, restaura SEDA/triggers y no introduce eje A fantasma, incluso al informar fallo de macro.", "evidence": "RPM, Z, modo y mensajes: ", "sources": "H4.3, C-rot-01", "checklist": []},
    {"id": "T07", "block": "9. M6 real, aspiración y aplanado en aire", "action": "Probar pin asignable J6/P6 solo si existe/cableado, usando el flujo PINES y sin salidas energizadas peligrosas.", "expected": "M950 aceptado y disparo llega; no asignar un puerto fuera del rango físico de esta placa.", "evidence": "Pin, error y entrada: ", "sources": "§Banco", "checklist": []},
    {"id": "U01", "block": "10. Marca, visor, accesibilidad y RotechOS Touch real", "action": "En móvil/tableta guardar nombre, PNG y color de Marca; recargar, exportar e importar identidad; probar SVG y falso PNG.", "expected": "Identidad persiste y se transfiere; RotechOS visible en cabecera/Pendant/marca de agua; formatos incorrectos rechazados.", "evidence": "Dispositivo y archivos de prueba: ", "sources": "C166", "checklist": [166]},
    {"id": "U02", "block": "10. Marca, visor, accesibilidad y RotechOS Touch real", "action": "Tras HOME, fijar WCS conocido y cargar trayectoria con tramo fuera de área; mover jog.", "expected": "Rectángulo coincide con mesa medida (530×830 solo si es la unidad base); cero máquina en HOME, punto sigue XY/Z del DRO y exceso se pinta desde borde.", "evidence": "Mesa, WCS, XY/Z y captura: ", "sources": "C167", "checklist": [167]},
    {"id": "U03", "block": "10. Marca, visor, accesibilidad y RotechOS Touch real", "action": "Sin G-code cargado, doble toque en mesa del visor superior en escritorio, tableta y TRAYECTORIA móvil, también sobre Cargar G-code; repetir al llegar. Probar fuera de área y sin HOME.", "expected": "Sube Z segura y va al XY del WCS activo; funciona un segundo destino; fuera de área o sin HOME no mueve.", "evidence": "Dispositivo, XY y Z: ", "sources": "C168", "checklist": [168]},
    {"id": "U04", "block": "10. Marca, visor, accesibilidad y RotechOS Touch real", "action": "En móvil real probar modo escuela: primer y segundo toque de acciones preparadas sin riesgo.", "expected": "Primer toque ayuda; segundo ejecuta una vez, sin doble envío.", "evidence": "Acción y número de envíos: ", "sources": "C164", "checklist": [164]},
    {"id": "U05", "block": "10. Marca, visor, accesibilidad y RotechOS Touch real", "action": "Con diálogos de CONFIGURACIÓN, firmware, macro y alarma abiertos, comprobar PARO, ESC, Espacio y foco con teclado/lector de pantalla.", "expected": "PARO alcanzable, una acción por tecla, Espacio no reanuda detrás de diálogo; alarma anuncia estado y foco se recupera al cerrar.", "evidence": "Viewport, diálogo, tecla y respuesta: ", "sources": "D-01–05, §Banco", "checklist": []},
    {"id": "U06", "block": "10. Marca, visor, accesibilidad y RotechOS Touch real", "action": "En TFT70 V3.0 real, probar PARO con diálogo abierto, jog sin HOME y lectura tras línea serie larga según prueba Touch.", "expected": "PARO llega a Scylla, jog sin HOME bloqueado; diálogo no absorbe parada ni atasca serie. Compilar no sustituye esta prueba.", "evidence": "Build Touch, latencia y estado: ", "sources": "§tercera/cuarta ronda, plan §5", "checklist": []},
    {"id": "U07", "block": "10. Marca, visor, accesibilidad y RotechOS Touch real", "action": "En el asistente y consola de soporte contrastar versión, hardware y mensajes con estado real; abrir/cerrar CONFIG repetidamente en dispositivos previstos.", "expected": "Ayudas/unidades describen esta máquina; guardas activas en trabajo/pausa, sin acciones ocultas tras modales ni preferencias anunciadas como persistidas tras un error.", "evidence": "Pantalla, estado y evidencia: ", "sources": "A-1, BANCO-06", "checklist": []},
    {"id": "W01", "block": "11. Última prueba: trabajo real con fresa", "action": "Solo con todos los pasos previos resueltos y decisiones de Sergi registradas, montar fresa y material blando; ejecutar trabajo corto con mano en seta.", "expected": "Corte controlado, cotas medidas, sin pérdida de pasos ni contacto imprevisto; pausa/reanudación y final correctos para el husillo instalado.", "evidence": "Material, herramienta, RPM, avance y cotas: ", "sources": "Plan §5", "checklist": []},
    {"id": "W02", "block": "11. Última prueba: trabajo real con fresa", "action": "Solo si V04 fue PASS y Sergi acepta el riesgo residual, repetir corte real de alimentación con pieza/herramienta y medios preparados.", "expected": "M5 efectivo en VFD, Z arriba sin dañar pieza/mesa y sin rearranque; registrar comportamiento de la variante manual, sin prometer paro por firmware.", "evidence": "Subida, marcas y tiempo: ", "sources": "C154, Protocolo 2.2", "checklist": [154]}
  ].map((row) => Object.freeze({ ...row, checklist: Object.freeze(row.checklist) }));
  Object.freeze(TESTS);
  const STATUSES = Object.freeze(['OK', 'FALLA', 'NO APLICA']);
  const isDate = (v) => typeof v === 'string' && /^\d{4}-\d\d-\d\dT/.test(v) && Number.isFinite(Date.parse(v));
  const clone = (v) => JSON.parse(JSON.stringify(v));

  function createReport(now = new Date().toISOString()) {
    if (!isDate(now)) throw Error('Fecha de sesión inválida.');
    return {
      format: 'rotechos-banco', schemaVersion: 1, protocol: PROTOCOL,
      sessionId: now, createdAt: now, updatedAt: now,
      unit: '', operator: '', software: '', conditions: '',
      results: TESTS.map(({ id }) => ({ id, status: null, note: '', updatedAt: null })),
    };
  }

  function validateReport(report, forSave = false) {
    const fail = (msg) => { throw Error(`Acta de banco inválida: ${msg}`); };
    if (!report || report.format !== 'rotechos-banco' || report.schemaVersion !== 1 || report.protocol !== PROTOCOL)
      fail('formato o guion no compatible.');
    for (const key of ['sessionId', 'createdAt', 'updatedAt']) if (!isDate(report[key])) fail(`fecha ${key}.`);
    for (const key of ['unit', 'operator', 'software', 'conditions']) {
      if (typeof report[key] !== 'string' || report[key].length > 2000) fail(`campo ${key}.`);
    }
    if (forSave && (!report.unit.trim() || !report.operator.trim())) fail('indica unidad y operario.');
    if (!Array.isArray(report.results) || report.results.length !== TESTS.length) fail('faltan pruebas o hay pruebas ajenas al guion.');
    const ids = new Set();
    for (const r of report.results) {
      if (!r || !TESTS.some((t) => t.id === r.id) || ids.has(r.id)) fail('ID desconocido o duplicado.');
      ids.add(r.id);
      if (r.status !== null && !STATUSES.includes(r.status)) fail(`resultado de ${r.id}.`);
      if (typeof r.note !== 'string' || r.note.length > 4000) fail(`nota de ${r.id}.`);
      if (r.updatedAt !== null && !isDate(r.updatedAt)) fail(`fecha de ${r.id}.`);
      if (r.status !== null && (!r.note.trim() || !isDate(r.updatedAt))) fail(`${r.id} necesita nota/evidencia y fecha.`);
    }
    return report;
  }

  function parseReport(raw) {
    if (typeof raw !== 'string' || raw.length > 512000) throw Error('Acta de banco ilegible o demasiado grande.');
    return validateReport(JSON.parse(raw));
  }

  function serializeReport(report) {
    validateReport(report, true);
    return JSON.stringify(report, null, 2) + '\n';
  }

  function totals(report) {
    const counts = { OK: 0, FALLA: 0, 'NO APLICA': 0, pending: 0 };
    report.results.forEach((r) => { counts[r.status || 'pending']++; });
    return counts;
  }

  function toMarkdown(report) {
    validateReport(report, true);
    const cell = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/\|/g, '&#124;').replace(/\r?\n/g, '<br>');
    const lines = ['# Acta de pruebas de banco', '',
      `Guion: ${PROTOCOL} · Sesión: ${cell(report.sessionId)}`,
      `Unidad: ${cell(report.unit)} · Operario: ${cell(report.operator)}`,
      `Software / SD / RRF: ${cell(report.software)}`, `Condiciones: ${cell(report.conditions)}`, '',
      'Resultados declarados por el operario. Lo no ejecutado sigue PENDIENTE BANCO.',
      'NO APLICA exige justificación y no equivale a OK. Revisar evidencias antes de actualizar el checklist.', '',
      '| ID | Bloque | Qué hacer | Qué mirar | Resultado | Nota / evidencia | Fecha |',
      '|---|---|---|---|---|---|---|'];
    for (const t of TESTS) {
      const r = report.results.find((v) => v.id === t.id);
      lines.push(`| ${t.id} | ${cell(t.block)} | ${cell(t.action)} | ${cell(t.expected)} | ${r.status || 'PENDIENTE BANCO'} | ${cell(r.note)} | ${r.updatedAt || ''} |`);
    }
    return lines.join('\n') + '\n';
  }

  // El transporte solo recibe rr_download y rr_upload. Nunca ejecuta G-code.
  // Comparación previa para detectar otra pestaña y lectura posterior obligatoria.
  function createStore(request, baseUrl = '') {
    let baseRaw, loaded = false, busy = false;
    const url = (endpoint) => `${baseUrl}/${endpoint}?name=${encodeURIComponent(SD_PATH)}&time=${Date.now()}`;
    async function readRaw() {
      const res = await request(url('rr_download'), { cache: 'no-store' }, 8000);
      if (res.status === 404) return null;
      if (!res.ok) throw Error(`No se pudo leer el acta de SD (HTTP ${res.status}).`);
      const raw = await res.text();
      parseReport(raw); // Un fichero roto nunca se interpreta como una sesión vacía.
      return raw;
    }
    return {
      async load() {
        if (busy) throw Error('Hay una operación de banco en curso.');
        busy = true;
        try {
          const raw = await readRaw();
          baseRaw = raw; loaded = true;
          return raw === null ? null : parseReport(raw);
        } finally { busy = false; }
      },
      async save(report) {
        if (!loaded) throw Error('Lee primero el acta de la SD.');
        if (busy) throw Error('Hay una operación de banco en curso.');
        const raw = serializeReport(report); // Instantánea: editar después no cambia esta subida.
        busy = true;
        try {
          if (await readRaw() !== baseRaw) throw Error('El acta cambió en otra sesión. Exporta tu borrador y vuelve a leer la SD antes de guardar.');
          const res = await request(url('rr_upload'), {
            method: 'POST', body: new Blob([raw], { type: 'application/json' }),
          }, 15000);
          if (!res.ok) throw Error(`No se pudo guardar el acta (HTTP ${res.status}).`);
          const ack = await res.json();
          if (!ack || ack.err !== 0) throw Error('La controladora rechazó el acta de banco.');
          if (await readRaw() !== raw) throw Error('No se pudo comprobar el acta guardada. Conserva o exporta este borrador y vuelve a leer la SD.');
          baseRaw = raw;
          return parseReport(raw);
        } finally { busy = false; }
      },
    };
  }

  let mounted = false;
  function open() {
    if (mounted) return;
    const panel = root.document.getElementById('mcfgTabBanco');
    if (!panel) return;
    mounted = true;
    const doc = root.document;
    const el = (tag, cls, text) => {
      const n = doc.createElement(tag);
      if (cls) n.className = cls;
      if (text !== undefined) n.textContent = text;
      return n;
    };
    const button = (text, id, fn) => {
      const b = el('button', 'mcfg-btn-sec', text);
      b.type = 'button'; b.id = id; b.addEventListener('click', fn);
      return b;
    };
    const header = el('header', 'mcfg-banco-header');
    const heading = el('div', 'mcfg-banco-heading');
    const progress = el('p', 'mcfg-hint'); progress.id = 'bancoProgress';
    heading.append(el('div', 'mcfg-section-title', 'Pruebas de banco'), progress);
    const message = el('p', 'mcfg-hint'); message.id = 'bancoMessage'; message.setAttribute('role', 'status');
    message.setAttribute('aria-live', 'polite');
    const toolbar = el('div', 'mcfg-banco-toolbar');
    header.append(heading, message, toolbar); while (panel.firstChild) panel.removeChild(panel.firstChild); panel.append(header);
    panel.append(el('p', 'mcfg-safety',
      'PENDIENTE BANCO. Este asistente solo registra lo observado. Ejecuta cada prueba con los controles habituales; aquí no se envían órdenes a la máquina. Sin fresa ni pieza hasta el último bloque. Sostén Z al probar cortes de corriente y mantén la mano en la seta durante movimientos. Ante una FALLA de seguridad, para y registra la incidencia. No pases a una prueba de mayor riesgo.'));
    const loadButton = button('Volver a leer SD', 'bancoLoad', () => { void load(); });
    const fields = el('fieldset', 'mcfg-banco-fields'); fields.disabled = true;
    fields.setAttribute('aria-label', 'Registro de pruebas de banco');
    panel.append(fields);
    let report = createReport(), lastSaved = null, index = 0, dirty = false, ready = false;
    const store = createStore((...args) => _fetchRRF(...args), typeof TARGET_IP === 'string' ? TARGET_IP : '');
    const session = el('details', 'mcfg-adv'); session.id = 'bancoSession';
    session.append(el('summary', '', 'Datos de la sesión')); fields.append(session);
    const sessionBody = el('div', 'mcfg-adv-body'); session.append(sessionBody);
    const metadata = el('div', 'mcfg-banco-metadata'); sessionBody.append(metadata);
    const metaInputs = {};
    for (const [key, label] of [['unit', 'Unidad / placa'], ['operator', 'Operario'], ['software', 'Versiones SD / RRF / commit'], ['conditions', 'Montaje, instrumentos y condiciones']]) {
      const wrap = el('div');
      const input = el('input', 'in-txt'); input.id = `banco-${key}`; input.type = 'text'; input.maxLength = 2000;
      const lbl = el('label', 'mcfg-lbl', label); lbl.htmlFor = input.id;
      input.addEventListener('input', () => { report[key] = input.value; changed(); });
      wrap.append(lbl, input); metadata.append(wrap); metaInputs[key] = input;
    }
    const selectLabel = el('label', 'mcfg-lbl', 'Prueba (orden de riesgo)'); selectLabel.htmlFor = 'bancoStep';
    const picker = el('select', 'in-txt'); picker.id = 'bancoStep';
    TESTS.forEach((t, i) => {
      const option = el('option', '', `${i + 1}. ${t.id} · ${t.block}`); option.value = String(i); picker.append(option);
    });
    picker.addEventListener('change', () => { index = Number(picker.value); renderStep(); });
    const step = el('div', 'mcfg-banco-step');
    const choice = el('div'); choice.append(selectLabel, picker); step.append(choice); fields.append(step);
    const card = el('section', 'mcfg-banco-card'); card.setAttribute('aria-labelledby', 'bancoTitle');
    const title = el('h3', 'mcfg-title'); title.id = 'bancoTitle';
    const action = el('p'), expected = el('p'), evidence = el('p', 'mcfg-hint'), sources = el('p', 'mcfg-hint');
    action.id = 'bancoAction'; expected.id = 'bancoExpected';
    const instructions = el('div', 'mcfg-banco-instructions');
    const doing = el('div'), looking = el('div');
    doing.append(el('strong', '', 'Qué hacer'), action);
    looking.append(el('strong', '', 'Qué mirar'), expected);
    instructions.append(doing, looking);
    const references = el('div', 'mcfg-banco-references'); references.append(evidence, sources);
    card.append(title, instructions, references);
    const statusLabel = el('label', 'mcfg-lbl', 'Resultado observado'); statusLabel.htmlFor = 'bancoStatus';
    const status = el('select', 'in-txt'); status.id = 'bancoStatus';
    for (const value of ['', ...STATUSES]) {
      const option = el('option', '', value || 'PENDIENTE BANCO'); option.value = value; status.append(option);
    }
    const noteLabel = el('label', 'mcfg-lbl', 'Nota, medida y evidencia (obligatoria al marcar resultado)'); noteLabel.htmlFor = 'bancoNote';
    const note = el('textarea', 'in-txt'); note.id = 'bancoNote'; note.rows = 2; note.maxLength = 4000;
    note.placeholder = 'Qué has observado, medidas con unidad y referencia de evidencia. Si no aplica, explica por qué. No incluyas contraseñas.';
    const updateResult = () => {
      const r = report.results.find((v) => v.id === TESTS[index].id);
      r.status = status.value || null; r.note = note.value; r.updatedAt = new Date().toISOString();
      changed();
    };
    status.addEventListener('change', updateResult); note.addEventListener('input', updateResult);
    const result = el('div', 'mcfg-banco-result');
    const observed = el('div'), annotated = el('div');
    observed.append(statusLabel, status); annotated.append(noteLabel, note);
    result.append(observed, annotated); card.append(result); fields.append(card);
    const nav = el('div', 'mcfg-banco-nav');
    nav.setAttribute('role', 'group'); nav.setAttribute('aria-label', 'Navegar por las pruebas');
    const prev = button('Anterior', 'bancoPrev', () => { index--; renderStep(); });
    const next = button('Siguiente', 'bancoNext', () => { index++; renderStep(); });
    nav.append(prev, next); step.append(nav);
    // Conserva el bloqueo de Guardar/Nueva sesión durante las operaciones de SD.
    // Exportar y Volver a leer mantienen su disponibilidad original.
    const actions = el('fieldset', 'mcfg-banco-actions'); actions.disabled = true;
    actions.setAttribute('aria-label', 'Guardar o iniciar sesión');
    const save = button('Guardar en SD', 'bancoSave', () => { void saveReport(); });
    actions.append(save,
      button('Nueva sesión', 'bancoNew', () => { void newSession(); }));
    toolbar.append(actions, button('Exportar JSON', 'bancoJson', () => download('json')),
      button('Exportar Markdown', 'bancoMarkdown', () => download('md')), loadButton);
    sessionBody.append(el('p', 'mcfg-hint', 'Guardar conserva la sesión actual en la SD. Exporta el JSON a docs/banco/resultados/ para que pendiente.sh lo lea. NO APLICA no equivale a OK; los documentos de origen se actualizan tras revisar la evidencia.'));

    function say(text, error = false) {
      message.textContent = text; message.classList.toggle('ui-warn', error);
    }
    function summary() {
      const n = totals(report);
      progress.textContent = `${n.OK} OK · ${n.FALLA} FALLA · ${n['NO APLICA']} NO APLICA · ${n.pending} PENDIENTE BANCO`;
    }
    function changed() {
      dirty = true; report.updatedAt = new Date().toISOString();
      summary(); say('Cambios sin guardar en SD.');
      if (report.results.some((r) => r.status === 'FALLA')) say('Hay pruebas con FALLA. Para ante un fallo de seguridad; no pases a mayor riesgo. Cambios sin guardar en SD.', true);
    }
    function renderStep() {
      const t = TESTS[index], r = report.results.find((v) => v.id === t.id);
      picker.value = String(index); title.textContent = `${t.id} · ${t.block}`;
      action.textContent = t.action; expected.textContent = t.expected;
      evidence.textContent = `Anota: ${t.evidence}`; sources.textContent = `Origen: ${t.sources}`;
      status.value = r.status || ''; note.value = r.note;
      prev.disabled = index === 0; next.disabled = index === TESTS.length - 1;
      summary();
    }
    function renderReport() {
      for (const key of Object.keys(metaInputs)) metaInputs[key].value = report[key];
      session.open = Object.keys(metaInputs).some((key) => !report[key].trim());
      renderStep();
    }
    async function load() {
      if (dirty && !await ask('Volver a leer SD', 'Se sustituirá el borrador por la sesión de la SD. Exporta primero si necesitas conservarlo. ¿Continuar?')) return;
      fields.disabled = actions.disabled = true; loadButton.disabled = true; say('Leyendo resultados de la SD…');
      try {
        const saved = await store.load();
        report = saved || createReport(); lastSaved = clone(report); ready = true; dirty = false;
        renderReport(); clearDirty();
        say(saved ? 'Sesión recuperada de la SD. Resultados declarados por el operario.' : 'Sin acta en SD. Todas las pruebas siguen PENDIENTE BANCO.');
      } catch (e) { ready = false; say(`No se pudo cargar: ${e.message} No se sobrescribirá el fichero.`, true); }
      finally { fields.disabled = actions.disabled = !ready; loadButton.disabled = false; }
    }
    function clearDirty() {
      if (typeof AppState !== 'undefined') AppState.ui?.mcfgDirtyClearTab?.('banco');
    }
    async function saveReport() {
      if (!ready || save.disabled) return;
      const snapshot = clone(report);
      fields.disabled = actions.disabled = true; save.disabled = true; loadButton.disabled = true; say('Guardando y comprobando en SD…');
      try {
        await store.save(snapshot); lastSaved = snapshot; dirty = false; clearDirty();
        say('Guardado y comprobado en SD. El registro no sustituye la validación física.');
      } catch (e) { say(`No se confirmó el guardado: ${e.message}`, true); }
      finally { fields.disabled = actions.disabled = false; save.disabled = false; loadButton.disabled = false; }
    }
    function download(ext) {
      try {
        const raw = ext === 'json' ? serializeReport(report) : toMarkdown(report);
        const url = root.URL.createObjectURL(new Blob([raw], { type: ext === 'json' ? 'application/json' : 'text/markdown;charset=utf-8' }));
        const link = el('a'); link.href = url;
        link.download = `banco-${report.createdAt.replace(/[^0-9]/g, '')}.${ext}`;
        doc.body.append(link); link.click(); link.remove();
        root.setTimeout(() => root.URL.revokeObjectURL(url), 1000);
        say(dirty ? 'Borrador exportado; hay cambios sin guardar en SD.' : 'Acta exportada. Revisa las evidencias antes de actualizar el checklist.');
      } catch (e) { say(e.message, true); }
    }
    function ask(titleText, body) {
      return typeof confirmDialog === 'function' ? confirmDialog(titleText, body) : Promise.resolve(root.confirm(body));
    }
    async function newSession() {
      if (!await ask('Nueva sesión de banco', 'Exporta el acta actual antes de sustituirla. La sesión anterior seguirá en la SD hasta que guardes la nueva. ¿Crear una sesión vacía?')) return;
      report = createReport(); index = 0; changed(); renderReport();
      // Notifica al aviso común de cierre que esta pestaña tiene un borrador.
      metaInputs.unit.dispatchEvent(new Event('input', { bubbles: true }));
    }
    // El listener común de cierre pide confirmación antes de llegar aquí.
    // Si el operario acepta descartar, restaurar también el borrador local.
    doc.getElementById('btnMcfgClose')?.addEventListener('click', () => {
      if (!dirty) return;
      report = lastSaved ? clone(lastSaved) : createReport(); dirty = false;
      renderReport(); say('Borrador descartado. Se conserva la última lectura o guardado de SD.');
    });
    // Sin beforeunload a propósito (FLUJO-7 / H-T-03): la UI no engancha el cierre de pestaña.
    void load();
  }

  const api = { PROTOCOL, SD_PATH, TESTS, STATUSES, createReport, validateReport, parseReport, serializeReport, totals, toMarkdown, createStore, open };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.ROTECHOS_BANCO = api;
})(typeof window !== 'undefined' ? window : globalThis);
