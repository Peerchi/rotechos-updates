/* ---
   ROTECHOS — Asignación de pines libres a funciones operativas (UI + lógica).

   Módulo auto-contenido (catálogo + parser + generador + UI) cargado de
   forma PEREZOSA al primer click en la pestaña CONTROLADORA. NO depende de
   rotechos-config-pins.js: todo lo necesario para pintar y persistir la
   asignación está aquí dentro, en un único script que viaja con la app.

   RAZÓN de inlineado (t_fa32b4d7, sep-2026): el gate de presupuesto de
   rendimiento bloquea cualquier crecimiento >4096 B por archivo contra la
   línea base. Inlining ahorra la cabecera/marco de un módulo extra y deja
   el coste asociado al "modulo del user que abre CONTROLADORA", no al
   bootstrap del modal principal.

   MODELO
   ──────
   - El operario no edita pines: edita FUNCIONES (aspiración, luz, etc.).
     Por cada función elige tipo (on/off / PWM / entrada) y pin.
   - La UI traduce la combinación a `M950 P{n}` (salida) o `M950 J{n}`
     (entrada): entradas desde J6 (J0..J5 son el escudo de homeall.g/recover_triggers.g) y
     salidas desde P6. Ver M950_BASE_J/M950_BASE_P: con 100 RRF rechazaba el M950.
   - Persistencia: línea `; rotech-pins=...` en config-machine.g
     (NO en config.g — es per-máquina).

   LÍMITES DUROS
   ─────────────
   - NUNCA ofrece D.8/D.9 (puerto serie pantalla), B.10/B.11 (I2C), ni los
     pines de los drivers TMC2160 ni sus endstops.
   - Toda salida nueva nace en OFF (M42 P{n} S0) — una salida que arranca
     activa puede energizar un relé o una bomba al inicio.

   PENDIENTE BANCO: la asignación real a un GPIO de la Scylla debe probarse
   con la placa conectada antes de confiar en un cliente.
   ═══════════════════════════════════════════════════════════════════════════ */
(function () {
  'use strict';

  // ---
  // Catálogo de pines BTT Scylla V1.0
  // ---
  const PINES_CATALOG = [
    { pin:'D.8',  role:'serial',   note:['Puerto serie pantalla (TX)','Display serial (TX)'] },
    { pin:'D.9',  role:'serial',   note:['Puerto serie pantalla (RX)','Display serial (RX)'] },
    { pin:'B.10', role:'i2c',      note:['Bus I2C SCL','I2C SCL'] },
    { pin:'B.11', role:'i2c',      note:['Bus I2C SDA','I2C SDA'] },
    { pin:'E.7',  role:'probe',    note:['Sonda Z (pulsador)','Z probe (contact button)'] },
    { pin:'D.6',  role:'led',      note:['LED RGB NeoPixel (WS2812B)','RGB LED NeoPixel (WS2812B)'] },
    { pin:'B.1',  role:'spindle',  note:['Spindle PWM (VFD 0-10V)','Spindle PWM (VFD 0-10V)'] },
    { pin:'C.5',  role:'spindle',  note:['Spindle enable','Spindle enable'] },
    { pin:'B.0',  role:'spindle',  note:['Spindle direction','Spindle direction'] },
    { pin:'D.11', role:'endstop',  note:['X-MIN','X-MIN'] },
    { pin:'C.6',  role:'endstop',  note:['X-MAX','X-MAX'] },
    { pin:'A.8',  role:'endstop',  note:['Y-MIN','Y-MIN'] },
    { pin:'D.14', role:'endstop',  note:['Y-MAX','Y-MAX'] },
    { pin:'C.7',  role:'endstop',  note:['Z-MIN','Z-MIN'] },
    { pin:'D.12', role:'endstop',  note:['Z-MAX','Z-MAX'] },
    { pin:'PA0',  role:'driver',   note:['Driver 0 (X) STEP','Driver 0 (X) STEP'] },
    { pin:'PA1',  role:'driver',   note:['Driver 0 (X) DIR','Driver 0 (X) DIR'] },
    { pin:'PC0',  role:'driver',   note:['Driver 0 (X) EN','Driver 0 (X) EN'] },
    { pin:'PC1',  role:'driver',   note:['Driver 0 (X) DIAG','Driver 0 (X) DIAG'] },
    { pin:'PC13', role:'driver',   note:['Driver 1 (Y) STEP','Driver 1 (Y) STEP'] },
    { pin:'PE6',  role:'driver',   note:['Driver 1 (Y) DIR','Driver 1 (Y) DIR'] },
    { pin:'PC2',  role:'driver',   note:['Driver 1 (Y) EN','Driver 1 (Y) EN'] },
    { pin:'PC3',  role:'driver',   note:['Driver 1 (Y) DIAG','Driver 1 (Y) DIAG'] },
    { pin:'PB8',  role:'driver',   note:['Driver 2 (Z) STEP','Driver 2 (Z) STEP'] },
    { pin:'PB9',  role:'driver',   note:['Driver 2 (Z) DIR','Driver 2 (Z) DIR'] },
    { pin:'PE5',  role:'driver',   note:['Driver 2 (Z) EN','Driver 2 (Z) EN'] },
    { pin:'PE3',  role:'driver',   note:['Driver 2 (Z) DIAG','Driver 2 (Z) DIAG'] },
    { pin:'PD3',  role:'driver',   note:['Driver 3 (A) STEP','Driver 3 (A) STEP'] },
    { pin:'PD4',  role:'driver',   note:['Driver 3 (A) DIR','Driver 3 (A) DIR'] },
    { pin:'PE1',  role:'driver',   note:['Driver 3 (A) EN','Driver 3 (A) EN'] },
    { pin:'PE0',  role:'driver',   note:['Driver 3 (A) DIAG','Driver 3 (A) DIAG'] },
    { pin:'D.5',  role:'logic',    note:['Relé mecánico 220V (contacto seco)','Mechanical relay 220V (dry contact)'] },
    { pin:'A.4',  role:'power',    note:['AUX 0 — emite tensión V-MOS','AUX 0 — emits V-MOS voltage'] },
    { pin:'A.5',  role:'power',    note:['AUX 1 — emite tensión V-MOS','AUX 1 — emits V-MOS voltage'] },
    { pin:'A.6',  role:'power',    note:['AUX 2 — emite tensión V-MOS','AUX 2 — emits V-MOS voltage'] },
    { pin:'A.7',  role:'power',    note:['Mist (M7) — emite tensión V-MOS','Mist (M7) — emits V-MOS voltage'] },
    { pin:'C.4',  role:'power',    note:['Cool (M8) — emite tensión V-MOS','Cool (M8) — emits V-MOS voltage'] },
    { pin:'B.7',  role:'logic',    note:['IO-IN (entrada 5 V tolerant)','IO-IN (5 V tolerant input)'] },
  ];

  // `inputNc` solo aplica a entradas digitales: indica si por defecto la
  // lectura debe invertirse con `!` (fail-safe: cable cortado dispara). Por
  // seguridad, NC es la opción por defecto en TODO el proyecto: un circuito
  // normalmente cerrado y un cable pelado tienen el mismo comportamiento — el
  // firmware para la máquina. NO (Normally Open) significa "si se corta el
  // cable, el botón deja de funcionar y nadie se entera".
  const PINES_FUNCTIONS = [
    { id:'aspiracion',          label:['Aspiración','Dust extraction'],         types:['output_digital'],                          defaultPin:'D.5', defaultType:'output_digital', pwmNote:'', inputNc:false },
    { id:'aspiracion_potencia', label:['Aspiración (V-MOS)','Dust extraction (V-MOS)'], types:['output_digital'],                   defaultPin:'A.5', defaultType:'output_digital', pwmNote:'', inputNc:false },
    { id:'luz',                 label:['Luz de trabajo','Work light'],           types:['output_digital'],                          defaultPin:'A.6', defaultType:'output_digital', pwmNote:'', inputNc:false },
    { id:'luz_potencia',        label:['Luz de trabajo (V-MOS)','Work light (V-MOS)'], types:['output_digital'],                  defaultPin:'A.6', defaultType:'output_digital', pwmNote:'', inputNc:false },
    { id:'refrigerante',        label:['Refrigerante (M8)','Coolant (M8)'],     types:['output_pwm','output_digital'],            defaultPin:'C.4', defaultType:'output_pwm',     pwmNote:['PWM en C.4: sin verificar en banco. Si tu V-MOS supera 24V, no uses PWM en este pin.','PWM on C.4: unverified in hardware.'], inputNc:false },
    { id:'neblina',             label:['Neblina (M7)','Mist (M7)'],             types:['output_pwm','output_digital'],            defaultPin:'A.7', defaultType:'output_pwm',     pwmNote:['PWM en A.7: sin verificar en banco. M7 y M8 son mutuamente excluyentes.','PWM on A.7: unverified in hardware. M7 and M8 are mutually exclusive.'], inputNc:false },
    { id:'ventilador_aux',      label:['Ventilador auxiliar','Auxiliary fan'],  types:['output_pwm','output_digital'],            defaultPin:'A.4', defaultType:'output_pwm',     pwmNote:'', inputNc:false },
    // paro_externo — UNICA función de tipo input_digital que el operario puede
    // configurar. NC por defecto (inputNc=true) por seguridad: cable cortado o
    // suelto dispara el paro. NO (Normally Open) significa "si se corta el
    // cable, el botón deja de funcionar y nadie se entera".
    { id:'paro_externo',        label:['Botón externo de PARO (entrada)','External STOP button (input)'], types:['input_digital'],     defaultPin:'B.7', defaultType:'input_digital',  pwmNote:'', inputNc:true, paro:true },
  ];

  // 27-sep (análisis de la interfaz contra el fuente de RRF 3.5.4): eran 100 para las dos, y
  // RRF no los admite. `M950 J` exige J < MaxGpInPorts (Platform.cpp:4610), que el mapa de bits de
  // entradas acota a 32 sin CAN (RepRapFirmware.h:380-387 y 419): `M950 J100` daba «parameter 'J'
  // too high», el pin no se configuraba y el PARO externo no vigilaba nada. J0..J5 son los seis
  // finales del escudo (recover_triggers.g), así que las entradas empiezan en J6. Las salidas
  // (`M950 P`, límite MaxGpOutPorts: 20 en la placa más pequeña definida en el fuente,
  // Pins_DuetNG.h:110) empiezan también en 6: P0/P1 las usaban guardados viejos de la
  // refrigeración (`M42 P0/P1`) y no deben volver a encender nada.
  const M950_BASE_J = 6;
  const M950_BASE_P = 6;
  const LANG = (typeof window.t === 'function') ? (k, d) => window.t(k, d) : (_k, d) => d;
  const MAX_INPUTS = Object.freeze({ 'C.6': 'X', 'D.14': 'Y', 'D.12': 'Z' });

  function pinRole(p) { const e = PINES_CATALOG.find((x) => x.pin === p); return e ? e.role : 'unknown'; }
  function pinFamily(p) { const r = pinRole(p); return r === 'power' ? 'power' : (r === 'logic' ? 'logic' : 'other'); }
  function maxInputReason(pin, endstopState) {
    const axis = MAX_INPUTS[pin];
    if (!axis) return '';
    const used = !!(endstopState && endstopState[axis] && endstopState[axis].maxOn);
    return used ? LANG('cfg.pinesFn.enUsoMax', 'El eje {a} referencia a MAX; el pin {p} está en uso.').replace('{a}', axis).replace('{p}', pin) : '';
  }
  function currentEndstopState() {
    if (typeof window._endstopCfg === 'object') return window._endstopCfg;
    // Mutacion comprobada 2026-09-05: devolver `{}` aqui deja pasar los MAX sin
    // saber que dice M574, y pone en rojo el test "sin M574 leido (fail closed)"
    // (37/1 mutado, 38/0 restaurado).
    // Fail closed si la UI aún no ha leído M574: no ofrecer un MAX hasta
    // saber que el eje correspondiente no lo usa.
    return { X: { maxOn: true }, Y: { maxOn: true }, Z: { maxOn: true } };
  }
  function pinUseReason(type, pin, endstopState = currentEndstopState()) {
    if (type !== 'input_digital') return '';
    if (pin === 'B.7') return '';
    if (!Object.prototype.hasOwnProperty.call(MAX_INPUTS, pin)) return LANG('cfg.pinesFn.noEntrada', 'El pin {p} no es una entrada asignable.').replace('{p}', pin);
    return maxInputReason(pin, endstopState);
  }
  function canUsePinAs(type, pin, endstopState = currentEndstopState()) {
    if (typeof pin !== 'string' || !pin) return false;
    const role = pinRole(pin);
    // Solo pines CONOCIDOS del catálogo. Un pin desconocido (typo, refactor
    // del catálogo, hardware no Scylla) nunca debe aparecer como opción y
    // debe rechazarse siempre — si un operario lo escribió a mano y luego
    // abre esta pestaña, la fila se marcará inválida y se le invita a
    // cambiarlo.
    if (role === 'unknown') return false;
    if (type === 'input_digital' && Object.prototype.hasOwnProperty.call(MAX_INPUTS, pin)) {
      return !pinUseReason(type, pin, endstopState);
    }
    if (role !== 'power' && role !== 'logic') return false;
    if (type === 'output_digital') return role === 'power' || role === 'logic';
    if (type === 'output_pwm')     return role === 'power';
    if (type === 'input_digital') return pin === 'B.7';
    return false;
  }

  // Formato del serializado: slug:type:pin:btn[:nc]
  //   - 2 campos (legado): slug:pin → output_digital, btn=0, nc=1 (NC)
  //   - 4 campos:           slug:type:pin:btn → nc=1 (NC, default seguro)
  //   - 5 campos:           slug:type:pin:btn:nc → nc ∈ {0,1,"0","1"} (1=NC, 0=NO)
  // El campo nc SOLO aplica a input_digital; en otro tipo se ignora.
  // MIGRACIÓN: las configuraciones previas (sin nc) asumen NC=1, que es la
  // opción segura por defecto — ningún operario verá su seta cambiar de
  // comportamiento al recargar esta versión.
  function parseRotechPins(raw) {
    const out = {};
    if (typeof raw !== 'string' || !raw) return out;
    const m = raw.match(/;\s*rotech-pins=([^\n]+)/);
    if (!m) return out;
    for (const part of m[1].split(',')) {
      const seg = part.trim(); if (!seg) continue;
      const f = seg.split(':').map((s) => s.trim());
      const slug = f[0]; if (!slug) continue;
      if (f.length === 2) {
        out[slug] = { type: 'output_digital', pin: f[1] || '', btn: 0, nc: 1 };
      } else if (f.length >= 4) {
        const ncRaw = (f[4] || '1').toLowerCase();
        const nc = (ncRaw === '0' || ncRaw === 'no' || ncRaw === 'false') ? 0 : 1;
        out[slug] = { type: f[1] || 'output_digital', pin: f[2] || '', btn: f[3] === '1' ? 1 : 0, nc };
      }
    }
    return out;
  }

  // Aplica el prefijo NC al pin de una entrada digital.
  //   nc=1 (NC)  → M950 J{n} C"^pin"    (pull-up, sin invertir)
  //   nc=0 (NO)  → M950 J{n} C"^!pin"   (pull-up + invertido)
  //
  // ¿POR QUÉ ASÍ (no al revés)?
  // ---
  // RRF: `^` activa pull-up, `!` invierte el valor leído. M581 S1 dispara
  // en FLANCO ASCENDENTE (0→1). La seta cablea entre el pin y GND.
  //
  // • NC — interruptor normalmente cerrado. Idle = cerrado = GND = LOW (0).
  //   Al pulsar se abre → pull-up → HIGH (1) → edge 0→1, FUEGO. Sin `!`.
  //   Fail-safe: cable cortado → flotante → HIGH → edge si veníamos de
  //   LOW → FUEGO (correcto, comportamiento fail-safe).
  //
  // • NO — interruptor normalmente abierto. Idle = abierto = flotante = HIGH
  //   (1) por pull-up. Al pulsar se cierra → GND → LOW (0). Como M581 S1
  //   solo dispara en 0→1, hace falta invertir con `!` para que pulsar
  //   produzca LOW→invertido→HIGH → edge → FUEGO.
  //   Fail-safe: cable cortado → flotante = HIGH (1), invertido = 0, sin
  //   edge → NO FUEGO. ESTO ES EL CONTRATO: NO no detecta cable cortado.
  function _pinSpec(pin, type, nc) {
    if (type !== 'input_digital') return pin;
    return nc ? `^${pin}` : `^!${pin}`;
  }

  // Número de M950 J{n} que se asigna a una entrada digital. Si cambia el
  // pin, el número SE RECICLA — al guardar, el módulo quita huérfanos via
  // applyPinsToContent (reescribe el bloque entero). Esto significa que un
  // cambio de pin no deja otro M950/M581 apuntando al pin anterior.
  // Trigger number es FIJO: el paro_externo usa SIEMPRE T0, la parada de emergencia NATIVA.
  // 26-sep (auditoría contra el fuente de RRF 3.5.4, C4): iba a T3 → trigger3.g, una macro, y
  // RRF no lanza un trigger ≥1 mientras otro está en curso (GCodes.cpp:818-845): si el escudo
  // de finales (T2) estaba ejecutándose, el PARO esperaba. T0 no espera a nada y no pasa por
  // ninguna macro (GCodes.cpp:821-825). Las configuraciones viejas con T3 siguen parando:
  // trigger3.g solo contiene M112.
  const PARO_TRIGGER_T = 0;
  const PARO_TRIGGER_FILE = 'parada de emergencia (T0)';

  function generateM950Lines(parsed) {
    const lines = [];
    const rtCmds = [];
    const owners = [];
    for (const slug of Object.keys(parsed || {})) {
      const r = parsed[slug];
      if (r && r.pin) owners.push({ slug, ...r });
    }
    const inputs  = owners.filter((o) => o.type === 'input_digital');
    const outputs = owners.filter((o) => o.type !== 'input_digital');
    let n = M950_BASE_J;
    for (const o of inputs) {
      const spec = _pinSpec(o.pin, o.type, o.nc);
      const line = `M950 J${n} C"${spec}"  ; rotech-pins → ${o.slug}${o.type === 'input_digital' ? ` (${o.nc ? 'NC' : 'NO'})` : ''}`;
      lines.push(line);
      rtCmds.push(line.split(';')[0].trim());
      // El paro_externo (única input_digital del catálogo) se cablea con
      // M581 al trigger 0 (parada de emergencia del firmware). Cualquier otro input_digital
      // futuro NO hereda este comportamiento — es opt-in por slug.
      if (o.slug === 'paro_externo') {
        const m581 = `M581 P${n} T${PARO_TRIGGER_T} S1 R0  ; paro_externo → ${PARO_TRIGGER_FILE}`;
        lines.push(m581);
        rtCmds.push(m581.split(';')[0].trim());
      }
      n++;
    }
    n = M950_BASE_P;
    for (const o of outputs) {
      const line = `M950 P${n} C"${o.pin}"  ; rotech-pins → ${o.slug}`;
      const off  = `M42 P${n} S0  ; apagado seguro al guardar (rotech-pins → ${o.slug})`;
      lines.push(line);
      // M42 P{n} S0 también se persiste para que la próxima vez que la
      // placa arranque sin el rtCmd, el pin nazca OFF (defensa en
      // profundidad: un operario que abre el fichero en frío ve el
      // mismo estado que tendría tras Guardar).
      lines.push(off);
      rtCmds.push(line.split(';')[0].trim());
      rtCmds.push(off.split(';')[0].trim());
      n++;
    }
    return { lines, rtCmds };
  }

  function applyPinsToContent(raw, parsed) {
    const text = String(raw || '');
    const bh = `; --- Pines asignados por el operario (rotech-pins) ---`;
    const bf = `; --- fin pines asignados ---`;
    const ser = [];
    for (const slug of Object.keys(parsed || {})) {
      const r = parsed[slug]; if (!r || !r.pin) continue;
      // Campo 5 solo si input_digital: nc ∈ {0,1}. Para outputs es siempre
      // 1 y se omite por brevedad — siempre fue 'NC' para homing endstops.
      const ncSuffix = (r.type === 'input_digital') ? `:${r.nc ? 1 : 0}` : '';
      ser.push(`${slug}:${r.type || 'output_digital'}:${r.pin}:${r.btn ? 1 : 0}${ncSuffix}`);
    }
    const newPinsLine = `; rotech-pins=${ser.join(',')}`;
    const rePins = /^;\s*rotech-pins=.*$/m;
    let out = rePins.test(text) ? text.replace(rePins, newPinsLine) : text + '\n' + newPinsLine + '\n';
    const { lines } = generateM950Lines(parsed);
    const esc = (s) => String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const reBlock = RegExp(`^${esc(bh)}\\n[\\s\\S]*?^${esc(bf)}\\n?`, 'm');
    const newBlock = lines.length
      ? `${bh}\n${lines.join('\n')}\n${bf}\n`
      : `${bh}\n${bf}\n`;
    if (reBlock.test(out)) return out.replace(reBlock, newBlock);
    const lastSet = out.lastIndexOf('set global.');
    if (lastSet > -1) {
      const end = out.indexOf('\n', lastSet);
      return out.slice(0, end + 1) + '\n' + newBlock + out.slice(end + 1);
    }
    return out + '\n' + newBlock;
  }

  function sanityCheckAssignment(parsed) {
    if (!parsed || typeof parsed !== 'object') return { ok: true };
    for (const slug of Object.keys(parsed)) {
      const r = parsed[slug]; if (!r || !r.pin) continue;
      const types = ['output_digital', 'output_pwm', 'input_digital'];
      if (!types.includes(r.type)) return { ok: false, reason: LANG('cfg.pinesFn.tipoDesc', 'Tipo desconocido "{t}" en {f}').replace('{t}', r.type).replace('{f}', slug) };
      const useReason = pinUseReason(r.type, r.pin);
      if (useReason) return { ok: false, reason: `${useReason} (función ${slug})` };
      if (!canUsePinAs(r.type, r.pin)) return { ok: false, reason: LANG('cfg.pinesFn.tipoNo', 'El pin {p} no admite tipo {t} (función {f})').replace('{p}', r.pin).replace('{t}', r.type).replace('{f}', slug) };
    }
    const counts = {};
    for (const slug of Object.keys(parsed)) {
      const r = parsed[slug]; if (!r || !r.pin) continue;
      (counts[r.pin] ||= []).push(slug);
    }
    const confs = Object.keys(counts).filter((p) => counts[p].length > 1);
    if (confs.length) {
      const list = confs.map((p) => `${p} → ${counts[p].join(', ')}`).join('; ');
      return { ok: false, reason: LANG('cfg.pinesFn.duplicado', 'Pin asignado a más de una función: ') + list };
    }
    return { ok: true };
  }

  // ---
  // UI
  // ---
  let _draft = {};

  function _buildPinOptions(type, selected) {
    const f = document.createDocumentFragment();
    const pg = document.createElement('optgroup'); pg.label = `Salidas de potencia V-MOS (24/36/48 V)`;
    const lg = document.createElement('optgroup'); lg.label = `Señales lógicas (relé / IO-IN 5 V)`;
    for (const e of PINES_CATALOG) {
      if (!canUsePinAs(type, e.pin)) continue;
      const o = document.createElement('option');
      o.value = e.pin;
      o.textContent = `${e.pin} — ${e.note[0]}`;
      if (e.role === 'power') pg.appendChild(o); else lg.appendChild(o);
    }
    if (pg.children.length) f.appendChild(pg);
    if (lg.children.length) f.appendChild(lg);
    const b = document.createElement('option'); b.value = ``; b.textContent = `— Sin asignar —`;
    f.insertBefore(b, f.firstChild);
    if (selected && [...f.querySelectorAll('option')].some((o) => o.value === selected)) b.selected = false;
    else b.selected = true;
    return f;
  }

  function _refreshNote(fn, td) {
    const tEl = document.getElementById(`mcfgPinesTipo_${fn.id}`);
    const pEl = document.getElementById(`mcfgPinesPin_${fn.id}`);
    if (!tEl || !pEl || !td) return;
    const t = tEl.value, pp = pEl.value;
    const bits = [];
    if (t === 'output_pwm' && pp && fn.pwmNote) bits.push(fn.pwmNote[0]);
    if (pp && pinFamily(pp) === 'power') {
      bits.push(`ATENCIÓN: ${pp} emite la tensión de V-MOS (${pp === 'D.5' ? 'contacto seco' : '24/36/48 V'}). NO conectar cargas de 5 V.`);
    }
    if (t === 'input_digital') {
      const reason = (pp && pinUseReason(t, pp)) || td.dataset.pinUseReason;
      if (reason) bits.push(reason);
      else if (pp && pinFamily(pp) !== 'logic') bits.push(`Pin no apto como entrada.`);
    }
    td.textContent = bits.join(' · ');
    td.style.color = bits.length ? 'var(--warn-strong)' : 'var(--text-3)';
  }

  function _renderConflicts() {
    const box = document.getElementById(`mcfgPinesFuncionesConflicts`);
    if (!box) return;
    const tmp = {};
    for (const slug of Object.keys(_draft)) {
      const r = _draft[slug]; if (!r || !r.pin) continue;
      (tmp[r.pin] ||= []).push(slug);
    }
    const conf = Object.keys(tmp).filter((p) => tmp[p].length > 1);
    box.innerHTML = conf.length === 0 ? '' : conf.map((p) => {
      const sl = tmp[p].join(', ');
      return `<div style="padding:8px 10px;border:1px solid var(--red);background:#ff5c5c14;color:var(--red);border-radius:var(--r-sm);font-size:12px;margin-bottom:6px">Pin <code>${p}</code> asignado a más de una función: <strong>${sl}</strong>. Elige un pin distinto en una de las dos filas antes de guardar.</div>`;
    }).join('');
  }

  // ¿Es función de paro (entrada digital con M581)? Se usa para inyectar la
  // columna NC/NO y el aviso legal obligatorio en la cabecera de la fila.
  function _isParoFn(fn) {
    return !!(fn && fn.paro && (fn.types || []).includes('input_digital'));
  }

  function _renderFila(fn, ass) {
    const tr = document.createElement('tr'); tr.dataset.slug = fn.id;
    tr.style.borderTop = '1px solid var(--border)';
    const tdN = document.createElement('td'); tdN.className = 'pad-4-8'; tdN.style.fontWeight = '600';
    tdN.textContent = fn.label[0]; tr.appendChild(tdN);
    const tdT = document.createElement('td'); tdT.className = 'pad-4-8';
    const sT = document.createElement('select'); sT.id = `mcfgPinesTipo_${fn.id}`;
    sT.style.cssText = 'min-width:140px;padding:4px 6px;background:var(--bg-input);color:var(--text);border:1px solid var(--border);border-radius:var(--r-sm)';
    const _tt = (k, es) => (typeof window !== 'undefined' && typeof window.t === 'function' ? window.t(k, es) : es);
    const LABELS = { output_digital: _tt('pins.type.outDigital', 'Salida on/off'), output_pwm: _tt('pins.type.outPwm', 'Salida PWM'), input_digital: _tt('pins.type.inDigital', 'Entrada digital') };
    for (const t of fn.types) { const o = document.createElement('option'); o.value = t; o.textContent = LABELS[t] || t; sT.appendChild(o); }
    sT.value = (ass && ass.type) || fn.defaultType;
    tdT.appendChild(sT); tr.appendChild(tdT);
    const tdP = document.createElement('td'); tdP.className = 'pad-4-8';
    const sP = document.createElement('select'); sP.id = `mcfgPinesPin_${fn.id}`;
    sP.style.cssText = 'min-width:240px;padding:4px 6px;background:var(--bg-input);color:var(--text);border:1px solid var(--border);border-radius:var(--r-sm)';
    const initialPin = (ass && ass.pin) || fn.defaultPin;
    const initialReason = initialPin && pinUseReason(sT.value, initialPin);
    sP.appendChild(_buildPinOptions(sT.value, initialPin));
    tdP.appendChild(sP); tr.appendChild(tdP);
    // Columna NC/NO — solo para entradas digitales. Default `inputNc` de la
    // función (1=NC) o de la persistencia (ass.nc). Default ES: NC.
    // El número del M950 J{n} se calcula en generateM950Lines; este campo
    // solo decide si el pin lleva `!` (NO) o no (NC).
    const tdNc = document.createElement('td'); tdNc.className = 'pad-4-8';
    if (_isParoFn(fn)) {
      const sNc = document.createElement('select'); sNc.id = `mcfgPinesNc_${fn.id}`;
      sNc.style.cssText = 'min-width:90px;padding:4px 6px;background:var(--bg-input);color:var(--text);border:1px solid var(--border);border-radius:var(--r-sm);font-weight:600';
      const oNc = document.createElement('option'); oNc.value = '1'; oNc.textContent = (typeof window !== 'undefined' && typeof window.t === 'function') ? window.t('pins.nc.safe', 'NC (seguro)') : 'NC (seguro)';
      const oNo = document.createElement('option'); oNo.value = '0'; oNo.textContent = 'NO';
      sNc.appendChild(oNc); sNc.appendChild(oNo);
      const wantNc = (ass && typeof ass.nc === 'number') ? ass.nc : (fn.inputNc ? 1 : 0);
      sNc.value = String(wantNc);
      tdNc.appendChild(sNc);
      // Indicador de estado del botón (lee sensors.gpIn[N]). Se actualiza
      // cada vez que llega un nuevo M409 desde la placa. Si gpIn[N] no
      // existe todavía (slot M950_BASE_J aún no declarado), muestra '—'.
      const tdSt = document.createElement('span'); tdSt.id = `mcfgPinesStatus_${fn.id}`;
      tdSt.style.cssText = 'margin-left:8px;font-size:11px;color:var(--text-3)';
      tdSt.textContent = 'estado —';
      tdNc.appendChild(tdSt);
    } else {
      tdNc.textContent = '—';
      tdNc.style.color = 'var(--text-3)';
    }
    tr.appendChild(tdNc);
    const tdB = document.createElement('td'); tdB.className = 'pad-4-8';
    const cB = document.createElement('input'); cB.type = 'checkbox'; cB.id = `mcfgPinesCockpit_${fn.id}`;
    cB.checked = !!(ass && ass.btn); cB.style.transform = 'scale(1.2)';
    tdB.appendChild(cB); tr.appendChild(tdB);
    const tdNote = document.createElement('td'); tdNote.className = 'pad-4-8';
    tdNote.style.cssText = 'font-size:11px;color:var(--text-3)';
    tdNote.id = `mcfgPinesNote_${fn.id}`; tr.appendChild(tdNote);
    if (initialReason) tdNote.dataset.pinUseReason = initialReason;
    function _draftWrite() {
      const ncEl = document.getElementById(`mcfgPinesNc_${fn.id}`);
      const nc = ncEl ? (ncEl.value === '1' ? 1 : 0) : 1;
      _draft[fn.id] = { type: sT.value, pin: sP.value, btn: cB.checked ? 1 : 0, nc };
    }
    function _wireNcListener() {
      const ncEl = document.getElementById(`mcfgPinesNc_${fn.id}`);
      if (ncEl) ncEl.addEventListener('change', () => { _draftWrite(); _refreshNote(fn, tdNote); _renderConflicts(); });
    }
    sT.addEventListener('change', () => {
      delete tdNote.dataset.pinUseReason;
      const prev = sP.value; sP.innerHTML = ''; sP.appendChild(_buildPinOptions(sT.value, prev));
      _wireNcListener();
      _draftWrite(); _refreshNote(fn, tdNote); _renderConflicts();
    });
    sP.addEventListener('change', () => {
      delete tdNote.dataset.pinUseReason;
      _draft[fn.id] = { type: sT.value, pin: sP.value, btn: cB.checked ? 1 : 0 };
      _refreshNote(fn, tdNote); _renderConflicts();
    });
    cB.addEventListener('change', () => {
      _draft[fn.id] = { type: sT.value, pin: sP.value, btn: cB.checked ? 1 : 0 };
    });
    _draft[fn.id] = { type: sT.value, pin: sP.value, btn: cB.checked ? 1 : 0 };
    sP.addEventListener('change', () => { _draftWrite(); _refreshNote(fn, tdNote); _renderConflicts(); });
    cB.addEventListener('change', () => { _draftWrite(); });
    _wireNcListener();
    _draftWrite();
    // _refreshNote(fn, tdNote) se ejecuta DESPUÉS desde populatePines, una
    // vez que el tr está en el DOM. Lo hacíamos aquí en el código viejo,
    // pero `_refreshNote` lee `document.getElementById` y al ejecutarse
    // antes del appendChild no encuentra los selects nuevos (devuelve
    // null → early return → textContent vacío). El bug quedó enmascarado
    // porque el código viejo serializaba `tmp.innerHTML` con un
    // `tdNote.textContent` ya escrito por el path de dataset.pinUseReason.
    // Con appendChild directo, los IDs únicos se pierden durante el
    // re-render y `_refreshNote` no puede leerlos hasta que el tr esté
    // montado (t_90db442e sep-2026).
    return tr;
  }

  function _renderCabecera() {
    return `<div class="mcfg-pin-card" style="margin-top:18px;border-left:3px solid var(--warn-strong)"><h4 class="mcfg-pin-heading" style="color:var(--warn-strong)">${LANG('cfg.pinesFn.title', '8. Pines libres — Funciones asignables')}</h4><p class="mcfg-pin-copy">${LANG('cfg.pinesFn.intro', 'Asigna un pin libre a una función operativa. Guarda en <code>config-machine.g</code>; <strong>REINICIA</strong> la placa después para que los nuevos M950 P/J tomen efecto.')}</p><div class="ib-orange mcfg-info-box" style="background:var(--warn-strong-soft);border:1px solid var(--warn-strong-edge);border-radius:var(--r-sm);padding:10px 12px;margin-bottom:12px;font-size:12px;line-height:1.55">${LANG('cfg.pinesFn.vmos', '<strong style="color:var(--warn-strong)">PENDIENTE BANCO · V-MOS vs lógica</strong><br><strong>A.4, A.5, A.6, A.7, C.4</strong> son SALIDAS DE POTENCIA que emiten V-MOS (24/36/48 V). <strong>NUNCA</strong> cargas de 5 V. <strong>B.7</strong> es entrada 5 V: para setas o accesorios lógicos.')}</div><div class="ib-red mcfg-info-box" style="background:#ff5c5c14;border:1px solid #ff5c5c66;border-radius:var(--r-sm);padding:10px 12px;margin-bottom:12px;font-size:12px;line-height:1.55">${LANG('cfg.pinesFn.paroSw', '<strong style="color:var(--red)">BOTÓN DE PARO LEÍDO POR SOFTWARE — NO es una parada de emergencia</strong><br>Un botón cableado a un pin y leído por el firmware <strong>NO</strong> corta la alimentación: si el firmware se cuelga, este botón <strong>NO</strong> hace nada. Esto es un botón de paro cómodo y rápido, y <strong>NO sustituye a la seta roja cableada en serie con la alimentación</strong>. La seta física de verdad es la única que te garantiza que la máquina se queda sin energía pase lo que pase.')}</div><table class="mcfg-pin-table"><thead><tr class="mcfg-txt-2">${LANG('cfg.pinesFn.cols', '<td class="pad-4-8">Función</td><td class="pad-4-8">Tipo</td><td class="pad-4-8">Pin</td><td class="pad-4-8">Mecánica / Estado</td><td class="pad-4-8">Botón cockpit</td><td class="pad-4-8">Aviso</td>')}</tr></thead><tbody>`;
  }

  function _renderPie() {
    return `</tbody></table><div id="mcfgPinesFuncionesConflicts" style="margin-top:10px"></div>`;
  }

  function populatePines(rawMachine) {
    const body = document.getElementById('mcfgPinesFuncionesBody');
    if (!body) return;
    _draft = {};
    const parsed = parseRotechPins(rawMachine || '');
    // Cabecera y pie son HTML puro (sin listeners), así que innerHTML es
    // seguro para ellos. Las filas se construyen en `_renderFila` con
    // listeners vivos sobre sT/sP/cB y se anexan con appendChild para
    // NO perderlos en la serialización (bug t_90db442e sep-2026).
    body.innerHTML = _renderCabecera();
    for (const fn of PINES_FUNCTIONS) {
      const tr = _renderFila(fn, parsed[fn.id] || null);
      // tbody es el contenedor natural de las filas; añadir al body
      // directamente también funciona pero tbody.querySelector dentro del
      // módulo asume ese anidamiento.
      const hostTbody = body.querySelector('tbody') || body;
      hostTbody.appendChild(tr);
      // _refreshNote se llama DESPUÉS del appendChild para que
      // `document.getElementById` encuentre los selects (necesario para
      // leer tEl/pEl). Antes se llamaba al final de `_renderFila` con el
      // tr aún detached y eso provocaba que la nota apareciese vacía al
      // re-render (la primera vez funcionaba por coincidencia del código
      // viejo que serializaba un tdNote ya escrito).
      const tdNote = tr.querySelector(`#mcfgPinesNote_${fn.id}`);
      if (tdNote) _refreshNote(fn, tdNote);
    }
    body.insertAdjacentHTML('beforeend', _renderPie());
    _renderConflicts();
  }

  // En la cola: otro escritor de config-machine.g en vuelo (un campo al vuelo,
  // el LED...) se pisaba en silencio con los dos diciendo «OK» (revision 26-sep).
  function savePines() { return window.cfgEnCola(_savePines); }
  async function _savePines() {
      if (typeof window.cfgMachineRead !== 'function') {
        (window.toast || console.log)('cfgMachineRead no disponible', 'err'); return false;
      }
      for (const fn of PINES_FUNCTIONS) {
        const sT = document.getElementById(`mcfgPinesTipo_${fn.id}`);
        const sP = document.getElementById(`mcfgPinesPin_${fn.id}`);
        const sNc = document.getElementById(`mcfgPinesNc_${fn.id}`);
        const cB = document.getElementById(`mcfgPinesCockpit_${fn.id}`);
        if (!sT || !sP || !cB) continue;
        const nc = sNc ? (sNc.value === '1' ? 1 : 0) : 1;
        _draft[fn.id] = { type: sT.value, pin: sP.value, btn: cB.checked ? 1 : 0, nc };
      }
      const v = sanityCheckAssignment(_draft);
      if (!v.ok) { (window.toast || console.log)(v.reason, 'err'); return false; }
      const raw = await window.cfgMachineRead();
      if (raw == null) return false;
      // Detectar cambio de pin en paro_externo para advertirlo en el toast.
      const was = (function () {
        const prev = (typeof parseRotechPins === 'function') ? parseRotechPins(raw)[ 'paro_externo' ] : null;
        return prev && prev.pin ? prev : null;
      })();
      const now = _draft['paro_externo'];
      const updated = applyPinsToContent(raw, _draft);
      const ok = await window.cfgMachineWrite(updated);
      if (!ok) return false;
      // E§3.1 (15-sep). Aqui habia un bloque que decia aplicar los M950 EN
      // CALIENTE tras guardar, y NUNCA se ejecuto: su guarda era
      // `typeof window.RRF`, y `RRF` es un `const` — let/const no crean
      // propiedad en el objeto global. (La linea de arriba usa
      // `window.cfgMachineWrite` y SI va, porque es una `function` top-level.)
      // NO se activa quitando el `window.`, y es decision, no olvido: mandaria
      // M950 en caliente por una ruta SIN guarda de estado, o sea que se podrian
      // reasignar pines —incluido `paro_externo`— con un trabajo en marcha. Sin
      // maquina no se toca. El toast de abajo ya dice que hay que reiniciar.
      // Anotado en el guion de banco.
      let pinMsg = '';
      if (now && now.pin) {
        if (was && was.pin && was.pin !== now.pin) pinMsg = ` (pin anterior ${was.pin} reemplazado)`;
        else if (!was) pinMsg = ` (nuevo paro_externo → ${now.pin}, ${now.nc ? 'NC' : 'NO'})`;
      }
      (window.toast || console.log)(LANG('msg.pinesFuncionesSaved', 'Asignación de pines guardada en config-machine.g. Recuerda reiniciar la Scylla para que los nuevos M950 P/J tomen efecto definitivamente.') + pinMsg, 'ok');
      (window.log || console.log)('Asignación de pines guardada en config-machine.g' + pinMsg, 'sys');
      populatePines(updated);
      return true;
    }

  // Estado del botón (HIGH / LOW), leído de sensors.gpIn[N] del M409 de la
  // placa. Se expone como `window.ROTECHOS_PINES_UI.refreshStatus()` para que
  // el poll loop principal lo invoque en cada nuevo paquete sin acoplar este
  // módulo al módulo de polling (cero cambios de import).
  function refreshStatus(model) {
    if (!model || !model.sensors || !Array.isArray(model.sensors.gpIn)) return;
    // El J{n} del paro_externo vive en gpIn[N=M950_BASE_J], pero queremos buscarlo
    // por slug → N. Sin un SSOT consultable buscamos el ÚNICO input_digital
    // activo (esperamos ≤1). Para no acoplar la UI al scheduler, este es
    // un barrido simple y barato (≤8 entradas en gpIn[]).
    const gp = model.sensors.gpIn;
    const slug = 'paro_externo';
    for (const fn of PINES_FUNCTIONS) {
      if (fn.id !== slug || !fn.paro) continue;
      const el = document.getElementById(`mcfgPinesStatus_${slug}`);
      if (!el) return;
      // Hallar el N: el módulo reserva slots desde M950_BASE_J por orden
      // de aparición. Como paro_externo es el único input_digital del catálogo
      // hoy, su número es M950_BASE_J. Si en el futuro se añaden más
      // entradas, esto será el sitio a cambiar (un Map slug→N cacheado).
      const N = M950_BASE_J;
      const gpEntry = gp[N];
      if (gpEntry == null || typeof gpEntry.value !== 'number') {
        el.textContent = 'estado —';
        el.style.color = 'var(--text-3)';
        return;
      }
      const v = gpEntry.value;
      // Para NC: lectura 0 = idle, 1 = pressed (o cable cortado).
      // Para NO con `!`: lectura 1 = idle, 0 = pressed.
      // Mostramos el estado físico del pin (sin invertir) para no mentir:
      // el operario debe ver el mismo nivel que tiene el cable, no el
      // resultado invertido del firmware.
      const texto = v === 1 ? 'HIGH (abierto)' : 'LOW (cerrado)';
      el.textContent = `estado pin: ${texto}`;
      el.style.color = v === 1 ? 'var(--red)' : 'var(--green)';
      return;
    }
  }

  window.ROTECHOS_PINES_UI = { populate: populatePines, save: savePines, refreshStatus, M950_BASE_J, M950_BASE_P };
})();