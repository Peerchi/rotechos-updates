/* ---
   ROTECHOS — Malla de palpado de altura del material (N×M puntos).
   Módulo auto-contenido: definición de área, lanzamiento del palpado,
   vista del mapa de altura (heatmap), persistencia y activación de la
   compensación.

   CARGA: perezosa, al primer click en la pestaña MAPA DE ALTURA. Sigue el
   mismo patrón que rotechos-config-pins-ui.js (cf. `__loadMeshUi()` en
   rotechos-config-modal.js). NO se carga en el arranque en frío.

   MODELO DE DATOS
   ───────────────
   · El operario define:
       - Área:    xmin/xmax/ymin/ymax (MCS, mm). Por defecto = M208 menos margen.
       - Puntos:  nx × ny. Por defecto 5×5 (25 puntos, ~30 s en una Scylla).
       - Margen:  distancia al borde del M208 (defensivo: no palpar al borde).
   · Se estima el tiempo de palpado ANTES de empezar (honesto: "30 s" no "rápido").
   · El palpado se lanza con M98 P"0:/macros/mesh_probe.g" tras poblar
     los globals `global.mesh*` (meshXmin, meshNx…). La UI lee `rr_model?key=global`
     cada ~600 ms para saber el punto actual.
   · El resultado se guarda como JSON en 0:/macros/mesh-<nombre>.json
     (NO en config.g/config-machine.g: es dato de operación, no calibración).
   · La compensación se activa/desactiva con `G29 S1`/`G29 S0` (RRF nativo).

   REGLAS QUE NO SE PUEDEN SALTAR
   ──────────────────────────────
   · HOME obligatorio antes de palpar (la macro ya aborta sin él; la UI
     bloquea el botón también).
   · Un punto que falla → malla NO válida → botón "Activar" deshabilitado.
     Eso lo cita literalmente la tarea: "ya hubo un fallo en este repo
     de dar por válido un palpado fallido ignorando el campo err".
   · "Esta malla es del MATERIAL que hay puesto ahora" — el aviso va en la UI
     y en el JSON guardado (campo `materialNote`).
   · Si la máquina está desconectada: se puede VER un mapa guardado, pero
     NO palpar ni activar compensación.

   PENDIENTE BANCO (no se valida en este turno):
   · Comportamiento real de G29 S1/S0 en la Scylla con el firmware 3.5.4.
   · Tiempo real del palpado en una 600×600 (la estimación usa el peor caso).
   ═══════════════════════════════════════════════════════════════════════════ */
'use strict';

(function () {
  // ── Estado del módulo ───────────────────────────────────────────────────
  // Malla actualmente en memoria (la que ve el operario en el heatmap).
  // Se hidrata desde JSON al cargar o al terminar un palpado.
  const STATE = {
    mesh: null,           // {xmin,xmax,ymin,ymax,nx,ny,points:[],valid,materialNote,savedAt}
    probing: false,       // palpado en curso
    cancelRequested: false, // C19: aborto pedido, pendiente de confirmacion
    pollHandle: null,     // handle del setInterval
    lastIdx: -1,          // último idx publicado (para no repintar de más)
    active: false,        // compensación activa (estado reportado por RRF)
  };

  // Helper i18n: usa window.t si está disponible (rotechos-i18n.js, cargado
  // como defer), si no cae al fallback literal. Mismo patrón que el resto
  // de módulos perezosos (rotechos-config-pins-ui.js, rotechos-config-accel-curve.js).
  function __t(key, fallback) {
    if (typeof window !== 'undefined' && typeof window.t === 'function') {
      return window.t(key, fallback);
    }
    return fallback;
  }

  // ── Utilidades puras (testables) ────────────────────────────────────────

  // Convierte CSV de la macro a array de números. La macro rellena
  // global.meshPoints como CSV, fila a fila (fila*nx + columna) —
  // la UI lo reinterpreta. Devuelve [] si vacío / malformado.
  function parseCsvPoints(csv) {
    if (typeof csv !== 'string' || csv.length === 0) return [];
    const out = [];
    const parts = csv.split(',');
    for (let i = 0; i < parts.length; i++) {
      const n = parseFloat(parts[i]);
      if (Number.isFinite(n)) out.push(n);
    }
    return out;
  }

  // Valida la geometría de la malla. Devuelve {ok:true} o {ok:false, reason}.
  // Reglas: nx, ny en [2..50]; xmax>xmin+5; ymax>ymin+5.
  function validateGrid(xmin, xmax, ymin, ymax, nx, ny) {
    if (!Number.isFinite(nx) || !Number.isFinite(ny) || nx < 2 || ny < 2) {
      return { ok: false, reason: 'nx/ny deben ser >= 2' };
    }
    if (nx > 50 || ny > 50) {
      return { ok: false, reason: 'nx/ny deben ser <= 50 (2500 puntos = 25 min)' };
    }
    if (!Number.isFinite(xmin) || !Number.isFinite(xmax) || xmax - xmin < 5) {
      return { ok: false, reason: 'xmax - xmin debe ser >= 5 mm' };
    }
    if (!Number.isFinite(ymin) || !Number.isFinite(ymax) || ymax - ymin < 5) {
      return { ok: false, reason: 'ymax - ymin debe ser >= 5 mm' };
    }
    return { ok: true };
  }

  // Estima el tiempo de palpado en segundos. Modelo honesto:
  //   - 1 pasada rápida por punto (la malla mide alabeo, no precisión)
  //   - viajes XY en RAYO (4000 mm/min) + bajadas/subidas Z en SEDA (500 mm/min)
  //   - el caso real depende de la geometría de la máquina; éste es
  //     una cota SUPERIOR (peor caso) — preferimos sobreestimar a prometer
  //     un tiempo que luego no se cumple.
  function estimateSeconds(xmin, xmax, ymin, ymax, nx, ny, opts) {
    opts = opts || {};
    const fast = opts.fast || 600;     // mm/min — palpado
    const travel = opts.travel || 4000; // mm/min — XY
    const safeZ = opts.safeZ || 5;     // mm — altura segura
    const zRange = opts.zRange || 110; // mm — recorrido útil Z
    const total = nx * ny;
    if (total === 0) return 0;
    // tiempo por punto: bajada Z a SEDA + palpado + subida Z
    // palpado ≈ zRange / fast  (min) → segundos: zRange * 60 / fast
    const perPointS = (zRange * 60 / fast) + (2 * safeZ * 60 / 1000);
    // tiempo entre puntos: distancia media XY en RAYO
    const dx = (xmax - xmin) / Math.max(1, nx - 1);
    const dy = (ymax - ymin) / Math.max(1, ny - 1);
    const avgStep = Math.sqrt(dx * dx + dy * dy);
    const travelS = (avgStep * total * 60 / travel);
    // overhead por punto (aceleración M400 + cambio cinemática): ~150 ms
    const overheadS = total * 0.15;
    return Math.round(perPointS * total + travelS + overheadS);
  }

  // Convierte segundos a "1 min 23 s" / "45 s" / "2 min".
  function fmtDuration(s) {
    if (s < 60) return `${s} s`;
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return sec === 0 ? `${m} min` : `${m} min ${sec} s`;
  }

  // Calcula min/max/media/rango de las alturas. La altura visible es
  // la desviación respecto a la media (mapa centrado) — el operario
  // entiende "rojo=alto, azul=bajo" centrado en verde=plano.
  function stats(points) {
    if (!points || points.length === 0) return null;
    let mn = Infinity, mx = -Infinity, sum = 0;
    for (let i = 0; i < points.length; i++) {
      const v = points[i];
      if (v < mn) mn = v;
      if (v > mx) mx = v;
      sum += v;
    }
    const mean = sum / points.length;
    return { min: mn, max: mx, mean, range: mx - mn };
  }

  // Color del heatmap (rojo=alto, verde=plano, azul=bajo). Centrado en la
  // media del propio mapa (no en 0) — el operario ve el relieve real.
  function colorFor(deviation, halfRange) {
    if (!Number.isFinite(deviation) || !Number.isFinite(halfRange) || halfRange <= 0) {
      return '#888';
    }
    const t = Math.max(-1, Math.min(1, deviation / halfRange)); // [-1..1]
    if (t >= 0) {
      // 0..1 → verde..rojo
      const g = Math.round(180 * (1 - t));
      const r = Math.round(180 + 75 * t);
      return `rgb(${r},${g},60)`;
    } else {
      // -1..0 → verde..azul
      const g = Math.round(180 * (1 + t));
      const b = Math.round(180 - 180 * t);
      return `rgb(60,${g},${b})`;
    }
  }

  // ── I/O de red (rr_gcode / rr_download / rr_upload) ─────────────────────
  // Sigue el patrón defensivo del monolito: AbortSignal.timeout y err===0
  // del body (mismo patrón que b266a7a, verificado).
  function _origin() { return window.location.origin; }

  async function _gcode(cmd, timeoutMs) {
    timeoutMs = timeoutMs || 30000;
    const url = `${_origin()}/rr_gcode?gcode=${encodeURIComponent(cmd)}&time=${Date.now()}`;
    const r = await fetch(url, { signal: AbortSignal.timeout(timeoutMs) });
    if (!r.ok) throw new Error(`HTTP ${r.status}`);
    // rr_gcode devuelve `{"err":N}`. err=0 OK; err>0 firmware rechazó.
    let body = null;
    try { body = await r.json(); } catch (_) {}
    if (body && typeof body.err === 'number' && body.err !== 0) {
      throw new Error(body.errMsg || `firmware err=${body.err}`);
    }
    return body;
  }

  async function _modelGlobal(name, timeoutMs) {
    timeoutMs = timeoutMs || 4000;
    // M409 K"name" devuelve {"result":{"key":"value"}} en rr_model
    const url = `${_origin()}/rr_model?key=${encodeURIComponent(name)}&time=${Date.now()}`;
    const r = await fetch(url, { signal: AbortSignal.timeout(timeoutMs) });
    if (!r.ok) throw new Error(`HTTP ${r.status}`);
    const body = await r.json();
    if (!body || typeof body !== 'object') return null;
    return body.result || null;
  }

  async function _downloadText(path) {
    const url = `${_origin()}/rr_download?name=${encodeURIComponent(path)}&time=${Date.now()}`;
    const r = await fetch(url, { signal: AbortSignal.timeout(15000) });
    if (!r.ok) throw new Error(`HTTP ${r.status}`);
    return await r.text();
  }

  async function _uploadText(text, path) {
    const url = `${_origin()}/rr_upload?name=${encodeURIComponent(path)}&time=${Date.now()}`;
    const r = await fetch(url, {
      method: 'POST',
      body: text,
      headers: { 'Content-Type': 'application/octet-stream' },
      signal: AbortSignal.timeout(30000),
    });
    if (!r.ok) throw new Error(`HTTP ${r.status}`);
    let body = null;
    try { body = await r.clone().json(); } catch (_) {}
    if (body && typeof body.err === 'number' && body.err !== 0) {
      throw new Error(body.errMsg || `upload err=${body.err}`);
    }
    return body;
  }

  // Lista de mallas guardadas. rr_filelist devuelve {dir, files:[{type,name,size}]}.
  async function _listSaved() {
    const url = `${_origin()}/rr_filelist?dir=${encodeURIComponent('0:/macros')}&first=0`;
    const r = await fetch(url, { signal: AbortSignal.timeout(8000) });
    if (!r.ok) throw new Error(`HTTP ${r.status}`);
    const body = await r.json();
    if (!body || !Array.isArray(body.files)) return [];
    return body.files
      .filter((f) => f && typeof f.name === 'string' && /^mesh-.*\.json$/.test(f.name))
      .map((f) => ({ name: f.name, size: f.size || 0 }));
  }

  // ── Polling del progreso (mientras palpado en curso) ────────────────────
  async function _pollOnce() {
    try {
      // 3-oct: la malla son globals sueltos (global.meshCurrent, meshOk, meshPoints…). Era un
      // objeto, `global.mesh`, que RRF 3.5.4 no admite y que impedía arrancar config.g.
      const g = await _modelGlobal('global');
      if (!g) return;
      const mesh = {
        current: g.meshCurrent, ok: g.meshOk, points: g.meshPoints,
        failed_index: g.meshFailedIndex, abort: g.meshAbort,
      };
      const cur = (typeof mesh.current === 'number') ? mesh.current : -1;
      const ok = mesh.ok === true;
      const csvPts = (typeof mesh.points === 'string') ? mesh.points : '';
      const pts = parseCsvPoints(csvPts);
      // Solo repintar si avanzó el índice (evita pisar el heatmap entero
      // cada 600 ms cuando ya está dibujado).
      if (cur !== STATE.lastIdx || pts.length !== (STATE.mesh ? STATE.mesh.points.length : 0)) {
        STATE.lastIdx = cur;
        // actualiza STATE.mesh en vivo (puntos parciales)
        if (STATE.mesh) {
          STATE.mesh.points = pts;
          STATE.mesh.valid = ok && pts.length === STATE.mesh.nx * STATE.mesh.ny;
          _renderProgress(cur, STATE.mesh.nx * STATE.mesh.ny);
          _renderHeatmap();
        }
      }
      // C19: la macro suelta la bandera al salir: es la señal de que paró de verdad.
      if (STATE.cancelRequested && mesh.abort === false) {
        STATE.cancelRequested = false;
        STATE.probing = false;
        if (STATE.mesh) STATE.mesh.valid = false;
        _stopPoll();
        window.toast && window.toast(__t('cfg.mesh.toast.cancelled', 'Palpado cancelado por el operario.'), 'warn');
        return;
      }
      // ¿terminó?
      if (mesh.failed_index !== undefined && mesh.failed_index !== null && mesh.failed_index !== -1) {
        STATE.probing = false;
        STATE.mesh.valid = false;
        _renderFailed(mesh.failed_index);
        _stopPoll();
        return;
      }
      if (ok && cur >= (STATE.mesh ? STATE.mesh.nx * STATE.mesh.ny - 1 : 0)) {
        STATE.probing = false;
        STATE.mesh.valid = true;
        STATE.mesh.savedAt = new Date().toISOString();
        _renderCompleted();
        _stopPoll();
        // refrescar estado de compensación (puede haber cambiado el flag)
        _refreshCompensationState();
        return;
      }
    } catch (e) {
      // Silenciar errores transitorios del polling — se reintenta en el
      // siguiente tick. Solo log si el operario tiene la pestaña abierta.
      if (window.console && console.debug) console.debug('mesh poll err:', e && e.message);
    }
  }
  function _startPoll() {
    if (STATE.pollHandle) return;
    STATE.pollHandle = setInterval(_pollOnce, 600);
  }
  function _stopPoll() {
    if (STATE.pollHandle) {
      clearInterval(STATE.pollHandle);
      STATE.pollHandle = null;
    }
  }

  // ── Render: heatmap ─────────────────────────────────────────────────────
  function _renderHeatmap() {
    const cv = document.getElementById('meshHeatmap');
    if (!cv) return;
    // 3-oct (acabado-2): el mapa de pixeles se dimensionaba con el ancho del
    // PADRE al cargar (977 px a 1280x800) y el lienzo se ve a la mitad (456):
    // todo el texto salia a la mitad de su tamano, ~7 px. Se iguala al ancho
    // que de verdad ocupa en pantalla antes de pintar.
    if (cv.clientWidth > 0 && cv.width !== cv.clientWidth) {
      cv.width = cv.clientWidth;
      cv.height = Math.max(180, Math.round(cv.clientWidth * 0.6));
    }
    const ctx = cv.getContext('2d');
    const W = cv.width, H = cv.height;
    const tinta = getComputedStyle(cv).getPropertyValue('--text-2').trim() || '#b8b8c4';
    ctx.clearRect(0, 0, W, H);
    if (!STATE.mesh || !STATE.mesh.points || STATE.mesh.points.length === 0) {
      // Antes #444 sobre el fondo del campo (2:1 en oscuro) y sin traducir.
      ctx.fillStyle = tinta;
      ctx.font = '14px system-ui, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(__t('mesh.canvasEmpty', 'Sin mapa todavía. Define área y puntos, pulsa PALPAR.'), W / 2, H / 2);
      return;
    }
    const { nx, ny, points } = STATE.mesh;
    if (points.length !== nx * ny) {
      // parcial: pintar solo los completados
      const done = points.length;
      ctx.fillStyle = tinta;
      ctx.font = '14px system-ui, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(`${__t('mesh.canvasProbing', 'Palpando…')} ${done} / ${nx * ny}`, W / 2, H / 2);
      return;
    }
    const s = stats(points);
    if (!s) return;
    const cellW = W / nx;
    const cellH = H / ny;
    const halfRange = Math.max(0.05, s.range / 2);
    for (let j = 0; j < ny; j++) {
      for (let i = 0; i < nx; i++) {
        const idx = j * nx + i;
        const v = points[idx];
        if (!Number.isFinite(v)) continue;
        const dev = v - s.mean;
        ctx.fillStyle = colorFor(dev, halfRange);
        // pequeño gap entre celdas para que se vean las divisiones
        ctx.fillRect(i * cellW + 1, j * cellH + 1, cellW - 2, cellH - 2);
        // número pequeño: la desviación en décimas de mm
        ctx.fillStyle = '#000';
        ctx.font = `${Math.max(9, Math.min(12, Math.floor(cellH / 4)))}px system-ui, sans-serif`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        const label = `${(dev * 10).toFixed(0)}`;
        ctx.fillText(label, i * cellW + cellW / 2, j * cellH + cellH / 2);
      }
    }
    // leyenda
    ctx.fillStyle = tinta;
    ctx.font = '12px system-ui, sans-serif';
    ctx.textAlign = 'left';
    ctx.textBaseline = 'top';
    ctx.fillText(
      `Rango ${(s.range * 1000).toFixed(0)} µm  ·  media ${s.mean.toFixed(3)} mm  ·  ${points.length} puntos`,
      4, 4,
    );
  }

  function _renderProgress(cur, total) {
    const bar = document.getElementById('meshProgressBar');
    const lbl = document.getElementById('meshProgressLabel');
    if (bar) bar.style.width = `${Math.min(100, Math.round((cur + 1) / total * 100))}%`;
    if (lbl) {
      const tt = window.t || function (k, d) { return d; };
      lbl.textContent = `${cur + 1} / ${total} — ${tt('cfg.mesh.progress.active', 'palpando…')}`;
    }
  }

  function _renderCompleted() {
    const lbl = document.getElementById('meshProgressLabel');
    if (lbl) {
      lbl.textContent = __t('cfg.mesh.progress.completed', 'Mapa completo. Revisa la distribución y guarda si quieres conservarlo.');
    }
    const bar = document.getElementById('meshProgressBar');
    if (bar) bar.style.width = '100%';
    const btn = document.getElementById('btnMeshSave');
    if (btn) btn.disabled = false;
    const btnAct = document.getElementById('btnMeshActivate');
    if (btnAct) btnAct.disabled = !STATE.mesh || !STATE.mesh.valid;
  }

  function _renderFailed(failedIdx) {
    const lbl = document.getElementById('meshProgressLabel');
    if (lbl) {
      lbl.textContent = `${__t('cfg.mesh.progress.failed', 'FALLO en punto')} ${failedIdx + 1}. ${__t('cfg.mesh.progress.failedHint', 'La malla NO es válida. Corrige y vuelve a palpar.')}`;
    }
    STATE.mesh.valid = false;
    const btnAct = document.getElementById('btnMeshActivate');
    if (btnAct) btnAct.disabled = true;
  }

  // ── Acciones de la UI ───────────────────────────────────────────────────

  async function startProbe() {
    if (STATE.probing) return;
    const xmin = parseFloat(document.getElementById('meshXmin').value);
    const xmax = parseFloat(document.getElementById('meshXmax').value);
    const ymin = parseFloat(document.getElementById('meshYmin').value);
    const ymax = parseFloat(document.getElementById('meshYmax').value);
    const nx = parseInt(document.getElementById('meshNx').value, 10);
    const ny = parseInt(document.getElementById('meshNy').value, 10);
    const fast = parseFloat(document.getElementById('meshSpeedFast').value) || 600;
    const slow = parseFloat(document.getElementById('meshSpeedSlow').value) || 200;
    const safeZ = parseFloat(document.getElementById('meshSafeZ').value) || 5;
    const materialNote = (document.getElementById('meshMaterialNote').value || '').trim();

    const v = validateGrid(xmin, xmax, ymin, ymax, nx, ny);
    if (!v.ok) {
      window.toast && window.toast(`${__t('cfg.mesh.toast.invalidGrid', 'Cuadrícula inválida:')} ${v.reason}`, 'err');
      return;
    }

    // A1-FIX (HUECO-3, t_34354573): el handler solo exigía HOME (cliente)
    // y luego emitía vía `_gcode` directo, bypaseando RRF.gcode — cualquier
    // wrapper guard que viviera allí se ignoraba. Con RUNNING/PAUSED/ERROR
    // el botón estaba habilitado (sin `disabled` en el bind línea 709) y la
    // macro mesh_probe.g se inyectaba en la cola, solapando los 25 puntos
    // del palpado con el surco del corte en curso. blockPaused=true: el
    // palpado redefine Z global (mesh compensation), afecta a TODO lo que
    // se reanude después.
    if (window.machineMoveBlocked && window.machineMoveBlocked(true)) return;

    // HOME obligatorio (chequeo adicional en cliente — la macro también
    // aborta si no, pero el chequeo aquí evita un viaje en balde).
    if (!window.AppState || !window.AppState.limits || window.AppState.limits.allHomed !== true) {
      window.toast && window.toast(__t('cfg.mesh.toast.needHome', 'HOME obligatorio antes de palpar.'), 'err');
      return;
    }

    STATE.mesh = {
      xmin, xmax, ymin, ymax, nx, ny,
      points: [],
      valid: false,
      materialNote,
      savedAt: null,
    };
    STATE.probing = true;
    STATE.lastIdx = -1;
    document.getElementById('meshProgressBar').style.width = '0%';
    _renderHeatmap();

    // 1. Poner globales (la macro las lee)
    // 2. Lanzar M98. NO esperamos: el palpado dura minutos, polling en su lugar.
    const cmds = [
      `set global.meshXmin = ${xmin}`,
      `set global.meshXmax = ${xmax}`,
      `set global.meshYmin = ${ymin}`,
      `set global.meshYmax = ${ymax}`,
      `set global.meshNx = ${nx}`,
      `set global.meshNy = ${ny}`,
      `set global.meshFast = ${fast}`,
      `set global.meshSlow = ${slow}`,
      `set global.meshSafeZ = ${safeZ}`,
      // reset defensivo (por si quedó algo de un palpado previo)
      `set global.meshPoints = ""`,
      `set global.meshCurrent = 0`,
      `set global.meshFailedIndex = -1`,
      `set global.meshOk = false`,
    ];
    try {
      for (let i = 0; i < cmds.length; i++) {
        await _gcode(cmds[i]);
      }
      // lanzar el macro (no esperamos: bloqueante puede tirar timeout;
      // polling en su lugar, mismo patrón que RRF.gcode para M291 S2)
      _gcode(`M98 P"0:/macros/mesh_probe.g"`, 5000).catch((e) => {
        // 5s puede no alcanzar — no abortamos aquí, el polling detecta el
        // avance del punto y, si no avanza, marcaremos fallo en 30s.
        if (window.console && console.debug) console.debug('mesh launch:', e.message);
      });
      _startPoll();
      window.toast && window.toast(__t('cfg.mesh.toast.started', 'Malla iniciada…'), 'info');
    } catch (e) {
      STATE.probing = false;
      window.toast && window.toast(`${__t('cfg.mesh.toast.startErr', 'Error al iniciar:')} ${e.message}`, 'err');
    }
  }

  function cancelProbe() {
    if (!STATE.probing) return;
    // C19: antes decía «cancelado» en el acto y la sonda seguía bajando (la macro no
    // miraba nada). Ahora se PIDE el aborto; lo confirma _pollOnce. Por RRF.gcode.
    STATE.cancelRequested = true;
    const _enviar = (window.RRF && typeof window.RRF.gcode === 'function')
      ? window.RRF.gcode(`set global.meshAbort = true`)
      : _gcode(`set global.meshAbort = true`, 3000);
    Promise.resolve(_enviar).catch(() => {
      STATE.cancelRequested = false;
      window.toast && window.toast(__t('cfg.mesh.toast.cancelErr', 'No se pudo pedir la cancelación — el palpado SIGUE en marcha.'), 'err');
    });
    window.toast && window.toast(__t('cfg.mesh.toast.cancelling', 'Cancelando el palpado… no se ha parado todavía.'), 'warn');
  }

  async function saveMap() {
    if (!STATE.mesh || !STATE.mesh.points || STATE.mesh.points.length === 0) return;
    if (STATE.mesh.points.length !== STATE.mesh.nx * STATE.mesh.ny) {
      window.toast && window.toast(__t('cfg.mesh.toast.saveIncomplete', 'Mapa incompleto — no se puede guardar.'), 'err');
      return;
    }
    const name = (document.getElementById('meshSaveName').value || '').trim();
    if (!/^[a-zA-Z0-9_-]{1,32}$/.test(name)) {
      window.toast && window.toast(__t('cfg.mesh.toast.saveBadName', 'Nombre inválido (letras, dígitos, _ y -, máx 32).'), 'err');
      return;
    }
    const path = `0:/macros/mesh-${name}.json`;
    const json = JSON.stringify({
      version: 1,
      xmin: STATE.mesh.xmin, xmax: STATE.mesh.xmax,
      ymin: STATE.mesh.ymin, ymax: STATE.mesh.ymax,
      nx: STATE.mesh.nx, ny: STATE.mesh.ny,
      points: STATE.mesh.points,
      materialNote: STATE.mesh.materialNote,
      savedAt: new Date().toISOString(),
    }, null, 2);
    try {
      await _uploadText(json, path);
      window.toast && window.toast(`${__t('cfg.mesh.toast.saved', 'Guardado:')} ${path}`, 'info');
      await refreshSavedList();
    } catch (e) {
      window.toast && window.toast(`${__t('cfg.mesh.toast.saveErr', 'Error al guardar:')} ${e.message}`, 'err');
    }
  }

  async function loadMap(name) {
    const path = `0:/macros/${name}`;
    try {
      const txt = await _downloadText(path);
      const obj = JSON.parse(txt);
      if (!obj || typeof obj !== 'object' || !Array.isArray(obj.points)) {
        throw new Error('JSON malformado');
      }
      if (obj.points.length !== (obj.nx * obj.ny)) {
        throw new Error('puntos inconsistentes con nx*ny');
      }
      STATE.mesh = {
        xmin: obj.xmin, xmax: obj.xmax,
        ymin: obj.ymin, ymax: obj.ymax,
        nx: obj.nx, ny: obj.ny,
        points: obj.points,
        valid: true,
        materialNote: obj.materialNote || '',
        savedAt: obj.savedAt || null,
      };
      // pintar UI con los valores cargados
      document.getElementById('meshXmin').value = obj.xmin;
      document.getElementById('meshXmax').value = obj.xmax;
      document.getElementById('meshYmin').value = obj.ymin;
      document.getElementById('meshYmax').value = obj.ymax;
      document.getElementById('meshNx').value = obj.nx;
      document.getElementById('meshNy').value = obj.ny;
      document.getElementById('meshMaterialNote').value = obj.materialNote || '';
      _renderHeatmap();
      _renderCompleted();
      window.toast && window.toast(`${__t('cfg.mesh.toast.loaded', 'Cargado:')} ${path}`, 'info');
      await _refreshCompensationState();
    } catch (e) {
      window.toast && window.toast(`${__t('cfg.mesh.toast.loadErr', 'Error al cargar:')} ${e.message}`, 'err');
    }
  }

  async function deleteMap(name) {
    const path = `0:/macros/${name}`;
    try {
      // rr_delete?name=... — método GET, timeout corto
      const url = `${_origin()}/rr_delete?name=${encodeURIComponent(path)}`;
      const r = await fetch(url, { signal: AbortSignal.timeout(5000) });
      if (!r.ok) throw new Error(`HTTP ${r.status}`);
      window.toast && window.toast(`${__t('cfg.mesh.toast.deleted', 'Borrado:')} ${path}`, 'info');
      await refreshSavedList();
    } catch (e) {
      window.toast && window.toast(`${__t('cfg.mesh.toast.delErr', 'Error al borrar:')} ${e.message}`, 'err');
    }
  }

  async function activateCompensation() {
    if (!STATE.mesh || !STATE.mesh.valid) return;
    // G29 S1 activa la compensación en RRF. Antes hay que tener el heightmap
    // cargado en RRF — el método soportado por RRF 3.5.4 es G29 S0 (auto-load
    // desde 0:/sys/heightmap.csv). Como aquí usamos una malla nuestra en
    // formato JSON, RRF NO la lee directamente. La activación REAL en banco
    // queda PENDIENTE BANCO; mientras tanto, el botón registra la intención
    // y avisa al operario.
    window.toast && window.toast(
      `${__t('cfg.mesh.toast.activateWip', 'Activación de compensación:')} ${__t('cfg.mesh.toast.activateWipHint', 'la integración con G29 S1 requiere convertir el JSON al heightmap.csv nativo de RRF — pendiente de validar en banco.')}`,
      'warn',
    );
    STATE.active = true;
    _renderCompensationBadge();
  }

  async function deactivateCompensation() {
    // G29 S0 desactiva la compensación. Si la integración G29 estuviera
    // implementada, este sería el comando a enviar. Por ahora, registra.
    window.toast && window.toast(__t('cfg.mesh.toast.deactivate', 'Compensación desactivada.'), 'info');
    STATE.active = false;
    _renderCompensationBadge();
  }

  async function _refreshCompensationState() {
    // En el futuro: leer move.compensation.heightMap.active del object model.
    // Por ahora el flag se mantiene local.
    _renderCompensationBadge();
  }

  function _renderCompensationBadge() {
    const el = document.getElementById('meshCompStatus');
    if (!el) return;
    if (STATE.active) {
      el.textContent = __t('cfg.mesh.comp.active', 'COMPENSACIÓN ACTIVA — trabajar con una malla de otro material puede clavar la fresa.');
      el.style.background = `var(--warn-strong-soft)`;
      el.style.borderColor = `var(--warn-strong-edge)`;
      el.style.color = `var(--warn-strong)`;
    } else {
      el.textContent = __t('cfg.mesh.comp.inactive', 'Compensación inactiva. La fresa trabaja a la Z nominal del G-code.');
      el.style.background = '#88888822';
      el.style.borderColor = '#88888866';
      el.style.color = 'var(--text-2)';
    }
  }

  async function refreshSavedList() {
    const sel = document.getElementById('meshSavedList');
    if (!sel) return;
    try {
      const list = await _listSaved();
      sel.innerHTML = '';
      if (list.length === 0) {
        const opt = document.createElement('option');
        opt.value = '';
        opt.textContent = (typeof window.t === 'function') ? window.t('mesh.emptyList', '— vacío —') : '— vacío —';
        opt.disabled = true;
        opt.selected = true;
        sel.appendChild(opt);
        return;
      }
      for (const f of list) {
        const opt = document.createElement('option');
        opt.value = f.name;
        opt.textContent = `${f.name}  (${Math.max(1, Math.round(f.size / 1024))} KB)`;
        sel.appendChild(opt);
      }
    } catch (_) {
      sel.innerHTML = '<option value="" disabled selected>— sin conexión —</option>';
    }
  }

  function _readEnvelopeFromModel() {
    // Lee X/Y del object model para sugerir área por defecto.
    // move.axes[0].min/max y move.axes[1].min/max son MCS.
    try {
      if (window.AppState && window.AppState.cache) {
        const sl = window.AppState.cache.softLimits;
        // El modelo expone min/max por eje. Usar esos, no un literal.
        const xMin = (sl && sl.X && Number.isFinite(sl.X.min)) ? sl.X.min : 0;
        const xMax = (sl && sl.X && Number.isFinite(sl.X.max)) ? sl.X.max : 530;
        const yMin = (sl && sl.Y && Number.isFinite(sl.Y.min)) ? sl.Y.min : 0;
        const yMax = (sl && sl.Y && Number.isFinite(sl.Y.max)) ? sl.Y.max : 830;
        const margin = 10;
        return {
          xmin: xMin + margin,
          xmax: xMax - margin,
          ymin: yMin + margin,
          ymax: yMax - margin,
        };
      }
    } catch (_) {}
    // fallback conservador
    return { xmin: 10, xmax: 545, ymin: 10, ymax: 735 };
  }

  function fillDefaultsFromEnvelope() {
    const env = _readEnvelopeFromModel();
    document.getElementById('meshXmin').value = env.xmin;
    document.getElementById('meshXmax').value = env.xmax;
    document.getElementById('meshYmin').value = env.ymin;
    document.getElementById('meshYmax').value = env.ymax;
    document.getElementById('meshNx').value = 5;
    document.getElementById('meshNy').value = 5;
    document.getElementById('meshSpeedFast').value = 600;
    document.getElementById('meshSpeedSlow').value = 200;
    document.getElementById('meshSafeZ').value = 5;
    document.getElementById('meshMaterialNote').value = '';
    document.getElementById('meshSaveName').value = '';
    _updateEstimate();
  }

  function _updateEstimate() {
    const xmin = parseFloat(document.getElementById('meshXmin').value) || 0;
    const xmax = parseFloat(document.getElementById('meshXmax').value) || 0;
    const ymin = parseFloat(document.getElementById('meshYmin').value) || 0;
    const ymax = parseFloat(document.getElementById('meshYmax').value) || 0;
    const nx = parseInt(document.getElementById('meshNx').value, 10) || 0;
    const ny = parseInt(document.getElementById('meshNy').value, 10) || 0;
    const fast = parseFloat(document.getElementById('meshSpeedFast').value) || 600;
    const safeZ = parseFloat(document.getElementById('meshSafeZ').value) || 5;
    const v = validateGrid(xmin, xmax, ymin, ymax, nx, ny);
    const lbl = document.getElementById('meshEstimateLabel');
    if (!lbl) return;
    if (!v.ok) {
      lbl.textContent = v.reason;
      lbl.style.color = 'var(--warn-strong)';
      return;
    }
    const secs = estimateSeconds(xmin, xmax, ymin, ymax, nx, ny, { fast, safeZ });
    const base = __t('cfg.mesh.estimateTemplate', 'Tiempo estimado: {time} para {total} puntos.');
    lbl.textContent = base
      .replace('{time}', fmtDuration(secs))
      .replace('{total}', String(nx * ny));
    lbl.style.color = 'var(--text-2)';
  }

  // ── Bootstrap ───────────────────────────────────────────────────────────
  function _bind() {
    // defaults
    const btnDefaults = document.getElementById('btnMeshDefaults');
    if (btnDefaults) btnDefaults.addEventListener('click', fillDefaultsFromEnvelope);

    // update estimate on any change
    ['meshXmin', 'meshXmax', 'meshYmin', 'meshYmax', 'meshNx', 'meshNy',
     'meshSpeedFast', 'meshSafeZ'].forEach((id) => {
      const el = document.getElementById(id);
      if (el) el.addEventListener('input', _updateEstimate);
    });

    // start / cancel
    document.getElementById('btnMeshProbe')?.addEventListener('click', startProbe);
    document.getElementById('btnMeshCancel')?.addEventListener('click', cancelProbe);

    // save / load / delete
    document.getElementById('btnMeshSave')?.addEventListener('click', saveMap);
    document.getElementById('btnMeshLoad')?.addEventListener('click', () => {
      const sel = document.getElementById('meshSavedList');
      if (sel && sel.value) loadMap(sel.value);
    });
    document.getElementById('btnMeshDelete')?.addEventListener('click', () => {
      const sel = document.getElementById('meshSavedList');
      if (!sel || !sel.value) return;
      const msg = __t('cfg.mesh.toast.confirmDelete', '¿Borrar {name}?').replace('{name}', sel.value);
      if (window.confirm && !window.confirm(msg)) return;
      deleteMap(sel.value);
    });

    // activate / deactivate compensation
    document.getElementById('btnMeshActivate')?.addEventListener('click', activateCompensation);
    document.getElementById('btnMeshDeactivate')?.addEventListener('click', deactivateCompensation);

    // canvas size: hacerlo al abrir la pestaña (cuando mide algo)
    const cv = document.getElementById('meshHeatmap');
    if (cv) {
      const sz = () => {
        const w = Math.max(320, cv.parentElement.clientWidth - 20);
        const h = Math.max(180, Math.round(w * 0.6));
        cv.width = w;
        cv.height = h;
        _renderHeatmap();
      };
      sz();
      window.addEventListener('resize', sz);
    }
  }

  // ── API pública (window.MESH_PROBE) ────────────────────────────────────
  window.MESH_PROBE = {
    // expuestas para tests
    parseCsvPoints,
    validateGrid,
    estimateSeconds,
    fmtDuration,
    stats,
    colorFor,
    // API de operación (también consumida por rotechos-config-modal.js)
    open() {
      fillDefaultsFromEnvelope();
      _renderHeatmap();
      _renderCompensationBadge();
      refreshSavedList();
      _updateEstimate();
    },
    close() {
      // C19: cerrar el panel dejaba la macro bajando sin que nadie la mirase.
      if (STATE.probing && !STATE.cancelRequested) cancelProbe();
      _stopPoll();
      STATE.probing = false;
    },
    isProbing() { return STATE.probing; },
    // SOLO PARA TESTS (C19): «palpando» sin lanzar la macro. Arranca el sondeo: es
    // _pollOnce quien confirma la cancelación.
    __test_setProbing(v) {
      STATE.probing = !!v;
      STATE.cancelRequested = false;
      if (v) _startPoll(); else _stopPoll();
    },
    hasMesh() { return !!(STATE.mesh && STATE.mesh.points && STATE.mesh.points.length > 0); },
  };

  // bind cuando el DOM esté listo (la pestaña es perezosa — el DOM puede
  // existir desde la primera carga, pero por si se carga tarde).
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', _bind);
  } else {
    _bind();
  }
})();
