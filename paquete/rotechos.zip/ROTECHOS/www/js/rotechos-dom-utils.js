/* ---
 * rotechos-dom-utils.js — Utilidades de DOM: escapado de HTML + persistencia
 * del tema claro/oscuro.
 *
 * Extraído del monolito (rotechos.js) en el sprint de reducción jul-2026
 * (bloque 7, líneas 522-544 del snapshot base 286b5d9, RANK 2, 20 líneas,
 *  riesgo 1).  Cubre dos responsabilidades que viajan juntas:
 *
 *   1. `escHtml(str)`  —  escapado de HTML para innerHTML.  CÓDIGO DE
 *      SEGURIDAD: previene XSS en datos del operario o del firmware que
 *      se inyectan al DOM.  NO MODIFICAR esta función sin una auditoría
 *      específica y un test que cubra el cambio.  El fixture
 *      `tests/unit/escHtml.test.js` cubre los 5 caracteres peligrosos,
 *      los edge cases (null/undefined/empty) y tres payloads XSS típicos.
 *
 *   2. El IIFE de tema (STORE.get('ui.theme') → data-theme + icoLuna/icoSol)
 *      que aplica la preferencia persistida ANTES del primer paint para
 *      que la UI no parpadee al cambiar de tema en caliente.  Vive aquí
 *      porque depende de STORE (rotechos-storage.js) y $ (rotechos.js);
 *      por tanto el módulo se carga DESPUÉS de ambos.
 *
 * IMPORTANTE — Compatibilidad con el código existente:
 *   - `escHtml` queda accesible vía `window.escHtml`.  Misma firma, mismo
 *     comportamiento.  Los 28 call-sites del monolito y de los defer modules
 *     (rotechos-macros, rotechos-fm, rotechos-pendant, rotechos-viz,
 *      rotechos-backup, rotechos-modules, rotechos-file-ops, etc.) siguen
 *      llamándola con el mismo nombre y obtienen el mismo resultado.
 *   - NO se re-declaran `$` ni `$$` (rotechos-dom.js ya los provee;
 *     redeclarar en un nuevo <script> lanzaría `SyntaxError: Identifier
 *     '$' has already been declared`).
 *
 * Dependencias globales (cargadas ANTES de este módulo en index.html):
 *   - $        (rotechos.js,        alias de document.getElementById)
 *   - STORE    (rotechos-storage.js, wrapper de localStorage)
 *   - document (navegador)
 *
 * Este módulo ES DEFENSIVO: si $ o STORE no existen (p.ej. tests
 * unitarios que lo cargan aisladamente), `applyStoredTheme` no rompe y
 * `escHtml` se define de todos modos para que la función pura sea
 * testeable.
 * --- */
(function () {
  'use strict';

  // ---
  // escHtml(str) — escapado de HTML (CÓDIGO DE SEGURIDAD).
  //
  // Reemplaza los 5 caracteres que pueden romper el contexto HTML o de
  // atributo:
  //   &  →  &amp;     (debe ir PRIMERO: si fuera al final, las otras
  //                    sustituciones crearían & extra que se duplicarían)
  //   <  →  &lt;      (apertura de tag)
  //   >  →  &gt;      (cierre de tag)
  //   "  →  &quot;    (cierre de atributo entrecomillado con ")
  //   '  →  &#39;     (cierre de atributo entrecomillado con ')
  //
  // null / undefined se tratan como string vacío (no lanzan).
  //
  // Test: tests/unit/escHtml.test.js (16 tests, incluye regresión XSS).
  // ---
  function escHtml(str) {
    return String(str ?? ``)
      .replace(/&/g, `&amp;`)
      .replace(/</g, `&lt;`)
      .replace(/>/g, `&gt;`)
      .replace(/"/g, `&quot;`)
      .replace(/'/g, `&#39;`);
  }

  // Exposición como global. NO pisar si ya existía (defensa por si el
  // shell todavía la publica durante una transición).
  if (typeof window.escHtml === 'undefined') {
    window.escHtml = escHtml;
  }

  // ---
  // escGcodeArg(str) — D-02 (15-sep). Saneo del texto libre que se interpola
  // entre comillas en una plantilla de G-code (M550 P"…", M587 S"…" P"…").
  // Los call-sites hacian solo `.replace(/"/g,'')`: eso cierra la comilla, pero
  // NO el salto de linea, y `rr_gcode` separa por saltos — un
  // \n en el SSID o en la contrasena convierte el resto en una SEGUNDA orden
  // para la maquina. Hoy el vector por teclado esta cerrado porque un
  // <input> de una linea descarta CR/LF por spec HTML; esto cubre el pegado
  // raro, un bug de navegador y la asignacion programatica de .value.
  // Se quitan los caracteres de CONTROL, no los acentuados: un nombre de
  // maquina con ñ o con acento debe llegar entero.
  // 5-oct: comillas dobladas, no quitadas (StringParser.cpp:1498-1516).
  // Test: tests/unit/gcode-arg-inyeccion.test.js.
  // ---
  function escGcodeArg(str) {
    // eslint-disable-next-line no-control-regex -- el punto del saneo es justo ese rango
    return String(str ?? ``).replace(/[\x00-\x1F\x7F]/g, ``).replace(/"/g, `""`).replace(/'/g, `''`);
  }
  if (typeof window.escGcodeArg === 'undefined') {
    window.escGcodeArg = escGcodeArg;
  }

  // ---
  // applyStoredTheme() — aplica el tema persistido al cargar la página.
  //
  // Se ejecuta al evaluar este módulo (IIFE), ANTES del primer paint, para
  // que el atributo `data-theme` del <html> y los iconos icoLuna/icoSol
  // reflejen la preferencia del operario sin parpadeo.
  //
  // El toggle en tiempo de ejecución (botón btnTheme) vive en el shell
  // (rotechos.js:3000-3013) y sigue siendo responsable de:
  //   - invertir el tema en data-theme,
  //   - conmutar icoLuna/icoSol,
  //   - sincronizar <meta name="theme-color"> (A-4 jul-2026),
  //   - STORE.set('ui.theme', newTheme) para persistir el cambio.
  // Esta función SOLO aplica la persistencia AL CARGAR; no duplica el
  // handler de btnTheme.
  // ---
  function applyStoredTheme() {
    if (typeof STORE === 'undefined') return;        // tests sin STORE: no-op
    if (typeof document === 'undefined') return;     // Node: no-op
    if (typeof $ !== 'function') return;             // shell no cargó: no-op
    const saved = STORE.get(`ui.theme`);
    if (saved === `light` || saved === `dark`) {
      document.documentElement.dataset.theme = saved;
      const luna = $(`icoLuna`),
        sol = $(`icoSol`);
      luna &&
        sol &&
        // display EXPLICITO: #icoLuna lleva la clase `telem-value`
        // (display:none) y la cadena vacia no la vence — el boton de tema
        // quedaba en blanco al restaurar tema claro. Ver rotechos.js:3434.
        ((luna.style.display = saved === `light` ? `block` : `none`),
        (sol.style.display = saved === `dark` ? `block` : `none`));
      // A-4 (audit 2026-07-20): replicar la sincronización de <meta name=theme-color>
      // que hace el handler de btnTheme (rotechos.js:2835-2840) para que la
      // barra del navegador NO quede oscura durante ~1 frame al recargar en
      // tema claro. Sin esto, el meta estático en <head> (#121215) gana al
      // primer paint, y el toggle en tiempo de ejecución ya nunca lo ve.
      document.querySelector(`meta[name="theme-color"]`)?.setAttribute(`content`,
        saved === `light` ? `#f0ede4` : `#121215`);
    }
  }
  applyStoredTheme();
})();

// 5-oct: AbortSignal.any/timeout para Safari < 17.4.
if (typeof AbortSignal !== `undefined`) {
  AbortSignal.timeout ||= (ms) => { const c = new AbortController(); setTimeout(() => c.abort(new DOMException(`Timeout`, `TimeoutError`)), ms); return c.signal; };
  AbortSignal.any ||= (ss) => {
    const c = new AbortController();
    for (const s of ss) { if (s.aborted) { c.abort(s.reason); break; } s.addEventListener(`abort`, () => c.abort(s.reason), { once: true }); }
    return c.signal;
  };
}
