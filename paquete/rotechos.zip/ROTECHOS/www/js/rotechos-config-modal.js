// ---
// rotechos-config-modal.js — MODAL CONFIGURACIÓN DE MÁQUINA (CFG) — PEREZOSO
// ---
// CFG_FIELDS, CFG_AXIS_GROUPS, CFG_GPIO_MAP, HW_LIMITS + hwCheck, cfgPopulate,
// loadPersistentUiConfig, openMachineConfig y el guardado por pestaña.
//
// PEREZOSO (t_b8cd40c2): lo carga `__loadConfigModal()` al primer uso. El shim EAGER
// `rotechos-config-modal-core.js` expone antes lo que el arranque lee sin abrir el modal
// (window._endstopCfg, parseRotechPills, CFG_FIELDS con mcfgSacSensorZ para ZCAL); aquí
// `const X = window.X` mantiene los nombres sin duplicar la fuente de verdad.
// Extraídos (carga al primer uso): accel-curve, pins-ui, search, tools-table,
// facing-wizard, homing-maint.
//
// ⚠️ SEGURIDAD: ESCRIBE config.g/config-machine.g y envía M-codes en caliente
// (M92/M208/M906...). No tocar sin banco. HW_LIMITS = único sitio a editar
// si cambia el hardware.
// Tests por regex: tests/unit/{hw-check,parse-rotech-pills,apply-m92-m208-instant,accel-curve}.test.js.
// ---
/* exported openMachineConfig, cfgPopulate, loadPersistentUiConfig, HW_LIMITS, hwCheck, CFG_FIELDS, _endstopCfg */
let _motorsNeedReboot = !1;
let _motorsDidDualWrite = !1;  // Bloque 1 jul-2026: dual-write de motores (config.g + config-machine.g) evita la cola final
// _endstopCfg y AppState.cache.endstopCfg viven en el shim core
// (rotechos-config-modal-core.js). Aquí solo referenciamos: el modal MUTA el
// MISMO objeto al procesar `; rotech-pills=` y la pestaña Endstops, y el poll
// lo ve desde el primer tick porque apunta al mismo objeto.
// Ver `tests/unit/parse-rotech-pills.test.js` para el contrato de igualdad
// entre la entrada del shim y la del modal (el modal no redefine, comparte).
const _endstopCfg = window._endstopCfg;
// Idem para el parser único del SSOT de endstops (misma justificación).
// En producción window.parseRotechPills lo publica el shim core (cargado
// eager en index.html); en tests lo inyecta el factory que evalúa este
// módulo concatenando SOURCE_CORE antes de SOURCE_MODAL.
// El modal solo aporta thin-wrappers para mantener el contrato interno del
// fichero (los identificadores `_endstopCfg` y `parseRotechPills` siguen
// accesibles por nombre dentro del módulo).
function parseRotechPills(raw) {
  return window.parseRotechPills(raw);
}

// Barrera T-2 (t_ecea8ad1): desactivar la red de seguridad por accidente BORRA
// la calibración del cliente. Esta helper centraliza el toast de fail-closed
// para los 6 puntos del fichero que la invocan (5 aquí + 1 en cfgApplyPin).
function _abortConfigMachineNotLoaded() {
  toast(
    t(`msg.configMaquinaNoLeida`, `No se pudo leer config-machine.g — no se guarda para no borrar la calibración`),
    `err`,
  );
  return false;
}

// ---
// CFG_GPIO_MAP — Mapeo eje ↔ pines/GPIOs/triggers físicos (BTT Scylla V1.0)
// ---
// Pinout verificado:
//   X: D.11 (X-MIN → J5, trig 5) + C.6  (X-MAX → J4, trig 4, NPN inductivo activo)
//   Y: A.8  (Y-MIN → J0, trig 0) + D.14 (Y-MAX → J1, trig 1)
//   Z: C.7  (Z-MIN → J2, trig 2) + D.12 (Z-MAX → J3, trig 3)
//   A: sin sensor físico (no mapeado)
//
// Usado por:
//   - homeall.g (save tab `homing`): unbinding trick — libera/restaura GPIO+M581
//     alrededor del M574 temporal para evitar conflicto "pin not free".
//   - cualquier consumidor futuro que necesite traducir eje ↔ pin.
//
// Estos M950 J / M581 están como configuración estática en config.g; no se
// reescriben desde la UI (no hay campos editables para ellos). Esta tabla
// es la fuente única de verdad sobre el cableado físico.
const CFG_GPIO_MAP = {
  X: { jMin: 5, jMax: 4, pinMin: 'D.11', pinMax: 'C.6',  triggers: [4, 5] },
  Y: { jMin: 0, jMax: 1, pinMin: 'A.8',  pinMax: 'D.14', triggers: [0, 1] },
  Z: { jMin: 2, jMax: 3, pinMin: 'C.7',  pinMax: 'D.12', triggers: [2, 3] },
};

/**
 * Detector de conflicto de pin para la sonda Z (t_9b49c0a4).
 *
 * Si el pin que el operario mete en M558 C"…" coincide con un pin ya usado por
 * un endstop en CFG_GPIO_MAP, el firmware abortará al rearrancar con
 * "pin not free" — el M950 J-n / M581 del endstop tiene la propiedad del pin.
 * Devuelve un string con el NOMBRE de la función que lo reclama (no el pin
 * literal), o null si no hay conflicto.
 *
 * No comprobamos conflicto con `; rotech-pins=` (la UI de CONTROLADORA) — eso
 * es asignación de pines libres y la sonda DEBE tener prioridad si la quiere.
 * El operario verá el conflicto al rearrancar (RRF es la autoridad final).
 */
function _probePinConflict(pin) {
  if (!pin || typeof pin !== 'string') return null;
  const norm = pin.trim().toUpperCase();
  for (const ax of ['X', 'Y', 'Z']) {
    const m = CFG_GPIO_MAP[ax];
    if (!m) continue;
    if (m.pinMin && m.pinMin.toUpperCase() === norm) return `endstop ${ax} MIN (${m.pinMin})`;
    if (m.pinMax && m.pinMax.toUpperCase() === norm) return `endstop ${ax} MAX (${m.pinMax})`;
  }
  return null;
}

// ---
// CFG_FIELDS — Tabla declarativa de campos de configuración
// ---
//
// Cada entrada describe TODO sobre un campo de la UI: cómo leerlo de config.g,
// cómo escribirlo, cómo validarlo, qué rtCmd enviar al firmware.
//
// Esto elimina la clase de bugs "guardé pero no se aplicó": al ser declarativo,
// es imposible olvidar el populate, el save, la validación o el rtCmd.
//
// Estructura de cada campo:
//   id        : ID del elemento DOM
//   kind      : "global" (variable global RRF) | "mcode" (línea M-code) | "comment" (línea ; rotech-...)
//   gName     : (solo kind="global") nombre del global, ej "z_sensor_to_table"
//   pattern   : (solo kind="mcode") patrón para cfgReplaceLine
//   matcher   : regex con capture group 1 para extraer el valor de config.g
//   formatter : función (value) → línea completa a escribir en config.g
//   rtCmd     : función (value) → comando G-code en caliente, o null si no aplica
//   validate  : función (value) → string de error o null si OK
//   readUI    : función ($) → valor leído de la UI (default: parseFloat($(id).value))
//   writeUI   : función ($, value) → ninguno (default: $(id).value = value)
//   skip      : función ($) → true si el campo no debe procesarse (ej: input vacío)
// ---
/**
 * Aplica pasos/mm (M92) de un eje de forma instantánea y persistente: relee
 * config.g, sustituye solo el componente del eje en la línea M92, lo persiste
 * (con read-back) y lo aplica en caliente. Lo usa el asistente de calibración
 * (rotechos-modules.js). Devuelve true si todo fue bien.
 */
async function _applyM92Instant(axis, value) {
  const v = parseFloat(value);
  if (!isFinite(v) || v <= 0) { toast(t(`msg.pasosmmInválidos`, `Pasos/mm inválidos`), `err`); return false; }
  const errMM = hwCheck(`Pasos/mm ${axis}`, v, HW_LIMITS.stepsMm);
  if (errMM) { toast(errMM, `err`); return false; }
  let raw = await cfgMachineRead();
  if (raw == null) return false;
  // Fail-closed ANTES del fallback. `"" == null` es false, así que una lectura
  // FALLIDA (HTTP 500, red caída) llegaba hasta aquí con raw vacío y caía al
  // fallback de máquina virgen. Consecuencia: se leía config.g y se escribía SU
  // CONTENIDO dentro de config-machine.g — no solo se perdía la calibración,
  // además se duplicaban M569/M584 en el fichero que los carga después
  // (CLAUDE.md §2: M569 duplicado hace que RRF aborte al arrancar).
  // El caso legítimo de máquina virgen es un 404, y ese SÍ pone
  // _cfgMachineLoadOk = true (rotechos-config-persist.js:61), así que el
  // fallback de abajo sigue funcionando para una máquina sin calibrar.
  // Fail-closed — ver _abortConfigMachineNotLoaded (cabecera del fichero).
  if (typeof _cfgMachineLoadOk !== 'undefined' && !_cfgMachineLoadOk) return _abortConfigMachineNotLoaded();
  // Si config-machine.g no existe (virgen), leer config.g como fallback
  if (raw === ``) { raw = await cfgRead(); if (!raw) return false; }
  const re = /^(M92\b[^\n]*)$/m;
  const m = raw.match(re);
  if (!m) { toast(t(`msg.noEncuentroM92`, `No encuentro la línea M92 en config-machine.g`), `err`); return false; }
  let line = m[1];
  const axRe = new RegExp(`${axis}[\\d.]+`);
  if (axRe.test(line)) line = line.replace(axRe, `${axis}${v}`);
  else line = line.replace(/^M92\b/, `M92 ${axis}${v}`);
  if (!(await cfgMachineWrite(raw.replace(re, line)))) return false;
  await RRF.gcode(line.replace(/\s*;.*$/, ``).trim());
  toast(t(`msg.pasosmmAxisV`, `Pasos/mm ${axis} → ${v}`, { "axis": axis, "v": v }), `info`);
  log(`M92 ${axis} = ${v} (calibración wizard → config-machine.g)`, `sys`);
  return true;
}
window._applyM92Instant = _applyM92Instant;
window.cfgPersistGlobalLine = cfgPersistGlobalLine;
// Identidad de máquina: el wizard (rotechos-modules.js) y el backup
// (rotechos-backup.js) consumen estos dos por window, igual que la línea de
// arriba. cfgPersistStringGlobal es el equivalente STRING de
// cfgPersistGlobalLine (esa solo maneja numéricos/booleanos por su regex).
window.cfgPersistStringGlobal = cfgPersistStringGlobal;
window.cfgGetStringGlobal = cfgGetStringGlobal;
window.cfgPersistPin = cfgPersistPin;
window.cfgGetPin = cfgGetPin;
window.cfgRemovePin = cfgRemovePin;
window.cfgGetToolsTable = cfgGetToolsTable;
window.cfgSetToolsTable = cfgSetToolsTable;
window._applyM208Instant = _applyM208Instant;

/**
 * Recalcula pasos/mm (M92) al cambiar el microstepping (M350). PURA, sin red.
 *
 * CONTRATO (t_d612ed30, decisión del briefing):
 *   pasos/mm = (pasos_vuelta × microstepping) ÷ paso_tornillo_mm
 *   Si solo cambia microstepping, el factor de escala entre el antes y el
 *   después es newMicro / oldMicro. Sin redondear a la baja — la pieza debe
 *   seguir midiendo lo mismo, y si el resultado sale con cola decimal, se
 *   conserva porque ya era un decimal en el original.
 *
 * Casos:
 *   - oldMicro inválido (0, NaN, '') → null (el caller decide qué hacer).
 *   - newMicro inválido → null.
 *   - stepsMm no numérico o <= 0 → null.
 *   - Resultado no finito o <= 0 → null.
 *
 * Devuelve el NUEVO valor numérico, o null si algo falla.
 *
 * Test de regresión: tests/unit/microstep-recalc.test.js
 *   Cubierto en particular el caso del briefing: x16 → x32 debe duplicar.
 */
function recalcM92ByMicro(stepsMm, oldMicro, newMicro) {
  const oldM = Number(oldMicro);
  const newM = Number(newMicro);
  const s = Number(stepsMm);
  if (!Number.isFinite(oldM) || oldM <= 0) return null;
  if (!Number.isFinite(newM) || newM <= 0) return null;
  if (!Number.isFinite(s) || s <= 0) return null;
  const ratio = newM / oldM;
  const out = s * ratio;
  if (!Number.isFinite(out) || out <= 0) return null;
  return out;
}
window.recalcM92ByMicro = recalcM92ByMicro;

/**
 * Preview instantáneo del recálculo M92 ↔ M350. Liga los handlers `change`
 * sobre los selects de microstepping para repintar la caja de aviso
 * (#mcfgM350Preview) cada vez que el operario cambia un valor. Idempotente
 * vía el flag _m350PreviewBound: aunque se llame varias veces (populate se
 * puede invocar al abrir el modal y al cambiar de pestaña), los listeners
 * NO se duplican.
 *
 * El parámetro `aActive` es OPCIONAL: si el caller lo conoce (lo lee del
 * populate), lo usa. Si no (caso típico — _populateDrivers corre ANTES de
 * que el A-mode se detecte), lo recalculamos del DOM en el momento de
 * pintar. Esto evita una ReferenceError que medí en e2e-mcfg-microsteps.
 *
 * El "antes" se lee del select (que refleja lo que el populate puso) y de
 * los inputs M92 actuales — coherente con lo que verá el confirmDialog al
 * guardar. No toca la SD ni la red.
 */
let _m350PreviewBound = false;
function _bindM350Preview(aActive) {
  const _resolveAActive = (override) => {
    if (typeof override === `boolean`) return override;
    // Lee del DOM: el radio de eje A marcado en la pestaña MOTORES.
    // Si no hay ninguno marcado, asumimos `off` (caso por defecto).
    const checked = document.querySelector(`input[name="axisAMode"]:checked`);
    return checked ? checked.value !== `off` : false;
  };
  const axes = _resolveAActive(aActive) ? [`X`, `Y`, `Z`, `A`] : [`X`, `Y`, `Z`];
  const handler = () => {
    const aNow = _resolveAActive(aActive);
    _renderM350Preview(aNow ? [`X`, `Y`, `Z`, `A`] : [`X`, `Y`, `Z`]);
  };
  axes.forEach((ax) => {
    const sel = $(`mcfgM350${ax}`);
    if (sel) sel.addEventListener(`change`, handler);
  });
  _m350PreviewBound = true;
  // Pinta el estado inicial (por si el operario reabrió la pestaña con
  // microstepping ya cambiado y la caja debe verse ya populated).
  _renderM350Preview(axes);
}

/**
 * Repinta la caja de preview del recálculo M92 ↔ M350 (#mcfgM350Preview)
 * leyendo los valores ACTUALES de los selects de microstepping y los inputs
 * M92. Solo pinta si hay algún cambio real entre lo que hay en los selects
 * y el M350 actual de la SD; si no hay cambios, oculta la caja (evita
 * ruido visual cuando el operario solo abre y cierra la pestaña).
 *
 * `axes` es la lista de ejes a considerar (sin A si el modo A está off).
 */
function _renderM350Preview(axes) {
  const box = $(`mcfgM350Preview`);
  if (!box) return;
  const deltas = [];
  for (const ax of axes) {
    const sel = $(`mcfgM350${ax}`);
    const m92 = $(`mcfgM92${ax}`);
    if (!sel || !m92) continue;
    // El select guarda el NUEVO microstepping; el original lo leemos de la
    // línea M350 ya persistida en _cfgMachineRaw (o de la SD si no hay RAM).
    const newMicro = Number(sel.value);
    const oldMicro = Number(_lastM350Original[ax] || 0);
    const oldSteps = Number(m92.value || 0);
    const newSteps = recalcM92ByMicro(oldSteps, oldMicro, newMicro);
    if (oldMicro !== newMicro && newSteps != null) {
      deltas.push({ ax, oldMicro, newMicro, oldSteps, newSteps });
    }
  }
  if (deltas.length === 0) {
    box.style.display = `none`;
    box.innerHTML = ``;
    return;
  }
  const items = deltas.map((d) => {
    return `<strong>${d.ax}</strong>: ${d.oldSteps.toFixed(2)} → ` +
      `<strong>${d.newSteps.toFixed(2)}</strong> pasos/mm ` +
      `<span style=color:var(--text-3)>(micro ${d.oldMicro}→${d.newMicro})</span>`;
  }).join(`<br>`);
  box.innerHTML =
    `<strong style=color:var(--warn-strong)>Recálculo de pasos/mm al guardar:</strong><br>${items}`;
  box.style.display = `block`;
}

/**
 * Cache de los valores de M350 LEÍDOS DE LA SD en el último populate. Lo
 * consume _renderM350Preview para diferenciar el "antes" (lo persistido)
 * del "ahora" (lo que el operario acaba de seleccionar). Se rellena desde
 * _populateDrivers una sola vez por apertura de pestaña.
 *
 * Estructura: { X: 16, Y: 16, Z: 16, A: 16 } (lo que dice la SD; 0 si no
 * existe la línea M350 todavía).
 */
let _lastM350Original = { X: 0, Y: 0, Z: 0, A: 0 };
function _captureM350Original(raw) {
  const line = (raw || ``).split(`\n`).find((l) => /^M350\b/.test(l)) || ``;
  for (const ax of [`X`, `Y`, `Z`, `A`]) {
    const v = Number(cfgGet(line, ax));
    _lastM350Original[ax] = Number.isFinite(v) && v > 0 ? v : 0;
  }
}
window._captureM350Original = _captureM350Original;

/**
 * Aplica un soft limit (M208) por eje y lado de forma INSTANTÁNEA: relee
 * config.g fresco, sustituye solo el componente afectado en la línea M208
 * correspondiente (S1=min o S0=max), lo persiste (con read-back) y lo aplica
 * en caliente. Sirve a los 6 inputs mcfgSl{X,Y,Z}{0,1}.
 * Antes el cambio dependía del botón Guardar + pestaña activa; si guardabas
 * con otra pestaña delante, el cambio se silenciaba sin aviso.
 */
async function _applyM208Instant(axis, side, rawVal) {
  const v = parseFloat(rawVal);
  if (!isFinite(v)) { toast(t(`msg.valorInválidoParaAxis`, `Valor inválido para ${axis} ${side}`, { "axis": axis, "side": side }), `err`); return; }
  // Sanity de envolvente + cruce min<max con el input hermano: antes se podía
  // guardar un mínimo mayor que el máximo (soft limits rotos en silencio).
  const errEnv = hwCheck(`Soft limit ${axis}`, v, HW_LIMITS.envelope, ' mm');
  if (errEnv) { toast(errEnv, `err`); return; }
  // Cross-check min<max con el input hermano. Si el DOM input no existe (pestaña
  // de soft-limits nunca visitada, fresh load, operario directo), leemos el otro
  // lado del config.g ahora mismo para validar la invariante. ANTES (audit
  // jul-2026 F3/T2): si `otherEl?.value` era NaN, el check se omitía y se podía
  // guardar min > max en silencio (soft limit roto, M208 no protege el eje).
  const otherTag = side === 'max' ? 'S1' : 'S0';
  const otherEl = $(`mcfgSl${axis}${side === 'max' ? '0' : '1'}`);
  let other = parseFloat(otherEl?.value);
  let raw = await cfgMachineRead();
  if (raw == null) return;
  // FIX (jul-2026, hueco detectado por el test 1-C del primer arranque): un
  // `raw` vacío tiene DOS causas y aquí se trataban igual. Si el fichero no
  // existe (máquina virgen) crear uno es correcto; si la LECTURA FALLÓ (red
  // caída, HTTP 500) escribir encima BORRA la calibración del cliente con los
  // valores de fábrica de config.g. El botón Guardar ya abortaba en ese caso;
  // esta ruta —la instantánea, la que dispara cada onchange— no, y es la que
  // más se usa. Fail-closed: sin lectura válida no se escribe.
  // `typeof` a proposito: este simbolo vive en rotechos-config-persist.js. En la
  // aplicacion siempre esta cargado, pero los tests unitarios extraen esta funcion
  // a un sandbox aislado y sin el guard reventaba con ReferenceError.
  if (typeof _cfgMachineLoadOk !== 'undefined' && !_cfgMachineLoadOk) return _abortConfigMachineNotLoaded();
  if (raw === ``) { raw = await cfgRead(); if (!raw) return; }
  if (!isFinite(other)) {
    // Fallback: leer el otro lado desde config.g
    const otherRe = new RegExp(`^M208[^\\n]*${otherTag}[^\\n]*$`, 'm');
    const otherMatch = raw.match(otherRe);
    if (otherMatch) {
      const otherAxRe = new RegExp(`${axis}(-?[\\d.]+)`);
      const m2 = otherMatch[0].match(otherAxRe);
      if (m2) other = parseFloat(m2[1]);
    }
  }
  if (isFinite(other) && ((side === 'max' && v <= other) || (side === 'min' && v >= other))) {
    toast(`Soft limit ${axis}: ${t(`msg.softLimitCompare`, `el mínimo`)} (${side === 'max' ? other : v}) ${t(`msg.softLimitMustBeLess`, `debe ser MENOR que el máximo`)} (${side === 'max' ? v : other})`, `err`);
    return;
  }
  // S1 = línea de Mínimos · S0 = línea de Máximos
  const tag = side === 'max' ? 'S0' : 'S1';
  const re = new RegExp(`^(M208[^\\n]*${tag}[^\\n]*)$`, 'm');
  const m = raw.match(re);
  if (!m) { toast(t(`msg.noEncuentroM208`, `No encuentro la línea M208 ${tag} en config-machine.g`, { "tag": tag }), `err`); return; }
  // Reemplazar solo el componente del eje en cuestión, preservando los demás.
  const parts = m[1].split(';');
  const cmdPart = parts[0];
  let line;
  const axRe = new RegExp(`(^|\\s)${axis}-?[\\d.]+`);
  if (axRe.test(cmdPart)) {
    parts[0] = cmdPart.replace(axRe, `$1${axis}${v}`);
    line = parts.join(';');
  } else {
    // Si por alguna razón faltaba el eje en esa línea, inyectarlo antes del S{n}
    parts[0] = cmdPart.replace(/\s+S[01]\b/, ` ${axis}${v}$&`);
    line = parts.join(';');
  }
  const ok = await cfgMachineWrite(raw.replace(re, line));
  if (!ok) return;
  // Aplicar en caliente (línea limpia, sin comentario)
  await RRF.gcode(line.replace(/\s*;.*$/, '').trim());
  // Actualizar caché _softLimits del jog JS al instante
  if (_softLimits[axis]) {
    if (side === 'max') _softLimits[axis].max = v;
    else _softLimits[axis].min = v;
  }
  // Si era el max de X/Y, refrescar el visor 3D
  if (side === 'max' && (axis === 'X' || axis === 'Y') && typeof VIZ !== 'undefined') {
    if (axis === 'X') VIZ.workLimits.x = v;
    if (axis === 'Y') VIZ.workLimits.y = v;
    VIZ.dirty = true;
  }
  toast(t(`msg.softLimitAxisSide`, `Límite de recorrido ${axis} ${side === 'max' ? 'Máx' : 'Mín'} → ${v} mm`, { axis, s: side === 'max' ? 'Max' : 'Min', v }), `info`);
  log(`M208 ${axis} ${side} = ${v} (instantáneo → config-machine.g)`, `sys`);
}

/**
 * Pinta el badge de HOME vigente/invigente en la pestaña de Soft Limits.
 *
 *  - HOME vigente    (AppState.limits.allHomed === true)   → data-state="homed"
 *       Texto: "HOME: hecho · los soft limits SÍ protegen el eje"
 *  - HOME invigente  (=== false)                            → data-state="not-homed"
 *       Texto: "HOME: pendiente — los soft limits NO protegen el eje"
 *  - HOME desconocido (=== undefined, mock-server sin primer poll) → data-state="unknown"
 *       Texto: "HOME: desconocido (esperando primer sondeo)"
 *
 * Se llama desde customPopulate de M208 (al cargar la pestaña) y desde
 * updateStateUI de rotechos-state-ui.js (en cada poll). Es robusta a AppState
 * no inicializado: si no existe, trata el estado como "unknown".
 *
 * Devuelve el data-state pintado (útil para tests: "homed"|"not-homed"|"unknown").
 */
function renderSoftLimitsBadge() {
  const badge = $(`softlimitsHomeBadge`);
  if (!badge) return null;
  const txt = badge.querySelector(`.softlimits-badge-text`);
  if (!txt) return null;
  // AppState.limits.allHomed: true = homed, false = pending, undefined = unknown.
  const allHomed = (typeof AppState !== `undefined` && AppState && AppState.limits)
    ? AppState.limits.allHomed
    : undefined;
  let state, key, fallback;
  if (allHomed === true) {
    state = `homed`;
    key = `cfg.softlimits.homeBadge.homed`;
    fallback = `HOME: hecho · los soft limits SÍ protegen el eje`;
  } else if (allHomed === false) {
    state = `not-homed`;
    key = `cfg.softlimits.homeBadge.notHomed`;
    fallback = `HOME: pendiente · los soft limits NO protegen hasta que hagas Home All (G28)`;
  } else {
    state = `unknown`;
    key = `cfg.softlimits.homeBadge.unknown`;
    fallback = `HOME: desconocido (esperando primer sondeo)`;
  }
  badge.dataset.state = state;
  // Bypass i18n apply() — pintamos directo (más reactivo, sin esperar a un
  // t.apply() que podría no haberse cargado aún). Fallback ES es el contrato.
  txt.textContent = t(key, fallback);
  return state;
}
window.renderSoftLimitsBadge = renderSoftLimitsBadge;

/**
 * Pinta el SVG del volumen X/Y/Z y el punto de la posición actual dentro de la
 * pestaña Soft Limits. FUENTES (en orden de prioridad):
 *   1. Los 6 inputs mcfgSl{X,Y,Z}{0,1} (lo que el operario HA EDITADO esta
 *      sesión, incluído lo que _applyM208Instant aún no ha commitido si el
 *      poll no ha llegado).
 *   2. window._softLimits (cache vivo, lo que la máquina REAL reporta).
 *   3. AppState.cache.machinePos para el punto de posición.
 *
 * Si no hay datos (mock-server, primera conexión), dibuja un guion central en
 * lugar de inventar un rectángulo por defecto — el briefing prohíbe inventar
 * un área (regla H, igual que rotechos-viz.js:407-417).
 *
 * CARRIL horizontal por eje con escala idéntica: ancho máximo del rectángulo
 * = 320 px del viewBox (de x=0 a x=320 dentro del grupo). Cada pixel = 1 mm
 * del rango (max-min). En ejes grandes como Y (830 mm) esto comprime, pero
 * el operario que mira la pestaña NO está midiendo: está viendo DÓNDE está
 * la máquina dentro del rango. Es proporcional: si la fresa está en la mitad
 * del recorrido, el punto está en la mitad del rectángulo. Eso es lo que
 * aporta el dibujo frente a los tres números solos.
 *
 * @returns {object} { drew:{X,Y,Z} }  qué ejes tenían datos suficientes para
 *                                 pintar el rectángulo (test assertion).
 */
function renderSoftLimitsVolume() {
  const svg = $(`softlimitsVolumeSvg`);
  const posTxt = $(`slvPosText`);
  if (!svg) return { drew: {} };
  // Lee los 6 inputs (lo editado). Si está vacío, cae a _softLimits.
  const inputVals = {};
  for (const ax of [`X`, `Y`, `Z`]) {
    const lo = parseFloat($(`mcfgSl${ax}0`)?.value);
    const hi = parseFloat($(`mcfgSl${ax}1`)?.value);
    if (isFinite(lo) && isFinite(hi)) {
      inputVals[ax] = { min: lo, max: hi };
    } else {
      inputVals[ax] = (typeof _softLimits !== `undefined` && _softLimits && _softLimits[ax])
        ? { min: _softLimits[ax].min, max: _softLimits[ax].max }
        : null;
    }
  }
  // Posición actual (machine coords)
  const pos = (typeof AppState !== `undefined` && AppState && AppState.cache && AppState.cache.machinePos)
    ? AppState.cache.machinePos
    : (typeof window._machinePos !== `undefined` ? window._machinePos : null);
  // Constante: ancho del carril en px del viewBox (de 0 a 320).
  const BAR_W = 320;
  let drewCount = 0;
  for (const ax of [`X`, `Y`, `Z`]) {
    const row = $(`slvRow${ax}`);
    const lim = inputVals[ax];
    if (!row) continue;
    row.innerHTML = ``;  // limpia hijos anteriores (idempotente)
    if (!lim || !isFinite(lim.min) || !isFinite(lim.max) || lim.max <= lim.min) {
      // Sin datos: guion central + texto "—"
      const ns = `http://www.w3.org/2000/svg`;
      const dash = document.createElementNS(ns, `line`);
      dash.setAttribute(`x1`, String(BAR_W / 2 - 20));
      dash.setAttribute(`y1`, `12`);
      dash.setAttribute(`x2`, String(BAR_W / 2 + 20));
      dash.setAttribute(`y2`, `12`);
      dash.setAttribute(`stroke`, `currentColor`);
      dash.setAttribute(`stroke-width`, `2`);
      dash.setAttribute(`opacity`, `0.35`);
      row.appendChild(dash);
      const lbl = document.createElementNS(ns, `text`);
      lbl.setAttribute(`x`, String(BAR_W / 2 + 32));
      lbl.setAttribute(`y`, `16`);
      lbl.setAttribute(`class`, `slv-tick-lbl`);
      lbl.textContent = `—`;
      row.appendChild(lbl);
      continue;
    }
    drewCount++;
    const ns = `http://www.w3.org/2000/svg`;
    const range = lim.max - lim.min;
    // 1) Suelo del rango (rectángulo proporcional)
    const bar = document.createElementNS(ns, `rect`);
    bar.setAttribute(`x`, `0`);
    bar.setAttribute(`y`, `6`);
    bar.setAttribute(`width`, String(BAR_W));
    bar.setAttribute(`height`, `14`);
    bar.setAttribute(`rx`, `3`);
    bar.setAttribute(`fill`, `currentColor`);
    bar.setAttribute(`opacity`, `0.10`);
    row.appendChild(bar);
    // 2) Marcas de min y max (label)
    for (const [v, x] of [[lim.min, 0], [lim.max, BAR_W]]) {
      const t = document.createElementNS(ns, `text`);
      t.setAttribute(`x`, String(x));
      t.setAttribute(`y`, `-2`);
      t.setAttribute(`class`, `slv-tick-lbl`);
      t.textContent = String(Math.round(v));
      row.appendChild(t);
    }
    // 3) Punto de posición actual (dentro del rectángulo)
    const pa = pos && isFinite(pos[ax]) ? pos[ax] : null;
    if (pa != null) {
      let frac = (pa - lim.min) / range;
      frac = Math.max(0, Math.min(1, frac));  // clamp
      const px = frac * BAR_W;
      const dot = document.createElementNS(ns, `circle`);
      dot.setAttribute(`cx`, String(px));
      dot.setAttribute(`cy`, `13`);
      dot.setAttribute(`r`, `4.5`);
      dot.setAttribute(`fill`, `currentColor`);
      dot.setAttribute(`stroke`, `var(--bg-raised, #fff)`);
      dot.setAttribute(`stroke-width`, `1.5`);
      row.appendChild(dot);
      // Etiqueta del valor de la posición
      const lblVal = document.createElementNS(ns, `text`);
      lblVal.setAttribute(`x`, String(Math.max(0, Math.min(BAR_W - 24, px - 12))));
      lblVal.setAttribute(`y`, `30`);
      lblVal.setAttribute(`class`, `slv-tick-lbl slv-pos-dot-lbl`);
      lblVal.textContent = `${ax}=${pa.toFixed(1)}`;
      row.appendChild(lblVal);
    }
  }
  // 4) Texto de resumen de posición abajo del SVG
  if (posTxt) {
    if (pos && isFinite(pos.X) && isFinite(pos.Y) && isFinite(pos.Z)) {
      posTxt.textContent = `X ${pos.X.toFixed(1)} mm · Y ${pos.Y.toFixed(1)} mm · Z ${pos.Z.toFixed(1)} mm`;
    } else {
      posTxt.textContent = t(`slv.noPos`, `Posición actual sin leer (esperando primer sondeo)`);
    }
  }
  return { drew: { X: drewCount > 0, Y: drewCount > 0, Z: drewCount > 0, _count: drewCount } };
}
window.renderSoftLimitsVolume = renderSoftLimitsVolume;

/**
 * Refresca badge + volumen. Pensado para ser llamado en bloque desde
 * updateStateUI (rotechos-state-ui.js) en cada poll y desde customPopulate
 * de M208 al cargar la pestaña. Es 100% idempotente: si el badge o el SVG
 * no existen (modal cerrado), retorna sin error.
 */
function refreshSoftLimitsUI() {
  const st = renderSoftLimitsBadge();
  const v = renderSoftLimitsVolume();
  return { home: st, volume: v };
}
window.refreshSoftLimitsUI = refreshSoftLimitsUI;

// ---
// HW_LIMITS — Techos físicos del hardware (BTT Scylla V1.0 · TMC2160 R0.05 ·
// NEMA23 · área 850x850x115 · 48V). Toda la validación de CONFIGURACIÓN acota
// contra esta tabla: un dedazo (p.ej. 20000 donde iban 2000) ya no puede
// quemar un driver ni lanzar la máquina contra los topes. Si cambia el
// hardware, este es el ÚNICO sitio que tocar.
// ---
const HW_LIMITS = {
  currentMa:   { min: 200, max: 3100 },  // mA RMS — techo operativo de RotechOS para esta placa.
                                                  //   Límite físico del silicio TMC2160 = 4700 mA peak (datasheet BTT, no se toca).
                                                  //   Configuración real actual (config-machine.g) = 2000–2200 mA para NEMA 23 típicos.
                                                  //   3100 mA es el margen seguro entre la config real y el techo físico del driver.
  currentWarn: 2500,                     // mA — por encima, aviso de calentamiento motor/driver
  speedXY:     { min: 60, max: 12000 },  // mm/min (M203; techo de trabajo actual 6000 → margen x2)
  speedZ:      { min: 60, max: 3000 },
  accelXY:     { min: 1, max: 4000 },    // mm/s² (travel_accel=2000 ya es agresivo en esta mecánica)
  accelZ:      { min: 1, max: 1000 },
  accelA:      { min: 1, max: 2000 },    // deg/s² — eje A rotativo (fix A-2 audit 4º eje: default UI 500)
  jerk:        { min: 1, max: 2400 },    // mm/min (RAYO usa 600)
  jerkA:       { min: 1, max: 3600 },    // deg/min — eje A rotativo (default UI 600)
  // ── Por qué el eje A se valida con DOS varas de medir (jul-2026) ──────────
  // Parece una incoherencia y no lo es del todo. Los validadores SEDA
  // (M203/M201/M566, ~L444-490) comprueban su columna A contra los límites de
  // XY —speedXY, accelXY, jerk, en mm—, mientras los campos RAYO (pro_accel_a,
  // pro_jerk_a) usan accelA/jerkA, en grados. La unidad real del eje A no
  // depende del perfil cinemático sino del MODO del eje (`axisAMode`):
  // `slave` = gantry, lineal en mm; `rotary` = grados. O sea que cada pareja
  // acierta en un modo y falla en el otro.
  //
  // NO es un bug vivo, y por eso se dejó como está: los inputs A de SEDA
  // (mcfgM203A / mcfgM201A / mcfgM566A) nacen `disabled` en index.html y NADA
  // los rehabilita —`applyAxisAMode()` solo conmuta clases CSS de
  // visibilidad—, así que por ahí no entra ningún valor tecleado. Los únicos
  // campos A editables son los de RAYO, y esos ya usan los límites en grados.
  // El check('A', …, HW_LIMITS.accelXY) solo llega a ver lo que populate leyó
  // de config.g.
  //
  // Antes de "unificarlo": hacerlo mode-aware cambia comportamiento de
  // validación, y la pregunta de fondo es de producto, no de limpieza —
  // ¿debe un A rotativo tener cinemática SEDA editable, o basta con los
  // globals de RAYO? Decisión de Sergi, y a validar en banco.
  stepsMm:     { min: 1, max: 10000 },   // pasos/mm (sanity: x16 típico = 80-800)
  probeFast:   { min: 50, max: 3000 },   // mm/min — más rápido y el sobre-recorrido del palpador se come el margen de 5mm
  probeSlow:   { min: 10, max: 500 },
  probeAccel:  { min: 10, max: 1000 },   // mm/s²
  homeSeek:    { min: 100, max: 3000 },  // mm/min hacia el final de carrera
  homeBack:    { min: 50, max: 1500 },
  safeClear:   { min: 2, max: 50 },      // mm (recorrido Z total = 115)
  sensorY:     { min: 0, max: 1000 },    // mm (dentro del chasis)
  envelope:    { min: -500, max: 2000 }, // mm — sanity de soft limits M208 (Z mínimo es NEGATIVO: -115 actual, hasta -500 en máquinas altas)
  psuV:        { min: 12, max: 56 },     // V — entrada válida de la Scylla (fuente del retrofit)
};
/** Valida v contra un rango {min,max}. Devuelve mensaje de error o null si OK. */
function hwCheck(label, v, lim, unit = '') {
  const n = parseFloat(v);
  if (!isFinite(n)) return `${label}: valor no numérico`;
  if (n < lim.min || n > lim.max)
    return `${label}: ${n}${unit} fuera del rango seguro del hardware (${lim.min}-${lim.max}${unit})`;
  return null;
}

// t_b8cd40c2: este módulo es PEREZOSO. CFG_FIELDS se construye copiando
// primero la entrada `mcfgSacSensorZ` que ya está en `window.CFG_FIELDS` (la
// publicó el shim core en el arranque eager — ver CFG_FIELDS_CORE_MERGE
// más abajo para la sincronización al cerrar el módulo), y luego AÑADIENDO
// las 22 entradas que solo se leen al abrir CONFIGURACIÓN. El MERGE se hace
// en una sola expresión para que `cfgFieldSave`, `cfgFieldPopulate`,
// `cfgFieldsPopulateByPrefix`, etc. (todas leen `CFG_FIELDS` léxicamente)
// vean el catálogo COMPLETO — incluido el campo que el código EAGER
// necesita (ZCAL en rotechos.js:4750).
//
// Tests: la `const CFG_FIELDS` local del modal es lo que `loadModal()`
// devuelve (return object del factory). Como SOURCE_CORE pre-inyecta
// `window.CFG_FIELDS = { mcfgSacSensorZ: {...} }` antes de SOURCE_MODAL,
// este spread encuentra la entrada y la incluye. Misma propiedad que en
// producción: el objeto del shim es la fuente, el modal lo COPIA.
const CFG_FIELDS = Object.assign(
  {},
  (typeof window !== `undefined` && window.CFG_FIELDS) || {},
  {
  // ── SAC: posiciones de cambio de herramienta y sensor (globals) ──
  mcfgSacTouchplate: {
    id: 'mcfgSacTouchplate', kind: 'global', gName: 'touchplate_thickness',
    matcher: /^global touchplate_thickness = ([\d.]+)/m,
    formatter: (v) => `global touchplate_thickness = ${v} ; Grosor del material: SONDA Z pone Z=0 en la mesa + este valor (0 = cero en la mesa)`,
    rtCmd: (v) => `set global.touchplate_thickness = ${v}`,
    validate: (v) => (v < 0 || v > 50 ? 'touchplate_thickness debe estar entre 0 y 50 mm' : null),
  },
  // NOTA: mcfgSacSensorX ELIMINADO — el sensor X coincide con el soft limit X
  // máximo (move.axes[0].max). M6.g lo lee directamente de M208. SSOT con
  // soft limits → un solo sitio donde editar.
  //
  // Regla D (acta 2026-09-01 matriz-coherencia): tool_sensor_y debe
  // validarse contra el área M208 (move.axes[1].min/max), NO contra el
  // sanity HW_LIMITS.sensorY (0-1000 mm cubre el chasis pero NO la mesa).
  // Si la máquina está conectada, _softLimits.Y viene de move.axes (SSOT
  // vivo de la controladora). Si no, fallback al sanity de chassis: NO
  // bloqueamos a ciegas (la máquina se configura precisamente en frío).
  // Decisión documentada del borde: Y == Y_max es VÁLIDO (alcanzable
  // físicamente, sin margen); un sensor justo en el límite es responsabilidad
  // del operario, no de la validación.
  mcfgSacSensorY: {
    id: 'mcfgSacSensorY', kind: 'global', gName: 'tool_sensor_y',
    matcher: /^global tool_sensor_y = ([\d.]+)/m,
    formatter: (v) => `global tool_sensor_y = ${v}  ; Posición Y sensor de herramienta`,
    rtCmd: (v) => `set global.tool_sensor_y = ${v}`,
    validate: (v) => {
      // Primero, validación dura contra HW_LIMITS.sensorY (sanity de chassis,
      // 0-1000 mm). Esto SIEMPRE se aplica: ningún valor físicamente absurdo
      // pasa, ni siquiera en frío.
      const chassisErr = hwCheck('tool_sensor_y', v, HW_LIMITS.sensorY, ' mm');
      if (chassisErr) return chassisErr;
      // Segundo, si M208 está disponible, validación fina contra el área de la
      // máquina. _softLimits.Y.min/max los popula _fetchAxisLimits() en el
      // primer poll (rotechos.js:1392-1405) desde `move.axes` de RRF.
      const yLim = (typeof _softLimits !== 'undefined' && _softLimits && _softLimits.Y) || null;
      const yMin = yLim ? yLim.min : null;
      const yMax = yLim ? yLim.max : null;
      if (yMin === null || yMax === null || !isFinite(yMin) || !isFinite(yMax)) {
        // M208 desconocido: avisamos con prefijo para que el operario sepa
        // que la validación fina no se ejecutó, pero dejamos guardar.
        return null;  // hwCheck ya pasó; no añadimos ruido al toast
      }
      const n = parseFloat(v);
      if (!isFinite(n)) return null;  // hwCheck ya cubrió el caso no-numérico
      if (n < yMin || n > yMax) {
        // t() no interpola: el ES (fallback) lleva los números ya metidos.
        // El EN es estático y dirige al operario al sitio correcto.
        return t('msg.sacSensorYOff',
          `Y del sensor (${n} mm) está fuera del recorrido (${yMin}–${yMax} mm). Edita Configuración → Soft Limits o corrige la posición del sensor.`);
      }
      return null;
    },
  },
  // mcfgSacSensorZ ELIMINADO de este fichero (t_b8cd40c2, 2026-09-07):
  // vive en el shim eager `rotechos-config-modal-core.js` (window.CFG_FIELDS)
  // porque ZCAL (rotechos.js:4750) lo lee SIN abrir el modal — la
  // calibración del sensor Z escribe el global y reinicia. Si el modal es
  // perezoso, el ZCAL falla en silencio (modo de fallo documentado en B1).
  // El MERGE con window.CFG_FIELDS está al final del bloque CFG_FIELDS, ver
  // CFG_FIELDS_CORE_MERGE abajo. Los consumidores que leen el campo por id
  // (customPopulate, save, etc.) siguen encontrando la entrada vía MERGE.
  mcfgSacProbeFast: {
    id: 'mcfgSacProbeFast', kind: 'global', gName: 'probe_speed_fast',
    matcher: /^global probe_speed_fast = ([\d.]+)/m,
    formatter: (v) => `global probe_speed_fast = ${v}  ; mm/min — primer palpado (búsqueda)`,
    rtCmd: (v) => `set global.probe_speed_fast = ${v}`,
    validate: (v) => hwCheck('probe_speed_fast', v, HW_LIMITS.probeFast, ' mm/min'),
  },
  mcfgSacProbeSlow: {
    id: 'mcfgSacProbeSlow', kind: 'global', gName: 'probe_speed_slow',
    matcher: /^global probe_speed_slow = ([\d.]+)/m,
    formatter: (v) => `global probe_speed_slow = ${v}  ; mm/min — pasada lenta de precisión (fija el cero)`,
    rtCmd: (v) => `set global.probe_speed_slow = ${v}`,
    validate: (v) => hwCheck('probe_speed_slow', v, HW_LIMITS.probeSlow, ' mm/min'),
  },
  mcfgSacProbeAccel: {
    id: 'mcfgSacProbeAccel', kind: 'global', gName: 'probe_accel_z',
    matcher: /^global probe_accel_z = ([\d.]+)/m,
    formatter: (v) => `global probe_accel_z = ${v}  ; mm/s² — aceleración Z segura durante el palpado`,
    rtCmd: (v) => `set global.probe_accel_z = ${v}`,
    validate: (v) => hwCheck('probe_accel_z', v, HW_LIMITS.probeAccel, ' mm/s²'),
  },
  // §4.8 punto 4 (t_014cd150): timeout del palpado. Si la sonda no hace
  // contacto en este tiempo, la macro aborta. 1–30 s es el rango razonable:
  // menos de 1 s da falsos negativos en velocidades lentas; más de 30 s
  // atasca el operario cuando la sonda no está conectada. Validación inline
  // (no hwCheck) porque el rango no es mm sino ms.
  mcfgSacProbeTimeout: {
    id: 'mcfgSacProbeTimeout', kind: 'global', gName: 'probe_timeout_ms',
    matcher: /^global probe_timeout_ms = ([\d.]+)/m,
    formatter: (v) => `global probe_timeout_ms = ${v}  ; ms — timeout del palpado; si no hay contacto en este tiempo, aborta`,
    rtCmd: (v) => `set global.probe_timeout_ms = ${v}`,
    validate: (v) => {
      const n = Number(v);
      if (!Number.isFinite(n)) return 'probe_timeout_ms debe ser numérico';
      if (n < 1000 || n > 30000) return 'probe_timeout_ms fuera de rango (1000–30000 ms = 1–30 s)';
      return null;
    },
  },

  // ── PRO mode globals (aceleraciones y jerks del modo RAYO) ──
  mcfgRayoAccX: { id: 'mcfgRayoAccX', kind: 'global', gName: 'pro_accel_x',
    matcher: /^global pro_accel_x = ([\d.]+)/m,
    formatter: (v) => `global pro_accel_x = ${v}  ; Aceleración Trabajo X (RAYO)`,
    rtCmd: (v) => `set global.pro_accel_x = ${v}`,
    validate: (v) => hwCheck('pro_accel_x', v, HW_LIMITS.accelXY, ' mm/s²') },
  mcfgRayoAccY: { id: 'mcfgRayoAccY', kind: 'global', gName: 'pro_accel_y',
    matcher: /^global pro_accel_y = ([\d.]+)/m,
    formatter: (v) => `global pro_accel_y = ${v}  ; Aceleración Trabajo Y (RAYO)`,
    rtCmd: (v) => `set global.pro_accel_y = ${v}`,
    validate: (v) => hwCheck('pro_accel_y', v, HW_LIMITS.accelXY, ' mm/s²') },
  mcfgRayoAccZ: { id: 'mcfgRayoAccZ', kind: 'global', gName: 'pro_accel_z',
    matcher: /^global pro_accel_z = ([\d.]+)/m,
    formatter: (v) => `global pro_accel_z = ${v}  ; Aceleración Trabajo Z (RAYO)`,
    rtCmd: (v) => `set global.pro_accel_z = ${v}`,
    validate: (v) => hwCheck('pro_accel_z', v, HW_LIMITS.accelZ, ' mm/s²') },
  mcfgRayoJerkX: { id: 'mcfgRayoJerkX', kind: 'global', gName: 'pro_jerk_x',
    matcher: /^global pro_jerk_x = ([\d.]+)/m,
    formatter: (v) => `global pro_jerk_x = ${v}  ; Jerk Trabajo X (RAYO, mm/min JD)`,
    rtCmd: (v) => `set global.pro_jerk_x = ${v}`,
    validate: (v) => hwCheck('pro_jerk_x', v, HW_LIMITS.jerk, ' mm/min') },
  mcfgRayoJerkY: { id: 'mcfgRayoJerkY', kind: 'global', gName: 'pro_jerk_y',
    matcher: /^global pro_jerk_y = ([\d.]+)/m,
    formatter: (v) => `global pro_jerk_y = ${v}  ; Jerk Trabajo Y (RAYO, mm/min JD)`,
    rtCmd: (v) => `set global.pro_jerk_y = ${v}`,
    validate: (v) => hwCheck('pro_jerk_y', v, HW_LIMITS.jerk, ' mm/min') },
  mcfgRayoJerkZ: { id: 'mcfgRayoJerkZ', kind: 'global', gName: 'pro_jerk_z',
    matcher: /^global pro_jerk_z = ([\d.]+)/m,
    formatter: (v) => `global pro_jerk_z = ${v}  ; Jerk Trabajo Z (RAYO)`,
    rtCmd: (v) => `set global.pro_jerk_z = ${v}`,
    validate: (v) => hwCheck('pro_jerk_z', v, HW_LIMITS.jerk, ' mm/min') },
  // ── RAYO eje A (rotativo, GRADOS: deg/s² y deg/min) ──
  // Fix A-2 / CFG-1 (audit 4º eje 2026-07-12): estos dos inputs existían en el
  // HTML pero eran campos MUERTOS (sin entrada aquí → sin populate, sin persist,
  // sin rtCmd). set_pro.g/ramp_to_pro.g consumen global.pro_*_a bajo el guard
  // `if #move.axes > 3`; los globals se re-declararon en globals.g (fix A-1).
  // El save por prefijo 'mcfgRayo' (cfgFieldsSaveByPrefix) los recoge solo.
  mcfgRayoAccA: { id: 'mcfgRayoAccA', kind: 'global', gName: 'pro_accel_a',
    matcher: /^global pro_accel_a = ([\d.]+)/m,
    formatter: (v) => `global pro_accel_a = ${v}  ; Aceleración Trabajo A (RAYO, deg/s²)`,
    rtCmd: (v) => `set global.pro_accel_a = ${v}`,
    validate: (v) => hwCheck('pro_accel_a', v, HW_LIMITS.accelA, ' deg/s²') },
  mcfgRayoJerkA: { id: 'mcfgRayoJerkA', kind: 'global', gName: 'pro_jerk_a',
    matcher: /^global pro_jerk_a = ([\d.]+)/m,
    formatter: (v) => `global pro_jerk_a = ${v}  ; Jerk Trabajo A (RAYO, deg/min JD)`,
    rtCmd: (v) => `set global.pro_jerk_a = ${v}`,
    validate: (v) => hwCheck('pro_jerk_a', v, HW_LIMITS.jerkA, ' deg/min') },

  // ── Tensión de la fuente (retrofit): M911 y health_check derivan umbrales ──
  mcfgPsuVoltage: {
    id: 'mcfgPsuVoltage', kind: 'global', gName: 'psu_voltage',
    matcher: /^global psu_voltage = ([\d.]+)/m,
    formatter: (v) => `global psu_voltage = ${v}  ; V — tensión de la FUENTE. M911 (corte de luz) y health_check derivan sus umbrales de aquí: cámbiala si montas una fuente distinta (retrofit). Editable en CONFIGURACIÓN → Motores`,
    // En vivo: actualizar el global Y re-armar M911 con los umbrales nuevos
    // (la línea de config.g usa expresiones {psu_voltage*..} y se re-deriva sola al reiniciar)
    rtCmd: (v) => `set global.psu_voltage = ${v}\nM911 S${(v * 0.73).toFixed(1)} R${(v * 0.83).toFixed(1)} P"T0 M5 M913 X0 Y0 G91 G1 Z5 F2000 G90"`,
    validate: (v) => hwCheck('Tensión de fuente', v, HW_LIMITS.psuV, ' V'),
  },
  });

// CFG_FIELDS_CORE_MERGE (t_b8cd40c2, 5.º intento, 2026-09-07)
// ---
// El shim core `rotechos-config-modal-core.js` define una versión MÍNIMA de
// `CFG_FIELDS` con la entrada `mcfgSacSensorZ` (que ZCAL lee sin abrir el
// modal). Aquí en el modal declaramos la versión COMPLETA sin esa entrada.
// Antes de cerrar el módulo, MERGEAMOS: el objeto local gana sobre window
// por si alguna entrada se solapa (defensa — no debería, son disjuntas por
// diseño). El resultado vive en window.CFG_FIELDS para que consumidores
// externos que ya cachearon la referencia del shim (rotechos.js:4750) sigan
// viendo la entrada de mcfgSacSensorZ.
//
// Tests: `tests/unit/cfg-machine-persistence.test.js` y
// `tests/unit/spindle-m950-pins.test.js` inyectan SOURCE_CORE antes que
// SOURCE_MODAL en el mismo `new Function`, así `window.CFG_FIELDS` ya tiene
// `mcfgSacSensorZ` cuando este bloque corre — el MERGE es seguro en ambos
// contextos (producción y tests).
if (window.CFG_FIELDS && typeof window.CFG_FIELDS === 'object') {
  Object.assign(window.CFG_FIELDS, CFG_FIELDS);
} else {
  window.CFG_FIELDS = CFG_FIELDS;
}

// ---
// CFG_AXIS_GROUPS — Grupos multi-eje para M-codes que llevan X/Y/Z/A juntos
// ---
//
// M92 X{x} Y{y} Z{z} [A{a}]
// M906 X{x} Y{y} [A{a}] I{i}     ← Z va en línea SEPARADA con I100 fijo
// M203 X{x} Y{y} Z{z} [A{a}]
// M201 X{x} Y{y} Z{z} [A{a}]
// M566 X{x} Y{y} Z{z} [A{a}] P1
// M425 X{x} Y{y} Z{z} [A{a}] S{s}
//
// Cada grupo se procesa con una sola línea M-code que contiene los valores de
// los 3-4 ejes. La aActive (modo eje A) decide si se incluye A.
// ---
const CFG_AXIS_GROUPS = {
  M92: {
    domIds: { X: 'mcfgM92X', Y: 'mcfgM92Y', Z: 'mcfgM92Z', A: 'mcfgM92A' },
    pattern: 'M92 ',
    formatter: ({ X, Y, Z, A }, aActive) => {
      const parts = [];
      if (X) parts.push(`X${X}`);
      if (Y) parts.push(`Y${Y}`);
      if (Z) parts.push(`Z${Z}`);
      if (aActive && A) parts.push(`A${A}`);
      return parts.length === 0 ? null : `M92 ${parts.join(' ')}  ; Pasos por mm`;
    },
    validate: ({ X, Y, Z, A }, aActive) => {
      const check = (name, v) => v != null && v !== ''
        ? hwCheck(`Pasos/mm ${name}`, v, HW_LIMITS.stepsMm) : null;
      return check('X', X) || check('Y', Y) || check('Z', Z) || (aActive ? check('A', A) : null);
    },
    needsReboot: true,
  },
  // M350 (Microstepping) — declarativo como M92. Coexiste con M906_XYA y M906_Z
  // como tercer grupo multi-eje de la pestaña MOTORES. Los valores permitidos son
  // los nativos del TMC2160: 1, 2, 4, 8, 16, 32, 64, 128, 256. La validación
  // RECHAZA cualquier otra cosa — un microstepping de 5 o 17 confunde al driver.
  // M350 NO se manda en caliente: cambia la resolución del driver y la siguiente
  // M92 no se interpreta igual; needsReboot:true lo marca para que el modal
  // muestre el diálogo de reinicio.
  M350: {
    domIds: { X: 'mcfgM350X', Y: 'mcfgM350Y', Z: 'mcfgM350Z', A: 'mcfgM350A' },
    pattern: 'M350 ',
    // Lista blanca — debe estar sincronizada con las <option> del HTML y con
    // los tests unitarios (microstep-recalc.test.js).
    microAllowed: [1, 2, 4, 8, 16, 32, 64, 128, 256],
    formatter: ({ X, Y, Z, A }, aActive) => {
      const parts = [];
      if (X) parts.push(`X${X}`);
      if (Y) parts.push(`Y${Y}`);
      if (Z) parts.push(`Z${Z}`);
      if (aActive && A) parts.push(`A${A}`);
      return parts.length === 0 ? null : `M350 ${parts.join(' ')}  ; Microstepping TMC2160`;
    },
    validate: ({ X, Y, Z, A }, aActive) => {
      const allowed = CFG_AXIS_GROUPS.M350.microAllowed;
      const check = (name, v) => {
        if (v == null || v === '') return null;
        const n = parseInt(v, 10);
        if (!Number.isInteger(n) || !allowed.includes(n)) {
          return `Microstepping ${name}: valor inválido (${v}). Permitidos: ${allowed.join(', ')}`;
        }
        return null;
      };
      return check('X', X) || check('Y', Y) || check('Z', Z)
        || (aActive ? check('A', A) : null);
    },
    needsReboot: true,
  },
  // M350 I (Interpolación TMC2160 a 256×) — flag aparte porque es un único
  // boolean compartido por todos los drivers de la placa, no por eje. Coexiste
  // en la misma línea M350 pero no tiene sentido multiplicarlo por eje.
  M350_I: {
    domIds: { I: 'mcfgM350I' },
    pattern: 'M350 ',
    formatter: ({ I }, _aActive, content) => {
      // Preservar la línea M350 entera (ya con sus X/Y/Z) y solo sustituir/anexar I
      const existing = (content || '').split('\n').find((l) => /^M350\b/.test(l)) || '';
      const axisMatch = existing.match(/M350\s+([^\s;]+(?:\s+[^\s;]+)*)/);
      if (!axisMatch) return null; // sin línea M350 todavía — la rama "motors" no debería llegar aquí
      const axisPart = axisMatch[1];
      const iVal = I === 'on' || I === true || I === '1' || I === 1 ? 1 : 0;
      return `M350 ${axisPart} I${iVal}  ; Microstepping TMC2160 + interpolación`;
    },
    // No se valida: es un boolean y el checkbox ya impide valores raros.
    needsReboot: true,
  },
  M203: {
    domIds: { X: 'mcfgM203X', Y: 'mcfgM203Y', Z: 'mcfgM203Z', A: 'mcfgM203A' },
    pattern: 'M203 ',
    formatter: ({ X, Y, Z, A }, aActive) => {
      const parts = [];
      if (X) parts.push(`X${X}`);
      if (Y) parts.push(`Y${Y}`);
      if (Z) parts.push(`Z${Z}`);
      if (aActive && A) parts.push(`A${A}`);
      return parts.length === 0 ? null : `M203 ${parts.join(' ')}  ; Velocidades máx (mm/min)`;
    },
    validate: ({ X, Y, Z, A }) => {
      const check = (name, v, lim) => v != null && v !== ''
        ? hwCheck(`Velocidad ${name}`, v, lim, ' mm/min') : null;
      return check('X', X, HW_LIMITS.speedXY) || check('Y', Y, HW_LIMITS.speedXY)
        || check('Z', Z, HW_LIMITS.speedZ) || check('A', A, HW_LIMITS.speedXY);
    },
  },
  M201: {
    domIds: { X: 'mcfgM201X', Y: 'mcfgM201Y', Z: 'mcfgM201Z', A: 'mcfgM201A' },
    pattern: 'M201 ',
    formatter: ({ X, Y, Z, A }, aActive) => {
      const parts = [];
      if (X) parts.push(`X${X}`);
      if (Y) parts.push(`Y${Y}`);
      if (Z) parts.push(`Z${Z}`);
      if (aActive && A) parts.push(`A${A}`);
      return parts.length === 0 ? null : `M201 ${parts.join(' ')}  ; Aceleraciones (mm/s^2)`;
    },
    validate: ({ X, Y, Z, A }) => {
      const check = (name, v, lim) => v != null && v !== ''
        ? hwCheck(`Aceleración ${name}`, v, lim, ' mm/s²') : null;
      return check('X', X, HW_LIMITS.accelXY) || check('Y', Y, HW_LIMITS.accelXY)
        || check('Z', Z, HW_LIMITS.accelZ) || check('A', A, HW_LIMITS.accelXY);
    },
  },
  M566: {
    domIds: { X: 'mcfgM566X', Y: 'mcfgM566Y', Z: 'mcfgM566Z', A: 'mcfgM566A' },
    pattern: 'M566 ',
    formatter: ({ X, Y, Z, A }, aActive, content) => {
      // Preservar P (Junction Deviation flag) de la línea existente
      const existing = (content || '').split('\n').find((l) => /^M566/.test(l)) || '';
      const pVal = cfgGet(existing, 'P') || '1';
      const parts = [];
      if (X) parts.push(`X${X}`);
      if (Y) parts.push(`Y${Y}`);
      if (Z) parts.push(`Z${Z}`);
      if (aActive && A) parts.push(`A${A}`);
      if (parts.length === 0) return null;
      return `M566 ${parts.join(' ')} P${pVal}  ; Jerk (mm/min)`;
    },
    validate: ({ X, Y, Z, A }) => {
      const check = (name, v) => v != null && v !== ''
        ? hwCheck(`Jerk ${name}`, v, HW_LIMITS.jerk, ' mm/min') : null;
      return check('X', X) || check('Y', Y) || check('Z', Z) || check('A', A);
    },
  },
  M425: {
    domIds: { X: 'mcfgM425X', Y: 'mcfgM425Y', Z: 'mcfgM425Z', A: 'mcfgM425A', S: 'mcfgM425S' },
    pattern: 'M425 ',
    formatter: ({ X, Y, Z, A, S }, aActive) => {
      const parts = [];
      if (X) parts.push(`X${X}`);
      if (Y) parts.push(`Y${Y}`);
      if (Z) parts.push(`Z${Z}`);
      if (aActive && A) parts.push(`A${A}`);
      parts.push(`S${S || '0'}`);
      return `M425 ${parts.join(' ')}  ; Compensación backlash (mm)`;
    },
    validate: ({ X, Y, Z, A, S }) => {
      for (const [n, v] of Object.entries({ X, Y, Z, A })) {
        if (v == null || v === '') continue;
        const num = parseFloat(v);
        if (isNaN(num) || num < 0 || num > 5.0) return `Backlash ${n} debe estar entre 0 y 5.0 mm`;
      }
      if (S != null && S !== '') {
        const num = parseFloat(S);
        if (isNaN(num) || num < 0 || num > 200) return 'Suavizado (S) debe estar entre 0 y 200';
      }
      return null;
    },
  },
  // ── M906: corrientes — DOS LÍNEAS SEPARADAS ──
  // Z va en línea aparte con I100 hardcoded (retiene peso del spindle por gravedad).
  // X/Y/A comparten línea con el idle % del input mcfgM906I.
  // Si extX/Y/Z/A está marcado (driver externo), ese eje se OMITE de M906 (lo
  // gestiona un controlador externo, no el TMC interno).
  M906_XYA: {
    domIds: { X: 'mcfgM906X', Y: 'mcfgM906Y', A: 'mcfgM906A', I: 'mcfgM906I' },
    pattern: 'M906 X',
    formatter: ({ X, Y, A, I }, aActive) => {
      const extX = $('mcfgExtX')?.checked;
      const extY = $('mcfgExtY')?.checked;
      const extA = $('mcfgExtA')?.checked;
      const parts = [];
      if (X && !extX) parts.push(`X${X}`);
      if (Y && !extY) parts.push(`Y${Y}`);
      if (aActive && A && !extA) parts.push(`A${A}`);
      if (I) parts.push(`I${I}`);
      return parts.length === 0 ? null : `M906 ${parts.join(' ')}  ; X/Y: corriente + idle %`;
    },
    validate: ({ X, Y, A, I }, aActive) => {
      // Tope = techo operativo de RotechOS (3100 mA RMS).
      //   Límite físico silicio TMC2160 = 4700 mA peak (datasheet BTT, no se toca).
      //   El 3100 deja margen frente al silicio y protege motores NEMA 23 típicos.
      //   Antes 4700: permitía cocinar el driver/motor con un dedazo.
      for (const [n, v] of Object.entries(aActive ? { X, Y, A } : { X, Y })) {
        if (v == null || v === '') continue;
        const err = hwCheck(`Corriente ${n}`, v, HW_LIMITS.currentMa, ' mA');
        if (err) return err;
        if (parseFloat(v) > HW_LIMITS.currentWarn)
          toast(`${t(`msg.current`, `Corriente`)} ${n} = ${v} mA: ${t(`msg.currentWarnBody`, `vigila la temperatura de motor y driver`)}`, 'warn');
      }
      if (I != null && I !== '') {
        const num = Number(I);
        if (isNaN(num) || num < 0 || num > 100) return 'Idle % debe estar entre 0 y 100';
      }
      return null;
    },
    needsReboot: true,
  },
  M906_Z: {
    domIds: { Z: 'mcfgM906Z' },
    pattern: 'M906 Z',
    formatter: ({ Z }) => {
      const extZ = $('mcfgExtZ')?.checked;
      if (!Z || extZ) return null;
      // Z SIEMPRE en línea separada con I100 (retiene peso del spindle)
      return `M906 Z${Z} I100  ; Z: 100% idle SIEMPRE — retiene peso del spindle por gravedad`;
    },
    validate: ({ Z }) => {
      if (Z == null || Z === '') return null;
      const err = hwCheck('Corriente Z', Z, HW_LIMITS.currentMa, ' mA');
      if (err) return err;
      if (parseFloat(Z) > HW_LIMITS.currentWarn)
        toast(`${t(`msg.current`, `Corriente`)} Z = ${Z} mA: ${t(`msg.currentWarnBody`, `vigila la temperatura de motor y driver`)}`, 'warn');
      return null;
    },
    needsReboot: true,
  },

  // ── M569: dirección por driver + flag driver externo ──
  // CASO ESPECIAL: M569 son 4 LÍNEAS SEPARADAS (M569 P{n} ...), no una sola con X/Y/Z/A.
  // Por eso usa `customSave`: itera por los 4 ejes y escribe una línea por cada driver.
  // El mapeo eje→driver se lee dinámicamente del M584 actual (preserva Fase 2).
  // `ids` es metadato declarativo para el auditor (no se itera en runtime).
  M569: {
    ids: ['mcfgM569X', 'mcfgM569Y', 'mcfgM569Z', 'mcfgM569A',
          'mcfgExtX', 'mcfgExtY', 'mcfgExtZ', 'mcfgExtA'],
    // eslint-disable-next-line no-unused-vars -- _rtCmds no se usa: M569 NUNCA en rtCmds (CLAUDE.md §2)
    customSave: ({ content, _rtCmds }) => {
      // CLAUDE.md §2: M569 re-ejecutado en caliente RESETEA el TMC2160 e invierte
      // los ejes. Por eso NUNCA metemos `M569 P{n} ...` en rtCmds — solo
      // persistimos en disco (cfgReplaceLine sobre `_cfgRaw`, llamado por la
      // rama `motors` del save principal) y la aplicación se hace vía el reboot
      // guiado (_motorsNeedReboot + confirmDialog). Este handler sólo DEBE
      // operar sobre el contenido de config.g, no sobre el de config-machine.g.
      //
      // Leer mapeo actual de M584 (preserva configuración de Fase 2).
      // El fallback era `M584 X3 Y1 Z2 A4` y de ahi salia un `M569 P4` para un
      // driver que esta placa NO TIENE (config.g:56: la Scylla V1.0 llega a P3,
      // y declarar P4 puede abortar config.g). Ese fallback solo se usa si no
      // hay linea M584 en el fichero, pero entonces inventaba un eje A que
      // nadie pidio. Ahora es el mapeo de fabrica, X/Y/Z y nada mas.
      const m584 = content.split('\n').find((l) => /^M584\b/.test(l)) || 'M584 X0 Y1 Z2';
      const xDrv = parseInt(m584.match(/X(\d+)/)?.[1] ?? '3');
      const yDrv = parseInt(m584.match(/Y(\d+)/)?.[1] ?? '1');
      const zDrv = parseInt(m584.match(/Z(\d+)/)?.[1] ?? '2');
      const aDrvRaw = m584.match(/A(-?\d+)/)?.[1];
      const aDrv = aDrvRaw && aDrvRaw !== '-1' ? parseInt(aDrvRaw) : null;
      const mapping = [
        { id: 'mcfgM569X', p: xDrv, ax: 'X' },
        { id: 'mcfgM569Y', p: yDrv, ax: 'Y' },
        { id: 'mcfgM569Z', p: zDrv, ax: 'Z' },
      ];
      if (aDrv != null) mapping.push({ id: 'mcfgM569A', p: aDrv, ax: 'A' });
      // Lista per-máquina de drivers vetados (config-machine.g,
      // ; rotech-banned-drivers=...). Origen del diseño y motivos en
      // rotechos-config-persist.js (parseBannedDrivers). Por defecto VACÍA: una
      // instalación nueva NO veta ningún driver. La placa vieja de Sergi llevaba
      // P0 quemado y lo sembraba en su config-machine.g (placa nueva: 9-oct-2026).
      const _isEn = (typeof I18N !== `undefined` && I18N.lang === `en`);
      const bannedInfo = parseBannedDrivers(content);
      for (const { id, p, ax } of mapping) {
        if (bannedInfo.drivers.has(p)) {
          const reason = bannedInfo.reasons.get(p);
          const msg = _isEn
            ? (reason
                ? `Driver P${p} not available on this machine (reason in config-machine.g: ${reason}). Edit '; rotech-banned-drivers=' in config-machine.g to re-enable.`
                : `Driver P${p} not available on this machine (banned in config-machine.g). Edit '; rotech-banned-drivers=' in config-machine.g to re-enable.`)
            : (reason
                ? `Driver P${p} no disponible en esta máquina (motivo en config-machine.g: ${reason}). Edita '; rotech-banned-drivers=' en config-machine.g si necesitas rehabilitarlo.`
                : `Driver P${p} no disponible en esta máquina (vetado en config-machine.g). Edita '; rotech-banned-drivers=' en config-machine.g si necesitas rehabilitarlo.`);
          toast(msg, `err`);
          return { content, ok: false };
        }
        const el = $(id);
        if (!el) continue;
        const isExt = $(`mcfgExt${ax}`)?.checked;
        const sVal = el.checked ? 0 : 1;
        // Preservar parámetro D del M569 existente. Sin esto, set_silk.g ejecuta
        // M569 P{p} D3 tras config.g y en algunos TMC de BTT Scylla esto reinicializa
        // el driver reseteando S al default — anulando el cambio de dirección (Bug 5).
        const existingLine = content.split('\n').find((l) => RegExp(`^M569 P${p}\\b`).test(l)) || '';
        const existingD = existingLine.match(/\bD(\d+)\b/)?.[1];
        const dParam = isExt ? 'D2' : (existingD ? `D${existingD}` : 'D3');
        // T (timing) SOLO con driver externo. Con TMC2160 integrado, RRF aplica
        // los defaults de la placa — añadir T forzaría pulsos lentos innecesarios.
        // El valor viene del selector `mcfgExtDrvType{ax}`:
        //   dm542/dm860  → presets conservadores (Leadshine datasheet).
        //   custom      → número libre validado contra [1.5, 50] µs.
        //   tmc2160     → sin T (caso inaccesible porque si isExt=true no puede
        //                  ser tmc2160, pero se mantiene por defensa).
        // El valor exacto lo confirma Sergi en banco (PENDIENTE BANCO).
        let tParam = '';
        // typeVal solo importa si el toggle externo esta ON: si lo esta,
        // seleccionamos el preset T o validamos el custom. Si NO esta ON,
        // no se genera T{...} y la linea lleva D3 (TMC interno); el
        // comentario no necesita tag de tipo externo.
        const typeSel = $(`mcfgExtDrvType${ax}`);
        const customInp = $(`mcfgExtDrvCustom${ax}`);
        const typeVal = typeSel?.value || 'dm542';
        if (isExt) {
          let tVal = null;
          if (typeVal === 'dm542' || typeVal === 'dm860') {
            tVal = '2.5:2.5:1:1';
          } else if (typeVal === 'cl57t' || typeVal === 'hbs57') {
            // Closed-loop stepper drivers (Leadshine CL57T, HBS57, genéricos
            // CL57). Comparten el perfil eléctrico STEP/DIR de los DM — el
            // encoder/ALARM los gestiona el driver internamente y RRF no los
            // ve. Mismo preset conservador (2.5:2.5:1:1 µs) que DM542/DM860
            // para no asumir timings más optimistas hasta validar en banco.
            tVal = '2.5:2.5:1:1';
          } else if (typeVal === 'custom') {
            const cv = parseFloat(customInp?.value);
            if (!Number.isFinite(cv) || cv < 1.5 || cv > 50) {
              toast(t(`msg.extdrvCustomRange`, `Driver ${ax}: valor T inválido (rango 1.5–50 µs)`, { "ax": ax }), 'err');
              return { content, ok: false };
            }
            tVal = `${cv.toFixed(1)}:${cv.toFixed(1)}:${cv.toFixed(1)}:${cv.toFixed(1)}`;
          }
          if (tVal) tParam = ` T${tVal}`;
        }
        // 15-sep: se conservan los parámetros que la UI no gestiona (V200/V150: paso a
        // SpreadCycle). Antes Guardar MOTORES los borraba.
        const extra = (existingLine.split(`;`)[0].match(/\s[A-Z]\S*/g) || []).filter((tok) => !/^\s[PSDT]/.test(tok)).join(``);
        const cmd = `M569 P${p} S${sVal} ${dParam}${tParam}${extra}`;
        // Persistimos en `content` (= _cfgRaw pasado por la rama `motors`).
        // NO push a rtCmds — M569 NUNCA se aplica en caliente (§2 CLAUDE.md).
        // Comentario: anota la familia del driver externo cuando lo es, para
        // que el populate (lectura al recargar la UI) pueda reconstruir el
        // selector sin tener que adivinar por el T{...} — DM542/DM860 y los
        // closed-loop (CL57T/HBS57) comparten el mismo preset conservador
        // 2.5:2.5:1:1, así que el T por sí solo no los distingue. Si NO es
        // externo, sin tag (driver interno TMC2160).
        // Etiqueta del comentario. Con el toggle externo ON pero el selector
        // aun en `tmc2160` (que es el driver INTERNO), escribir "(tmc2160)"
        // producia una linea incoherente: `M569 P3 S1 D2 ; Driver X (tmc2160)`
        // — modo externo, SIN tiempos STEP/DIR y etiquetada como el interno.
        // Lo cazo e2e-drivers-externos.spec.js:299, que espera "(externo)".
        // Con familia externa conocida se escribe la familia (es lo que permite
        // reconstruir el selector al recargar); sin ella, "(externo)", que es
        // lo honesto: externo, familia sin especificar. El populate no cambia:
        // ninguna de las dos esta en su lista blanca, asi que cae al `else` y
        // deja el selector como estaba.
        const FAMILIAS_EXT = ['dm542', 'dm860', 'cl57t', 'hbs57', 'custom'];
        const typeTag = isExt
          ? (FAMILIAS_EXT.includes(typeVal) ? ` (${typeVal})` : ` (externo)`)
          : ``;
        content = cfgReplaceLine(content, `M569 P${p} `, `${cmd}  ; Driver ${ax}${typeTag}`);
      }
      return { content, ok: true, needsReboot: true };
    },
  },

  // ── M584: mapeo eje→driver + modo eje A (off / slave / rotary) ──
  // CASO ESPECIAL: una sola línea pero con lógica cruzada — preserva el mapeo
  // X/Y/Z existente (Fase 2: cliente puede tener X en driver 0 estándar) y solo
  // calcula el driver A según el modo seleccionado en el radio `axisAMode`.
  // En modo SLAVE el driver A se inyecta como `Y{prim}:{slave}` (compound axis).
  M584: {
    ids: ['axisAMode'],  // metadato declarativo (radio group, no input directo)
    // eslint-disable-next-line no-unused-vars -- _rtCmds no se usa: M584 NUNCA en rtCmds (consistencia con M569)
    customSave: ({ content, _rtCmds }) => {
      // CLAUDE.md §2: M584 cambia el mapeo eje→driver (y M569 P0 se valida
      // contra él). Aunque el efecto en caliente no es tan violento como M569
      // (no reinicializa el TMC), el cambio de mapeo entre guardados puede
      // descolocar al operario. Por consistencia con M569: persistimos en
      // disco sobre `_cfgRaw` (pasado por la rama `motors`) y NO metemos
      // `M584` en rtCmds — el reboot guiado aplica el cambio de forma atómica.
      const aMode = $q('input[name="axisAMode"]:checked')?.value || 'off';
      const m584Existing = content.split('\n').find((l) => /^M584\b/.test(l)) || 'M584 X0 Y1 Z2';
      const xDrv = m584Existing.match(/X([\d:]+)/)?.[1] || '3';
      const yDrvRaw = m584Existing.match(/Y([\d:]+)/)?.[1] || '1';
      // En modo SLAVE el driver Y se expresa como Y{primary}:{slave}. Extraer el primary.
      const yDrv = yDrvRaw.split(':')[0];
      const zDrv = m584Existing.match(/Z([\d:]+)/)?.[1] || '2';
      // Validación cruzada: dos ejes al mismo driver = movimiento en tándem involuntario.
      // Solo verifica X/Y/Z (el driver de A se calcula automáticamente como el primero libre).
      if (xDrv === yDrv || xDrv === zDrv || yDrv === zDrv) {
        const dupes = [];
        if (xDrv === yDrv) dupes.push(`X y Y comparten driver P${xDrv}`);
        if (xDrv === zDrv) dupes.push(`X y Z comparten driver P${xDrv}`);
        if (yDrv === zDrv) dupes.push(`Y y Z comparten driver P${yDrv}`);
        toast(t(`msg.colisiónDeDriversDupesjoin`, `Colisión de drivers: ${dupes.join(', ')} — un driver TMC2160 no puede mover dos ejes a la vez. Revisa M584 en CONFIGURACIÓN → Motores y asigna cada eje a un driver distinto (P0, P1, P2, …). Si dudas del mapeo correcto, abre el .g CONFIGURACIÓN → "Ver config.g" y busca la línea M584 X… Y… Z…; esos son los drivers actuales.`, { "dupes.join(', ')": dupes.join(', ') }), 'err');
        return { content, ok: false };
      }
      // A§11 (15-sep). Dos defectos, los dos con la maquina de por medio:
      //  1. el candidato PREFERIDO para el eje A era el driver 4, y config.g:56
      //     avisa por escrito de que la Scylla V1.0 solo tiene P0-P3 y de que
      //     declarar P4 da «Driver 4 not present», que puede ABORTAR config.g
      //     entero — es decir, dejar la maquina sin calibracion al arrancar;
      //  2. con el eje A apagado se reescribia la linea con `A-1`, y que RRF
      //     3.5.4 acepte ese token no esta verificado (PENDIENTE BANCO): si lo
      //     rechaza, se aplica el mapeo por defecto y los ejes salen cambiados.
      // Ahora: solo P0-P3, respetando los drivers vetados de esta maquina
      // (`; rotech-banned-drivers=` en config-machine.g — la placa vieja de Sergi tenia el
      // P0 quemado), y si no queda ninguno libre se ABORTA en vez de inventar
      // un driver. Con A apagado no se toca el token A: se escribe la linea sin el.
      const usedDrvs = new Set([xDrv, yDrv, zDrv]);
      const _banned = (typeof parseBannedDrivers === `function`)
        ? parseBannedDrivers(content).drivers : new Set();
      // `drivers` de parseBannedDrivers es un Set de NUMEROS (config-persist.js:772);
      // los xDrv/yDrv/zDrv de aqui son STRINGS del regex. Comparar sin convertir
      // dejaba el veto en no-op silencioso, justo en la maquina que tiene un
      // driver quemado. El guard de M569 (mas arriba) ya usa parseInt por eso.
      const aDrv = ['0', '1', '2', '3'].find((d) => !usedDrvs.has(d) && !_banned.has(Number(d)));
      let m584cmd = '';
      if (aMode === 'off') {
        m584cmd = `M584 X${xDrv} Y${yDrv} Z${zDrv}`;
      } else if (!aDrv) {
        toast(t(`msg.m584SinDriverLibre`,
          `No queda ningún driver libre (P0-P3) para el eje A: X, Y y Z ya ocupan los disponibles en esta placa. La Scylla V1.0 no tiene driver P4. Libera un eje o revisa '; rotech-banned-drivers=' en config-machine.g.`), `err`);
        return { content, ok: false };
      } else if (aMode === 'slave') {
        m584cmd = `M584 X${xDrv} Y${yDrv}:${aDrv} Z${zDrv}`;
      } else if (aMode === 'rotary') {
        m584cmd = `M584 X${xDrv} Y${yDrv} Z${zDrv} A${aDrv}`;
      }
      if (!m584cmd) return { content, ok: true, needsReboot: false };
      // Persistir en `content` (= _cfgRaw). NO push a rtCmds — reboot guiado.
      content = cfgReplaceLine(content, 'M584 ', m584cmd + `  ; Asignación ejes → modo A: ${aMode}`);
      return { content, ok: true, needsReboot: true };
    },
  },

  // ── M208: soft limits (2 líneas: S1=min, S0=max) + toggle global M564 S ──
  // Sin toggles por eje — el toggle global mcfgSoftLimits controla M564 S
  // (si el firmware aplica los límites). Los valores M208 siempre se escriben
  // con los valores reales del formulario.
  M208: {
    ids: ['mcfgSlX0','mcfgSlX1',
          'mcfgSlY0','mcfgSlY1',
          'mcfgSlZ0','mcfgSlZ1'],
    customPopulate: ({ lines }) => {
      const find = (re) => lines.find((l) => re.test(l)) || '';
      const m208min = find(/^M208.*S1/), m208max = find(/^M208.*S0/);
      // FIX H-2-01-bis (campaña t_668de252): el formato de M208 con soft-limits
      // es `M208 X{min}:{max} Y{min}:{max} Z{min}:{max} S{n}`. cfgGet extrae el
      // PRIMER número de cada eje (`X0:530` → `0`), así que sin este parse
      // específico los inputs mcfgSlX0/mcfgSlX1, mcfgSlY0/mcfgSlY1,
      // mcfgSlZ0/mcfgSlZ1 acababan con el mismo valor (Xmin=Xmax=X0) y el SVG
      // de volumen salía degenerado. Además, en el Save de Fase 4.4 los ejes
      // Y y Z disparaban la validación min>=max en cuanto el operario cambiaba
      // SOLO uno de los seis campos (e2e-primer-arranque-virgen.spec.js:1-B).
      // El parse correcto divide por eje (X/Y/Z) y luego extrae el lado
      // izquierdo del rango (`min`) y el derecho (`max`) del literal.
      const parseMinMaxRange = (line, ax) => {
        const m = line?.match(new RegExp(`\\b${ax}(-?[\\d.]+):(-?[\\d.]+)\\b`));
        if (m) return { min: m[1], max: m[2] };
        // Fallback defensivo: línea en formato valor único (no rango). La
        // rama 1196-1205 sigue funcionando con cualquier formato, así que esto
        // solo mejora la población del formulario.
        const single = line?.match(new RegExp(`\\b${ax}(-?[\\d.]+)\\b`));
        return single ? { min: single[1], max: single[1] } : { min: '', max: '' };
      };
      ['X','Y','Z'].forEach((ax) => {
        const rMin = parseMinMaxRange(m208min, ax);
        const rMax = parseMinMaxRange(m208max, ax);
        // Las dos líneas M208 del firmware traen los MISMOS pares
        // (X0:530 X0:530) — los rangos se duplican en S0 y S1. Por
        // uniformidad y para no perder datos al hacer Save, si la línea S1
        // trae el rango y la S0 también (caso típico), leemos de S1 para
        // Xmin/Ymin/Zmin y de S0 para Xmax/Ymax/Zmax, como hace RRF al
        // aplicarlos (S1 = mínimo global del eje, S0 = máximo global).
        setVal(`mcfgSl${ax}0`, rMin.min);
        setVal(`mcfgSl${ax}1`, rMax.max);
      });
      const wx = parseFloat(parseMinMaxRange(m208max, 'X').max) || 500;
      const wy = parseFloat(parseMinMaxRange(m208max, 'Y').max) || 400;
      if (typeof VIZ !== 'undefined') { VIZ.workLimits = { x: wx, y: wy }; VIZ.dirty = true; }
      // t_080e0a9d (Fase 4.4 resto, 2026-09-02): pinta el badge HOME + SVG
      // de volumen al cargar la pestaña. Idempotente: si los elementos no
      // están en DOM (modal no abierto) retorna sin error.
      refreshSoftLimitsUI();
      // t_080e0a9d: cada cambio en un input repinta el SVG al vuelo. NO
      // esperamos al save — así el operario ve cómo su edición mueve el
      // rectángulo antes de pulsar Guardar.
      ['X','Y','Z'].forEach((ax) => {
        ['0','1'].forEach((side) => {
          const elIn = $(`mcfgSl${ax}${side}`);
          if (!elIn) return;
          elIn.oninput = () => renderSoftLimitsVolume();
        });
      });
      // APLICACIÓN INSTANTÁNEA por campo (fix del bug "cambio X Max y no se
      // guarda"): cada onchange persiste M208 + aplica en caliente, sin
      // depender del botón Guardar ni de qué pestaña esté activa. Asignamos
      // .onchange directamente: idempotente entre populates, no se acumula.
      ['X','Y','Z'].forEach((ax) => {
        ['0','1'].forEach((side) => {
          const el = $(`mcfgSl${ax}${side}`);
          if (!el) return;
          el.onchange = () => cfgEnCola(() => _applyM208Instant(ax, side === '1' ? 'max' : 'min', el.value));
        });
      });
      // safe_clearance (altura Z segura para park/goto0/probe3d) — instantáneo.
      const elSC = $(`mcfgSafeClearance`);
      if (elSC) {
        const scLine = find(/^global safe_clearance\s*=/);
        const scVal = scLine ? parseFloat(scLine.match(/=\s*([\d.]+)/)?.[1]) : 10;
        if (isFinite(scVal)) elSC.value = scVal;
        elSC.onchange = () => {
          const v = parseFloat(elSC.value);
          const errSC = hwCheck(`Altura de seguridad`, v, HW_LIMITS.safeClear, ' mm');
          if (errSC) { toast(errSC, `err`); return; }
          cfgPersistGlobalLine(`safe_clearance`,
            `global safe_clearance = ${v}  ; Distancia Z segura para despejar fresa (mm)`);
          RRF.gcode(`set global.safe_clearance = ${v}`);
          toast(t(`msg.alturaZDeSeguridad`, `Altura Z de seguridad → ${v} mm`, { "v": v }), `info`);
          log(`safe_clearance → ${v} (instantáneo)`, `sys`);
        };
      }
    },
    customSave: async ({ content, rtCmds }) => {
      // FIX H-4-04 (carril 4, BLOQUEANTE): el operario que vacía un input
      // (mcfgSlX1 = '') caía a '0' por el `|| '0'` y se escribía M208 X0…
      // aceptando una "jaula" de un solo punto. Rechazar vacío ANTES de
      // componer la línea: si CUALQUIER min/max viene vacío, toast rojo y
      // flujo abortado (ok=false → caller lanza Error('validation')).
      const _emptyFields = [];
      ['X','Y','Z'].forEach((ax) => {
        if ($(`mcfgSl${ax}0`).value === '') _emptyFields.push(`${ax} min`);
        if ($(`mcfgSl${ax}1`).value === '') _emptyFields.push(`${ax} max`);
      });
      if (_emptyFields.length) {
        toast(t(`msg.softLimitVacioNo`, `Soft limit: los campos ${_emptyFields.join(', ')} no pueden estar vacíos. Si quieres desactivar el límite del eje, bórralo de config-machine.g con el editor de archivos.`, { fields: _emptyFields.join(', ') }), `err`);
        return { content, ok: false };
      }
      // ── FIX Fase 4.4 (carril 4, BLOQUEANTE — hallazgo F matriz-coherencia
      // 2026-09-01): validar min < max por eje. _applyM208Instant ya hacía
      // este check sobre el delta unitario (línea 244), pero el botón Guardar
      // NO — el operario podía teclear X min=600 / X max=500 y el formulario
      // aceptaba el soft limit invertido. M208 con min > max NO protege el
      // eje (cualquier movimiento aborta al instante por soft limit violado).
      // Z es el caso CARO: signo invertido baja la fresa contra la mesa.
      // Guardamos los 6 valores YA VALIDADOS para reusarlos abajo.
      const vals = {};
      let _invAxis = null;
      ['X','Y','Z'].forEach((ax) => {
        const mn = parseFloat($(`mcfgSl${ax}0`).value);
        const mx = parseFloat($(`mcfgSl${ax}1`).value);
        vals[ax] = { min: mn, max: mx };
        if (isFinite(mn) && isFinite(mx) && mn >= mx) _invAxis = ax;
      });
      if (_invAxis) {
        toast(t(
          `msg.softLimitInvRange${_invAxis}`,
          `Soft limit ${_invAxis}: el mínimo (${vals[_invAxis].min}) debe ser MENOR que el máximo (${vals[_invAxis].max}). M208 con min ≥ max no protege el eje.`,
        ), `err`);
        return { content, ok: false };
      }
      // Safety adicional: si algún valor NO es finito (NaN, Infinity por
      // algún parseo raro), abortamos aquí. Si pasara, el template literal
      // abajo escribiría "XNaN" en config-machine.g y el firmware rechazaría
      // M208 con mensaje críptico al rearrancar.
      for (const ax of ['X', 'Y', 'Z']) {
        if (!isFinite(vals[ax].min) || !isFinite(vals[ax].max)) {
          toast(t(`msg.softLimitInvRange${ax}`,
            `Soft limit ${ax}: valor no numérico (mín=${vals[ax].min}, máx=${vals[ax].max}). Revisa el formulario.`),
            `err`);
          return { content, ok: false };
        }
      }
      // ── FIX Fase 4.4: confirmar si la posición ACTUAL queda fuera del
      // nuevo rango. A diferencia del check de min<max (BLOQUEANTE), este
      // es CONSULTIVO: el operario puede querer reducir el área y mover
      // manualmente después. Pero SI la posición cae fuera, el siguiente
      // jog aborta con "outside soft limit" sin entender por qué. Por eso
      // pedimos confirmación explícita con el detalle de QUÉ eje está fuera.
      //
      // Fail-quiet: si AppState.cache.machinePos no existe (mock-server,
      // primera conexión), NO pedimos confirmación — no sabemos si está
      // fuera. El operario verá el resultado al guardar.
      if (typeof AppState !== `undefined` && AppState.cache && AppState.cache.machinePos) {
        const _mp = AppState.cache.machinePos;
        const _out = [];
        ['X','Y','Z'].forEach((ax) => {
          const pos = parseFloat(_mp[ax]);
          const mn = vals[ax].min, mx = vals[ax].max;
          if (!isFinite(pos) || !isFinite(mn) || !isFinite(mx)) return;
          if (pos < mn || pos > mx) _out.push({ ax, pos, mn, mx });
        });
        if (_out.length) {
          const _lines = _out.map((o) => {
            const side = o.pos < o.mn ? `<` : `>`;
            return `${o.ax}: pos=${o.pos} ${side} [${o.mn}..${o.mx}]`;
          }).join(' · ');
          const _title = t(`msg.softLimitPosOutTitle`, `La posición actual queda fuera del nuevo rango`);
          const _body = t(
            `msg.softLimitPosOutBody`,
            `Si guardas, la máquina no podrá moverse hasta que hagas HOME otra vez.\n\n${_lines}\n\n¿Guardar igualmente?`,
            { axes: _lines },
          );
          // customSave es async para poder hacer await del modal.
          // El caller (handler Guardar) ya aborta con `throw Error('validation')`
          // si ok===false, así que cancelar → ok=false → caller aborta el flujo
          // completo y deja los inputs del usuario intactos.
          //
          // Fallback: si por la razón que sea confirmDialog no está disponible
          // (modo degradado, mock-server sin UI), ABORTAMOS en vez de seguir.
          // Sin aviso al operario es mejor que aceptar un cambio peligroso.
          if (typeof confirmDialog !== `function`) return { content, ok: false };
          const ok = await confirmDialog(_title, _body);
          if (!ok) return { content, ok: false };
        }
      }
      // ── Construir las líneas M208 — los valores ya están validados ──
      // El bucle de validación min<max arriba (FIX Fase 4.4) ya pobló
      // `vals[ax] = { min: <number>, max: <number> }` a partir de los inputs.
      // Antes había aquí `vals[ax] = { min: $(…).value || '0', max: … }` —
      // lo eliminamos: el `|| '0'` enmascaraba el bug de inputs vacíos
      // (FIX H-4-04 ya lo atrapa arriba con `ok=false` antes de llegar aquí)
      // y los números que tenemos son más seguros que strings (toString en
      // template literal hace lo correcto).
      // NO-OP: vals ya está poblado por el bucle de validación.
      const aMode = $q('input[name="axisAMode"]:checked')?.value || 'off';
      const aActive = aMode !== 'off';
      const oldMin = content.split('\n').find((l) => /^M208.*S1/.test(l)) || '';
      const oldMax = content.split('\n').find((l) => /^M208.*S0/.test(l)) || '';
      const aMin = cfgGet(oldMin, 'A') || '0';
      const aMax = cfgGet(oldMax, 'A') || '0';
      const newMin = `M208 X${vals.X.min} Y${vals.Y.min} Z${vals.Z.min}${aActive ? ' A' + aMin : ''} S1`;
      const newMax = `M208 X${vals.X.max} Y${vals.Y.max} Z${vals.Z.max}${aActive ? ' A' + aMax : ''} S0`;
      // FIX: NO usar cfgReplaceLine con 'M208.*S1' — el escape de cfgReplaceLine
      // convierte .* a literal \.\* y NUNCA casa → duplica líneas en cada save.
      // Reemplazar usando regex real (no escapada) directamente.
      // FIX H-2-01: si la línea NO existe hay que AÑADIRLA. String.replace sin
      // coincidencia devuelve el original sin avisar: en un config-machine.g sin
      // M208 (máquina virgen, que es justo el primer calibrado del cliente) los
      // soft limits se perdían en silencio y el Guardar decía que había ido bien.
      const _reMin = /^M208\b[^\n]*\bS1\b[^\n]*/m;
      const _reMax = /^M208\b[^\n]*\bS0\b[^\n]*/m;
      const _lineMin = newMin + '  ; Mínimos';
      const _lineMax = newMax + '  ; Máximos';
      // FIX H-2-01: si la línea NO existe hay que AÑADIRLA. String.replace sin
      // coincidencia devuelve el original sin avisar: en un config-machine.g sin
      // M208 (máquina virgen, que es justo el primer calibrado del cliente) los
      // soft limits se perdían en silencio y el Guardar decía que había ido bien.
      // Demostrado por la mutación de prueba de t_668de252 (2026-09-02): quitar
      // la rama append hace caer en rojo los specs "soft-limits-virgen" del
      // persistencia y "1-B" del primer-arranque-virgen.
      content = _reMin.test(content)
        ? content.replace(_reMin, _lineMin)
        : content.replace(/\n*$/, '\n') + _lineMin + '\n';
      content = _reMax.test(content)
        ? content.replace(_reMax, _lineMax)
        : content.replace(/\n*$/, '\n') + _lineMax + '\n';
      rtCmds.push(newMin, newMax);
      // Actualizar caché _softLimits INMEDIATAMENTE para que el jog JS
      // use los valores nuevos sin esperar al siguiente poll con d99.
      ['X','Y','Z'].forEach((ax) => {
        if (!_softLimits[ax]) return;
        _softLimits[ax].min = parseFloat(vals[ax].min);
        _softLimits[ax].max = parseFloat(vals[ax].max);
      });
      // Soft limits — FUENTE ÚNICA DE VERDAD: global.softLimitsOn.
      // config.g aplica `M564 S{global.softLimitsOn ? 1 : 0}` al arrancar y homeall.g
      // hace lo mismo tras homing. Por eso aquí NO reescribimos la línea M564 de
      // config.g (la dejaríamos hardcoded y volvería a divergir del global). Solo
      // actualizamos el global + aplicamos en vivo con `M564 S` (sin tocar H).
      const softLimEl = $(`mcfgSoftLimits`);
      if (softLimEl) {
        const sVal = softLimEl.checked ? 1 : 0;
        _softLimitsEnabled = !!sVal;
        const slBool = sVal ? 'true' : 'false';
        content = cfgSetGlobal(content, 'softLimitsOn', slBool);
        rtCmds.push(`set global.softLimitsOn = ${slBool}`);
        rtCmds.push(`M564 S${sVal}`);   // aplicar en vivo (solo S, preserva H)
      }
      // Actualizar VIZ si está presente
      if (typeof VIZ !== 'undefined') {
        VIZ.workLimits = {
          x: parseFloat(vals.X.max) || 500,
          y: parseFloat(vals.Y.max) || 400,
        };
        VIZ.dirty = true;
      }
      return { content, ok: true };
    },
  },

  // ── SPINDLE: M950 R0 (modo PWM/relay/modbus/laser) + rotech-spindle-ramp ──
  // La línea M950 R0 tiene forma variable según modo:
  //   PWM:    M950 R0 C"pins" Q{freq} L{min}:{max}
    //   Relay:  M950 R0 C"D.5"            ; Relé mecánico 220V (PD5 → RRF D.5)
    //   Modbus: M950 R0 C"uart0" Q{addr} L{min}:{max}   ; PENDIENTE BANCO: uart0
    //         es el puerto serie principal (USB) — choca con DWC. El pin correcto
    //         en Scylla es uart1 con serial.aux.rxTxPins={A.10,A.9} (RS485
    //         hardware), pero eso entra en conflicto con RotechOS Touch (P1,
    //         D.9/D.8). Sergi debe decidir qué dispositivo comparte el aux.
    //   Laser:  M950 R0 C"B.1+C.5" Q10000 L{pmin}:100
    //           SPD (B.1) emite PWM/TTL con jumper "Speed-OUT" en DO;
    //           SP-EN (C.5) sirve de habilitación de seguridad (lo apaga M5).
    //           Rango 0-100 = porcentaje de potencia, NO RPM. (t_028bceef, sep-2026)
  // El ramp se persiste como `; rotech-spindle-ramp={secs}`.
  // NOTA: mist/cool y SAC comparten el tab spindle pero no se migran aquí
  // (SAC ya está en cfgFieldsSaveByPrefix, mist/cool son 2 bloques triviales).
  //
  // FIX t_ef4d529c: el modo Relay antes escribía `exp.heater3` (pin de la
  // placa de expansión Duet3, que la Scylla NO tiene). Corregido a `D.5`,
  // que es el pin documentado en HARDWARE_SCYLLA_V1_OFICIAL.md §5 y en el
  // mapa de pines UI (index.html "Relé Mecánico (220V) · PD5 · RRF: D.5").
  SPINDLE: {
    ids: ['mcfgSpindleMin','mcfgSpindleMax','mcfgSpindleRamp','mcfgLaserMin','mcfgLaserMax'],
    customPopulate: ({ lines }) => {
      const find = (re) => lines.find((l) => re.test(l)) || '';
      const m950s = find(/^M950 R0\b/);
      const lMatch = m950s.match(/L([\d.]+):([\d.]+)/);
      const qMatch = m950s.match(/Q([\d.]+)/);
      const cMatch = m950s.match(/C"([^"]+)"/);
      setVal('mcfgSpindleMin', lMatch ? lMatch[1] : '');
      setVal('mcfgSpindleMax', lMatch ? lMatch[2] : (qMatch ? qMatch[1] : ''));
      const spMin = parseFloat(lMatch ? lMatch[1] : '');
      const spMax = parseFloat(lMatch ? lMatch[2] : qMatch ? qMatch[1] : '');
      if (spMin > 0) CFG.spindleMin = spMin;
      if (spMax > 0) CFG.maxRPM = spMax;
      // Detectar modo. Orden importante:
      //   1. laser: M950 R0 ... C"B.1+C.5" (sin B.0) — pines SPD+SP-EN
      //   2. modbus: M950 R0 ... C"uart..." — RS485
      //   3. relay: M950 R0 sin Q y sin L (la línea M950 está presente)
      //   4. pwm: cualquier otro caso (fallback)
      let detectedMode = 'pwm';
      const cPins = cMatch ? cMatch[1].toUpperCase().replace(/\s+/g, '') : '';
      if (cPins === 'B.1+C.5' && !/\+B\.0/i.test(cPins)) detectedMode = 'laser';
      else if (m950s.includes('uart')) detectedMode = 'modbus';
      else if (!lMatch && !qMatch && m950s.includes('M950 R0')) detectedMode = 'relay';
      if (/^set global\.spindleManual\s*=\s*true/m.test(lines.join('\n'))) detectedMode = 'manual';
      const modeRadio = $q(`input[name="spindleMode"][value="${detectedMode}"]`);
      if (modeRadio) { modeRadio.checked = true; updateSpindleModeCards(); }
      // Si detectamos láser y la línea tiene L0:100, lo replicamos en los
      // inputs visibles del modo láser para que la pestaña refleje el estado.
      if (detectedMode === 'laser' && lMatch) {
        setVal('mcfgLaserMin', lMatch[1]);
        setVal('mcfgLaserMax', lMatch[2]);
      }
      // Ramp (persistido como comentario)
      const rampVal = find(/; rotech-spindle-ramp=/).match(/rotech-spindle-ramp=([\d.]+)/)?.[1];
      setVal('mcfgSpindleRamp', rampVal || '3');
      CFG.spindleRamp = parseFloat(rampVal) || 0;
      // Persistir el modo en CFG para que el resto de la UI (cockpit/pendant)
      // pueda cambiar los textos de "RPM" a "Potencia (%)" sin re-leer config.g.
      CFG.spindleMode = detectedMode;
      // 27-sep (análisis de la interfaz, M1; decisión de Sergi): se retiran los interruptores de
      // neblina (M7) y refrigerante (M8). Solo guardaban un comentario que nada volvía a leer, y RRF
      // 3.5.4 no implementa M7/M8/M9 (no hay su `case` en GCodes2.cpp): no encendían nada.
    },
    customSave: ({ content, rtCmds }) => {
      const mode = $q('input[name="spindleMode"]:checked')?.value || 'pwm';
      // Manual (Makita): M950 intacto (los M3/M5 del CAM no deben dar error); lo sabe la interfaz.
      const man = mode === 'manual';
      const cl = globalThis.document?.body?.classList;
      if (cl && man !== cl.contains('spindle-manual')) {
        cfgPersistGlobalLine('spindleManual', `set global.spindleManual = ${man}`);
        rtCmds.push(`set global.spindleManual = ${man}`);
        cl.toggle('spindle-manual', man);
      }
      if (man) { CFG.spindleMode = mode; return { content, ok: true }; }
      // LÁSER (t_028bceef): rango 0-100 = porcentaje de potencia, NO RPM.
      // Los inputs mcfgLaserMin / mcfgLaserMax se muestran solo en modo láser
      // (JS los enseña/oculta según radio). No se aplica el clamp 6000-24000.
      if (mode === 'laser') {
        let lmin = parseInt($('mcfgLaserMin').value);
        let lmax = parseInt($('mcfgLaserMax').value);
        if (!Number.isFinite(lmin) || lmin < 0 || lmin > 100
            || !Number.isFinite(lmax) || lmax < 0 || lmax > 100) {
          toast(t(`msg.laserRangoInvalido`, 'Potencia láser: rango 0–100 (%) obligatorio'), 'err');
          return { content, ok: false };
        }
        if (lmin >= lmax) {
          toast(t(`msg.laserMinDebeMenorMax`, `Potencia láser mínima (${lmin}) debe ser menor que máxima (${lmax})`, { mn: lmin, mx: lmax }), 'err');
          return { content, ok: false };
        }
        // Limpia los inputs RPM visibles (no se usan en láser) para que no
        // contaminen lecturas futuras si el operario cambia de modo sin recargar.
        setVal('mcfgSpindleMin', '');
        setVal('mcfgSpindleMax', '');
        CFG.spindleMin = lmin;
        CFG.maxRPM = lmax;
        CFG.spindleMode = 'laser';
        const newM950 = `M950 R0 C"B.1+C.5" Q10000 L${lmin}:100`;
        content = cfgReplaceLine(content, 'M950 R0 ', newM950 + '  ; Spindle Laser (SPD+SP-EN)');
        rtCmds.push(newM950);
        // El ramp de software (G4) NO tiene sentido físico para láser
        // (encendido/apagado instantáneo). Forzamos 0 y limpiamos el comentario.
        content = cfgReplaceLine(content, '; rotech-spindle-ramp=', '; rotech-spindle-ramp=0');
        if (!content.includes('; rotech-spindle-ramp=')) content += `\n; rotech-spindle-ramp=0`;
        CFG.spindleRamp = 0;
        return { content, ok: true };
      }
      let mn = parseInt($('mcfgSpindleMin').value) || 0;
      let mx = parseInt($('mcfgSpindleMax').value) || 0;
      if (!mn || !mx) {
        toast(t(`msg.introduceVelocidadMinimaY`, 'Introduce velocidad minima y maxima'), 'warn');
        return { content, ok: false };
      }
      // Clamp al rango seguro del spindle air-cooled
      if (mn < 6000)  { mn = 6000;  $('mcfgSpindleMin').value = mn; toast(t(`msg.rpmMinimoAjustadoA`, 'RPM mínimo ajustado a 6000 (seguridad del husillo)'), 'warn'); }
      if (mx > 24000) { mx = 24000; $('mcfgSpindleMax').value = mx; toast(t(`msg.rpmMaximoAjustadoA`, 'RPM máximo ajustado a 24000 (límite del husillo)'), 'warn'); }
      if (mn >= mx) {
        toast(t(`msg.rpmMinimoMnDebe`, `RPM mínimo (${mn}) debe ser menor que máximo (${mx})`, { "mn": mn, "mx": mx }), 'err');
        return { content, ok: false };
      }
      // FIX H-4-03 (carril 4): el input `max=60 atributo HTML` no se aplica al
      // save (parseFloat + || 0 silenciaba NaN). Si devtools pone 9999, se
      // persistía ; rotech-spindle-ramp=9999. Clamp defensivo al rango seguro
      // (0-60s de rampa — más de eso no es razonable para un spindle air-cooled).
      let ramp = parseFloat($('mcfgSpindleRamp').value);
      if (!isFinite(ramp) || ramp < 0) { ramp = 0; $('mcfgSpindleRamp').value = 0; }
      if (ramp > 60) { toast(t(`msg.rampSpindleClampeadoA`, `Rampa del husillo ${ramp}s fuera de rango, ajustado a 60s (techo seguro)`, { "ramp": ramp }), `warn`); ramp = 60; $('mcfgSpindleRamp').value = 60; }
      let newM950 = '';
      const _ex = content.split('\n').find((l) => /^M950 R0\b/.test(l)) || '';
      const _cm = _ex.match(/C"([^"]+)"/);
      const _qm = _ex.match(/Q([\d.]+)/);
      if (mode === 'pwm') {
        const cp = _cm ? _cm[1] : 'B.1+C.5+B.0';
        const qp = _qm ? _qm[1] : '10000';
        newM950 = `M950 R0 C"${cp}" Q${qp} L${mn}:${mx}`;
        content = cfgReplaceLine(content, 'M950 R0 ', newM950 + '  ; Spindle PWM');
      } else if (mode === 'relay') {
        // FIX t_ef4d529c: el pin del relé mecánico 220V en BTT Scylla V1.0 es
        // PD5 → "D.5" (HARDWARE_SCYLLA_V1_OFICIAL.md §5 + UI pin map).
        // Antes escribía exp.heater3 (pin de placa expansión Duet3, no existe
        // en la Scylla — el firmware aborta con "unknown pin").
        newM950 = 'M950 R0 C"D.5"';
        content = cfgReplaceLine(content, 'M950 R0 ', newM950 + '  ; Spindle rele ON/OFF (Relé mecánico 220V en D.5)');
      } else if (mode === 'modbus') {
        const qp = _qm ? _qm[1] : '1';
        newM950 = `M950 R0 C"uart0" Q${qp} L${mn}:${mx}`;
        content = cfgReplaceLine(content, 'M950 R0 ', newM950 + '  ; Spindle Modbus/RS485');
      }
      if (newM950) rtCmds.push(newM950);
      // Ramp (comentario persistido)
      content = cfgReplaceLine(content, '; rotech-spindle-ramp=', `; rotech-spindle-ramp=${ramp}`);
      if (!content.includes('; rotech-spindle-ramp=')) content += `\n; rotech-spindle-ramp=${ramp}`;
      CFG.spindleRamp = ramp || 0;
      CFG.spindleMode = mode;
      if (mx > 0) CFG.maxRPM = mx;
      if (mn > 0) CFG.spindleMin = mn;
      return { content, ok: true };
    },
  },

  // ── PROBE: M558 (declaración de la sonda) + G31 (offset XYZ) — t_9b49c0a4 ────
  // Persiste en config-machine.g (calibración per-máquina) como ya hace M92,
  // M906, M208 y G31. NO en config.g — la OTA puede reescribir config.g sin
  // perder la sonda calibrada del cliente.
  //
  // customSave/customPopulate maneja las DOS líneas juntas (M558 y G31) porque
  // están íntimamente ligadas: el offset XYZ sin la declaración del pin no
  // significa nada, y al editar la sonda en la UI el operario espera ver
  // ambos valores a la vez.
  //
  // El campo Z va con aviso destacado: un signo invertido clava la fresa
  // contra la mesa. Se valida rango y se entrega un toast claro si se sale.
  //
  // Conflicto de pin con CFG_GPIO_MAP: si el cliente pone el pin de la sonda
  // en un pin ya usado por un endstop X/Y/Z (D.11, C.6, A.8, D.14, C.7, D.12),
  // se avisa con el nombre del endstop que lo reclama.
  PROBE: {
    ids: ['mcfgM558P','mcfgM558C','mcfgM558H','mcfgM558F','mcfgM558T',
          'mcfgM558G31P','mcfgG31X','mcfgG31Y','mcfgG31Z'],
    customPopulate: ({ lines }) => {
      // M558 y G31 — leemos de la ÚLTIMA ocurrencia (config-machine.g pisa
      // a config.g). El merged ya está en lines, así que findLast sería
      // ideal pero `lines.find` da la primera; en la práctica, config.g
      // tiene la línea M558/G31 y config-machine.g puede tener su propio
      // G31 override — el find devuelve la primera (config.g) si no usamos
      // findLast. El cfgPopulate ya llama a lines.findLast y luego
      // lines.find como fallback (rotechos-config-modal.js:2096); recibimos
      // el `lines` ya ordenado, así que basta con find().
      const m558 = lines.find((l) => /^M558\b/.test(l)) || '';
      const g31  = lines.find((l) => /^G31\b/.test(l)) || '';

      // M558 P (tipo): regex acepta P5, P8, etc.
      const pM = m558.match(/\bP(\d+)/);
      if (pM) setVal('mcfgM558P', pM[1]);
      // M558 C"…": pin con modificadores ^ y !. RRF acepta C"^!E.7" o C"!E.7".
      const cM = m558.match(/C"([^"]+)"/);
      if (cM) setVal('mcfgM558C', cM[1]);
      // M558 H/F/T
      const hM = m558.match(/\bH(\d+(?:\.\d+)?)/);
      if (hM) setVal('mcfgM558H', hM[1]);
      const fM = m558.match(/\bF(\d+(?:\.\d+)?)/);
      if (fM) setVal('mcfgM558F', fM[1]);
      const tM = m558.match(/\bT(\d+(?:\.\d+)?)/);
      if (tM) setVal('mcfgM558T', tM[1]);

      // G31 P (valor de disparo) y X/Y/Z (offset). cfgGet extrae el primer
      // número tras el eje, así que X12.5 → "12.5". Para Z aceptamos negativos
      // (cfgGet ya soporta -?[\d.]+).
      setVal('mcfgM558G31P', cfgGet(g31, 'P') || '500');
      setVal('mcfgG31X', cfgGet(g31, 'X') || '0');
      setVal('mcfgG31Y', cfgGet(g31, 'Y') || '0');
      // Z puede ser negativo — leer directo de la regex con captura de signo
      const zM = g31.match(/\bZ(-?\d+(?:\.\d+)?)/);
      if (zM) setVal('mcfgG31Z', zM[1]);
    },
    customSave: ({ content, rtCmds }) => {
      // ── 1. Validar que los 9 campos son numéricos cuando proceda ────────
      const elP = $('mcfgM558P');
      const elC = $('mcfgM558C');
      const elH = $('mcfgM558H');
      const elF = $('mcfgM558F');
      const elT = $('mcfgM558T');
      const elGP = $('mcfgM558G31P');
      const elGX = $('mcfgG31X');
      const elGY = $('mcfgG31Y');
      const elGZ = $('mcfgG31Z');
      if (!elP || !elC || !elH || !elF || !elT || !elGP || !elGX || !elGY || !elGZ) {
        // DOM no cargado — no debería pasar en flujo normal, pero fail-closed
        toast(t('msg.probeDeclDomMissing', 'Faltan campos de la sonda en la UI'), 'err');
        return { content, ok: false };
      }

      // P: 0–9 (RRF 3.5.4). 0 = deshabilitada.
      const pVal = parseInt(elP.value, 10);
      if (!Number.isInteger(pVal) || pVal < 0 || pVal > 9) {
        toast(t('msg.probeTipoInvalido', 'Tipo de sonda (P) inválido: debe ser 0–9'), 'err');
        elP.style.borderColor = 'var(--red)';
        return { content, ok: false };
      }
      elP.style.borderColor = '';

      // C: pin con modificadores ^ y ! opcionales. Validamos formato
      // [\^!]*[A-Z]\.\d+ (1 letra mayúscula + 1–2 dígitos).
      const cRaw = elC.value.trim();
      const cPinMatch = cRaw.match(/^([\^!]*)([A-Z])\.(\d{1,2})$/);
      if (!cPinMatch) {
        toast(t('msg.probePinFormato',
          'Pin de sonda inválido. Formato: [modificadores]LETRA.NÚMERO — p.ej. ^!E.7, !D.11. Sin # ni comas.'), 'err');
        elC.style.borderColor = 'var(--red)';
        return { content, ok: false };
      }
      elC.style.borderColor = '';
      // OJO: existe un validador estático (en tests/unit) que rechaza que
      // la UI cite un pin distinto al E.7 — el firmware solo declara E.7.
      // Los ejemplos de error usan D.11 (pin de endstop X-MIN, ya en
      // CFG_GPIO_MAP) para evitar el falso positivo del invariante.
      const cPin = cPinMatch[2] + '.' + cPinMatch[3]; // ej "E.7" (sin modificadores — los re-añadimos en el formato)
      const cMods = cPinMatch[1]; // "^", "!", "^!" o ""

      // H, F, T: rangos seguros
      const hErr = hwCheck('M558 H (dive height)', elH.value, { min: 1, max: 50 }, ' mm');
      if (hErr) { toast(hErr, 'err'); elH.style.borderColor = 'var(--red)'; return { content, ok: false }; }
      elH.style.borderColor = '';
      const fErr = hwCheck('M558 F (velocidad sondeo)', elF.value, { min: 10, max: 3000 }, ' mm/min');
      if (fErr) { toast(fErr, 'err'); elF.style.borderColor = 'var(--red)'; return { content, ok: false }; }
      elF.style.borderColor = '';
      const tErr = hwCheck('M558 T (timeout sondeo)', elT.value, { min: 1000, max: 30000 }, ' ms');
      if (tErr) { toast(tErr, 'err'); elT.style.borderColor = 'var(--red)'; return { content, ok: false }; }
      elT.style.borderColor = '';

      // G31 P/X/Y/Z
      const gpVal = parseInt(elGP.value, 10);
      if (!Number.isFinite(gpVal) || gpVal < 0 || gpVal > 10000) {
        toast(t('msg.probeG31PInvalido', 'G31 P (valor de disparo) debe estar entre 0 y 10000'), 'err');
        elGP.style.borderColor = 'var(--red)';
        return { content, ok: false };
      }
      elGP.style.borderColor = '';
      const gx = parseFloat(elGX.value);
      const gy = parseFloat(elGY.value);
      const gz = parseFloat(elGZ.value);
      if (!Number.isFinite(gx) || !Number.isFinite(gy) || !Number.isFinite(gz)) {
        toast(t('msg.probeG31XYZInvalido', 'G31 X/Y/Z deben ser numéricos'), 'err');
        return { content, ok: false };
      }
      // Z es CRÍTICO — sanity de signo y rango (±50 mm cubre holguras reales).
      if (Math.abs(gz) > 50) {
        toast(t('msg.probeG31ZFuera',
          `Offset Z de la sonda fuera de rango (${gz} mm). El Z rara vez supera ±10 mm: |Z|>50 mm es casi seguro un signo invertido, no una calibración real. NO guardes sin verificar.`, { z: gz }), 'err');
        elGZ.style.borderColor = 'var(--red)';
        return { content, ok: false };
      }
      elGZ.style.borderColor = '';

      // ── 2. Conflicto de pin con CFG_GPIO_MAP ─────────────────────────────
      // Si el pin de la sonda coincide con un pin ya usado por un endstop,
      // el firmware abortará con "pin not free" al rearrancar. Avisamos con
      // el nombre del endstop que lo reclama, NO con el pin literal.
      const conflict = _probePinConflict(cPin);
      if (conflict) {
        toast(t('msg.probePinConflicto',
          `Pin ${cPin} ocupado por ${conflict}. Elige otro pin o desconecta esa función en su pestaña.`, { pin: cPin, conflict }), 'err');
        elC.style.borderColor = 'var(--red)';
        return { content, ok: false };
      }

      // ── 3. Generar líneas M558 y G31 ─────────────────────────────────────
      // M558 — pin entre comillas con modificadores preservados
      const m558Line = `M558 P${pVal} C"${cMods}${cPin}" H${parseFloat(elH.value)} F${parseFloat(elF.value)} T${parseFloat(elT.value)}  ; Sonda Z — declaración`;
      const g31Line  = `G31 P${gpVal} X${gx} Y${gy} Z${gz}  ; Offset sonda → husillo (calibrado en banco)`;

      content = cfgReplaceLine(content, 'M558 ', m558Line);
      content = cfgReplaceLine(content, 'G31 ',  g31Line);
      // Aplicar en caliente: M558 re-ejecutado en caliente es SEGURO (cambia
      // tipo/pin/H/F/T sin tocar drivers — solo reconfigura la sonda).
      // G31 también es seguro. A diferencia de M569, no resetea TMC2160.
      rtCmds.push(`M558 P${pVal} C"${cMods}${cPin}" H${parseFloat(elH.value)} F${parseFloat(elF.value)} T${parseFloat(elT.value)}`);
      rtCmds.push(`G31 P${gpVal} X${gx} Y${gy} Z${gz}`);
      // 3-oct: G38.x ignora su F y usa la de M558; sys/probe_speed.g la cambia antes de cada
      // palpado sin pasar de global.probeSpeedCap, que config.g toma de esta misma F. Sin esto,
      // el tope nuevo no valdría hasta reiniciar la placa.
      rtCmds.push(`set global.probeSpeedCap = ${parseFloat(elF.value)}`);
      return { content, ok: true };
    },
  },

  // ── M574: endstops por eje (X/Y/Z/A, lado Min y Max) + estado UI persistido ──
  // CASO ESPECIAL: 8 líneas separadas (`M574 {ax}{1|2} ...`) + 1 línea comentario
  // (`; rotech-pills=...`) + localStorage de trigLevels. Toda la generación, la
  // validación de pines (no permitir activar un lado sin pin) y el contrato con
  // _endstopCfg viven aquí.
  M574: {
    ids: ['mcfgEndPinXMin','mcfgEndPinYMin','mcfgEndPinZMin',
          'mcfgEndPinXMax','mcfgEndPinYMax','mcfgEndPinZMax',
          'mcfgEndXMinOn','mcfgEndYMinOn','mcfgEndZMinOn',
          'mcfgEndXMaxOn','mcfgEndYMaxOn','mcfgEndZMaxOn',
          'mcfgEndTypeXMin','mcfgEndTypeYMin','mcfgEndTypeZMin',
          'mcfgEndTypeXMax','mcfgEndTypeYMax','mcfgEndTypeZMax'],
    customPopulate: ({ raw, lines }) => {
      // t_b04be87e: la lógica pura que solo depende del texto de config.g (M574
      // + ; rotech-pills= → minOn/maxOn/off/trigLevel) vive ahora en
      // `window.hydrateEndstopCfg` (shim eager) — la llamamos UNA vez aquí
      // para que el modal NO la duplique. Después, este customPopulate solo
      // se ocupa de pintar el DOM (inputs, checkboxes, selects) y de avisar
      // al motor de refresco de la celda "Lectura" (updateEndstopRowState).
      // El modal manda sobre el DOM: si el operario tocó algo, sus checkboxes
      // ya están reflejados en `window._endstopCfg` por updateEndstopRowState.
      if (typeof window.hydrateEndstopCfg === `function`) window.hydrateEndstopCfg(raw);
      // Pass DOM: leer de config.g para pintar inputs (pin, side, type).
      const m574 = lines.filter((l) => /^M574\b/.test(l));
      for (const ax of ['X','Y','Z']) {
        const minL = m574.find((l) => RegExp(`^M574 ${ax}1`).test(l));
        const maxL = m574.find((l) => RegExp(`^M574 ${ax}2`).test(l));
        const rawPinMin = minL?.match(/P"([^"]+)"/)?.[1] || '';
        const rawPinMax = maxL?.match(/P"([^"]+)"/)?.[1] || '';
        const pinMin = rawPinMin.replace(/^!/, '');
        const pinMax = rawPinMax.replace(/^!/, '');
        const minActive = !!(minL && /S1\b/.test(minL));
        const maxActive = !!(maxL && /S1\b/.test(maxL));
        const isInverted = (rawPinMin || rawPinMax).startsWith('!');
        // Inputs de pin (placeholder "?" no se materializa)
        const elPinMin = $(`mcfgEndPin${ax}Min`);
        const elPinMax = $(`mcfgEndPin${ax}Max`);
        if (elPinMin) elPinMin.value = pinMin === '?' ? '' : pinMin;
        if (elPinMax) elPinMax.value = pinMax === '?' ? '' : pinMax;
        // Checkboxes Min/Max
        const elMinOn = $(`mcfgEnd${ax}MinOn`);
        const elMaxOn = $(`mcfgEnd${ax}MaxOn`);
        if (elMinOn) elMinOn.checked = minActive;
        if (elMaxOn) elMaxOn.checked = maxActive;
        // Tipo NC/NO (mismo para los dos lados del eje)
        for (const side of ['Min','Max']) {
          const typeEl = $(`mcfgEndType${ax}${side}`);
          if (typeEl) typeEl.value = isInverted ? 'NO' : 'NC';
        }
        updateEndstopRowState(ax);
      }
      // Pass 2 (DOM): reflejar el override de pills sobre las checkboxes.
      // Los minOn/maxOn/off/trigLevel ya los hidrató `hydrateEndstopCfg` arriba;
      // aquí sincronizamos el DOM (checkboxes + selects de tipo) leyendo del
      // MISMO objeto — así no duplicamos la lógica del parser y garantizamos
      // que las checkboxes siempre coincidan con `_endstopCfg` (SSOT).
      // El shim ya aplicó el orden M574→pills, así que basta con releer.
      ['X','Y','Z'].forEach((ax) => {
        if (!_endstopCfg[ax]) return;
        const elMinOn = $(`mcfgEnd${ax}MinOn`);
        const elMaxOn = $(`mcfgEnd${ax}MaxOn`);
        if (elMinOn) elMinOn.checked = !!_endstopCfg[ax].minOn;
        if (elMaxOn) elMaxOn.checked = !!_endstopCfg[ax].maxOn;
        updateEndstopRowState(ax);              // sincroniza la celda "Lectura" + dim de pines
      });
      // Selects NC/NO por lado: vienen del pills parser (formato moderno
      // tiene typeMin/typeMax separados; el legacy los pone iguales).
      const pills = typeof window.parseRotechPills === `function`
        ? window.parseRotechPills(raw)
        : parseRotechPills(raw);
      if (pills) {
        ['X','Y','Z'].forEach((ax) => {
          const p = pills[ax];
          if (!p) return;
          const elTMin = $(`mcfgEndType${ax}Min`);
          const elTMax = $(`mcfgEndType${ax}Max`);
          if (elTMin) elTMin.value = p.typeMin.toUpperCase();
          if (elTMax) elTMax.value = p.typeMax.toUpperCase();
        });
      }
    },
    customSave: ({ content, rtCmds }) => {
      // Generar líneas M574 (4 ejes × Min/Max)
      // IMPORTANTE: ejes con pines en CFG_GPIO_MAP usan M950 J + M581 (trigger mode)
      // para protección runtime. NO se debe escribir M574 con pin porque reclamaría
      // el pin del módulo GPIO y desactivaría el trigger M581. Para esos ejes, el
      // estado on/off solo afecta a los pills y al monitoring, no a M574.
      let shieldMask = 0;   // bit n = entrada Jn con sensor (ver sys/globals.g)
      let shieldNoMask = 0; // bit n = el sensor de Jn es NO (normalmente abierto)
      for (const ax of ['X','Y','Z']) {
        const elMin = $(`mcfgEndPin${ax}Min`);
        const elMax = $(`mcfgEndPin${ax}Max`);
        const minOn = $(`mcfgEnd${ax}MinOn`)?.checked ?? false;
        const maxOn = $(`mcfgEnd${ax}MaxOn`)?.checked ?? false;
        const typeNCmin = ($(`mcfgEndType${ax}Min`)?.value ?? 'NC') === 'NC';
        const typeNCmax = ($(`mcfgEndType${ax}Max`)?.value ?? 'NC') === 'NC';
        const pinMin = (elMin.value.trim() || elMin.placeholder || '').trim().replace(/^\?$/, '');
        const pinMax = (elMax.value.trim() || elMax.placeholder || '').trim().replace(/^\?$/, '');
        // ── Eje con GPIO/trigger (CFG_GPIO_MAP) → NO generar M574 con pin ──
        // El on/off se persiste en rotech-pills; M574 permanece sin endstop.
        // Los triggers M581 (registrados en config.g y recover_triggers.g) proveen
        // la protección runtime; homeall.g usa el unbinding trick para homing.
        const gpMap = CFG_GPIO_MAP[ax];
        if (gpMap) {
          // Mantener M574 X0 S1 (sin endstop permanente) — no tocar el pin
          const noEnd = `M574 ${ax}0 S1  ; ${ax} sin endstop permanente — usa M581 trigger`;
          content = cfgReplaceLine(content, `M574 ${ax}0 `, noEnd);
          // Limpiar líneas M574 {ax}1/{ax}2 espurias de saves anteriores que
          // reclamaban el pin y desactivaban el trigger M581.
          const reSpurious = RegExp(`^M574 ${ax}[12]\\b[^\\n]*`, 'gm');
          content = content.replace(reSpurious, '').replace(/\n{3,}/g, '\n\n');
          rtCmds.push(`M574 ${ax}0 S1`);
          // 28-sep (R2 de la revisión de la integración): el escudo va POR LADO. Antes se
          // armaban los dos pines de un eje si cualquiera de sus lados estaba activo, y se
          // re-registraban con `M950 J… C"D.11"` SIN el `^` del pull-up que pone
          // recover_triggers.g. Ahora solo se calcula el bit de cada lado; al final se manda
          // `set global.shieldMask` y recover_triggers.g, que es el ÚNICO que registra los
          // pines (con pull-up) y arma M581 (con S-1 en los lados sin sensor; A2, 26-sep).
          if (minOn) shieldMask |= (1 << gpMap.jMin);
          if (maxOn) shieldMask |= (1 << gpMap.jMax);
          if (!typeNCmin) shieldNoMask |= (1 << gpMap.jMin);   // NO: dispara al pasar a 0
          if (!typeNCmax) shieldNoMask |= (1 << gpMap.jMax);
          // Actualizar _endstopCfg para pills
          _endstopCfg[ax].minOn = minOn;
          _endstopCfg[ax].maxOn = maxOn;
          _endstopCfg[ax].off = !minOn && !maxOn;
          continue;
        }
        // ── Eje sin GPIO (ej: A) → generar M574 normal con pin ──
        // Validar: lado activado obliga a tener pin
        if (minOn && !pinMin) {
          elMin.style.borderColor = 'var(--red)';
          toast(t(`msg.ejeAxMinFalta`, `Eje ${ax} MIN: falta pin. Escribe el pin (ej: A.8) o usa el placeholder.`, { "ax": ax }), 'err');
          return { content, ok: false };
        }
        if (maxOn && !pinMax) {
          elMax.style.borderColor = 'var(--red)';
          toast(t(`msg.ejeAxMaxFalta`, `Eje ${ax} MAX: falta pin. Escribe el pin (ej: C.6) o usa el placeholder.`, { "ax": ax }), 'err');
          return { content, ok: false };
        }
        elMin.style.borderColor = ''; elMax.style.borderColor = '';
        // Materializar placeholder si se usa
        if (minOn && pinMin && !elMin.value.trim()) elMin.value = pinMin;
        if (maxOn && pinMax && !elMax.value.trim()) elMax.value = pinMax;
        // Generar M574 (S1 activado / S0 desactivado, prefijo `!` si NO en lugar de NC)
        const lineMin = minOn
          ? `M574 ${ax}1 S1 P"${typeNCmin ? '' : '!'}${pinMin}"  ; ${ax} min — ${typeNCmin ? 'NC' : 'NO'}`
          : (pinMin ? `M574 ${ax}1 S0 P"${pinMin}"` : `M574 ${ax}1 S0`) + `  ; ${ax} min — desactivado`;
        const lineMax = maxOn
          ? `M574 ${ax}2 S1 P"${typeNCmax ? '' : '!'}${pinMax}"  ; ${ax} max — ${typeNCmax ? 'NC' : 'NO'}`
          : (pinMax ? `M574 ${ax}2 S0 P"${pinMax}"` : `M574 ${ax}2 S0`) + `  ; ${ax} max — desactivado`;
        content = cfgReplaceLine(content, `M574 ${ax}1 `, lineMin);
        content = cfgReplaceLine(content, `M574 ${ax}2 `, lineMax);
        rtCmds.push(lineMin.split('  ')[0].trim());
        rtCmds.push(lineMax.split('  ')[0].trim());
      }
      // Persistir estado UI POR LADO en `; rotech-pills=` (SSOT en la SD).
      // Formato: ax:minOn|maxOn:typeMin|typeMax:trig  (sin localStorage).
      const pillStates = ['X','Y','Z'].map((ax) => {
        const minOn = $(`mcfgEnd${ax}MinOn`)?.checked ? 1 : 0;
        const maxOn = $(`mcfgEnd${ax}MaxOn`)?.checked ? 1 : 0;
        const typeMin = ($(`mcfgEndType${ax}Min`)?.value || 'NC').toLowerCase();
        const typeMax = ($(`mcfgEndType${ax}Max`)?.value || 'NC').toLowerCase();
        const trig = _endstopCfg[ax].trigLevel ?? (typeMax === 'no' ? 0 : 1);
        return `${ax}:${minOn}|${maxOn}:${typeMin}|${typeMax}:${trig}`;
      }).join(',');
      content = cfgReplaceLine(content, '; rotech-pills=', `; rotech-pills=${pillStates}`);
      // Lados con sensor: en vivo y en config-machine.g (es cableado de ESTA máquina; una OTA
      // puede reescribir config.g). recover_triggers.g rearma el escudo con la máscara nueva.
      rtCmds.push(`set global.shieldMask = ${shieldMask}`);
      rtCmds.push(`set global.shieldNoMask = ${shieldNoMask}`);
      rtCmds.push(`M98 P"0:/sys/recover_triggers.g"`);
      if (typeof cfgPersistGlobalLine === 'function') {
        cfgPersistGlobalLine(`shieldMask`, `set global.shieldMask = ${shieldMask}`);
        cfgPersistGlobalLine(`shieldNoMask`, `set global.shieldNoMask = ${shieldNoMask}`);
      }
      return { content, ok: true };
    },
  },
};

// ---
// Helpers que operan sobre CFG_FIELDS
// ---

/** Lee un campo desde el contenido raw de config.g y lo coloca en la UI.
 *  t_8cc28493 FASE 3.1: marca f-inherited si NO se encontro, lo quita si
 *  sí se encontro (acta t_87adb63b para fix del matcher de kind:global). */
function cfgFieldPopulate(field, raw) {
  const el = $(field.id);
  if (!el) return;
  let matcher = field.matcher;
  let lastWins = false;
  if (field.kind === 'global' && field.gName) {
    // Flag 'g' ademas de 'm': en RRF `global X = v` DECLARA y
    // `set global.X = v` ASIGNA, y pueden convivir en el mismo fichero.
    // RRF las aplica en orden, asi que el valor en efecto es el de la
    // ULTIMA linea — no el de la primera que devolveria String.match.
    matcher = new RegExp(
      `^(?:set\\s+)?global[\\s.]${field.gName.replace(/[.*+?^${}()|[\\]\\\\]/g, '\\\\$&')}\\s*=\\s*(-?[\\d.]+)`,
      'gm',
    );
    lastWins = true;
  }
  const m = lastWins ? [...raw.matchAll(matcher)].pop() : raw.match(matcher);
  if (m) {
    if (field.writeUI) field.writeUI($, m[1]);
    else el.value = m[1];
    // El valor VINO de config.g (perfil/operario) → NO es heredado
    if (typeof AppState !== 'undefined' && AppState.ui?.fieldClearInherited) {
      AppState.ui.fieldClearInherited(el);
    }
  } else {
    // El campo NO está en config.g → heredado del perfil por defecto
    if (typeof AppState !== 'undefined' && AppState.ui?.fieldMarkInherited) {
      AppState.ui.fieldMarkInherited(el);
    }
  }
}

/**
 * Guarda un campo: valida, actualiza contenido de config.g y añade rtCmd.
 * Devuelve { content, ok } — si ok=false, hay un error de validación (toast ya disparado).
 * t_8cc28493 FASE 3.1: ademas de mostrar el toast, pinta f-invalid en el
 * campo para que el operario vea QUE valor esta mal sin tener que recordar
 * el mensaje del toast. Si valida OK, quita la marca.
 */
function cfgFieldSave(field, content, rtCmds) {
  const el = $(field.id);
  if (!el) return { content, ok: true };  // campo no presente en DOM, ignorar
  // Saltar si el campo lo decide así
  if (field.skip && field.skip($)) return { content, ok: true };
  const rawVal = field.readUI ? field.readUI($) : el.value.trim();
  if (rawVal === '' || rawVal == null) return { content, ok: true };
  const value = (typeof rawVal === 'string' && !isNaN(parseFloat(rawVal))) ? parseFloat(rawVal) : rawVal;
  if (field.validate) {
    const err = field.validate(value);
    if (err) {
      // Marcar visualmente el campo como invalido (clase CSS) — pista
      // persistente que el operario ve al volver la mirada, no efimera
      // como el toast.
      if (typeof AppState !== 'undefined' && AppState.ui?.fieldMarkInvalid) {
        AppState.ui.fieldMarkInvalid(el);
      }
      toast(err, 'err');
      return { content, ok: false };
    }
    // Valido: limpiar marca (por si estaba invalid de un cambio previo)
    if (typeof AppState !== 'undefined' && AppState.ui?.fieldClearInvalid) {
      AppState.ui.fieldClearInvalid(el);
    }
  }
  const newLine = field.formatter(value);
  // Globals per-máquina → cfgSetGlobal (set global.X = value, sin redeclaración)
  // El resto (mcodes, comments) → cfgReplaceLine con su patrón
  if (field.kind === 'global') {
    content = cfgSetGlobal(content, field.gName, value);
  } else {
    content = cfgReplaceLine(content, field.pattern, newLine);
  }
  if (field.rtCmd) {
    const cmd = field.rtCmd(value);
    if (cmd) rtCmds.push(cmd);
  }
  return { content, ok: true };
}

/** Populate de todos los campos cuyo ID empieza por un prefijo (ej "mcfgSac"). */
function cfgFieldsPopulateByPrefix(prefix, raw) {
  Object.values(CFG_FIELDS)
    .filter((f) => f.id.startsWith(prefix))
    .forEach((f) => cfgFieldPopulate(f, raw));
}

/** Save de todos los campos cuyo ID empieza por un prefijo. Devuelve { content, ok }. */
function cfgFieldsSaveByPrefix(prefix, content, rtCmds) {
  const fields = Object.values(CFG_FIELDS).filter((f) => f.id && f.id.startsWith(prefix));
  for (const f of fields) {
    const r = cfgFieldSave(f, content, rtCmds);
    if (!r.ok) return r;
    content = r.content;
  }
  return { content, ok: true };
}

/**
 * Ejecuta una entrada de CFG_FIELDS con `customSave` (sin id único; agrupa
 * varios DOM IDs o requiere lógica cruzada — p.ej. M569 que son 4 líneas
 * `M569 P{n}`, o M584 que combina mapeo X/Y/Z + modo A).
 * El customSave es responsable de los toast de validación y de leer/escribir
 * todas las líneas que afecte; debe devolver { content, ok, needsReboot? }.
 */
/**
 * Resuelve una entrada por nombre en los DOS registros.
 *
 * FIX H-2-01/02 (2026-07-28): las entradas con `customSave` (M208, SPINDLE,
 * M569, M584, M574) viven en CFG_AXIS_GROUPS, no en CFG_FIELDS — CFG_FIELDS
 * solo tiene campos sueltos con id `mcfg*`. Como este runner miraba SOLO en
 * CFG_FIELDS, `cfgFieldsRunCustom` devolvía el contenido SIN TOCAR y con
 * ok:true, así que el Guardar decía que había ido bien y no persistía nada:
 * soft limits, RPM máxima del husillo, dirección de drivers (M569), mapeo de
 * ejes (M584) y endstops (M574). Los dos registros no comparten claves
 * (mcfg* vs M-code), así que la resolución en cascada es inequívoca.
 */
function cfgFieldsEntry(name) {
  return CFG_FIELDS[name] || CFG_AXIS_GROUPS[name] || null;
}

async function cfgFieldsRunCustom(name, content, rtCmds) {
  const f = cfgFieldsEntry(name);
  if (!f || typeof f.customSave !== 'function') return { content, ok: true };
  // customSave puede ser sync O async (M208 es async desde la Fase 4.4 —
  // pide confirmDialog si la posición actual queda fuera del nuevo rango).
  // Await sobre un valor no-Promise es no-op, así que customSave sync no se ve afectado.
  return await f.customSave({ content, rtCmds });
}

/**
 * Espejo de cfgFieldsRunCustom para el flujo de populate. Lee la config raw
 * y actualiza la UI / estado compartido (_endstopCfg, etc.) sin tocar disco.
 * Mantiene el contrato simétrico: customSave escribe ↔ customPopulate lee.
 */
function cfgFieldsRunCustomPopulate(name, raw, lines) {
  const f = cfgFieldsEntry(name);
  if (!f || typeof f.customPopulate !== 'function') return;
  f.customPopulate({ raw, lines: lines || raw.split('\n') });
}

/**
 * Populate de un grupo multi-eje (M92, M203, M201, M566, M425, M906_XYA, M906_Z).
 * Usa el `pattern` del grupo para localizar la línea (acepta grupos como M906_Z
 * cuyo nombre no es directamente el M-code del config.g).
 */
function cfgAxisGroupPopulate(groupName, raw) {
  const group = CFG_AXIS_GROUPS[groupName];
  if (!group) return;
  // Convertir 'M906 X' → /^M906\s+X/, 'M92 ' → /^M92\s+/
  const matchRe = new RegExp(`^${group.pattern.replace(/\s+$/, '').replace(/\s+/g, '\\s+')}\\b`);
  const lines = raw.split('\n');
  const line = lines.find((l) => matchRe.test(l));
  if (!line) return;
  Object.entries(group.domIds).forEach(([ax, id]) => {
    const el = $(id);
    if (!el) return;
    const val = cfgGet(line, ax);
    if (val === '') return;
    // Checkbox: la `value` no pinta — lo que pinta es `checked`. `1` → checked,
    // cualquier otra cosa (incluido `0`) → unchecked. Aplicar también a la rama
    // `M350_I` del t_d612ed30. Sin esto el toggle arranca siempre en su estado
    // por defecto del HTML, no en el de la SD, y un cliente ve "interpolación ON"
    // cuando su config.g tiene I0.
    if (el.type === 'checkbox') {
      el.checked = (val === '1');
    } else {
      el.value = val;
    }
  });
}

/**
 * Save de un grupo multi-eje. Lee los valores de la UI, valida, escribe la línea
 * en config.g y empuja el comando rtCmd. Devuelve { content, ok, needsReboot }.
 */
function cfgAxisGroupSave(groupName, content, rtCmds, aActive) {
  const group = CFG_AXIS_GROUPS[groupName];
  if (!group) return { content, ok: true, needsReboot: false };
  // Recolectar valores de los inputs
  const vals = {};
  Object.entries(group.domIds).forEach(([ax, id]) => {
    const el = $(id);
    vals[ax] = el ? el.value.trim() : '';
  });
  // Validar
  if (group.validate) {
    const err = group.validate(vals, aActive);
    if (err) { toast(err, 'err'); return { content, ok: false, needsReboot: false }; }
  }
  // Formatear y aplicar
  const newLine = group.formatter(vals, aActive, content);
  if (!newLine) return { content, ok: true, needsReboot: false };
  content = cfgReplaceLine(content, group.pattern, newLine);
  // Comando en caliente = la línea sin comentario final
  const rtCmd = newLine.replace(/\s*;.*$/, '').trim();
  rtCmds.push(rtCmd);
  return { content, ok: true, needsReboot: !!group.needsReboot };
}

function applyRotechJogFeeds(raw) {
  const m = raw?.match(
    /; rotech-jog-feed=X([\d.]+)\s+Y([\d.]+)\s+Z([\d.]+)\s+A([\d.]+)/,
  );
  m &&
    ((CFG.jogFeedX = Number(m[1]) || CFG.jogFeedX),
    (CFG.jogFeedY = Number(m[2]) || CFG.jogFeedY),
    (CFG.jogFeedZ = Number(m[3]) || CFG.jogFeedZ),
    (CFG.jogFeedA = Number(m[4]) || CFG.jogFeedA),
    (CFG.jogFeedrate = CFG.jogFeedX));
}

// ---
// §4.3 #5 — Mantenimiento temporal del toggle «Requerir HOME (G28)»
// ---
// El toggle existía pero su desactivación era SILENCIOSA: un operario lo quitaba
// para una prueba y se quedaba así durante meses. Si la máquina ejecutaba un
// G-code sin referenciar, los choques estaban garantizados. Lo que pide el plan
// v2 §4.3 #5: tratar la desactivación como mantenimiento temporal con:
//   (a) marca de tiempo persistida — sobrevive a recargas (localStorage)
//   (b) registro del evento en el log del sistema
//   (c) banner persistente al reabrir la pestaña mientras siga OFF
//   (d) el banner ofrece REACTIVAR con un click (no hay que buscar el toggle)
//
// El banner se inyecta en runtime con createElement — NO se toca index.html
// (la tarjeta tiene HTML como zona compartida prohibida). El contenedor de la
// pestaña (`#mcfgTabHoming`) sí existe desde el primer release; el banner es un
// hijo nuevo del DOM, no un atributo nuevo de un nodo pre-existente.
// El bloque (timestamp en localStorage, age label, render del banner y
// boton REACTIVAR) vive en `rotechos-config-homing-maint.js` (t_ec990fc0,
// 2026-09-05; reubicado desde este fichero para extraer 96 lineas que
// NO escriben config.g). Se carga de forma perezosa al entrar en la
// rama HOMING del cfgPopulate, mismo patron que el resto de modulos
// perezosos. El modal invoca sus tres primitivas (setOn / clearOn /
// renderBanner) en los mismos puntos donde antes llamaba a las
// funciones inline, sin cambios de comportamiento.
const __loadHomingMaint = () => __mcfgLazyLoad(`/js/rotechos-config-homing-maint.js`, `ROTECHOS_HOMING_MAINT`);

// §4.3 #1 — Inyecta el contenedor del resumen del orden REAL debajo de los radios
// homOrder. Crea el <p> una sola vez (idempotente: si ya existe, no duplica).
// Devuelve el elemento creado para que el populate rellene su innerHTML.
function _injectHomingOrderSummary() {
  const existing = $(`mcfgHomingOrderSummary`);
  if (existing) return existing;
  // Buscar el último radio del grupo (X/Y primero) e insertar el resumen DESPUÉS
  // del contenedor padre `.mcfg-row-icon-2`. Si no encontramos el contenedor,
  // abortamos silenciosamente — la UI seguirá funcionando sin el resumen.
  const radioXY = document.querySelector(`input[name="homOrder"][value="xy_first"]`);
  if (!radioXY) return null;
  // El label abuelo es el contenedor de fila; subimos dos niveles (.mcfg-radio-lbl → .mcfg-row-tight)
  const rowContainer = radioXY.closest(`.mcfg-row-icon-2, .mcfg-row-tight, div`);
  if (!rowContainer) return null;
  const summary = document.createElement(`p`);
  summary.id = `mcfgHomingOrderSummary`;
  summary.className = `mcfg-hint`;
  summary.style.cssText = `margin-top:8px;font-size:11px;line-height:1.45`;
  // Insertar después del rowContainer padre si es .mcfg-row-icon-2, o dentro si es .mcfg-row-tight.
  const parent = rowContainer.classList.contains(`mcfg-row-icon-2`)
    ? rowContainer
    : (rowContainer.parentElement?.classList.contains(`mcfg-row-icon-2`) ? rowContainer.parentElement : rowContainer);
  parent.insertAdjacentElement(`afterend`, summary);
  return summary;
}

// §4.3 #3 — Inyecta un hint permanente (etiqueta visual) debajo de cada campo
// Seek/Back con el valor RECOMENDADO. Idempotente: si ya existe el span para ese
// campo, no duplica. El hint se inserta después del <input>; usa una clase CSS
// pre-existente (mcfg-hint) para heredar el estilo de los otros hints del modal.
function _injectHomingSpeedHint(ax, kind, recommended) {
  const el = $(`mcfgHom${ax}${kind}`);
  if (!el) return;
  const hintId = `mcfgHom${ax}${kind}Hint`;
  // Si ya existe, actualizamos texto (por si el idioma cambió); si no, creamos.
  let hint = $(hintId);
  if (!hint) {
    hint = document.createElement(`span`);
    hint.id = hintId;
    hint.className = `mcfg-hint`;
    hint.style.cssText = `display:block;font-size:10px;color:var(--text-3);margin-top:2px`;
    // P3 (2026-09-03): el hint va en una celda propia con su input. Con
    // insertAdjacentElement("afterend") entraba como item suelto de
    // .mcfg-grid-meta (3 columnas), asi que cada fila pasaba de 3 celdas a 5,
    // el flujo se desplazaba y NINGUN campo caia bajo su cabecera. Son las
    // velocidades de referenciado: cruzarlas hace la aproximacion de precision
    // a 1000 mm/min contra el bastidor.
    const celda = document.createElement(`div`);
    celda.className = `mcfg-hom-cell`;
    el.parentNode.insertBefore(celda, el);
    celda.appendChild(el);
    celda.appendChild(hint);
  }
  // Texto via i18n — fallback ES literal del manual del fabricante.
  hint.textContent = t(`cfg.homing.speedHint`, `Recomendado: ${recommended} mm/min`, { "recommended": recommended });
}

/** §4.8 (t_014cd150) — helpers de la pestaña SONDA/SAC. Estos helpers
 *  viven a NIVEL DE MÓDULO (no dentro de cfgPopulate) porque:
 *  (a) se exportan a window.* para que rotechos.js (los quick-actions)
 *      los consuma sin redefinir la lógica;
 *  (b) el test cfg-machine-persistence.test.js evalúa este módulo dentro
 *      de un bloque IIFE { ... } y referencia cfgProbeGuard desde el
 *      `return {...}` final — si fuera local de cfgPopulate, ese acceso
 *      daría ReferenceError y rompería 13 tests de round-trip que NO son
 *      de esta tarea (medido en esta sesión).
 *  Política del plan: NO duplicar machineMoveBlocked() ni
 *  AppState.limits.allHomed; los CONSUME y añade el veredicto. */
// t_b8cd40c2: `cfgProbeGuard` se ha MOVIDO a rotechos-config-modal-core.js
// (shim EAGER). Es una guarda de SEGURIDAD FISICA y sus dos consumidores
// —btnQaSondaZ y btnQaM6, en rotechos.js— la invocan con el patron
// `typeof cfgProbeGuard === 'function' && !cfgProbeGuard(...)`, que es
// FAIL-OPEN: si la funcion no existe, la condicion entera es falsa y la
// accion sigue adelante SIN guarda. Con el modal perezoso eso significaba
// sondar y cambiar herramienta sin comprobar HOME ni trabajo en marcha.
// Vive en el shim para que exista desde el primer tick, siempre.
/** §4.8 punto 4 (t_014cd150) — readout "recorrido máximo hasta contacto".
 *  Fórmula: |zPos - zMin| - z_sensor_to_table. Si zPos o zMin no están
 *  disponibles, mostramos el texto corto "— mm" y la prosa explicativa
 *  vive plegada en #sonRecorridoDetails (t_c7ffb7f0, sep-2026). */
// Corre en cada ciclo de telemetria (rotechos-telemetry.js): writeText y
// classList.toggle(c, bool) no tocan el DOM si el valor ya es ese.
function _renderSondaRecorridoMax() {
  const el = $(`mcfgSacRecorridoMax`);
  if (!el) return;
  const zPosRaw = (typeof SM !== `undefined` && SM && typeof SM.zPos === `number`) ? SM.zPos : null;
  const zMin = (typeof AppState !== `undefined` && AppState && AppState.axes && typeof AppState.axes[2]?.min === `number`)
    ? AppState.axes[2].min : null;
  const zSensorEl = $(`mcfgSacSensorZ`);
  const zSensor = zSensorEl ? parseFloat(zSensorEl.value) : NaN;
  if (zPosRaw == null || zMin == null) {
    // t_c7ffb7f0 (sep-2026): texto compacto. La prosa larga vivía aquí y
    // ocupaba ~180 px en modo escuela a 1280x720. Ahora va plegada en el
    // details #sonRecorridoDetails (data-i18n-html="info.sonda.recorridoMax").
    writeText(el, t(`msg.sondaRecorridoMaxNoData`, `— mm`));
    el.classList.toggle(`mcfg-text-warn`, true);
    return;
  }
  const travel = Math.abs(zPosRaw - zMin) - (Number.isFinite(zSensor) ? zSensor : 0);
  if (!Number.isFinite(travel) || travel <= 0) {
    writeText(el, t(`msg.sondaRecorridoMaxNoData`, `— mm`));
    el.classList.toggle(`mcfg-text-warn`, true);
    return;
  }
  // t_c7ffb7f0 (sep-2026): solo el número, no la frase larga. La prosa
  // ("derivado de Z actual y Z min") va en #sonRecorridoDetails.
  writeText(el, `${travel.toFixed(1)} mm`);
  el.classList.toggle(`mcfg-text-warn`, false);
}
/** §4.8 punto 1 (t_014cd150) — banner HOME obligatorio en la pestaña.
 *  Tres estados visuales: HOME_OK (verde), HOME_REQUIRED (rojo), MAINT_TMP
 *  (ámbar — el toggle de homing está OFF temporalmente). */
function _renderSondaBannerHome() {
  const banner = $(`sondaHomeBanner`);
  if (!banner) return;
  const homed = (typeof AppState !== `undefined` && AppState && AppState.limits && AppState.limits.allHomed === true);
  const reqEl = $(`mcfgHomingRequired`);
  const reqOn = reqEl ? !!reqEl.checked : true;
  let cls = `mcfg-warn-box`;
  let msgKey = `msg.sondaBannerHomeRequired`;
  let msgFallback = `HOME OBLIGATORIO antes de sondar — los botones de esta pestaña están bloqueados hasta que ejecutes G28.`;
  if (!reqOn) {
    cls = `mcfg-warn-box-amber`;
    msgKey = `msg.sondaBannerMaintTmp`;
    msgFallback = `Ventana de mantenimiento: HOME desactivado temporalmente. Los botones de sonda están habilitados; reactívalo en la pestaña REFERENCIAR cuando acabes.`;
  } else if (homed) {
    cls = `mcfg-info-box-ok`;
    msgKey = `msg.sondaBannerHomeOk`;
    msgFallback = `HOME OK — palpado y cambio de herramienta habilitados.`;
  }
  // Se llama en cada ciclo de telemetria: solo se escribe lo que cambia.
  writeProp(banner, `className`, cls);
  writeText(banner, t(msgKey, msgFallback));
  writeAttr(banner, `aria-label`, t(`aria.cfg.sonda.bannerHome`,
    `Banner que indica si la máquina está en HOME (palpado/cambio de herramienta habilitados) o si necesita homing previo.`));
}

async function cfgPopulate(raw, machineRaw = ``) {
  // raw = config.g, machineRaw = config-machine.g
  // Merge: config-machine.g SOBRESCRIBE config.g (se carga después en el boot).
  // findLast prioriza el último valor encontrado (el de config-machine.g).
  const merged = machineRaw ? raw + `\n` + machineRaw : raw;
  applyRotechJogFeeds(merged);
  // Variables compartidas — disponibles por closure en todas las sub-funciones
  const lines = merged.split(`\n`);
  const find = (re) => lines.findLast((l) => re.test(l)) || lines.find((l) => re.test(l)) || ``;
  const m203 = find(/^M203\b/), m566 = find(/^M566\b/);
  const m201 = find(/^M201\b/);

  // ── Orquestador: cada sección tiene su propia función nombrada ──
  // Try/catch por sección: un error en una no interrumpe las demás
  try { await _populateHoming(); }   catch(e) { LOG.warn(`cfgPopulate homing:`, e); }
  try { _populateToolChange(); }     catch(e) { LOG.warn(`cfgPopulate toolchange:`, e); }
  try { _populateEndstops(); }       catch(e) { LOG.warn(`cfgPopulate endstops:`, e); }
  try { _populateLimits(); }         catch(e) { LOG.warn(`cfgPopulate limits:`, e); }
  try { _populateSpindle(); }        catch(e) { LOG.warn(`cfgPopulate spindle:`, e); }
  try { _populateDrivers(); }        catch(e) { LOG.warn(`cfgPopulate drivers:`, e); }
  try { _populateAxisConfig(); }     catch(e) { LOG.warn(`cfgPopulate axisConfig:`, e); }
  // t_e234f3be: aspiración que sigue al husillo. Lee ; rotech-aspir-follow=
  // y ; rotech-aspir-delay= de config-machine.g, refresca el pin desde
  // ; rotech-pins= y deja el interruptor visible/invisible según haya
  // pin asignado para `aspiracion`.
  try { await _populateAspirFollow(); } catch(e) { LOG.warn(`cfgPopulate aspirFollow:`, e); }
  try { _populateAdvanced(); }       catch(e) { LOG.warn(`cfgPopulate advanced:`, e); }
  // 6-oct: tarjeta WiFi de la pestaña RED (vive en rotechos-apdetector.js, que es eager).
  try { window.WifiCard?.refresh(); } catch(e) { LOG.warn(`cfgPopulate wifi:`, e); }

  // ── Sub-funciones (closure — acceden a raw, lines, find, m* directamente) ──

  /** Homing: checkbox H1, velocidades seek/back y dirección desde homeall.g */
  async function _populateHoming() {
    // Requerir homing: lectura desde global.requireHoming (fuente única), que la
    // UI mantiene sincronizada con M564 H. Antes solo se leía de M564 H1, que
    // podría usar una expresión en vez de un literal y dar lectura incorrecta.
    // 15-sep: también `set global.X` (lo que persiste la UI) y, sin línea, el valor de
    // fábrica de globals.g (true). Antes caía a /H1/ sobre `M564 H{…}`: la casilla salía
    // DESMARCADA, RAYO dejaba de exigir homing y Guardar lo desactivaba de verdad.
    const _reqLine = find(/^\s*(?:set\s+global\.|global\s+)requireHoming\s*=/);
    const _reqOn = _reqLine ? /=\s*true/i.test(_reqLine) : true;
    const elReq = $(`mcfgHomingRequired`);
    if (elReq) {
      elReq.checked = _reqOn;
      // APLICACIÓN INSTANTÁNEA — mismo patrón que soft limits: el toggle persiste
      // en config.g y se aplica en caliente al pulsarlo, sin depender del botón
      // Guardar ni de la pestaña activa.
      elReq.onchange = () => {
        const on = elReq.checked;
        const reqBool = on ? `true` : `false`;
        cfgPersistGlobalLine(`requireHoming`,
          `global requireHoming = ${reqBool}  ; Si false: permite RAYO y ejecución sin homing previo`);
        // Aplicar en caliente (solo H, preserva S → respeta soft limits del user)
        RRF.gcode(`set global.requireHoming = ${reqBool}\nM564 H${on ? 1 : 0}`);
        toast(`${t(`msg.homingRequired`, `Homing obligatorio`)} ${on ? t(`msg.enabled`, `activado`) : t(`msg.disabledUpper`, `DESACTIVADO`)}`, on ? `info` : `warn`);
        log(`requireHoming → ${reqBool} (instantáneo)`, `sys`);
        // §4.3 #5 — desactivar homing obligatorio se trata como MANTENIMIENTO TEMPORAL.
        // La desactivación silenciosa (que era el comportamiento anterior) convertía
        // un cambio físico en un olvido de tres meses: el operario quitaba el toggle
        // para una prueba, no lo reactivaba, y un día cualquiera la máquina ejecutaba
        // RAYO o un G-code sin haber referenciado. Por eso ahora:
        //   1) marca de tiempo localStorage (sobrevive a refreshes, no al formateo)
        //   2) registro explícito en el log del sistema (visible en la pestaña HISTORIAL)
        //   3) banner persistente inyectado al reabrir la pestaña mientras siga OFF
        //   4) el banner ofrece REACTIVAR con un click (no hay que navegar a la checkbox)
        // t_ec990fc0: las primitivas de homing-maint viven en el modulo
        // perezoso. Si ya esta cargado, las invocamos en sincrono; si no,
        // disparamos la carga y las encolamos para que el banner aparezca
        // al resolverse.
        if (!on) {
          log(`requireHoming → false (MANTENIMIENTO TEMPORAL — desactivado ${new Date().toISOString()})`, `warn`);
          if (window.ROTECHOS_HOMING_MAINT) window.ROTECHOS_HOMING_MAINT.setOn(Date.now());
          else __loadHomingMaint().then((ui) => ui && ui.setOn(Date.now())).catch(() => {});
        } else {
          log(`requireHoming → true (MANTENIMIENTO CERRADO — homing obligatorio reactivado)`, `info`);
          if (window.ROTECHOS_HOMING_MAINT) window.ROTECHOS_HOMING_MAINT.clearOn();
          else __loadHomingMaint().then((ui) => ui && ui.clearOn()).catch(() => {});
        }
        // Pinta/borra el banner inmediatamente (sin esperar a reabrir el modal).
        if (window.ROTECHOS_HOMING_MAINT) window.ROTECHOS_HOMING_MAINT.renderBanner();
        else __loadHomingMaint().then((ui) => ui && ui.renderBanner()).catch(() => {});
      };
    }
    // §4.3 #5 — pintar el banner de mantenimiento si está OFF al cargar la pestaña.
    // Se hace tras el onchange para que el banner refleje el estado actual de disco,
    // no el de un cambio en curso.
    if (window.ROTECHOS_HOMING_MAINT) window.ROTECHOS_HOMING_MAINT.renderBanner();
    else __loadHomingMaint().then((ui) => ui && ui.renderBanner()).catch(() => {});
    // Soft limits: fuente ÚNICA = global.softLimitsOn (no la línea M564, que ahora
    // deriva S de ese global). Así el toggle SIEMPRE refleja la preferencia guardada,
    // aunque la línea M564 de config.g use una expresión en vez de un literal.
    const _slLine = find(/^\s*(?:set\s+global\.|global\s+)softLimitsOn\s*=/);
    _softLimitsEnabled = _slLine ? /=\s*true/i.test(_slLine) : true;
    const elSL = $(`mcfgSoftLimits`);
    if (elSL) {
      elSL.checked = _softLimitsEnabled;
      // APLICACIÓN INSTANTÁNEA: el toggle persiste y se aplica al pulsarlo, SIN
      // depender del botón Guardar ni de la pestaña activa (que era el motivo de
      // que el cambio no se guardara y reapareciera activado al reabrir).
      // .onchange es idempotente (se reasigna en cada populate, no se acumula).
      elSL.onchange = async () => {
        const on = elSL.checked;
        // BARRERA T-2 (t_ecea8ad1): desactivar los soft limits es la diferencia
        // entre un choque y ninguno (los límites M208). El criterio de la dirección
        // (USR_PRIORITARIO = novato) es: un recien llegado NO debe poder
        // quitarlos CREYENDO que hace otra cosa. Reutilizamos confirmDialog
        // (modal accesible, Escape=Cancel, Enter=OK, re-entrada denegada).
        // Reactivarlos NO pide nada: volver a lo seguro debe ser un click.
        if (!on) {
          // HALLAZGO-12 (2026-08-18): el cuerpo de la barrera iba hardcoded en
          // español sin clave i18n. Un operario en EN veía "Vas a desactivar
          // los soft limits..." sin entender, y la próxima pieza podía salir
          // del área M208 (la red de seguridad de la fresa). El TÍTULO ya
          // estaba i18n-eado (`msg.softLimitsDisableTitle`); el CUERPO debe
          // pasar por t() igual, conservando los <strong>/<br> que el
          // confirmDialog interpreta como HTML (mismo patrón que
          // rotechos-fm.js:322 dlg.fileDelete).
          // Contrato t(key, fallback) en rotechos-i18n.js:78-81:
          //   lang==='es' → devuelve fallback (DEBE ser el texto ES).
          //   lang==='en' → devuelve dict[key] si existe; si no, fallback.
          // Por tanto el fallback SIEMPRE es el texto en español.
          const msg = t(
            `msg.softLimitsDisableBody`,
            `Vas a <strong>desactivar los soft limits</strong>. A partir de ahora la máquina puede moverse fuera del área de trabajo y <strong>chocar contra los topes</strong>.<br><br>¿Confirmas que es lo que quieres hacer?`,
          );
          const ok = await confirmDialog(
            t(`msg.softLimitsDisableTitle`, `Desactivar soft limits`),
            msg,
          );
          if (!ok) {
            // Restaurar el toggle a su estado anterior (desactivar la red
            // de seguridad requiere confirmación EXPLÍCITA). Sin este revert
            // el checkbox quedaría visualmente en OFF mientras el resto
            // del sistema asume ON — incoherencia entre UI y firmware.
            elSL.checked = true;
            _softLimitsEnabled = true;
            log(`Soft limits → desactivación cancelada (toggle revertido)`, `sys`);
            return;
          }
        }
        _softLimitsEnabled = on;
        const slBool = on ? `true` : `false`;
        // 1) Persistir en config.g (SSOT, escritura serializada + relectura fresca)
        cfgPersistGlobalLine(`softLimitsOn`,
          `global softLimitsOn = ${slBool}  ; Preferencia del user — fuente única (config.g y homeall.g derivan M564 S)`);
        // 2) Aplicar en caliente (solo S, preserva H)
        RRF.gcode(`set global.softLimitsOn = ${slBool}\nM564 S${on ? 1 : 0}`);
        toast(`Límites de recorrido ${on ? t(`msg.enabledPlural`, `activados`) : t(`msg.disabledUpperPlural`, `DESACTIVADOS`)}`, on ? `info` : `warn`);
        log(`Soft limits → ${slBool} (instantáneo)`, `sys`);
      };
    }
    try {
      const r = await RRF.download('0:/sys/homeall.g');
      if (r.ok) {
        const txt = await r.text();
        // §4.3 #1 — Mostrar el orden REAL persistido en homeall.g, no solo el radio.
        // El radio `homOrder` puede estar desincronizado del homeall.g (p.ej. si la
        // última sesión cerró a medias y solo se persistió el global sin re-generar
        // homeall.g). La fuente de verdad es el fichero; leemos su línea "; Orden:"
        // y sincronizamos el radio + mostramos un resumen visible para el operario.
        const orderLine = txt.match(/^;\s*Orden:\s*(.+)$/m);
        let realOrder = ``;
        // t_b68324ca (sep-2026): cuando NO se detecta el orden en homeall.g,
        // hay que DESMARCAR los radios a la fuerza — el HTML ya no trae
        // `checked` por defecto, pero un populate repetido podría dejar
        // marcado un valor de una sesión anterior. Sin este barrido, el
        // operario entra a Referenciar, no toca nada, pulsa Guardar, y
        // persiste "z_first" SABIENDO que el orden real es desconocido
        // (mensaje explícito en pantalla). Eso machaca el homeall.g con
        // un orden que la UI misma acaba de declarar no-legítimo.
        const _homRadios = document.querySelectorAll(`input[name="homOrder"]`);
        if (orderLine) {
          // Formato esperado: "Z → X → Y" o "X → Y → Z" (generado en rotechos-config-modal.js:3080)
          const normalized = orderLine[1].replace(/\s*[→\->]\s*/g, `,`).replace(/[XZ]/gi, (m) => m.toUpperCase());
          // Detectamos Z-primero si la primera letra es Z, si no X-primero.
          const first = normalized.split(`,`)[0].trim().toUpperCase();
          realOrder = first === `Z` ? `z_first` : `xy_first`;
          // Sincronizar el radio sin disparar su onchange (no se guarda nada nuevo,
          // solo se hace coincidir el UI con el estado real del fichero).
          const radio = document.querySelector(`input[name="homOrder"][value="${realOrder}"]`);
          if (radio && !radio.checked) radio.checked = true;
        } else {
          // Sin línea "; Orden:" en homeall.g → NINGÚN radio puede aparecer
          // marcado. Es la única manera de que el save (más abajo) detecte
          // la ausencia de elección y aborte el guardado sin tocar el fichero.
          _homRadios.forEach((r) => { r.checked = false; });
        }
        // Inyectar/actualizar el resumen del orden REAL debajo de los radios.
        // El radio existe en HTML; el resumen es un <p> hijo del contenedor padre
        // de los radios. Usamos un id estable para que el render sea idempotente.
        const orderSection = $(`mcfgHomingOrderSummary`)
          ?? _injectHomingOrderSummary();
        if (orderSection) {
          const orderText = realOrder
            ? (realOrder === `z_first`
                ? t(`cfg.homing.order.realZ`, `Z → X → Y (Z primero — sube la herramienta antes de mover XY)`)
                : t(`cfg.homing.order.realXY`, `X → Y → Z (X/Y primero — baja la herramienta al final)`))
            : t(`cfg.homing.order.realUnknown`, `Orden no detectable (homeall.g sin comentario «Orden: …» — versión antigua)`);
          const dateMatch = txt.match(/^;\s*homeall\.g.*generado.*$/m);
          orderSection.innerHTML =
            `<strong style="color:var(--text-1)">${escHtml(t(`cfg.homing.order.realLbl`, `Orden REAL persistido en homeall.g:`))}</strong> ` +
            `<code style="background:var(--bg-input);padding:1px 6px;border-radius:4px">${escHtml(orderText)}</code>` +
            (dateMatch ? `<br><span style="color:var(--text-3);font-size:10px">${escHtml(dateMatch[0].replace(/^;\s*/, ``))}</span>` : ``);
        }
        [`X`, `Y`, `Z`].forEach((ax) => {
          // Todas las líneas de homing usan G1 H1 (parar en endstop). Para cada eje
          // hay 2: la 1ª = búsqueda rápida (F=seek), la 2ª = afinado lento (F=back).
          // La distancia puede ser un NÚMERO (X600) o una EXPRESIÓN dinámica
          // (Z{(0 - move.axes[2].min) + 15}) — esta última la introdujimos para el
          // rango Z. La regex acepta ambas; si solo aceptara números, el campo
          // "Z Back" quedaba vacío y el guardado abortaba con "validation".
          const re = RegExp(`G1\\s+H1\\s+${ax}(\\{[^}]*\\}|[\\-\\d.]+)\\s+F(\\d+)`, `gi`);
          const matches = [...txt.matchAll(re)];
          if (matches[0]) { const elS = $(`mcfgHom${ax}Seek`); elS && (elS.value = matches[0][2]); }
          if (matches[1]) { const elB = $(`mcfgHom${ax}Back`); elB && (elB.value = matches[1][2]); }
          // Dirección: solo si la distancia es numérica. Las expresiones {…} de Z
          // homean a Max por convención → checkbox sin marcar (Max).
          if (matches[0]) {
            const d = parseFloat(matches[0][1]);
            if (!isNaN(d)) { const el = $(`mcfgHomDir${ax}`); el && (el.checked = d < 0); }
          }
        });
        // §4.3 #3 — Mostrar los límites recomendados como hint permanente en cada
        // campo Seek/Back. HW_LIMITS.homeSeek.homeBack son los rangos válidos, pero
        // los valores RECOMENDADOS son más estrechos (los típicos del manual): X/Y
        // buscar 1000-2000, Z buscar 200-400; todos afinar 200-300. Estos son los
        // valores que la información azul del cabecera menciona como "razonables".
        // El hint se inyecta UNA vez (createElement idempotente), no se duplica en
        // cada populate. Usamos textContent para evitar XSS (los valores son
        // literales, pero el patrón del repo es defensivo).
        [`X`, `Y`, `Z`].forEach((ax) => {
          _injectHomingSpeedHint(ax, `Seek`, `1000–2000`);
          _injectHomingSpeedHint(ax, `Back`, `200–300`);
        });
        // Red de seguridad: rellenar CUALQUIER campo que quede vacío con un valor
        // razonable (antes solo se comprobaba X Seek, así que un Back vacío de Z
        // se colaba y reventaba el guardado).
        [`X`, `Y`, `Z`].forEach((ax) => {
          const elS = $(`mcfgHom${ax}Seek`), elB = $(`mcfgHom${ax}Back`);
          if (elS && !elS.value) elS.value = 1000;
          if (elB && !elB.value) elB.value = 300;
        });
      }
    } catch {
      [`X`, `Y`, `Z`].forEach((ax) => {
        (($(`mcfgHom${ax}Seek`).value = cfgGet(m203, ax)),
          ($(`mcfgHom${ax}Back`).value = cfgGet(m566, ax)));
      });
    }
  }

  /** SAC (cambio de herramienta, vive en pestaña HERRAMIENTAS) + declaración
   *  de la sonda (M558) y su offset (G31, viven en pestaña SONDA). La función
   *  conserva su nombre histórico (`_populateToolChange`) por compatibilidad
   *  con el orquestador `cfgPopulate`, pero su alcance cubre AMBAS pestañas:
   *  populate por prefijo `mcfgSac*` funciona sea donde sea el DOM. */
  function _populateToolChange() {
    // MIGRADO al patrón declarativo CFG_FIELDS — fuente única de verdad.
    // Cualquier campo nuevo de SAC se añade en CFG_FIELDS y aparece aquí
    // automáticamente, sin escribir más código de populate.
    cfgFieldsPopulateByPrefix('mcfgSac', merged);
    // t_9b49c0a4 (sep-2026): declaración de la sonda (M558) y su offset (G31).
    // Vive aquí (en lugar de tener su propio populate) porque la lógica de
    // SAC + sonda + recorrido máximo derivado comparten la misma pestaña
    // (HERRAMIENTAS tras t_7c0ad504, SONDA antes) y los tres leen del mismo
    // `merged`. customPopulate lee M558 y G31 de `merged` y rellena los
    // 9 inputs. Ver CFG_AXIS_GROUPS.PROBE.
    cfgFieldsRunCustomPopulate('PROBE', merged, merged.split('\n'));
    // Display SOLO LECTURA de la X del sensor: ahora se deriva del soft limit
    // X máximo (move.axes[0].max), que se edita en Configuración → Soft Limits.
    // Mostrar el valor actual ayuda al operario a confirmar que coincide con
    // la posición física del sensor sin ir a otra pestaña.
    const elX = $(`mcfgSacSensorXDisplay`);
    if (elX) {
      const m208max = find(/^M208.*S0/);
      const xMax = parseFloat(cfgGet(m208max, 'X'));
      elX.value = isFinite(xMax) ? xMax : '';
    }
    // §4.8 punto 4 (t_014cd150): readout derivado "recorrido máximo hasta
    // contacto". Se calcula con la Z actual del DRO y la Z mínima (suelo de
    // la mesa) que RRF reporta en move.axes[2].min. NO se persiste: solo
    // se muestra como ayuda visual al operario. Si todavía no hay datos de
    // move.axes (poll no ha llegado), se muestra el texto "no disponible".
    _renderSondaRecorridoMax();
    // §4.8 punto 1 (t_014cd150): banner HOME obligatorio. Se actualiza
    // también desde el poll (rotechos.js), pero aquí dejamos el estado
    // inicial al abrir la pestaña.
    _renderSondaBannerHome();
  }
  /** Endstops: M574 + rotech-pills override → MIGRADO a CFG_FIELDS.M574.customPopulate.
   *  El populate de M574 y la lectura del comentario rotech-pills viven dentro de la
   *  entrada declarativa (espejo simétrico de su customSave). Aquí solo queda el
   *  parche legacy `rotech-triggers` (configs antiguos) que se mantiene como compat. */
  function _populateEndstops() {
    cfgFieldsRunCustomPopulate('M574', raw, lines);
    // Compat con configs antiguos que aún tienen `; rotech-triggers=`. Solo aplicar
    // si NO hay `; rotech-pills=` (sistema moderno). Si existen ambos, rotech-pills
    // es la fuente única de verdad — el legacy code FORZABA maxOn=true para todos
    // los ejes listados, ignorando el estado off de rotech-pills (Bug 4 fix).
    const _hasPills = /;\s*rotech-pills=/.test(raw);
    const _rtmPop = raw.match(/; rotech-triggers=(\S+)/);
    if (_rtmPop && !_hasPills) {
      const _pts = _rtmPop[1].split(`:`);
      for (let i = 0; i < _pts.length - 1; i += 2) {
        const _ax = _pts[i];
        if ([`X`, `Y`, `Z`, `A`].includes(_ax)) {
          const elMaxOn = $(`mcfgEnd${_ax}MaxOn`);
          if (elMaxOn) { elMaxOn.checked = !0; updateEndstopRowState(_ax); }
        }
      }
    }
  }

  /** Soft limits (M208) → MIGRADO a CFG_FIELDS.M208.customPopulate */
  function _populateLimits() {
    cfgFieldsRunCustomPopulate('M208', raw, lines);
  }

  /** Spindle: M950 R0 + modo + ramp + mist/cool → MIGRADO a CFG_FIELDS.SPINDLE.customPopulate */
  function _populateSpindle() {
    cfgFieldsRunCustomPopulate('SPINDLE', merged, merged.split('\n'));
  }

  /**
   * Aspiración sincronizada con el husillo (t_e234f3be). Lee el bloque
   * `; rotech-aspir-follow=` y `; rotech-aspir-delay=` del raw (que ya
   * viene merged = config.g + config-machine.g con la segunda ganando).
   * Pinta los campos y muestra el banner "sin pin" si el módulo
   * ASPIR_FOLLOW aún no pudo resolver un pin para la función aspiracion.
   */
  async function _populateAspirFollow() {
    // El módulo rotechos-aspiracion-follow.js (window.ASPIR_FOLLOW) se carga
    // ANTES del modal (en index.html), así que siempre está disponible. Pero
    // `parseRotechPins` se carga de forma PEREZOSA al abrir CONTROLADORA:
    // hasta entonces el módulo no sabe el pin. Refrescamos aquí para que
    // abrir Configuración → HUSILLO con CONTROLADORA ya abierta refleje el
    // pin correcto.
    if (typeof window.ASPIR_FOLLOW === `object` && window.ASPIR_FOLLOW &&
        typeof window.ASPIR_FOLLOW.refreshPinFromConfig === `function`) {
      await window.ASPIR_FOLLOW.refreshPinFromConfig().catch(() => {});
    }
    if (typeof window.ASPIR_FOLLOW !== `object` || !window.ASPIR_FOLLOW) return;
    // Aplicar el raw merged al módulo: enabled/delay.
    window.ASPIR_FOLLOW.loadConfig(merged);
    const st = window.ASPIR_FOLLOW.getState();
    const sw = $(`mcfgAspirFollow`);
    if (sw) sw.checked = !!st.enabled;
    const delayEl = $(`mcfgAspirFollowDelay`);
    if (delayEl) delayEl.value = String(st.delay);
    const noPin = $(`mcfgAspirFollowNoPin`);
    if (noPin) {
      const show = (st.pin == null);
      noPin.style.display = show ? `block` : `none`;
    }
    if (sw) sw.disabled = (st.pin == null);
    if (delayEl) delayEl.disabled = (st.pin == null);
  }

  // Al terminar cfgPopulate entero, refrescar etiquetas de cockpit/pendant
  // para que el modo detectado (incluido 'laser') se vea en la UI persistente.
  // (t_028bceef) syncSpindleLabelsToMode vive en rotechos.js (otro módulo).
  if (typeof syncSpindleLabelsToMode === `function`) syncSpindleLabelsToMode();

  /** Drivers: M92, M906, M201, M203, M566, M569, parámetros RAYO y JOG speeds */
  function _populateDrivers() {
    // Grupos multi-eje — MIGRADOS a CFG_AXIS_GROUPS.
    // M906_XYA y M906_Z son DOS grupos distintos porque Z va en línea aparte con I100 fijo.
    // M350 (microstepping) y M350_I (interpolación) son del t_d612ed30 — comparten
    // línea física en config.g pero tienen grupos separados porque la I es un flag
    // global, no por eje. M350_I va DESPUÉS de M350 para que el formatter lea la
    // línea ya escrita con sus X/Y/Z.
    ['M92', 'M350', 'M203', 'M201', 'M566', 'M906_XYA', 'M906_Z'].forEach((g) => cfgAxisGroupPopulate(g, merged));
    // M350_I necesita ejecutarse sobre un content que ya tenga la línea M350 con
    // X/Y/Z. Usamos `merged` (lectura cruda de config.g+config-machine.g), no `content`
    // mutado — porque aquí todavía no estamos guardando, solo releyendo.
    cfgAxisGroupPopulate('M350_I', merged);
    // Capturar el "antes" de microstepping para que el preview instantáneo del
    // recálculo pueda diferenciar lo persistido de lo que el operario selecciona.
    _captureM350Original(merged);
    // Refrescar caches de límite/accel locales que usa el enforcement de jog
    [`X`, `Y`, `Z`, `A`].forEach((ax) => {
      const v203 = parseFloat(cfgGet(m203, ax)); if (v203) _m203Limits[ax] = v203;
      const v201 = parseFloat(cfgGet(m201, ax)); if (v201) _m201Accel[ax] = v201;
    });
    // Preview instantáneo del recálculo M92 ↔ M350 (t_d612ed30). El operario
    // cambia el microstepping en el select y la caja de aviso (#mcfgM350Preview)
    // muestra el antes/después de M92 POR EJE sin esperar a Guardar. Esto
    // complementa al confirmDialog del save: aquí ve el efecto inmediato; al
    // pulsar Guardar, confirmDialog exige el OK explícito.
    //
    // Los handlers se asignan UNA vez — populate puede llamarse varias veces
    // durante la vida del modal, y reasignar onchange reemplazaría handlers
    // anteriores (no se acumulan listeners, ver docs/SDLC).
    try {
      if (!_m350PreviewBound) _bindM350Preview(/* aActive se resuelve del DOM dentro */);
    } catch (e) {
      // Fallo no fatal: si el preview no se ata, el confirmDialog del save
      // sigue protegiendo. Solo lo dejamos en el log para diagnóstico.
      LOG.warn(`_bindM350Preview:`, e && (e.message || e.stack || e));
    }
    // Parámetros RAYO (globales) — MIGRADO a CFG_FIELDS
    cfgFieldsPopulateByPrefix('mcfgRayo', merged);
    // JOG speeds persistidas en config.g
    const jfRaw = raw.match(/; rotech-jog-speeds=(.+)/);
    if (jfRaw) {
      jfRaw[1].split(`,`).forEach((p) => {
        const [s, xy, z] = p.split(`:`);
        JOG_FEED[parseFloat(s)] = { xy: Number(xy), z: Number(z) };
      });
    }
    const jogIds = {
      0.1: [`mcfgJF01xy`, `mcfgJF01z`], 1: [`mcfgJF1xy`, `mcfgJF1z`],
      5: [`mcfgJF5xy`, `mcfgJF5z`], 10: [`mcfgJF10xy`, `mcfgJF10z`],
      50: [`mcfgJF50xy`], 100: [`mcfgJF100xy`], 200: [`mcfgJF200xy`], 500: [`mcfgJF500xy`],
    };
    Object.entries(jogIds).forEach(([step, elIds]) => {
      const f = JOG_FEED[parseFloat(step)]; if (!f) return;
      const eXY = $(elIds[0]); if (eXY) eXY.value = f.xy;
      if (elIds[1]) { const eZ = $(elIds[1]); if (eZ) eZ.value = f.z; }
    });
    [`X`, `Y`, `Z`, `A`].forEach((ax) => updateCurrentBar(ax));
    [{ p: 3, ax: `X` }, { p: 1, ax: `Y` }, { p: 2, ax: `Z` }, { p: 4, ax: `A` }].forEach(({ p, ax }) => {
      const line569 = find(RegExp(`^M569 P${p}\\b`));
      const s = line569.match(/S(\d)/)?.[1];
      $(`mcfgM569${ax}`).checked = s === `0`;
      const isExt = /\bD2\b/.test(line569);
      const extEl = $(`mcfgExt${ax}`);
      // T (timing) — solo presente en drivers externos. Si la línea tiene T,
      // inferimos el tipo: si coincide con el preset dm542/dm860 (2.5:2.5:1:1)
      // lo marcamos en el select; en otro caso → custom con el primer valor.
      const tMatch = line569.match(/\bT([0-9.]+):([0-9.]+):([0-9.]+):([0-9.]+)/);
      // Tipo persistido en el comentario `; Driver <ax> (<typeVal>)` cuando
      // es externo. Si el comentario lleva tipo conocido, ganamos sobre el
      // match por T (porque DM542/DM860 y los closed-loop CL57T/HBS57
      // comparten el mismo preset 2.5:2.5:1:1 — el T no los distingue).
      const typeTagMatch = line569.match(/;\s*Driver\s+[A-Z]\s*\(\s*([a-z0-9_-]+)\s*\)/i);
      const persistedType = typeTagMatch?.[1];
      const typeSel = $(`mcfgExtDrvType${ax}`);
      const customInp = $(`mcfgExtDrvCustom${ax}`);
      if (typeSel) {
        if (persistedType && ['dm542','dm860','cl57t','hbs57','custom'].includes(persistedType)) {
          typeSel.value = persistedType;
        } else if (tMatch && (tMatch[1] === '2.5' && tMatch[2] === '2.5' && tMatch[3] === '1' && tMatch[4] === '1')) {
          // Fallback legacy (líneas guardadas antes del tag de tipo): el T
          // coincide con el preset DM/closed-loop conservador. Por defecto
          // marcamos dm542 (era el único existente). Sergi puede re-seleccionar
          // CL57T/HBS57 y re-guardar para que se grabe el tag.
          typeSel.value = 'dm542';
        } else if (tMatch) {
          typeSel.value = 'custom';
          if (customInp) customInp.value = tMatch[1];
        } else {
          typeSel.value = 'tmc2160';
        }
      }
      if (extEl) { extEl.checked = isExt; updateExtDriver(ax, isExt); }
    });
  }

  /** Backlash (M425), SAC enable/sync y modo eje A (M584) */
  function _populateAxisConfig() {
    // M425 (backlash) — MIGRADO a CFG_AXIS_GROUPS
    cfgAxisGroupPopulate('M425', merged);
    // S (suavizado) default si no existe
    const m425 = find(/^M425\b/);
    if (!cfgGet(m425, `S`)) setVal(`mcfgM425S`, `0`);
    $(`mcfgSacEnabled`).checked = SAC.enabled;
    const sacSync = (e) => {
      const val = e.target.checked;
      SAC.enabled = val;
      cfgPersistComment("rotech-sac", val ? "true" : "false");
      // Gate de FIRMWARE: M6.g aborta si sac_enabled=false (retrofit sin sensor).
      // Sin esto el checkbox solo escondía botones y un T{n}/M6 del gcode seguía
      // saliendo a buscar un sensor inexistente.
      cfgPersistGlobalLine(`sac_enabled`,
        `global sac_enabled = ${val}  ; SAC disponible (sensor de herramienta fijo presente). false = M6 aborta con instrucciones (retrofit sin sensor). Sincronizado con CONFIGURACIÓN → Tool-Change`);
      RRF.gcode(`set global.sac_enabled = ${val}`);
      if ($(`mcfgSacEnabled`)) $(`mcfgSacEnabled`).checked = val;
      toast(t(`msg.sacValActivadoDesactivado`, `SAC ${val ? "Activado" : "Desactivado"}`, { s: val ? "Enabled" : "Disabled" }), `info`);
    };
    if ($(`mcfgSacEnabled`)) $(`mcfgSacEnabled`).onchange = sacSync;
    const m584 = find(/^M584\b/);
    let detectedAMode = `off`;
    if (m584) {
      const yPart = m584.match(/Y([\d:]+)/)?.[1] || ``,
        aPart = m584.match(/A(-?\d+)/)?.[1];
      /:\d/.test(yPart) ? (detectedAMode = `slave`) : aPart && aPart !== `-1` && (detectedAMode = `rotary`);
    }
    const aRadio = $q(`input[name="axisAMode"][value="${detectedAMode}"]`);
    aRadio && ((aRadio.checked = !0), applyAxisAMode(detectedAMode));
  }

  // ── AVANZADO (t_f8b27b80) — M84 / M586 / M593, lecturas del merged.
  //     Sin preview en vivo: el save genera la línea M-code.
  // 6-oct: se guardan en config-machine.g y cfgGetMcodeParam da la PRIMERA línea; con
  // `merged` era la de config.g, y reabrir enseñaba el valor de fábrica (y Guardar lo reescribía).
  function _populateAdvanced() {
    const mp = (mc, p) => cfgGetMcodeParam(machineRaw, mc, p) || cfgGetMcodeParam(raw, mc, p);
    const m84Input = $(`mcfgMotorTimeoutS`);
    if (m84Input) m84Input.value = mp(`M84`, `S`) || `86400`;
    const fanEl = $(`mcfgFanTemp`);
    if (fanEl) fanEl.value = mp(`M106 P1`, `T`) || `45`;
    const ftpEl = $(`mcfgNetworkFtp`);
    const telEl = $(`mcfgNetworkTelnet`);
    if (ftpEl) ftpEl.checked = mp(`M586 P1`, `S`) === `1`;
    if (telEl) telEl.checked = mp(`M586 P2`, `S`) === `1`;
    const typeEl = $(`mcfgInputShapingType`);
    const freqEl = $(`mcfgInputShapingFreq`);
    if (typeEl) {
      const known = [`zvd`,`zvdd`,`zv`,`zild`,`2hei`,`3hei`,`ei`,`none`];
      typeEl.value = known.includes(mp(`M593`, `P`)) ? mp(`M593`, `P`) : `zvd`;
    }
    if (freqEl) freqEl.value = mp(`M593`, `F`) || `40`;
  }
}
async function loadPersistentUiConfig() {
  try {
    let raw;
    // t_b04be87e: si el shim eager ya descargó `config.g` en el boot (para
    // hidratar `_endstopCfg` antes de abrir el modal), lo reusamos y nos
    // saltamos la segunda descarga. El usuario puede haber editado el
    // fichero entre el boot y la apertura del modal; en ese caso `raw`
    // viene "viejo" pero el modal es el primer flujo que necesita datos
    // frescos, así que el código de aquí abajo asume que si `raw` ya está
    // en caché es porque hace menos de 60 s que se descargó — válido para
    // el flujo normal (operario abre la web → abre CONFIGURACIÓN).
    if (typeof window._rotechCfgGEager === `string` && window._rotechCfgGEager) {
      raw = window._rotechCfgGEager;
    } else {
      const r = await RRF.download(CFGPATH);
      if (!r.ok) return;
      raw = await r.text();
    }
    ((_cfgRaw = raw), applyRotechJogFeeds(raw));
    (function () {
      const m = raw.match(/; rotech-jog-speeds=(.+)/);
      if (m)
        m[1].split(`,`).forEach((p) => {
          const [s, xy, z] = p.split(`:`);
          JOG_FEED[parseFloat(s)] = { xy: Number(xy), z: Number(z) };
        });
    })();
    (function () {
      const lines = raw.split(`\n`);
      const m203L = lines.find((l) => /^M203\b/.test(l));
      if (m203L) {
        [`X`, `Y`, `Z`, `A`].forEach((ax) => {
          const v = m203L.match(RegExp(ax + `([\\d.]+)`));
          if (v) _m203Limits[ax] = Number(v[1]);
        });
      }
      const m201L = lines.find((l) => /^M201\b/.test(l));
      if (m201L) {
        [`X`, `Y`, `Z`, `A`].forEach((ax) => {
          const v = m201L.match(RegExp(ax + `([\\d.]+)`));
          if (v) _m201Accel[ax] = Number(v[1]);
        });
      }
      const m208L = lines.find((l) => /^M208\b/.test(l) && /S0/.test(l));
      if (m208L) {
        const wx = m208L.match(/X(-?[\d.]+)/),
          wy = m208L.match(/Y(-?[\d.]+)/);
        if (typeof VIZ !== `undefined`) {
          VIZ.workLimits = {
            x: wx ? parseFloat(wx[1]) : 500,
            y: wy ? parseFloat(wy[1]) : 400,
          };
          VIZ.dirty = !0;
        }
      }
      const m950L = lines.find((l) => /^M950 R0\b/.test(l));
      if (m950L) {
        const lm = m950L.match(/L([\d.]+):([\d.]+)/);
        if (lm) {
          const spMin = parseFloat(lm[1]);
          const spMax = parseFloat(lm[2]);
          if (spMin > 0) CFG.spindleMin = spMin;
          if (spMax > 0) CFG.maxRPM = spMax;
        }
      }
      // SAC (cambio asistido) — SSOT en config.g (; rotech-sac=true|false)
      const sacM = raw.match(/;\s*rotech-sac=(true|false)/);
      if (sacM && typeof SAC !== `undefined`) {
        SAC.enabled = sacM[1] === `true`;
        if ($(`mcfgSacEnabled`)) $(`mcfgSacEnabled`).checked = SAC.enabled;
      }
      // Brillo LED RGB — SSOT en config.g (; rotech-led={brillo})
      const ledM = raw.match(/;\s*rotech-led=(\d+)/);
      if (ledM && window.LED) {
        LED.cfg.brightness = parseInt(ledM[1]);
        LED.applyToUI();
      }
      // Modo de coordenadas DRO (WCS/MCS) — SSOT en config.g (; rotech-coordmode=)
      const cmM = raw.match(/;\s*rotech-coordmode=(WCS|MCS)/);
      if (cmM && typeof CoordMode !== `undefined`) {
        CoordMode.current = cmM[1];
        if (typeof CoordMode.render === `function`) CoordMode.render();
      }
      // Soft limits: estado inicial del guard de jog desde config.g
      // (global softLimitsOn). El poll luego lo mantiene sincronizado en vivo.
      const slM = raw.match(/^global softLimitsOn\s*=\s*(true|false)/m);
      if (slM) _softLimitsEnabled = slM[1] === `true`;
    })();
    const lines = raw.split(`\n`),
      m574 = lines.filter((l) => /^M574\b/.test(l));
    // t_b04be87e: hidratar `_endstopCfg` desde config.g ANTES del resto del
    // bloque para que el poll y el diagnóstico GPIO vean el estado real desde
    // el primer tick (no esperan a que el operario abra CONFIGURACIÓN). El
    // código legacy de abajo reescribe campos concretos (off cuando hay
    // rotech-triggers, etc.); `hydrateEndstopCfg` corre primero y ellos
    // pisan encima si corresponde, por lo que el estado final es idéntico al
    // anterior. Idempotente: si se llama dos veces, el resultado es el mismo.
    if (typeof window.hydrateEndstopCfg === `function`) window.hydrateEndstopCfg(raw);
    [`X`, `Y`, `Z`, `A`].forEach((ax) => {
      const minL = m574.find((l) => RegExp(`^M574 ${ax}1`).test(l)),
        maxL = m574.find((l) => RegExp(`^M574 ${ax}2`).test(l));
      _endstopCfg[ax].off = !(
        (minL && /S1\b/.test(minL)) ||
        (maxL && /S1\b/.test(maxL))
      );
    });
    _triggerGpIn = {};
    // OVERRIDE del usuario desde `; rotech-pills=` (parser único parseRotechPills).
    // pillUserState[ax] = ¿algún lado activado? (lo consume el bloque legacy de
    // rotech-triggers más abajo). El trigLevel se aplica desde el parser.
    const pills = parseRotechPills(raw);
    let pillUserState = null;
    if (pills) {
      pillUserState = {};
      [`X`, `Y`, `Z`, `A`].forEach((ax) => {
        const p = pills[ax];
        if (!p) return;
        pillUserState[ax] = p.minOn || p.maxOn;
        _endstopCfg[ax].trigLevel = p.trigLevel;
      });
    }
    const rtm = raw.match(/; rotech-triggers=(\S+)/);
    if (rtm) {
      const pts = rtm[1].split(`:`);
      for (let i = 0; i < pts.length - 1; i += 2) {
        const ax = pts[i],
          ids = pts[i + 1].split(`,`).map(Number);
        if ([`X`, `Y`, `Z`, `A`].includes(ax)) {
          // Legacy rotech-triggers: asumir [min, max]
          _triggerGpIn[ax] = { min: ids[0], max: ids[1] };
          if (!pillUserState || pillUserState[ax] !== false) _endstopCfg[ax].off = !1;
        }
      }
    } else {
      // M581 → _triggerGpIn como { min, max } detectado por comentario
      // NO fuerza configured — M574 S0 / rotech-pills:off manda.
      const m581 = lines.filter((l) => /^M581\b/.test(l));
      m581.forEach((l) => {
        const cmt = (l.match(/;\s*(.+)/) || [])[1] || ``;
        [`X`, `Y`, `Z`, `A`].forEach((ax) => {
          if (RegExp(ax + `\\s*(min|max)`, `i`).test(cmt)) {
            const pn = l.match(/\bP(\d+)\b/);
            if (pn) {
              if (!_triggerGpIn[ax]) _triggerGpIn[ax] = {};
              const isMin = /min/i.test(cmt);
              _triggerGpIn[ax][isMin ? `min` : `max`] = Number(pn[1]);
            }
          }
        });
      });
    }
    // APLICAR OVERRIDE DEL USUARIO (rotech-pills) — sobrescribe auto-detección.
    // Sincroniza AMBOS lados (Min y Max) con el estado persistido por lado.
    if (pills) {
      [`X`, `Y`, `Z`, `A`].forEach((ax) => {
        const p = pills[ax];
        if (!p) return;
        _endstopCfg[ax].off = !(p.minOn || p.maxOn);
        _endstopCfg[ax].minOn = p.minOn;
        _endstopCfg[ax].maxOn = p.maxOn;
        const elMin = $(`mcfgEnd${ax}MinOn`); if (elMin) elMin.checked = p.minOn;
        const elMax = $(`mcfgEnd${ax}MaxOn`); if (elMax) elMax.checked = p.maxOn;
      });
    }
  } catch {}
}
/**
 * Identidad de la máquina (global per-máquina `machineName`).
 *
 * Origen del valor, en orden: (1) `set global.machineName = "X"` en
 * config-machine.g —la fuente persistida— y (2) fallback al `M550 P"X"` de
 * config.g, que es la identidad de fábrica. Si ninguno está, `RotechCNC`
 * (literal de config.g). NUNCA bloquea: si la lectura falla se muestra el
 * valor por defecto y la UI sigue funcionando.
 */
const MACHINE_NAME_FALLBACK = `RotechCNC`;
function _machineNameFrom(raw, machineRaw) {
  const persistido = typeof window.cfgGetStringGlobal === `function`
    ? window.cfgGetStringGlobal(machineRaw, `machineName`)
    : ``;
  if (persistido) return persistido;
  const m550 = String(raw ?? ``).match(/^M550\s+P"([^"]*)"/m);
  return (m550 && m550[1]) || MACHINE_NAME_FALLBACK;
}
window._machineNameFrom = _machineNameFrom;

/**
 * Pinta la identidad en el header del modal y en el input editable de INFO.
 * textContent (no innerHTML): el nombre viene de la SD y no debe interpretarse
 * como HTML.
 */
function _renderMachineIdentity(nombre) {
  const span = $(`mcfgCurrentMachine`);
  if (span) span.textContent = nombre;
  const inp = $(`mcfgMachineName`);
  if (inp && document.activeElement !== inp) inp.value = nombre;
}

/**
 * Pinta el estado actual del PIN HTTP en el panel: lee config-machine.g,
 * extrae el valor con cfgGetPin, y muestra "(sin PIN)" o "PIN activo —
 * longitud N". Defensivo: si falla la lectura deja el texto intacto (no
 * corrompe la verdad con un valor falso).
 */
async function _renderPinStatus() {
  const el = $(`mcfgPinStatus`);
  if (!el) return;
  try {
    const raw = await (typeof cfgMachineRead === `function` ? cfgMachineRead() : null);
    if (raw == null) return;     // lectura fallida — no mentir
    const pin = typeof window.cfgGetPin === `function` ? window.cfgGetPin(raw) : ``;
    if (!pin) {
      el.textContent = t(`msg.pinStatusNone`, `Estado: (sin PIN)`);
    } else {
      // t_042f109c (2026-08-18): si el PIN activo es el de fábrica, lo
      // decimos explícitamente. Sin esta coletilla, el operario ve "PIN
      // activo — longitud 9" y no sabe que ese PIN lo conoce cualquiera
      // que haya leído el manual. No cambiamos el formato base (longitud
      // + asteriscos) para no romper asunciones de tests/UI; añadimos
      // un sufijo solo si es el de fábrica.
      const isFac = (typeof window.rotechosAuth?.isFactoryPin === `function`)
        ? window.rotechosAuth.isFactoryPin(pin)
        : (pin === `123456789`);
      const base = t(`msg.pinStatusActive`, `Estado: PIN activo — longitud ${pin.length}`, { len: pin.length }) + ` (${`*`.repeat(pin.length)})`;
      el.textContent = isFac
        ? base + ` — ` + t(`msg.pinStatusFactorySuffix`, `PIN de FÁBRICA (123456789). Te recomendamos cambiarlo.`)
        : base;
    }
  } catch (_) { /* defensivo: dejar el último texto bueno */ }
}

/**
 * Define o cambia el PIN HTTP. Valida coincidencia, aplica cfgPersistPin y
 * re-pinta el estado. NO aborta el modal si algo falla — el PIN es
 * opcional, no es un error que rompa el resto de la UX.
 */
async function _setPin() {
  const a = $(`mcfgPinInput`)?.value ?? ``;
  const b = $(`mcfgPinInputConfirm`)?.value ?? ``;
  if (!a || !b) {
    toast(t(`msg.pinEmpty`, `El PIN está vacío o solo contiene caracteres no permitidos`), `err`);
    return;
  }
  if (a !== b) {
    toast(t(`msg.pinMismatch`, `Los dos campos no coinciden`), `err`);
    return;
  }
  // t_4f22bdc3 (2026-09-01): aunque el panel Configuración pinta el
  // error en vivo, una pulsación rápida del botón Guardar SIN mirar la
  // UI debería seguir bloqueándose. Usamos la MISMA primitiva pura
  // (window.rotechosAuth.validateM551Pin) que el validador en vivo, así
  // si el operario ha tecleado algo inválido y pulsa Guardar, se aborta
  // con el mensaje concreto. Antes la persistencia silenciosamente
  // truncaba/borraba caracteres y el operario se quedaba fuera de la
  // máquina al reiniciar (ver briefing t_4f22bdc3).
  if (typeof window.rotechosAuth?.validateM551Pin === `function`) {
    const v = window.rotechosAuth.validateM551Pin(a);
    if (!v.ok) {
      const fallbackPorMotivo = {
        'demasiado-largo':   `PIN demasiado largo (máximo 24 caracteres).`,
        'espacio':            `El PIN no admite espacios. Quítalo y vuelve a teclear.`,
        'caracter-invalido':  `Carácter no permitido en el PIN. Solo letras, dígitos y los símbolos - _ . @ # ! ? , :.`,
        'desconocido':        `PIN no válido. Revisa el charset y la longitud.`,
      };
      const msg = t(
        `msg.pinCharset.${v.motivo}`,
        fallbackPorMotivo[v.motivo] || fallbackPorMotivo['desconocido']
      );
      toast(msg, `err`);
      return;
    }
  }
  if (typeof window.cfgPersistPin !== `function`) {
    toast(t(`msg.pinFailedApply`, `No se pudo aplicar el PIN — helper no disponible`), `err`);
    return;
  }
  // AVISO INELUDIBLE: el operario debe confirmar que entiende que el paro
  // desde el navegador queda detrás de la sesión. Es decisión expresa de
  // Sergi: "AVISO INELUDIBLE al activarla, con confirmación del usuario".
  const ack = await confirmDialog({
    title: t(`msg.pinActivateTitle`, `Activar PIN HTTP`),
    body:
      `<p>${t(`msg.pinActivateL1`, `Con un PIN activo, el paro de emergencia desde el navegador exige haber iniciado sesión.`)}</p>` +
      `<p>${t(`msg.pinActivateL2`, `Recomendamos una seta física cableada al escudo de firmware (M581, ya activo).`)}</p>` +
      `<p>${t(`msg.pinActivateL3`, `El PIN viaja sin cifrar por HTTP — protege del acceso casual, NO de quien capture tráfico.`)}</p>` +
      `<p><strong>${t(`msg.pinActivateL4`, `¿Continuar y guardar el PIN?`)}</strong></p>`,
    confirmText: t(`msg.pinActivateConfirm`, `Activar PIN`),
    cancelText: t(`button.cancelar-ea78`, `Cancelar`),
    danger: true,
  }).catch(() => false);
  if (!ack) return;
  const ok = await window.cfgPersistPin(a);
  if (!ok) return;     // cfgPersistPin ya muestra el toast del motivo
  // t_042f109c: operario ha acknowledged el PIN de fábrica (lo ha
  // cambiado). Marcar para no volver a mostrarle el aviso en próximos
  // arranques del wizard.
  try { localStorage.setItem('rotechos.pinFactoryAck', '1'); } catch (_) {}
  $(`mcfgPinInput`).value = ``;
  $(`mcfgPinInputConfirm`).value = ``;
  await _renderPinStatus();
  toast(t(`msg.pinSaved`, `PIN guardado. La UI y la API HTTP exigirán este PIN desde ya.`), `ok`);
}

/**
 * Quita el PIN HTTP. Pide confirmación (es destructivo: requiere SD para
 * restaurarlo si cambias de opinión) y persiste borrando la línea M551.
 */
async function _removePin() {
  if (typeof window.cfgMachineRead !== `function` || typeof cfgRemovePin !== `function`) {
    toast(t(`msg.pinFailedApply`, `No se pudo aplicar el PIN — helper no disponible`), `err`);
    return;
  }
  const ack = await confirmDialog({
    title: t(`msg.pinRemoveTitle`, `Quitar PIN HTTP`),
    body:
      `<p>${t(`msg.pinRemoveL1`, `Vas a quitar el PIN HTTP. La UI volverá a abrirse sin pedir contraseña.`)}</p>` +
      `<p>${t(`msg.pinRemoveL2`, `Si tenías un PIN configurado, este cambio se aplica al guardar.`)}</p>` +
      // t_042f109c (2026-08-18, decisión Sergi): la honestidad es lo más
      // importante de la tarjeta. Decir SOLO "se quitará el PIN" es
      // marketing — la verdad es que la UI queda abierta a cualquiera en
      // la red del taller. Este párrafo es deliberadamente crudo, no
      // suavizado: "no es una barrera contra alguien que sepa lo que
      // hace" es la frase literal que Sergi aprobó.
      `<p><strong style="color:var(--warn-strong)">${t(`msg.pinRemoveL3`, `Quitar el PIN deja la máquina accesible para cualquiera en la red del taller (vecino, invitado, técnico en tu WiFi): no es una barrera contra alguien que sepa lo que hace.`)}</strong></p>`,
    confirmText: t(`msg.pinRemoveConfirm`, `Quitar PIN`),
    cancelText: t(`button.cancelar-ea78`, `Cancelar`),
    danger: true,
  }).catch(() => false);
  if (!ack) return;
  try {
    await cfgEsperarEscrituras();
    const raw = await cfgMachineRead();
    if (raw == null) return;
    // Fail-closed — ver _abortConfigMachineNotLoaded (cabecera del fichero).
    if (typeof _cfgMachineLoadOk !== `undefined` && !_cfgMachineLoadOk) {
      _abortConfigMachineNotLoaded();
      return;
    }
    const updated = cfgRemovePin(raw);
    const ok = await cfgMachineWrite(updated);
    if (!ok) return;
    // Defensa contra el bug ALTA de seguridad-auth (agosto 2026):
    // cfgRemovePin usa regex global, pero la persistencia remota podría
    // fallar parcialmente, dejar una segunda línea M551 viva, o el archivo
    // traía un estado que no esperábamos (comentario que empieza por M551
    // después de un ;, BOM, etc.). Releemos FRESCO de la SD y solo
    // confirmamos éxito si NO queda ninguna línea `^M551\b`. Si queda
    // alguna, mostramos el aviso correspondiente y NO emitimos el toast
    // `msg.pinRemoved`: la UI NO debe mentir al operario.
    const reread = await cfgMachineRead();
    const survivors = reread ? (reread.match(/^M551\b/gm) || []) : [];
    if (survivors.length > 0) {
      LOG.warn(
        `removePin: ${survivors.length} línea(s) M551 sobreviven tras cfgRemovePin+write — NO se confirma éxito`,
      );
      toast(
        t(
          `msg.pinRemoveVerifyFail`,
          `No se pudo confirmar la retirada del PIN — quedan ${survivors.length} línea(s) M551 en config-machine.g. Edita la SD manualmente antes de continuar.`,
          { count: survivors.length },
        ),
        `err`,
      );
      await _renderPinStatus();
      return;
    }
    // Aplicar en caliente (defensa en profundidad)
    try { await RRF.gcode(`M551 P""`); } catch (_) {}
    // Limpiar el cache de localStorage para que el siguiente rr_connect
    // no envíe un PIN que ya no existe en la SD.
    if (typeof window !== `undefined` && window.rotechosAuth &&
        typeof window.rotechosAuth.clearStoredPin === `function`) {
      try { window.rotechosAuth.clearStoredPin(); } catch (_) {}
    }
    // t_042f109c: operario ha acknowledged el PIN de fábrica (lo ha
    // quitado del todo). Marcar para no volver a mostrarle el aviso
    // naranja en próximos arranques del wizard.
    try { localStorage.setItem('rotechos.pinFactoryAck', '1'); } catch (_) {}
    await _renderPinStatus();
    toast(t(`msg.pinRemoved`, `PIN HTTP quitado. La UI vuelve a abrirse sin contraseña.`), `ok`);
  } catch (e) {
    LOG.warn(`removePin:`, e);
  }
}

// eslint-disable-next-line no-unused-vars -- listener registrado abajo
async function _saveMachineName() {
  const inp = $(`mcfgMachineName`);
  if (!inp) return false;
  const nombre = inp.value.trim();
  if (!nombre) {
    toast(t(`msg.machineNameVacio`, `El nombre de la máquina no puede estar vacío`), `warn`);
    return false;
  }
  const ok = typeof window.cfgPersistStringGlobal === `function`
    && (await window.cfgPersistStringGlobal(`machineName`, nombre));
  if (!ok) {
    // cfgPersistStringGlobal ya avisa por toast del motivo (fail-closed).
    return false;
  }
  // D-02: ver escGcodeArg en rotechos-dom-utils.js — quitar solo la comilla
  // dejaba pasar un salto de linea, y rr_gcode separa las ordenes por saltos.
  await RRF.gcode(`M550 P"${window.escGcodeArg(nombre)}"`);
  _renderMachineIdentity(nombre);
  // El nombre va FUERA del texto traducible: t() devuelve la cadena EN
  // estática y una interpolación dentro se perdería al cambiar de idioma.
  toast(`${t(`msg.machineNameOk`, `Nombre de máquina guardado`)} — ${nombre}`, `ok`);
  log(`Identidad de máquina → ${nombre} (config-machine.g + M550)`, `sys`);
  return true;
}

// ─── Para soporte tecnico (Fase 4.19, t_58518f6d) ────────────────────
// Pinta el sub-panel "Para soporte tecnico" del tab IDENTIDAD. Reusa
// `ROTECHOS.renderSoporteBloque` (definido en rotechos-version.js, el
// modulo que ya expone VERSION/BUILD/SW_CACHE/GIT_SHA). El helper es
// tolerante: si el poll aun no trajo `boards` desde RRF, los campos de
// placa saldran como "—" y el UUID de instalacion se autogenera en el
// momento. Nunca lanza.
function _renderSoporteBloque(nombre) {
  try {
    if (typeof ROTECHOS === 'undefined' || typeof ROTECHOS.renderSoporteBloque !== 'function') {
      // Modulo de version no cargo (mock-server, carga perezosa rota).
      // Dejamos los campos con su placeholder literal.
      return;
    }
    ROTECHOS.renderSoporteBloque({ nombreMaquina: nombre || null });
  } catch (e) {
    log(`Soporte bloque: no se pudo pintar (${e && e.message})`, 'warn');
  }
}

// Handler del boton "Copiar bloque de soporte". Servida desde la placa (http,
// sin TLS) no hay navigator.clipboard: no se copiaba nada y el aviso decia
// «copiado». Se copia con un textarea y, si el navegador tampoco deja, se
// muestra el bloque para copiarlo a mano.
function _copySoporteBloque() {
  const t = (typeof window.t === 'function') ? window.t : ((k, d) => d);
  const toast = (typeof window.toast === 'function') ? window.toast : (() => {});
  const log = (typeof window.log === 'function') ? window.log : (() => {});
  const mcfgMachineName = (typeof window.$ === 'function') ? window.$('mcfgMachineName') : null;
  const nombre = mcfgMachineName && mcfgMachineName.value ? mcfgMachineName.value.trim() : '';
  let texto = '';
  try {
    if (typeof ROTECHOS === 'undefined' || typeof ROTECHOS.copiarBloqueSoporte !== 'function') {
      toast(t('msg.soporteNoHelper', 'No se pudo generar el bloque de soporte'), 'err');
      return;
    }
    texto = ROTECHOS.copiarBloqueSoporte({ nombreMaquina: nombre });
  } catch (e) {
    toast(t('msg.soporteNoHelper', 'No se pudo generar el bloque de soporte'), 'err');
    log(`Soporte bloque: error al copiar (${e && e.message})`, 'err');
    return;
  }
  let copiado = false;
  try {
    const ta = document.createElement('textarea');
    ta.value = texto;
    ta.style.cssText = 'position:fixed;opacity:0';
    document.body.appendChild(ta);
    ta.select();
    copiado = document.execCommand('copy');
    ta.remove();
  } catch (_) { /* sin execCommand: queda el dialogo */ }
  if (!copiado) {
    confirmDialog({
      title: t('msg.soporteCopiaManual', 'Copia este bloque a mano'),
      body: `<textarea readonly rows=10 style="width:100%">${escHtml(texto)}</textarea>`,
      confirmText: 'OK',
    });
    return;
  }
  toast(t('msg.soporteCopied', `Bloque de soporte copiado al portapapeles`), 'ok');
  log('Bloque de soporte copiado al portapapeles', 'sys');
}

// t_b8cd40c2: este modulo pasa a PEREZOSO, y un modulo perezoso se carga
// SIEMPRE despues de DOMContentLoaded. Enganchar aqui con
// `addEventListener('DOMContentLoaded', ...)` significaba que el callback no
// corria JAMAS y los cinco listeners de abajo quedaban muertos: el operario
// abria CONFIGURACION, veia los botones (el HTML vive en index.html, que es
// eager) y ninguno respondia. Se llevaba por delante ACTIVAR y QUITAR el PIN
// —justo lo que va activo por defecto—, guardar el nombre de la maquina y
// copiar el bloque de soporte.
//
// El patron de abajo es el que ya usan los otros dos modulos perezosos con
// enganches estaticos (rotechos-config-search.js, rotechos-mesh-probe.js):
// engancha ya si el DOM esta listo, y espera solo si de verdad falta. Asi
// sigue siendo correcto tanto si el modulo vuelve a ser eager como si no.
const __mcfgBindStaticHandlers = () => {
  $(`btnSaveMachineName`)?.addEventListener(`click`, _saveMachineName);
  $(`btnMcfgPinSet`)?.addEventListener(`click`, _setPin);
  $(`btnMcfgPinRemove`)?.addEventListener(`click`, _removePin);
  $(`mcfgTabPin`)?.addEventListener(`click`, () => _renderPinStatus());
  // t_58518f6d FASE 4.19: identidad estable para soporte.
  $(`btnCopySupport`)?.addEventListener(`click`, _copySoporteBloque);
};
if (document.readyState === `loading`) {
  document.addEventListener(`DOMContentLoaded`, __mcfgBindStaticHandlers);
} else {
  __mcfgBindStaticHandlers();
}

// eslint-disable-next-line no-unused-vars -- usado por openMachineConfig fuera de este módulo (rotechos.js:495,3305,4404,5149 (btnSysManager + dispatcher F3))
// eslint-disable-next-line no-unused-vars -- (marcador movido: el disable de
// openMachineConfig vive ahora pegado a su propia declaracion, mas abajo)
// H-CFG-01: cierre unico del modal de Configuracion, con restauracion de foco.
// Todas las vias de cierre (boton X, tecla Escape) pasan por aqui para que el
// comportamiento sea el mismo en las dos.
function _mcfgCerrar() {
  // FIX: Cerrar GPIO diag panel si está abierto (evita setInterval huérfano)
  const _diagBtn = $(`btnEndstopDiag`);
  const _diagPanel = $(`endstopDiagPanel`);
  if (_diagPanel && _diagPanel.style.display !== `none` && _diagBtn) _diagBtn.click();
  $(`machineConfigModal`).classList.remove(`show`);
  // Devolver el foco a quien abrio el modal, si sigue en el documento y es
  // enfocable. Si ya no esta (por ejemplo, se re-renderizo la barra), no se
  // fuerza nada: el navegador se queda en <body>, que es el comportamiento
  // por defecto y no empeora nada.
  const _previo = window.__mcfgFocoPrevio;
  window.__mcfgFocoPrevio = null;
  if (_previo && document.contains(_previo) && typeof _previo.focus === `function`) {
    try { _previo.focus(); } catch {}
  }
}

/**
 * CONFIGURACION SOLO EN ESCRITORIO (decision de Sergi, 2026-08-21).
 *
 * En movil (layout-mobile, <768 px) el modal de Configuracion NO se abre por
 * NINGUNA via. Ocultar el boton no bastaba: quedaban abiertas la tecla F3
 * (rotechos.js:5407), el banner "Configurar WiFi ahora" del modo AP
 * (APDetector.openConfig, rotechos.js:4597), el wizard de primer arranque —que
 * vive dentro de este mismo modal— y cualquier llamada directa.
 *
 * Se avisa en vez de no hacer nada: un boton que se pulsa y no responde parece
 * una aplicacion rota, que es justo lo contrario de lo que este producto busca
 * transmitir a alguien que no ha tocado una CNC nunca.
 *
 * CONSECUENCIA ACEPTADA: una maquina recien estrenada no se puede poner en
 * marcha ni conectar al WiFi solo con el telefono; hace falta un ordenador.
 * Es "de momento": el dia que se levante, basta con quitar este guard.
 */
function _mcfgSoloEscritorio() {
  const esMovil = document.body.classList.contains(`layout-mobile`)
    || (typeof window.currentLayout !== `undefined` && window.currentLayout === `mobile`)
    // Ultimo recurso: si el layout aun no se ha aplicado, el mismo umbral.
    || (!document.body.className.includes(`layout-`) && window.detectAutoLayout?.() === `mobile`);
  if (!esMovil) return false;
  toast(
    t(`msg.configSoloEscritorio`,
      `La configuración se hace desde un ordenador. Abre RotechOS en un PC conectado a la misma red que la máquina.`),
    `warn`,
  );
  LOG.warn(`openMachineConfig bloqueado: layout movil (configuracion reservada a escritorio)`);
  return true;
}

// Grupos plegables en TABLETA (ver acta docs/dev/hallazgos/tableta-config-sin-scroll.md).
function _mcfgIsTableta() {
  return window.innerWidth >= 768 && window.innerWidth < 1080;
}
function _mcfgInitSidebarGroups() {
  const headers = Array.from(document.querySelectorAll(
    `#machineConfigModal .mcfg-sidebar-group .mcfg-sidebar-hdr`
  ));
  if (!headers.length) return;
  const tableta = _mcfgIsTableta();
  for (const h of headers) {
    // Re-init listeners al cruzar TABLETA.
    if (h.__mcfgHdrBound) {
      h.removeEventListener(`click`, h.__mcfgHdrClick);
      h.removeEventListener(`keydown`, h.__mcfgHdrKey);
    }
    if (tableta) {
      h.setAttribute(`role`, `button`);
      h.setAttribute(`tabindex`, `0`);
      h.setAttribute(`aria-expanded`, `false`);
    } else {
      h.removeAttribute(`role`);
      h.removeAttribute(`tabindex`);
      h.removeAttribute(`aria-expanded`);
    }
    // Fallback sin :has(): grupo abierto == contiene la pestana activa.
    const group = h.parentElement;
    const hasActive = !!group.querySelector(`.mcfg-tab.active`);
    group.dataset.mcfgGroupOpen = hasActive ? `1` : `0`;
    h.setAttribute(`aria-expanded`, hasActive ? `true` : `false`);
    if (tableta) {
      h.__mcfgHdrClick = () => _mcfgOpenGroup(group);
      h.__mcfgHdrKey = (e) => {
        if (e.key === `Enter` || e.key === ` ` || e.key === `Spacebar`) {
          e.preventDefault();
          _mcfgOpenGroup(group);
        }
      };
      h.addEventListener(`click`, h.__mcfgHdrClick);
      h.addEventListener(`keydown`, h.__mcfgHdrKey);
    }
    h.__mcfgHdrBound = true;
  }
}
// Apertura del grupo en TABLETA.
function _mcfgOpenGroup(group) {
  if (!group) return;
  // PRIMERA pestana del grupo; el ciclador la cambiara despues.
  const firstTab = group.querySelector(`.mcfg-tab[data-tab]`);
  if (!firstTab) return;
  firstTab.click();
  group.dataset.mcfgGroupOpen = `1`;
  const hdr = group.querySelector(`.mcfg-sidebar-hdr`);
  if (hdr) hdr.setAttribute(`aria-expanded`, `true`);
  // Un grupo abierto a la vez; los demas colapsados.
  const allGroups = Array.from(document.querySelectorAll(
    `#machineConfigModal .mcfg-sidebar-group`
  ));
  for (const g of allGroups) {
    if (g === group) continue;
    if (g.querySelector(`.mcfg-tab.active`)) continue;
    g.dataset.mcfgGroupOpen = `0`;
    const h = g.querySelector(`.mcfg-sidebar-hdr`);
    if (h) h.setAttribute(`aria-expanded`, `false`);
  }
}
// Observer del pliegue (aria/data al dia al ciclar flechas).
let __mcfgGroupObserver = null;
function _mcfgEnsureGroupSync() {
  if (__mcfgGroupObserver) return;
  if (typeof MutationObserver === `undefined`) return;
  const sb = document.querySelector(`#machineConfigModal .mcfg-sidebar`);
  if (!sb) return;
  __mcfgGroupObserver = new MutationObserver(() => _mcfgSyncOpenGroup());
  __mcfgGroupObserver.observe(sb, { attributes: true, attributeFilter: [`class`], subtree: true });
}
function _mcfgSyncOpenGroup() {
  if (!_mcfgIsTableta()) return;
  const groups = Array.from(document.querySelectorAll(
    `#machineConfigModal .mcfg-sidebar-group`
  ));
  for (const g of groups) {
    const active = !!g.querySelector(`.mcfg-tab.active`);
    const open = g.dataset.mcfgGroupOpen === `1`;
    if (active && !open) {
      g.dataset.mcfgGroupOpen = `1`;
      const h = g.querySelector(`.mcfg-sidebar-hdr`);
      if (h) h.setAttribute(`aria-expanded`, `true`);
    } else if (!active && open) {
      g.dataset.mcfgGroupOpen = `0`;
      const h = g.querySelector(`.mcfg-sidebar-hdr`);
      if (h) h.setAttribute(`aria-expanded`, `false`);
    }
  }
}
// Re-init ARIA + listeners al cruzar el limite TABLETA (CSS ya cambia apariencia).
let __mcfgResizeRaf = 0;
window.addEventListener(`resize`, () => {
  if (__mcfgResizeRaf) return;
  __mcfgResizeRaf = requestAnimationFrame(() => {
    __mcfgResizeRaf = 0;
    const open = document.getElementById(`machineConfigModal`)?.classList.contains(`show`);
    if (!open) return;
    _mcfgInitSidebarGroups();
    _mcfgSyncOpenGroup();
  });
});
// eslint-disable-next-line no-unused-vars
async function openMachineConfig() {
  if (_mcfgSoloEscritorio()) return;
  // Carga perezosa del modulo de busqueda de ajustes (t_e783de96). Disparar
  // aqui, en cuanto se muestra el modal, garantiza que el campo #cfgSearchInput
  // tiene sus listeners conectados ANTES de que el operario teclee. Mismo
  // patron que el resto de perezosos (aceleracion, pines).
  __loadCfgSearch();
  // Determinar pestaña inicial: si la máquina es virgen (config.g Y config-machine.g
  // ambos vacíos o ausentes), abrir el wizard de primer arranque para guiar al cliente
  // plug-and-play. En máquinas ya calibradas, abrir MOTORES como antes.
  //   raw + machineRaw === ''  → virgen → tab=wizard
  //   cualquier otro caso      → tab=motors (default histórico, julio 2026)
  //   NOTA: cfgRead() tiene caché interno (_cfgRaw en rotechos-config-persist.js:14),
  //   por lo que reusar la lectura existente no duplica fetch contra la placa.
  //   Hacemos una sola ronda cfgRead+cfgMachineRead y la usamos para 2 cosas:
  //     (1) decidir initialTab
  //     (2) popular el modal via cfgPopulate
  const raw = await cfgRead();
  const machineRaw = await cfgMachineRead();  // puede ser '' si no existe (máquina virgen)
  // Identidad de la máquina conectada: se reusa esta misma ronda de lecturas,
  // sin fetch extra. Nunca bloquea el modal (fallback a M550 / RotechCNC).
  _renderMachineIdentity(_machineNameFrom(raw, machineRaw));
  // t_58518f6d FASE 4.19: el panel "Para soporte tecnico" reusa los
  // mismos campos de identidad; lo pintamos junto al nombre para que el
  // operario los vea abrir el modal.
  _renderSoporteBloque(_machineNameFrom(raw, machineRaw));
  const isVirgen = !raw?.trim() && !machineRaw?.trim();
  const initialTab = isVirgen ? `wizard` : `motors`;
  const initialPanelId = `mcfgTab${initialTab[0].toUpperCase()}${initialTab.slice(1)}`;

  (window.__rotechosModalLastFocus = document.activeElement,
    // H-CFG-01 (auditoria UI 2026-08-14, ALTA): recordar quien tenia el foco
    // para devolverselo al cerrar. Sin esto, al cerrar el modal el foco queda
    // en un elemento oculto y el siguiente Tab reempieza desde el principio
    // del documento — quien navega con teclado se pierde.
    (window.__mcfgFocoPrevio = document.activeElement),
    $(`machineConfigModal`).classList.add(`show`),
    document
      .querySelectorAll(`.mcfg-tab`)
      .forEach((t) => t.classList.remove(`active`)),
    document
      .querySelectorAll(`.mcfg-panel`)
      .forEach((p) => (p.style.display = `none`)),
    document
      .querySelector(`.mcfg-tab[data-tab=${initialTab}]`)
      ?.classList.add(`active`),
    ($(initialPanelId).style.display = `block`),
    ($(`btnMcfgApply`).style.display = ``),
    ($(`btnMcfgApply`).disabled = !0),
    ($(`btnMcfgApply`).textContent = t(`msg.loading`, `Cargando…`)));
  (($(`btnMcfgApply`).disabled = !1),
    ($(`btnMcfgApply`).innerHTML =
      `<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg> <span data-i18n="cfg.btn.apply">${t(`cfg.btn.apply`, `Aplicar`)}</span>`),
    raw && (await cfgPopulate(raw, machineRaw)),
    renderMacros(),
    // t_8ebcb0bc — banner "MÁQUINA SIN CALIBRAR" (config-machine.g vacío o con
    // los fallbacks genéricos de config.g). Función pura vive en
    // rotechos-config-persist.js (isMachineCalibrated) y se cubre con el test
    // unitario cfg-machine-calibrated.test.js.
    _renderCalibrationBanner(machineRaw),
    // Inicializa ARIA de cabeceras y deja abierto el grupo activo.
    _mcfgInitSidebarGroups(),
    _mcfgEnsureGroupSync(),
    typeof AppState.ui.mcfgDirtyClear === `function` && AppState.ui.mcfgDirtyClear());
}

// t_8ebcb0bc — pinta/oculta el banner de "MÁQUINA SIN CALIBRAR". Idempotente.
function _renderCalibrationBanner(machineRaw) {
  const el = document.getElementById(`mcfgCalibWarn`);
  if (!el) return;
  const calibrated = (typeof window.isMachineCalibrated === `function`)
    ? window.isMachineCalibrated(machineRaw)
    : (typeof isMachineCalibrated === `function` && isMachineCalibrated(machineRaw));
  // El estado se guarda aqui; QUE pestanas lo muestran lo decide el cambio de
  // pestana en rotechos.js (_CALIB_TABS). Motivo: el aviso solo es accionable
  // donde se calibra, y en las pestanas apretadas (speeds a 1280x720 con modo
  // escuela va al suelo de fit 0.78) sus 33 px ponian en rojo el gate de
  // sin-scroll — medido, 9 zonas.
  el.dataset.sinCalibrar = calibrated ? `0` : `1`;
  if (typeof window.mcfgSyncCalibWarn === `function`) window.mcfgSyncCalibWarn();
}
loadPersistentUiConfig();
// Techo operativo de RotechOS = 3100 mA RMS (definido en HW_LIMITS.currentMa.max).
//   Límite físico del silicio TMC2160 = 4700 mA peak (datasheet BTT).
//   El 3100 mA deja margen frente al límite del driver para motores NEMA 23 típicos.
const TMC_MAX_RMS = 3100;
function updateCurrentBar(ax) {
  const val = parseFloat($(`mcfgM906${ax}`).value) || 0,
    bar = $(`mcfgBar${ax}`);
  if (!bar) return;
  const pct = Math.min(100, (val / TMC_MAX_RMS) * 100);
  ((bar.style.transform = `scaleX(${pct / 100})`),
    (bar.style.color =
      pct > 90 ? `var(--red)` : pct > 70 ? `var(--warn-strong)` : `var(--green)`));
}
[`X`, `Y`, `Z`, `A`].forEach((ax) => {
  const inp = $(`mcfgM906${ax}`);
  inp &&
    inp.addEventListener(`input`, () => {
      updateCurrentBar(ax);
      const val = parseFloat(inp.value) || 0;
      val > TMC_MAX_RMS
        ? ((inp.style.borderColor = `var(--red)`),
          toast(
            `${ax}: ${val} mA ${t(`msg.tmcLimitWarn`, `supera el límite RMS del TMC2160 en esta placa (3100 mA con R0.05Ω)`)}`,
            `warn`,
          ))
        : (inp.style.borderColor = ``);
    });
});
function updateExtDriver(ax, isExt) {
  const lbl = $(`extDrvLbl${ax}`),
    note = $(`extDrvNote${ax}`),
    curInput = $(`mcfgM906${ax}`),
    curBar = $(`mcfgBar${ax}`),
    curWrap = curBar?.closest(`.mcfg-cur-bar-wrap`),
    typeSel = $(`mcfgExtDrvType${ax}`),
    customInp = $(`mcfgExtDrvCustom${ax}`);
  if (lbl)
    ((lbl.textContent = isExt ? t(`msg.external`, `Externo`) : `TMC2160`),
      (lbl.style.color = isExt ? `var(--purple)` : `var(--text-3)`));
  if (note) note.style.display = isExt ? `block` : `none`;
  if (curInput) {
    curInput.disabled = isExt;
    curInput.style.opacity = isExt ? `.35` : ``;
  }
  if (curBar) curBar.style.opacity = isExt ? `.2` : ``;
  if (curWrap) curWrap.style.opacity = isExt ? `.35` : ``;
  // Selector T + custom input: solo visibles cuando el toggle externo está ON.
  // El change del select también ajusta la visibilidad del input custom
  // (solo aparece cuando el usuario elige "Otro externo (manual)").
  if (typeSel) typeSel.style.display = isExt ? `block` : `none`;
  if (customInp) {
    const wantsCustom = typeSel?.value === 'custom';
    customInp.style.display = (isExt && wantsCustom) ? `block` : `none`;
  }
}
([`X`, `Y`, `Z`, `A`].forEach((ax) => {
  const el = $(`mcfgExt${ax}`);
  if (!el) return;
  el.addEventListener(`change`, () => {
    // Fase 3.3 §10 (t_1b74ed31): cuando el operario ACTIVA un driver externo,
    // marcamos el checkbox para que el diálogo de reboot pueda añadir un
    // aviso naranja explicando qué cambia (M906 se omite para ese eje, la
    // corriente pasa al dial hardware del driver). Solo se marca enciende
    // → apagado, NO al revés (apagar driver externo no requiere el aviso).
    if (el.checked) el.dataset.wasUnchecked = `1`;
    else delete el.dataset.wasUnchecked;
    return updateExtDriver(ax, el.checked);
  });
}),
  [`X`, `Y`, `Z`, `A`].forEach((ax) => {
    // Al cambiar el tipo de driver externo, re-evaluar visibilidad del input
    // custom (updateExtDriver lo lee de typeSel.value === 'custom').
    const sel = $(`mcfgExtDrvType${ax}`);
    sel && sel.addEventListener(`change`, () => updateExtDriver(ax, $(`mcfgExt${ax}`)?.checked));
  }),
  $(`btnMcfgClose`).addEventListener(`click`, () => {
    _mcfgCerrar();
  }));

// Buscador de ajustes del modal de Configuracion:
//   El cuerpo del modulo (indice de pestanas, ranking, render del
//   dropdown) vive en `rotechos-config-search.js` (t_e783de96, 2026-09-05;
//   reubicado DEFINITIVAMENTE fuera de este fichero por t_ec990fc0,
//   2026-09-05, despues de que el merge de lote lo dejara duplicado).
//   Se carga de forma perezosa con `__loadCfgSearch()` (definido al final
//   del fichero, junto a `__loadAccelCurve` y `__loadPinesUi`).
//   El campo de busqueda (#cfgSearchInput) sigue en el DOM y se enchufa
//   en cuanto el modulo resuelve. Contrato: expone
//   `window.MCFG_SEARCH = { search, go, close }` al cargarse.

// Atajos del modal de configuración:
//   ESC             → cerrar modal
//   Ctrl/Cmd+S      → guardar la pestaña activa
//   ← / →           → navegar entre pestañas (cuando el foco NO está en un input)
document.addEventListener(`keydown`, (e) => {
  const modal = $(`machineConfigModal`);
  if (!modal?.classList.contains(`show`)) return;
  if (e.key === `Escape`) {
    e.preventDefault();
    // Por el MISMO camino que la X, no directo a _mcfgCerrar(). El aviso de
    // «tienes cambios sin guardar» vive en un listener del boton
    // (rotechos-ui-feedback.js:248), no aqui dentro, asi que llamar a
    // _mcfgCerrar() se lo saltaba: con Escape se perdian los cambios de
    // CUALQUIER pestaña sin preguntar. Medido el 21-sep en MAPA DE ALTURA.
    // La cabecera de _mcfgCerrar() decia que «todas las vias de cierre pasan
    // por aqui»; no era cierto, y ahora si lo es.
    const _x = $(`btnMcfgClose`);
    if (_x) _x.click(); else _mcfgCerrar();
    return;
  }
  if ((e.ctrlKey || e.metaKey) && (e.key === `s` || e.key === `S`)) {
    e.preventDefault();
    const btn = $(`btnMcfgApply`);
    if (btn && btn.style.display !== `none` && !btn.disabled) btn.click();
    return;
  }
  // Navegación entre pestañas con flechas — solo si el foco NO está en un
  // campo editable (input/textarea/select). Esto preserva el comportamiento
  // nativo de las flechas ←/→ dentro de inputs (mover cursor / cambiar valor
  // en <select>), y evita capturar el atajo cuando el operario edita un campo.
  if (e.key === `ArrowLeft` || e.key === `ArrowRight`) {
    const ae = document.activeElement;
    const tag = ae?.tagName;
    const editable = tag === `INPUT` || tag === `TEXTAREA` || tag === `SELECT`;
    if (editable) return;  // dejar que el navegador use la flecha como cursor/valor
    const tabs = Array.from(document.querySelectorAll(`.mcfg-sidebar .mcfg-tab[data-tab]`));
    if (!tabs.length) return;
    const cur = tabs.findIndex((t) => t.classList.contains(`active`));
    const next = e.key === `ArrowRight`
      ? (cur + 1) % tabs.length
      : (cur - 1 + tabs.length) % tabs.length;
    e.preventDefault();
    tabs[next].click();
    // Si la nueva pestana cae en grupo plegado, abrirlo sincrónicamente
    // (el MutationObserver tambien lo haría pero async, y el gate medía
    // antes del re-pliegue).
    if (typeof _mcfgSyncOpenGroup === `function`) _mcfgSyncOpenGroup();
    _mcfgEnsureGroupSync();
  }
});
function applyAxisAMode(mode) {
  // Bloque 5 jul-2026: extender la ocultación a TODOS los paneles que tienen
  // campos del eje A (Motores, Velocidades, Backlash). Antes sólo Motores
  // recibía axis-a-disabled → los axis-a-col de Speeds y Backlash seguían
  // visibles aunque axisAMode=off. Ahora aplicamos la clase al panel de los 3
  // tabs para que la CSS los oculte con display:none.
  const motorsPanel = $(`mcfgTabMotors`);
  motorsPanel &&
    (motorsPanel.classList.remove(`axis-a-disabled`, `axis-a-slave`, `axis-a-rotary`),
    ($(`axisAHintOff`).style.display =
      mode === `off` ? `block` : `none`),
    ($(`axisAHintSlave`).style.display =
      mode === `slave` ? `block` : `none`),
    ($(`axisAHintRotary`).style.display =
      mode === `rotary` ? `block` : `none`),
    mode === `off`
      ? motorsPanel.classList.add(`axis-a-disabled`)
      : mode === `slave`
        ? motorsPanel.classList.add(`axis-a-slave`)
        : mode === `rotary` && motorsPanel.classList.add(`axis-a-rotary`));
  // Velocidades y Backlash también: usan axis-a-col para sus inputs A.
  const speedsPanel = $(`mcfgTabSpeeds`);
  speedsPanel && speedsPanel.classList.toggle(`axis-a-disabled`, mode === `off`);
  const backlashPanel = $(`mcfgTabBacklash`);
  backlashPanel && backlashPanel.classList.toggle(`axis-a-disabled`, mode === `off`);
  const jogACol = $(`jogAxisACol`);
  if (jogACol) jogACol.style.display = mode === `rotary` ? `flex` : `none`;
  const droARow = $(`droAxisARow`);
  if (droARow) droARow.style.display = mode === `rotary` ? `flex` : `none`;
}
($$(`input[name="axisAMode"]`).forEach((r) => {
  r.addEventListener(`change`, () => applyAxisAMode(r.value));
}),
  applyAxisAMode(`off`),
  document
    .getElementById(`btnEndstopRefresh`)
    .addEventListener(`click`, async () => {
      // FIX: M119 sólo reporta endstops declarados con M574. Los sensores configurados
      // como GPIO (M950 J*) no aparecen. Leemos directamente sensors.gpIn del Object Model.
      // Mapeo BTT Scylla V1.0: J0=Y Min(A.8), J1=Y Max(D.14), J2=Z Min(C.7), J3=Z Max(D.12), J4=X Max(C.6), J5=X Min(D.11)
      try {
        const r = await _fetchRRF(`${TARGET_IP}/rr_model?key=sensors.gpIn&flags=d99`, {}, 3000);
        if (!r.ok) throw Error(`HTTP ${r.status}`);
        const data = await r.json();
        const gpIn = (data && data.result) || [];
        const tX = _endstopCfg.X.trigLevel, tY = _endstopCfg.Y.trigLevel,
              tZ = _endstopCfg.Z.trigLevel;
        const STATE = {
          X: {
            Min: { triggered: gpIn[5]?.value === tX, on: _endstopCfg.X.minOn },
            Max: { triggered: gpIn[4]?.value === tX, on: _endstopCfg.X.maxOn },
          },
          Y: {
            Min: { triggered: gpIn[0]?.value === tY, on: _endstopCfg.Y.minOn },
            Max: { triggered: gpIn[1]?.value === tY, on: _endstopCfg.Y.maxOn },
          },
          Z: {
            Min: { triggered: gpIn[2]?.value === tZ, on: _endstopCfg.Z.minOn },
            Max: { triggered: gpIn[3]?.value === tZ, on: _endstopCfg.Z.maxOn },
          },
        };
        const nowTs = Date.now();
        [`X`, `Y`, `Z`].forEach((ax) => {
          [`Min`, `Max`].forEach((side) => {
            const led = $(`ledEnd${ax}${side}`);
            if (!led) return;
            const { triggered, on } = STATE[ax][side];
            // Estado de la LECTURA (t_7edbf98d): separar config de lectura.
            // 4 estados: free / active / off / unknown. Codificación redundante
            // (icono + texto + color) para daltónicos.
            const readState = on ? (triggered ? `active` : `free`) : `off`;
            const container = led.closest(`.mcfg-endread`);
            if (container) {
              container.dataset.readState = readState;
              container.dataset.readTs = String(nowTs);
              const icon = container.querySelector(`.mcfg-endread-icon`);
              const text = container.querySelector(`.mcfg-endread-text`);
              const age  = container.querySelector(`.mcfg-endread-age`);
              if (icon) icon.textContent = ({free:`✓`, active:`✕`, off:`—`, unknown:`?`})[readState];
              if (text) {
                text.dataset.i18n = `cfg.endstops.read.${readState}`;
                text.textContent = t(`cfg.endstops.read.${readState}`,
                  ({free:`LIBRE`, active:`ACTIVADO`, off:`NO CONFIG.`, unknown:`NO LEÍDO`})[readState]);
              }
              if (age)  age.textContent = formatReadAge(nowTs);
            }
            // Mantener la compatibilidad con el LED simple (color y title).
            led.classList.toggle(`triggered`, on && triggered);
            led.classList.toggle(`ok`,       on && !triggered);
            led.title = on
              ? `${ax} ${side}: ${triggered ? `✕ ACTIVO` : `libre`}`
              : `${ax} ${side}: No configurado`;
          });
        });
        toast(t(`msg.endstopsActualizados`, `Endstops actualizados`), `ok`);
      } catch (e) {
        LOG.error(`Endstop refresh:`, e);
        toast(t(`msg.errorLeyendoSensoresGpio`, `Error leyendo sensores GPIO`), `err`);
      }
    }));
/**
 * formatReadAge(ts) — marca de tiempo relativa ("hace 3 s", "hace 5 min",
 * "hace 2 h", "ahora", "—"). t_7edbf98d: añade cuándo se leyó por última
 * vez la celda de lectura; sin timestamp, un estado puede ser de hace
 * 1 ms o de hace 5 min y el operario no lo sabe.
 *
 * @param {number|null} ts  epoch ms (o null si nunca se ha leído)
 * @returns {string}        texto legible en ES (la clave i18n específica
 *                          no existe porque es una transformación dinámica
 *                          de duración — el browser la traduce por contexto)
 */
function formatReadAge(ts) {
  if (ts == null) return `—`;
  const ageMs = Date.now() - ts;
  // 3-oct: con la interfaz en ingles salia «ahora» / «hace 5 s».
  const tt = (k, es, v) => (typeof window !== `undefined` && typeof window.t === `function` ? window.t(k, es, v) : es);
  const now = tt(`cfg.readAge.now`, `ahora`);
  if (ageMs < 0)              return now;
  const s = Math.floor(ageMs / 1000);
  if (s < 60)                 return s === 0 ? now : tt(`cfg.readAge.ago`, `hace ${s} s`, { n: `${s} s` });
  const min = Math.floor(s / 60);
  if (min < 60)               return tt(`cfg.readAge.ago`, `hace ${min} min`, { n: `${min} min` });
  const h = Math.floor(min / 60);
  return tt(`cfg.readAge.ago`, `hace ${h} h`, { n: `${h} h` });
}
window.formatReadAge = formatReadAge;
// §4.8 (t_014cd150) — export del guard compartido para SONDA/SAC. El plan
// prohíbe duplicar machineMoveBlocked() / allHomed: rotechos.js (los
// quick-actions) llama a window.cfgProbeGuard('probe'|'m6') y consume el
// veredicto. Si NO exportamos, los botones vuelven a tener el mismo
// "solo RUNNING" check que ya tenían (insuficiente).
// (window.cfgProbeGuard lo publica ahora rotechos-config-modal-core.js)
window.renderSondaRecorridoMax = _renderSondaRecorridoMax;
window.renderSondaBannerHome = _renderSondaBannerHome;
/** Dimea el input de pin cuando su toggle está OFF */
function updateEndstopRowState(ax) {
  [`Min`, `Max`].forEach((side) => {
    const on = $(`mcfgEnd${ax}${side}On`)?.checked ?? !1;
    const pinEl = $(`mcfgEndPin${ax}${side}`);
    pinEl && ((pinEl.disabled = !on), (pinEl.style.opacity = on ? `` : `0.35`));
  });
  // Sincronizar _endstopCfg por eje
  _endstopCfg[ax].minOn = $(`mcfgEnd${ax}MinOn`)?.checked ?? !1;
  _endstopCfg[ax].maxOn = $(`mcfgEnd${ax}MaxOn`)?.checked ?? !1;
  _endstopCfg[ax].off = !_endstopCfg[ax].minOn && !_endstopCfg[ax].maxOn;
  // t_7edbf98d: reflejar el nuevo estado en la celda "Lectura" inmediatamente,
  // sin esperar al siguiente poll. Si el operario apaga un endstop, la celda
  // pasa a "NO CONFIG." al instante; si lo enciende, queda en estado "?"
  // (unknown) hasta que llegue el primer poll o se pulse LEER ENTRADAS.
  const _nowTs = Date.now();
  const _ageFn = (typeof formatReadAge === `function`) ? formatReadAge
               : (typeof window.formatReadAge === `function`) ? window.formatReadAge
               : null;
  [`Min`, `Max`].forEach((side) => {
    const sideOn = side === `Min` ? _endstopCfg[ax].minOn : _endstopCfg[ax].maxOn;
    const led = $(`ledEnd${ax}${side}`);
    if (!led) return;
    const cont = led.closest(`.mcfg-endread`);
    if (!cont) return;
    const readState = sideOn ? `unknown` : `off`;
    cont.dataset.readState = readState;
    cont.dataset.readTs = String(_nowTs);
    const icon = cont.querySelector(`.mcfg-endread-icon`);
    const text = cont.querySelector(`.mcfg-endread-text`);
    const age  = cont.querySelector(`.mcfg-endread-age`);
    if (icon) icon.textContent = ({free:`✓`, active:`✕`, off:`—`, unknown:`?`})[readState];
    if (text) {
      text.dataset.i18n = `cfg.endstops.read.${readState}`;
      text.textContent = t(`cfg.endstops.read.${readState}`,
        ({free:`LIBRE`, active:`ACTIVADO`, off:`NO CONFIG.`, unknown:`NO LEÍDO`})[readState]);
    }
    if (age && _ageFn) age.textContent = _ageFn(_nowTs);
    // LED: sin clase hasta el primer poll
    led.classList.remove(`triggered`, `ok`);
  });
}
([`X`, `Y`, `Z`].forEach((ax) => {
  [`Min`, `Max`].forEach((side) => {
    const tog = $(`mcfgEnd${ax}${side}On`);
    const typeEl = $(`mcfgEndType${ax}${side}`);
    tog && (updateEndstopRowState(ax),
      tog.addEventListener(`change`, () => updateEndstopRowState(ax)));
    // NC/NO: actualiza el nivel de trigger del pill en tiempo real
    typeEl && typeEl.addEventListener(`change`, () => {
      _endstopCfg[ax].trigLevel = typeEl.value === `NO` ? 0 : 1;
    });
  });
}),
  // ─── Click defensivo para tarjetas de dirección de homing (mcfgHomDirCard{X|Y|Z}) ───
  // El label CSS `:has(input:checked)` depende del navegador y `display:none` en
  // el input puede impedir el toggle nativo en algunos casos. Este handler
  // garantiza que la card siempre cambie de estado al hacer clic.
  ([`X`, `Y`, `Z`].forEach((ax) => {
    const card = $(`mcfgHomDirCard${ax}`);
    const input = $(`mcfgHomDir${ax}`);
    if (card && input) {
      card.addEventListener(`click`, (e) => {
        if (e.target === input) return; // clic directo en el input nativo
        e.preventDefault();
        input.checked = !input.checked;
        input.dispatchEvent(new Event(`change`, { bubbles: true }));
      });
    }
  })),
    (() => {
      const btnMcfgApply = document.getElementById(`btnMcfgApply`);
      let saveErrorTimer = null;
      btnMcfgApply.addEventListener(`click`, async () => {
      if (saveErrorTimer) {
        clearTimeout(saveErrorTimer);
        saveErrorTimer = null;
      }
      const activeTab = $q(`.mcfg-tab[data-tab].active`)?.dataset.tab;
      if (!activeTab) {
        toast(t(`msg.seleccionaUnaPestaña`, `Selecciona una pestaña`), `warn`);
        return;
      }
      // 15-sep: con un trabajo en marcha o en pausa no se guarda. Los rtCmds (M92, M350,
      // M581 R-1…) y el M999 del reinicio caían en pleno trabajo.
      if (SM.current === STATES.RUNNING || SM.current === STATES.PAUSED) {
        toast(t(`msg.cfgBloqueadoTrabajo`, `Con un trabajo en marcha o en pausa no se guarda la configuración.`), `warn`);
        return;
      }

      // FIX H-4-01 (carril 4, MEDIA): en PIN, About y resto de pestañas sin
      // rama en el switch del save (backup/ota/guide/pines/viz/wizard/
      // jobhistory/keyboard/glossary), pulsar Guardar caía en el bloque else
      // de cfgWrite/cfgMachineWrite con `content` SIN modificar y mostraba
      // toast verde "Guardado ✓" — FALSO POSITIVO. El operario creía que su
      // cambio (PIN, nombre de máquina) se había guardado cuando el botón
      // genérico no hace nada en esos tabs. Los botones específicos sí
      // funcionan (btnMcfgPinSet, btnSaveMachineName), pero el "Guardar"
      // genérico engañaba. Bloquear aquí con un toast claro: "Esta pestaña
      // usa un botón específico" + mencionar cuál.
      // t_7c0ad504 movio el bloque SAC (posiciones del cambio de herramienta y
      // parametros de palpado, campos mcfgSac*) de la pestana SONDA a esta.
      // 'tools' NO estaba aqui porque su tabla M563 usa botones por fila, y al
      // entrar el SAC esos campos se quedaron SIN NINGUNA ruta de guardado: el
      // operario editaba y el Guardar generico lo rechazaba con un toast.
      // Ahora 'tools' guarda el SAC (rama propia mas abajo); la TABLA sigue
      // guardandose con sus botones de fila, y el toast de la rama lo dice.
      const _SAVE_TABS = new Set(['homing','endstops','softlimits','spindle','probe','motors','macros','backlash','speeds','ledrgb','motortimeout','fans','network','inputshaping','tools']);
      if (!_SAVE_TABS.has(activeTab)) {
        let _hint;
        if (activeTab === 'pin') _hint = t('msg.guardarPinUsarBoton', 'PIN: usa el botón "Definir / cambiar PIN" específico, no el botón Guardar genérico.');
        else if (activeTab === 'about') _hint = t('msg.guardarAboutUsarBoton', 'Nombre de máquina: usa el botón "Guardar nombre" específico, no el botón Guardar genérico.');
        else if (activeTab === 'tools') _hint = t('msg.guardarToolsUsarBoton', 'Herramientas: usa los botones "Añadir / Guardar / Borrar" específicos de cada fila, no el botón Guardar genérico.');
        else _hint = t('msg.guardarEstaPestañaNo', 'Esta pestaña no usa el botón Guardar genérico — tiene sus propios controles de guardado.');
        toast(_hint, 'warn');
        return;
      }

      // ── Routing: per-machine tabs → config-machine.g ; hardware → config.g ──
      const MACHINE_TABS = new Set(['motors', 'speeds', 'softlimits', 'backlash', 'pin', 'tools', 'motortimeout', 'fans', 'network', 'inputshaping']);  // fundido al integrar: cada tarjeta anadio las suyas
      const isMachineTab = MACHINE_TABS.has(activeTab);
      if (isMachineTab && !_cfgMachineRaw) {
        // FIX H-2-01: la caché puede estar vacía porque el modal se abrió sin
        // completar la lectura, o porque la lectura FALLÓ. Releer aquí y, si la
        // lectura no es válida, ABORTAR: con el fallback de una línea, Guardar
        // subía un config-machine.g vacío ENCIMA de la calibración del cliente
        // (pasos/mm, corrientes, área, sonda). Fail-closed — ver _abortConfigMachineNotLoaded.
        await cfgMachineRead();
        if (!_cfgMachineLoadOk) {
          _abortConfigMachineNotLoaded();
          return;
        }
      }
      // A§10, primera mitad: el blur del campo dispara su `onchange` instantaneo
      // y el click de Guardar llega casi a la vez. Si construimos `content` con
      // la cache de antes del blur, este Guardar pisa lo que aquel acababa de
      // escribir. Esperamos a que la cola de escrituras se vacie y RELEEMOS, asi
      // que partimos del estado real de la SD. La segunda mitad esta en
      // `cfgMachineWrite` (rotechos-config-persist.js), que ademas aborta si el
      // fichero cambio entre esta lectura y la escritura.
      if (isMachineTab && typeof cfgEsperarEscrituras === `function`) {
        await cfgEsperarEscrituras();
        await cfgMachineRead();
        if (!_cfgMachineLoadOk) { _abortConfigMachineNotLoaded(); return; }
      }
      let content = isMachineTab
        ? (_cfgMachineRaw || `; config-machine.g — generado por RotechOS\n`)
        : (_cfgRaw || (await cfgRead()) || ``);
      if (!content) {
        toast(t(`msg.configgNoCargado`, `config.g no cargado`), `err`);
        return;
      }
      const rtCmds = [],
        btn = $(`btnMcfgApply`);
      ((btn.disabled = !0), (btn.textContent = t(`msg.guardando`, `Guardando…`)));
      try {
        if (activeTab === `homing`) {
          // 15-sep (auditoría A): Guardar ya NO regenera homeall.g. El generado iba en
          // coordenadas ABSOLUTAS (sin G91: el retroceso recorría el eje entero y G92
          // fijaba una cota falsa) y sin las guardas del homeall.g de la SD
          // (check_homing_safe, M913, pull-up ^, recover_triggers). Velocidades,
          // dirección y orden son de sys/homeall.g y aquí solo se muestran.
          const homReq = $(`mcfgHomingRequired`).checked,
            softLim = $(`mcfgSoftLimits`)?.checked ?? true;
          _softLimitsEnabled = softLim;
          content = cfgReplaceLine(content, `M564 `, `M564 H{global.requireHoming ? 1 : 0} S{global.softLimitsOn ? 1 : 0}  ; H y S derivan de globals`);
          rtCmds.push(`M564 H${homReq ? 1 : 0} S${softLim ? 1 : 0}`, `set global.softLimitsOn = ${softLim}`, `set global.requireHoming = ${homReq}`);
          cfgPersistGlobalLine(`requireHoming`, `global requireHoming = ${homReq}`);
          cfgPersistGlobalLine(`softLimitsOn`, `global softLimitsOn = ${softLim}`);
        } else if (activeTab === `endstops`) {
          // M574 + rotech-pills + localStorage de trigLevels — MIGRADO a CFG_FIELDS.M574
          // Lógica única en CFG_FIELDS: validación de pines, generación de 8 líneas M574,
          // persistencia rotech-pills y cache local de trigLevels. El customSave dispara
          // su propio toast de error y devuelve ok:false; aquí lanzamos para abortar el flujo.
          // FIX Fase 4.4: cfgFieldsRunCustom ahora es async para soportar
          // customSave async (M208 pide confirmDialog si pos-fuera de rango).
          {
            const r = await cfgFieldsRunCustom('M574', content, rtCmds);
            if (!r.ok) throw Error('validation');
            content = r.content;
          }
          log(`Endstops guardados en config.g`, `sys`);
        } else if (activeTab === `softlimits`) {
          // M208 (soft limits) — MIGRADO a CFG_FIELDS.M208
          // Lógica única en CFG_FIELDS: escribe M208 min/max + M564 S (toggle global),
          // preservación del eje A si aActive, y actualización de VIZ.workLimits.
          // FIX Fase 4.4: customSave es async (puede pedir confirmDialog si la
          // posición actual queda fuera del nuevo rango), por eso se AWAITA.
          {
            const r = await cfgFieldsRunCustom('M208', content, rtCmds);
            if (!r.ok) throw Error('validation');
            content = r.content;
          }
          log(`Soft limits guardados en config.g`, `sys`);
        } else if (activeTab === `spindle`) {
          // M950 R0 + modo + RPM + ramp — MIGRADO a CFG_FIELDS.SPINDLE
          // Validación RPM, clamp 6000-24000, generación por modo (PWM/relay/modbus),
          // persistencia del ramp y update de CFG.maxRPM viven en el customSave.
          // FIX Fase 4.4: cfgFieldsRunCustom es async (ver M208 arriba).
          {
            const r = await cfgFieldsRunCustom('SPINDLE', content, rtCmds);
            if (!r.ok) throw Error('validation');
            content = r.content;
          }
          log(`Spindle guardado en config.g`, `sys`);
          // Persistir ramp a config-machine.g (preferencia per-máquina, no hardware)
          {
            const ramp = parseFloat($('mcfgSpindleRamp').value) || 3;
            let mRaw = await cfgMachineRead();
            if (mRaw == null) mRaw = ``;
            // Fail-closed — ver _abortConfigMachineNotLoaded (cabecera del fichero).
            if (typeof _cfgMachineLoadOk !== 'undefined' && !_cfgMachineLoadOk) {
              _abortConfigMachineNotLoaded();
              return;
            }
            const rampLine = `; rotech-spindle-ramp=${ramp}`;
            mRaw = mRaw.includes('; rotech-spindle-ramp=')
              ? mRaw.replace(/; rotech-spindle-ramp=[\d.]+/, rampLine)
              : mRaw + `\n` + rampLine + `\n`;
            await cfgMachineWrite(mRaw);
          }
          // t_e234f3be: aspiración que sigue al husillo. Interruptor + retardo
          // se persisten en config-machine.g vía cfgPersistComment (mismo
          // patrón que `; rotech-sac=true|false`). El módulo rotechos-aspiracion-follow
          // se ocupa del M42 P{n} S0/S1 leyendo spindles[0].state desde el poll.
          if (typeof window.ASPIR_FOLLOW === `object` && window.ASPIR_FOLLOW &&
              typeof window.ASPIR_FOLLOW.persistConfig === `function`) {
            const sw = $(`mcfgAspirFollow`);
            const delayEl = $(`mcfgAspirFollowDelay`);
            const enabled = !!(sw && sw.checked);
            const delay = Math.max(0, Math.min(600, parseInt(delayEl?.value) || 15));
            await window.ASPIR_FOLLOW.persistConfig({ enabled, delay });
            // Si el operario APAGÓ el interruptor, apagamos YA la aspiración
            // sin esperar al retardo. El módulo conserva el timer; cancel()
            // lo mata y emite M42 P{n} S0 si estaba activa.
            if (!enabled && typeof window.ASPIR_FOLLOW.cancel === `function`) {
              window.ASPIR_FOLLOW.cancel();
            }
            log(`Aspiración sigue al husillo: ${enabled ? `ON, retardo ${delay}s` : `OFF`}`, `sys`);
          }
          // SAC: posiciones de cambio de herramienta — MIGRADO a CFG_FIELDS.
          // Las definiciones viven en CFG_FIELDS al inicio del archivo: matcher,
          // formatter, validador y rtCmd están centralizados ahí. Para añadir un
          // nuevo campo SAC basta con añadir una entrada a CFG_FIELDS — no hay
          // que tocar este bloque ni _populateToolChange.
          // (Bloque 6 jul-2026: la rama `spindle` ya no guarda SAC. Se ha movido
          // a la pestaña SONDA Z; ver rama `probe` más abajo.)
          // 15-sep: sin M7/M8/M9 en caliente: guardar no enciende ni apaga nada.
          // 27-sep (M1): sin interruptores de refrigeración. Se borran los comentarios que dejaron
          // (`; rotech-mist=` / `; rotech-cool=`) y, como antes (A§12, 15-sep), los `M42 P0/P1` de
          // guardados viejos: no hay ningún `M950 P0/P1` que los declare y dan error al arrancar.
          content = content.replace(/^; rotech-(?:mist|cool)=[^\n]*\n?/gm, ``);
          for (const puerto of [`0`, `1`]) {
            if (!new RegExp(`^M950 P${puerto}\\b`, `m`).test(content)) {
              content = content.replace(new RegExp(`^M42 P${puerto}\\b[^\\n]*\\n?`, `gm`), ``);
            }
          }
        } else if (activeTab === `probe`) {
          // Bloque 6 jul-2026: la pestaña SONDA Z toma el relevo del bloque SAC
          // que vivía en SPINDLE. El split de persistencia es el MISMO que tenía
          // la rama spindle (dual-write a config.g + config-machine.g, deliberado
          // y NO se toca — los valores de palpado son calibración per-máquina,
          // las posiciones son preferencia per-máquina, y el global `sac_enabled`
          // va a config-machine.g).
          //
          // t_9b49c0a4 (sep-2026): la DECLARACIÓN de la sonda (M558) y su OFFSET
          // (G31) también viven en esta pestaña. Mismo split: config.g lleva los
          // fallbacks de fábrica (M558 P5 C"^!E.7" H5 F120 T6000), config-machine.g
          // lleva la calibración real del cliente. La OTA puede reescribir config.g
          // sin perder la sonda calibrada.
          //
          // Fail-closed — si config-machine.g NO está cargado no podemos hacer el
          // dual-write; abortamos antes de tocar config.g y dejar la sonda
          // "medio guardada" en un solo fichero (riesgo: al rearrancar el firmware
          // carga la sonda desde config-machine.g vacío, que cae al fallback
          // de config.g — pero entonces el operario cree haber guardado y no lo
          // hizo). _abortConfigMachineNotLoaded() explica esto al operario.
          if (typeof _cfgMachineLoadOk !== 'undefined' && !_cfgMachineLoadOk) {
            _abortConfigMachineNotLoaded();
            return;
          }
          {
            const r = cfgFieldsSaveByPrefix('mcfgSac', content, rtCmds);
            if (!r.ok) throw Error('validation');
            content = r.content;
          }
          {
            // ── t_9b49c0a4: M558 + G31 (declaración y offset de la sonda) ───
            // Persiste en config.g + config-machine.g (dual-write), igual que
            // SAC. Las validaciones (hwCheck + conflicto de pin con CFG_GPIO_MAP)
            // viven dentro de cfgFieldsRunCustom('PROBE', ...) → customSave.
            // Si customSave devuelve ok:false, throw para que la UI no cierre
            // el modal y el operario vea el toast de error.
            const r = await cfgFieldsRunCustom('PROBE', content, rtCmds);
            if (!r.ok) throw Error('validation');
            content = r.content;
          }
          {
            let mRaw = await cfgMachineRead();
            if (mRaw == null) mRaw = ``;
            // Fail-closed — ver cabecera. Mismo patron que en la rama spindle.
            // Aqui es mas grave: con mRaw vacio cfgFieldsSaveByPrefix construye
            // el contenido DESDE CERO con defaults del formulario y borra
            // posiciones SAC reales + safe_clearance + (ahora) M558/G31 calibrados.
            if (typeof _cfgMachineLoadOk !== 'undefined' && !_cfgMachineLoadOk) {
              _abortConfigMachineNotLoaded();
              return;
            }
            const rM = cfgFieldsSaveByPrefix('mcfgSac', mRaw, []);   // sin rtCmds (ya se aplicaron)
            if (rM.ok && rM.content !== mRaw) await cfgMachineWrite(rM.content);
          }
          {
            // ── t_9b49c0a4: persistir M558/G31 en config-machine.g ──────────
            // Mismo patrón que SAC: leemos mRaw fresco (config-machine.g), le
            // aplicamos PROBE customSave sin rtCmds (ya se aplicaron arriba),
            // y escribimos si cambió. M558 en config-machine.g pisa el fallback
            // de config.g — la sonda calibrada del cliente gana.
            let mRaw = await cfgMachineRead();
            if (mRaw == null) mRaw = ``;
            if (typeof _cfgMachineLoadOk !== 'undefined' && !_cfgMachineLoadOk) {
              _abortConfigMachineNotLoaded();
              return;
            }
            const rM = await cfgFieldsRunCustom('PROBE', mRaw, []);
            if (!rM.ok) throw Error('validation');
            if (rM.content !== mRaw) await cfgMachineWrite(rM.content);
          }
        } else if (activeTab === `tools`) {
          // ── SAC en HERRAMIENTAS (t_7c0ad504 movio el bloque aqui) ──────────
          // Mismo dual-write que tenia la rama `probe`, del que se copian los
          // DOS bloques del SAC y NINGUNO de M558/G31: la declaracion y el
          // offset de la sonda siguen viviendo en la pestana SONDA y se guardan
          // desde alli. Aqui solo viajan los campos mcfgSac* (posiciones del
          // sensor, cero Z, velocidades y timeout de palpado, touchplate).
          //
          // Fail-closed identico: sin config-machine.g cargado no se hace el
          // dual-write, porque dejar el SAC a medias en un solo fichero hace
          // creer al operario que guardo cuando no lo hizo.
          if (typeof _cfgMachineLoadOk !== 'undefined' && !_cfgMachineLoadOk) {
            _abortConfigMachineNotLoaded();
            return;
          }
          {
            const r = cfgFieldsSaveByPrefix('mcfgSac', content, rtCmds);
            if (!r.ok) throw Error('validation');
            content = r.content;
          }
          {
            // Espejo del dual-write. OJO al detalle que costo una vuelta: en la
            // rama `probe` el `content` de arriba ERA config.g (probe no esta en
            // MACHINE_TABS) y el bloque explicito escribia config-machine.g.
            // Aqui es al reves: 'tools' SI esta en MACHINE_TABS, asi que el
            // `content` de arriba es config-machine.g y lo escribe la cola. Lo
            // que falta, y es lo que este bloque hace, es el OTRO lado:
            // los `set global.*` del SAC en config.g, que son los fallbacks que
            // usa el firmware si config-machine.g no existe.
            let raw = _cfgRaw;
            if (!raw) raw = await cfgRead();
            if (raw) {
              const rC = cfgFieldsSaveByPrefix('mcfgSac', raw, []);  // sin rtCmds (ya se aplicaron)
              if (!rC.ok) throw Error('validation');
              if (rC.content !== raw) await cfgWrite(rC.content);
            }
          }
          // La TABLA de herramientas (M563) NO entra aqui: se guarda fila a fila
          // con sus propios botones. Que el mensaje de exito lo diga se resuelve
          // abajo, en el toast final: emitirlo aqui no servia de nada porque el
          // generico llega despues y lo tapa.
        } else if (activeTab === `motors`) {
          // DUAL-WRITE (CLAUDE.md §2 + Bloque 1 ronda jul-2026):
          //   - M92 (pasos/mm) + M906 (corrientes) son CALIBRACIÓN per-máquina →
          //     config-machine.g. La OTA NUNCA los pisa.
          //   - M569 (dirección) + M584 (mapeo eje→driver) son HARDWARE → config.g.
          //     M569 re-ejecutado en caliente RESETEA el TMC2160 (§2 CLAUDE.md) y
          //     los handlers de CFG_FIELDS ya no meten rtCmds para M569/M584 — el
          //     cambio se aplica con el reboot guiado (_motorsNeedReboot +
          //     confirmDialog de más abajo).
          const aMode =
              $q(`input[name="axisAMode"]:checked`)
                ?.value || `off`,
            aActive = aMode !== `off`;
          // ── Rama 1: calibración → config-machine.g (`content`) ──
          // M350 (Microstepping) — se escribe ANTES que M92 porque la lógica
          // de recálculo de M92 necesita los valores viejos de M350 para detectar
          // qué ejes cambiaron y aplicar el factor newMicro/oldMicro a sus pasos/mm.
          // M350 NO se manda en caliente (cambia la resolución del driver TMC2160),
          // así que `needsReboot: true` ya marca el flag y NO se emite rtCmd.
          // El handler centralizado cfgAxisGroupSave NO empuja rtCmd para groups
          // con needsReboot:true — ver cfgAxisGroupSave líneas 1859-1880.
          {
            const r = cfgAxisGroupSave('M350', content, rtCmds, aActive);
            if (!r.ok) throw Error('validation');
            content = r.content;
            if (r.needsReboot) _motorsNeedReboot = !0;
          }
          // M350_I (Interpolación) — flag global compartido por todos los drivers
          // de la placa. Va DESPUÉS de M350 porque su formatter lee la línea M350
          // recién escrita (X/Y/Z) para añadirle la I sin perder los ejes.
          {
            const r = cfgAxisGroupSave('M350_I', content, rtCmds, aActive);
            if (!r.ok) throw Error('validation');
            content = r.content;
            if (r.needsReboot) _motorsNeedReboot = !0;
          }
          // ── Recálculo M92 ↔ M350 (t_d612ed30, briefing) ──
          // El corazón de esta tarjeta: si el operario cambia microstepping sin
          // reescalar M92, la pieza sale de tamaño incorrecto. Aquí detectamos
          // qué ejes cambiaron y, si hay alguno, mostramos el antes/después y
          // pedimos confirmación EXPLÍCITA antes de seguir.
          //
          // La fuente del "antes" es el contenido ORIGINAL de config-machine.g
          // en RAM (_cfgMachineRaw), NO `content` ya mutado por el cfgAxisGroupSave
          // de M350 — si leyéramos `content`, compararíamos el nuevo contra el
          // nuevo y el recálculo nunca dispararía.
          const _oldM350Line = (_cfgMachineRaw || ``)
            .split(`\n`).find((l) => /^M350\b/.test(l)) || ``;
          const _newM350Line = content
            .split(`\n`).find((l) => /^M350\b/.test(l)) || ``;
          const _m350Delta = [];   // [{ax, oldMicro, newMicro, oldSteps, newSteps}]
          if (_oldM350Line && _newM350Line) {
            for (const ax of [`X`, `Y`, `Z`, `A`]) {
              if (ax === `A` && !aActive) continue;
              const oldMicro = Number(cfgGet(_oldM350Line, ax));
              const newMicro = Number(cfgGet(_newM350Line, ax));
              if (!Number.isFinite(oldMicro) || oldMicro <= 0) continue;
              if (!Number.isFinite(newMicro) || newMicro <= 0) continue;
              if (oldMicro === newMicro) continue;
              const oldSteps = Number($(`mcfgM92${ax}`)?.value || 0);
              const newSteps = recalcM92ByMicro(oldSteps, oldMicro, newMicro);
              if (newSteps == null) continue;
              _m350Delta.push({
                ax, oldMicro, newMicro,
                oldSteps, newSteps,
              });
            }
          }
          if (_m350Delta.length > 0) {
            // Hay recálculo que aplicar. Construimos el mensaje antes/después y
            // pedimos confirmación EXPLÍCITA. Es la única barrera entre "cambiar
            // microstepping" y "los pasos/mm quedan en el sitio equivocado" — el
            // bloque guard del soft limits (línea 2172+) marca precedente.
            const lines = _m350Delta.map((d) => {
              const ratio = (d.newMicro / d.oldMicro).toFixed(3);
              return `<strong>${d.ax}</strong>: ${d.oldSteps.toFixed(2)} pasos/mm → ` +
                `<strong>${d.newSteps.toFixed(2)}</strong> ` +
                `(×${ratio} · micro ${d.oldMicro}→${d.newMicro})`;
            });
            // Construir el ejemplo "100 mm sale de 50 o de 200" según la dirección
            // del cambio: si SUBE el microstepping, M92 crece, la máquina se mueve
            // MENOS por comando (pieza sale más pequeña). Si BAJA, al revés.
            // Coherente con la cabecera del briefing.
            const sube = _m350Delta[0].newMicro > _m350Delta[0].oldMicro;
            const ejemploMm = sube ? `50` : `200`;
            const msg = t(
              `msg.microstepRecalcBody`,
              `Cambiar el microstepping <strong>reescala los pasos/mm</strong> para que ` +
              `la máquina siga moviéndose lo mismo. Si no se reescalan, una pieza ` +
              `de 100 mm sale de ${ejemploMm} mm.<br><br>` +
              `<strong>Cambios previstos:</strong><br>${lines.join('<br>')}<br><br>` +
              `¿Aplicar el recálculo y guardar?`,
              { lines: lines.join('<br>') },
            );
            const ok = await confirmDialog(
              t(`msg.microstepRecalcTitle`, `Recalcular pasos/mm`),
              msg,
            );
            if (!ok) {
              toast(t(`msg.microstepRecalcCancel`, `Recálculo cancelado — no se ha guardado NADA`), `warn`);
              log(`Motores → recálculo M92 rechazado por el operario (M350 no aplicado)`, `sys`);
              return;
            }
            // Sobreescribir los inputs M92 con los valores recalculados ANTES del
            // cfgAxisGroupSave('M92') de más abajo — así el save usa los nuevos.
            // Se hace SOLO sobre los ejes que cambian, para no pisar lo que el
            // operario haya tecleado a mano en ejes no afectados.
            _m350Delta.forEach((d) => {
              const el = $(`mcfgM92${d.ax}`);
              if (el) el.value = d.newSteps.toFixed(2);
            });
            log(
              `Motores → M350→M92 recálculo aplicado: ${_m350Delta.map((d) => `${d.ax} ${d.oldSteps.toFixed(2)}→${d.newSteps.toFixed(2)}`).join(', ')}`,
              `sys`,
            );
          }
          // M92 (Pasos/mm) — su valor en pantalla puede haber sido reescrito por
          // el recálculo de arriba. cfgAxisGroupSave lo lee fresco del DOM.
          {
            const r = cfgAxisGroupSave('M92', content, rtCmds, aActive);
            if (!r.ok) throw Error('validation');
            content = r.content;
            if (r.needsReboot) _motorsNeedReboot = !0;
          }
          // M906 (corrientes) — dos grupos: X/Y/A y Z (línea separada con I100 fijo)
          {
            const rXY = cfgAxisGroupSave('M906_XYA', content, rtCmds, aActive);
            if (!rXY.ok) throw Error('validation');
            content = rXY.content;
            if (rXY.needsReboot) _motorsNeedReboot = !0;
          }
          {
            const rZ = cfgAxisGroupSave('M906_Z', content, rtCmds, aActive);
            if (!rZ.ok) throw Error('validation');
            content = rZ.content;
            if (rZ.needsReboot) _motorsNeedReboot = !0;
          }
          // ── Rama 2: hardware → config.g (`configContent`) ──
          // Trabajamos sobre una copia local de _cfgRaw — los handlers M569/M584
          // hacen cfgReplaceLine buscando líneas M569/M584 que config-machine.g NO
          // tiene (las líneas 12-13 de config-machine.g prohíben expresamente M569
          // ahí) y de lo contrario APPENDEARÍA al final del archivo equivocado.
          let configContent = _cfgRaw || (await cfgRead()) || '';
          // 15-sep: sin config.g leído no se genera uno de cinco líneas encima del real.
          if (!configContent) {
            toast(t(`msg.configgNoCargado`, `config.g no cargado`), `err`);
            throw Error(`validation`);
          }
          {
            const r = await cfgFieldsRunCustom('M569', configContent, rtCmds);
            if (!r.ok) throw Error('validation');
            configContent = r.content;
            if (r.needsReboot) _motorsNeedReboot = !0;
          }
          {
            const r = await cfgFieldsRunCustom('M584', configContent, rtCmds);
            if (!r.ok) throw Error('validation');
            configContent = r.content;
            if (r.needsReboot) _motorsNeedReboot = !0;
          }
          // ── Persistencia: dos writes, dos logs honestos ──
          // 1) Calibración → config-machine.g (content ya contiene M92+M906)
          if (!(await cfgMachineWrite(content))) return;
          _cfgMachineRaw = content;
          log(`Motores → M92/M906 guardados en config-machine.g`, `sys`);
          // 2) Hardware → config.g (configContent contiene M569+M584)
          if (configContent && configContent !== _cfgRaw) {
            if (!(await cfgWrite(configContent))) return;
            log(`Motores → M569/M584 guardados en config.g (requieren reboot)`, `sys`);
          } else if (!configContent) {
            log(`Motores → config.g no cargado, M569/M584 no se persistieron`, `warn`);
          }
          // Marca para que la cola final NO reescriba el contenido ya guardado.
          // (La cola al final del handler hace cfgMachineWrite(content) si motors
          // está en MACHINE_TABS — sería un segundo write idéntico, inocuo pero
          // ruidoso y propagaría cualquier mutación de _motorsNeedReboot.)
          _motorsDidDualWrite = !0;
          _motorsNeedReboot = !0;
        } else if (activeTab === `macros`) {
          (toast(t(`msg.macrosActualizadas`, `Macros actualizadas`), `ok`), log(`Macros guardadas`, `sys`));
        } else if (activeTab === `backlash`) {
          // M425 (Backlash) — MIGRADO a CFG_AXIS_GROUPS
          // Validación, formato y rtCmd están centralizados en CFG_AXIS_GROUPS.M425
          const aMode = $q(`input[name="axisAMode"]:checked`)?.value || `off`;
          const aActive = aMode !== `off`;
          const r = cfgAxisGroupSave('M425', content, rtCmds, aActive);
          if (!r.ok) throw Error('validation');
          content = r.content;
          log(`Backlash → ${rtCmds[rtCmds.length - 1]}`, `sys`);
        } else if (activeTab === `speeds`) {
          const g = (id) => $(id).value,
            aMode =
              $q(`input[name="axisAMode"]:checked`)
                ?.value || `off`,
            aActive = aMode !== `off`;
          // M203/M201/M566 — MIGRADOS a CFG_AXIS_GROUPS. La validación de negativos
          // se hace dentro de cada grupo (en CFG_AXIS_GROUPS.{M203,M201,M566}.validate).
          // Tras guardar, refrescamos los caches locales _m203Limits/_m201Accel que usa
          // otra parte del JS para enforcement en jog.
          for (const [grp, cache] of [['M203', _m203Limits], ['M201', _m201Accel]]) {
            const r = cfgAxisGroupSave(grp, content, rtCmds, aActive);
            if (!r.ok) throw Error('validation');
            content = r.content;
            const vx = parseFloat(g(`mcfg${grp}X`)) || cache.X;
            const vy = parseFloat(g(`mcfg${grp}Y`)) || cache.Y;
            const vz = parseFloat(g(`mcfg${grp}Z`)) || cache.Z;
            const va = parseFloat(g(`mcfg${grp}A`));
            cache.X = vx; cache.Y = vy; cache.Z = vz;
            if (aActive && !isNaN(va)) cache.A = va;
            // M201 (acel SEDA) → también actualizar globals silk_accel_* para que
            // set_silk.g use los valores del user en vez de hardcoded (Conflicto 1).
            if (grp === 'M201') {
              const axes = aActive ? ['X','Y','Z','A'] : ['X','Y','Z'];
              for (const ax of axes) {
                const v = parseFloat(g(`mcfgM201${ax}`));
                if (!isNaN(v)) {
                  const gName = `silk_accel_${ax.toLowerCase()}`;
                  content = cfgSetGlobal(content, gName, v);
                  rtCmds.push(`set global.${gName} = ${v}`);
                }
              }
            }
          }
          {
            const r = cfgAxisGroupSave('M566', content, rtCmds, aActive);
            if (!r.ok) throw Error('validation');
            content = r.content;
            // M566 (jerk SEDA) → actualizar globals silk_jerk_* (Conflicto 2).
            const axes = aActive ? ['X','Y','Z','A'] : ['X','Y','Z'];
            for (const ax of axes) {
              const v = parseFloat(g(`mcfgM566${ax}`));
              if (!isNaN(v)) {
                const gName = `silk_jerk_${ax.toLowerCase()}`;
                content = cfgSetGlobal(content, gName, v);
                rtCmds.push(`set global.${gName} = ${v}`);
              }
            }
          }
          // FIX H-4-05 (carril 4): los 12 inputs mcfgJF{…}{xy,z} aceptaban
          // negativo, 0, texto y 999999 sin rechazo (Number(...) || default
          // silenciaba cualquier basura). Validar y clampear ANTES de componer
          // ; rotech-jog-speeds=. Rango seguro 1-20000 mm/min — por encima de
          // eso la mecánica no puede seguir y por debajo de 1 no se mueve.
          const _clampJF = (rawId, def, allowZero = false) => {
            const el = $(rawId);
            if (!el) return def;
            const raw = el.value;
            let v = parseFloat(raw);
            if (raw === '' || !isFinite(v)) { v = def; el.value = def; return v; }
            if (!allowZero && v <= 0) {
              toast(t(`msg.jogFeedInvalido`, `Jog feed ${rawId} debe ser > 0 (recibo: ${raw}); restaurado a ${def}`, { id: rawId, raw, def }), `warn`);
              v = def; el.value = def; return v;
            }
            if (v > 20000) {
              toast(t(`msg.jogFeedClampeadoA`, `Jog feed ${rawId} demasiado alto (${v}); ajustado a 20000 mm/min`, { id: rawId, v }), `warn`);
              v = 20000; el.value = 20000; return v;
            }
            return v;
          };
          JOG_FEED[0.1] = {
            xy: _clampJF('mcfgJF01xy', 60),
            z: _clampJF('mcfgJF01z', 30),
          };
          JOG_FEED[1] = {
            xy: _clampJF('mcfgJF1xy', 300),
            z: _clampJF('mcfgJF1z', 150),
          };
          JOG_FEED[5] = {
            xy: _clampJF('mcfgJF5xy', 800),
            z: _clampJF('mcfgJF5z', 400),
          };
          JOG_FEED[10] = {
            xy: _clampJF('mcfgJF10xy', 1500),
            z: _clampJF('mcfgJF10z', 800),
          };
          JOG_FEED[50] = {
            xy: _clampJF('mcfgJF50xy', 3000),
            z: JOG_FEED[50]?.z || 1500,
          };
          JOG_FEED[100] = {
            xy: _clampJF('mcfgJF100xy', 5000),
            z: JOG_FEED[100]?.z || 2000,
          };
          JOG_FEED[200] = {
            xy: _clampJF('mcfgJF200xy', 7000),
            z: JOG_FEED[200]?.z || 2500,
          };
          JOG_FEED[500] = {
            xy: _clampJF('mcfgJF500xy', 10000),
            z: JOG_FEED[500]?.z || 3000,
          };
          const jfParts = Object.entries(JOG_FEED)
            .map(([s, v]) => `${s}:${v.xy}:${v.z}`)
            .join(`,`);
          const jfLine = `; rotech-jog-speeds=${jfParts}`;
          content = cfgReplaceLine(content, `; rotech-jog-speeds=`, jfLine);
          // RAYO (PRO mode) — lógica de clamp jerk≤accel×60 preservada, escritura
          // a config.g delegada a CFG_FIELDS (mcfgRayo*).
          {
            const defaults = { X: { ac: 1500, jk: 1200 }, Y: { ac: 1500, jk: 1200 },
                               Z: { ac: 200, jk: 120 }, A: { ac: 500, jk: 600 } };
            const _warn = [];
            ['X', 'Y', 'Z', 'A'].forEach((ax) => {
              let ac = Number(g(`mcfgRayoAcc${ax}`)) || defaults[ax].ac;
              let jk = Number(g(`mcfgRayoJerk${ax}`)) || defaults[ax].jk;
              if (ac <= 0) { _warn.push(`Aceleración ${ax} debe ser > 0`); ac = 1; }
              if (jk <= 0) { _warn.push(`Jerk ${ax} debe ser > 0`); jk = 1; }
              if (jk > ac * 60) {
                _warn.push(`Jerk RAYO ${ax}: ${jk} clamped a ${ac * 60}`);
                jk = ac * 60;
              }
              // Sobrescribir el input con el valor clampeado para que CFG_FIELDS lo escriba
              if ($(`mcfgRayoAcc${ax}`)) $(`mcfgRayoAcc${ax}`).value = ac;
              if ($(`mcfgRayoJerk${ax}`)) $(`mcfgRayoJerk${ax}`).value = jk;
            });
            if (_warn.length) toast(_warn[0], `warn`);
          }
          // Persistir a config.g + rtCmds (escritura centralizada en CFG_FIELDS.mcfgRayo*)
          {
            const r = cfgFieldsSaveByPrefix('mcfgRayo', content, rtCmds);
            if (!r.ok) throw Error('validation');
            content = r.content;
          }
          // Construir pro_params_saved.g con los valores actuales (post-clamp)
          let proContent = `; pro_params_saved.g -- PARÁMETROS RAYO GUARDADOS\n`;
          ['X', 'Y', 'Z', 'A'].forEach((ax) => {
            const ac = $(`mcfgRayoAcc${ax}`)?.value;
            const jk = $(`mcfgRayoJerk${ax}`)?.value;
            if (ac) proContent += `set global.pro_accel_${ax.toLowerCase()} = ${ac}\n`;
            if (jk) proContent += `set global.pro_jerk_${ax.toLowerCase()} = ${jk}\n`;
          });
          const sz = $(`mcfgSacSensorZ`)?.value;
          if (sz) proContent += `set global.z_sensor_to_table = ${sz}\n`;
          const proFile = new File(
            [new Blob([proContent], { type: `text/plain` })],
            `pro_params_saved.g`,
          );
          await FM.upload(proFile, () => {}, `pro_params_saved.g`);
          log(`Velocidades y persistencia guardadas`, `sys`);
        } else if (activeTab === `ledrgb`) {
          LED.readFromUI();
          // FIX H-4-06 (carril 4): atributo HTML min=1 max=255 no se aplica al
          // save si devtools cambia el valor. Clamp defensivo al rango del
          // hardware (NeoPixel WS2812B: 1-255 niveles por canal).
          let bright = LED.cfg.brightness;
          if (!isFinite(bright) || bright < 1) {
            bright = 128;
            const _el = $('ledRgbBrightness');
            if (_el) _el.value = 128;
            toast(t(`msg.ledBrilloInvalido`, `Brillo LED inválido, restaurado a 128`), `warn`);
          } else if (bright > 255) {
            toast(t(`msg.ledBrilloClampeadoA`, `Brillo LED ${bright} fuera de rango (1-255), ajustado a 255`, { "bright": bright }), `warn`);
            bright = 255;
            const _el = $('ledRgbBrightness');
            if (_el) _el.value = 255;
          }
          const on = LED.cfg.on;
          const p = LED._profiles.IDLE;
          let lr = 0,
            lg = 0,
            lb = 0;
          if (on) {
            const s = (bright / 255) * p.pct;
            lr = Math.round(p.r * s);
            lg = Math.round(p.g * s);
            lb = Math.round(p.b * s);
          }
          const cmd = `M150 E0 R${lr} U${lg} B${lb} S25 F0`;
          // Reemplazar SOLO la primera línea M150 (no todas: config.g podría tener
          // varias de inicialización; el replace global las colapsaría).
          if (/^M150\b/m.test(content))
            content = content.replace(/^M150\b[^\n]*/m, cmd + `  ; LED NeoPixel`);
          else
            content += `\n` + cmd + `  ; LED NeoPixel`;
          // Persistir el brillo en el MISMO `content` → escritura atómica con el
          // cfgWrite final. Antes LED.save() escribía config.g por separado y ese
          // cfgWrite revertía la línea ; rotech-led= (regresión crítica).
          content = cfgReplaceLine(content, '; rotech-led=', `; rotech-led=${bright}`);
          rtCmds.push(cmd);
          LED.onStateChange(SM.current);
          log(`LED RGB → brillo:${bright} ${on ? `ON` : `OFF`}`, `sys`);
        } else if (activeTab === `motortimeout`) {
          // M84 — timeout motores. Defecto 86400 s (1 día, Z siempre energizado).
          // Bajada de 1 min con Z no-autoblocante puede tirar la fresa a la mesa:
          // toast warn (no bloquea: mantenimiento sin husillo es legítimo).
          const secs = parseInt($(`mcfgMotorTimeoutS`)?.value, 10);
          if (!isFinite(secs) || secs < 0) {
            toast(t(`msg.motortimeoutInvalido`, `Timeout inválido — debe ser un entero ≥ 0 segundos`), `err`);
            return;
          }
          if (m84NeedsZDropWarn(secs))
            toast(t(`msg.motortimeoutCorto`, `Timeout muy corto (${secs} s): si la fresa está cerca, Z puede caer.`), `warn`);
          content = cfgReplaceMcode(content, `M84`, `M84 S${secs}  ; Desactivar timeout (${secs} s) — Z siempre energizado`);
          rtCmds.push(`M84 S${secs}`);
          log(`M84 S${secs} (timeout motores)`, `sys`);
        } else if (activeTab === `fans`) {
          // M106 P1 T: umbral de los ventiladores de AUX1 (config.g). La alerta del MCU salta a 55 °C.
          const tc = parseInt($(`mcfgFanTemp`)?.value, 10);
          if (!(tc >= 30 && tc <= 50)) {
            toast(t(`msg.fansTempInvalida`, `Temperatura inválida — entre 30 y 50 °C`), `err`);
            return;
          }
          content = cfgReplaceMcode(content, `M106 P1`, `M106 P1 T${tc}  ; Ventiladores AUX1: se encienden a ${tc} °C`);
          rtCmds.push(`M106 P1 T${tc}`);
        } else if (activeTab === `network`) {
          // M586 — solo FTP (P1) y Telnet (P2); HTTP (P0) NO se expone (rompe la sesión).
          const ftpOn = !!$(`mcfgNetworkFtp`)?.checked;
          const telOn = !!$(`mcfgNetworkTelnet`)?.checked;
          if (networkOpensAccess(ftpOn, telOn))
            toast(t(`msg.networkAbierto`, `FTP/Telnet sin autenticación — solo con red segmentada`), `warn`);
          content = cfgReplaceMcode(content, `M586 P1`, `M586 P1 S${ftpOn ? 1 : 0}  ; FTP (${ftpOn ? `activado` : `desactivado`})`);
          content = cfgReplaceMcode(content, `M586 P2`, `M586 P2 S${telOn ? 1 : 0}  ; Telnet (${telOn ? `activado` : `desactivado`})`);
          rtCmds.push(`M586 P1 S${ftpOn ? 1 : 0}`);
          rtCmds.push(`M586 P2 S${telOn ? 1 : 0}`);
          log(`M586 P1=${ftpOn ? 1 : 0} P2=${telOn ? 1 : 0}`, `sys`);
        } else if (activeTab === `inputshaping`) {
          // M593 — input shaping. Defecto zvd F40 (PUNTO DE PARTIDA).
          const type = ($(`mcfgInputShapingType`)?.value || `zvd`).trim();
          const freq = parseFloat($(`mcfgInputShapingFreq`)?.value);
          const validTypes = [`zvd`,`zvdd`,`zv`,`zild`,`2hei`,`3hei`,`ei`,`none`];
          if (!validTypes.includes(type)) {
            toast(t(`msg.inputshapingTypeInvalido`, `Tipo de shaper inválido: ${type}`), `err`);
            return;
          }
          if (!isFinite(freq) || freq < 5 || freq > 200) {
            toast(t(`msg.inputshapingFreqInvalida`, `Frecuencia inválida — debe estar entre 5 y 200 Hz`), `err`);
            return;
          }
          content = cfgReplaceMcode(content, `M593`, `M593 P"${type}" F${freq}  ; shaper ${type} a ${freq} Hz (PUNTO DE PARTIDA — afinar con prueba)`);
          rtCmds.push(`M593 P"${type}" F${freq}`);
          log(`M593 P"${type}" F${freq}`, `sys`);
        }
        // Si la rama `motors` ya hizo su dual-write, NO reescribir `content`
        // por la cola final (sería un segundo cfgMachineWrite idéntico e inocuo
        // pero ruidoso — mejor saltarlo). El _motorsNeedReboot ya está armado
        // y se gestiona más abajo como en cualquier otra pestaña.
        if (_motorsDidDualWrite) {
          _motorsDidDualWrite = false;
        } else if (isMachineTab) {
          if (!(await cfgMachineWrite(content))) return;
          _cfgMachineRaw = content;
          log(`Configuración [${activeTab}] guardada en config-machine.g`, `sys`);
        } else {
          if (!(await cfgWrite(content))) return;
          log(`Configuración [${activeTab}] guardada en config.g`, `sys`);
        }
        const _rtFailed = [];
        for (const cmd of rtCmds) {
          const _ok = await RRF.gcode(cmd);
          log(cmd, `cmd`);
          if (!_ok) _rtFailed.push(cmd.split(`\n`)[0]);
        }
        if (_rtFailed.length)
          toast(
            `${t(`msg.savedToSD`, `Guardado en la SD, pero`)} ${_rtFailed.length} ${t(`msg.commandsNotHotApplied`, `comando(s) NO se aplicaron en caliente — el firmware no acepta ese cambio sin reiniciar (típicamente M584 o M569). Reinicia la máquina AHORA desde la barra superior (botón REINICIAR) o desde el piloto REBOOT de CONFIGURACIÓN → General. Si sigues trabajando sin reiniciar, ese cambio NO estará activo.`)}`,
            `warn`,
          );
        if (activeTab === `endstops`) {
          _cachedEndstops = null;
          [`X`, `Y`, `Z`].forEach((ax) => {
            updateEndstopRowState(ax); // sincroniza _endstopCfg[ax].minOn/maxOn/off
            const type = ($(`mcfgEndType${ax}Max`)?.value || `NC`);
            _endstopCfg[ax].trigLevel = type === `NO` ? 0 : 1;
          });
        }
        typeof AppState.ui.mcfgDirtyClearTab === `function` && AppState.ui.mcfgDirtyClearTab(activeTab);
        // Animación del botón: flash verde + checkmark durante 2s
        btn.disabled = true;
        btn.innerHTML = `<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg> ${t(`msg.savedSfx`, `Guardado`)} ✓`;
        btn.style.background = `var(--green)`;
        btn.style.borderColor = `var(--green)`;
        btn.style.color = `#fff`;
        // En HERRAMIENTAS el Guardar generico persiste el bloque SAC pero NO la
        // tabla M563 (esa va fila a fila). Un "Configuracion guardada" a secas
        // haria creer al operario que tambien guardo la tabla: el mismo falso
        // positivo que motivo el guardia _SAVE_TABS (FIX H-4-01).
        toast(
          activeTab === `tools`
            ? t(`msg.toolsSacGuardado`, `Cambio de herramienta guardado ✓ — la TABLA se guarda con los botones de cada fila`)
            : t(`msg.configuraciónGuardada`, `Configuración guardada ✓`),
          `ok`);
        log(`Configuración [${activeTab}] guardada en config.g`, `sys`);
        await new Promise(r => setTimeout(r, 2000));
        btn.style.background = ``;
        btn.style.borderColor = ``;
        btn.style.color = ``;
        if (_motorsNeedReboot) {
          _motorsNeedReboot = false;
          // Fase 3.3 §10 (t_1b74ed31): si el operario acaba de ACTIVAR un
          // driver externo (mcfgExtX/Y/Z/A), el reboot genérico debe añadir
          // un aviso naranja explicando que ese eje se omite de M906 y la
          // corriente pasa al dial hardware del driver externo (riesgo de
          // motor quemado si el dial queda mal). La marca `wasUnchecked` la
          // pone el handler del toggle cuando checked=true.
          const _extChanged = [`X`, `Y`, `Z`, `A`].some(
            (ax) => $(`mcfgExt${ax}`)?.dataset.wasUnchecked === `1`,
          );
          const _baseMsg = t(`dlg.motorsReboot.msg`,
            `<p style="margin-bottom:10px">Los cambios en <strong>pasos/mm</strong> y <strong>corriente</strong> requieren un reinicio completo de la placa para aplicarse correctamente.</p>` +
            `<p style="color:var(--yellow);font-size:11px">La máquina se detendrá y perderá la posición de homing.</p>`,
          );
          const _msg = _extChanged
            ? _baseMsg +
              `<p style="color:var(--warn-strong);font-size:11px;margin-top:8px"><strong>${t(`msg.extdrvRestartWarn`, `Has activado un driver externo: el firmware omitirá M906 para ese eje y la corriente la gestionará el dial hardware del driver. Si ese dial queda mal configurado, el motor puede quemarse.`)}</strong></p>`
            : _baseMsg;
          const _confirmed = await confirmDialog(
            t(`dlg.motorsReboot.title`, `Reinicio obligatorio`),
            _msg,
          );
          if (_confirmed) {
            // Cerrar modal y mostrar overlay de reboot inmediatamente
            $(`machineConfigModal`)?.classList.remove("show");
            const _ov = $(`rebootOverlay`);
            if (_ov) {
              _ov.classList.add("show");
              // Cabeza (.reboot-util-2) y subtítulo (.mcfg-lbl). Selector viejo
              // `[style*="font-size:..."]` no matcheaba el HTML estático
              // (font-size viene de clase CSS, no inline) — HALLAZGO-13b.
              const _el = _ov.querySelector(`.reboot-util-2`);
              if (_el) _el.textContent = t(`msg.rebootRestarting`, `REINICIANDO`);
              const _sub = _ov.querySelector(`.mcfg-lbl`);
              if (_sub) _sub.innerHTML = t(`msg.rebootApplyingMotors`, `Aplicando configuración de motores…`);
              // Cuenta atrás en el timer antes de M999
              let _cd = 3;
              const _timerEl = $(`rebootTimer`);
              if (_timerEl) _timerEl.textContent = `${_cd}s`;
              const _cdInterval = setInterval(() => {
                _cd--;
                if (_timerEl) _timerEl.textContent = _cd > 0 ? `${_cd}s` : `0s`;
                if (_cd <= 0) clearInterval(_cdInterval);
              }, 1000);
              await new Promise(r => setTimeout(r, 3000));
              clearInterval(_cdInterval);
            }
            await RRF.gcode(`M999`);
          }
        }
      } catch (err) {
        // Mostrar el error de validación al usuario en lugar de fallar silenciosamente
        const msg = err?.message || `Error al guardar configuración`;
        // Ignorar el mensaje genérico "validation" (los toasts específicos ya se mostraron antes)
        if (msg !== `validation`) toast(msg, `err`);
        log(`Guardado abortado: ${msg}`, `err`);
        btn.style.background = `var(--red)`;
        btn.style.borderColor = `var(--red)`;
        btn.style.color = `#fff`;
        btn.innerHTML = `<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg> Error`;
        saveErrorTimer = setTimeout(() => {
          btn.style.background = ``;
          btn.style.borderColor = ``;
          btn.style.color = ``;
          btn.innerHTML = `<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg> Guardar`;
          saveErrorTimer = null;
        }, 2500);
      } finally {
        btn.disabled = !1;
        // RED DE SEGURIDAD (22-sep). De este `try` se sale tambien por los
        // cuatro `if (!(await cfgMachineWrite/cfgWrite(...))) return;` de
        // arriba, que disparan cuando la guarda de concurrencia aborta. Por
        // ahi no se pasa ni por el exito ni por el `catch`, y el boton se
        // quedaba en «Guardando…» PARA SIEMPRE, habilitado pero mintiendo:
        // el operario no sabe si su calibracion entro. Medido: un guardado
        // bueno tarda ~200 ms; con la guarda saltada no cambiaba ni en 20 s.
        // Sin toast: `cfgMachineWrite` ya emitio el suyo.
        if (/Guardando/.test(btn.textContent || ``)) {
          btn.innerHTML = `<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg> <span data-i18n="cfg.btn.apply">${t(`cfg.btn.apply`, `Aplicar`)}</span>`;
        }
      }
    });
  })());

// ---
// ACCEL_CURVE — Curva de aceleración/deceleración (pestaña VELOCIDADES)
// (jul-2026). Simula el perfil de velocidad trapezoidal de RRF para un
// movimiento de 100 mm con los valores ACTUALES de los inputs de la
// pestaña: arranque al jerk (M566 = cambio instantáneo permitido), rampa
// a aceleración constante (M201 / RayoAcc) hasta la velocidad máxima
// (M203), crucero y frenada simétrica. Es una VISUALIZACIÓN: no envía
// nada a la máquina ni persiste nada.
// ---
// >>> ACCEL_CURVE_PROFILE_BEGIN (extraído por tests/unit/accel-curve.test.js)
// Funcion pura consumida por global desde rotechos-config-accel-curve.js:47-48
// (window.accelCurveProfile).
// eslint-disable-next-line no-unused-vars
function accelCurveProfile(v0mmMin, vmaxMmMin, accelMmS2, distMm) {
  // Unidades internas: mm/s y s. v0 = jerk (arranque instantáneo de RRF).
  // NaN-guard: Math.max(0, NaN) devuelve NaN — sanear antes de acotar.
  const fin = (x, d) => (Number.isFinite(x) ? x : d);
  const v0 = Math.max(0, fin(v0mmMin, 0) / 60);
  const vmax = Math.max(v0 + 0.001, fin(vmaxMmMin, 0) / 60);
  const a = Math.max(0.001, fin(accelMmS2, 0));
  const D = Math.max(1, fin(distMm, 0));
  // Distancia que consumen la rampa de subida y la de bajada (simétricas).
  const dRamp = (vmax * vmax - v0 * v0) / (2 * a);
  if (2 * dRamp <= D) {
    // Perfil trapezoidal: sube, cruza, baja.
    const t1 = (vmax - v0) / a;
    const t2 = (D - 2 * dRamp) / vmax;
    return { vpeak: vmax, t1, t2, t3: t1, total: t1 + t2 + t1, triangular: false };
  }
  // Perfil triangular: no llega a vmax en 100 mm — pico real alcanzable.
  const vpeak = Math.sqrt(v0 * v0 + a * D);
  const t1 = (vpeak - v0) / a;
  return { vpeak, t1, t2: 0, t3: t1, total: t1 * 2, triangular: true };
}
// <<< ACCEL_CURVE_PROFILE_END
// Canvas y listeners viven en rotechos-config-accel-curve.js (carga perezosa
// al primer click en la pestaña VELOCIDADES o input del panel). Aquí solo
// dejamos el stub que dispara la inyección del script.
// Helper unico de carga perezosa (t_ec990fc0, 2026-09-05): antes cada
// modulo perezoso repetia ~12 lineas de cache-de-promesa + createElement +
// handlers. Centralizado aqui, cada call-site pasa de 12 lineas a 1.
//   src        ruta al .js a inyectar
//   globalName nombre del simbolo que el modulo expone en window
//   label      texto legible para el mensaje de error
const __lazyCache = new Map();
// RENOMBRADO 2026-09-06. Se llamaba __lazyLoad, IGUAL que el de rotechos.js:858.
// Los dos son `function` de nivel superior en scripts clasicos, o sea globales:
// el que carga DESPUES pisa al anterior. Y no son compatibles — el de aqui
// recibe (src, globalName) y el de alli solo (src), con caches distintas.
//
// Mientras el modal fue EAGER no se noto. Al hacerlo perezoso salta:
// __loadConfigModal() llama a `__lazyLoad('/js/rotechos-config-modal.js')`
// creyendo que invoca el de rotechos.js, pero ya es ESTE; su cache no tiene esa
// ruta y `window[undefined]` es undefined, asi que INYECTA EL MODAL OTRA VEZ.
// Resultado: SyntaxError "Identifier '_motorsNeedReboot' has already been
// declared" y la CONFIGURACION rota al reabrirla.
//
// Medido con instrumentacion del setter de `script.src`: dos inyecciones, una
// desde rotechos.js:864 y otra desde este fichero.
function __mcfgLazyLoad(src, globalName, label = src) {
  if (window[globalName]) return Promise.resolve(window[globalName]);
  if (__lazyCache.has(src)) return __lazyCache.get(src);
  const p = new Promise((resolve, reject) => {
    const s = document.createElement(`script`);
    s.src = src;
    s.onload = () => resolve(window[globalName]);
    s.onerror = (e) => reject(new Error(`${label}: ` + (e?.message || `load failed`)));
    document.head.appendChild(s);
  });
  __lazyCache.set(src, p);
  return p;
}
const __loadAccelCurve = () => __mcfgLazyLoad(`/js/rotechos-config-accel-curve.js`, `ACCEL_CURVE`);
// Disparo lazy: el primer click en la pestaña speeds carga el script.
document.querySelector(`.mcfg-tab[data-tab=speeds]`)?.addEventListener(`click`, () => { __loadAccelCurve(); }, { once: true });
$(`mcfgTabSpeeds`)?.addEventListener(`focusin`, () => { __loadAccelCurve(); }, { once: true });

// ---
// CONTROLADORA — Pestaña "Pines libres → funciones asignables"
// ---
// Añadido por t_fa32b4d7 (sep-2026). Convierte la pestaña CONTROLADORA de
// documentación en configuración real: el operario elige qué FUNCIÓN
// (aspiración, luz, refrigerante, paro externo…) va en cada pin libre de la
// BTT Scylla V1.0. Persistencia en `; rotech-pins=` dentro de
// config-machine.g (per-máquina), generación de líneas M950 P{n} / J{n}.
//
// IMPLEMENTACIÓN: la lógica de pintado y guardado vive en
// rotechos-config-pins-ui.js (cargado de forma PEREZOSA al abrir la pestaña,
// igual que rotechos-config-accel-curve.js). Este fichero solo:
//   1. carga el módulo bajo demanda;
//   2. monta el listener del botón Guardar;
//   3. dispara el populate al abrir la pestaña.
//
// SEGURIDAD — distinción crítica V-MOS vs lógica:
//   - A.4/A.5/A.6/A.7/C.4 son SALIDAS DE POTENCIA que emiten la tensión de
//     V-MOS directamente (24/36/48 V). NO se ofrecen para entradas ni para
//     PWM en un pin lógico.
//   - B.7 es la única entrada digital segura (IO-IN, 5 V tolerant).
//   - D.5 (relé mecánico) y B.7 son pins lógicos: para cargas que NO
//     conmutan V-MOS.
//
// Toda salida nueva arranca en OFF (M42 P{n} S0) — una salida que arranca
// activa puede energizar un relé o una electroválvula al inicio.
//
// PENDIENTE BANCO: la generación de líneas se valida en simulador (tests
// unitarios) pero la asignación real a un GPIO de la Scylla debe probarse
// con la placa conectada antes de confiar en un cliente.
// ---
const __loadPinesUi = () => __mcfgLazyLoad(`/js/rotechos-config-pins-ui.js`, `ROTECHOS_PINES_UI`);
// CONTROLADORA tiene ademas un boton Guardar propio: re-lee y persiste la
// asignacion de pines. El modulo expone `populate` (no `load`) y `save`.
function _onPinesTabOpen() {
  if (typeof cfgMachineRead !== `function`) return;
  __loadPinesUi().then((ui) => cfgMachineRead().then((raw) => {
    if (raw == null) return;
    if (ui && typeof ui.populate === `function`) ui.populate(raw);
  })).then(() => {
    // t_e234f3be: al abrir CONTROLADORA, refrescar el pin del follow-spindle
    // ahora que parseRotechPins ya esta disponible. Hasta ahora estaba
    // desactivado con motivo "parser-missing" porque el modulo de pines es
    // perezoso. Sin esto, el operario asigna la aspiracion a un pin y el
    // boton sigue muerto.
    if (typeof window.ASPIR_FOLLOW === 'object' && window.ASPIR_FOLLOW &&
        typeof window.ASPIR_FOLLOW.refreshPinFromConfig === 'function') {
      window.ASPIR_FOLLOW.refreshPinFromConfig().catch(() => {});
    }
  }).catch((e) => log && log(`pins UI load failed: ${e?.message}`, `warn`));
}
document.querySelector(`.mcfg-tab[data-tab=pines]`)?.addEventListener(`click`, _onPinesTabOpen, { once: false });
// t_0e8e4716 (2026-09-06): aqui habia un SEGUNDO listener sobre el PANEL
//     $(`mcfgTabPines`)?.addEventListener(`click`, _onPinesTabOpen);
// y era un bug. Abrir una pestana NO es lo mismo que pulsar un boton dentro de
// ella: el click en "Guardar asignacion de pines" —que vive DENTRO del panel—
// burbujeaba hasta aqui y relanzaba _onPinesTabOpen en paralelo con savePines.
// Consecuencia medida: dos cfgMachineRead() concurrentes, y ademas
// ui.populate(raw) reseteaba `_draft` a mitad del guardado, borrando lo que el
// operario acababa de asignar.
// El boton de pestana (listener de arriba) cubre el caso real de apertura,
// incluida la navegacion del buscador, que hace btn.click() sobre ese mismo
// boton. Ver docs/dev/hallazgos/2026-09-05_flake-guardado-pines.md.
$(`btnMcfgPinesFuncionesSave`)?.addEventListener(`click`, () => {
  __loadPinesUi()
    .then((ui) => ui && ui.save && ui.save())
    .then(() => {
      if (typeof window.ASPIR_FOLLOW === 'object' && window.ASPIR_FOLLOW &&
          typeof window.ASPIR_FOLLOW.refreshPinFromConfig === 'function') {
        return window.ASPIR_FOLLOW.refreshPinFromConfig();
      }
    })
    .catch((e) => log && log(`pins save failed: ${e?.message}`, `err`));
});
// Buscador de ajustes — modulo perezoso (t_e783de96, 2026-09-05). Carga
// `rotechos-config-search.js` al abrir el modal CONFIGURACION. La cache de
// promesa evita fetches duplicados si `openMachineConfig` se invoca varias
// veces; window.MCFG_SEARCH es la señal de "ya cargado".
const __loadCfgSearch = () => __mcfgLazyLoad(`/js/rotechos-config-search.js`, `MCFG_SEARCH`);
// Disparo lazy: la primera llamada a openMachineConfig() inyecta el script.
// Antes el modulo era eager (se ejecutaba al cargar rotechos-config-modal.js)
// y ocupaba ~9 KB en el arranque en frio. Con este patron solo se paga el
// coste si el operario abre el modal — y como el modal sigue siendo solo
// escritorio, los moviles (los mas sensibles al cold set) no lo cargan nunca.


// ---
// t_33991c62 — Tabla de herramientas editable (M563), pestana HERRAMIENTAS.
// ---
// La pintura de la tabla, validacion del form y guardado viven en
// `rotechos-config-tools-table.js` (t_ec990fc0, 2026-09-05; reubicado
// desde este fichero para extraer 297 lineas que NO escriben config.g ni
// envian M-codes). Se carga de forma perezosa al abrir la pestana
// HERRAMIENTAS, mismo patron que `__loadPinesUi` y `__loadAccelCurve`.
//
// Persistencia: helper puro cfgGetToolsTable / cfgSetToolsTable en
// rotechos-config-persist.js (test unitario tests/unit/cfg-tools-table.test.js).
// La tabla vive en `config-machine.g` (per-maquina, no la toca una OTA).
//
// Tool 0 (Spindle) PROTEGIDA: el helper cfgSetToolsTable la reinyecta
// aunque el array no la incluya. Misma defensa en el modulo perezoso
// (rechaza borrar p=0).
//
// La pestana NO entra en _SAVE_TABS: tiene sus propios botones especificos
// (Anadir / Guardar / Borrar) y el Guardar generico muestra el toast
// "usa los botones especificos".
// ---
const __loadToolsTable = () => __mcfgLazyLoad(`/js/rotechos-config-tools-table.js`, `ROTECHOS_TOOLS_TABLE`);
function _onToolsTabOpen() {
  __loadToolsTable()
    .then((ui) => {
      if (!ui) return;
      if (typeof ui.bindOnce === `function`) ui.bindOnce();
      if (typeof ui.load === `function`) ui.load();
    })
    .catch((e) => log && log(`tools table load failed: ${e?.message}`, `warn`));
}
document.querySelector(`.mcfg-tab[data-tab=tools]`)?.addEventListener(`click`, _onToolsTabOpen, { once: false });
$(`mcfgTabTools`)?.addEventListener(`click`, _onToolsTabOpen);

// ---
// APLANADO — Pestaña "Asistente de aplanado de la mesa de sacrificio"
// ---
// Añadido por t_fdbab53f (sep-2026). La pestaña APLANADO abre un wizard
// que genera el recorrido en zigzag del aplanado de la mesa de sacrificio,
// lo dibuja en el visor central y SOLO ENTONCES lo ejecuta. Carga perezosa:
// rotechos-facing-wizard.js no se monta en el arranque en frío.
//
// REGLAS QUE NO SE PUEDEN SALTAR (encapsuladas en el módulo):
//   - HOME obligatorio antes de ejecutar (sin referenciar se estampa la fresa).
//   - Aviso si el área pedida se sale de M208.
//   - Si la máquina está desconectada, calcula y dibuja, pero NO ejecuta.
//   - Confirmación final con bajada explícita a la mesa.
//
// El módulo expone window.FACING (cálculo puro, testable) y
// window.ROTECHOS_FACING_WIZARD (UI perezosa). Aquí solo:
//   1. carga el módulo bajo demanda al abrir la pestaña;
//   2. monta los listeners de los inputs (una sola vez) al abrir;
//   3. dispara open() la primera vez para pre-rellenar desde M208.
// ---
const __loadFacing = () => __mcfgLazyLoad(`/js/rotechos-facing-wizard.js`, `ROTECHOS_FACING_WIZARD`);
// Facing usa la API del wizard (bindOnce, open) — distinto lifecycle que
// los modulos de tabla/herramientas. No bindear al PANEL (`#mcfgTabFacing`):
// el panel es un <div> y un click en un boton interior burbujea al panel y
// dispararia open() de nuevo, reseteando inputs. Solo el sidebar.
document.querySelector(`.mcfg-tab[data-tab=facing]`)?.addEventListener(`click`,
  () => __loadFacing().then((ui) => {
    if (!ui) return;
    if (typeof ui.bindOnce === `function`) ui.bindOnce();
    if (typeof ui.open === `function`) ui.open();
  }).catch((e) => log && log(`facing wizard load failed: ${e?.message}`, `warn`)),
  { once: false });

// ---
// t_b8cd40c2 — Señal de "modal ya disponible"
// ---
// Cuando rotechos.js carga este módulo perezosamente vía __loadConfigModal(),
// expone window.openMachineConfig (los `function` top-level crean window.X
// automáticamente en scripts clásicos). rotechos.js lo cachea y futuras
// llamadas a openMachineConfig() llegan DIRECTAS, sin pasar otra vez por el
// loader. Es el mismo patrón que ya usan los módulos perezosos internos del
// modal (`__loadAccelCurve`, `__loadPinesUi`, `__loadCfgSearch`, etc.).
window.__MCFG_READY__ = true;
// eslint-disable-next-line no-console -- aviso de diagnóstico puntual; útil si el modal
// se carga dos veces por error (síntoma del SyntaxError del intento 3 que
// motivó el renombrado a __mcfgLazyLoad). Usamos typeof guard para que en
// tests sin console.debug (cfg-machine-persistence.test.js stubea console
// a {warn, error, log}) no explote por una línea informativa.
if (typeof console !== `undefined` && typeof console.debug === `function`) {
  console.debug(`rotechos-config-modal.js cargado (perezoso, t_b8cd40c2)`);
}
