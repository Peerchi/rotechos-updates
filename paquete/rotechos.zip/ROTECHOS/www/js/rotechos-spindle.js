/* ---
 * rotechos-spindle.js — Módulo de control de husillo
 *
 * Extraído del monolito `rotechos.js` en PR #4 (refactor v103, jul-2026).
 * Contiene 2 IIFEs autocontenidos que eran gemelos dentro de rotechos.js:
 *
 *   1. SPINDLE TOGGLE (UNIFICADO)  — ex rotechos.js:2455-2539
 *      - setSpindleState(on)         → estado visual del botón btnSpindle
 *      - _spindleStop()              → para el husillo (T0 + M5)
 *      - handler del botón btnSpindle (enciende / apaga)
 *      - registerUIHook('spindle') para sincronizar con RRF
 *
 *   2. SPINDLE OVERRIDE PENDANT2       — ex rotechos.js:9105-9148
 *      - applySpOvr(val)            → override 10-200%, recalcula RPM
 *      - handlers de pendant2SpMinus / pendant2Plus (y Run, pendant2RunSpMinus/Plus)
 *      - usa SPINDLE._getNominal() y RRF.urgentGcode
 *
 * API PÚBLICA (única fuente de verdad del override del husillo — refactor
 * jul-2026, sustituye las globales implícitas _spindleOvPct /
 * _spindleNominalRpm que vivían en el monolito):
 *
 *   window.SPINDLE.getOvPct()         → porcentaje override (10–200, default 100)
 *   window.SPINDLE.setOvPct(v)        → escribe override (clamp 10–200)
 *   window.SPINDLE._getNominal()      → RPM nominal actual (0 si spindle parado)
 *   window.SPINDLE._setNominal(rpm)   → escribe RPM nominal (lo calcula el poll)
 *
 * Dependencias globales (disponibles si el módulo se carga DESPUÉS de
 * rotechos.js, que es como está en index.html):
 *   - $                  (helper DOM, rotechos.js:18)
 *   - $$                 (helper DOM, rotechos.js:19)
 *   - t()                (i18n, rotechos-i18n.js)
 *   - RRF                (namespace API RRF, rotechos.js)
 *   - registerUIHook()   (rotechos.js:1459)
 *   - _pausePollMs()     (rotechos.js:1961)
 *   - updateOvBar()      (rotechos.js:3638)
 *   - setText()          (rotechos.js, top-level helper)
 *   - toast() / log()    (top-level helpers, rotechos.js)
 *   - confirmDialog()    (top-level helper, rotechos.js)
 *   - bindFastTouch()    (rotechos.js, helper pointer events)
 *   - CFG, SM            (objetos globales del monolito)
 *
 * NOTA: de las 8 funciones que el prompt original pretendía extraer
 * (setSpindleState, _spindleStop, _populateSpindle, _uiSyncSpindleOverride,
 *  syncSpindleSlider, updateSpindleModeCards, applySpOvr, initPendant2SpOvr)
 * se extraen 4 en este PR: setSpindleState, _spindleStop, applySpOvr,
 * initPendant2SpOvr. Las 4 restantes son 1-2 liners top-level que comparten
 * closure con muchas otras funciones del monolito (raw, lines, JOG_FEED,
 * SPINDLE._getNominal, SPINDLE.getOvPct) — extraerlas aisladamente
 * aumentaría la complejidad sin reducir el tamaño del monolito de forma
 * significativa.
 *
 * LIMITACIÓN CONOCIDA (jul-2026, documentada tras refactor del doble estado):
 * La POSICIÓN visual del slider del cockpit (#spindleSlider / #spindleVal)
 * NO se re-sincroniza cuando el usuario cambia el override desde el
 * pendant PENDANT2 (pendant2SpMinus / pendant2SpPlus). El bug de CÁLCULO queda
 * arreglado: el siguiente tick del poll desnormalizará el nominal con el
 * % actualizado. La desincronización visual del slider del cockpit debe
 * validarse en banco (pendant → spindleSlider cockpit refleja el cambio
 * tras el próximo poll, NO inmediatamente). Si quieres feedback
 * inmediato, añadir un event listener en el módulo que sincronice ambos
 * sliders cuando SPINDLE.setOvPct() cambia el valor desde fuera del
 * monolito.
 * NOTA (cruce eval 2026-07-05): los botones pendant2SpMinus/pendant2SpPlus/
 * pendant2RunSpMinus/pendant2RunSpPlus que binda initPendant2SpOvr NO existen en el
 * index.html actual — los binds son null-safe y quedan inertes. El control
 * real del pendant es pendant2SpSlider (RPM objetivo, rotechos.js). Si se
 * reintroduce el override % en el pendant, crear esos IDs en index.html.
 *
 * FASE 4.7 — NATURALEZA DE LA "RAMPA" (t_8759e5e7, sep-2026):
 * La espera configurable en CONFIG → SPINDLE (campo `mcfgSpindleRamp`,
 * persistido como `; rotech-spindle-ramp={seg}`) es una espera del FIRMWARE
 * RRF mediante `G4` (dwell), NO una rampa de aceleración física del variador
 * (VFD). Implementación real cuando el operario pulsa "ENCENDER HUSILLO"
 * desde el cockpit — `startSpindleWithRamp(rpm)` en rotechos.js:1299-1325
 * emite 5 escalones `M3 S{step}` intercalados con `G4 P{dwellMs}` lineales
 * entre `spindleMin` y el RPM objetivo; no se envía ningún perfil analógico
 * de aceleración al VFD. Lo mismo aplica al post-procesador
 * POSTPROCESADORES/FUSION 360/rotechosultimate.cps:357-361 (inserta `G4 S{s}`
 * tras cada `M3 S{n}` cuando la propiedad `spindleSpinUpDelay > 0`) y al
 * macro `sys/spindle_ramp_wait.g` (emite `G4 P{ms}` proporcional a
 * `spindles[0].active/spindles[0].max`). Las tres rutas son SOFTWARE waits;
 * la curva de aceleración analógica del propio VFD — si existe — queda
 * intacta (es un parámetro del variador, no de RRF). Por eso la UI dice
 * "Espera" (firmware dwell) y NO "rampa" cuando se refiere a este campo;
 * ver también la medición Fase 4.7 en `docs/dev/hallazgos/` para los
 * efectos en UI que SÍ requerirían tocar `index.html`/`rotechos.css`
 * (sacar "Calentar" de Configuracion, separar visualmente PWM/relé/Modbus,
 * ocultar parámetros según modo, panel comando/RPM/VFD/err) — esos cambios
 * quedan BLOQUEADOS en t_8759e5e7 por la restricción del carril de la
 * tarjeta (no tocar HTML/CSS/config-modal).
 * --- */
(function () {
  'use strict';

  // ---
  // NAMESPACE PÚBLICO DEL HUSILLO
  // Estado encapsulado: las dos variables que antes vivían como
  // globales implícitas en el monolito (_spindleOvPct,
  // _spindleNominalRpm) pasan a este closure. Acceso solo vía la API.
  // ---
  let _ovPct = 100;        // % override (clamp 10–200)
  let _nominalRpm = 0;     // RPM nominal (0 cuando spindle parado)
  window.SPINDLE = {
    getOvPct()       { return _ovPct; },
    setOvPct(v)      { _ovPct = Math.max(10, Math.min(200, Math.round(+v))); },
    _getNominal()    { return _nominalRpm; },
    _setNominal(rpm) { _nominalRpm = Math.max(0, Math.round(+rpm || 0)); },
  };

  // ---
  // MÓDULO 1: SPINDLE TOGGLE (UNIFICADO)
  // Ex rotechos.js:2455-2539
  // ---
  (function () {
    const btnSpindle = $(`btnSpindle`);
    let spindleOn = !1,
      _spindleBusy = !1;
    function setSpindleState(on) {
      // _spindleBusy solo bloquea clics del usuario, NO la actualización visual.
      // Antes: la guardia impedía que el propio _spindleStop() actualizara el botón
      // tras enviar M5, dejándolo siempre como "encendido" visualmente.
      spindleOn = on;
      // Espejo en SM para que JOBHIST (rotechos-modules.js) pueda acumular las
      // horas de husillo — antes leía SM.spindleOn (inexistente) y el contador
      // de mantenimiento quedaba siempre a 0.
      if (typeof SM !== `undefined`) SM.spindleOn = on;
      if (btnSpindle) {
        btnSpindle.className = on ? `exec-action-btn spindle-off school-tip` : `exec-action-btn spindle-on school-tip`;
        $(`btnSpindleLabel`).textContent = on ? t(`btn.spindleOff`, `APAGAR HUSILLO`) : t(`btn.spindleOn`, `ENCENDER HUSILLO`);
        $(`btnSpindleIcon`).innerHTML = on
          ? `<svg viewbox="0 0 24 24" fill=none height=18 stroke=currentColor stroke-linecap=round stroke-linejoin=round stroke-width=3 width=18><circle cx=12 cy=12 r=10 /><line x1=15 x2=9 y1=9 y2=15 /><line x1=9 x2=15 y1=9 y2=15 /></svg>`
          : `<svg viewbox="0 0 24 24" fill=none height=18 stroke=currentColor stroke-linecap=round stroke-linejoin=round stroke-width=3 width=18><path d="M18.36 6.64a9 9 0 1 1-12.73 0"/><line x1=12 x2=12 y1=2 y2=12 /></svg>`;
      }
    }
    // window.setSpindleState = setSpindleState;  // ELIMINADO jul-2026: cero llamadores externos (grep verificado en www/ y tests/). "Compat" sin consumidores es superficie falsa.
    registerUIHook(`spindle`, (data) => {
      // Usar spindles[0].state como fuente de verdad — `active` retiene el último
      // RPM solicitado incluso después de M5 en algunas versiones de RRF, lo que
      // hacía que el botón se quedara como "encendido" tras apagar.
      const sp = data?.spindles?.[0];
      const running = sp && sp.state && sp.state !== `stopped` && sp.state !== `unconfigured`;
      setSpindleState(!!running);
    });
    async function _spindleStop() {
      _spindleBusy = !0;
      if (btnSpindle) { btnSpindle.disabled = !0; btnSpindle.style.opacity = `0.5`; }
      _pausePollMs(2500);
      try {
        await RRF.urgentGcode(`T0\nM5`).catch(() => {});
        setSpindleState(false);
        // Resetear RPM inmediatamente — el poll está pausado 2.5s y sin esto
        // la barra y el contador se quedan en el último valor hasta que vuelva
        // el siguiente ciclo de polling.
        setText(`sRPM`, `0`);
        const _sBar = $(`sBar`);
        if (_sBar) _sBar.style.transform = `scaleX(0)`;
        SPINDLE._setNominal(0);
        updateOvBar(`spindleBarFill`, `spindleBarTrack`, SPINDLE.getOvPct());
        toast(t(`msg.spindleOff`, `Spindle OFF`), `ok`);
        log(`T0 + M5 — Spindle apagado`, `cmd`);
      } finally {
        setTimeout(() => {
          _spindleBusy = !1;
          if (btnSpindle) { btnSpindle.disabled = !1; btnSpindle.style.opacity = ``; }
        }, 1500);
      }
    }
    btnSpindle && btnSpindle.addEventListener(`click`, async () => {
      if (_spindleBusy) return;
      if (document.body.classList.contains(`spindle-manual`))
        return toast(t(`msg.spManual`, `Husillo manual: se enciende y se apaga con su interruptor.`), `warn`);
      const s = SM.current;
      if (!spindleOn && (s === STATES.RUNNING || s === STATES.PAUSED)) {  // A-2: guard de estado
        toast(t(`msg.noSePuedeModificar`, `No se puede modificar el husillo en marcha`), `warn`);
        return;
      }
      // 15-sep: tras un paro de emergencia no se enciende; apagar, siempre.
      if (!spindleOn && s === STATES.ERROR && machineMoveBlocked()) return;
      if (spindleOn) {
        await _spindleStop();
      } else {
        const mx = parseInt($(`mcfgSpindleMax`)?.value) || 24000;
        const mn = parseInt($(`mcfgSpindleMin`)?.value) || CFG.spindleMin || 6e3;
        const rpm = Math.min(mx, Math.max(6000, mn)); // A-3: clamp spindleMin al rango seguro
        if (!(await confirmDashboard(
          t(`dlg.spindleOn.title`, `Encender husillo`),
          `<p style="margin-bottom:10px">${t(`dlg.spindleOn.pre`, `El husillo arrancará a`)} <strong style="color:var(--green-strong);font-size:16px">${rpm.toLocaleString(`es-ES`)} RPM</strong>.</p><p style="color:var(--yellow);font-size:11px">${t(`dlg.spindleOn.warn`, `Asegúrate de que no hay nadie cerca de la fresa.`)}</p>`,
        ))) return;
        _spindleBusy = !0;
        if (btnSpindle) { btnSpindle.disabled = !0; btnSpindle.style.opacity = `0.5`; }
        _pausePollMs(2500);
        // Feedback INMEDIATO (igual que el OFF): el poll está pausado 2.5s, así que
        // sin esto el botón y el RPM no cambiarían hasta que vuelva el polling.
        setSpindleState(true);
        setText(`sRPM`, `${rpm}`);
        try {
          // FIX: usar startSpindleWithRamp para soft-start si CFG.spindleRamp > 0
          await RRF.startSpindleWithRamp(rpm);
        } finally {
          setTimeout(() => {
            _spindleBusy = !1;
            if (btnSpindle) { btnSpindle.disabled = !1; btnSpindle.style.opacity = ``; }
          }, 1500);
        }
      }
    });
  })();

  // ---
  // MÓDULO 2: SPINDLE OVERRIDE PENDANT2
  // Ex rotechos.js:9105-9148
  // FIX: M221 es override de extrusión (impresora 3D), NO afecta al spindle.
  // Para CNC, calculamos las RPM efectivas en JS y enviamos M3 directamente.
  // ---
  (function initPendant2SpOvr() {
    function applySpOvr(val) {
      // A1-FIX (HUECO-4, t_34354573): el inventario A1 documentó que
      // applySpOvr no consultaba estado de la máquina — un operario podía
      // subir override al 200% durante un corte y RRF aceptaba el M3
      // recalculando RPM al doble (posible rotura de fresa). El comentario
      // de líneas 63-67 dice "los botones NO existen en index.html" pero
      // grep verificado 2026-09-06: pendant2RunSpMinus/Plus sí existen
      // (index.html:2838, 2841) y los binds de este IIFE están vivos. El
      // guard sigue el patrón canónico del proyecto: machineMoveBlocked()
      // corta RUNNING+ERROR y deja pasar PAUSED (mismo contrato que las
      // macros QA; los keybindings X/Y/Z que cortan en PAUSED usan el
      // parámetro blockPaused=true pero redefinen el WCS, no es nuestro
      // caso — el override de RPM puede querer ajustarse en pausa para
      // reanudar con RPM corregida). PAUSED deja el G-code del corte
      // intacto en su RPM nominal; el override solo afecta el M3 siguiente.
      if (window.machineMoveBlocked && window.machineMoveBlocked()) return;
      // El clamp se aplica dentro de SPINDLE.setOvPct (10–200).
      SPINDLE.setOvPct(val);
      const spOvPct = SPINDLE.getOvPct();
      // Calcular RPM real basado en el nominal del spindle (clamped al rango VFD)
      const nominal = SPINDLE._getNominal();
      // 26-sep: sin `_spindleRunning` el + arrancaba el husillo parado (el nominal
      // guarda el último S); sin reintentos, que uno tardío lo rearrancaría tras un M5.
      if (nominal > 0 && _spindleRunning) {
        const spindleMax = parseInt($(`mcfgSpindleMax`)?.value) || 24000;
        const spindleMin = parseInt($(`mcfgSpindleMin`)?.value) || 6000;
        const rpm = Math.max(spindleMin, Math.min(spindleMax, Math.round(nominal * spOvPct / 100)));
        RRF.gcode("M3 S" + rpm).catch(() => {});
      }
      [
        $(`pendant2SpVal`),
        $(`pendant2RunSpVal`),
      ].forEach(function (el) {
        if (el) el.textContent = spOvPct + "%";
      });
      [
        $(`pendant2SpBar`),
        $(`pendant2RunSpBar`),
      ].forEach(function (el) {
        if (el) el.style.transform = `scaleX(${Math.min(spOvPct, 200) / 200})`;
      });
      // (mpgSpOv/mpgSpOvVal — overrides móviles eliminados al rediseñar el pendant)
    }
    ["pendant2SpMinus", "pendant2RunSpMinus"].forEach(function (id) {
      const el = $(id);
      if (el)
        bindFastTouch(el, function () {
          applySpOvr(SPINDLE.getOvPct() - 10);
        });
    });
    ["pendant2SpPlus", "pendant2RunSpPlus"].forEach(function (id) {
      const el = $(id);
      if (el)
        bindFastTouch(el, function () {
          applySpOvr(SPINDLE.getOvPct() + 10);
        });
    });
  })();

  // El namespace window.SPINDLE se declara al INICIO del IIFE exterior
  // (junto con el estado encapsulado _ovPct / _nominalRpm). El bloque
  // "Exposición pública (namespace, coherente con otros módulos rotechos-*)"
  // que vivía aquí ha sido eliminado: declarar dos veces el mismo objeto
  // sombreaba el API inicial.
})();