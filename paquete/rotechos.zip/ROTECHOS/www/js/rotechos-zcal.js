// ---
// rotechos-zcal.js — ZCAL · asistente de calibración del sensor Z (mide
// z_sensor_to_table = global.probe_trigger_z − Z máquina al tocar el mártir).
//
// PEREZOSO: solo lo abre CONFIGURACIÓN → SONDA/SAC → «Calibrar con asistente».
// rotechos.js instala un PROXY en window.ZCAL que carga este fichero en el
// primer clic; al ejecutarse lo sustituye por el objeto real.
// Tests: e2e-asistentes-guardas-paridad.spec.js (guardas) y e2e-ui-states.
// ---
(function () {
  // eslint-disable-next-line no-var -- var deliberado (hoisting, mismo patrón que KIN)
  var ZCAL = {
    triggerZ: null, touchZ: null, result: null, _t: null,
    go(n) {
      $$("#zcalModal .zcal-step").forEach((e) => {
        e.style.display = +e.dataset.step === n ? "block" : "none";
      });
    },
    open() {
      this.triggerZ = this.touchZ = this.result = null;
      clearInterval(this._t); this._t = null;
      const homed = !!(AppState.limits && AppState.limits.allHomed);
      const w = $("zcalHomeWarn"); if (w) w.style.display = homed ? "none" : "block";
      this.go(1);
      $("zcalModal").classList.add("show");
    },
    close() { clearInterval(this._t); this._t = null; $("zcalModal").classList.remove("show"); },
    // Guardas de su referencia (14-sep): palpado y viaje en XY como SONDA Z e
    // Ir a 0 (p vacío); flechas como el jog, que también bloquea en PAUSA (p=true).
    _ok(p) {
      if (machineMoveBlocked(p)) return false;
      if (AppState.limits && AppState.limits.allHomed) return true;
      toast(t("zcal.msg.homeRequired", "Haz homing (G28) antes de calibrar"), "err");
      return false;
    },
    async step2() {
      if (!this._ok()) return;
      this.go(2);
      $("zcalProbeResult").textContent = t("zcal.msg.probingSensor", "Palpando el sensor…");
      const b = $("zcalToStep3"); if (b) b.disabled = true;
      const ok = await RRF.gcode("M5\nM98 P\"0:/sys/probe_z_sensor.g\"");
      if (!ok) { $("zcalProbeResult").innerHTML = '<span style="color:var(--red)">' + t("zcal.msg.probeError", "Error en el palpado. Revisa el sensor.") + '</span>'; return; }
      const m = await _fetchModel("global.probe_trigger_z");
      const v = m && m.result;
      if (typeof v !== "number") { $("zcalProbeResult").innerHTML = '<span style="color:var(--red)">' + t("zcal.msg.readError", "No pude leer el disparo (probe_trigger_z).") + '</span>'; return; }
      this.triggerZ = v;
      // FIX B-03 (2026-07-05): escHtml por defense-in-depth (v.toFixed(3) es número,
      // pero un firmware comprometido podría devolver HTML aquí).
      $("zcalProbeResult").innerHTML = t("zcal.msg.sensorTriggered", "Disparo del sensor:") + " <b>" + escHtml(v.toFixed(3)) + "</b> " + t("zcal.msg.mmMachine", "mm (máquina) ✓");
      typeof droRipple === `function` && droRipple(`wZ`);
      if (b) b.disabled = false;
    },
    async step3() {
      if (!this._ok()) return;
      this.go(3);
      await RRF.gcode("G90\nG53 G0 X{move.axes[0].max/2} Y{move.axes[1].max/2}").catch(() => {});
      clearInterval(this._t);
      this._t = setInterval(async () => {
        if (!$("zcalModal") || !$("zcalModal").classList.contains("show")) { clearInterval(this._t); this._t = null; return; }
        const m = await _fetchModel("move.axes[2].machinePosition");
        if (m && typeof m.result === "number") { const el = $("zcalZlive"); if (el) el.textContent = m.result.toFixed(3); }
      }, 400);
    },
    descend(mm) { if (this._ok(true)) RRF.gcode("G91\nG1 Z-" + mm + " F200\nG90").catch(() => {}); },
    up(mm) { if (this._ok(true)) RRF.gcode("G91\nG1 Z" + mm + " F300\nG90").catch(() => {}); },
    async paperDrags() {
      const m = await _fetchModel("move.axes[2].machinePosition");
      const v = m && m.result;
      if (typeof v !== "number") { toast(t("zcal.msg.readZMachineError", "No pude leer la Z máquina"), "err"); return; }
      this.touchZ = v;
      this.result = this.triggerZ - this.touchZ;
      clearInterval(this._t); this._t = null;
      $("zcalResult").textContent = this.result.toFixed(2);
      this.go(4);
    },
    async save() {
      const v = +Number(this.result).toFixed(2);
      const f = CFG_FIELDS.mcfgSacSensorZ;
      const inp = $("mcfgSacSensorZ"); if (inp) inp.value = v;
      await RRF.gcode(f.rtCmd(v)).catch(() => {});
      await cfgPersistGlobalLine("z_sensor_to_table", f.formatter(v));
      toast("z_sensor_to_table = " + v + ` mm ${t(`msg.savedSfxUpper`, `guardado`)} ✓`, "ok");
      this.close();
    },
  };

  // Sustituye el proxy del monolito: las llamadas siguientes llegan directas.
  window.ZCAL = ZCAL;
})();
