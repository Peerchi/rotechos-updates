/* ---
 * rotechos-dom-helpers.js — Helpers DOM puros + guarda de movimientos
 *
 * Extraído del monolito (rotechos.js:59-127) en la tarjeta kanban
 * t_82625155 (bloques 3, 4 y 5 del re-mapeo de Kimi2, ago-2026). Agrupa
 * cinco helpers que viajan juntos por contrato: cuatro son DOM puro
 * (no tocan estado de máquina) y uno es la guarda de seguridad que
 * decide si una acción de UI debe seguir adelante.
 *
 *   1. `setText(id, val)`        — asignación segura de `textContent`
 *                                  (ignora silenciosamente si el id no existe).
 *                                  Sustituye el patrón `$(id).textContent = x`
 *                                  en los 13 call-sites del monolito y los
 *                                  13 call-sites de los defer modules.
 *
 *   2. `setVal(id, val)`         — análogo para `value` (8 call-sites).
 *
 *   3. `bindFastTouch(el, cb)`   — pointerdown + click-suppressor.
 *                                  Usado en 6 botones críticos (jog pendant,
 *                                  wizard, macros del teclado) para que un
 *                                  pointerdown prolongado dispare la acción
 *                                  sin disparar el click sintético.
 *
 *   4. `setupDragAndDrop(...)`   — UI de drop de archivos (border + bg +
 *                                  handler de drop / change). Único consumidor
 *                                  actual: rotechos-backup.js:220 (panel de
 *                                  restore de backups).
 *
 *   6. `writeText` / `writeHtml` / `writeProp` / `writeAttr` — escriben en el DOM SOLO si el
 *                                  valor cambia (ver el bloque de abajo).
 *
 *   5. `machineMoveBlocked(b)`   — GUARDA DE SEGURIDAD: corta acciones que
 *                                  MUEVEN la máquina fuera del trabajo.
 *                                  `blockPaused = true` también corta en
 *                                  PAUSED (re-cero manual desplazaría la pieza
 *                                  al reanudar). Es la pieza que mantiene los
 *                                  tests QA-8 (HOME ALL bloqueado en RUNNING)
 *                                  y el guard A-1 del wizard.
 *
 * POR QUÉ UN MÓDULO NUEVO Y NO FUSIONAR CON rotechos-dom-utils.js:
 *
 *   - rotechos-dom-utils.js: `escHtml` (seguridad XSS) + `applyStoredTheme`
 *     (efecto de arranque). Responsabilidades: seguridad + persistencia.
 *   - rotechos-dom.js: `$q` / `$qa` (querySelector con root opcional).
 *     Responsabilidad: helpers de query.
 *   - rotechos-dom-helpers.js (este): manipulación DOM de instancia + guarda
 *     de UI. Responsabilidad: acciones de UI sobre el árbol.
 *
 * Fusionar este módulo en dom-utils mezclaría XSS con asignación de texto,
 * y haría el archivo confuso para cualquiera que busque "qué pasa si un
 * id no existe en `setText`". Sergi pide 2 módulos coherentes antes que
 * 5 con una función cada uno; aquí la coherencia es por RESPONSABILIDAD,
 * no por proximidad léxica en el monolito original.
 *
 * DEPENDENCIAS (cargadas ANTES en index.html):
 *
 *   - `$`               (rotechos.js, alias de `document.getElementById`)
 *   - `SM`, `STATES`    (rotechos.js, máquina de estados) — solo machineMoveBlocked
 *   - `toast`, `t`      (rotechos.js / rotechos-i18n.js)       — solo machineMoveBlocked
 *
 * Si `SM` / `STATES` / `toast` / `t` no existen (tests sin shell),
 * `machineMoveBlocked` se DEFENDE: devuelve `false` (NO bloquea) en vez
 * de tirar. Esto es seguro porque el único estado en el que debería
 * bloquear es RUNNING/PAUSED, y un test sin shell no tiene máquina.
 *
 * CARGA: este módulo debe ir ANTES de rotechos.js en index.html. Motivo:
 * los 31 call-sites internos del monolito y los 14 de los defer modules
 * (rotechos-jog, rotechos-modules, rotechos-macros, rotechos-pendant,
 *  rotechos-spindle, rotechos-wcs, rotechos-config-modal, rotechos-backup,
 *  rotechos-state-ui) usan estos identificadores como si fueran globales
 * del script (mismo global lexical environment en los <script defer>).
 * Con defer, el orden de aparición ES el orden de ejecución: si este
 * módulo va primero, los símbolos quedan registrados antes de que el
 * monolito y los defer modules posteriores los necesiten.
 *
 * El monolito conserva PUENTES LOCALES mínimos (`const setText = window.setText`,
 * etc.) para no tocar las 31 invocaciones internas.
 * --- */
(function () {
  'use strict';

  // ---
  // 1. setText(id, val) — asignación segura de textContent
  //
  // Si el elemento no existe (id dinámico aún sin pintar, o test sin DOM)
  // ignora silenciosamente en vez de tirar `Cannot read properties of
  // null (reading 'textContent')`. Misma firma, mismo comportamiento que
  // la versión del monolito.
  // ---
  // ---
  // writeText / writeHtml / writeProp — escribir solo si cambia (8-oct-2026)
  //
  // Medido con la maquina en reposo: cada ciclo de telemetria reescribia ~90
  // textos, clases, titles y disabled con el MISMO valor que ya tenian. El
  // resultado en pantalla era identico, pero cada escritura generaba una
  // mutacion del DOM, y el autoajuste de pantalla (rotechos-autofit.js) las
  // escucha: re-medía las dos columnas del cockpit en cada ciclo (~30 ms de
  // layout forzado en un portatil; varias veces mas en una tablet de taller).
  //
  // La comparacion es contra el DOM VIVO, no contra una cache: si otra cosa
  // cambio el elemento, se escribe igual que antes. Solo se salta una
  // escritura cuyo resultado ya esta en pantalla.
  // ---
  function writeText(el, val) {
    if (!el) return;
    const s = val == null ? '' : String(val);
    const f = el.firstChild;
    // Igual que textContent = s: un unico nodo de texto con ese contenido
    // (o ningun hijo si s es ''). Un hijo elemento obliga a escribir, porque
    // textContent = s lo aplanaria. `f == null` cubre los mocks sin DOM.
    if (s === '' ? f === null
      : (f != null && f === el.lastChild && f.nodeType === 3 && f.data === s)) return;
    el.textContent = s;
  }

  // Solo para marcado sin listeners en sus hijos (iconos, decimales del DRO):
  // saltarse la escritura conserva los nodos hijos existentes en vez de crear
  // otros iguales.
  function writeHtml(el, html) {
    if (!el) return;
    if (typeof html === 'string' && el.innerHTML === html) return;
    if (el.__rtHtmlSrc === html && el.innerHTML === el.__rtHtmlOut) return;
    el.innerHTML = html;
    el.__rtHtmlSrc = html;
    el.__rtHtmlOut = el.innerHTML;
  }

  // Propiedades reflejadas (className, title, disabled, hidden, value...).
  function writeProp(el, prop, val) {
    if (el && el[prop] !== val) el[prop] = val;
  }

  function writeAttr(el, name, val) {
    if (el && el.getAttribute(name) !== String(val)) el.setAttribute(name, val);
  }

  const setText = (id, val) => {
    writeText(typeof $ === 'function' ? $(id) : document.getElementById(id), val);
  };

  // ---
  // 2. setVal(id, val) — análogo para `value`
  // ---
  const setVal = (id, val) => {
    const el = typeof $ === 'function' ? $(id) : document.getElementById(id);
    if (el) el.value = val;
  };

  // ---
  // 3. bindFastTouch(element, callback) — pointerdown + click suppressor
  //
  // El botón se subscribe a pointerdown para reaccionar al toque largo;
  // también se subscribe a click para ANULAR el click sintético que el
  // navegador dispara tras pointerup (evita doble disparo). El mouse
  // sólo cuenta si es botón izquierdo (e.button === 0).
  // ---
  function bindFastTouch(element, callback) {
    if (!element) return;
    element.addEventListener('pointerdown', (e) => {
      // Solo clic izquierdo o toque táctil
      if (e.pointerType === 'mouse' && e.button !== 0) return;
      if (e.pointerId && element.hasPointerCapture(e.pointerId)) {
        element.releasePointerCapture(e.pointerId);
      }
      callback(e);
    });
    element.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
    });
  }

  // ---
  // 4. setupDragAndDrop(dropZone, fileInput, onFileDrop, hoverBorder, hoverBg)
  //
  // Conecta el click → fileInput, los eventos dragover/dragleave (cambia
  // border/bg), y drop/change (entrega el primer archivo a `onFileDrop`).
  // No-op silencioso si dropZone o fileInput faltan.
  // ---
  function setupDragAndDrop(dropZone, fileInput, onFileDrop, hoverBorder, hoverBg = '') {
    if (!dropZone || !fileInput) return;
    dropZone.addEventListener(`click`, () => fileInput.click());
    dropZone.addEventListener(`dragover`, (e) => {
      e.preventDefault();
      if (hoverBorder) dropZone.style.borderColor = hoverBorder;
      if (hoverBg) dropZone.style.background = hoverBg;
    });
    dropZone.addEventListener(`dragleave`, () => {
      dropZone.style.borderColor = ``;
      dropZone.style.background = ``;
    });
    const handleFiles = (e) => {
      e.preventDefault();
      dropZone.style.borderColor = ``;
      dropZone.style.background = ``;
      const files = e.dataTransfer ? e.dataTransfer.files : e.target.files;
      if (files.length) onFileDrop(files[0]);
    };
    dropZone.addEventListener(`drop`, handleFiles);
    fileInput.addEventListener(`change`, handleFiles);
  }

  // ---
  // 5. machineMoveBlocked(blockPaused = false) — guarda de seguridad
  //
  // Devuelve `true` si la máquina está en un estado en el que la acción
  // debe cortarse (con toast informativo). Sin SM/STATES/toast (tests sin
  // shell) devuelve `false` para no bloquear tests.
  //
  // Estados que cortan:
  //   - RUNNING: bloquea con msg.blockedRunning
  //   - PAUSED  (sólo si blockPaused=true): bloquea con msg.blockedPaused
  //              (un re-cero manual desplazaría la pieza al reanudar)
  //   - ERROR   (t_ee1497a0): bloquea SIEMPRE, sin excepción. Esta guarda
  //              cubre los 18 call-sites de rotechos.js (HOME, M6, goto0,
  //              park, simulate, spindleWarmup, pendantLoadFile, macros con
  //              movimiento, ceros XYZ, keybindings H/S/R/X/Y/Z). El único
  //              movimiento que se permite en ERROR es +Z, y ese caso NO
  //              pasa por aquí: lo trata doJogStep en rotechos-jog.js con
  //              confirmación explícita y velocidad reducida.
  //
  // Razonamiento: tras un M112 la herramienta puede quedar clavada en la
  // pieza. +Z la aleja (reduce peligro). XY y -Z rompen herramienta/pieza
  // o hunden más la fresa. Pero un guard genérico que dejara +Z abierto
  // aquí obligaría a TODOS los consumidores a recordar el caso. Mejor un
  // punto único (machineMoveBlocked) que dice "no" y un handler concreto
  // (doJogStep) que dice "+Z con confirmación".
  //
  // PENDIENTE BANCO: lo que RRF hace con un G1 después de un M112 NO se
  // ha probado nunca contra la Scylla. Este cambio arregla la INTERFAZ;
  // NO afirma que el firmware rechace el comando. No escribir nunca en
  // acta o comentario que "la máquina no se moverá".
  //
  // El monolito conserva un puente local `const machineMoveBlocked = window.machineMoveBlocked`
  // para no tocar las 19 invocaciones internas (líneas 2998, 4105, 4138, 4152,
  // 4169, 4192, 4448, 4520, 4658, 4662, 4663, 4666-4668).
  // ---
  function machineMoveBlocked(blockPaused = false) {
    if (typeof SM === 'undefined' || typeof STATES === 'undefined') return false;
    if (SM.current === STATES.RUNNING) {
      if (typeof toast === 'function') {
        toast(t(`msg.blockedRunning`, `Bloqueado: hay un trabajo EN MARCHA (pausa primero)`), `warn`);
      }
      return true;
    }
    if (blockPaused && SM.current === STATES.PAUSED) {
      if (typeof toast === 'function') {
        toast(t(`msg.blockedPaused`, `Bloqueado en PAUSA: alteraría el trabajo al reanudar`), `warn`);
      }
      return true;
    }
    if (SM.current === STATES.ERROR) {
      // Tras un paro de emergencia la herramienta puede estar clavada en la
      // pieza. Bloqueamos TODO aquí (HOME, sonda Z, M6, husillo, ceros,
      // macros con movimiento, iniciar trabajo). El único movimiento que
      // se permite es +Z, y ese caso lo trata doJogStep en rotechos-jog.js
      // con confirmación explícita + velocidad reducida.
      if (typeof toast === 'function') {
        toast(
          t(
            `msg.blockedEStop`,
            `Parada de emergencia activa. Rearma para recuperar el control. Puedes subir Z para retirar la herramienta.`,
          ),
          `warn`,
        );
      }
      return true;
    }
    return false;
  }

  // ---
  // Publicación en globalThis (mismo patrón que rotechos-gcode-map.js y
  // rotechos-dom-utils.js). El monolito hace `const X = window.X` justo
  // después para mantener las 31 invocaciones internas con el mismo
  // nombre y sin tocar nada.
  // ---
  if (typeof globalThis.setText === 'undefined') {
    globalThis.setText = setText;
  }
  if (typeof globalThis.writeText === 'undefined') {
    globalThis.writeText = writeText;
  }
  if (typeof globalThis.writeHtml === 'undefined') {
    globalThis.writeHtml = writeHtml;
  }
  if (typeof globalThis.writeProp === 'undefined') {
    globalThis.writeProp = writeProp;
  }
  if (typeof globalThis.writeAttr === 'undefined') {
    globalThis.writeAttr = writeAttr;
  }
  if (typeof globalThis.setVal === 'undefined') {
    globalThis.setVal = setVal;
  }
  if (typeof globalThis.bindFastTouch === 'undefined') {
    globalThis.bindFastTouch = bindFastTouch;
  }
  if (typeof globalThis.setupDragAndDrop === 'undefined') {
    globalThis.setupDragAndDrop = setupDragAndDrop;
  }
  if (typeof globalThis.machineMoveBlocked === 'undefined') {
    globalThis.machineMoveBlocked = machineMoveBlocked;
  }
})();
