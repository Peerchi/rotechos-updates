/* ---
 * RotechOS — MODAL PENDANT (Macros / Files / G-code editor)
 * Extraído de rotechos.js. Debe cargarse DESPUÉS de rotechos.js — usa
 *   $, RRF, _fetchRRF, TARGET_IP, myMacros, renderMacros, escHtml,
 *   toast, log, confirmDialog, loadFile, FM, sleep, fmLoadList,
 *   SM, STATES. Todos definidos en rotechos.js.
 *
 * NOTA: el rescate PLR (Power Loss Recovery) fue RETIRADO del sistema
 * (decisión 2026-07-04). M911 y la persistencia de posición se conservan.
 * --- */

// ---
// MODAL PENDANT — Macros, archivos y editor G-code para PENDANT/PC
// ---
(function () {
  const btn = $(`pcMacrosTriggerBtn`);
  const modal = $(`macrosModal`);
  const closeBtn = $(`btnMacrosModalClose`);

  function renderMacrosModal() {
    const body = $(`macrosModalBody`);
    if (!body) return;

    if (!myMacros || !myMacros.length) {
      body.innerHTML = '<div class="fm-empty">No hay macros configuradas</div>';
      return;
    }

    body.innerHTML = "";
    myMacros.forEach(function (m, i) {
      const row = document.createElement("div");
      row.className = "macros-modal-macro-row";
      row.innerHTML =
        `<button class="macros-modal-play" title="Ejecutar: ${escHtml(m.name)}">` +
        `<span class="macros-modal-idx">${i + 1}</span>` +
        `<span><span class="macros-modal-name">${escHtml(m.name)}</span>` +
        `<span class="macros-modal-path">${escHtml(m.path)}</span></span>` +
        `<svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor" style="color:var(--green-strong);opacity:.5;flex-shrink:0;margin-left:auto"><polygon points="5 3 19 12 5 21 5 3"/></svg>` +
        `</button>`;

      // K-COB-01 (t_752b8b07, 2026-08-12): el modal del pendant NO preguntaba
      // antes de mover la máquina. El cockpit (rotechos-macros.js:154) y la
      // lista pendant2 (rotechos.js:4440) ya confirmaban con una whitelist
      // (bordeador|sonda|probe|home|goto|park|coreografia) — la incoherencia
      // es que esta entrada repetía la lógica de ejecución sin reusar el
      // confirmDialog. Un recién llegado tocaba un nombre que no entendía y
      // la máquina se movía. Mismo patrón que los otros dos caminos:
      // confirmDialog antes del gcode, sin whitelist (toda macro desde esta
      // lista es desconocida, no podemos adivinar qué hace). Texto dice QUÉ
      // va a pasar (mueve la máquina) y el nombre del archivo, no solo
      // "¿estás seguro?".
      row
        .querySelector(".macros-modal-play")
        .addEventListener("click", async function () {
          // A1-FIX (HUECO-1, t_34354573): las otras 3 superficies de macros
          // (rotechos-macros.js:299, rotechos.js:6044, rotechos-macros.js:1075)
          // ya llaman machineMoveBlocked() antes del M98. Esta era la única
          // que se quedó fuera — un RUNNING/PAUSED/ERROR podía lanzar M98
          // sobre goto0.g / park.g con la fresa cortando. Mismo patrón y
          // misma excepción vssc (anti-chatter en marcha a propósito).
          if (!/vssc/i.test(m.name) && window.machineMoveBlocked && window.machineMoveBlocked()) return;
          const ok = await confirmDialog(
            t("dlg.macroPendant.title", "Ejecutar macro"),
            `<strong>${escHtml(m.name)}</strong><br>` +
              t(
                "dlg.macroRun.will",
                "Moverá la máquina",
              ) +
              `.<br>${t("dlg.macroRun.cont", "¿Continuar?")}`,
          );
          if (!ok) return;
          this.style.opacity = "0.5";
          modal.classList.remove("show");
          const r = await RRF.gcode(`M98 P"${m.path}"`);
          this.style.opacity = "";
          toast(r ? m.name : `${t("msg.errorIn", "Error en")} "${m.name}"`, r ? "ok" : "err");
          log(`M98 P"${m.path}"`, "cmd");
        });

      body.appendChild(row);
    });
  }

  window.renderMacrosModal = renderMacrosModal;

  if (btn) {
    btn.addEventListener("click", function () {
      renderMacrosModal();
      modal.classList.add("show");
    });
  }

  if (closeBtn) {
    closeBtn.addEventListener("click", function () {
      modal.classList.remove("show");
    });
  }

  if (modal) {
    modal.addEventListener("click", function (e) {
      if (e.target === modal) modal.classList.remove("show");
    });
  }

  const _origRenderMacros = window.renderMacros;
  window.renderMacros = function () {
    if (_origRenderMacros) _origRenderMacros();
    const modal = $(`macrosModal`);
    if (modal && modal.classList.contains("show")) renderMacrosModal();
  };
})();

async function tvLoadFilesModal() {
  const body = $(`tvFilesModalBody`);
  const countEl = $(`tvFilesModalCount`);
  const badgeEl = $(`tvFilesBadge`);

  if (!body) return;

  body.innerHTML = '<div class="fm-empty">Cargando…</div>';

  let data = null;
  try {
    // FIX t_34d8ec32 (H-N7 informe 2026-08-18_busca-superficie-de-seguridad-v3):
    // escudo tryConnect antes de listar /gcodes — sin él, un atacante en la
    // WiFi del taller puede leer los nombres de las piezas (info comercial)
    // SIN autenticar. Solo aplica el escudo si rotechosAuth está cargado;
    // si no, mismo comportamiento que antes (no-op). Sin toast: el call-site
    // ya muestra "Cargando…" y el estado vacío del modal indica fallo al
    // operario sin reinvención de UX. NO contaminamos RRF._lastFail: el
    // pendant es solo-lectura y el escudo aborta por motivos ortogonales al
    // diagnóstico MDI.
    if (typeof window !== `undefined` && window.rotechosAuth && typeof window.rotechosAuth.tryConnect === `function`) {
      const sc = await window.rotechosAuth.tryConnect(TARGET_IP, ``);
      if (!sc || !sc.ok) {
        log(`pendant rr_filelist: escudo auth rechaza — catálogo no cargado`, `warn`);
        data = null;
      } else {
        data = await _fileList(`0:/gcodes`);
      }
    } else {
      data = await _fileList(`0:/gcodes`);
    }
  } catch (e) {
    data = null;
  }

  const files = (data && data.files ? data.files : []).filter(function (f) {
    return f.type === "f" && /\.(gcode|g|nc|cnc|tap|txt)\s*$/i.test(f.name);
  });

  /* archivo demo eliminado — sin conexión se muestra vacío */

  body.innerHTML = "";

      if (countEl)
        countEl.textContent =
          `${files.length} archivo${files.length === 1 ? "" : "s"}`;

      if (badgeEl) badgeEl.textContent = files.length || "—";

      if (!files.length) {
        body.innerHTML =
          '<div class="fm-empty">No hay archivos G-code en la SD</div>';

        return;
      }

      files.forEach(function (f) {
        const sizeTxt =
          f.size >= 1048576
            ? `${(f.size / 1048576).toFixed(1)} MB`
            : `${Math.round(f.size / 1024)} KB`;

        const isActive = SM.loadedFile === f.name;

        const row = document.createElement("div");

        row.className = "fm-file-row" + (isActive ? " active-file" : "");

        row.style.marginBottom = "6px";

        row.innerHTML =
          '<button class="fm-file-load-btn" title="Cargar ' +
          escHtml(f.name) +
          '">' +
          '<span class="fm-file-ico"><svg width=16 height=16 viewBox="0 0 24 24" fill=none stroke=currentColor stroke-width=2 stroke-linecap=round stroke-linejoin=round><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg></span>' +
          '<span class="fm-file-name" style="font-size:14px">' +
          escHtml(f.name) +
          "</span>" +
          '<span class="fm-file-meta">' +
          sizeTxt +
          "</span>" +
          '<svg width=13 height=13 viewBox="0 0 24 24" fill=currentColor style="color:var(--green-strong);opacity:.6;flex-shrink:0"><polygon points="5 3 19 12 5 21 5 3"/></svg>' +
          "</button>" +
          '<div class="fm-file-actions">' +
          '<button class="fm-action-btn edit" title="Editar"><svg width=12 height=12 viewBox="0 0 24 24" fill=none stroke=currentColor stroke-width=2.5 stroke-linecap=round stroke-linejoin=round><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg></button>' +
          '<button class="fm-action-btn del" title="Eliminar"><svg width=12 height=12 viewBox="0 0 24 24" fill=none stroke=currentColor stroke-width=2.5 stroke-linecap=round stroke-linejoin=round><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4h6v2"/></svg></button>' +
          "</div>";

        row
          .querySelector(".fm-file-load-btn")
          .addEventListener("click", async function () {
            if (window.machineMoveBlocked && window.machineMoveBlocked(true)) return;
            $(`tvFilesModal`).classList.remove("show");

            toast(`${t("msg.loadingPfx", "Cargando")} ${f.name}…`, "info");

            let gcode = null;

            // No descargar el G-code (varios MB) si hay un trabajo activo:
            // saturaría el WiFi compitiendo con el polling. Crítico desde el
            // pendant (el operario está junto a la máquina).
            if (SM.current !== STATES.RUNNING && SM.current !== STATES.PAUSED) {
              try {
                // FIX t_34d8ec32 (H-N7): escudo tryConnect antes de descargar
                // /gcodes/<file> desde el pendant — sin él, un atacante en la
                // WiFi puede leer G-codes completos (dimensiones, material,
                // parámetros de corte, propiedad intelectual) sin autenticar.
                let shieldOk = true;
                if (typeof window !== `undefined` && window.rotechosAuth && typeof window.rotechosAuth.tryConnect === `function`) {
                  const sc = await window.rotechosAuth.tryConnect(TARGET_IP, ``);
                  if (!sc || !sc.ok) {
                    log(`pendant rr_download(load): escudo auth rechaza — archivo no cargado`, `warn`);
                    shieldOk = false;
                  }
                }
                if (shieldOk) {
                  const r = await RRF.download('0:/gcodes/' + f.name);

                  if (r.ok) gcode = await r.text();
                }
              } catch (e) {}
            }

            await loadFile(f.name, gcode);

            if (badgeEl) badgeEl.textContent = files.length || "—";
          });

        row
          .querySelector(".fm-action-btn.del")
          .addEventListener("click", async function () {
            if (SM.loadedFile === f.name && SM.current === STATES.RUNNING) {
              toast(t("msg.cantDeleteRunning", "No se puede eliminar mientras ejecuta"), "warn");
              return;
            }

            if (
              !(await confirmDialog(
                t(`dlg.fileDelete.title`, `Eliminar archivo`),
                `¿Eliminar <strong>${escHtml(f.name)}</strong>? Esta acción no se puede deshacer.`,
              ))
            )
              return;

            // Usar la API HTTP rr_delete en lugar de G-code M30 para evitar inyección
            const r = await RRF.deleteFile(`0:/gcodes/${f.name}`);

            if (r) {
              toast(`"${f.name}" ${t("msg.deletedSfx", "eliminado")}`, "ok");
              log(`rr_delete: 0:/gcodes/${f.name}`, "cmd");

              if (SM.loadedFile === f.name) {
                SM.loadedFile = null;
                SM.transition(STATES.IDLE, "archivo eliminado");
              }

              tvLoadFilesModal();
            } else {
              toast(t("msg.deleteErr", "Error al eliminar"), "err");
            }
          });

        row
          .querySelector(".fm-action-btn.edit")
          .addEventListener("click", async function () {
            // H-novato-tanda2 #9: defensa en profundidad — si por algún motivo
            // llega un nombre de archivo vacío (carril roto, antigua entrada
            // del modal en el DOM, etc.), NO abrimos el editor mudo: avisamos
            // con el mensaje accionable y abortamos. El editor oficial (fileEditor-
            // Modal en rotechos.js) tiene su propia guarda en btnEditorSave, pero
            // este call-site en PENDANT es el que el lote #9 mide y es la ÚLTIMA
            // línea de defensa antes de abrir el modal.
            if (!f.name || !String(f.name).trim()) {
              toast(t(`msg.noFileName`, `Sin nombre de archivo — pulsa el icono de carpeta arriba para seleccionar un .g de la SD antes de Guardar`), `err`);
              return;
            }
            // Editor oficial (H-4-02 · decisión 2026-08-17 opción A):
            // fileEditorModal + btnEditorSave (rotechos.js:3009-3100), el
            // ÚNICO con lint _lintGcode que bloquea >256 chars y TAB en .g.
            // EDITOR siempre está definido al boot (defer en orden
            // rotechos.js → rotechos-fm.js → rotechos-pendant.js).
            try {
              // FIX t_34d8ec32 (H-N7): escudo tryConnect antes de descargar
              // /gcodes/<file> para abrir el editor desde el pendant — sin él,
              // un atacante en la WiFi puede descargar el G-code y leerlo.
              let shieldOk = true;
              if (typeof window !== `undefined` && window.rotechosAuth && typeof window.rotechosAuth.tryConnect === `function`) {
                const sc = await window.rotechosAuth.tryConnect(TARGET_IP, ``);
                if (!sc || !sc.ok) {
                  log(`pendant rr_download(edit): escudo auth rechaza — editor no abierto`, `warn`);
                  shieldOk = false;
                  // FIX t_34d8ec32 (H-N7): escudo aborta descarga antes de
                  // abrir el editor. Mostramos el mismo toast de "no se pudo
                  // leer" que ya usa el call-site para 401/timeout, para que
                  // el operario reciba la misma pista UX ante escudo, red o
                  // firmware y no diagnostique en falso.
                  toast(t(`msg.loadFailedSaveLocked`, `No se pudo leer el archivo de la SD — no se guarda para no pisarlo; cierra este editor, vuelve a abrir el archivo desde el icono de carpeta y reintenta`), `err`);
                }
              }
              if (shieldOk) {
                const r = await RRF.download('0:/gcodes/' + f.name);
                if (!r.ok) {
                  // H-novato-tanda2 #10: el guardado queda BLOQUEADO porque si la
                  // descarga falla NO tenemos contenido limpio para subir — pisaríamos
                  // el archivo en SD con basura. Mensaje accionable: 3 pasos.
                  toast(t(`msg.loadFailedSaveLocked`, `No se pudo leer el archivo de la SD — no se guarda para no pisarlo; cierra este editor, vuelve a abrir el archivo desde el icono de carpeta y reintenta`), `err`);
                  return;
                }
                const content = await r.text();
                // Fijar contexto ANTES de abrir el modal: el handler de
                // btnEditorSave (rotechos.js:3066) lee `editingFileName ||
                // EDITOR.filename` y `editingFileDir` para decidir destino del
                // upload. Sin editingFileDir, subiría al dir por defecto
                // (0:/sys) en lugar de /gcodes/.
                window.editingFileName = f.name;
                window.editingFileDir = `0:/gcodes`;
                window.EDITOR.open(f.name, content);
              }
            } catch (e) {
              toast(`${t(`msg.error`, `Error`)}: ${e.message}`, `err`);
            }
          });

        body.appendChild(row);
      });
}

(function () {
  const modal = $(`tvFilesModal`);
  const closeBtn = $(`btnTvFilesModalClose`);
  const refreshBtn = $(`tvFilesModalRefresh`);
  const uploadBtn = $(`tvFilesModalUpload`);
  const fileInput = $(`tvFilesModalFileInput`);

  if (closeBtn)
    closeBtn.addEventListener("click", function () {
      modal.classList.remove("show");
    });

  if (modal)
    modal.addEventListener("click", function (e) {
      if (e.target === modal) modal.classList.remove("show");
    });

  if (refreshBtn)
    refreshBtn.addEventListener("click", function () {
      tvLoadFilesModal();
      toast(t("msg.listUpdated", "Lista actualizada"), "info");
    });

  if (uploadBtn && fileInput) {
    uploadBtn.addEventListener("click", function () {
      fileInput.click();
    });

    fileInput.addEventListener("change", async function () {
      const files = Array.from(this.files);

      if (!files.length) return;

      // No subir durante un trabajo: FM.upload pausa el polling y sin el latido
      // uiBeat el watchdog de daemon.g PAUSARÍA el corte a mitad.
      if (SM.current === STATES.RUNNING) {
        toast(t("msg.cantUploadDuringJob", "No se puede subir archivos durante un trabajo"), "warn");
        this.value = "";
        return;
      }

      modal.classList.remove("show");

      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        const safeName = file.name.replace(/[^\w.-]/g, "_").replace(/_+/g, "_");

        if (safeName !== file.name)
          toast(`${t("msg.nameSanitized", "Nombre sanitizado →")} "${safeName}"`, "warn");

        log(`Subiendo: ${safeName} (${FM.fmtSize(file.size)})`, "sys");

        const ok = await FM.upload(file, function () {}, safeName);

        // 14-sep: el fallo ya lo avisa FM.upload con la causa; este, solo de respaldo.
        if (ok) toast(`"${safeName}" ${t("msg.uploadedSfx", "subido")}`, "ok");
        else if (!window.rotechosOpFeedback) toast(`${t("msg.uploadErrorPfx", "Error subiendo")} "${safeName}"`, "err");

        await sleep(300);
      }

      fmLoadList && fmLoadList();
    });
  }
})();
