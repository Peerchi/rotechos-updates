// RotechOS Service Worker — CACHE-FIRST para el app shell.
// Decisión de diseño: network-first saturaba el ESP con 11 GET por apertura;
// una revalidación en background (SWR real) re-introduciría ese mismo tráfico,
// así que se sirve caché SIN revalidar (cruce eval 2026-07-05: el header decía
// "stale-while-revalidate" pero el código siempre fue cache-first — era el
// comentario lo que estaba mal, no el código).
// IMPORTANTE: la frescura la garantiza EXCLUSIVAMENTE el bump de CACHE_NAME
// tras cada subida a la SD — ¡cada despliegue DEBE subir la versión!
//
// El DIARIO de versiones (qué entró en cada bump) vive en
// docs/dev/historial-sw.md. Estaba aquí dentro y eran 87 KB de texto que la
// placa servía en cada actualización del SW sin que ningún navegador los
// leyera: de los 91.082 B del fichero, solo 3.520 eran código.
// Al subir versión: escribe la entrada en ese fichero y bumpea la línea de
// abajo. La frescura de la caché depende EXCLUSIVAMENTE de ese bump.

const CACHE_NAME = 'rotechos-v360';
const STATIC_ASSETS = [
  '/index.html',
  '/css/rotechos.css',
  '/js/rotechos-version.js',
  '/js/rotechos-logger.js',
  '/js/rotechos-error-trap.js',
  '/js/rotechos-storage.js',
  '/js/rotechos-i18n.js',
  '/js/rotechos-i18n-cockpit.js',
  '/js/rotechos-i18n-config.js',
  '/js/rotechos-i18n-dynjs.js',
  '/js/rotechos-dom.js',
  '/js/rotechos-led.js',
  '/js/rotechos-config-persist.js',
  '/js/rotechos-auth.js',
  '/js/rotechos-ota-zip.js',
  '/js/rotechos-const.js',
  '/js/rotechos-dom-utils.js',
  '/js/rotechos-shield-msgs.js',
  '/js/rotechos-confirm.js',
  '/js/rotechos-state-ui.js',
  '/js/rotechos-ui-states.js',
  '/js/rotechos-layout.js',
  '/js/rotechos-gcode-map.js',
  '/js/rotechos-dom-helpers.js',
  '/js/rotechos-lint-gcode.js',
  '/js/rotechos-paro-teclado.js',
  '/js/rotechos-viz-empty.js',
  '/js/rotechos-m999-watchdog.js',
  // FASE 5 (t_f92d87da): el banner AP sale del monolito como fachada EAGER.
  // Razón: el IIFE se ejecutaba al final de rotechos.js con registerUIHook ya
  // vivo; el patrón fachada (APDetector.init()) lo invoca desde bootStep4,
  // pero el módulo en sí debe estar cargado ANTES de rotechos.js para que
  // window.APDetector exista en el call site de rotechos-modules.js:596
  // (`window.APDetector ? await APDetector._check() : null`). Sin entrada
  // aquí, un cliente SIN RED abriría un index que pide el módulo y no lo
  // encontraría en caché: el banner AP quedaría mudo justo cuando el
  // operario más lo necesita (máquina virgen recién conectada al AP).
  '/js/rotechos-apdetector.js',
  '/js/rotechos-telemetry.js',
  '/js/rotechos.js',
  '/js/rotechos-config-modal-core.js',
  '/js/rotechos-modal-backdrop.js',
  '/js/rotechos-ui-feedback.js',
  '/js/rotechos-op-feedback.js',
  '/js/rotechos-aspiracion-follow.js',
  '/js/rotechos-poll.js',
  '/js/rotechos-file-ops.js',
  '/js/rotechos-wcs.js',
  '/js/rotechos-welcome.js',
  '/js/rotechos-firstcut.js',
  '/js/rotechos-backup.js',
  '/js/rotechos-notif.js',
  '/js/rotechos-fm.js',
  '/js/rotechos-config-accel-curve.js',
  '/js/rotechos-config-pins-ui.js',
  '/js/rotechos-config-search.js',
  '/js/rotechos-config-tools-table.js',
  '/js/rotechos-config-homing-maint.js',
  '/js/rotechos-facing-wizard.js',
  '/js/rotechos-mesh-probe.js',
  '/js/rotechos-bordeador.js',
  // Perezoso (2026-08-31): paquete de diagnostico. Se precachea como el resto
  // de perezosos para que este en disco antes de que el operario lo pida —
  // justo cuando algo falla es cuando peor momento hay para depender de la red.
  '/js/rotechos-diag.js',
  '/js/rotechos-endstop-diag.js',
  '/js/rotechos-modo-murcielago.js',
  '/js/rotechos-zcal.js',
  '/js/rotechos-macros.js',
  '/js/rotechos-jog.js',
  '/js/rotechos-spindle.js',
  '/js/rotechos-viz.js',
  '/js/rotechos-pendant.js',
  '/js/rotechos-autofit.js',
  '/js/rotechos-modules.js',
  '/js/rotechos-ota.js',
  '/js/rotechos-ota-install.js',
  // Perezoso (t_b8cd40c2): el modal de CONFIGURACION sale del arranque en
  // frio (sale de index.html y de cold arranque), pero SIGUE en el precache
  // porque contiene 6 call sites del helper perezoso INTERNO que cargan
  // los sub-modulos de cada pestana. Si el modal no estuviera en el
  // precache, un operario offline que abra VELOCIDADES / HOMING /
  // CONTROLADORA / BUSCADOR / HERRAMIENTAS / APLANADO dispararia un
  // fetch y fallaria, aunque el modulo concreto SI estuviera en
  // precache. Mantener el modal precacheado es la unica forma de que
  // los perezosos internos lleguen al cliente offline. El cold arranque
  // NO se ve afectado: cache-first lo trae en background despues del
  // primer paint — no entra en el cold medido.
  '/js/rotechos-config-modal.js',
  '/manifest.json',
  '/icons/icon-192.png',
  '/icons/icon-512.png',
];

self.addEventListener('install', e => {
  e.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => cache.addAll(STATIC_ASSETS))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', e => {
  if (e.request.method !== 'GET') return;

  const url = new URL(e.request.url);

  // Otro origen (el manifest y el paquete de GitHub): siempre a la red. Con
  // cache-first, «Buscar actualizaciones» leía para siempre el primer
  // manifest visto y respondía «Estás al día» con una versión nueva publicada.
  if (url.origin !== self.location.origin) return;

  // Nunca interceptar la API del firmware RRF — siempre datos en vivo.
  if (
    url.pathname.startsWith('/rr_') ||
    url.pathname.startsWith('/machine') ||
    url.pathname.startsWith('/api') ||
    url.pathname.startsWith('/sd')
  ) return;

  // Navegaciones (p.ej. "/"): solo se cachea /index.html.
  if (e.request.mode === 'navigate') {
    e.respondWith(
      caches.match('/index.html').then(cached => {
        if (cached) return cached;
        return fetch(e.request).then(resp => {
          if (resp.ok) {
            const clone = resp.clone();
            caches.open(CACHE_NAME).then(c => c.put('/index.html', clone));
          }
          return resp;
        });
      })
    );
    return;
  }

  // CACHE-FIRST: caché al instante. Si no hay caché, va a red y la guarda.
  e.respondWith(
    caches.match(e.request).then(cachedResponse => {
      if (cachedResponse) {
        return cachedResponse;
      }
      return fetch(e.request).then(networkResponse => {
        if (networkResponse.ok && networkResponse.type !== 'opaque') {
          const clone = networkResponse.clone();
          caches.open(CACHE_NAME).then(c => c.put(e.request, clone));
        }
        return networkResponse;
      });
    })
  );
});
