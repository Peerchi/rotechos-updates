# RotechOS v2026.10 — notas de versión

**Versión:** 2026-10-31
**Estado: pendiente de validación en banco.**

## Novedades de la 2026-10-31

- **Husillo y finales de carrera.** El calentamiento ya no puede volver a arrancar la
  fresa después de saltar un final de carrera. Aparcar, ir a 0, bordeador y coreografía
  se niegan a moverse con un final pisado.
- **Eje Z.** Las subidas de seguridad del bordeador, la coreografía y la sonda ya no
  pueden bajar unos milímetros antes de viajar.
- **Jog.** Mantener pulsado se para al perder el foco o con el botón derecho, y no
  repite pasos de más de 10 mm, ni con ratón ni con teclado. LIBRE respeta el límite
  de velocidad del firmware.
- **Aplanado con husillo manual.** Pide encender el Makita antes de empezar.
- **Configuración.** Sonda, homing y rampa ya no dicen «guardado» si falla la SD, y al
  activar el eje A se guarda bien su driver.
- **OTA y restauración.** Se bloquean con la máquina ocupada, y la carga manual protege
  los mismos ficheros de máquina que el instalador.
- **Interfaz y manual.** Una lectura sin coordenadas ya no muestra ceros falsos, el
  asistente de bienvenida cabe en el móvil apaisado y el manual se ha corregido contra
  la interfaz real.

## Novedades de la 2026-10-30

- **OTA más segura ante cortes y configuraciones personalizadas.** La instalación
  deja una transacción pendiente antes de escribir, valida las rutas del paquete,
  detecta conflictos de macros y solo recupera una copia antigua de `config.g`
  cuando existe una OTA interrumpida.
- **Compatibilidad con máquinas antiguas.** Si una máquina todavía no tiene
  manifiesto OTA y ya contiene un macro, ese macro se conserva y la actualización
  continúa; las siguientes instalaciones ya pueden comparar su huella.
- **Espacio y estado de la SD comprobados también en cargas manuales.** La UI
  rechaza una SD ausente o sin espacio suficiente antes de transferir archivos y
  no permite subir archivos mientras la máquina está moviéndose o ejecutando una
  macro.
- **Reinicio confirmado.** Si la placa no confirma `M999`, la interfaz informa
  de que los archivos se escribieron pero el reinicio no quedó confirmado.
- **PWA coherente con la red real.** En el AP HTTP de la máquina la UI sigue
  funcionando, pero no promete modo offline; el Service Worker solo se registra
  en un contexto seguro.
- **Validación de interfaz más fiable.** El gate de “sin scroll” espera a que el
  layout se estabilice y ya no se queda esperando el timeout completo por cada
  pestaña.
- **Validación en banco pendiente.** Antes de producción hay que probar físicamente
  homing, desplazamientos, VFD/Makita, ventiladores y persistencia de la
  configuración.

## Novedades de la 2026-10-29

- **Pausa y reanudación más seguras.** La interfaz reconoce los estados transitorios de RRF (`pausing` y `cancelling`) y espera la confirmación real antes de ofrecer REANUDAR o continuar el trabajo.
- **Configuración de máquina preservada en OTA.** La actualización mantiene `M150` y las órdenes de configuración desconocidas para no perder personalizaciones de la máquina al actualizar.
- **Marca y experiencia de actualización revisadas.** Se reparan enlaces de archivo de la marca y se mantiene la preparación del paquete para instalación OTA.
- **Validación en banco pendiente.** Antes de producción hay que probar físicamente homing, desplazamientos, VFD/Makita, ventiladores y persistencia de la configuración.

## Novedades de la 2026-10-28

- **Clave propia para la red RotechOS.** En CONFIGURACIÓN → Red puedes generar
  una clave solo para tu máquina e imprimir una etiqueta con la red, la clave y
  la dirección. Mientras no la generes sigue valiendo `rotechos`, y siempre
  puedes leerla en la SD (`sys/ap-key.g`).
- **Final de carrera durante un jog.** La interfaz deja de mandar jog y bloquea
  ese sentido; el contrario sigue disponible para alejarte. Si el eje sigue
  moviéndose, usa PARO o la seta.
- **Tras el PARO la interfaz vuelve a conectar sola**, sin recargar la página.
- **Los pasos largos de jog ya no se atascan:** techo de velocidad en X/Y.
- **Ventiladores de la electrónica** también en máquinas con un config.g viejo.
- **Soft limits coherentes** con los finales en X/Y/Z MAX: la pestaña lee la
  calibración de la máquina.
- **Dashboard a pantalla completa** en escritorio, rejilla del visor más ligera,
  doble toque en el visor tras HOME aunque no haya G-code y vuelve el favicon.
- **Móvil más claro.** El estado de la máquina se ve también en apaisado, hay
  un indicador de HOME y «XYZ 0» y APARCAR se muestran como aviso, no en verde.
- **El jog usa la velocidad real de la máquina desde el arranque**: lee M203,
  M201 y M208 de config.g y config-machine.g, no los valores de fábrica.
- Pendiente de validación en banco: clave del punto de acceso (generar, imprimir,
  arrancar sin WiFi), final de carrera en jog, reconexión tras el PARO, pasos
  largos de jog, ventiladores a 45 °C, vista móvil en apaisado y velocidad del
  jog tras arrancar.

## Novedades de la 2026-10-27

- **El aplanado no corta sin husillo.** Si el husillo no arranca, el asistente
  se para antes de la primera pasada, y solo dice «finalizado» cuando la
  máquina confirma el apagado.
- **El móvil dice la verdad sobre el husillo.** APAGAR y ENCENDER esperan la
  respuesta de la máquina; si no llega, aviso rojo para usar PARO o la seta.
- **Finales de carrera más seguros.** En el ordenador y la tableta, el PARO ya
  no queda tapado por el aviso de final de carrera. Reanudar y LIMPIAR ALARMA
  comprueban antes que el sensor esté libre. Si salta durante un jog, el aviso
  ya no dice que el eje está parado: pide PARO si sigue moviéndose.
- **Menos movimientos con la fresa girando.** Ir a 0 y el Bordeador apagan el
  husillo antes de moverse, y HOME TODOS del móvil no se lanza en pausa. Los
  ceros no se fijan con una macro en marcha.
- **Visor más fiel.** Entiende G91, G20, G53, comentarios entre paréntesis y
  arcos en los tres planos; el aviso de «M3 sin espera» mira cada encendido.
- **Actualizaciones más seguras.** La instalación comprueba la respuesta de la
  placa por cada fichero, verifica la reposición de config.g y no toca los
  ceros guardados, la malla ni el historial de la máquina.
- Pendiente de validación en banco: aplanado con el VFD desconectado, APAGAR del
  móvil con la WiFi cortada, final de carrera con trabajo en marcha y en jog,
  Ir a 0 y Bordeador con el husillo encendido, y una actualización completa.

## Novedades de la 2026-10-26

- **El bordeador ya no puede bajar de más.** Antes subía y bajaba la fresa en
  relativo: si arrancabas con Z arriba, podía recorrer el perímetro hasta 40 mm
  más bajo que el punto de partida. Ahora usa cotas de máquina y nunca baja de
  la Z de partida. Además, solo dice «completado» cuando ha apagado el husillo
  y restaurado el modo, y si se agota el tiempo lo cuenta como error.
- **El botón del husillo dice la verdad.** Solo marca apagado o encendido
  cuando la máquina responde. Si el apagado no se confirma (por ejemplo, con la
  WiFi caída), sale un aviso rojo para usar PARO o la seta.
- **Asistente de primer arranque más seguro.** Mientras baja la sonda o gira el
  husillo de prueba no se puede pasar de paso; el test del husillo arranca con
  rampa y, con husillo manual (Makita), se omite.
- **Final de carrera y botones de cero confirman con la máquina.** Con un
  trabajo en marcha, el final de carrera solo marca «pausado» si la máquina lo
  confirma; si no, pide PARO. Los botones de cero no actúan con datos viejos ni
  con un trabajo en curso.
- Pendiente de validación en banco: bordeador con Z arriba y a media altura,
  apagado del husillo con la WiFi cortada, pasos 10 y 11 del asistente (VFD y
  Makita), final de carrera con trabajo en marcha y ceros con móvil y
  ordenador a la vez.

## Novedades de la 2026-10-25

- **El escudo de finales de carrera para también el HOME y los palpados.** Si
  se pisa un final de seguridad durante un HOME, el SAC, la Sonda Z, la malla o
  el palpado XY/3D, la macro se detiene en la siguiente fase y avisa con
  «final de carrera de seguridad disparado», en vez de seguir moviendo. M6 y
  los palpados no arrancan con un final del escudo pisado.
- **El visor del G-code dibuja la mesa de la máquina.** Se ven los límites de
  la mesa y el cero de máquina, la pieza y la fresa salen donde caen de verdad
  y se mueven al fijar el cero o cambiar de G54 a G55. La fresa muestra su Z y
  en rojo se marcan exactamente los tramos que salen del área. Sin G-code
  cargado también se ven la mesa y la fresa.
- **Marca de tu empresa en la pantalla (opcional).** El botón Marca de la
  cabecera deja poner nombre, subtítulo, logo (PNG, JPG o WebP), color y marca
  de agua para vídeos. Se guarda en el navegador; no toca la máquina.
  RotechOS sigue visible siempre.
- **Manual de usuario rediseñado.** La tarjeta «Mi primer corte» sale de la
  interfaz; el primer corte se explica paso a paso en el capítulo 6 del manual.
- Si vienes de una versión anterior a la 2026-10-24, instala esta dos veces
  para que `config.g` reciba también sus mejoras.

## Novedades de la 2026-10-24

- **Actualizar ya trae las mejoras de `config.g` sin tocar lo de tu máquina.**
  Hasta ahora `config.g` no se actualizaba nunca. Ahora se toma el de la versión
  nueva y se le copian, tal cual, las líneas que son de tu máquina: nombre,
  sentido y modo de cada driver, mapeo de ejes, finales de carrera, sonda,
  husillo, HOME obligatorio, límites y las preferencias de la interfaz. El
  anterior queda guardado en la SD como `config.g.antes-ota`. Si algo no
  cuadra, `config.g` no se toca.
- **Siguen sin tocarse** tu calibración y tu PIN (`config-machine.g`),
  `board.txt`, la WiFi y las macros o mallas propias.
- Esta mejora vive en el instalador, así que se aplica a partir de la
  siguiente actualización. Si quieres las mejoras de `config.g` ya, instala
  esta misma versión una segunda vez.

## Novedades de la 2026-10-23

- **HOME obligatorio para empezar o reanudar un trabajo.** INICIAR y la
  reanudación piden la máquina referenciada.
- **Las subidas a Z segura ya no bajan la fresa.** El doble toque del visor,
  ir a 0, aparcar, SAC/M6, la malla y el palpado solo suben Z; antes, justo
  después del HOME, bajaban hasta 10 mm antes de moverse en XY.
- **ESC para el trabajo aunque haya un diálogo abierto.** Si el PARO está en
  otra tecla y la parada no se confirma, la interfaz lo dice y no da el
  trabajo por cancelado.
- **Ayuda corregida de la altura Z de seguridad.** Cuanto menor es el valor,
  más alta viaja la fresa.
- **Asistente de puesta en marcha más seguro.** Cada movimiento va en una sola
  orden y se comprueba la respuesta.
- **Macros.** Pausar y reanudar esperan la confirmación de la máquina, y un
  doble toque ya no lanza la misma macro dos veces.
- **Fallos de red visibles.** Jog, microajuste Z y los diálogos del firmware
  ya no dan el paso por hecho si la máquina no respondió.
- **Motores.** La ayuda del eje A ya no habla de un driver 4 inexistente y
  los drivers vetados se respetan.
- **Actualizar conserva `board.txt`** de cada máquina, igual que `config.g`.

## Novedades de la 2026-10-22

- **Guardar CONFIGURACIÓN es más robusto.** Un doble toque rápido en
  «Aplicar» solo inicia un guardado; evita dos escrituras simultáneas sobre la
  calibración de la máquina.

## Novedades de la 2026-10-21

- **Bloqueo del PIN más consistente.** CONFIGURACIÓN consulta el tiempo de
  bloqueo al mismo componente que autentica; se elimina una lectura duplicada
  de almacenamiento que podía quedar desalineada al cambiar esa política.

## Novedades de la 2026-10-20

- **Mover desde el visor.** En vista superior, un doble toque eleva Z a la
  altura segura configurada y desplaza XY al punto elegido. Solo funciona con
  HOME completo, máquina en reposo y un punto dentro del área configurada.

## Novedades de la 2026-10-19

- **Visor G-code tras recargar.** La trayectoria permanece durante la sesión
  del navegador y vuelve a dibujarse solo si la placa confirma que sigue
  seleccionado exactamente el mismo archivo. No controla la máquina ni se
  conserva al cerrar el navegador.
- **Recuperación visible.** Cuando la máquina está en ERROR, MODO EXPERTO y
  MODO ESCUELA muestran junto a REINICIAR el orden seguro: liberar la causa,
  confirmar la placa, reconectar y hacer HOME ALL antes de mover.

## Novedades de la 2026-10-18

- **Actualización OTA más resistente.** Rechaza antes de escribir la SD los
  ZIP de más de 16 MiB, con más de 2.000 ficheros o más de 64 MiB expandidos;
  evita que un paquete corrupto agote la memoria del móvil.
- **Teclado en el PIN HTTP.** El cuadro de PIN mantiene el foco dentro,
  Escape lo cancela desde cualquiera de sus botones y al cerrar vuelve al
  control que lo abrió.

## Novedades de la 2026-10-17

- **Corriente de motores fiable.** Con un driver externo en X, la interfaz lee
  correctamente una corriente parcial como `M906 Y2200 I20`: al reiniciar no la
  sustituye visualmente por el valor por defecto de 800 mA.
- **Configuración segura ante un fallo de lectura.** Si la placa no puede leer
  `config-machine.g`, CONFIGURACIÓN abre solo COPIA DE SEGURIDAD, deja las
  calibraciones vacías y bloquea APLICAR. Así no se muestran ni se guardan
  valores inventados mientras se recupera la tarjeta SD.

## Novedades de la 2026-10-16

- **Homing y sentido de giro.** El homing es secuencial Z → X → Y y bloquea HOME
  si has invertido un motor hasta que confirmes físicamente que el sentido positivo
  va a su final MAX.
- **Corriente de motores.** La configuración M906 se guarda con su porcentaje Idle
  y se vuelve a leer tras reiniciar; por ejemplo, 2200 mA no vuelve a 800 mA.
- **Interfaz más clara y resistente.** HOME no se puede pedir dos veces durante el
  ciclo, PARO y desconexión se distinguen en el pendant, los controles táctiles de
  tableta alcanzan 44 px y las animaciones LED son más suaves.
- **Sin cambios de red.** Ethernet sigue en desarrollo y no forma parte de esta
  actualización: la Scylla con ESP32 original sigue usando AP/WiFi como antes.

## Novedades de la 2026-10-14

- **Sentido de motor seguro.** Al invertir un eje, HOME queda bloqueado hasta comprobar
  físicamente que el sentido positivo alcanza su final MAX; evita buscar el MIN por error.
- **Corriente de motores.** Guardar 2000 mA conserva el porcentaje Idle y se relee desde
  `config-machine.g` tras reiniciar.
- **Jog directo.** Ya no pide confirmación por un movimiento normal, incluso a 50 mm;
  siguen activos HOME, topes, límites de recorrido, PARO y el microajuste Z.

## Novedades de la 2026-10-13

- **Arranque más ligero.** La interfaz descarga unos 36 KB menos al abrirse (el diccionario
  de textos de CONFIGURACIÓN se carga solo al abrir CONFIGURACIÓN o si usas el idioma inglés),
  y pide una sola vez el listado de archivos.
- **El visor del G-code ya no repinta sin parar.** Solo dibuja cuando hay cambios y se detiene
  con la vista oculta: menos consumo de batería en el móvil.
- **Actualizar es más seguro.** «Instalar ahora» y «Instalar desde un ZIP» no instalan mientras
  la máquina está en HOME, simulando, ejecutando una macro o el bordeador.
- **Detalles de aspecto.** Los botones deshabilitados del panel del móvil se leen bien, el
  selector del tipo de sonda ya no se corta, «Sin macros» sale centrado y el área de soltar
  del visor 3D muestra el foco del teclado.
- **Límites internos.** Tope en el historial de pantallas del móvil y en la cola de avisos
  (los errores nunca se descartan); el filtro de archivos del móvil espera a que dejes de teclear.
- Pendiente de validación en banco, como el resto de la versión.

## Novedades de la 2026-10-12

- **Las macros que creas se pueden editar y borrar otra vez.**
- **INPUT SHAPING sale de CONFIGURACIÓN.** La pestaña ofrecía un ajuste que esta máquina no
  usa; ya no aparece.
- **Aspecto de CONFIGURACIÓN.** Los desplegables de micropasos de Motores siguen el tema
  oscuro, los contadores de la barra lateral cuadran con las pestañas y los avisos largos
  enseñan dos líneas con una flecha visible.
- **Panel del móvil.** HOME pasa a la primera fila, antes de INICIAR, y la celda vacía de JOG
  deja de parecer un botón que falta.
- Cambios solo de aspecto y orden; el comportamiento de la máquina no cambia. Pendiente de
  validación en banco.

## Novedades de la 2026-10-11

- **REARMAR tras un PARO funciona.** Después de pulsar PARO (o ESC) la placa queda detenida
  y solo admite reiniciarse. REARMAR / RECUPERAR decía «Sensores re-armados» y la máquina
  seguía en ERROR; ahora reinicia la placa y la interfaz vuelve sola cuando está lista.
- **«Requerir HOME» desactivado deja mover los ejes.** La interfaz bloqueaba el movimiento
  manual sin HOME aunque la opción estuviera quitada. Ahora la obedece y avisa una vez de que
  la máquina no sabe dónde está. Aparcar, el cambio de herramienta y las sondas siguen
  exigiendo HOME.
- **El diagnóstico de finales de carrera ve los tres ejes.** Con los finales Max de X, Y y Z
  activos, al abrir CONFIGURACIÓN solo se marcaba el de X, y guardar la pestaña Endstops
  dejaba sin protección los de Y y Z. Corregido.
  En la pestaña Endstops, cada fila de «Lectura» muestra ahora el estado de su propio pin, y
  una nota recuerda que «LIBRE» no demuestra que haya un sensor conectado.
- **El PIN es opcional.** Una instalación nueva abre la interfaz sin contraseña; el PIN se
  pone o se quita en CONFIGURACIÓN → PIN HTTP.
  **Si ya tienes RotechOS instalado:** actualizar no toca tu calibración, así que conservas
  el PIN que tuvieras. La interfaz lo llama «PIN antiguo de fábrica» y te ofrece cambiarlo o
  quitarlo.
- **WiFi.** El paso 4 del asistente une la máquina a tu WiFi sin reiniciarla (antes volvía a
  la red RotechOS y no se unía nunca). La red propia sale siempre con su nombre y su clave,
  **RotechOS** / `rotechos`. En una placa nueva cuyo módulo WiFi no arranca, la máquina le
  graba su firmware una sola vez.
- **Macro nueva `ventiladores_prueba`.** Enciende los ventiladores de la electrónica al 100 %
  durante 15 segundos y los devuelve al control por temperatura. Sirve para saber si un
  ventilador parado es cosa del cableado o de la configuración. No se ejecuta con un trabajo
  en marcha.

## Novedades de la 2026-10-10

- **El eje X va por su conector de fábrica.** La configuración de fábrica (`config.g`) mueve
  ahora el eje X con el driver 0, el conector **X** de la BTT Scylla
  (`M584 X0 Y1 Z2`). Hasta la 2026-10-09 lo movía el driver 3, el conector **A**, un apaño
  para una placa con el driver X dañado. El conector A queda libre para el eje A opcional.
  **Instalación nueva:** enchufa el motor X al conector X.
  **Si ya tienes RotechOS instalado:** actualizar no toca tu `config.g`, así que tu máquina
  sigue moviendo X por donde lo tengas cableado y no tienes que hacer nada. Si quieres pasar
  X al conector X, copia el `sys/config.g` de este ZIP a la SD (o cambia el driver de X en
  CONFIGURACIÓN → Motores), mueve el cable del motor y reinicia.
  Tras el cambio, comprueba que X se mueve hacia donde toca; si va al revés, invierte su
  sentido en CONFIGURACIÓN → Motores.
- La interfaz va más fluida: en cada lectura de la máquina solo redibuja lo que ha cambiado,
  y arranca algo más rápido.

## Novedades de la 2026-10-09

- **Las actualizaciones se instalan desde la interfaz.** Cuando sale el aviso de versión nueva,
  trae el botón **Instalar ahora**: descarga la versión, comprueba que llega entera y la
  escribe en la SD. Si el dispositivo no tiene internet (por ejemplo, conectado a la red
  RotechOS), descarga el ZIP desde otro y usa **Instalar desde un ZIP** en
  CONFIGURACIÓN → ACTUALIZAR (OTA), sin descomprimirlo. Las dos piden confirmación, conservan
  tu calibración (`config-machine.g`), el mapeo de motores (`config.g`) y tu WiFi, y reinician
  la placa al terminar.
  **Esta vez todavía se instala a mano** (sección 2 de la guía), porque tu versión actual no
  trae el instalador; las siguientes ya se instalan desde la interfaz.
- «Buscar actualizaciones» ya no se queda con una versión vieja guardada en el navegador: antes
  podía responder «Estás al día» habiendo una nueva.

## Novedades del 8 de octubre

- **De fábrica, la máquina arranca en su propia red.** Crea la red **RotechOS** (clave
  `rotechos`, `http://192.168.1.1`) nada más encender, sin esperar a ninguna WiFi ni llevar
  credenciales de nadie. Si prefieres tu WiFi, se pone en CONFIGURACIÓN → Red.
  **Si ya trabajabas con tu WiFi:** tras actualizar, la máquina aparecerá en la red RotechOS.
  Conéctate a ella, abre `http://192.168.1.1` y vuelve a unirla a tu WiFi en
  CONFIGURACIÓN → Red; desde entonces arrancará en tu WiFi como antes.
- La interfaz arranca un poco más rápido: la página principal viaja sin comentarios internos.

## Novedades del 7 de octubre

- **WiFi desde la interfaz, sin cable USB.** En CONFIGURACIÓN → Red hay una tarjeta WiFi:
  dice en qué red está la máquina, permite unirla a tu WiFi y tiene el interruptor
  «Trabajar siempre con la red propia RotechOS» para talleres sin WiFi (arranca directamente
  en esa red, sin esperar). Si la WiFi que escribes no conecta, la máquina vuelve a crear la
  red RotechOS en un par de minutos. El aviso naranja de la red propia tiene dos botones:
  «Poner mi WiFi» y «Seguir con esta red».
- **Placa nueva.** El ZIP trae ahora el firmware del módulo WiFi (`firmware/`) y la
  plantilla de calibración (`rotechos-sys/config-machine.g.ejemplo`), y la página de la
  versión trae `firmware.bin` (RepRapFirmware 3.5.4) aparte. La guía de instalación tiene un
  paso 0 para grabarlo.

## Novedades del 6 de octubre

- **Ventiladores de la electrónica (AUX1).** Se encienden solos cuando el procesador de la
  placa llega a 45 °C o un driver de motor avisa de que se calienta. La temperatura se cambia
  en CONFIGURACIÓN → VENTILADORES (de 30 a 50 °C). AUX1 da la tensión de la fuente (24 o
  48 V): los ventiladores tienen que ser de esa tensión.
- **Cargar un G-code** comprueba que la máquina ha abierto el fichero. Antes decía LISTO
  aunque no lo hubiera encontrado, y luego INICIAR no hacía nada.
- **CONFIGURACIÓN:** TIMEOUT MOTORES, RED e INPUT SHAPING enseñaban el valor de fábrica al
  reabrirlas aunque hubieras guardado otro, y guardar otra vez lo devolvía al de fábrica.
- **Macro `diagnostico.g`:** escribe en la consola el estado de la máquina (versión,
  temperaturas, sensores, red, calibración) para copiarlo cuando algo falla. No mueve nada.

## Novedades del 5 de octubre

Arreglos encontrados antes de la primera sesión de banco. Si ya cargaste la del 4 de
octubre, instala esta encima: no hace falta nada más.

- **Red RotechOS de respaldo.** Si la máquina no encuentra tu WiFi, ahora levanta su red
  propia de forma fiable; antes podía no aparecer.
- **Finales de carrera.** El escudo vigila por defecto los tres finales MAX, y los de homing
  vuelven a tener pull-up. Antes, una SD con un `config-machine.g` antiguo bloqueaba todos los
  trabajos.
- **Palpado** recortado al recorrido real del eje.
- **Postprocesador de Fusion 360.** El G-code generado ya se ejecuta entero en RepRapFirmware:
  antes el husillo no arrancaba y se perdía parte de la trayectoria. Vuelve a elegirlo en
  Fusion después de actualizar.
- **Interfaz:** el PIN de la placa se pide de verdad; el PARO funciona aunque la sesión haya
  caducado; los ficheros con espacios o acentos se encuentran; INICIAR, PAUSA y CANCELAR ya no
  fallan en iPhones sin actualizar; el jog avisa de que hace falta RESET tras un PARO; el
  asistente WiFi acepta contraseñas de 8 a 63 caracteres.
- El ejemplo `test_cuadrado_400x400.gcode` espera 3 segundos de verdad (antes eran 3 ms).
- **Historial de trabajos y horas de husillo.** Abrir la interfaz desde un móvil o un
  ordenador nuevo ya no borra el historial guardado en la máquina.
- **Archivos.** Con muchos G-code en la SD ya salen todos en ARCHIVOS, en el móvil y en la
  copia de seguridad (antes la lista se cortaba sin avisar). Si un fichero no se puede borrar,
  la interfaz lo dice en vez de darlo por borrado.
- **Husillo manual (Makita).** Al reanudar una pausa, la interfaz pide encenderlo antes de
  seguir, igual que al iniciar.
- **Final de carrera durante un trabajo.** La máquina para antes de encender el LED rojo
  (antes el LED podía hacerla esperar a terminar el movimiento en curso).
- **Cambio de herramienta.** Si el sensor de herramienta no está calibrado, avisa antes de
  mover nada; y un cambio manual fuera de un trabajo vuelve a dejar la dinámica suave.
- **Manual:** la clave de la red RotechOS es `rotechos` (el manual decía `123456789`, que es
  el PIN de la interfaz).

---

Igual que la anterior: probada a fondo en el ordenador (unas 2.000 pruebas unitarias, más de
900 de interfaz y un simulador de las macros contra el fuente de RepRapFirmware 3.5.4), pero
**todavía no con la máquina encendida**. Sin material y con la mano en la seta hasta que pase
la sesión de banco.

---

## Lo que cambia para ti en la v2026.10

### Arreglos en las macros de la máquina

- **La placa arrancaba sin configurar.** Un fichero de arranque (`globals.g`) usaba una
  sintaxis que RepRapFirmware 3.5.4 no admite y abortaba `config.g` entero: ejes, husillo y
  WiFi se quedaban sin cargar. Corregido.
- **Los palpados iban a otro sitio.** La Sonda Z, el Palpador 3D y el mapa de altura
  calculaban el destino como si fuera relativo, y el firmware lo trata como absoluto. Ahora
  todos los palpados van a una coordenada de máquina calculada desde la posición real.
- **El Palpador 3D abortaba siempre** y el **mapa de altura** usaba operaciones que el
  firmware no tiene. Los dos reescritos.
- **El HOME de Z ya no baja 10 mm a ciegas** antes de buscar el final de carrera.
- Sin conexión, la temperatura del micro ya no muestra un valor inventado: muestra «—».
- **El PARO externo y las salidas de PINES no llegaban a configurarse**: la interfaz pedía al
  firmware un número de pin fuera de rango. Si los tenías asignados, no funcionaban.
- **El microajuste de Z de un trabajo se resetea al empezar el siguiente.** Antes se quedaba
  puesto, sin aviso.
- **El escudo de finales de carrera solo mira los lados que tienen sensor**: una máquina con
  finales solo en un extremo ya no ve cancelados todos sus trabajos al empezar.
- **Parar durante un cambio de herramienta** (ESC, Espacio, cancelar una macro) ya no puede
  dejar la máquina atascada: la interfaz no manda la pausa y te pide usar el PARO.
- **Desplegar ya no borra tu cero de pieza** (`saved_offsets.g`).

### Área de trabajo nueva: X530 × Y830

Las medidas de fábrica pasan a X530 × Y830 (Z sigue de 0 a −115). Si tu máquina ya estaba
instalada, **tu `config-machine.g` no se toca**: cambia los límites desde
CONFIGURACIÓN → Límites de recorrido si tu máquina es de las nuevas medidas.

### Husillo manual (Makita)

CONFIGURACIÓN → Husillo tiene un modo **Manual**. Con él, la pantalla dice MANUAL en vez de
PARADO o en marcha, INICIAR te pide encender el husillo antes de empezar, y al acabar o
cancelar te recuerda apagarlo con su interruptor. La pantalla no puede encender ni apagar un
husillo manual.

### El móvil en horizontal

Un móvil girado ahora usa la vista de móvil completa, con el PARO en su sitio, en lugar del
panel de escritorio comprimido.

### Aviso de actualizaciones

Al abrir la interfaz, el navegador comprueba si hay una versión nueva publicada y, si la hay,
muestra un aviso con enlace a la descarga. Si vas varias versiones atrás, te dice cuántas:
cada versión trae la SD completa, así que basta con instalar la última. La instalación sigue
siendo manual: nada se instala solo en la máquina.

### Interfaz

Tres pasadas de acabado visual: tamaños de botones y textos, contraste en tema claro y oscuro,
pantallas que se cortaban en tableta y escritorio.

---

## Si vienes de la v2026.09

**Haz primero una copia de seguridad** (CONFIGURACIÓN → RESPALDO → *Descargar backup.zip*).
Sube los ficheros de la nueva versión desde ACTUALIZAR (OTA), como siempre. `globals.g` y
las macros de palpado y HOME cambian: súbelos todos. Tu calibración (`config-machine.g`) no
viaja en el paquete y no se pisa.

---

## Lo que falta por validar con la máquina (nuevo en la v2026.10)

- **Arranque:** que `config.g` cargue completo con el `globals.g` nuevo.
- **Palpados:** Sonda Z, Palpador 3D y mapa de altura, con el destino en coordenadas de
  máquina. Primero en vacío, con la mano en la seta.
- **Husillo manual:** los avisos de encender y apagar.
- Los puntos de la v2026.09, más abajo, siguen pendientes.

---

# Versión anterior: v2026.09

**Fecha:** 26 de septiembre de 2026
**Estado: candidata de lanzamiento, pendiente de validación en banco.**

Qué quiere decir eso, sin rodeos: la interfaz y las macros están probadas a fondo en el
ordenador —unas 2.900 pruebas automáticas, un simulador de las macros de seguridad y una
revisión independiente de los caminos de seguridad—, pero **todavía no se han probado con la
máquina encendida en esta versión**. Hasta que eso pase, trátala como una versión para
probar con cuidado, sin material y con la mano en la seta de emergencia. Lo que falta está al
final de este documento.

---

## Lo que cambia para ti

### Seguridad

- **El PARO sin WiFi ya no te engaña.** Si pulsas PARO en la pantalla y la red se ha caído,
  la orden de parada no llega a la máquina. Antes el botón decía igualmente «M112 ENVIADO».
  Ahora dice **«M112 NO ENTREGADO: USA LA SETA»**, y en cuanto vuelve la red la interfaz
  **envía la parada de nuevo**. Recuerda: la seta roja física es siempre lo primero.
- **El husillo no arranca solo al reanudar** si estaba parado cuando pausaste (por ejemplo,
  entre dos operaciones). *Cambio en las macros: pendiente de probar con la máquina.*
- **Tus ajustes de calibración ya no se pierden en silencio.** Si cambiabas dos límites de
  recorrido seguidos, o guardabas los pines (CONTROLADORA) o HERRAMIENTAS mientras otro ajuste se estaba
  guardando, uno de los dos podía perderse aunque la pantalla dijera «guardado». Lo notabas al
  reiniciar la máquina. Ahora los guardados van uno detrás de otro.
- **Tras el cambio de herramienta (M6), el husillo espera a tu OK.** Antes arrancaba solo a los
  3 segundos del aviso, justo después de tocar la fresa. Si tu husillo es manual (Makita),
  el aviso te recuerda apagarlo antes de tocar la fresa y encenderlo antes de pulsar OK: la
  máquina no puede apagarlo ni encenderlo por ti. *Pendiente de probar con la máquina.*
- **Un final de carrera durante un trabajo pausa la máquina al instante**, en vez de medio
  segundo después y con el husillo ya parado. *Pendiente de probar con la máquina.*
- **El cero de pieza se guarda en el sistema de coordenadas que estés usando** (G55, G56…),
  también al cambiar de herramienta o con la Sonda Z. Antes iba siempre a G54.
  *Pendiente de probar con la máquina.*
- **El microajuste de Z durante un trabajo ahora funciona** (antes la orden no movía nada):
  como mucho 1 mm por pulsación, y una pulsación es un solo ajuste aunque mantengas el botón o
  la tecla. El ajuste queda puesto hasta reiniciar la máquina.
- **Al encender, haz HOME.** La máquina ya no se da por referenciada con la posición de la
  última vez (podías haberla movido a mano con ella apagada). El cero de pieza sí se conserva.
- **Cancelar un aviso del firmware detiene de verdad lo que viene detrás.** Antes, pulsar
  Cancelar en el cambio de herramienta podía dejar el trabajo siguiendo sin cambiar la fresa o
  sin husillo. Y los avisos que solo tienen OK ya no enseñan un botón Cancelar.
  *Pendiente de probar con la máquina.*
- **No se puede reanudar si durante la pausa un eje perdió la referencia o X/Y se quedaron sin
  corriente**: la interfaz lo dice y te pide cancelar y hacer HOME.
- **El botón externo de PARO** (si lo cableas) usa ahora la parada de emergencia directa del
  firmware, sin esperar a nada. *Pendiente de probar con la máquina.*
- **Sin HOME no se puede iniciar un trabajo** mientras «Requerir HOME» esté activado (lo normal).
  Antes la interfaz lo permitía y la máquina se daba por referenciada donde estuviera.
- **Cancelar una macro** ya no dice «cancelada» hasta que la máquina confirma que ha parado. Si
  sigue en marcha, la interfaz te lo dice: para una macro, lo que funciona es el PARO o la seta.

### Actualizar la máquina

- La zona de **ACTUALIZAR (OTA)** coloca cada fichero en su carpeta, también los `.gz`,
  `sw.js` y los de `www/data` y `www/icons`. Antes algunos se iban a una carpeta equivocada y
  la pantalla podía seguir mostrando la versión vieja.
- La OTA **rechaza** los ficheros que son solo de tu máquina: `config-machine.g` (tu
  calibración), `config-override.g` y las credenciales WiFi.
- Si subes `config.g`, **te pregunta antes**: lleva el mapeo de tus motores (qué driver mueve
  cada eje, sentido de giro, finales de carrera).
- La copia de seguridad guarda ahora la versión de RotechOS con la que se hizo.

### Sonda Z: los textos dicen lo que hace la máquina

La Sonda Z **no palpa la pieza**: va al pulsador fijo (el mismo del cambio de herramienta) y
pone Z=0 en la mesa **más el grosor de material** configurado en CONFIGURACIÓN → SONDA Z. La
interfaz y el manual hablaban de una «pastilla» sobre la pieza y de una pinza de cocodrilo, que
no se usan. **Si tenías ahí el grosor de una pastilla, cámbialo por el grosor de tu material**:
con el valor equivocado el cero queda mal y la fresa corta de más o de menos.

### La interfaz en inglés

- Los avisos que en inglés mostraban texto roto como «Endstop ${ax} triggered» ahora dicen
  el eje, el fichero o el valor de verdad.
- Traducidos los textos de seguridad que seguían en español: el aviso de que un botón de paro
  leído por software **no es** una parada de emergencia, la ayuda de herramientas (M563) y la
  lista de atajos de teclado, entre otros.

### Otras mejoras

- **Tableta:** la tarjeta ESTADO ya muestra el tiempo del trabajo y el sistema de
  coordenadas sin cortarlos.
- **Historial y mantenimiento:** los trabajos y las horas de husillo se apuntan siempre.
  Antes solo se registraban si abrías la pestaña HISTORIAL en esa sesión, así que los avisos
  de mantenimiento podían ir muy retrasados.
- **Bloque de soporte:** el botón COPIAR SOPORTE (CONFIGURACIÓN → IDENTIDAD) no copiaba nada al portapapeles cuando la
  interfaz se sirve desde la máquina, aunque dijera «copiado». Ahora, si el navegador no deja
  copiar, te muestra el texto para copiarlo a mano.
- **Móvil:** la pantalla ya no se queda en blanco por una navegación a una pantalla que no
  existe.
- El manual de usuario está al día con esta versión (capturas nuevas y textos corregidos).

---

## Si vienes de la v2026.08

**Haz primero una copia de seguridad** (CONFIGURACIÓN → RESPALDO → *Descargar backup.zip*).

Esta versión trae un **`config.g` nuevo**: valores de reserva más prudentes para una máquina
sin calibrar y la detección de fuente de 24 V o 48 V. Tu calibración no está ahí, está en
`config-machine.g`, que no se toca.

- Si **nunca** cambiaste nada en MOTORES, FINAL DE CARRERA o CONTROLADORA, sube también el
  `config.g` nuevo.
- Si **sí** los cambiaste (sentido de giro, driver de algún eje, finales de carrera, pines),
  apunta lo que tienes antes de actualizar, sube el `config.g` nuevo y vuelve a aplicarlo
  desde esas mismas pestañas. Después, **antes de hacer HOME**, mueve cada eje un poco con el
  JOG y la mano en la seta para comprobar que va hacia donde debe.

El procedimiento paso a paso está en `GUIA_INSTALACION.md`.

---

## Lo que esta versión NO hace

- **No tiene marcado CE.** Se ofrece como kit / retrofit; la conformidad de la máquina final
  es de quien la integra.
- **No reanuda un trabajo tras un corte de luz.** Hay que relanzarlo desde el principio.
- **No incluye la pantalla física RotechOS Touch.** Ese firmware existe, pero no está
  validado en hardware y no forma parte de esta versión.
- La sección **Drivers externos (M569 D2)** de MOTORES no está validada: no la actives.
- El botón **Buscar actualizaciones** de la v2026.09 consultaba un canal que no existía. Desde
  la v2026.10 el aviso funciona; si no tienes internet, usa el ZIP que te hayan entregado.

---

## Lo que falta por validar con la máquina

Ninguno de estos puntos se puede cerrar desde un ordenador. Hasta que estén probados:
**sin material, sin fresa dentro de la pieza y con la mano en la seta.**

- **Referenciado (HOME):** que la máquina detecte un final de carrera desconectado en vez de
  creer que ha llegado; y que la Z no baje más de la cuenta al referenciar cerca de la mesa.
- **Palpado (sonda Z, mapa de altura, palpado 3D):** que un palpado que no toca, o con el
  cable de la sonda cortado, se detenga con un error.
- **Final de carrera durante un trabajo:** que pause la máquina a tiempo.
- **Corte de tensión (M911):** que apague el husillo y levante la Z.
- **Pausa y reanudación:** el cambio del husillo de esta versión.
- **Jog LIBRE:** cuánto sigue moviéndose la máquina después de soltar el botón.
- **Finales de carrera:** hoy pausan el trabajo, pero no cortan el movimiento que ya está en
  marcha. Si deben parar la máquina al instante está pendiente de decidir y de probar.
- **Cambio de herramienta (M6) y Sonda Z:** el recorrido al pulsador y el cero resultante.
- **Pérdida de WiFi durante un trabajo:** que la máquina pause a los ~30 s sin interfaz.
- **PARO con la red caída:** el reenvío automático de la parada.
- **Primer arranque WiFi en una placa nueva** y **restaurar un respaldo con PIN**.
