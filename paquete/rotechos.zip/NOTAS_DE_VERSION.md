# RotechOS v2026.10 — notas de versión

**Versión:** 2026-10-09 (revisión de la publicada el 4 de octubre)
**Estado: candidata de lanzamiento, pendiente de validación en banco.**

## Novedades de la 2026-10-09

- **Las actualizaciones se instalan desde la interfaz.** Cuando sale el aviso de versión nueva,
  trae el botón **Instalar ahora**: descarga la versión, comprueba que llega entera y la
  escribe en la SD. Si el dispositivo no tiene internet (por ejemplo, conectado a la red
  RotechOS), descarga el ZIP desde otro y usa **Instalar desde un ZIP** en
  CONFIGURACIÓN → ACTUALIZAR (OTA), sin descomprimirlo. Las dos piden confirmación, conservan
  tu calibración (`config-machine.g`), el mapeo de motores (`config.g`) y tu WiFi, y reinician
  la placa al terminar.
  **Esta vez todavía se instala a mano** (sección 2 de la guía), porque tu versión actual no
  trae el instalador; las siguientes ya se instalan desde la interfaz.
- «Buscar actualizaciones» ya no se queda con una versión vieja guardada en el navegador: antes
  podía responder «Estás al día» habiendo una nueva.

## Novedades del 8 de octubre

- **De fábrica, la máquina arranca en su propia red.** Crea la red **RotechOS** (clave
  `rotechos`, `http://192.168.1.1`) nada más encender, sin esperar a ninguna WiFi ni llevar
  credenciales de nadie. Si prefieres tu WiFi, se pone en CONFIGURACIÓN → Red.
  **Si ya trabajabas con tu WiFi:** tras actualizar, la máquina aparecerá en la red RotechOS.
  Conéctate a ella, abre `http://192.168.1.1` y vuelve a unirla a tu WiFi en
  CONFIGURACIÓN → Red; desde entonces arrancará en tu WiFi como antes.
- La interfaz arranca un poco más rápido: la página principal viaja sin comentarios internos.

## Novedades del 7 de octubre

- **WiFi desde la interfaz, sin cable USB.** En CONFIGURACIÓN → Red hay una tarjeta WiFi:
  dice en qué red está la máquina, permite unirla a tu WiFi y tiene el interruptor
  «Trabajar siempre con la red propia RotechOS» para talleres sin WiFi (arranca directamente
  en esa red, sin esperar). Si la WiFi que escribes no conecta, la máquina vuelve a crear la
  red RotechOS en un par de minutos. El aviso naranja de la red propia tiene dos botones:
  «Poner mi WiFi» y «Seguir con esta red».
- **Placa nueva.** El ZIP trae ahora el firmware del módulo WiFi (`firmware/`) y la
  plantilla de calibración (`rotechos-sys/config-machine.g.ejemplo`), y la página de la
  versión trae `firmware.bin` (RepRapFirmware 3.5.4) aparte. La guía de instalación tiene un
  paso 0 para grabarlo.

## Novedades del 6 de octubre

- **Ventiladores de la electrónica (AUX1).** Se encienden solos cuando el procesador de la
  placa llega a 45 °C o un driver de motor avisa de que se calienta. La temperatura se cambia
  en CONFIGURACIÓN → VENTILADORES (de 30 a 50 °C). AUX1 da la tensión de la fuente (24 o
  48 V): los ventiladores tienen que ser de esa tensión.
- **Cargar un G-code** comprueba que la máquina ha abierto el fichero. Antes decía LISTO
  aunque no lo hubiera encontrado, y luego INICIAR no hacía nada.
- **CONFIGURACIÓN:** TIMEOUT MOTORES, RED e INPUT SHAPING enseñaban el valor de fábrica al
  reabrirlas aunque hubieras guardado otro, y guardar otra vez lo devolvía al de fábrica.
- **Macro `diagnostico.g`:** escribe en la consola el estado de la máquina (versión,
  temperaturas, sensores, red, calibración) para copiarlo cuando algo falla. No mueve nada.

## Novedades del 5 de octubre

Arreglos encontrados antes de la primera sesión de banco. Si ya cargaste la del 4 de
octubre, instala esta encima: no hace falta nada más.

- **Red RotechOS de respaldo.** Si la máquina no encuentra tu WiFi, ahora levanta su red
  propia de forma fiable; antes podía no aparecer.
- **Finales de carrera.** El escudo vigila por defecto los tres finales MAX, y los de homing
  vuelven a tener pull-up. Antes, una SD con un `config-machine.g` antiguo bloqueaba todos los
  trabajos.
- **Palpado** recortado al recorrido real del eje.
- **Postprocesador de Fusion 360.** El G-code generado ya se ejecuta entero en RepRapFirmware:
  antes el husillo no arrancaba y se perdía parte de la trayectoria. Vuelve a elegirlo en
  Fusion después de actualizar.
- **Interfaz:** el PIN de la placa se pide de verdad; el PARO funciona aunque la sesión haya
  caducado; los ficheros con espacios o acentos se encuentran; INICIAR, PAUSA y CANCELAR ya no
  fallan en iPhones sin actualizar; el jog avisa de que hace falta RESET tras un PARO; el
  asistente WiFi acepta contraseñas de 8 a 63 caracteres.
- El ejemplo `test_cuadrado_400x400.gcode` espera 3 segundos de verdad (antes eran 3 ms).
- **Historial de trabajos y horas de husillo.** Abrir la interfaz desde un móvil o un
  ordenador nuevo ya no borra el historial guardado en la máquina.
- **Archivos.** Con muchos G-code en la SD ya salen todos en ARCHIVOS, en el móvil y en la
  copia de seguridad (antes la lista se cortaba sin avisar). Si un fichero no se puede borrar,
  la interfaz lo dice en vez de darlo por borrado.
- **Husillo manual (Makita).** Al reanudar una pausa, la interfaz pide encenderlo antes de
  seguir, igual que al iniciar.
- **Final de carrera durante un trabajo.** La máquina para antes de encender el LED rojo
  (antes el LED podía hacerla esperar a terminar el movimiento en curso).
- **Cambio de herramienta.** Si el sensor de herramienta no está calibrado, avisa antes de
  mover nada; y un cambio manual fuera de un trabajo vuelve a dejar la dinámica suave.
- **Manual:** la clave de la red RotechOS es `rotechos` (el manual decía `123456789`, que es
  el PIN de la interfaz).

---

Igual que la anterior: probada a fondo en el ordenador (unas 2.000 pruebas unitarias, más de
900 de interfaz y un simulador de las macros contra el fuente de RepRapFirmware 3.5.4), pero
**todavía no con la máquina encendida**. Sin material y con la mano en la seta hasta que pase
la sesión de banco.

---

## Lo que cambia para ti en la v2026.10

### Arreglos en las macros de la máquina

- **La placa arrancaba sin configurar.** Un fichero de arranque (`globals.g`) usaba una
  sintaxis que RepRapFirmware 3.5.4 no admite y abortaba `config.g` entero: ejes, husillo y
  WiFi se quedaban sin cargar. Corregido.
- **Los palpados iban a otro sitio.** La Sonda Z, el Palpador 3D y el mapa de altura
  calculaban el destino como si fuera relativo, y el firmware lo trata como absoluto. Ahora
  todos los palpados van a una coordenada de máquina calculada desde la posición real.
- **El Palpador 3D abortaba siempre** y el **mapa de altura** usaba operaciones que el
  firmware no tiene. Los dos reescritos.
- **El HOME de Z ya no baja 10 mm a ciegas** antes de buscar el final de carrera.
- Sin conexión, la temperatura del micro ya no muestra un valor inventado: muestra «—».
- **El PARO externo y las salidas de PINES no llegaban a configurarse**: la interfaz pedía al
  firmware un número de pin fuera de rango. Si los tenías asignados, no funcionaban.
- **El microajuste de Z de un trabajo se resetea al empezar el siguiente.** Antes se quedaba
  puesto, sin aviso.
- **El escudo de finales de carrera solo mira los lados que tienen sensor**: una máquina con
  finales solo en un extremo ya no ve cancelados todos sus trabajos al empezar.
- **Parar durante un cambio de herramienta** (ESC, Espacio, cancelar una macro) ya no puede
  dejar la máquina atascada: la interfaz no manda la pausa y te pide usar el PARO.
- **Desplegar ya no borra tu cero de pieza** (`saved_offsets.g`).

### Área de trabajo nueva: X530 × Y830

Las medidas de fábrica pasan a X530 × Y830 (Z sigue de 0 a −115). Si tu máquina ya estaba
instalada, **tu `config-machine.g` no se toca**: cambia los límites desde
CONFIGURACIÓN → Límites de recorrido si tu máquina es de las nuevas medidas.

### Husillo manual (Makita)

CONFIGURACIÓN → Husillo tiene un modo **Manual**. Con él, la pantalla dice MANUAL en vez de
PARADO o en marcha, INICIAR te pide encender el husillo antes de empezar, y al acabar o
cancelar te recuerda apagarlo con su interruptor. La pantalla no puede encender ni apagar un
husillo manual.

### El móvil en horizontal

Un móvil girado ahora usa la vista de móvil completa, con el PARO en su sitio, en lugar del
panel de escritorio comprimido.

### Aviso de actualizaciones

Al abrir la interfaz, el navegador comprueba si hay una versión nueva publicada y, si la hay,
muestra un aviso con enlace a la descarga. Si vas varias versiones atrás, te dice cuántas:
cada versión trae la SD completa, así que basta con instalar la última. La instalación sigue
siendo manual: nada se instala solo en la máquina.

### Interfaz

Tres pasadas de acabado visual: tamaños de botones y textos, contraste en tema claro y oscuro,
pantallas que se cortaban en tableta y escritorio.

---

## Si vienes de la v2026.09

**Haz primero una copia de seguridad** (CONFIGURACIÓN → RESPALDO → *Descargar backup.zip*).
Sube los ficheros de la nueva versión desde ACTUALIZAR (OTA), como siempre. `globals.g` y
las macros de palpado y HOME cambian: súbelos todos. Tu calibración (`config-machine.g`) no
viaja en el paquete y no se pisa.

---

## Lo que falta por validar con la máquina (nuevo en la v2026.10)

- **Arranque:** que `config.g` cargue completo con el `globals.g` nuevo.
- **Palpados:** Sonda Z, Palpador 3D y mapa de altura, con el destino en coordenadas de
  máquina. Primero en vacío, con la mano en la seta.
- **Husillo manual:** los avisos de encender y apagar.
- Los puntos de la v2026.09, más abajo, siguen pendientes.

---

# Versión anterior: v2026.09

**Fecha:** 26 de septiembre de 2026
**Estado: candidata de lanzamiento, pendiente de validación en banco.**

Qué quiere decir eso, sin rodeos: la interfaz y las macros están probadas a fondo en el
ordenador —unas 2.900 pruebas automáticas, un simulador de las macros de seguridad y una
revisión independiente de los caminos de seguridad—, pero **todavía no se han probado con la
máquina encendida en esta versión**. Hasta que eso pase, trátala como una versión para
probar con cuidado, sin material y con la mano en la seta de emergencia. Lo que falta está al
final de este documento.

---

## Lo que cambia para ti

### Seguridad

- **El PARO sin WiFi ya no te engaña.** Si pulsas PARO en la pantalla y la red se ha caído,
  la orden de parada no llega a la máquina. Antes el botón decía igualmente «M112 ENVIADO».
  Ahora dice **«M112 NO ENTREGADO: USA LA SETA»**, y en cuanto vuelve la red la interfaz
  **envía la parada de nuevo**. Recuerda: la seta roja física es siempre lo primero.
- **El husillo no arranca solo al reanudar** si estaba parado cuando pausaste (por ejemplo,
  entre dos operaciones). *Cambio en las macros: pendiente de probar con la máquina.*
- **Tus ajustes de calibración ya no se pierden en silencio.** Si cambiabas dos límites de
  recorrido seguidos, o guardabas los pines (CONTROLADORA) o HERRAMIENTAS mientras otro ajuste se estaba
  guardando, uno de los dos podía perderse aunque la pantalla dijera «guardado». Lo notabas al
  reiniciar la máquina. Ahora los guardados van uno detrás de otro.
- **Tras el cambio de herramienta (M6), el husillo espera a tu OK.** Antes arrancaba solo a los
  3 segundos del aviso, justo después de tocar la fresa. Si tu husillo es manual (Makita),
  el aviso te recuerda apagarlo antes de tocar la fresa y encenderlo antes de pulsar OK: la
  máquina no puede apagarlo ni encenderlo por ti. *Pendiente de probar con la máquina.*
- **Un final de carrera durante un trabajo pausa la máquina al instante**, en vez de medio
  segundo después y con el husillo ya parado. *Pendiente de probar con la máquina.*
- **El cero de pieza se guarda en el sistema de coordenadas que estés usando** (G55, G56…),
  también al cambiar de herramienta o con la Sonda Z. Antes iba siempre a G54.
  *Pendiente de probar con la máquina.*
- **El microajuste de Z durante un trabajo ahora funciona** (antes la orden no movía nada):
  como mucho 1 mm por pulsación, y una pulsación es un solo ajuste aunque mantengas el botón o
  la tecla. El ajuste queda puesto hasta reiniciar la máquina.
- **Al encender, haz HOME.** La máquina ya no se da por referenciada con la posición de la
  última vez (podías haberla movido a mano con ella apagada). El cero de pieza sí se conserva.
- **Cancelar un aviso del firmware detiene de verdad lo que viene detrás.** Antes, pulsar
  Cancelar en el cambio de herramienta podía dejar el trabajo siguiendo sin cambiar la fresa o
  sin husillo. Y los avisos que solo tienen OK ya no enseñan un botón Cancelar.
  *Pendiente de probar con la máquina.*
- **No se puede reanudar si durante la pausa un eje perdió la referencia o X/Y se quedaron sin
  corriente**: la interfaz lo dice y te pide cancelar y hacer HOME.
- **El botón externo de PARO** (si lo cableas) usa ahora la parada de emergencia directa del
  firmware, sin esperar a nada. *Pendiente de probar con la máquina.*
- **Sin HOME no se puede iniciar un trabajo** mientras «Requerir HOME» esté activado (lo normal).
  Antes la interfaz lo permitía y la máquina se daba por referenciada donde estuviera.
- **Cancelar una macro** ya no dice «cancelada» hasta que la máquina confirma que ha parado. Si
  sigue en marcha, la interfaz te lo dice: para una macro, lo que funciona es el PARO o la seta.

### Actualizar la máquina

- La zona de **ACTUALIZAR (OTA)** coloca cada fichero en su carpeta, también los `.gz`,
  `sw.js` y los de `www/data` y `www/icons`. Antes algunos se iban a una carpeta equivocada y
  la pantalla podía seguir mostrando la versión vieja.
- La OTA **rechaza** los ficheros que son solo de tu máquina: `config-machine.g` (tu
  calibración), `config-override.g` y las credenciales WiFi.
- Si subes `config.g`, **te pregunta antes**: lleva el mapeo de tus motores (qué driver mueve
  cada eje, sentido de giro, finales de carrera).
- La copia de seguridad guarda ahora la versión de RotechOS con la que se hizo.

### Sonda Z: los textos dicen lo que hace la máquina

La Sonda Z **no palpa la pieza**: va al pulsador fijo (el mismo del cambio de herramienta) y
pone Z=0 en la mesa **más el grosor de material** configurado en CONFIGURACIÓN → SONDA Z. La
interfaz y el manual hablaban de una «pastilla» sobre la pieza y de una pinza de cocodrilo, que
no se usan. **Si tenías ahí el grosor de una pastilla, cámbialo por el grosor de tu material**:
con el valor equivocado el cero queda mal y la fresa corta de más o de menos.

### La interfaz en inglés

- Los avisos que en inglés mostraban texto roto como «Endstop ${ax} triggered» ahora dicen
  el eje, el fichero o el valor de verdad.
- Traducidos los textos de seguridad que seguían en español: el aviso de que un botón de paro
  leído por software **no es** una parada de emergencia, la ayuda de herramientas (M563) y la
  lista de atajos de teclado, entre otros.

### Otras mejoras

- **Tableta:** la tarjeta ESTADO ya muestra el tiempo del trabajo y el sistema de
  coordenadas sin cortarlos.
- **Historial y mantenimiento:** los trabajos y las horas de husillo se apuntan siempre.
  Antes solo se registraban si abrías la pestaña HISTORIAL en esa sesión, así que los avisos
  de mantenimiento podían ir muy retrasados.
- **Bloque de soporte:** el botón COPIAR SOPORTE (CONFIGURACIÓN → IDENTIDAD) no copiaba nada al portapapeles cuando la
  interfaz se sirve desde la máquina, aunque dijera «copiado». Ahora, si el navegador no deja
  copiar, te muestra el texto para copiarlo a mano.
- **Móvil:** la pantalla ya no se queda en blanco por una navegación a una pantalla que no
  existe.
- El manual de usuario está al día con esta versión (capturas nuevas y textos corregidos).

---

## Si vienes de la v2026.08

**Haz primero una copia de seguridad** (CONFIGURACIÓN → RESPALDO → *Descargar backup.zip*).

Esta versión trae un **`config.g` nuevo**: valores de reserva más prudentes para una máquina
sin calibrar y la detección de fuente de 24 V o 48 V. Tu calibración no está ahí, está en
`config-machine.g`, que no se toca.

- Si **nunca** cambiaste nada en MOTORES, FINAL DE CARRERA o CONTROLADORA, sube también el
  `config.g` nuevo.
- Si **sí** los cambiaste (sentido de giro, driver de algún eje, finales de carrera, pines),
  apunta lo que tienes antes de actualizar, sube el `config.g` nuevo y vuelve a aplicarlo
  desde esas mismas pestañas. Después, **antes de hacer HOME**, mueve cada eje un poco con el
  JOG y la mano en la seta para comprobar que va hacia donde debe.

El procedimiento paso a paso está en `GUIA_INSTALACION.md`.

---

## Lo que esta versión NO hace

- **No tiene marcado CE.** Se ofrece como kit / retrofit; la conformidad de la máquina final
  es de quien la integra.
- **No reanuda un trabajo tras un corte de luz.** Hay que relanzarlo desde el principio.
- **No incluye la pantalla física RotechOS Touch.** Ese firmware existe, pero no está
  validado en hardware y no forma parte de esta versión.
- La sección **Drivers externos (M569 D2)** de MOTORES no está validada: no la actives.
- El botón **Buscar actualizaciones** de la v2026.09 consultaba un canal que no existía. Desde
  la v2026.10 el aviso funciona; si no tienes internet, usa el ZIP que te hayan entregado.

---

## Lo que falta por validar con la máquina

Ninguno de estos puntos se puede cerrar desde un ordenador. Hasta que estén probados:
**sin material, sin fresa dentro de la pieza y con la mano en la seta.**

- **Referenciado (HOME):** que la máquina detecte un final de carrera desconectado en vez de
  creer que ha llegado; y que la Z no baje más de la cuenta al referenciar cerca de la mesa.
- **Palpado (sonda Z, mapa de altura, palpado 3D):** que un palpado que no toca, o con el
  cable de la sonda cortado, se detenga con un error.
- **Final de carrera durante un trabajo:** que pause la máquina a tiempo.
- **Corte de tensión (M911):** que apague el husillo y levante la Z.
- **Pausa y reanudación:** el cambio del husillo de esta versión.
- **Jog LIBRE:** cuánto sigue moviéndose la máquina después de soltar el botón.
- **Finales de carrera:** hoy pausan el trabajo, pero no cortan el movimiento que ya está en
  marcha. Si deben parar la máquina al instante está pendiente de decidir y de probar.
- **Cambio de herramienta (M6) y Sonda Z:** el recorrido al pulsador y el cero resultante.
- **Pérdida de WiFi durante un trabajo:** que la máquina pause a los ~30 s sin interfaz.
- **PARO con la red caída:** el reenvío automático de la parada.
- **Primer arranque WiFi en una placa nueva** y **restaurar un respaldo con PIN**.
